#!/usr/bin/env python3
"""
run_resolve.py — Resolve outcomes for tracked NIMBUS signals.

Run daily (after market close) to:
  1. Fetch close prices for signals that are ≥10 trading days old
  2. Mark them as resolved with P&L
  3. Check for regime drift
  4. Optionally export a report for analysis

Usage:
    python3 run_resolve.py             # resolve + drift check
    python3 run_resolve.py --export    # also export report to file
    python3 run_resolve.py --status    # just show current performance
"""

import argparse
import logging
import os
import sys
from datetime import date, timedelta

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("resolve")


def resolve_mature_signals():
    """
    Fetch outcomes for signals using the hybrid exit rules.

    Priority order on each bar (first match wins):
      1. HARD_STOP   — close ≤ entry × 0.95 (non-negotiable -5% floor)
      2. BAR_RATCHET — at bar 8, still underwater (cut slow-bleed losers early)
      3. PROFIT_TARGET → switches to TRAIL mode (winner runner)
      4. TRAIL_STOP  — peak − min(1.5×ATR, 4% of entry)
      5. BBW_CONTRACT — original signal-driven exit
      6. MAX_HOLD    — final cap at 30 bars

    See modules/dual_mode.py for the rule constants.
    """
    from modules.signal_tracker import get_unresolved, resolve_signal
    from modules.dual_mode import (
        PROFIT_TARGET, MAX_HOLD,
        HARD_STOP_PCT, BAR_RATCHET, TRAIL_ATR_MULT, MAX_TRAIL_PCT,
    )

    unresolved = get_unresolved()
    if not unresolved:
        logger.info("No unresolved MR signals")
        return 0

    # Filter to MR signals only (both PRIMARY and SECONDARY tiers — they're the
    # same strategy with different entry strictness). Ride is handled separately
    # by resolve_mature_ride_signals() with its own exit logic.
    unresolved = [s for s in unresolved if s.get("mode") in ("PRIMARY", "SECONDARY")]
    if not unresolved:
        logger.info("No unresolved MR signals")
        return 0

    # Hybrid exit rules can fire as early as bar 1 (HARD_STOP, PT). Wait
    # 2 calendar days from signal_date so the next trading day's close has
    # had time to land in yfinance. Anything older is fair game for evaluation.
    min_days_cutoff = date.today() - timedelta(days=2)
    # Signals at max hold (30 trading days ≈ 42 calendar days)
    max_hold_cutoff = date.today() - timedelta(days=MAX_HOLD + 12)

    candidates = [
        s for s in unresolved
        if s["signal_date"] <= min_days_cutoff.isoformat()
    ]

    if not candidates:
        logger.info(
            "%d MR signals pending, none old enough yet (cutoff: %s)",
            len(unresolved), min_days_cutoff,
        )
        return 0

    logger.info("Evaluating %d MR signals for exit", len(candidates))

    try:
        import yfinance as yf
    except ImportError:
        logger.error("yfinance required for resolution")
        return 0

    resolved = 0
    still_open = 0
    for sig in candidates:
        symbol = sig["symbol"]
        signal_date = sig["signal_date"]
        entry_price = sig["entry_price"]

        try:
            ticker = f"{symbol}.NS" if not symbol.startswith("^") else symbol
            # Fetch with extra history before signal_date so we can compute ATR(14)
            atr_lookback_start = (
                date.fromisoformat(signal_date) - timedelta(days=45)
            ).isoformat()
            df = yf.download(
                tickers=ticker, start=atr_lookback_start, interval="1d",
                auto_adjust=True, progress=False,
            )
            if hasattr(df.columns, "levels"):
                df.columns = df.columns.get_level_values(0)

            if df.empty or "Close" not in df.columns:
                logger.warning("No price data for %s from %s", symbol, signal_date)
                continue

            # Locate the entry bar (signal_date) in the fetched series
            df_idx = df.index.tz_localize(None) if df.index.tz is not None else df.index
            df.index = df_idx
            entry_ts = pd.Timestamp(signal_date)
            entry_pos_arr = df.index.get_indexer([entry_ts], method="bfill")
            if len(entry_pos_arr) == 0 or entry_pos_arr[0] < 0:
                logger.warning("Could not locate entry bar for %s on %s", symbol, signal_date)
                continue
            entry_pos = int(entry_pos_arr[0])

            # Compute ATR(14) on the full pre-entry history
            high = df["High"]; low = df["Low"]; close_full = df["Close"]
            prev_close = close_full.shift(1)
            tr = pd.concat([
                high - low,
                (high - prev_close).abs(),
                (low - prev_close).abs(),
            ], axis=1).max(axis=1)
            atr_14 = tr.rolling(14).mean()
            atr_at_entry = (
                float(atr_14.iloc[entry_pos])
                if entry_pos < len(atr_14) and not pd.isna(atr_14.iloc[entry_pos])
                else 0.0
            )

            # Slice forward from entry for the exit walk
            forward = df.iloc[entry_pos:].copy()
            closes = forward["Close"].dropna()
            if len(closes) < 2:
                continue

            # BBW slope and SMA on the forward window for original BBW exit logic
            sma_20 = forward["Close"].rolling(20, min_periods=10).mean()
            bb_ma = forward["Close"].rolling(20, min_periods=10).mean()
            bb_sd = forward["Close"].rolling(20, min_periods=10).std()
            bbw = ((bb_ma + 2*bb_sd) - (bb_ma - 2*bb_sd)) / bb_ma.replace(0, float('nan')) * 100
            bbw_slope = bbw.diff(5)

            # Pre-compute trail width for winner runner
            raw_trail = TRAIL_ATR_MULT * atr_at_entry
            max_trail = entry_price * MAX_TRAIL_PCT / 100
            trail_width = min(raw_trail, max_trail) if atr_at_entry > 0 else max_trail

            # Walk forward bar by bar applying hybrid rules
            exit_price = None
            exit_bar = None
            exit_reason = None
            in_trail_mode = False
            peak_price = entry_price

            # t=0 is entry day, start checking from t=1
            for t in range(1, min(MAX_HOLD, len(closes))):
                c = float(closes.iloc[t])
                pnl_pct = (c / entry_price - 1) * 100

                # Rule 1: HARD STOP — checked on every bar, non-negotiable
                if pnl_pct <= HARD_STOP_PCT:
                    exit_price = c; exit_bar = t; exit_reason = "HARD_STOP"
                    break

                # Rule 2: BAR RATCHET — only at the checkpoint, only if not trailing
                if not in_trail_mode and t == BAR_RATCHET and c < entry_price:
                    exit_price = c; exit_bar = t; exit_reason = "BAR_RATCHET"
                    break

                # Rule 3: PROFIT TARGET — switches to trail mode instead of exiting
                if not in_trail_mode and pnl_pct >= PROFIT_TARGET:
                    in_trail_mode = True
                    peak_price = c
                    continue

                # Rule 4: TRAIL STOP — only when in trail mode
                if in_trail_mode:
                    if c > peak_price:
                        peak_price = c
                    trail_stop = peak_price - trail_width
                    if c <= trail_stop:
                        exit_price = c; exit_bar = t; exit_reason = "TRAIL_STOP"
                        break
                    # Skip BBW check when actively trailing — let the trail run
                    continue

                # Rule 5: BBW contraction + above SMA (original signal-driven exit)
                if t >= 5 and t < len(sma_20) and t < len(bbw_slope):
                    sma_val = sma_20.iloc[t]
                    slope_val = bbw_slope.iloc[t]
                    if (not pd.isna(sma_val) and c > sma_val and
                        not pd.isna(slope_val) and slope_val < 0):
                        exit_price = c; exit_bar = t; exit_reason = "BBW_CONTRACT"
                        break

            # Rule 6: MAX_HOLD fallback
            if exit_price is None:
                if len(closes) >= MAX_HOLD:
                    exit_price = float(closes.iloc[MAX_HOLD - 1])
                    exit_bar = MAX_HOLD - 1
                    exit_reason = "MAX_HOLD"
                elif sig["signal_date"] <= max_hold_cutoff.isoformat():
                    # Past max hold period, use last available close
                    exit_price = float(closes.iloc[-1])
                    exit_bar = len(closes) - 1
                    exit_reason = "MAX_HOLD"
                else:
                    # No exit rule fired yet — trade is still open and within
                    # the MAX_HOLD window. Log it and move on. We'll re-check
                    # tomorrow when the next bar lands.
                    bars_walked = len(closes) - 1
                    last_close = float(closes.iloc[-1])
                    last_pnl = (last_close / entry_price - 1) * 100
                    logger.info(
                        "  %s %s: still open after %d bars, "
                        "current=%.2f P&L=%+.2f%% (no exit rule fired yet)",
                        symbol, signal_date, bars_walked, last_close, last_pnl,
                    )
                    still_open += 1
                    continue

            peak = float(closes.iloc[:exit_bar+1].max())
            pnl = (exit_price / entry_price - 1) * 100

            resolve_signal(
                signal_id=sig["id"],
                exit_price=exit_price,
                peak_price=peak,
                exit_reason=exit_reason,
            )
            logger.info(
                "  %s %s: entry=%.2f exit=%.2f P&L=%+.2f%% (%s, %dd)",
                symbol, signal_date, entry_price, exit_price, pnl,
                exit_reason, exit_bar,
            )
            resolved += 1

        except Exception as exc:
            logger.exception("Resolution failed for %s: %s", symbol, exc)

    if still_open:
        logger.info(
            "MR Summary: %d resolved, %d still open (within MAX_HOLD window)",
            resolved, still_open,
        )
    return resolved


# ══════════════════════════════════════════════════════════════════════════════
# RIDE RESOLVER
# ══════════════════════════════════════════════════════════════════════════════

# Ride exit constants are imported from modules/bb_ride.py — single source
# of truth. The constants there also feed BBRideResult dataclass field
# defaults so the live engine and the resolver can never drift apart.
from modules.bb_ride import (
    RIDE_HARD_STOP_PCT,
    RIDE_PROFIT_TARGET,
    RIDE_TRAIL_ATR_MULT,
    RIDE_MAX_TRAIL_PCT,
    RIDE_MAX_HOLD,
)


def resolve_mature_ride_signals():
    """
    Fetch outcomes for Ride signals using Ride-specific exit rules.

    Priority order on each bar (first match wins):
      1. HARD_STOP   — close ≤ entry × 0.95 (your principle, applies to all strategies)
      2. PROFIT_TARGET (+10%) → switches to TRAIL mode
      3. TRAIL_STOP  — peak − min(3.0×ATR, 8% of entry)
      4. MAX_HOLD    — final cap at 30 bars

    Notes:
      - No BAR_RATCHET (Ride is momentum continuation; chop tolerance is the play)
      - No BBW_CONTRACT (Ride doesn't use BBW contraction as exit signal)
      - The -5% HARD_STOP applies to Ride too — your principle is non-negotiable
        across strategies, not just MR
    """
    from modules.signal_tracker import get_unresolved, resolve_signal

    unresolved = get_unresolved()
    if not unresolved:
        return 0

    # Filter to RIDE signals only
    unresolved = [s for s in unresolved if s.get("mode") == "RIDE"]
    if not unresolved:
        logger.info("No unresolved Ride signals")
        return 0

    min_days_cutoff = date.today() - timedelta(days=2)
    max_hold_cutoff = date.today() - timedelta(days=RIDE_MAX_HOLD + 12)

    candidates = [
        s for s in unresolved
        if s["signal_date"] <= min_days_cutoff.isoformat()
    ]

    if not candidates:
        logger.info(
            "%d Ride signals pending, none old enough yet (cutoff: %s)",
            len(unresolved), min_days_cutoff,
        )
        return 0

    logger.info("Evaluating %d Ride signals for exit", len(candidates))

    try:
        import yfinance as yf
    except ImportError:
        logger.error("yfinance required for resolution")
        return 0

    resolved = 0
    still_open = 0
    for sig in candidates:
        symbol = sig["symbol"]
        signal_date = sig["signal_date"]
        entry_price = sig["entry_price"]

        try:
            ticker = f"{symbol}.NS" if not symbol.startswith("^") else symbol
            atr_lookback_start = (
                date.fromisoformat(signal_date) - timedelta(days=45)
            ).isoformat()
            df = yf.download(
                tickers=ticker, start=atr_lookback_start, interval="1d",
                auto_adjust=True, progress=False,
            )
            if hasattr(df.columns, "levels"):
                df.columns = df.columns.get_level_values(0)

            if df.empty or "Close" not in df.columns:
                logger.warning("No price data for %s from %s", symbol, signal_date)
                continue

            df_idx = df.index.tz_localize(None) if df.index.tz is not None else df.index
            df.index = df_idx
            entry_ts = pd.Timestamp(signal_date)
            entry_pos_arr = df.index.get_indexer([entry_ts], method="bfill")
            if len(entry_pos_arr) == 0 or entry_pos_arr[0] < 0:
                logger.warning("Could not locate entry bar for %s on %s", symbol, signal_date)
                continue
            entry_pos = int(entry_pos_arr[0])

            # ATR(14) for trailing stop sizing
            high = df["High"]; low = df["Low"]; close_full = df["Close"]
            prev_close = close_full.shift(1)
            tr = pd.concat([
                high - low,
                (high - prev_close).abs(),
                (low - prev_close).abs(),
            ], axis=1).max(axis=1)
            atr_14 = tr.rolling(14).mean()
            atr_at_entry = (
                float(atr_14.iloc[entry_pos])
                if entry_pos < len(atr_14) and not pd.isna(atr_14.iloc[entry_pos])
                else 0.0
            )

            forward = df.iloc[entry_pos:].copy()
            closes = forward["Close"].dropna()
            if len(closes) < 2:
                continue

            # Pre-compute trail width — Ride uses 3x ATR but capped at 8% of entry
            raw_trail = RIDE_TRAIL_ATR_MULT * atr_at_entry
            max_trail = entry_price * RIDE_MAX_TRAIL_PCT / 100
            trail_width = min(raw_trail, max_trail) if atr_at_entry > 0 else max_trail

            exit_price = None
            exit_bar = None
            exit_reason = None
            in_trail_mode = False
            peak_price = entry_price

            for t in range(1, min(RIDE_MAX_HOLD, len(closes))):
                c = float(closes.iloc[t])
                pnl_pct = (c / entry_price - 1) * 100

                # Rule 1: HARD STOP (-5% — your principle, applies to all strategies)
                if pnl_pct <= RIDE_HARD_STOP_PCT:
                    exit_price = c; exit_bar = t; exit_reason = "HARD_STOP"
                    break

                # Rule 2: PROFIT TARGET (+10%) — switches to trail mode
                if not in_trail_mode and pnl_pct >= RIDE_PROFIT_TARGET:
                    in_trail_mode = True
                    peak_price = c
                    continue

                # Rule 3: TRAIL STOP — only when in trail mode
                if in_trail_mode:
                    if c > peak_price:
                        peak_price = c
                    trail_stop = peak_price - trail_width
                    if c <= trail_stop:
                        exit_price = c; exit_bar = t; exit_reason = "TRAIL_STOP"
                        break

            # Rule 4: MAX_HOLD fallback
            if exit_price is None:
                if len(closes) >= RIDE_MAX_HOLD:
                    exit_price = float(closes.iloc[RIDE_MAX_HOLD - 1])
                    exit_bar = RIDE_MAX_HOLD - 1
                    exit_reason = "MAX_HOLD"
                elif sig["signal_date"] <= max_hold_cutoff.isoformat():
                    exit_price = float(closes.iloc[-1])
                    exit_bar = len(closes) - 1
                    exit_reason = "MAX_HOLD"
                else:
                    bars_walked = len(closes) - 1
                    last_close = float(closes.iloc[-1])
                    last_pnl = (last_close / entry_price - 1) * 100
                    logger.info(
                        "  RIDE %s %s: still open after %d bars, "
                        "current=%.2f P&L=%+.2f%% (no exit rule fired yet)",
                        symbol, signal_date, bars_walked, last_close, last_pnl,
                    )
                    still_open += 1
                    continue

            peak = float(closes.iloc[:exit_bar+1].max())
            pnl = (exit_price / entry_price - 1) * 100

            resolve_signal(
                signal_id=sig["id"],
                exit_price=exit_price,
                peak_price=peak,
                exit_reason=exit_reason,
            )
            logger.info(
                "  RIDE %s %s: entry=%.2f exit=%.2f P&L=%+.2f%% (%s, %dd)",
                symbol, signal_date, entry_price, exit_price, pnl,
                exit_reason, exit_bar,
            )
            resolved += 1

        except Exception as exc:
            logger.exception("Ride resolution failed for %s: %s", symbol, exc)

    if still_open:
        logger.info(
            "Ride Summary: %d resolved, %d still open (within MAX_HOLD window)",
            resolved, still_open,
        )
    return resolved


def show_status():
    """Display current performance and drift status."""
    from modules.signal_tracker import get_performance, check_drift, EXPECTED
    from modules.dual_mode import ENABLE_SECONDARY_TIER

    print("\n" + "=" * 60)
    print("NIMBUS FORWARD VALIDATION STATUS")
    print("=" * 60)

    # Skip SECONDARY display when disabled — no new signals being emitted
    tiers_to_show = [("PRIMARY", "Primary Entry")]
    if ENABLE_SECONDARY_TIER:
        tiers_to_show.append(("SECONDARY", "Secondary Entry"))

    for mode_key, mode_name in tiers_to_show:
        perf = get_performance(mode=mode_key)
        exp = EXPECTED[mode_key]
        print(f"\n── Tier {mode_key}: {mode_name} ──")

        if perf["n_signals"] == 0:
            print("  No resolved signals yet. Monitoring...")
            continue

        # Performance vs expectations
        wr = perf["win_rate"]
        avg = perf["avg_pnl"]
        wr_delta = wr - exp["win_rate"]
        avg_delta = avg - exp["avg_return"]

        print(f"  Signals:    {perf['n_signals']}")
        print(f"  Win rate:   {wr:5.1f}%  (expected {exp['win_rate']:.0f}%  Δ={wr_delta:+.1f}%)")
        print(f"  Avg P&L:    {avg:+.3f}%  (expected {exp['avg_return']:+.2f}%  Δ={avg_delta:+.2f}%)")
        print(f"  Median:     {perf['med_pnl']:+.3f}%")
        print(f"  Prof. fac:  {perf['profit_factor']:.2f}")
        print(f"  Sharpe:     {perf['sharpe']:.2f}  (expected {exp['sharpe']:.2f})")

    # Drift
    drift = check_drift()
    print(f"\n── Drift Detection ──")
    for mode_key, d in drift.items():
        icon = {"OK": "✓", "WARNING": "⚠", "ALERT": "✗", "NO_DATA": "○"}
        print(f"  {icon.get(d['status'], '?')} {d['message']}")

    print()


def export():
    """Export full report to file."""
    from modules.signal_tracker import export_report

    report = export_report()
    out_dir = os.path.join(os.path.dirname(__file__), "data", "backtest_results")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "forward_validation_report.txt")
    with open(path, "w") as f:
        f.write(report)
    print(f"\nReport exported: {path}")
    print("Upload this file for analysis.\n")
    print(report)


def main():
    parser = argparse.ArgumentParser(description="NIMBUS Signal Resolution")
    parser.add_argument("--export", action="store_true", help="Export report")
    parser.add_argument("--status", action="store_true", help="Show status only")
    args = parser.parse_args()

    from modules.signal_tracker import init_tracker
    init_tracker()

    if args.status:
        show_status()
        return

    # Resolve MR (PRIMARY) signals
    n_mr = resolve_mature_signals()
    logger.info("Resolved %d MR signals", n_mr)

    # Resolve Ride signals
    n_ride = resolve_mature_ride_signals()
    logger.info("Resolved %d Ride signals", n_ride)

    # Status
    show_status()

    # Export if requested
    if args.export:
        export()


if __name__ == "__main__":
    main()
