"""
ChartBuilder — All Plotly chart functions for the NSE Trading Signal Dashboard.
Dark theme throughout.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from typing import Optional

# ─── theme constants ──────────────────────────────────────────────────────────

BG = "#0d0d1a"
CARD_BG = "#14142a"
GRID = "#1e1e2e"
GREEN = "#00e676"
RED = "#ff5252"
GOLD = "#ffd740"
CYAN = "#00e5ff"
ORANGE = "#ff6d00"
PURPLE = "#ce93d8"
WHITE = "#e0e0e0"
MUTED = "#9e9e9e"


def _base_layout(**kwargs) -> dict:
    layout = dict(
        paper_bgcolor=BG,
        plot_bgcolor=BG,
        font=dict(color=WHITE, family="Inter, Segoe UI, sans-serif"),
        xaxis=dict(gridcolor=GRID, zerolinecolor=GRID, color=WHITE),
        yaxis=dict(gridcolor=GRID, zerolinecolor=GRID, color=WHITE),
        legend=dict(bgcolor=CARD_BG, bordercolor=GRID, borderwidth=1, font=dict(color=WHITE)),
        margin=dict(l=60, r=30, t=50, b=50),
        hoverlabel=dict(bgcolor=CARD_BG, bordercolor=GRID, font=dict(color=WHITE)),
    )
    layout.update(kwargs)
    return layout


# ─── 1. Main OI Wall Chart ────────────────────────────────────────────────────

def oi_wall_chart(
    walls_df: pd.DataFrame,
    call_walls: pd.DataFrame,
    put_walls: pd.DataFrame,
    cmp: Optional[float] = None,
    max_pain: Optional[float] = None,
    title: str = "Options Wall — Open Interest by Strike",
) -> go.Figure:
    fig = go.Figure()

    # Call OI bars (green, upward)
    fig.add_trace(go.Bar(
        x=walls_df["Strike"],
        y=walls_df["Call_OI"],
        name="Call OI",
        marker_color=GREEN,
        opacity=0.85,
        hovertemplate=(
            "<b>Strike %{x}</b><br>"
            "Call OI: %{y:,.0f}<br>"
            "<extra></extra>"
        ),
    ))

    # Put OI bars (red, downward — negative)
    fig.add_trace(go.Bar(
        x=walls_df["Strike"],
        y=-walls_df["Put_OI"],
        name="Put OI",
        marker_color=RED,
        opacity=0.85,
        hovertemplate=(
            "<b>Strike %{x}</b><br>"
            "Put OI: %{customdata:,.0f}<br>"
            "<extra></extra>"
        ),
        customdata=walls_df["Put_OI"],
    ))

    max_oi = walls_df[["Call_OI", "Put_OI"]].max().max()

    # Call Wall dashed lines
    for _, row in call_walls.iterrows():
        fig.add_vline(
            x=row["Strike"],
            line=dict(color=GREEN, width=2, dash="dash"),
            annotation=dict(
                text=f"CW {row['Strike']:.0f}",
                font=dict(color=GREEN, size=10),
                yref="paper",
                y=1.02,
            ),
        )

    # Put Wall dashed lines
    for _, row in put_walls.iterrows():
        fig.add_vline(
            x=row["Strike"],
            line=dict(color=RED, width=2, dash="dash"),
            annotation=dict(
                text=f"PW {row['Strike']:.0f}",
                font=dict(color=RED, size=10),
                yref="paper",
                y=-0.05,
            ),
        )

    # CMP golden line
    if cmp is not None:
        fig.add_vline(
            x=cmp,
            line=dict(color=GOLD, width=2.5),
            annotation=dict(
                text=f"CMP {cmp:.0f}",
                font=dict(color=GOLD, size=12, family="Inter Bold"),
                yref="paper",
                y=0.95,
            ),
        )

    # Max Pain cyan dashed
    if max_pain is not None:
        fig.add_vline(
            x=max_pain,
            line=dict(color=CYAN, width=2, dash="dot"),
            annotation=dict(
                text=f"Max Pain {max_pain:.0f}",
                font=dict(color=CYAN, size=11),
                yref="paper",
                y=0.05,
            ),
        )

    fig.update_layout(
        **_base_layout(
            title=dict(text=title, font=dict(size=16, color=WHITE)),
            barmode="overlay",
            xaxis_title="Strike Price",
            yaxis_title="Open Interest",
            yaxis=dict(
                gridcolor=GRID,
                zerolinecolor=WHITE,
                zerolinewidth=1,
                tickformat=",",
                color=WHITE,
            ),
            height=420,
        )
    )
    return fig


# ─── 2. PCR by Strike ────────────────────────────────────────────────────────

def pcr_by_strike_chart(walls_df: pd.DataFrame) -> go.Figure:
    df = walls_df.copy()
    colors = df["PCR_OI"].apply(
        lambda v: GREEN if v < 0.7 else (ORANGE if v < 1.3 else RED)
    )

    fig = go.Figure(go.Bar(
        x=df["Strike"],
        y=df["PCR_OI"],
        marker_color=colors,
        hovertemplate="<b>Strike %{x}</b><br>PCR OI: %{y:.3f}<extra></extra>",
    ))

    # Threshold lines
    for y, color, label in [(0.7, GREEN, "Bullish 0.7"), (1.0, WHITE, "Neutral 1.0"), (1.3, RED, "Bearish 1.3")]:
        fig.add_hline(y=y, line=dict(color=color, dash="dot", width=1.5),
                      annotation=dict(text=label, font=dict(color=color, size=10), x=1.01, xref="paper"))

    fig.update_layout(**_base_layout(
        title="PCR OI by Strike",
        xaxis_title="Strike",
        yaxis_title="Put/Call OI Ratio",
        height=300,
    ))
    return fig


# ─── 3. IV Smile ─────────────────────────────────────────────────────────────

def iv_smile_chart(walls_df: pd.DataFrame) -> go.Figure:
    df = walls_df.sort_values("Strike")
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=df["Strike"], y=df["Call_IV"],
        name="Call IV", line=dict(color=GREEN, width=2),
        mode="lines+markers",
        hovertemplate="<b>Strike %{x}</b><br>Call IV: %{y:.1f}%<extra></extra>",
    ))

    fig.add_trace(go.Scatter(
        x=df["Strike"], y=df["Put_IV"],
        name="Put IV", line=dict(color=RED, width=2),
        mode="lines+markers",
        fill="tonexty",
        fillcolor="rgba(255,82,82,0.08)",
        hovertemplate="<b>Strike %{x}</b><br>Put IV: %{y:.1f}%<extra></extra>",
    ))

    fig.update_layout(**_base_layout(
        title="IV Smile",
        xaxis_title="Strike",
        yaxis_title="Implied Volatility (%)",
        height=300,
    ))
    return fig


# ─── 4. Total OI Area Chart ──────────────────────────────────────────────────

def total_oi_area_chart(walls_df: pd.DataFrame) -> go.Figure:
    df = walls_df.sort_values("Strike")
    fig = go.Figure(go.Scatter(
        x=df["Strike"], y=df["Total_OI"],
        fill="tozeroy",
        fillcolor="rgba(0,230,118,0.12)",
        line=dict(color=GREEN, width=2),
        hovertemplate="<b>Strike %{x}</b><br>Total OI: %{y:,.0f}<extra></extra>",
    ))
    fig.update_layout(**_base_layout(
        title="Total OI by Strike",
        xaxis_title="Strike",
        yaxis_title="Total Open Interest",
        height=280,
    ))
    return fig


# ─── 5. Wall Strength % Stacked Bar ──────────────────────────────────────────

def wall_strength_chart(walls_df: pd.DataFrame) -> go.Figure:
    df = walls_df.sort_values("Strike")
    fig = go.Figure()

    fig.add_trace(go.Bar(
        x=df["Strike"], y=df["Call_Strength_%"],
        name="Call Strength %",
        marker_color=GREEN, opacity=0.85,
        hovertemplate="Strike %{x}<br>Call Strength: %{y:.2f}%<extra></extra>",
    ))
    fig.add_trace(go.Bar(
        x=df["Strike"], y=df["Put_Strength_%"],
        name="Put Strength %",
        marker_color=RED, opacity=0.85,
        hovertemplate="Strike %{x}<br>Put Strength: %{y:.2f}%<extra></extra>",
    ))

    fig.update_layout(**_base_layout(
        title="Wall Strength % Distribution",
        barmode="group",
        xaxis_title="Strike",
        yaxis_title="Strength (%)",
        height=280,
    ))
    return fig


# ─── 6. OI Wall + Deal Overlay ───────────────────────────────────────────────

def oi_deal_overlay_chart(
    walls_df: pd.DataFrame,
    call_walls: pd.DataFrame,
    put_walls: pd.DataFrame,
    matched_df: Optional[pd.DataFrame] = None,
    zones_df: Optional[pd.DataFrame] = None,
    cmp: Optional[float] = None,
    max_pain: Optional[float] = None,
) -> go.Figure:
    fig = oi_wall_chart(walls_df, call_walls, put_walls, cmp, max_pain, "OI Wall + Institutional Deal Overlay")

    if matched_df is not None and not matched_df.empty:
        buys = matched_df[matched_df["Buy/Sell"] == "BUY"].copy()
        sells = matched_df[matched_df["Buy/Sell"] == "SELL"].copy()

        max_qty = matched_df["Quantity Traded"].max() if not matched_df.empty else 1

        def size_arr(df):
            return (df["Quantity Traded"] / max_qty * 25 + 8).clip(upper=40)

        if not buys.empty:
            fig.add_trace(go.Scatter(
                x=buys["Trade Price/Wght. Avg. Price"],
                y=[0] * len(buys),
                mode="markers",
                marker=dict(
                    symbol="triangle-up",
                    size=size_arr(buys),
                    color=GREEN,
                    opacity=0.9,
                    line=dict(color=WHITE, width=0.5),
                ),
                name="BUY Deals",
                text=buys["Client Name"],
                hovertemplate=(
                    "<b>%{text}</b><br>"
                    "BUY @ %{x:.2f}<br>"
                    "Qty: %{customdata:,.0f}<extra></extra>"
                ),
                customdata=buys["Quantity Traded"],
            ))

        if not sells.empty:
            fig.add_trace(go.Scatter(
                x=sells["Trade Price/Wght. Avg. Price"],
                y=[0] * len(sells),
                mode="markers",
                marker=dict(
                    symbol="triangle-down",
                    size=size_arr(sells),
                    color=RED,
                    opacity=0.9,
                    line=dict(color=WHITE, width=0.5),
                ),
                name="SELL Deals",
                text=sells["Client Name"],
                hovertemplate=(
                    "<b>%{text}</b><br>"
                    "SELL @ %{x:.2f}<br>"
                    "Qty: %{customdata:,.0f}<extra></extra>"
                ),
                customdata=sells["Quantity Traded"],
            ))

    # Zone overlays
    if zones_df is not None and not zones_df.empty:
        for _, z in zones_df.iterrows():
            color = GOLD if z["Zone_Type"] == "ACCUMULATION" else ORANGE
            fig.add_vline(
                x=z["Strike"],
                line=dict(color=color, width=1.5, dash="dot"),
                annotation=dict(
                    text=z["Zone_Type"][:3],
                    font=dict(color=color, size=9),
                    yref="paper", y=0.5,
                ),
            )

    return fig


# ─── 7. Signal Score Scatter ─────────────────────────────────────────────────

def signal_score_scatter(matched_df: pd.DataFrame) -> go.Figure:
    if matched_df is None or matched_df.empty:
        return _empty_fig("No matched deals to display")

    df = matched_df.copy()
    df["color"] = df["Buy/Sell"].map({"BUY": GREEN, "SELL": RED})
    df["text"] = df.apply(
        lambda r: r["Client Name"][:15] + "…" if r["Score"] >= 60 else "", axis=1
    )

    max_qty = df["Quantity Traded"].max() if df["Quantity Traded"].max() > 0 else 1

    fig = go.Figure(go.Scatter(
        x=df["Trade Price/Wght. Avg. Price"],
        y=df["Score"],
        mode="markers+text",
        marker=dict(
            size=(df["Quantity Traded"] / max_qty * 30 + 8).clip(upper=50),
            color=df["color"],
            opacity=0.85,
            line=dict(color=WHITE, width=0.5),
        ),
        text=df["text"],
        textposition="top center",
        textfont=dict(color=WHITE, size=9),
        customdata=df[["Client Name", "Buy/Sell", "Quantity Traded", "Entity"]].values,
        hovertemplate=(
            "<b>%{customdata[0]}</b><br>"
            "%{customdata[1]} @ %{x:.2f}<br>"
            "Score: %{y}<br>"
            "Qty: %{customdata[2]:,.0f}<br>"
            "Entity: %{customdata[3]}<extra></extra>"
        ),
    ))

    fig.add_hline(y=60, line=dict(color=GOLD, dash="dot", width=1.5),
                  annotation=dict(text="High Conviction", font=dict(color=GOLD, size=10)))
    fig.add_hline(y=80, line=dict(color=RED, dash="dot", width=1.5),
                  annotation=dict(text="Very High", font=dict(color=RED, size=10)))

    fig.update_layout(**_base_layout(
        title="Signal Score — Deal Price vs Score",
        xaxis_title="Deal Price",
        yaxis_title="Signal Score (0–100)",
        yaxis=dict(range=[0, 105], gridcolor=GRID, color=WHITE),
        height=350,
    ))
    return fig


# ─── 8. Net Buy/Sell per Wall Level ──────────────────────────────────────────

def net_qty_bar_chart(aggregated_df: pd.DataFrame) -> go.Figure:
    if aggregated_df is None or aggregated_df.empty:
        return _empty_fig("No aggregated deal data")

    df = aggregated_df.sort_values("Net_Qty")
    colors = [GREEN if v >= 0 else RED for v in df["Net_Qty"]]
    qty_cr = df["Net_Qty"] / 1e7  # to crores

    fig = go.Figure(go.Bar(
        y=df["Strike"].astype(str),
        x=qty_cr,
        orientation="h",
        marker_color=colors,
        text=[f"₹{abs(v):.2f}Cr" for v in qty_cr],
        textposition="outside",
        textfont=dict(color=WHITE, size=10),
        hovertemplate="Strike %{y}<br>Net Qty: %{x:.2f} Cr<extra></extra>",
    ))

    fig.add_vline(x=0, line=dict(color=WHITE, width=1))
    fig.update_layout(**_base_layout(
        title="Net Institutional Buy/Sell per Wall Level (₹Cr)",
        xaxis_title="Net Qty (Cr)",
        yaxis_title="Strike",
        height=350,
    ))
    return fig


# ─── 9. Composite Signal Gauge ───────────────────────────────────────────────

def composite_gauge(score: float, label: str) -> go.Figure:
    color = GREEN if score > 30 else (RED if score < -30 else GOLD)
    normalized = (score + 100) / 2  # remap -100..+100 → 0..100

    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=normalized,
        delta={"reference": 50, "valueformat": ".1f"},
        number={"suffix": "", "font": {"size": 32, "color": WHITE}},
        title={"text": label, "font": {"size": 14, "color": WHITE}},
        gauge=dict(
            axis=dict(range=[0, 100], tickwidth=1, tickcolor=WHITE, tickfont=dict(color=WHITE)),
            bar=dict(color=color, thickness=0.3),
            bgcolor=CARD_BG,
            borderwidth=2,
            bordercolor=GRID,
            steps=[
                {"range": [0, 33], "color": "rgba(255,82,82,0.25)"},
                {"range": [33, 67], "color": "rgba(255,215,64,0.15)"},
                {"range": [67, 100], "color": "rgba(0,230,118,0.25)"},
            ],
            threshold=dict(
                line=dict(color=WHITE, width=3),
                thickness=0.8,
                value=normalized,
            ),
        ),
    ))

    fig.update_layout(
        paper_bgcolor=BG,
        font=dict(color=WHITE),
        margin=dict(l=20, r=20, t=60, b=20),
        height=260,
    )
    return fig


# ─── 10. OI Change Chart (Historical) ───────────────────────────────────────

def oi_change_chart(today_df: pd.DataFrame, yesterday_df: pd.DataFrame) -> go.Figure:
    merged = today_df[["Strike", "Total_OI"]].merge(
        yesterday_df[["Strike", "Total_OI"]].rename(columns={"Total_OI": "Prior_OI"}),
        on="Strike", how="inner"
    )
    merged["OI_Change"] = merged["Total_OI"] - merged["Prior_OI"]
    merged["OI_Change_pct"] = merged["OI_Change"] / merged["Prior_OI"].clip(lower=1) * 100
    colors = [GREEN if v >= 0 else RED for v in merged["OI_Change"]]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=merged["Strike"], y=merged["OI_Change"],
        marker_color=colors,
        hovertemplate="Strike %{x}<br>OI Change: %{y:,.0f}<extra></extra>",
        name="OI Change",
    ))
    fig.update_layout(**_base_layout(
        title="OI Change (Today vs Yesterday)",
        xaxis_title="Strike",
        yaxis_title="OI Delta",
        height=300,
    ))
    return fig


# ─── 11. PCR Trend Line ───────────────────────────────────────────────────────

def pcr_trend_chart(pcr_series: pd.Series, dates: list) -> go.Figure:
    fig = go.Figure(go.Scatter(
        x=dates, y=pcr_series,
        mode="lines+markers",
        line=dict(color=PURPLE, width=2),
        marker=dict(color=PURPLE, size=6),
        hovertemplate="%{x}<br>PCR: %{y:.3f}<extra></extra>",
    ))
    fig.add_hline(y=0.7, line=dict(color=GREEN, dash="dot"),
                  annotation=dict(text="0.7 Bullish", font=dict(color=GREEN, size=10)))
    fig.add_hline(y=1.3, line=dict(color=RED, dash="dot"),
                  annotation=dict(text="1.3 Bearish", font=dict(color=RED, size=10)))
    fig.update_layout(**_base_layout(
        title="PCR OI Trend",
        xaxis_title="Date",
        yaxis_title="PCR OI",
        height=280,
    ))
    return fig


# ─── 12. Max Pain Migration ──────────────────────────────────────────────────

def max_pain_migration_chart(max_pains: list, dates: list) -> go.Figure:
    fig = go.Figure(go.Scatter(
        x=dates, y=max_pains,
        mode="lines+markers",
        line=dict(color=CYAN, width=2),
        marker=dict(color=CYAN, size=7, symbol="diamond"),
        hovertemplate="%{x}<br>Max Pain: %{y:.0f}<extra></extra>",
    ))
    fig.update_layout(**_base_layout(
        title="Max Pain Migration",
        xaxis_title="Date",
        yaxis_title="Max Pain Strike",
        height=280,
    ))
    return fig


# ─── helper ──────────────────────────────────────────────────────────────────

def _empty_fig(msg: str) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(
        text=msg,
        xref="paper", yref="paper",
        x=0.5, y=0.5,
        showarrow=False,
        font=dict(color=MUTED, size=14),
    )
    fig.update_layout(**_base_layout(height=280))
    return fig
