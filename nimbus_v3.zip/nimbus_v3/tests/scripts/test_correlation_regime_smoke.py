"""Smoke test for run_correlation_regime_validation.py.

Tests the pipeline mechanics on synthetic data:
- Mean pairwise correlation series math is correct
- Regime classification (top/bottom quintile vs trailing window)
  produces sensible labels

Does NOT test the hypothesis itself.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from scripts.run_correlation_regime_validation import (    # noqa: E402
    _classify_regimes,
    _mean_pairwise_correlation_series,
    _MIN_INDUSTRIES,
)


def _synthetic_returns(
    n_industries: int, n_bars: int, common_factor_weight: float, seed: int,
) -> pd.DataFrame:
    """Build N industries' return series. common_factor_weight=1.0
    means everyone moves together (correlation ≈ 1.0); 0.0 means
    everyone is independent (correlation ≈ 0.0)."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2024-01-01", periods=n_bars)
    common = rng.normal(0, 0.01, n_bars)
    out = {}
    for i in range(n_industries):
        idiosyncratic = rng.normal(0, 0.01, n_bars)
        rets = common_factor_weight * common + (1 - common_factor_weight) * idiosyncratic
        out[f"IND{i}"] = pd.Series(rets, index=idx)
    return pd.DataFrame(out)


# ══════════════════════════════════════════════════════════════════════
# Mean pairwise correlation math
# ══════════════════════════════════════════════════════════════════════

class TestMeanPairwiseCorrelation:

    def test_high_common_factor_yields_high_correlation(self):
        """When all industries share a common factor, mean pairwise
        correlation should be near 1.0 in the rolling window."""
        rets = _synthetic_returns(
            n_industries=15, n_bars=200,
            common_factor_weight=0.95, seed=1,
        )
        corr = _mean_pairwise_correlation_series(rets, window=60)
        # Skip warmup
        last_value = corr.iloc[-1]
        assert not np.isnan(last_value)
        assert last_value > 0.7, (
            f"high-common-factor corr={last_value:.3f}, expected > 0.7"
        )

    def test_low_common_factor_yields_low_correlation(self):
        """Independent industries → mean pairwise correlation ≈ 0."""
        rets = _synthetic_returns(
            n_industries=15, n_bars=200,
            common_factor_weight=0.0, seed=2,
        )
        corr = _mean_pairwise_correlation_series(rets, window=60)
        last_value = corr.iloc[-1]
        assert not np.isnan(last_value)
        assert abs(last_value) < 0.3, (
            f"independent corr={last_value:.3f}, expected near 0"
        )

    def test_warmup_period_is_nan(self):
        """First (window - 1) bars have no rolling correlation yet."""
        rets = _synthetic_returns(
            n_industries=15, n_bars=200,
            common_factor_weight=0.5, seed=3,
        )
        corr = _mean_pairwise_correlation_series(rets, window=60)
        # First 59 bars (indices 0..58) should be NaN
        assert corr.iloc[:59].isna().all()
        # Bar 59 (the 60th bar) should be defined
        assert not np.isnan(corr.iloc[59])


# ══════════════════════════════════════════════════════════════════════
# Regime classification
# ══════════════════════════════════════════════════════════════════════

class TestClassifyRegimes:

    def test_high_value_in_top_quintile_is_high_corr(self):
        """A correlation series with a known spike — the spike bar
        should classify as HIGH_CORR once the trailing window has
        established a baseline."""
        # 300 bars: first 252 are baseline ~0.3, then a spike to 0.9
        idx = pd.bdate_range("2023-01-01", periods=300)
        values = np.full(300, 0.3)
        values[270:] = 0.9    # spike in last 30 bars
        corr = pd.Series(values, index=idx)
        regimes = _classify_regimes(
            corr, pctile_window=252,
            high_pctile=0.80, low_pctile=0.20,
        )
        # Last bar should be HIGH_CORR (spike well above the 80th
        # percentile of the trailing 252 bars which were all 0.3)
        assert regimes.iloc[-1] == "HIGH_CORR"

    def test_low_value_at_bottom_quintile_is_low_corr(self):
        idx = pd.bdate_range("2023-01-01", periods=300)
        values = np.full(300, 0.5)
        values[270:] = 0.1
        corr = pd.Series(values, index=idx)
        regimes = _classify_regimes(
            corr, pctile_window=252,
            high_pctile=0.80, low_pctile=0.20,
        )
        assert regimes.iloc[-1] == "LOW_CORR"

    def test_warmup_bars_are_na(self):
        """Bars before pctile_window=252 don't have enough history
        to rank against, so they should be pd.NA."""
        idx = pd.bdate_range("2023-01-01", periods=300)
        corr = pd.Series(np.linspace(0.1, 0.9, 300), index=idx)
        regimes = _classify_regimes(corr, pctile_window=252)
        # First 251 bars are NA (no full trailing window yet)
        for i in range(251):
            assert pd.isna(regimes.iloc[i]), (
                f"Bar {i} should be NA, got {regimes.iloc[i]}"
            )
