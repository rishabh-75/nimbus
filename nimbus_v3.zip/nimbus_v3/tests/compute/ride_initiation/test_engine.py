"""Tests for RideEngine — single-symbol phase classification,
industry consensus, universe aggregation."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.ride_initiation import (
    INDUSTRY_MIN_MEMBERS,
    RideEngine,
    RidePhase,
    RideResult,
)


# ══════════════════════════════════════════════════════════════════════
# Synthetic builders
# ══════════════════════════════════════════════════════════════════════


def _enrich(close: np.ndarray, idx: pd.DatetimeIndex,
            open_: np.ndarray | None = None,
            high: np.ndarray | None = None,
            low: np.ndarray | None = None,
            volume: np.ndarray | None = None) -> pd.DataFrame:
    """Build a fully-enriched OHLC dataframe from a close series."""
    n = len(close)
    df = pd.DataFrame(index=idx)
    df["Close"] = close
    df["Open"] = open_ if open_ is not None else close.copy()
    df["High"] = high if high is not None else close * 1.005
    df["Low"] = low if low is not None else close * 0.995
    df["Volume"] = volume if volume is not None else np.full(n, 1_000_000.0)
    sma = pd.Series(close, index=idx).rolling(20, min_periods=20).mean()
    std = pd.Series(close, index=idx).rolling(20, min_periods=20).std()
    df["sma_20"] = sma
    df["bb_20_1s_upper"] = sma + std
    df["bb_20_1s_lower"] = sma - std
    df["bbw_20_1s"] = (df["bb_20_1s_upper"] - df["bb_20_1s_lower"]) / df["sma_20"] * 100
    return df


def _make_init_scenario(n_base: int = 120, n_ramp: int = 30) -> pd.DataFrame:
    """Build a synthetic that satisfies all INITIATION criteria at bar n_base."""
    n = n_base + n_ramp
    idx = pd.bdate_range("2025-01-01", periods=n)

    sma = np.full(n, 100.0)
    upper = np.full(n, 100.30)
    lower = np.full(n, 99.70)
    bbw = np.full(n, 0.60)

    drift_start = n_base - 20
    for i in range(drift_start, n):
        sma[i] = 100.0 + (i - drift_start) * 0.04
        upper[i] = sma[i] + 0.30
        lower[i] = sma[i] - 0.30

    for i in range(n_base, n):
        bbw[i] = 0.60 + (i - n_base + 1) * 0.12

    close = sma.copy()
    open_ = sma.copy()

    t1 = n_base - 1
    open_[t1] = upper[t1] + 0.03
    close[t1] = upper[t1] + 0.15

    t0 = n_base
    open_[t0] = upper[t0] + 0.05
    close[t0] = upper[t0] + 0.25

    for i in range(n_base + 1, min(n_base + 3, n)):
        open_[i] = upper[i] + 0.04
        close[i] = upper[i] + 0.20

    high = np.where(close > open_, close + 0.05, open_ + 0.05)
    low = np.where(close > open_, open_ - 0.05, close - 0.05)

    volume = np.full(n, 1_000_000.0)
    volume[t1] = 2_200_000.0
    volume[t0] = 2_500_000.0

    return pd.DataFrame({
        "Open": open_, "High": high, "Low": low, "Close": close,
        "Volume": volume, "sma_20": sma,
        "bb_20_1s_upper": upper, "bb_20_1s_lower": lower, "bbw_20_1s": bbw,
    }, index=idx)


# ══════════════════════════════════════════════════════════════════════
# Result type contract
# ══════════════════════════════════════════════════════════════════════


class TestRideResultContract:

    def test_classify_returns_ride_result(self):
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        assert isinstance(res, RideResult)

    def test_phase_score_fire_aligned_to_index(self):
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        assert len(res.phase) == len(df)
        assert len(res.score) == len(df)
        assert len(res.fire) == len(df)
        assert (res.phase.index == df.index).all()

    def test_score_nan_where_no_fire(self):
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        # Wherever fire is False, score must be NaN
        assert res.score[~res.fire].isna().all()

    def test_score_finite_where_fire(self):
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        # Wherever fire is True, score must be finite
        assert np.isfinite(res.score[res.fire]).all()

    def test_fire_iff_phase_not_none(self):
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        # fire must equal (phase != NONE) bar-by-bar
        not_none = res.phase != RidePhase.NONE.value
        assert (res.fire == not_none).all()

    def test_empty_result_for_invalid_input(self):
        idx = pd.bdate_range("2025-01-01", periods=10)
        df = pd.DataFrame({"Close": np.full(10, 100.0)}, index=idx)
        res = RideEngine().classify(df)
        assert not res.fire.any()
        assert (res.phase == RidePhase.NONE.value).all()
        assert res.score.isna().all()


# ══════════════════════════════════════════════════════════════════════
# Phase classification
# ══════════════════════════════════════════════════════════════════════


class TestInitiationPhase:

    def test_clean_init_fires_init_phase(self):
        df = _make_init_scenario(n_base=120)
        res = RideEngine().classify(df)
        # Should fire INIT somewhere in 120..123
        window = res.phase.iloc[119:124]
        assert (window == RidePhase.INITIATION.value).any(), (
            f"INIT did not fire on clean init scenario. "
            f"Phases in window: {window.tolist()}"
        )

    def test_no_fire_during_consolidation(self):
        df = _make_init_scenario(n_base=120)
        res = RideEngine().classify(df)
        # Bars 0..118 are flat consolidation — no fire
        assert not res.fire.iloc[:119].any()


class TestPhasePriority:
    """When multiple detectors fire on the same bar, INIT > RETEST > CONT."""

    def test_priority_resolution_init_over_others(self):
        # If INIT fires on a bar, that bar's phase must be INIT
        # regardless of whether retest/cont also matched.
        df = _make_init_scenario(n_base=120)
        res = RideEngine().classify(df)
        if res.fire.iloc[120]:
            # Bar 120 fires — should be INIT (cleanest signal)
            assert res.phase.iloc[120] == RidePhase.INITIATION.value


# ══════════════════════════════════════════════════════════════════════
# Composite score
# ══════════════════════════════════════════════════════════════════════


class TestCompositeScore:

    def test_score_in_0_100_range(self):
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        valid = res.score.dropna()
        if len(valid) > 0:
            assert (valid >= 0).all()
            assert (valid <= 100).all()

    def test_score_higher_for_fresher_init(self):
        """A perfectly fresh init (only 1 prior body-above bar) should
        score higher than one with 2 prior body-above bars."""
        # This is structurally enforced by FRESHNESS = 100 - 25*prior_count
        # but since fresh_cross requires prior_count == 0, this is mostly
        # a sanity test that the formula doesn't break.
        df = _make_init_scenario()
        res = RideEngine().classify(df)
        # Just ensure scores exist and are sensible
        valid = res.score.dropna()
        if len(valid) > 0:
            assert valid.mean() > 0


# ══════════════════════════════════════════════════════════════════════
# Industry / universe aggregation
# ══════════════════════════════════════════════════════════════════════


class TestIndustryAggregation:
    """Industry classification via roll-up over per-constituent
    classifications. Returns a full RideResult, not a bool series.

    Group's phase = highest-priority phase appearing in any
    constituent on each bar. Group's score = ADTV-weighted mean of
    scores at that phase. Group's fire = True iff any constituent
    fires.
    """

    def test_thin_industry_returns_empty(self):
        """Single-member 'industry' has no aggregate to build —
        returns RideResult.empty when below INDUSTRY_MIN_MEMBERS."""
        idx = pd.bdate_range("2025-01-01", periods=200)
        members = {"SYM0": _enrich(np.full(200, 100.0), idx)}
        result = RideEngine().classify_industry(members)
        assert isinstance(result, RideResult)
        assert result.fire.empty

    def test_industry_returns_ride_result(self):
        """Three flat members produce no individual fires → group
        rolls up to all-NONE phase, no fires anywhere."""
        idx = pd.bdate_range("2025-01-01", periods=200)
        members = {
            f"SYM{i}": _enrich(np.full(200, 100.0 + i), idx)
            for i in range(3)
        }
        result = RideEngine().classify_industry(members)
        assert isinstance(result, RideResult)
        # Flat members → no fires individually → no fires in roll-up
        assert not result.fire.any()
        # Phase populated for every bar
        assert (result.phase == RidePhase.NONE.value).all()

    def test_industry_below_min_members(self):
        """Below INDUSTRY_MIN_MEMBERS the result is empty regardless of
        member quality."""
        idx = pd.bdate_range("2025-01-01", periods=200)
        members = {
            f"SYM{i}": _enrich(np.full(200, 100.0 + i), idx)
            for i in range(INDUSTRY_MIN_MEMBERS - 1)
        }
        result = RideEngine().classify_industry(members)
        assert result.fire.empty

    def test_group_fire_implies_constituent_fire(self):
        """Roll-up invariant: on any bar the group fires, at least
        one constituent fires. Regression for the 'Petroleum CONT
        but no constituent riding' bug — that was the old
        synthetic-OHLCV behaviour where the group could fire on
        the synthetic series independently of any member.
        """
        # Mix of flat and active members — only active ones can fire,
        # group should fire iff at least one active member fires.
        idx = pd.bdate_range("2025-01-01", periods=200)
        rng = np.random.default_rng(0)
        flat = np.full(200, 100.0)
        # Trending member that may produce some fires.
        trend = 100 + np.cumsum(rng.normal(0.1, 0.8, 200))
        members = {
            "FLAT_A": _enrich(flat, idx),
            "FLAT_B": _enrich(flat, idx),
            "TREND":  _enrich(trend, idx),
        }
        eng = RideEngine()
        per_member_fire = pd.DataFrame({
            sym: eng.classify(df).fire for sym, df in members.items()
        }).any(axis=1)
        group = eng.classify_industry(members)
        # Every bar where group fires, at least one member must fire.
        violations = (group.fire & ~per_member_fire).sum()
        assert violations == 0, (
            f"group fired on {violations} bars where no constituent fired"
        )

    def test_group_phase_matches_max_constituent_priority(self):
        """Group's resolved phase on each bar equals the highest-
        priority phase any constituent shows on that bar."""
        idx = pd.bdate_range("2025-01-01", periods=200)
        rng = np.random.default_rng(1)
        members = {
            f"SYM{i}": _enrich(
                100 + np.cumsum(rng.normal(0.1, 0.8, 200)), idx,
            )
            for i in range(4)
        }
        eng = RideEngine()
        per_phase = pd.DataFrame({
            s: eng.classify(df).phase for s, df in members.items()
        })
        group = eng.classify_industry(members)

        priority_map = {
            RidePhase.INITIATION.value:   3,
            RidePhase.RETEST.value:       2,
            RidePhase.CONTINUATION.value: 1,
            RidePhase.NONE.value:         0,
        }
        member_priority = per_phase.map(
            lambda p: priority_map.get(str(p), 0)
        )
        max_member_priority = member_priority.max(axis=1)
        group_priority = group.phase.map(
            lambda p: priority_map.get(str(p), 0)
        )
        # Roll-up invariant: group's priority == max constituent priority.
        diffs = (group_priority != max_member_priority).sum()
        assert diffs == 0


class TestUniverseAggregation:
    """Universe-level classification. Same roll-up approach as
    industry but without the min-members floor.
    """

    def test_universe_returns_ride_result(self):
        idx = pd.bdate_range("2025-01-01", periods=200)
        members = {
            f"SYM{i}": _enrich(np.full(200, 100.0 + i), idx)
            for i in range(10)
        }
        result = RideEngine().classify_universe(members)
        assert isinstance(result, RideResult)
        assert not result.fire.any()    # flat → no fires

    def test_universe_empty_panel(self):
        result = RideEngine().classify_universe({})
        assert isinstance(result, RideResult)
        assert result.fire.empty

    def test_universe_handles_single_member(self):
        """A single member is enough for the universe roll-up
        (no min-members floor — it's already an aggregate).
        Result equals that member's classification one-to-one."""
        idx = pd.bdate_range("2025-01-01", periods=200)
        members = {"SOLO": _enrich(np.full(200, 100.0), idx)}
        result = RideEngine().classify_universe(members)
        assert isinstance(result, RideResult)


# ══════════════════════════════════════════════════════════════════════
# RidePhase enum
# ══════════════════════════════════════════════════════════════════════


class TestRidePhase:

    def test_priority_ordering(self):
        assert RidePhase.NONE.priority < RidePhase.CONTINUATION.priority
        assert RidePhase.CONTINUATION.priority < RidePhase.RETEST.priority
        assert RidePhase.RETEST.priority < RidePhase.INITIATION.priority

    def test_enum_value_matches_display_label(self):
        assert RidePhase.NONE.value == "—"
        assert RidePhase.INITIATION.value == "INIT"
        assert RidePhase.RETEST.value == "RETEST"
        assert RidePhase.CONTINUATION.value == "CONT"

    def test_phase_string_equality(self):
        """Phase values stored in pd.Series compare equal both as enum
        members and as strings (str-enum semantics)."""
        assert RidePhase.INITIATION == "INIT"
        assert "INIT" == RidePhase.INITIATION


# ══════════════════════════════════════════════════════════════════════
# Backward compatibility
# ══════════════════════════════════════════════════════════════════════


class TestLegacyBoolApi:
    """The legacy `compute_ride_init_active` / `_industry` functions
    must keep working for callers that haven't migrated yet."""

    def test_compute_ride_init_active_returns_bool_series(self):
        from nimbus_v3.compute.ride_initiation import compute_ride_init_active
        df = _make_init_scenario()
        result = compute_ride_init_active(df)
        assert isinstance(result, pd.Series)
        assert result.dtype == bool

    def test_industry_legacy_returns_bool_series(self):
        from nimbus_v3.compute.ride_initiation import compute_ride_init_active_industry
        idx = pd.bdate_range("2025-01-01", periods=200)
        members = {f"SYM{i}": _enrich(np.full(200, 100.0 + i), idx) for i in range(5)}
        result = compute_ride_init_active_industry(members)
        assert isinstance(result, pd.Series)
        assert result.dtype == bool
