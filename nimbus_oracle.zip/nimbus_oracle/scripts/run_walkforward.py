#!/usr/bin/env python3
"""
run_walkforward.py — Walk-forward optimization + validation.

For each fold:
  1. TRAIN window: sweep key parameters, pick best by IS Sharpe
  2. TEST window: run best params OOS, record trades
  3. Advance 6 months, repeat

Output (data/backtest_results/):
  wf_oos_trades.csv   — all OOS trades with real symbols + entry/exit prices
  wf_chosen_params.csv — best params per fold
  wf_report.txt       — human-readable summary

Usage:
    python3 run_walkforward.py              # live NSE data (default)
    python3 run_walkforward.py --n 70       # top 70 symbols
    python3 run_walkforward.py --years 5    # 5yr history
    python3 run_walkforward.py --synthetic  # offline testing with fake data
"""
import argparse, datetime, itertools, logging, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()
import numpy as np, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("wf")

# ══════════════════════════════════════════════════════════════════════════════
# INDICATORS
# ══════════════════════════════════════════════════════════════════════════════

def compute_indicators(df):
    d = df.copy(); c=d["Close"]; h=d["High"]; l=d["Low"]
    v = d["Volume"] if "Volume" in d.columns else pd.Series(0, index=d.index)
    for p in [10, 20]: d[f"SMA_{p}"] = c.rolling(p).mean()
    for p in [14, 20, 30]:
        hh = h.rolling(p).max(); ll = l.rolling(p).min()
        d[f"WR_{p}"] = ((hh - c) / (hh - ll).replace(0, np.nan)) * -100
    tp = (h+l+c)/3; mf = tp*v
    pmf = pd.Series(np.where(tp>tp.shift(1), mf, 0), index=d.index)
    nmf = pd.Series(np.where(tp<tp.shift(1), mf, 0), index=d.index)
    mr = pmf.rolling(14).sum() / nmf.rolling(14).sum().replace(0, np.nan)
    d["MFI"] = 100 - (100 / (1 + mr))
    bb_ma = c.rolling(20).mean(); bb_sd = c.rolling(20).std()
    d["BBW"] = ((bb_ma + 2*bb_sd) - (bb_ma - 2*bb_sd)) / bb_ma.replace(0, np.nan) * 100
    d["BBW_slope"] = d["BBW"].diff(5)
    d["VOL_RATIO"] = v / v.rolling(20).mean().replace(0, np.nan)
    d["HIGH_50"] = h.rolling(50, min_periods=20).max()
    d["DD"] = ((c - d["HIGH_50"]) / d["HIGH_50"]) * 100
    red = (c < c.shift(1)).astype(int)
    d["RED_STREAK"] = red.groupby((red != red.shift()).cumsum()).cumsum()
    # ATR(14) — needed by the hybrid exit logic for trail-stop sizing.
    # Same formula as run_resolve.py and the live system.
    prev_close = c.shift(1)
    tr = pd.concat([
        h - l,
        (h - prev_close).abs(),
        (l - prev_close).abs(),
    ], axis=1).max(axis=1)
    d["ATR_14"] = tr.rolling(14).mean()
    return d

# ══════════════════════════════════════════════════════════════════════════════
# SIMULATION (parameterized)
# ══════════════════════════════════════════════════════════════════════════════

def simulate(df, start_idx, end_idx, params):
    """
    Run entry/exit simulation. Returns list of trade dicts with prices.

    Entry filter mirrors compute_dual_mode() in modules/dual_mode.py:
      Core: WR < wr_thresh AND close < SMA AND MFI >= mfi_min
      PRIMARY: core + DD <= dd_thresh + streak >= streak_min + vol >= vol_min_ratio
      SECONDARY: core only (and not PRIMARY)

    Exit logic mirrors check_exit() in modules/dual_mode.py exactly:
      Priority order (first match wins, applied on every bar):
        1. HARD_STOP    — non-negotiable hard_stop_pct floor
        2. BAR_RATCHET  — at bar `bar_ratchet` if still underwater (not in trail)
        3. PROFIT_TARGET → switches to trail mode (winner runner)
        4. TRAIL_STOP   — peak - min(trail_atr_mult*ATR, max_trail_pct% of entry)
        5. BBW_CONTRACT — bars >= 5 AND bbw_slope < 0 AND close > SMA
        6. MAX_HOLD     — final fallback

    Params dict keys (entry-side):
        wr_period, wr_thresh, sma_period, mfi_min, dd_thresh, streak_min
        vol_min_ratio (optional, defaults to dual_mode.VOL_MIN_RATIO)
        primary_only (optional bool, default False — drop SECONDARY entirely)

    Params dict keys (exit-side):
        profit_target, max_hold
        hard_stop_pct (optional, defaults to dual_mode.HARD_STOP_PCT)
        bar_ratchet (optional, defaults to dual_mode.BAR_RATCHET)
        trail_atr_mult (optional, defaults to dual_mode.TRAIL_ATR_MULT)
        max_trail_pct (optional, defaults to dual_mode.MAX_TRAIL_PCT)

    Optional keys fall back to live constants when absent, so existing
    sweep grids that only specify entry params still work unchanged.
    """
    from modules.dual_mode import (
        HARD_STOP_PCT as _LIVE_HARD_STOP_PCT,
        BAR_RATCHET as _LIVE_BAR_RATCHET,
        TRAIL_ATR_MULT as _LIVE_TRAIL_ATR_MULT,
        MAX_TRAIL_PCT as _LIVE_MAX_TRAIL_PCT,
        VOL_MIN_RATIO as _LIVE_VOL_MIN_RATIO,
    )

    # Resolve overridable params (fall back to live constants)
    hard_stop_pct = params.get("hard_stop_pct", _LIVE_HARD_STOP_PCT)
    bar_ratchet_bar = params.get("bar_ratchet", _LIVE_BAR_RATCHET)
    trail_atr_mult = params.get("trail_atr_mult", _LIVE_TRAIL_ATR_MULT)
    max_trail_pct = params.get("max_trail_pct", _LIVE_MAX_TRAIL_PCT)
    vol_min_ratio = params.get("vol_min_ratio", _LIVE_VOL_MIN_RATIO)
    primary_only = params.get("primary_only", False)

    n = len(df)
    if n < 60: return []
    wr_col = f"WR_{params['wr_period']}"; sma_col = f"SMA_{params['sma_period']}"
    if wr_col not in df.columns or sma_col not in df.columns: return []
    c = df["Close"].values; sma = df[sma_col].values; wr = df[wr_col].values
    mfi = df["MFI"].values; vol_r = df["VOL_RATIO"].values
    dd = df["DD"].values; streak = df["RED_STREAK"].values
    bbw_slope = df["BBW_slope"].values; dates = df.index
    atr = df["ATR_14"].values if "ATR_14" in df.columns else np.full(n, 0.0)

    wt = params["wr_thresh"]; mfi_min = params["mfi_min"]
    dd_thresh = params["dd_thresh"]; streak_min = params["streak_min"]
    pt = params["profit_target"]; max_hold = params["max_hold"]

    trades = []
    in_t = False; eb = 0; ep = 0.0; tier = ""
    # Hybrid exit state, reset on every new entry:
    in_trail_mode = False
    peak_price = 0.0
    atr_at_entry = 0.0

    for t in range(max(60, start_idx), min(end_idx, n)):
        if not in_t:
            # ── ENTRY LOGIC (mirrors compute_dual_mode) ────────────
            w = wr[t]; cl = c[t]; s = sma[t]; m = mfi[t]
            if np.isnan(w) or np.isnan(s) or s == 0 or np.isnan(m): continue
            if w >= wt or cl >= s or m < mfi_min: continue
            d_val = dd[t] if not np.isnan(dd[t]) else 0
            r_val = streak[t] if not np.isnan(streak[t]) else 0
            v_val = vol_r[t] if not np.isnan(vol_r[t]) else 1.0
            if d_val <= dd_thresh and r_val >= streak_min and v_val >= vol_min_ratio:
                tier = "PRIMARY"
            else:
                tier = "SECONDARY"
            # primary_only mode skips SECONDARY entries entirely
            if primary_only and tier == "SECONDARY":
                continue
            in_t = True; eb = t; ep = cl
            # Reset hybrid exit state for the new trade
            in_trail_mode = False
            peak_price = ep
            atr_at_entry = float(atr[t]) if not np.isnan(atr[t]) else 0.0
            continue

        # ── EXIT LOGIC (mirrors check_exit() exactly) ─────────────
        bars = t - eb; cl = c[t]
        if ep <= 0:
            in_t = False
            continue
        loss_pct = (cl / ep - 1) * 100
        ex = False; reason = ""

        # Rule 1: HARD STOP — non-negotiable, every bar
        if loss_pct <= hard_stop_pct:
            ex = True; reason = "HARD_STOP"

        # Rule 2: BAR RATCHET — only at the checkpoint, only if not trailing
        if not ex and not in_trail_mode and bars == bar_ratchet_bar and cl < ep:
            ex = True; reason = "BAR_RATCHET"

        # Rule 3: PROFIT TARGET — switches to trail mode (winner runner)
        if not ex and not in_trail_mode and loss_pct >= pt:
            in_trail_mode = True
            peak_price = cl
            # No exit yet — start trailing on next bar

        # Rule 4: TRAIL STOP — only when in trail mode
        if not ex and in_trail_mode:
            if cl > peak_price:
                peak_price = cl
            raw_trail = trail_atr_mult * atr_at_entry
            max_trail = ep * max_trail_pct / 100
            trail_width = min(raw_trail, max_trail) if atr_at_entry > 0 else max_trail
            trail_stop = peak_price - trail_width
            if cl <= trail_stop:
                ex = True; reason = "TRAIL_STOP"

        # Rule 5: BBW contraction — only if not in trail mode (matches resolver)
        if not ex and not in_trail_mode and bars >= 5:
            s_now = sma[t]
            slope_val = bbw_slope[t]
            if (not np.isnan(slope_val) and slope_val < 0
                    and not np.isnan(s_now) and cl > s_now):
                ex = True; reason = "BBW_CONTRACT"

        # Rule 6: MAX_HOLD fallback
        if not ex and bars >= max_hold:
            ex = True; reason = "MAX_HOLD"

        if ex:
            pnl = (cl / ep - 1) * 100
            entry_dt = dates[eb]; exit_dt = dates[t]
            trades.append({
                "entry_bar": eb, "bars_held": bars,
                "pnl_pct": round(pnl, 4), "tier": tier, "exit_reason": reason,
                "entry_date": str(entry_dt.date()) if hasattr(entry_dt, 'date') else str(entry_dt)[:10],
                "exit_date": str(exit_dt.date()) if hasattr(exit_dt, 'date') else str(exit_dt)[:10],
                "entry_price": round(float(ep), 2),
                "exit_price": round(float(cl), 2),
            })
            in_t = False
    return trades

def calc_stats(pnls):
    if len(pnls) < 3:
        return {"n": len(pnls), "avg": 0, "win": 0, "sharpe": 0, "pf": 0}
    arr = np.array(pnls); avg = float(np.mean(arr)); std = float(np.std(arr))
    w = arr[arr > 0]; lo = arr[arr <= 0]
    return {
        "n": len(arr), "avg": round(avg, 4),
        "win": round((arr > 0).mean() * 100, 1),
        "sharpe": round(avg / std * np.sqrt(252/10), 2) if std > 0 else 0,
        "pf": round(float(w.sum()) / abs(float(lo.sum())), 2) if len(lo) > 0 and lo.sum() != 0 else 99.0,
    }

# ══════════════════════════════════════════════════════════════════════════════
# PARAMETER GRID
# ══════════════════════════════════════════════════════════════════════════════

def build_param_grid(lock_live: bool = False, robust_sweep: bool = False):
    """
    Build the walkforward parameter grid.

    Modes (mutually exclusive — pass at most one True):

    lock_live=True:
        Returns a single config matching the live MR strategy constants
        from modules/dual_mode.py. Used to measure what the actual live
        parameter set produces.

    robust_sweep=True:
        Returns a focused grid for finding "fewer but higher quality"
        configurations. Holds entry-side core (WR/SMA/MFI/MAX_HOLD) and
        downside exits (HARD_STOP, BAR_RATCHET) at live values, sweeps
        only the levers that change selectivity and winner-runner room:

          primary_only:    [True, False]   — drop SECONDARY tier
          dd_thresh:       [-5, -8, -10]   — capitulation depth
          streak_min:      [2, 3, 4]       — red day count
          vol_min_ratio:   [0.5, 1.0, 1.5] — volume confirmation
          profit_target:   [5.0, 7.0, 10.0]— winner runner trigger
          trail_atr_mult:  [1.5, 2.5]      — trail width
          max_trail_pct:   [4.0, 6.0]      — trail cap

        Total: 2 * 3 * 3 * 3 * 3 * 2 * 2 = 648 configs.

    No flags (default):
        The original 8-axis sweep over WR/SMA/MFI/DD/streak/PT/MAX_HOLD.
        Used for general parameter discovery from scratch.
    """
    if lock_live:
        # Pull live constants from dual_mode.py — single source of truth.
        # If these change in dual_mode, this lock follows automatically.
        from modules.dual_mode import (
            WR_PERIOD, WR_THRESH, SMA_PERIOD, MFI_MIN,
            DD_MODERATE, RED_STREAK_MIN, VOL_MIN_RATIO, PROFIT_TARGET, MAX_HOLD,
            HARD_STOP_PCT, BAR_RATCHET, TRAIL_ATR_MULT, MAX_TRAIL_PCT,
            ENABLE_SECONDARY_TIER,
        )
        return [{
            "wr_period": WR_PERIOD,
            "wr_thresh": WR_THRESH,
            "sma_period": SMA_PERIOD,
            "mfi_min": MFI_MIN,
            "dd_thresh": DD_MODERATE,
            "streak_min": RED_STREAK_MIN,
            "vol_min_ratio": VOL_MIN_RATIO,
            "profit_target": PROFIT_TARGET,
            "max_hold": MAX_HOLD,
            "hard_stop_pct": HARD_STOP_PCT,
            "bar_ratchet": BAR_RATCHET,
            "trail_atr_mult": TRAIL_ATR_MULT,
            "max_trail_pct": MAX_TRAIL_PCT,
            # When ENABLE_SECONDARY_TIER is False (production default since
            # 2026-04-08), the live system only emits PRIMARY signals.
            # primary_only mirrors that behavior in the simulator so the
            # lock-live measurement actually matches what runs in production.
            "primary_only": not ENABLE_SECONDARY_TIER,
        }]

    if robust_sweep:
        # Focused search for "quality over quantity" — see docstring.
        # Entry core (WR/SMA/MFI) and downside exits (HARD_STOP/BAR_RATCHET)
        # are held at live values; only the selectivity and winner-runner
        # axes are swept.
        from modules.dual_mode import (
            WR_PERIOD, WR_THRESH, SMA_PERIOD, MFI_MIN, MAX_HOLD,
        )
        configs = []
        for primary_only in [True, False]:
            for dd_t in [-5.0, -8.0, -10.0]:
                for streak_m in [2, 3, 4]:
                    for vol_min in [0.5, 1.0, 1.5]:
                        for pt in [5.0, 7.0, 10.0]:
                            for trail_atr in [1.5, 2.5]:
                                for trail_cap in [4.0, 6.0]:
                                    configs.append({
                                        # Locked at live values
                                        "wr_period": WR_PERIOD,
                                        "wr_thresh": WR_THRESH,
                                        "sma_period": SMA_PERIOD,
                                        "mfi_min": MFI_MIN,
                                        "max_hold": MAX_HOLD,
                                        # Swept axes
                                        "primary_only": primary_only,
                                        "dd_thresh": dd_t,
                                        "streak_min": streak_m,
                                        "vol_min_ratio": vol_min,
                                        "profit_target": pt,
                                        "trail_atr_mult": trail_atr,
                                        "max_trail_pct": trail_cap,
                                    })
        return configs

    configs = []
    for wr_p in [14, 20, 30]:
        for wr_t in [-30, -40, -50]:
            for sma_p in [10, 20]:
                for mfi_min in [30, 40]:
                    for dd_t in [-5, -8]:
                        for streak_m in [2, 3]:
                            for pt in [3.0, 5.0]:
                                for mh in [25, 30]:
                                    configs.append({
                                        "wr_period": wr_p, "wr_thresh": wr_t,
                                        "sma_period": sma_p, "mfi_min": mfi_min,
                                        "dd_thresh": dd_t, "streak_min": streak_m,
                                        "profit_target": pt, "max_hold": mh,
                                    })
    return configs

def param_label(p):
    return (f"WR({p['wr_period']},{p['wr_thresh']}) SMA{p['sma_period']} "
            f"MFI>={p['mfi_min']} DD<={p['dd_thresh']} Str>={p['streak_min']} "
            f"PT{p['profit_target']}% MH{p['max_hold']}")

# ══════════════════════════════════════════════════════════════════════════════
# SYMBOL UNIVERSE
# ══════════════════════════════════════════════════════════════════════════════

# NIFTY 200 — covers large + mid cap. Bulk/block deals more common in mid-caps.
UNIVERSE_SYMBOLS = [
    # NIFTY 50
    "RELIANCE","HDFCBANK","TCS","INFY","ICICIBANK","SBIN","AXISBANK",
    "BAJFINANCE","TATAMOTORS","MARUTI","TATASTEEL","JSWSTEEL","HINDALCO",
    "WIPRO","TECHM","SUNPHARMA","CIPLA","LT","NTPC","BHARTIARTL",
    "ITC","HINDUNILVR","ASIANPAINT","DRREDDY","KOTAKBANK","BAJAJ-AUTO",
    "HEROMOTOCO","M&M","BPCL","COALINDIA","ONGC","POWERGRID","DIVISLAB",
    "TITAN","ULTRACEMCO","NESTLEIND","HCLTECH","APOLLOHOSP","ADANIENT",
    "ADANIPORTS","BRITANNIA","SBILIFE","HDFCLIFE","BAJAJFINSV","GRASIM",
    "INDUSINDBK","EICHERMOT","SHRIRAMFIN","TRENT","BEL",
    # NIFTY NEXT 50
    "CHOLAFIN","CANBK","BANKBARODA","PNB","IOC","IRCTC","HAL",
    "MOTHERSON","TATAPOWER","ABB","SIEMENS","GODREJCP","COLPAL","HAVELLS",
    "VOLTAS","MFSL","VBL","MUTHOOTFIN","IDFCFIRSTB","PIDILITIND",
    "NAUKRI","DMART","DABUR","BERGEPAINT","MARICO","TATACONSUM",
    "TORNTPHARM","LUPIN","AMBUJACEM","ACC","DLF","JINDALSTEL",
    "VEDL","GAIL","SAIL","RECLTD","PFC","NHPC","IRFC",
    "SBICARD","ICICIPRULI","ICICIGI","HDFCAMC","MCDOWELL-N",
    # NIFTY MIDCAP SELECT / 200 additions
    "TVSMOTOR","PAGEIND","PIIND","ASTRAL","BALKRISIND","COFORGE",
    "LTTS","PERSISTENT","MPHASIS","LALPATHLAB","METROPOLIS",
    "AUROPHARMA","BIOCON","ALKEM","IPCALAB","NATCOPHARMA",
    "FEDERALBNK","AUBANK","BANDHANBNK","MANAPPURAM",
    "OBEROIRLTY","GODREJPROP","PRESTIGE","PHOENIXLTD","BRIGADE",
    "CONCOR","POLYCAB","CUMMINSIND","THERMAX",
    "DEEPAKNTR","AARTI","CLEAN","JUBLFOOD","TATACOMM",
    "MRF","BOSCHLTD","SCHAEFFLER","SUPREMEIND","APLAPOLLO",
    "SUNDARMFIN","LICHSGFIN","CANFINHOME","ABCAPITAL",
    "MAXHEALTH","FORTIS","STARHEALTH",
    "CROMPTON","WHIRLPOOL","CENTURYTEX",
    "ZYDUSLIFE","GLENMARK","LAURUSLABS","GRANULES","AJANTPHARM",
    "TATACHEM","ATUL","NAVINFLUOR","SRF","FLUOROCHEM",
    "INDIANHOTELS","EIH","DEVYANI",
    "CGPOWER","BHEL","HUDCO","SJVN",
    "PETRONET","IGL","MGL","GSPL",
    "ABFRL","RAYMOND","RELAXO","BATA",
    "KPITTECH","ZENSAR","LTIM","TATAELXSI",
    "DALBHARAT","RAMCOCEM","JKCEMENT","BIRLASOFT","HINDPETRO",
    "ESCORTS","TIINDIA","CEATLTD","ENDURANCE","EXIDEIND",
    "ATGL","KALYANKJIL",
]

# ══════════════════════════════════════════════════════════════════════════════
# WALK-FORWARD ENGINE
# ══════════════════════════════════════════════════════════════════════════════

def _config_label(p):
    """Compact label for robust sweep — only the swept axes."""
    po = "PRI" if p.get("primary_only") else "ALL"
    return (f"{po} DD<={p['dd_thresh']:.0f} Str>={p['streak_min']} "
            f"Vol>={p['vol_min_ratio']:.1f} PT{p['profit_target']:.0f}% "
            f"Trail{p['trail_atr_mult']:.1f}x/{p['max_trail_pct']:.0f}%cap")


def _run_robust_sweep(universe, n_folds, TRAIN_BARS, TEST_BARS, t0):
    """
    Robust sweep: evaluate every config in build_param_grid(robust_sweep=True)
    against every fold's OOS window directly. No IS optimization. Rank
    configs by robustness across folds.

    Robustness criterion (lexicographic):
      1. Number of positive Sharpe folds  (higher is better)
      2. Min fold Sharpe                  (higher is better — worst-case)
      3. Aggregate Sharpe across all folds (higher is better)

    The first criterion catches consistency. The second catches worst-case
    behavior. The third is the tiebreaker on overall edge.
    """
    grid = build_param_grid(robust_sweep=True)
    logger.info("ROBUST SWEEP — %d configs x %d folds = %d evaluations",
                len(grid), n_folds, len(grid) * n_folds)
    logger.info("Locked at live values: WR(30,-30) SMA20 MFI>=30 MaxHold30")
    logger.info("Locked at live values: HARD_STOP=-5%% BAR_RATCHET=8")
    logger.info("Sweeping: primary_only, dd_thresh, streak_min, vol_min_ratio,")
    logger.info("          profit_target, trail_atr_mult, max_trail_pct")
    logger.info("")

    # Evaluate each config against every fold's OOS window directly.
    # No IS picking — every config sees every fold's OOS data.
    config_results = []
    for cfg_idx, params in enumerate(grid):
        if cfg_idx % 50 == 0:
            logger.info("Progress: %d/%d configs evaluated", cfg_idx, len(grid))

        per_fold_stats = []
        all_trades = []
        for fold in range(n_folds):
            train_start = fold * TEST_BARS
            train_end = train_start + TRAIN_BARS
            test_start = train_end
            test_end = test_start + TEST_BARS

            fold_trades = []
            for sym, df in universe.items():
                if len(df) < test_end:
                    continue
                trades = simulate(df, test_start, test_end, params)
                for t in trades:
                    t["fold"] = fold + 1
                fold_trades.extend(trades)

            fold_pnls = [t["pnl_pct"] for t in fold_trades]
            stats = calc_stats(fold_pnls)
            per_fold_stats.append(stats)
            all_trades.extend(fold_trades)

        # Aggregate stats across all folds
        agg_pnls = [t["pnl_pct"] for t in all_trades]
        agg_stats = calc_stats(agg_pnls)

        # Robustness metrics
        fold_sharpes = [s["sharpe"] for s in per_fold_stats]
        positive_folds = sum(1 for sh in fold_sharpes if sh > 0)
        min_fold_sharpe = min(fold_sharpes) if fold_sharpes else 0
        avg_fold_sharpe = float(np.mean(fold_sharpes)) if fold_sharpes else 0

        # Loser exit rate (HARD_STOP + BAR_RATCHET)
        n_total = len(all_trades)
        if n_total > 0:
            loser_exits = sum(
                1 for t in all_trades
                if t["exit_reason"] in ("HARD_STOP", "BAR_RATCHET")
            )
            loser_exit_pct = loser_exits / n_total * 100
        else:
            loser_exit_pct = 0

        config_results.append({
            "params": params,
            "n_total": agg_stats["n"],
            "agg_sharpe": agg_stats["sharpe"],
            "agg_win": agg_stats["win"],
            "agg_avg": agg_stats["avg"],
            "agg_pf": agg_stats["pf"],
            "positive_folds": positive_folds,
            "min_fold_sharpe": min_fold_sharpe,
            "avg_fold_sharpe": avg_fold_sharpe,
            "loser_exit_pct": loser_exit_pct,
            "fold_sharpes": fold_sharpes,
        })

    logger.info("Progress: %d/%d configs evaluated", len(grid), len(grid))

    # Rank by lexicographic criterion: (positive_folds, min_fold_sharpe, agg_sharpe)
    config_results.sort(
        key=lambda r: (r["positive_folds"], r["min_fold_sharpe"], r["agg_sharpe"]),
        reverse=True,
    )

    # ── Report ─────────────────────────────────────────────────────────────
    logger.info("\n" + "=" * 110)
    logger.info("ROBUST SWEEP RESULTS — top 25 configs by robustness")
    logger.info("=" * 110)
    logger.info("Ranking criterion (lexicographic):")
    logger.info("  1. positive folds (higher = more consistent)")
    logger.info("  2. min fold sharpe (higher = better worst case)")
    logger.info("  3. aggregate sharpe (tiebreaker)")
    logger.info("")
    logger.info("%-4s %-3s %-5s %-4s %-7s %-7s %-6s %-5s  %-7s  %s",
                 "Rank", "+/F", "MinSh", "AggSh", "Win%", "Avg%", "PF", "N",
                 "Loser%", "Config")
    logger.info("-" * 110)

    for rank, r in enumerate(config_results[:25], 1):
        logger.info("%-4d %d/%d %+5.2f %+5.2f %6.1f%% %+6.2f%% %5.2f %5d  %5.1f%%  %s",
                     rank,
                     r["positive_folds"], len(r["fold_sharpes"]),
                     r["min_fold_sharpe"],
                     r["agg_sharpe"],
                     r["agg_win"],
                     r["agg_avg"],
                     r["agg_pf"],
                     r["n_total"],
                     r["loser_exit_pct"],
                     _config_label(r["params"]))

    # ── Live baseline comparison ───────────────────────────────────────────
    # Find where the live params would rank, if they were in the grid
    from modules.dual_mode import (
        DD_MODERATE, RED_STREAK_MIN, VOL_MIN_RATIO, PROFIT_TARGET,
        TRAIL_ATR_MULT, MAX_TRAIL_PCT,
    )
    live_match = None
    for r in config_results:
        p = r["params"]
        if (p.get("primary_only") == False
                and p["dd_thresh"] == DD_MODERATE
                and p["streak_min"] == RED_STREAK_MIN
                and p["vol_min_ratio"] == VOL_MIN_RATIO
                and p["profit_target"] == PROFIT_TARGET
                and p["trail_atr_mult"] == TRAIL_ATR_MULT
                and p["max_trail_pct"] == MAX_TRAIL_PCT):
            live_match = r
            break

    if live_match:
        live_rank = config_results.index(live_match) + 1
        logger.info("")
        logger.info("LIVE BASELINE (current dual_mode.py params) ranks #%d/%d in this sweep:",
                     live_rank, len(config_results))
        logger.info("  %d/%d positive folds, MinSh=%+.2f, AggSh=%+.2f, Win=%.1f%%, "
                     "Avg=%+.2f%%, PF=%.2f, N=%d, Losers=%.1f%%",
                     live_match["positive_folds"], len(live_match["fold_sharpes"]),
                     live_match["min_fold_sharpe"], live_match["agg_sharpe"],
                     live_match["agg_win"], live_match["agg_avg"],
                     live_match["agg_pf"], live_match["n_total"],
                     live_match["loser_exit_pct"])
        logger.info("  %s", _config_label(live_match["params"]))

    # ── Save full results CSV ──────────────────────────────────────────────
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out = os.path.join(project_root, "data", "backtest_results")
    os.makedirs(out, exist_ok=True)

    rows = []
    for rank, r in enumerate(config_results, 1):
        row = {
            "rank": rank,
            "positive_folds": r["positive_folds"],
            "min_fold_sharpe": round(r["min_fold_sharpe"], 3),
            "agg_sharpe": round(r["agg_sharpe"], 3),
            "agg_win_pct": round(r["agg_win"], 1),
            "agg_avg_pct": round(r["agg_avg"], 3),
            "agg_pf": round(r["agg_pf"], 2),
            "n_trades": r["n_total"],
            "loser_exit_pct": round(r["loser_exit_pct"], 1),
            **r["params"],
        }
        for f_idx, sh in enumerate(r["fold_sharpes"]):
            row[f"fold{f_idx+1}_sharpe"] = round(sh, 3)
        rows.append(row)

    results_df = pd.DataFrame(rows)
    results_path = os.path.join(out, "wf_robust_sweep.csv")
    results_df.to_csv(results_path, index=False)

    logger.info("\nFull results: %s (%d configs)", results_path, len(rows))
    logger.info("Complete in %.1f min", (time.time() - t0) / 60)


def run(use_synthetic=False, n_symbols=200, years=5, lock_live_params=False,
        robust_sweep=False):
    t0 = time.time()
    logger.info("=" * 70)
    if robust_sweep:
        logger.info("WALK-FORWARD ROBUST SWEEP — finding fewer/higher-quality params")
    else:
        logger.info("WALK-FORWARD OPTIMIZATION + VALIDATION")
    logger.info("=" * 70)

    if use_synthetic:
        logger.info("Using SYNTHETIC data (offline mode)")
        from backtest.data_loader import generate_universe
        raw = generate_universe(n_symbols=n_symbols, n_bars=int(years * 252))
    else:
        logger.info("Downloading LIVE data for %d NSE symbols, %dyr...", n_symbols, years)
        from backtest.data_loader import download_batch
        symbols = UNIVERSE_SYMBOLS[:n_symbols]
        raw = download_batch(symbols, years=years)

    logger.info("Loaded %d symbols", len(raw))

    logger.info("Computing indicators...")
    universe = {}
    for sym, df in raw.items():
        if len(df) >= 100:
            universe[sym] = compute_indicators(df)
    logger.info("Ready: %d symbols, %d-%d bars",
                len(universe),
                min(len(v) for v in universe.values()),
                max(len(v) for v in universe.values()))

    TRAIN_BARS = 378; TEST_BARS = 126
    MIN_BARS_NEEDED = TRAIN_BARS + 2 * TEST_BARS

    short = [s for s, df in universe.items() if len(df) < MIN_BARS_NEEDED]
    if short:
        logger.info("Dropping %d symbols with < %d bars: %s",
                     len(short), MIN_BARS_NEEDED, ", ".join(short[:10]))
        for s in short: del universe[s]

    if len(universe) < 5:
        logger.error("Only %d symbols with enough data. Need at least 5.", len(universe))
        return

    max_bars = min(len(df) for df in universe.values())
    n_folds = (max_bars - TRAIN_BARS) // TEST_BARS
    if n_folds < 2:
        logger.error("Need %d bars, have %d", TRAIN_BARS + 2*TEST_BARS, max_bars)
        return
    logger.info("After filter: %d symbols, %d-%d bars, %d folds",
                len(universe), min(len(v) for v in universe.values()),
                max(len(v) for v in universe.values()), n_folds)

    # ── Robust sweep: separate code path ──────────────────────────────────
    if robust_sweep:
        return _run_robust_sweep(universe, n_folds, TRAIN_BARS, TEST_BARS, t0)

    param_grid = build_param_grid(lock_live=lock_live_params)
    if lock_live_params:
        logger.info("LIVE PARAMS LOCKED — single config per fold (no sweep)")
        logger.info("  Live config: %s", param_label(param_grid[0]))
    else:
        logger.info("Parameter grid: %d combinations per fold", len(param_grid))

    fold_results = []; all_oos_trades = []; chosen_params_log = []

    for fold in range(n_folds):
        train_start = fold * TEST_BARS
        train_end = train_start + TRAIN_BARS
        test_start = train_end; test_end = test_start + TEST_BARS

        first_df = next(iter(universe.values()))
        train_dates = f"{first_df.index[train_start].date()} -> {first_df.index[min(train_end-1, len(first_df)-1)].date()}"
        test_dates = f"{first_df.index[test_start].date()} -> {first_df.index[min(test_end-1, len(first_df)-1)].date()}"
        logger.info("\n-- Fold %d/%d -- Train: %s | Test: %s", fold+1, n_folds, train_dates, test_dates)

        best_sharpe = -999; best_params = None; best_is_stats = None
        for params in param_grid:
            all_pnls = []
            for sym, df in universe.items():
                if len(df) < test_end: continue
                trades = simulate(df, train_start, train_end, params)
                all_pnls.extend(t["pnl_pct"] for t in trades)
            if len(all_pnls) < 10: continue
            stats = calc_stats(all_pnls)
            if stats["sharpe"] > best_sharpe:
                best_sharpe = stats["sharpe"]
                best_params = params.copy()
                best_is_stats = calc_stats(all_pnls)

        if best_params is None:
            logger.warning("    No viable params found"); continue

        logger.info("    BEST IS: %s", param_label(best_params))
        logger.info("    IS: N=%d Sh=%.2f W=%.1f%% Avg=%+.3f%%",
                     best_is_stats["n"], best_is_stats["sharpe"], best_is_stats["win"], best_is_stats["avg"])

        oos_trades = []
        for sym, df in universe.items():
            if len(df) < test_end: continue
            trades = simulate(df, test_start, test_end, best_params)
            for t in trades: t["symbol"] = sym; t["fold"] = fold + 1
            oos_trades.extend(trades)

        oos_stats = calc_stats([t["pnl_pct"] for t in oos_trades])
        pri_stats = calc_stats([t["pnl_pct"] for t in oos_trades if t["tier"] == "PRIMARY"])
        sec_stats = calc_stats([t["pnl_pct"] for t in oos_trades if t["tier"] == "SECONDARY"])
        logger.info("    OOS: N=%d Sh=%.2f W=%.1f%% Avg=%+.3f%% (PRI=%d, SEC=%d)",
                     oos_stats["n"], oos_stats["sharpe"], oos_stats["win"], oos_stats["avg"],
                     pri_stats["n"], sec_stats["n"])

        fold_results.append({
            "fold": fold+1, "train_dates": train_dates, "test_dates": test_dates,
            "best_params": best_params, "is_stats": best_is_stats,
            "oos_all": oos_stats, "oos_primary": pri_stats, "oos_secondary": sec_stats,
        })
        chosen_params_log.append({"fold": fold+1, **best_params})
        all_oos_trades.extend(oos_trades)

    # ══════════════════════════════════════════════════════════════════════
    # RESULTS
    # ══════════════════════════════════════════════════════════════════════
    if not all_oos_trades:
        logger.error("No OOS trades generated. Check data quality."); return

    all_pnls = [t["pnl_pct"] for t in all_oos_trades]
    pri_pnls = [t["pnl_pct"] for t in all_oos_trades if t["tier"] == "PRIMARY"]
    sec_pnls = [t["pnl_pct"] for t in all_oos_trades if t["tier"] == "SECONDARY"]
    a = calc_stats(all_pnls); p = calc_stats(pri_pnls); s = calc_stats(sec_pnls)
    unique_syms = sorted(set(t["symbol"] for t in all_oos_trades))
    params_df = pd.DataFrame(chosen_params_log)

    logger.info("\n" + "=" * 90)
    logger.info("WALK-FORWARD RESULTS")
    logger.info("=" * 90)
    logger.info("  ALL:       N=%-5d Sh=%5.2f W=%5.1f%% Avg=%+.3f%% PF=%.2f", a["n"], a["sharpe"], a["win"], a["avg"], a["pf"])
    logger.info("  PRIMARY:   N=%-5d Sh=%5.2f W=%5.1f%% Avg=%+.3f%% PF=%.2f", p["n"], p["sharpe"], p["win"], p["avg"], p["pf"])
    logger.info("  SECONDARY: N=%-5d Sh=%5.2f W=%5.1f%% Avg=%+.3f%% PF=%.2f", s["n"], s["sharpe"], s["win"], s["avg"], s["pf"])
    logger.info("  Symbols: %d | Folds: %d", len(unique_syms), len(fold_results))

    # Per-fold
    logger.info("\n-- PER-FOLD --")
    for f in fold_results:
        o = f["oos_all"]; bp = f["best_params"]
        logger.info("  F%d %s | N=%d Sh=%.2f W=%.1f%% | %s",
                     f["fold"], f["test_dates"], o["n"], o["sharpe"], o["win"], param_label(bp))

    # Stability
    fold_sh = [f["oos_all"]["sharpe"] for f in fold_results]
    pos = sum(1 for x in fold_sh if x > 0)
    avg_is = np.mean([f["is_stats"]["sharpe"] for f in fold_results])
    wfe = np.mean(fold_sh) / avg_is * 100 if avg_is > 0 else 0
    logger.info("\n-- STABILITY --")
    logger.info("  Positive folds: %d/%d", pos, len(fold_sh))
    logger.info("  OOS Sharpe: %.2f - %.2f (median %.2f)", min(fold_sh), max(fold_sh), np.median(fold_sh))
    logger.info("  WF Efficiency: %.0f%%", wfe)

    # Param stability
    logger.info("\n-- PARAMETER STABILITY --")
    for col in params_df.columns:
        if col == "fold": continue
        vals = list(params_df[col].values)
        u = np.unique(vals)
        logger.info("  %-16s: %s %s", col, vals, "<- UNANIMOUS" if len(u)==1 else "")

    # Exit reasons
    logger.info("\n-- EXIT REASONS --")
    from collections import Counter
    for r, cnt in Counter(t["exit_reason"] for t in all_oos_trades).most_common():
        rs = calc_stats([t["pnl_pct"] for t in all_oos_trades if t["exit_reason"] == r])
        logger.info("  %-4s: N=%4d (%4.1f%%) W=%5.1f%% Avg=%+.3f%%",
                     r, cnt, cnt/len(all_oos_trades)*100, rs["win"], rs["avg"])

    # ── Save ──
    # Project root = parent of scripts/. The dirname-of-dirname pattern
    # avoids the bug where os.path.dirname(__file__) alone resolves to
    # scripts/ and produces scripts/data/backtest_results/ — wrong location.
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out = os.path.join(project_root, "data", "backtest_results")
    os.makedirs(out, exist_ok=True)

    trades_df = pd.DataFrame(all_oos_trades)
    col_order = ["symbol","entry_date","exit_date","entry_price","exit_price",
                 "pnl_pct","tier","exit_reason","bars_held","entry_bar","fold"]
    for c in col_order:
        if c not in trades_df.columns: trades_df[c] = ""
    trades_df[col_order].to_csv(os.path.join(out, "wf_oos_trades.csv"), index=False)
    params_df.to_csv(os.path.join(out, "wf_chosen_params.csv"), index=False)

    lines = [
        "WALK-FORWARD OPTIMIZATION REPORT",
        f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"Mode: {'SYNTHETIC' if use_synthetic else 'LIVE NSE'}",
        f"Universe: {len(universe)} symbols, {years}yr daily",
        f"Folds: {len(fold_results)} (train={TRAIN_BARS}d, test={TEST_BARS}d)",
        f"Param grid: {len(param_grid)} per fold",
        f"Symbols traded: {len(unique_syms)}", "",
        "AGGREGATE OOS:",
        f"  ALL:       N={a['n']} Sh={a['sharpe']} W={a['win']}% Avg={a['avg']:+.3f}% PF={a['pf']}",
        f"  PRIMARY:   N={p['n']} Sh={p['sharpe']} W={p['win']}% Avg={p['avg']:+.3f}% PF={p['pf']}",
        f"  SECONDARY: N={s['n']} Sh={s['sharpe']} W={s['win']}% Avg={s['avg']:+.3f}% PF={s['pf']}", "",
    ]
    for f in fold_results:
        o = f["oos_all"]; bp = f["best_params"]
        lines.append(f"Fold {f['fold']}: {f['test_dates']} OOS N={o['n']} Sh={o['sharpe']} W={o['win']}% Avg={o['avg']:+.3f}%")
        lines.append(f"  Best: {param_label(bp)}")
        lines.append(f"  IS: N={f['is_stats']['n']} Sh={f['is_stats']['sharpe']} W={f['is_stats']['win']}%")
        lines.append("")
    lines.append("STABILITY:")
    lines.append(f"  Positive folds: {pos}/{len(fold_sh)}")
    lines.append(f"  Sharpe: {min(fold_sh):.2f} - {max(fold_sh):.2f} (median {np.median(fold_sh):.2f})")
    lines.append(f"  WF Efficiency: {wfe:.0f}%")
    lines.append("\nPARAMETER STABILITY:")
    for col in params_df.columns:
        if col == "fold": continue
        lines.append(f"  {col}: {list(params_df[col].values)}")

    with open(os.path.join(out, "wf_report.txt"), "w") as f:
        f.write("\n".join(lines))

    logger.info("\nSaved to %s", out)
    logger.info("  wf_oos_trades.csv: %d trades, %d symbols", len(all_oos_trades), len(unique_syms))
    logger.info("Complete in %.1f min", (time.time()-t0)/60)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Walk-forward optimization for NIMBUS")
    ap.add_argument("--synthetic", action="store_true", help="Use synthetic data (offline)")
    ap.add_argument("--n", type=int, default=200, help="Number of symbols (default: 200)")
    ap.add_argument("--years", type=int, default=5, help="Years of history (default: 5)")
    ap.add_argument(
        "--lock-live-params", action="store_true",
        help="Skip parameter sweep; use the live MR constants from "
             "modules/dual_mode.py for every fold. Produces a clean "
             "measurement of what the live system actually does, used to "
             "set EXPECTED baselines in modules/signal_tracker.py."
    )
    ap.add_argument(
        "--robust-sweep", action="store_true",
        help="Run a focused sweep over selectivity and winner-runner axes "
             "to find configs that are more consistent across folds. Holds "
             "WR/SMA/MFI/HARD_STOP/BAR_RATCHET at live values; sweeps "
             "primary_only, dd_thresh, streak_min, vol_min_ratio, "
             "profit_target, trail_atr_mult, max_trail_pct. Ranks results "
             "by (positive folds, min fold sharpe, aggregate sharpe). "
             "Outputs data/backtest_results/wf_robust_sweep.csv with all "
             "648 configs ranked. Use this to find 'fewer but higher quality' "
             "parameter sets."
    )
    a = ap.parse_args()
    if a.lock_live_params and a.robust_sweep:
        print("ERROR: --lock-live-params and --robust-sweep are mutually exclusive")
        sys.exit(1)
    run(use_synthetic=a.synthetic, n_symbols=a.n, years=a.years,
        lock_live_params=a.lock_live_params, robust_sweep=a.robust_sweep)
