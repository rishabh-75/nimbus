#!/usr/bin/env python3
"""
scripts/run_dow_backtest.py — Day-of-week effect on mean reversion trades.

Tests whether entry day affects trade outcomes. Hypothesis: Friday entries
carry weekend gap risk (geopolitical events, global market moves) that
Mon-Thu entries don't face.

Usage:
    python3 scripts/run_dow_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("dow_bt")


def calc_stats(pnls):
    if len(pnls) < 5:
        return {"n": len(pnls), "avg": 0, "win": 0, "sharpe": 0}
    arr = np.array(pnls)
    avg = float(np.mean(arr)); std = float(np.std(arr))
    return {
        "n": len(arr), "avg": round(avg, 3),
        "win": round((arr > 0).mean() * 100, 1),
        "sharpe": round(avg / std * np.sqrt(252 / 10), 2) if std > 0 else 0,
        "median": round(float(np.median(arr)), 3),
        "worst": round(float(arr.min()), 2),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="dow_backtest_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        alt = "/mnt/user-data/uploads/wf_oos_trades.csv"
        if os.path.exists(alt): args.trades = alt

    df = pd.read_csv(args.trades)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    df["dow"] = df["entry_date"].dt.dayofweek  # 0=Mon, 4=Fri
    df["dow_name"] = df["entry_date"].dt.day_name()

    report = []
    report.append("=" * 70)
    report.append("DAY-OF-WEEK BACKTEST REPORT")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)} | Symbols: {df['symbol'].nunique()}")
    report.append("=" * 70)

    # ── TEST 1: Performance by day ──
    report.append("\n" + "=" * 70)
    report.append("TEST 1: PERFORMANCE BY ENTRY DAY")
    report.append("=" * 70)

    for day in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]:
        subset = df[df["dow_name"] == day]
        s = calc_stats(subset["pnl_pct"].values)
        pt_pct = (subset["exit_reason"] == "PT").mean() * 100 if len(subset) > 0 else 0
        max_pct = (subset["exit_reason"] == "MAX").mean() * 100 if len(subset) > 0 else 0
        report.append(f"  {day:10s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}  "
                      f"PT={pt_pct:.0f}%  MAX={max_pct:.0f}%  worst={s.get('worst',0):.1f}%")

    # ── TEST 2: Friday vs Mon-Thu ──
    report.append("\n" + "=" * 70)
    report.append("TEST 2: FRIDAY vs MON-THU (t-test)")
    report.append("=" * 70)

    fri = df[df["dow"] == 4]["pnl_pct"].values
    monthu = df[df["dow"] < 4]["pnl_pct"].values

    s_fri = calc_stats(fri)
    s_mt = calc_stats(monthu)
    report.append(f"\n  Friday:   N={s_fri['n']}  avg={s_fri['avg']:+.3f}%  win={s_fri['win']:.1f}%  Sh={s_fri['sharpe']:.2f}")
    report.append(f"  Mon-Thu:  N={s_mt['n']}  avg={s_mt['avg']:+.3f}%  win={s_mt['win']:.1f}%  Sh={s_mt['sharpe']:.2f}")

    try:
        from scipy import stats
        t, p = stats.ttest_ind(monthu, fri, equal_var=False)
        sig = "✓ SIGNIFICANT" if p < 0.05 else "○ not significant"
        report.append(f"  t={t:.3f}  p={p:.4f}  {sig}")
    except ImportError:
        report.append("  (scipy not installed)")

    # ── TEST 3: Friday × VIX interaction ──
    report.append("\n" + "=" * 70)
    report.append("TEST 3: FRIDAY × VIX REGIME")
    report.append("=" * 70)

    try:
        import yfinance as yf
        start = df["entry_date"].min() - pd.Timedelta(days=30)
        end = df["entry_date"].max() + pd.Timedelta(days=5)
        vix = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                          end=end.strftime("%Y-%m-%d"), progress=False)
        if isinstance(vix.columns, pd.MultiIndex):
            vix.columns = vix.columns.get_level_values(0)
        vix.index = pd.to_datetime(vix.index)
        if hasattr(vix.index, "tz") and vix.index.tz is not None:
            vix.index = vix.index.tz_localize(None)
        vix_series = vix["Close"]

        vix_vals = []
        for _, row in df.iterrows():
            dt = row["entry_date"]
            mask = vix_series.index <= dt
            vix_vals.append(float(vix_series[mask].iloc[-1]) if mask.any() else np.nan)
        df["vix"] = vix_vals

        valid = df.dropna(subset=["vix"])
        for vix_label, lo, hi in [("Low VIX (<13)", 0, 13), ("Normal (13-18)", 13, 18), ("Elevated (≥18)", 18, 999)]:
            vix_mask = (valid["vix"] >= lo) & (valid["vix"] < hi)
            for day_label, dow_mask in [("Mon-Thu", valid["dow"] < 4), ("Friday", valid["dow"] == 4)]:
                subset = valid[vix_mask & dow_mask]
                if len(subset) < 15:
                    report.append(f"  {vix_label:18s} × {day_label:7s}: N={len(subset):4d}  (insufficient)")
                    continue
                s = calc_stats(subset["pnl_pct"].values)
                report.append(f"  {vix_label:18s} × {day_label:7s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                              f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}")
    except Exception as e:
        report.append(f"  VIX data unavailable: {e}")

    # ── TEST 4: Friday × tier ──
    report.append("\n" + "=" * 70)
    report.append("TEST 4: FRIDAY × TIER")
    report.append("=" * 70)

    for tier in ["PRIMARY", "SECONDARY"]:
        for day_label, dow_mask in [("Mon-Thu", df["dow"] < 4), ("Friday", df["dow"] == 4)]:
            subset = df[(df["tier"] == tier) & dow_mask]
            if len(subset) < 20:
                continue
            s = calc_stats(subset["pnl_pct"].values)
            report.append(f"  {tier:10s} × {day_label:7s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                          f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}")

    # ── TEST 5: Worst drawdowns by day ──
    report.append("\n" + "=" * 70)
    report.append("TEST 5: TAIL RISK — WORST 1% TRADES BY DAY")
    report.append("=" * 70)

    for day in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]:
        subset = df[df["dow_name"] == day]
        if len(subset) < 20:
            continue
        worst_1pct = np.percentile(subset["pnl_pct"].values, 1)
        worst_5pct = np.percentile(subset["pnl_pct"].values, 5)
        report.append(f"  {day:10s}: 1st pctl={worst_1pct:+.1f}%  5th pctl={worst_5pct:+.1f}%")

    # ── TEST 6: Filter simulation ──
    report.append("\n" + "=" * 70)
    report.append("TEST 6: FILTER SIMULATION — SKIP FRIDAY ENTRIES")
    report.append("=" * 70)

    baseline = calc_stats(df["pnl_pct"].values)
    no_fri = df[df["dow"] < 4]
    s_nofri = calc_stats(no_fri["pnl_pct"].values)
    report.append(f"\n  Baseline (all days): N={baseline['n']}  avg={baseline['avg']:+.3f}%  "
                  f"win={baseline['win']:.1f}%  Sh={baseline['sharpe']:.2f}")
    report.append(f"  Skip Friday:        N={s_nofri['n']} ({len(no_fri)/len(df)*100:.0f}%)  avg={s_nofri['avg']:+.3f}%  "
                  f"win={s_nofri['win']:.1f}%  Sh={s_nofri['sharpe']:.2f}  "
                  f"ΔSh={s_nofri['sharpe'] - baseline['sharpe']:+.2f}")

    # Also test: skip Friday + Normal VIX
    if "vix" in df.columns:
        valid = df.dropna(subset=["vix"])
        no_fri_norm = valid[~((valid["dow"] == 4) & (valid["vix"] >= 13) & (valid["vix"] < 18))]
        s_combo = calc_stats(no_fri_norm["pnl_pct"].values)
        report.append(f"  Skip Fri+NormVIX:   N={s_combo['n']} ({len(no_fri_norm)/len(valid)*100:.0f}%)  avg={s_combo['avg']:+.3f}%  "
                      f"win={s_combo['win']:.1f}%  Sh={s_combo['sharpe']:.2f}  "
                      f"ΔSh={s_combo['sharpe'] - baseline['sharpe']:+.2f}")

    # Decision
    report.append("\n" + "=" * 70)
    report.append("DECISION FRAMEWORK")
    report.append("=" * 70)
    report.append("""
  IF Friday win rate is significantly lower (p < 0.05):
    → Add day-of-week as a feature in ML model
    → Consider: Friday + Normal VIX → reduce sizing
    → Consider: Friday + SECONDARY → SKIP (compound with VIX gate)

  IF Friday tail risk is worse (deeper 1st/5th percentile):
    → Weekend gap risk is real → flag in verdict
    → "⚠ Friday entry — weekend gap risk"

  IF not significant:
    → Display as context only (like ETF VIX)

  IMPLEMENTATION OPTIONS:
    A. Verdict warning only: "⚠ Friday entry — weekend gap risk"
    B. Sizing reduction: Friday → SIZE down one tier
    C. ML feature: add dow to conviction model features
    D. Combined: Friday + Normal VIX + SECONDARY → SKIP
""")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
