"""nimbus_v3.compute.industry_rollup — member-aggregate industry metrics.

Stateless functions that roll a set of per-symbol ride results up to
an industry-level summary: how many members are riding, and a single
recalibrated industry score that blends *breadth* (how many ride),
*liquidity* (ADTV weighting) and *conviction* (each rider's own ride
score).

This is deliberately separate from ``RideEngine.classify_industry``,
which builds a synthetic peer index and scores *that*. The synthetic
index still drives the industry **Phase**; this module drives the
recalibrated industry **Score** and the **Riding** count. Keeping the
arithmetic here (not in the table widget) preserves the rule that the
UI renders, never computes.

Score formula (operator-chosen "option 2" — breadth-scaled
ADTV-weighted mean of riders' scores):

    riders          = members whose latest phase != NONE
    weighted_mean   = Σ(score_i · adtv_i) / Σ(adtv_i)      over riders
    breadth         = len(riders) / len(members_with_data)
    industry_score  = breadth · weighted_mean

So an industry ranks high only when a large *fraction* of its members
ride (breadth), those riders carry real ₹-liquidity (ADTV weight), and
they score well individually (score_i). A lone liquid rider in an
otherwise-quiet industry is discounted by the breadth term; a swarm of
tiny illiquid riders is discounted by the ADTV weighting.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.compute.ride_initiation import RideResult
from nimbus_v3.compute.ride_initiation.types import RidePhase

#: Minimum bars of Close×Volume needed to trust a member's ADTV.
_ADTV_MIN_BARS: int = 5
#: ADTV lookback (bars) — matches the engine/score definition.
_ADTV_WINDOW: int = 20


@dataclass(frozen=True)
class IndustryRollup:
    """Member-aggregate summary for one industry.

    Attributes:
        riding: count of members whose latest ride phase != NONE.
        members: count of members that had usable data in the panel.
        adtv_total: summed 20-bar mean Close×Volume across members (₹).
        score: recalibrated industry score (breadth-scaled ADTV-weighted
            mean of riders' individual scores), or NaN when nothing
            rides / no usable data.
    """

    riding: int
    members: int
    adtv_total: float
    score: float


def _member_adtv(df: pd.DataFrame) -> float:
    """20-bar mean Close×Volume for one member, or NaN if unusable."""
    if df is None or df.empty or "Volume" not in df.columns:
        return float("nan")
    sub = df[["Close", "Volume"]].tail(_ADTV_WINDOW)
    if len(sub) < _ADTV_MIN_BARS:
        return float("nan")
    v = float((sub["Close"] * sub["Volume"]).mean())
    return v if (v == v and v > 0) else float("nan")


def aggregate_industry(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    symbol_results: dict[str, RideResult],
) -> IndustryRollup | None:
    """Roll up one industry's members into an :class:`IndustryRollup`.

    Args:
        members: symbols belonging to the industry.
        panel: ``{symbol: enriched_df}`` (for ADTV).
        symbol_results: ``{symbol: RideResult}`` — the per-symbol ride
            cache (single source of truth for phase + score).

    Returns:
        An :class:`IndustryRollup`, or ``None`` if no member had usable
        panel data (so the caller can skip the row entirely).
    """
    present = [s for s in members if s in panel and panel[s] is not None
               and not panel[s].empty]
    if not present:
        return None

    adtv_total = 0.0
    riders = 0
    weighted_score_sum = 0.0
    rider_adtv_sum = 0.0

    for sym in present:
        adtv = _member_adtv(panel[sym])
        if adtv == adtv:    # not NaN
            adtv_total += adtv

        res = symbol_results.get(sym)
        if res is None or res.latest_phase is RidePhase.NONE:
            continue
        riders += 1
        sc = res.latest_score
        if sc == sc and adtv == adtv:    # both valid → weight by ADTV
            weighted_score_sum += sc * adtv
            rider_adtv_sum += adtv

    members_n = len(present)
    if riders == 0 or rider_adtv_sum <= 0:
        score = float("nan")
    else:
        weighted_mean = weighted_score_sum / rider_adtv_sum
        breadth = riders / members_n
        score = breadth * weighted_mean

    return IndustryRollup(
        riding=riders,
        members=members_n,
        adtv_total=adtv_total if adtv_total > 0 else float("nan"),
        score=score,
    )
