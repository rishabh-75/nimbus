"""Tests for nimbus_v3.tracking — schema, tracker, stats."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.conviction.formula import Contribution
from nimbus_v3.conviction.grade_engine import Conviction
from nimbus_v3.core.types import (
    GradeLetter, SetupType, Sizing, Verdict,
)
from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.tracking.schema import SCHEMA_VERSION, connect, schema_version
from nimbus_v3.tracking.stats import (
    rolling_lift_by_strategy, regime_conditioned_lift,
)
from nimbus_v3.tracking.tracker import (
    SignalTracker, TrackedSignal, _compute_forward_returns, _extract_close_price,
)


_ASOF = pd.Timestamp("2024-05-15")


# ══════════════════════════════════════════════════════════════════════════════
# Fixture helpers
# ══════════════════════════════════════════════════════════════════════════════

class _FakeStrategy:
    def __init__(self, name="MeanReversion", priority=50, production_weight=1.0):
        self.name = name
        self.setup_type = SetupType.MEAN_REVERSION
        self.priority = priority
        self.production_weight = production_weight

    def accepts(self, _meta): return True
    def evaluate(self, **_kw): return None


def _make_conviction(
    *,
    score=3.5, grade=GradeLetter.A, verdict=Verdict.TAKE, sizing=Sizing.FULL,
    strategy_name="MeanReversion", production_weight=1.0, override_reason=None,
    asof=_ASOF,
) -> Conviction:
    contribs = (
        Contribution("mfi", 0.5, "neutral"),
        Contribution("volume", 0.3, "ok"),
    )
    return Conviction(
        symbol="X", asof_date=asof, strategy_name=strategy_name,
        setup_type=SetupType.MEAN_REVERSION,
        raw_score=score, score=score * production_weight,
        grade=grade, verdict=verdict, sizing=sizing,
        contributions=contribs,
        production_weight=production_weight,
        override_reason=override_reason,
    )


def _make_scan_result(
    *, symbol="X", asof=_ASOF, close_price=100.0, strategy=None, conviction=None,
) -> ScanResult:
    return ScanResult(
        symbol=symbol,
        asof_date=asof,
        strategy=strategy or _FakeStrategy(),
        conviction=conviction or _make_conviction(asof=asof),
        close_price=close_price,
    )


@pytest.fixture
def tracker_db(tmp_path: Path) -> SignalTracker:
    """Fresh tracker per test, cleaned up by tmp_path."""
    tracker = SignalTracker(tmp_path / "signals.db")
    yield tracker
    tracker.close()


# ══════════════════════════════════════════════════════════════════════════════
# Schema
# ══════════════════════════════════════════════════════════════════════════════

def test_schema_created_on_first_connect(tmp_path: Path) -> None:
    db = tmp_path / "new.db"
    conn = connect(db)
    assert schema_version(conn) == SCHEMA_VERSION
    # Table exists.
    tables = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='signals'"
    ).fetchall()
    assert len(tables) == 1
    conn.close()


def test_schema_idempotent_on_reconnect(tmp_path: Path) -> None:
    db = tmp_path / "reopen.db"
    conn1 = connect(db)
    conn1.execute("INSERT INTO schema_version (version) VALUES (?)", (99,))
    conn1.commit()
    conn1.close()
    # Reopening should not corrupt.
    conn2 = connect(db)
    rows = conn2.execute(
        "SELECT version FROM schema_version ORDER BY version"
    ).fetchall()
    conn2.close()
    assert len(rows) >= 1


def test_schema_creates_parent_dir(tmp_path: Path) -> None:
    db = tmp_path / "nested" / "dirs" / "signals.db"
    conn = connect(db)
    assert db.exists()
    conn.close()


# ══════════════════════════════════════════════════════════════════════════════
# Record path
# ══════════════════════════════════════════════════════════════════════════════

def test_record_inserts_new_signal(tracker_db: SignalTracker) -> None:
    result = _make_scan_result()
    inserted = tracker_db.record(result)
    assert inserted is True
    assert tracker_db.count() == 1


def test_record_returns_false_on_duplicate(tracker_db: SignalTracker) -> None:
    result = _make_scan_result()
    assert tracker_db.record(result) is True
    assert tracker_db.record(result) is False
    assert tracker_db.count() == 1


def test_record_many_atomic(tracker_db: SignalTracker) -> None:
    results = [
        _make_scan_result(symbol=f"S{i}", close_price=100.0 + i)
        for i in range(5)
    ]
    n = tracker_db.record_many(results)
    assert n == 5
    assert tracker_db.count() == 5


def test_record_preserves_contributions_as_json(
    tracker_db: SignalTracker,
) -> None:
    result = _make_scan_result()
    tracker_db.record(result)
    rows = tracker_db.query()
    assert len(rows) == 1
    # Raw SQL check — contributions_json isn't on TrackedSignal but is stored.
    raw = tracker_db._conn.execute(
        "SELECT contributions_json FROM signals LIMIT 1"
    ).fetchone()
    parsed = json.loads(raw["contributions_json"])
    assert isinstance(parsed, list)
    assert parsed[0]["name"] == "mfi"


def test_record_preserves_production_weight(
    tracker_db: SignalTracker,
) -> None:
    prod = _make_scan_result(
        strategy=_FakeStrategy(name="MeanReversion", production_weight=1.0),
        conviction=_make_conviction(production_weight=1.0),
    )
    research = _make_scan_result(
        symbol="Y",
        strategy=_FakeStrategy(name="DrawdownReversal", production_weight=0.0),
        conviction=_make_conviction(
            strategy_name="DrawdownReversal", production_weight=0.0,
            score=0.0, grade=GradeLetter.D, verdict=Verdict.WATCH,
            sizing=Sizing.SKIP, override_reason="research-only",
        ),
    )
    tracker_db.record(prod)
    tracker_db.record(research)
    prod_rows = tracker_db.query(production_only=True)
    assert len(prod_rows) == 1
    assert prod_rows[0].strategy_name == "MeanReversion"


# ══════════════════════════════════════════════════════════════════════════════
# Close-price extraction
# ══════════════════════════════════════════════════════════════════════════════

def test_extract_close_price_from_scan_result() -> None:
    result = _make_scan_result(close_price=123.45)
    assert _extract_close_price(result) == 123.45


def test_extract_close_price_nan_when_missing() -> None:
    # Simulate a legacy ScanResult without close_price by wrapping an object.
    class _LegacyResult:
        symbol = "X"
        conviction = _make_conviction()
    assert np.isnan(_extract_close_price(_LegacyResult()))


# ══════════════════════════════════════════════════════════════════════════════
# Backfill path
# ══════════════════════════════════════════════════════════════════════════════

def _price_panel_with_returns(symbol: str, asof: pd.Timestamp) -> dict:
    """Build a panel where the symbol's series extends 30 bars past asof,
    with a deterministic +1% per bar drift so forward returns are known."""
    idx = pd.bdate_range(asof - pd.Timedelta(days=10), periods=50)
    # asof should be in the middle.
    closes = 100.0 * np.exp(np.arange(len(idx)) * 0.01)  # +1% per bar in logs
    df = pd.DataFrame(
        {"Open": closes, "High": closes, "Low": closes,
         "Close": closes, "Volume": 1e6},
        index=idx,
    )
    return {symbol: df}


def test_backfill_fills_forward_returns(tracker_db: SignalTracker) -> None:
    asof = pd.Timestamp("2024-05-15")
    panel = _price_panel_with_returns("RELIANCE", asof)
    # Record at the asof close.
    signal_close = float(panel["RELIANCE"].loc[
        panel["RELIANCE"].index <= asof
    ]["Close"].iloc[-1])
    result = _make_scan_result(symbol="RELIANCE", asof=asof,
                                 close_price=signal_close)
    tracker_db.record(result)
    assert tracker_db.count_unfilled() == 1

    updated = tracker_db.backfill_returns(price_panel=panel)
    assert updated == 1
    assert tracker_db.count_unfilled() == 0

    rows = tracker_db.query()
    r = rows[0]
    assert r.fwd_ret_10d is not None
    # The planted drift is +1% log per bar → 10d log return ≈ +0.10.
    assert r.fwd_ret_10d == pytest.approx(0.10, abs=1e-6)


def test_backfill_skips_rows_with_insufficient_forward_history(
    tracker_db: SignalTracker,
) -> None:
    asof = pd.Timestamp("2024-05-15")
    # Panel ends only 5 bars after asof — not enough for horizon 20.
    idx = pd.bdate_range(asof - pd.Timedelta(days=10), asof + pd.Timedelta(days=7))
    closes = np.linspace(100.0, 110.0, len(idx))
    panel = {"X": pd.DataFrame(
        {"Open": closes, "High": closes, "Low": closes,
         "Close": closes, "Volume": 1e6}, index=idx,
    )}
    result = _make_scan_result(symbol="X", asof=asof, close_price=100.0)
    tracker_db.record(result)

    updated = tracker_db.backfill_returns(price_panel=panel)
    assert updated == 0
    assert tracker_db.count_unfilled() == 1   # still unfilled


def test_backfill_skips_nan_close_price(tracker_db: SignalTracker) -> None:
    """Scanner-legacy signals with NaN close must not crash backfill."""
    asof = pd.Timestamp("2024-05-15")
    panel = _price_panel_with_returns("X", asof)
    result = _make_scan_result(symbol="X", asof=asof, close_price=float("nan"))
    tracker_db.record(result)
    updated = tracker_db.backfill_returns(price_panel=panel)
    assert updated == 0
    assert tracker_db.count_unfilled() == 1


def test_backfill_skips_symbol_missing_from_panel(
    tracker_db: SignalTracker,
) -> None:
    asof = pd.Timestamp("2024-05-15")
    panel = _price_panel_with_returns("A", asof)
    # Record signal for a symbol NOT in the panel.
    result = _make_scan_result(symbol="B", asof=asof, close_price=100.0)
    tracker_db.record(result)
    updated = tracker_db.backfill_returns(price_panel=panel)
    assert updated == 0


def test_backfill_idempotent_on_second_call(
    tracker_db: SignalTracker,
) -> None:
    """Calling backfill twice after success should not re-update."""
    asof = pd.Timestamp("2024-05-15")
    panel = _price_panel_with_returns("RELIANCE", asof)
    signal_close = float(panel["RELIANCE"].loc[
        panel["RELIANCE"].index <= asof
    ]["Close"].iloc[-1])
    tracker_db.record(_make_scan_result(
        symbol="RELIANCE", asof=asof, close_price=signal_close,
    ))
    first = tracker_db.backfill_returns(price_panel=panel)
    second = tracker_db.backfill_returns(price_panel=panel)
    assert first == 1
    assert second == 0


# ══════════════════════════════════════════════════════════════════════════════
# _compute_forward_returns (unit tests — fine grained)
# ══════════════════════════════════════════════════════════════════════════════

def test_compute_forward_returns_basic() -> None:
    idx = pd.bdate_range("2024-05-01", periods=40)
    closes = 100.0 * np.exp(np.arange(len(idx)) * 0.01)
    df = pd.DataFrame(
        {"Close": closes, "Open": closes, "High": closes, "Low": closes,
         "Volume": 1e6},
        index=idx,
    )
    panel = {"X": df}
    asof = idx[10]
    signal_close = float(closes[10])
    returns = _compute_forward_returns(
        symbol="X", asof_date=asof, close_at_signal=signal_close,
        price_panel=panel, horizons=(1, 5, 10, 20),
    )
    assert returns is not None
    assert returns[10] == pytest.approx(0.10, abs=1e-6)
    assert returns[1] == pytest.approx(0.01, abs=1e-6)


def test_compute_forward_returns_none_when_nan() -> None:
    idx = pd.bdate_range("2024-05-01", periods=40)
    df = pd.DataFrame({"Close": np.ones(40) * 100.0}, index=idx)
    result = _compute_forward_returns(
        symbol="X", asof_date=idx[5], close_at_signal=float("nan"),
        price_panel={"X": df}, horizons=(10,),
    )
    assert result is None


# ══════════════════════════════════════════════════════════════════════════════
# Query path
# ══════════════════════════════════════════════════════════════════════════════

def test_query_filters_by_strategy(tracker_db: SignalTracker) -> None:
    tracker_db.record(_make_scan_result(
        strategy=_FakeStrategy(name="MeanReversion"),
        conviction=_make_conviction(strategy_name="MeanReversion"),
    ))
    tracker_db.record(_make_scan_result(
        symbol="Y",
        strategy=_FakeStrategy(name="Breakout", production_weight=0.0),
        conviction=_make_conviction(
            strategy_name="Breakout", production_weight=0.0,
        ),
    ))
    mr_rows = tracker_db.query(strategy_name="MeanReversion")
    assert len(mr_rows) == 1
    assert mr_rows[0].strategy_name == "MeanReversion"


def test_query_filters_by_date_range(tracker_db: SignalTracker) -> None:
    for i, date_str in enumerate([
        "2024-05-01", "2024-05-15", "2024-06-01", "2024-06-15",
    ]):
        tracker_db.record(_make_scan_result(
            symbol=f"S{i}", asof=pd.Timestamp(date_str),
        ))
    rows = tracker_db.query(
        asof_from=pd.Timestamp("2024-05-10"),
        asof_to=pd.Timestamp("2024-06-05"),
    )
    assert len(rows) == 2
    assert {r.symbol for r in rows} == {"S1", "S2"}


def test_query_production_only(tracker_db: SignalTracker) -> None:
    tracker_db.record(_make_scan_result(
        strategy=_FakeStrategy(production_weight=1.0),
        conviction=_make_conviction(production_weight=1.0),
    ))
    tracker_db.record(_make_scan_result(
        symbol="Y",
        strategy=_FakeStrategy(name="DR", production_weight=0.0),
        conviction=_make_conviction(
            strategy_name="DR", production_weight=0.0,
        ),
    ))
    rows = tracker_db.query(production_only=True)
    assert len(rows) == 1


def test_query_filled_only(tracker_db: SignalTracker) -> None:
    asof = pd.Timestamp("2024-05-15")
    panel = _price_panel_with_returns("FILLED", asof)
    tracker_db.record(_make_scan_result(
        symbol="FILLED", asof=asof, close_price=100.0,
    ))
    tracker_db.record(_make_scan_result(
        symbol="UNFILLED", asof=asof, close_price=100.0,
    ))
    # Backfill only the symbol that's in the panel.
    tracker_db.backfill_returns(price_panel=panel)
    rows = tracker_db.query(filled_only=True)
    assert len(rows) == 1
    assert rows[0].symbol == "FILLED"


def test_query_returns_typed_dataclass(tracker_db: SignalTracker) -> None:
    tracker_db.record(_make_scan_result())
    rows = tracker_db.query()
    assert isinstance(rows[0], TrackedSignal)
    assert isinstance(rows[0].asof_date, pd.Timestamp)


# ══════════════════════════════════════════════════════════════════════════════
# Context manager
# ══════════════════════════════════════════════════════════════════════════════

def test_tracker_is_context_manager(tmp_path: Path) -> None:
    db = tmp_path / "cm.db"
    with SignalTracker(db) as tracker:
        tracker.record(_make_scan_result())
        assert tracker.count() == 1
    # Reopen after close.
    with SignalTracker(db) as tracker2:
        assert tracker2.count() == 1


# ══════════════════════════════════════════════════════════════════════════════
# Stats
# ══════════════════════════════════════════════════════════════════════════════

def test_rolling_lift_empty_tracker(tracker_db: SignalTracker) -> None:
    rows = rolling_lift_by_strategy(tracker_db)
    assert rows == []


def test_rolling_lift_computes_per_strategy(
    tracker_db: SignalTracker,
) -> None:
    asof = pd.Timestamp("2024-05-15")
    panel_mr = _price_panel_with_returns("MR_A", asof)
    panel_bo = _price_panel_with_returns("BO_A", asof)
    # Capture actual asof closes — panel has +1% log-drift.
    mr_close = float(
        panel_mr["MR_A"].loc[panel_mr["MR_A"].index <= asof]["Close"].iloc[-1]
    )
    bo_close = float(
        panel_bo["BO_A"].loc[panel_bo["BO_A"].index <= asof]["Close"].iloc[-1]
    )
    # One MR signal at correct close.
    tracker_db.record(_make_scan_result(
        symbol="MR_A", asof=asof, close_price=mr_close,
    ))
    # One BO signal at correct close.
    tracker_db.record(_make_scan_result(
        symbol="BO_A", asof=asof, close_price=bo_close,
        strategy=_FakeStrategy(name="Breakout", production_weight=0.0),
        conviction=_make_conviction(
            strategy_name="Breakout", production_weight=0.0,
        ),
    ))
    tracker_db.backfill_returns(price_panel={**panel_mr, **panel_bo})
    rows = rolling_lift_by_strategy(tracker_db)
    assert {r.strategy_name for r in rows} == {"MeanReversion", "Breakout"}
    mr_row = next(r for r in rows if r.strategy_name == "MeanReversion")
    assert mr_row.n_filled == 1
    # +1% log-drift per bar × 10 bars → 10d log return ≈ +0.10.
    assert mr_row.mean_fwd_ret_10d == pytest.approx(0.10, abs=1e-6)


def test_rolling_lift_production_only_filter(
    tracker_db: SignalTracker,
) -> None:
    """Research-tier strategies excluded when production_only=True."""
    tracker_db.record(_make_scan_result(
        strategy=_FakeStrategy(name="MR", production_weight=1.0),
        conviction=_make_conviction(strategy_name="MR", production_weight=1.0),
    ))
    tracker_db.record(_make_scan_result(
        symbol="Y",
        strategy=_FakeStrategy(name="DR", production_weight=0.0),
        conviction=_make_conviction(
            strategy_name="DR", production_weight=0.0,
        ),
    ))
    rows = rolling_lift_by_strategy(tracker_db, production_only=True)
    assert len(rows) == 1
    assert rows[0].strategy_name == "MR"


def test_regime_conditioned_by_grade(tracker_db: SignalTracker) -> None:
    asof = pd.Timestamp("2024-05-15")
    panel = _price_panel_with_returns("X", asof)
    panel_y = _price_panel_with_returns("Y", asof)
    # A-grade MR signal.
    tracker_db.record(_make_scan_result(
        symbol="X", asof=asof, close_price=100.0,
        conviction=_make_conviction(
            grade=GradeLetter.A, score=3.5, verdict=Verdict.TAKE,
            sizing=Sizing.FULL, asof=asof,
        ),
    ))
    # B-grade MR signal, same symbol prefix but different.
    tracker_db.record(_make_scan_result(
        symbol="Y", asof=asof, close_price=100.0,
        conviction=_make_conviction(
            grade=GradeLetter.B, score=2.0, verdict=Verdict.TAKE,
            sizing=Sizing.HALF, asof=asof,
        ),
    ))
    tracker_db.backfill_returns(price_panel={**panel, **panel_y})
    rows = regime_conditioned_lift(
        tracker_db, strategy_name="MeanReversion", bucket_field="grade",
    )
    # Both grades appear (sorted alpha: A then B).
    assert [r.bucket for r in rows] == ["A", "B"]
    assert all(r.n_filled == 1 for r in rows)
