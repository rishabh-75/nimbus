"""
modules/bb_ride.py — BB Upper Band Ride Momentum Engine.

Single source of truth for BB ride momentum signals — same architecture
as ConvictionEngine / nse_client:
  - BBRideEngine class: stateless, compute once, read everywhere
  - Module-level singleton + convenience function
  - No UI, no data fetching, no side effects

Usage (identical pattern to compute_conviction):
    from modules.bb_ride import compute_ride
    result = compute_ride(price_df, symbol="TATASTEEL",
                          vix_regime="ELEVATED", sector_ctx=sector_dict)
    # result.grade, result.verdict, result.sizing, etc.

Backtest validation (2,919 trades, 50 stocks, 7yr):
    Trail 3xATR:            Sh 0.88, Win 48.0%, Avg +1.76%, PF 1.63
    SILVER filter (CYC+EL): Sh 1.45, Win 48.1%, Avg +2.96%, N=291
"""

from __future__ import annotations
import logging, math
import numpy as np, pandas as pd
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


# ── Ride exit constants — single source of truth ──────────────────────────
# These mirror the MR exit principles in dual_mode.py but with Ride-specific
# values: wider trail (3x vs 1.5x ATR), higher PT (10% vs 5%), no BAR_RATCHET
# (Ride is momentum continuation — chop tolerance is the play).
#
# The -5% HARD_STOP applies to Ride too because that principle is non-negotiable
# across all strategies, not just MR.
#
# Imported by run_resolve.py for the Ride resolver. If you change a value here,
# the resolver picks it up automatically. Don't redefine these anywhere else.
RIDE_HARD_STOP_PCT = -5.0       # max acceptable loss per trade (matches MR principle)
RIDE_PROFIT_TARGET = 10.0       # higher PT than MR (Ride is momentum)
RIDE_TRAIL_ATR_MULT = 3.0       # wider trail than MR (rides through chop)
RIDE_MAX_TRAIL_PCT = 8.0        # cap trail at 8% of entry
RIDE_MAX_HOLD = 30              # match MR's max-hold cap


@dataclass
class BBRideSignal:
    """Raw BB ride signal — internal to engine."""
    symbol: str = ""
    close: float = 0.0
    bb_upper: float = 0.0
    bb_mid: float = 0.0
    bb_lower: float = 0.0
    bb_pct: float = 0.5
    bbw: float = 0.0
    bbw_slope: float = 0.0
    sma_50: float = 0.0
    above_sma50: bool = False
    pct_from_sma50: float = 0.0
    vol_ratio: float = 0.0
    rsi: float = 50.0
    mfi: float = 50.0
    adx: float = 20.0
    atr: float = 0.0
    roc_10: float = 0.0
    was_below_upper: bool = False
    at_upper: bool = False
    entry_triggered: bool = False
    entry_reason: str = ""
    data_sufficient: bool = False


@dataclass
class BBRideResult:
    """Complete BB ride output — signal + grade + verdict + targets.
    This is what UI components receive. Single source of truth."""
    # Signal data (copied for UI convenience)
    symbol: str = ""
    close: float = 0.0
    bb_upper: float = 0.0
    bb_mid: float = 0.0
    bb_pct: float = 0.5
    bbw: float = 0.0
    bbw_slope: float = 0.0
    vol_ratio: float = 0.0
    rsi: float = 50.0
    mfi: float = 50.0
    adx: float = 20.0
    atr: float = 0.0
    roc_10: float = 0.0
    pct_from_sma50: float = 0.0
    above_sma50: bool = False
    entry_triggered: bool = False
    entry_reason: str = ""
    data_sufficient: bool = False
    # Grade
    grade: str = "—"
    grade_pts: int = 0
    verdict: str = ""
    sizing: str = "SKIP"
    # Context
    vix_regime: str = "UNKNOWN"
    sector_type: str = "UNKNOWN"
    rs_bucket: str = "INLINE"
    quality_rank: float = 0.0
    # Targets — defaults reference the module constants above so they
    # cannot drift from the resolver values.
    trailing_atr_mult: float = RIDE_TRAIL_ATR_MULT
    profit_target: float = RIDE_PROFIT_TARGET
    trail_stop: float = 0.0
    trail_pct: float = 0.0
    pt_price: float = 0.0


class BBRideEngine:
    """Stateless BB ride calculator — single source of truth.
    Same pattern as ConvictionEngine: compute once, read everywhere."""

    BB_PERIOD = 20
    BB_STD = 1.0
    MIN_BARS = 60

    _VIX_GRADE_PTS = {"PANIC": 3, "ELEVATED": 3, "LOW": 2, "NORMAL": 0, "UNKNOWN": 1}
    # Grade thresholds: S is awarded only via _check_s_tier(), not by points alone
    _GRADE_MAP = [(6, "A+"), (5, "A"), (4, "B+"), (3, "B"), (2, "C+"), (1, "C")]
    _GRADE_SIZING = {"S": "FULL", "A+": "FULL", "A": "FULL", "B+": "HALF", "B": "HALF",
                     "C+": "SKIP", "C": "SKIP", "D": "SKIP", "—": "SKIP"}
    _GRADE_ORD = {"S": 0, "A+": 1, "A": 2, "B+": 3, "B": 4, "C+": 5, "C": 6, "D": 7, "—": 8}
    _SECTOR_TYPE = {
        "Private Bank": "CYCLICAL", "PSU Bank": "CYCLICAL", "Fin Service": "CYCLICAL",
        "Nifty Bank": "CYCLICAL", "Auto": "CYCLICAL", "Metal": "CYCLICAL",
        "Realty": "CYCLICAL", "Infra": "CYCLICAL", "Energy": "CYCLICAL",
        "Oil & Gas": "CYCLICAL", "CPSE": "CYCLICAL", "PSE": "CYCLICAL",
        "Defence": "CYCLICAL", "Media": "CYCLICAL", "Consumption": "CYCLICAL",
        "IT": "DEFENSIVE", "Pharma": "DEFENSIVE", "Healthcare": "DEFENSIVE",
        "FMCG": "DEFENSIVE",
    }

    def compute(self, price_df: pd.DataFrame, symbol: str = "",
                vix_regime: str = "UNKNOWN", sector_ctx: Optional[dict] = None) -> BBRideResult:
        """Compute everything: signal + grade + verdict + targets. THE single entry point."""
        r = BBRideResult(symbol=symbol, vix_regime=vix_regime)
        sig = self._extract_signal(price_df, symbol)
        if not sig.data_sufficient:
            return r
        # Copy signal → result
        for f in ("close", "bb_upper", "bb_mid", "bb_pct", "bbw", "bbw_slope",
                  "vol_ratio", "rsi", "mfi", "adx", "atr", "roc_10",
                  "pct_from_sma50", "above_sma50", "entry_triggered", "entry_reason"):
            setattr(r, f, getattr(sig, f))
        r.data_sufficient = True
        # Sector context
        if sector_ctx:
            r.sector_type = self.get_sector_type(sector_ctx.get("sector", ""))
            r.rs_bucket = self.get_rs_bucket(sector_ctx.get("adj_score", 0))
        # Targets
        r.trail_stop = sig.close - r.trailing_atr_mult * sig.atr if sig.atr > 0 else 0
        r.trail_pct = (sig.close - r.trail_stop) / sig.close * 100 if sig.close > 0 else 0
        r.pt_price = sig.close * (1 + r.profit_target / 100)
        # Grade (entries only)
        if not sig.entry_triggered:
            r.verdict = self._build_non_entry_verdict(sig)
            return r
        r.grade_pts = self._compute_grade_pts(sig, r)
        r.grade = "D"
        for threshold, grade in self._GRADE_MAP:
            if r.grade_pts >= threshold:
                r.grade = grade
                break
        # S-tier upgrade — only the historical lottery quadrant
        # CYCLICAL × ELEVATED/PANIC × ADX>25, requires already A/A+ grade
        # OOS data: 39.9% PT-hit rate, +3.14% avg, Sharpe 1.95 (vs 23%/+1.17/0.90 baseline)
        if r.grade in ("A", "A+") and self._check_s_tier(sig, r):
            r.grade = "S"
        r.sizing = self._GRADE_SIZING.get(r.grade, "SKIP")
        r.quality_rank = self._compute_quality_rank(sig, r)
        r.verdict = self._build_entry_verdict(sig, r)
        return r

    def _extract_signal(self, price_df, symbol):
        sig = BBRideSignal(symbol=symbol)
        if price_df is None or len(price_df) < self.MIN_BARS:
            return sig
        df = price_df
        c = df["Close"]; h = df["High"]; l = df["Low"]
        v = df["Volume"] if "Volume" in df.columns else pd.Series(0, index=df.index)
        mid = c.rolling(self.BB_PERIOD).mean()
        std = c.rolling(self.BB_PERIOD).std()
        upper = mid + self.BB_STD * std
        lower = mid - self.BB_STD * std
        band = (upper - lower).replace(0, np.nan)
        pctb = (c - lower) / band
        bbw = band / mid.replace(0, np.nan) * 100
        sma50 = c.rolling(50, min_periods=30).mean()
        tr = pd.concat([h-l, (h-c.shift(1)).abs(), (l-c.shift(1)).abs()], axis=1).max(axis=1)
        atr = tr.rolling(14).mean()
        vol_avg = v.rolling(20).mean().replace(0, np.nan)
        vol_ratio = v / vol_avg
        delta = c.diff()
        with np.errstate(divide="ignore", invalid="ignore"):
            rs = np.where((-delta.clip(upper=0)).rolling(14).mean() > 0,
                          delta.clip(lower=0).rolling(14).mean() / (-delta.clip(upper=0)).rolling(14).mean(), 0)
        rsi = pd.Series(100 - (100 / (1 + rs)), index=df.index)
        tp = (h+l+c)/3; mf = tp*v
        pmf = pd.Series(np.where(tp>tp.shift(1), mf, 0), index=df.index)
        nmf = pd.Series(np.where(tp<tp.shift(1), mf, 0), index=df.index)
        with np.errstate(divide="ignore", invalid="ignore"):
            mfr = np.where(nmf.rolling(14).sum()>0, pmf.rolling(14).sum()/nmf.rolling(14).sum(), 0)
        mfi_s = pd.Series(100-(100/(1+mfr)), index=df.index)
        up_move = h.diff(); dn_move = -l.diff()
        pdm = pd.Series(np.where((up_move>dn_move)&(up_move>0), up_move, 0), index=df.index)
        mdm = pd.Series(np.where((dn_move>up_move)&(dn_move>0), dn_move, 0), index=df.index)
        pdi = 100*pdm.rolling(14).mean()/atr.replace(0, np.nan)
        mdi = 100*mdm.rolling(14).mean()/atr.replace(0, np.nan)
        dx = 100*(pdi-mdi).abs()/(pdi+mdi).replace(0, np.nan)
        adx = dx.rolling(14).mean()
        sig.data_sufficient = True
        sig.close = float(c.iloc[-1])
        sig.bb_upper = float(upper.iloc[-1]) if not pd.isna(upper.iloc[-1]) else 0
        sig.bb_mid = float(mid.iloc[-1]) if not pd.isna(mid.iloc[-1]) else 0
        sig.bb_lower = float(lower.iloc[-1]) if not pd.isna(lower.iloc[-1]) else 0
        sig.bb_pct = float(pctb.iloc[-1]) if not pd.isna(pctb.iloc[-1]) else 0.5
        sig.bbw = float(bbw.iloc[-1]) if not pd.isna(bbw.iloc[-1]) else 0
        sig.bbw_slope = float(bbw.iloc[-1]-bbw.iloc[-6]) if len(bbw)>=6 and not pd.isna(bbw.iloc[-6]) else 0
        sig.sma_50 = float(sma50.iloc[-1]) if not pd.isna(sma50.iloc[-1]) else 0
        sig.above_sma50 = sig.close > sig.sma_50 if sig.sma_50 > 0 else False
        sig.pct_from_sma50 = (sig.close/sig.sma_50-1)*100 if sig.sma_50 > 0 else 0
        sig.vol_ratio = float(vol_ratio.iloc[-1]) if not pd.isna(vol_ratio.iloc[-1]) else 0
        sig.rsi = float(rsi.iloc[-1]) if not pd.isna(rsi.iloc[-1]) else 50
        sig.mfi = float(mfi_s.iloc[-1]) if not pd.isna(mfi_s.iloc[-1]) else 50
        sig.adx = float(adx.iloc[-1]) if not pd.isna(adx.iloc[-1]) else 20
        sig.atr = float(atr.iloc[-1]) if not pd.isna(atr.iloc[-1]) else 0
        sig.roc_10 = float(c.pct_change(10).iloc[-1]*100) if len(c)>10 else 0
        prev_upper = float(upper.iloc[-2]) if len(upper)>=2 and not pd.isna(upper.iloc[-2]) else 0
        prev_close = float(c.iloc[-2]) if len(c)>=2 else 0
        sig.at_upper = sig.close >= sig.bb_upper if sig.bb_upper > 0 else False
        sig.was_below_upper = prev_close < prev_upper if prev_upper > 0 else True
        sig.entry_triggered = sig.at_upper and sig.was_below_upper
        if sig.entry_triggered:
            sig.entry_reason = (f"BB RIDE: touched upper band ({sig.bb_upper:,.0f}) | "
                                f"%B={sig.bb_pct:.2f} | Vol={sig.vol_ratio:.1f}x | ROC={sig.roc_10:+.1f}%")
        return sig

    def _compute_grade_pts(self, sig, r):
        pts = 0
        pts += self._VIX_GRADE_PTS.get(r.vix_regime, 1)
        if r.sector_type == "CYCLICAL": pts += 1
        if r.rs_bucket == "LEADING": pts += 1
        elif r.rs_bucket == "LAGGING": pts -= 1
        if sig.vol_ratio >= 1.3: pts += 1
        return pts

    def _check_s_tier(self, sig, r) -> bool:
        """
        S-tier identifies the historical lottery quadrant:
          CYCLICAL sector × ELEVATED/PANIC VIX × ADX > 25 (trending breakout, not chop)
        OOS validation (291 trades 2019-2023):
          - PT-hit rate: 40.2% (vs 23% baseline)
          - Average PnL: +2.96% (vs +1.17% baseline)
          - Sharpe: 1.81 (vs 0.90 baseline)
        Cohen's d = +0.36 each on VIX, BBW, ROC at entry — strongest signals in dataset.
        """
        if r.sector_type != "CYCLICAL":
            return False
        if r.vix_regime not in ("ELEVATED", "PANIC"):
            return False
        if sig.adx < 25:
            return False
        return True

    def _compute_quality_rank(self, sig, r):
        q = 0.0
        vol = max(0.5, min(3.0, sig.vol_ratio))
        q += (math.log(vol/0.5)/math.log(6.0))*25
        pctb = max(1.0, min(1.5, sig.bb_pct))
        q += ((pctb-1.0)/0.5)*20
        bbw_val = max(2, min(12, sig.bbw))
        q += ((bbw_val-2)/10)*15
        roc = max(-5, min(15, sig.roc_10))
        q += ((roc+5)/20)*15
        adx_val = max(10, min(40, sig.adx))
        q += ((adx_val-10)/30)*10
        if sig.above_sma50: q += 15
        return round(max(0, min(100, q)), 1)

    def _build_entry_verdict(self, sig, r):
        cats = []
        if r.vix_regime in ("ELEVATED","PANIC"): cats.append(f"vol regime ({r.vix_regime.lower()})")
        if r.sector_type == "CYCLICAL": cats.append("cyclical")
        if r.rs_bucket == "LEADING": cats.append("sector leading")
        if sig.vol_ratio >= 1.5: cats.append(f"vol {sig.vol_ratio:.1f}x")
        elif sig.vol_ratio >= 1.3: cats.append("volume confirming")
        if sig.above_sma50: cats.append("above SMA50")
        cat_str = ", ".join(cats[:3]) if cats else "BB upper touch"
        if r.grade == "S":
            return f"★ RIDE S-TIER [{r.grade}] — lottery setup: {cat_str}"
        if r.sizing == "FULL": return f"▶ RIDE FULL [{r.grade}] — {cat_str}"
        elif r.sizing == "HALF": return f"▷ RIDE HALF [{r.grade}] — {cat_str}"
        return f"▽ WATCH [{r.grade}] — {cat_str}"

    def _build_non_entry_verdict(self, sig):
        if not sig.data_sufficient: return "— insufficient data"
        if sig.at_upper and not sig.was_below_upper: return f"△ RIDING — at upper band, %B={sig.bb_pct:.2f}"
        if sig.bb_pct >= 0.75: return f"▽ WATCH — near upper, %B={sig.bb_pct:.2f}"
        if sig.bb_pct >= 0.5: return f"▽ NEUTRAL — mid-band, %B={sig.bb_pct:.2f}"
        return f"▽ SKIP — below mid-band, %B={sig.bb_pct:.2f}"

    def get_sector_type(self, sector_name):
        return self._SECTOR_TYPE.get(sector_name, "UNKNOWN")

    def get_rs_bucket(self, rs_20d):
        if rs_20d > 2.0: return "LEADING"
        elif rs_20d < -2.0: return "LAGGING"
        return "INLINE"


# ── Module-level singleton + convenience function ────────────────────────────

_engine = BBRideEngine()

def compute_ride(price_df, symbol="", vix_regime="UNKNOWN", sector_ctx=None):
    """Convenience function — calls the singleton engine.
    This is what DataManager and scanner worker call. Single source of truth."""
    return _engine.compute(price_df, symbol=symbol, vix_regime=vix_regime, sector_ctx=sector_ctx)
