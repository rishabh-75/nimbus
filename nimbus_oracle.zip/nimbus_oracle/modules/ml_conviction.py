"""
modules/ml_conviction.py — ML-based win probability for mean-reversion trades.

This module is ADDITIVE — it never replaces the rules-based score, grade, or verdict.
It provides a calibrated P(win) that sits alongside those outputs as a second opinion.

Architecture:
  - Model is trained offline by scripts/train_conviction.py
  - Model file lives at data/models/conviction_model.pkl
  - If model file is missing, predict() returns None (graceful degradation)
  - Features are the same ones already computed by dual_mode.py and scanner.py
  - Never imported at module level — always lazy-loaded on first call

Usage:
    from modules.ml_conviction import predict_conviction
    result = predict_conviction(features_dict)
    # result = {"p_win": 0.78, "e_return": 2.3, "confidence": "high"} or None
"""
import logging
import os

logger = logging.getLogger(__name__)

_MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "models", "conviction_model.pkl")
_model = None
_feature_names = None
_model_loaded = False  # distinguish "not yet tried" from "tried and failed"


# ── Feature extraction ───────────────────────────────────────────────────────

FEATURE_SPEC = [
    # (name, source, description)
    ("wr_30", "dm_sig.wr_30", "Williams %R(30) at entry"),
    ("mfi", "dm_sig.mfi", "Money Flow Index"),
    ("mfi_slope", "dm_sig.mfi_slope", "MFI 5-bar slope"),
    ("dd_from_high", "dm_sig.dd_from_high", "Drawdown from 50d high (%)"),
    ("red_streak", "dm_sig.red_streak", "Consecutive red days"),
    ("vol_ratio", "dm_sig.vol_ratio", "Volume vs 20d average"),
    ("bbw_pctl", "dm_sig.bbw_pctl", "BBW percentile (0-100)"),
    ("pct_from_sma", "dm_sig.pct_from_sma", "% distance from SMA(20)"),
    ("base_score", "dm_sig.base_score", "Rules-based score (0-100)"),
    ("options_overlay", "dm_sig.options_overlay", "Options overlay (±10)"),
    ("filing_overlay", "dm_sig.filing_overlay", "Filing overlay (±10)"),
    ("vix", "scanner", "India VIX at entry"),
    ("adx", "dm_sig.adx_14", "ADX trend strength"),
    ("rsi", "dm_sig.rsi", "RSI(14)"),
    ("bbw_slope", "dm_sig.bbw_slope", "BBW 5-bar slope"),
    ("is_friday", "derived", "1 if Friday entry, 0 otherwise"),
]

FEATURE_NAMES = [f[0] for f in FEATURE_SPEC]


def extract_features(dm_sig=None, scanner_row=None, vix=None):
    """
    Extract ML features from a DualModeSignal or scanner result dict.
    Returns dict of {feature_name: value} or None if insufficient data.
    """
    if dm_sig is not None:
        import datetime as _dt
        return {
            "wr_30": dm_sig.wr_30,
            "mfi": dm_sig.mfi,
            "mfi_slope": dm_sig.mfi_slope,
            "dd_from_high": dm_sig.dd_from_high,
            "red_streak": dm_sig.red_streak,
            "vol_ratio": dm_sig.vol_ratio,
            "bbw_pctl": dm_sig.bbw_pctl,
            "pct_from_sma": dm_sig.pct_from_sma,
            "base_score": dm_sig.base_score,
            "options_overlay": dm_sig.options_overlay,
            "filing_overlay": dm_sig.filing_overlay,
            "vix": vix if vix is not None else 15.0,
            "adx": dm_sig.adx_14,
            "rsi": dm_sig.rsi,
            "bbw_slope": dm_sig.bbw_slope,
            "is_friday": 1 if _dt.datetime.now().weekday() == 4 else 0,
        }

    if scanner_row is not None:
        import datetime as _dt
        return {
            "wr_30": scanner_row.get("dm_wr") or -30,
            "mfi": scanner_row.get("dm_mfi") or 40,
            "mfi_slope": 0,
            "dd_from_high": scanner_row.get("dm_dd") or -5,
            "red_streak": scanner_row.get("dm_streak") or 0,
            "vol_ratio": 1.0,
            "bbw_pctl": 50,
            "pct_from_sma": scanner_row.get("dm_pct_sma") or 0,
            "base_score": scanner_row.get("dm_score") or 50,
            "options_overlay": 0,
            "filing_overlay": 0,
            "vix": scanner_row.get("vix") or 15.0,
            "adx": scanner_row.get("dm_adx") or 20,
            "rsi": 50,
            "bbw_slope": scanner_row.get("dm_bbw_slope") or 0,
            "is_friday": 1 if scanner_row.get("is_friday", _dt.datetime.now().weekday() == 4) else 0,
        }

    return None


# ── Model loading (lazy, once) ───────────────────────────────────────────────

def _load_model():
    """Load model from disk. Called once on first predict(). Thread-safe enough."""
    global _model, _feature_names, _model_loaded
    _model_loaded = True

    model_path = os.path.abspath(_MODEL_PATH)
    if not os.path.exists(model_path):
        logger.debug("ML model not found at %s — conviction predictions disabled", model_path)
        return False

    try:
        import joblib
        data = joblib.load(model_path)
        _model = data["model"]
        _feature_names = data.get("feature_names", FEATURE_NAMES)
        logger.info("ML conviction model loaded: %s (features: %d)",
                    model_path, len(_feature_names))
        return True
    except ImportError:
        logger.debug("joblib not installed — ML predictions disabled")
        return False
    except Exception as exc:
        logger.warning("ML model load failed: %s", exc)
        return False


# ── Prediction ───────────────────────────────────────────────────────────────

def predict_conviction(features_dict):
    """
    Predict win probability and expected return for a trade.

    Args:
        features_dict: output of extract_features()

    Returns:
        dict with {"p_win": float, "confidence": str} or None if model unavailable.
        Never raises — returns None on any error.
    """
    if not _model_loaded:
        _load_model()

    if _model is None:
        return None

    try:
        import numpy as np

        # Build feature vector in correct order
        feature_vec = np.array([[features_dict.get(f, 0) for f in _feature_names]])

        # Handle NaN/inf
        feature_vec = np.nan_to_num(feature_vec, nan=0, posinf=0, neginf=0)

        # Predict probability
        p_win = float(_model.predict_proba(feature_vec)[0, 1])

        # Confidence bracket
        if p_win >= 0.80:
            confidence = "high"
        elif p_win >= 0.65:
            confidence = "medium"
        else:
            confidence = "low"

        return {
            "p_win": round(p_win, 3),
            "p_win_pct": round(p_win * 100, 1),
            "confidence": confidence,
        }

    except Exception as exc:
        logger.debug("ML prediction failed: %s", exc)
        return None


def is_model_available():
    """Check if a trained model exists without loading it."""
    return os.path.exists(os.path.abspath(_MODEL_PATH))
