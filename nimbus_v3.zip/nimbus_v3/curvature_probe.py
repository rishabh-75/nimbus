#!/usr/bin/env python3
"""curvature_probe.py — does the EMA20/SMA20 gap predict forward returns?

THE THEORY BEING TESTED
-----------------------
"Take EMA20 and SMA20. When they DIVERGE or run PARALLEL the stock is
rising; when they CONVERGE it is starting to revert."

THE FIRST-PRINCIPLES REFRAME (why the raw theory is imprecise)
--------------------------------------------------------------
EMA20 and SMA20 have the SAME centre-of-mass lag — both 9.5 bars (that is
the whole point of the alpha = 2/(N+1) convention: it matches the SMA's
average age). What differs is the WIDTH of the two weighting kernels
(EMA variance 99.75 vs SMA boxcar 33.25). Subtracting two filters of equal
lag cancels the SLOPE term and leaves, to leading order,

        EMA20 - SMA20  ~=  33.25 x price''(t)          (price ACCELERATION)

So the gap is a CURVATURE gauge, not a trend gauge. Consequences:

  * A steady trend of ANY steepness -> gap ~ 0 (the lines OVERLAP). A stock
    ripping straight up at a constant rate looks "converged". So
    "converging => reverting" conflates a topping move with a healthy
    constant-slope trend — they are the same picture to this signal.
  * "Diverging => rising" is sign-blind: EMA pulling ABOVE SMA is upward
    acceleration; EMA pulling BELOW is an accelerating DECLINE.
  * It is a second derivative of an already-lagged, already-smoothed series
    — structurally the noisiest, lattest thing in the toolkit.

None of that says the effect is zero. It says the theory needs to be
operationalised with the SIGN and the SLOPE of the gap, then tested against
forward EXCESS return with a hold-out and a random control — same frame as
entry_probe / volume_probe. That is what this does.

WHAT IS TESTED (per as-of date, cross-section, de-marketed)
-----------------------------------------------------------
    gap            (EMA20 - SMA20)/Close * 100   signed accel proxy
    -gap           the mean-reversion sign of the same
    gap_slope      gap(t) - gap(t-3)             DIVERGING(>0)/CONVERGING(<0)
    -gap_slope     the reverse sign
    abs_gap        |gap|      "parallel/diverged EITHER way" (magnitude only)
    gap_x_trend    gap * sign(SMA slope)   accel ALIGNED with the trend
                                           (the charitable reading of the
                                           theory: diverging WITH the trend)
    price_accel    normalised 2nd difference of Close — the raw curvature the
                   gap approximates, as an independent cross-check
    sma_slope      SMA20 slope — pure TREND, the reference. If the gap beats
                   nothing but sma_slope beats random, the information was in
                   the trend, not the convergence story.
    ~random~       the noise floor. If nothing clears it, there is nothing.

READ THE HOLD-OUT COLUMN, and read the COHORT table. The cohort table is the
direct verdict on the stated theory: it pools names by converging/parallel/
diverging and shows what each did NEXT. If diverging names do not out-return
converging ones out-of-sample, the theory is decoration however good the one
chart looked.

USAGE
    python curvature_probe.py
    python curvature_probe.py --horizons 5,10,20 --dates 60 --slope-k 3
    python curvature_probe.py --selftest      # verify the gap==curvature math
"""
from __future__ import annotations

import argparse
import statistics
import sys


# --------------------------------------------------------------------------
# stats helpers (identical conventions to volume_probe.spearman)
# --------------------------------------------------------------------------
def spearman(a, b):
    def ranks(xs):
        order = sorted(range(len(xs)), key=lambda i: xs[i], reverse=True)
        r = [0] * len(xs)
        for pos, i in enumerate(order):
            r[i] = pos
        return r
    n = len(a)
    if n < 3:
        return float("nan")
    ra, rb = ranks(a), ranks(b)
    d2 = sum((ra[i] - rb[i]) ** 2 for i in range(n))
    return 1.0 - 6.0 * d2 / (n * (n * n - 1))


def _t_of(xs):
    """t-stat of a sample mean against zero."""
    if len(xs) < 2:
        return 0.0
    m = statistics.mean(xs)
    se = statistics.stdev(xs) / (len(xs) ** 0.5)
    return m / se if se > 0 else 0.0


# --------------------------------------------------------------------------
# panel loading — identical to volume_probe.load_panel so it shares the
# enriched cache and the frozen schema hash.
# --------------------------------------------------------------------------
def load_panel(engine, ind_db):
    from nimbus_v3.data.cache import ParquetCache
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.paths import cache_dir

    raw = ParquetCache(base_dir=cache_dir("equity_price"))
    ec = EnrichedPanelCache(raw_cache=raw,
                            schema_hash=engine.enrichment_schema_hash())
    panel, members = {}, {}
    for sym in sorted(ind_db):
        df = ec.get_if_fresh(sym)
        if df is None:
            df = ec.get_stale(sym)
        if df is None:
            try:
                r = raw.get(sym)
            except Exception:            # noqa: BLE001
                r = None
            if r is not None and not r.empty:
                try:
                    df = engine.enrich(r, sym)
                except Exception:        # noqa: BLE001
                    df = None
        if df is None or df.empty:
            continue
        panel[sym] = df
        rec = ind_db.get(sym)
        if rec is not None and rec.industry:
            members.setdefault(rec.industry, []).append(sym)
    return panel, members


MA_WINDOW = 20
WARMUP = 60                 # enough for the EMA recursion to settle


# --------------------------------------------------------------------------
# feature construction
# --------------------------------------------------------------------------
def _gap_series(close, n=MA_WINDOW):
    """Return the normalised gap series g = (EMA_n - SMA_n)/Close * 100.

    Pure price transform; no lookahead — every point uses only close[:t+1].
    """
    import numpy as np
    import pandas as pd

    s = pd.Series(close, dtype=float)
    ema = s.ewm(span=n, adjust=False).mean().to_numpy()
    sma = s.rolling(n).mean().to_numpy()
    with np.errstate(invalid="ignore", divide="ignore"):
        g = (ema - sma) / s.to_numpy() * 100.0
    return g, ema, sma


def features_at(panel, asof, slope_k, rng):
    """Every candidate curvature feature as of DATE ``asof``.

    Sliced by DATE (df.loc[:asof]), not position — symbols have different
    histories, so positional slicing would compare mismatched dates. All
    inputs are at/<= asof; the forward return is measured after.
    """
    import numpy as np

    feats = {}
    for sym, df in panel.items():
        h = df.loc[:asof]
        if len(h) < WARMUP + slope_k + 2:
            continue
        close = h["Close"].to_numpy(dtype=float)
        if close[-1] <= 0:
            continue
        g, _, sma = _gap_series(close)
        gap = g[-1]
        gap_k = g[-1 - slope_k]
        if not (np.isfinite(gap) and np.isfinite(gap_k)):
            continue
        gap_slope = gap - gap_k                     # >0 diverging, <0 conv.

        # pure trend reference: SMA20 slope over the same k, %/bar
        if not np.isfinite(sma[-1]) or not np.isfinite(sma[-1 - slope_k]) \
                or sma[-1 - slope_k] <= 0:
            continue
        sma_slope = (sma[-1] / sma[-1 - slope_k] - 1.0) * 100.0

        # raw curvature cross-check: 2nd difference of close, normalised
        accel = (close[-1] - 2 * close[-1 - slope_k]
                 + close[-1 - 2 * slope_k]) / close[-1] * 100.0 \
            if len(close) > 2 * slope_k else float("nan")

        feats[sym] = {
            "gap": gap,
            "-gap": -gap,
            "gap_slope": gap_slope,
            "-gap_slope": -gap_slope,
            "abs_gap": abs(gap),
            "gap_x_trend": gap * np.sign(sma_slope),
            "price_accel": accel,
            "sma_slope": sma_slope,
            "~random~": rng.random(),
        }
    return feats


CANDIDATES = ["gap", "-gap", "gap_slope", "-gap_slope", "abs_gap",
              "gap_x_trend", "price_accel", "sma_slope", "~random~"]


def forward_excess(panel, feats, asof, horizon):
    """Forward EXCESS return over the equal-weight cross-section on ``asof``.

    Excess so the number measures whether the SIGNAL picked the right names,
    not whether the market happened to rise.
    """
    import numpy as np

    fwd = {}
    for sym in feats:
        df = panel[sym]
        idx = df.index
        pos = idx.searchsorted(asof, side="right") - 1
        if pos < 0 or pos + horizon >= len(idx):
            continue
        c = df["Close"].to_numpy(dtype=float)
        c0, c1 = c[pos], c[pos + horizon]
        if c0 > 0:
            fwd[sym] = (c1 / c0 - 1.0) * 100.0
    if len(fwd) < 40:
        return None, None
    mkt = float(np.mean(list(fwd.values())))
    return fwd, mkt


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--horizons", default="5,10,20",
                    help="forward horizons in bars")
    ap.add_argument("--dates", type=int, default=60,
                    help="as-of dates sampled, stepping back by --step")
    ap.add_argument("--step", type=int, default=5)
    ap.add_argument("--slope-k", type=int, default=3,
                    help="bars over which the gap slope (converging vs "
                         "diverging) and the trend reference are measured")
    ap.add_argument("--holdout", type=float, default=0.38,
                    help="hold-out fraction (fit on the rest). The FIT column "
                         "exists only to show DECAY into the hold-out.")
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--csv", default=None)
    ap.add_argument("--selftest", action="store_true",
                    help="verify gap==curvature on synthetic paths and exit")
    args = ap.parse_args()

    if args.selftest:
        return _selftest()

    import numpy as np
    import pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    print("loading panel...", file=sys.stderr)
    panel, _members = load_panel(eng, db)
    if not panel:
        print("panel empty — run the app once first.", file=sys.stderr)
        return 1

    lens = sorted(len(df) for df in panel.values())
    all_dates = sorted({d for df in panel.values() for d in df.index})
    print(f"  {len(panel)} symbols   bars: min={lens[0]} "
          f"median={lens[len(lens) // 2]} max={lens[-1]}", file=sys.stderr)
    print(f"  span {all_dates[0].date()} -> {all_dates[-1].date()} "
          f"({len(all_dates)} trading days)   slope_k={args.slope_k}",
          file=sys.stderr)

    horizons = [int(h) for h in args.horizons.split(",")]
    rng = np.random.default_rng(args.seed)
    rows_out = []

    for H in horizons:
        # ---- pool every (value, fwd_excess) obs across sampled dates -----
        pooled = {k: [] for k in CANDIDATES}
        # cohort pools: split the cross-section each date into diverging /
        # parallel / converging by gap_slope terciles, collect fwd excess.
        cohorts = {"strong conv": [], "converging": [], "parallel": [],
                   "diverging": [], "strong div": []}
        used = 0
        for i in range(args.dates):
            di = len(all_dates) - H - 1 - i * args.step
            if di < WARMUP + args.slope_k + 5:
                break
            asof = all_dates[di]
            feats = features_at(panel, asof, args.slope_k, rng)
            if len(feats) < 40:
                continue
            fwd, mkt = forward_excess(panel, feats, asof, H)
            if fwd is None:
                continue
            used += 1
            for sym, fr in fwd.items():
                ex = fr - mkt
                for k in CANDIDATES:
                    v = feats[sym][k]
                    if v == v:                       # not NaN
                        pooled[k].append((v, ex))

            # cohort assignment by within-date gap_slope quintiles
            slopes = sorted(feats[s]["gap_slope"] for s in fwd)
            n = len(slopes)
            q = [slopes[int(n * p)] for p in (0.2, 0.4, 0.6, 0.8)]
            for sym, fr in fwd.items():
                gs = feats[sym]["gap_slope"]
                ex = fr - mkt
                if gs <= q[0]:
                    cohorts["strong conv"].append(ex)
                elif gs <= q[1]:
                    cohorts["converging"].append(ex)
                elif gs <= q[2]:
                    cohorts["parallel"].append(ex)
                elif gs <= q[3]:
                    cohorts["diverging"].append(ex)
                else:
                    cohorts["strong div"].append(ex)

        if used == 0:
            continue

        # ================= COHORT TABLE (the direct verdict) ==============
        print()
        print("=" * 90)
        print(f"  EMA20/SMA20 GAP — {H}-day forward EXCESS return  "
              f"({used} as-of dates)")
        print("=" * 90)
        print("  THE THEORY, DIRECTLY: pool names by gap SLOPE (is the gap")
        print("  opening or closing?) and see what each cohort did next.")
        print("  Theory predicts diverging>0, converging<0.")
        print()
        print(f"    {'cohort (gap slope)':<20}{'n':>8}{'excess':>10}{'t':>7}")
        print("    " + "-" * 45)
        for name in ("strong conv", "converging", "parallel",
                     "diverging", "strong div"):
            g = cohorts[name]
            if len(g) < 30:
                continue
            m = statistics.mean(g)
            t = _t_of(g)
            star = " *" if abs(t) > 2 else ""
            print(f"    {name:<20}{len(g):>8}{m:>+9.2f}%{t:>7.1f}{star}")
        print()

        # ================= CANDIDATE FIT / HOLD-OUT TABLE =================
        print("  " + "-" * 86)
        print(f"  CANDIDATE RANKING — fit/hold-out split "
              f"(hold-out = {args.holdout:.0%})")
        print(f"    {'candidate':<16}{'FIT rho':>9}{'OOS rho':>9}"
              f"{'OOS top':>10}{'spread':>10}{'t':>7}  sig")
        print("    " + "-" * 66)
        control_top = None
        winners = []
        for k in CANDIDATES:
            obs = pooled[k]
            if len(obs) < 400:
                continue
            # deterministic split per feature
            r = np.random.default_rng(args.seed + hash(k) % 9973)
            idx = np.arange(len(obs))
            r.shuffle(idx)
            cut = int(len(obs) * (1 - args.holdout))
            fit = [obs[j] for j in idx[:cut]]
            oos = [obs[j] for j in idx[cut:]]

            fit_rho = spearman([v for v, _ in fit], [e for _, e in fit])
            oos_rho = spearman([v for v, _ in oos], [e for _, e in oos])

            # OOS top/bottom DECILE forward excess, and the t of the top
            oos_sorted = sorted(oos, key=lambda t: -t[0])
            d = max(1, len(oos_sorted) // 10)
            top_ret = [e for _, e in oos_sorted[:d]]
            bot_ret = [e for _, e in oos_sorted[-d:]]
            oos_top = statistics.mean(top_ret)
            spread = oos_top - statistics.mean(bot_ret)
            t = _t_of(top_ret)
            sig = " *" if abs(t) > 2 else ""

            if k == "~random~":
                control_top = oos_top
            elif abs(t) > 2:
                winners.append((k, oos_top, t, fit_rho, oos_rho))

            tag = "  <<<" if k == "~random~" else (
                "  <-- pure trend" if k == "sma_slope" else "")
            print(f"    {k:<16}{fit_rho:>+9.3f}{oos_rho:>+9.3f}"
                  f"{oos_top:>+9.2f}%{spread:>+9.2f}%{t:>7.1f}{sig}{tag}")

            rows_out.append({
                "horizon": H, "feature": k, "fit_rho": fit_rho,
                "oos_rho": oos_rho, "oos_top": oos_top, "spread": spread,
                "t": t, "n_obs": len(obs), "significant": bool(sig.strip()),
            })

        # verdict line, entry_probe style
        real = [w for w in winners
                if control_top is None or abs(w[1]) > abs(control_top)]
        if real:
            print(f"    -> {len(real)} candidate(s) clear |t|>2 OUT-OF-SAMPLE "
                  f"and beat the control:")
            for k, top, t, fr, orh in real:
                print(f"       {k:<14} OOS {top:+.2f}% (t {t:+.1f})  "
                      f"fit->oos rho {fr:+.3f} -> {orh:+.3f}")
        else:
            print("    -> nothing clears |t|>2 out-of-sample "
                  "AND beats the control.")

    print()
    print("  HOW TO READ THIS")
    print("  * COHORT table is the theory verbatim: does 'diverging' out-")
    print("    return 'converging'? If both hover at 0% with |t|<2, the")
    print("    convergence story carries no directional information.")
    print("  * HOLD-OUT column only. A candidate strong in-fit and dead OOS")
    print("    is over-fit by definition; the fit column is shown to expose")
    print("    that decay. With ~9 candidates x 3 horizons some WILL star by")
    print("    luck — that is what ~random~ and the split are for.")
    print("  * sma_slope is PURE TREND. If the gap features die but sma_slope")
    print("    lives, the signal was the trend, not the EMA/SMA convergence.")
    print("  * The gap is a 2nd derivative of a lagged series. Prior: low.")
    print("    The harness, not the prior, decides.")
    print()

    if args.csv:
        pd.DataFrame(rows_out).to_csv(args.csv, index=False)
        print(f"wrote {args.csv}", file=sys.stderr)
    return 0


# --------------------------------------------------------------------------
# self-test: verify the gap really is a curvature gauge, no cache needed
# --------------------------------------------------------------------------
def _selftest():
    import numpy as np
    t = np.arange(300.0)

    def gap_mean(close):
        g, _, _ = _gap_series(close)
        g = g[~np.isnan(g)][40:]
        return float(np.mean(g))

    # All paths stay strictly positive (real closes are); the claim is about
    # the SIGN of the gap, so we assert signs with a small tolerance.
    flat = gap_mean(1000 + 0 * t)
    up_shallow = gap_mean(1000 + 2.0 * t)
    up_steep = gap_mean(1000 + 8.0 * t)
    convex = gap_mean(1000 + 0.02 * t ** 2)          # accelerating up
    concave = gap_mean(1000 + 40.0 * np.sqrt(t))     # rising but decelerating

    print("curvature_probe self-test — gap = (EMA20-SMA20)/Close*100")
    print(f"  flat                     mean gap {flat:+.5f}")
    print(f"  steady UP  (slope +2)    mean gap {up_shallow:+.5f}")
    print(f"  steep  UP  (slope +8)    mean gap {up_steep:+.5f}")
    print(f"  convex  (accel up)       mean gap {convex:+.5f}")
    print(f"  concave (rising, fading) mean gap {concave:+.5f}")
    tol = 0.01
    ok = (abs(flat) < 1e-6 and abs(up_shallow) < tol and abs(up_steep) < tol
          and convex > tol and concave < -tol)
    print()
    if ok:
        print("  PASS: gap ~0 for ANY constant-slope trend (so 'converging'")
        print("  is indistinguishable from a healthy steady trend), and only")
        print("  departs from 0 under curvature. The gap measures ACCEL, not")
        print("  trend — exactly the reframe the probe is built on.")
        return 0
    print("  FAIL: gap did not behave as a curvature gauge.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
