"""End-to-end Scanner tests using the real ConvictionEngine."""
from __future__ import annotations

from dataclasses import dataclass, field
from unittest.mock import MagicMock

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.conviction.grade_engine import ConvictionEngine
from nimbus_v3.core.context import MarketContext, SectorContext
from nimbus_v3.core.types import (
    GradeLetter, RSRegime, SetupType, Sizing, Verdict, VIXRegime,
)
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.scanner.engine import ContextProviders, ScanResult, Scanner
from nimbus_v3.strategies.base import StrategySignal
from nimbus_v3.strategies.mean_reversion import (
    MeanReversionParams, MeanReversionStrategy,
)
from nimbus_v3.strategies.pullback_uptrend import PullbackUptrendStrategy
from nimbus_v3.strategies.registry import StrategyRegistry


# ══════════════════════════════════════════════════════════════════════════════
# Panel / universe fixtures
# ══════════════════════════════════════════════════════════════════════════════

def _synthetic_enriched_panel(
    symbols: list[str], *, n_days: int = 400, seed: int = 0,
) -> dict[str, pd.DataFrame]:
    """Build a panel of enriched DataFrames that will produce realistic
    states when run through ``StrategyComputeEngine.extract_state``."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2023-01-01", periods=n_days)
    engine = StrategyComputeEngine()
    panel: dict[str, pd.DataFrame] = {}
    for i, sym in enumerate(symbols):
        log_rets = rng.normal(0.0005, 0.018, size=n_days)
        closes = 100.0 * np.exp(np.cumsum(log_rets))
        raw = pd.DataFrame({
            "Open": closes, "High": closes * 1.005, "Low": closes * 0.995,
            "Close": closes, "Volume": 1e6 + rng.normal(0, 1e5, n_days),
        }, index=idx)
        panel[sym] = engine.enrich(raw, sym)
    return panel


def _universe_of(*symbols: str, etfs: tuple[str, ...] = ()) -> Universe:
    symbol_map = {}
    for s in symbols:
        symbol_map[s] = SymbolMeta(symbol=s, sector="Test", is_etf=(s in etfs))
    return Universe(symbols=symbol_map, built_at=pd.Timestamp("2024-01-01"))


# ══════════════════════════════════════════════════════════════════════════════
# Market context fakes
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class _FakeMarketProvider:
    regime: VIXRegime = VIXRegime.NORMAL
    streak: int = 0
    calls: list = field(default_factory=list)

    def build(self, *, symbol, asof_date):
        self.calls.append((symbol, asof_date))
        return MarketContext(
            asof_date=asof_date, vix_value=None,
            vix_regime=self.regime, vix_high_streak=self.streak,
        )


@dataclass
class _FakeSectorProvider:
    regime: RSRegime = RSRegime.NEUTRAL
    rs_20d: float = 0.0

    def build(self, *, symbol, asof_date):
        if symbol is None:
            return None
        return SectorContext(
            asof_date=asof_date, symbol=symbol, sector_name="Test",
            sector_type=None, rs_regime=self.regime, rs_20d=self.rs_20d,
            realized_vol_20d=15.0, vol_z_score=0.0,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Scanner construction helper
# ══════════════════════════════════════════════════════════════════════════════

def _build_scanner(
    *,
    universe: Universe,
    market_streak: int = 6,
    market_regime: VIXRegime = VIXRegime.HIGH,
    strategies: list | None = None,
) -> Scanner:
    if strategies is None:
        strategies = [MeanReversionStrategy()]
    registry = StrategyRegistry()
    for s in strategies:
        registry.register(s)
    return Scanner(
        compute_engine=StrategyComputeEngine(),
        registry=registry,
        providers=ContextProviders(
            market=_FakeMarketProvider(regime=market_regime, streak=market_streak),
            sector=_FakeSectorProvider(),
        ),
        conviction_engine=ConvictionEngine(),
        universe=universe,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Scan results
# ══════════════════════════════════════════════════════════════════════════════

def test_scan_returns_empty_when_no_strategy_fires() -> None:
    """Default synthetic panel (random noise) rarely satisfies MR gates
    — expected output is an empty result list in most random seeds."""
    panel = _synthetic_enriched_panel(["A", "B", "C"], seed=1)
    universe = _universe_of("A", "B", "C")
    scanner = _build_scanner(universe=universe, market_streak=0)
    # With vix_streak=0, the MR gate blocks everything.
    results = scanner.scan(
        enriched_panel=panel, asof_date=panel["A"].index[-1],
    )
    assert results == []


def test_scan_emits_results_when_gates_pass() -> None:
    """Force an MR signal by crafting a panel where the last bar has
    roc_5<-3, bbw_pctl<40 — the three MR gates — then scan under a
    HIGH-VIX market regime."""
    panel = _forced_mr_panel(["RELIANCE"])
    universe = _universe_of("RELIANCE")
    scanner = _build_scanner(universe=universe, market_streak=7)
    results = scanner.scan(
        enriched_panel=panel,
        asof_date=panel["RELIANCE"].index[-1],
    )
    assert len(results) == 1
    r = results[0]
    assert r.symbol == "RELIANCE"
    assert r.conviction.setup_type == SetupType.MEAN_REVERSION
    assert r.conviction.verdict in (Verdict.TAKE, Verdict.WATCH)
    assert isinstance(r.conviction.grade, GradeLetter)


def test_scan_sorts_by_score_desc() -> None:
    panel = _forced_mr_panel(["SYM_A", "SYM_B", "SYM_C"], seed_offset=10)
    universe = _universe_of("SYM_A", "SYM_B", "SYM_C")
    scanner = _build_scanner(universe=universe, market_streak=7)
    results = scanner.scan(
        enriched_panel=panel,
        asof_date=panel["SYM_A"].index[-1],
    )
    scores = [r.conviction.score for r in results]
    assert scores == sorted(scores, reverse=True)


def test_scan_respects_symbol_subset() -> None:
    panel = _forced_mr_panel(["A", "B", "C"])
    universe = _universe_of("A", "B", "C")
    scanner = _build_scanner(universe=universe, market_streak=7)
    results = scanner.scan(
        enriched_panel=panel,
        asof_date=panel["A"].index[-1],
        symbols=["A", "B"],
    )
    symbols_seen = {r.symbol for r in results}
    assert symbols_seen.issubset({"A", "B"})


def test_scan_skips_symbols_not_in_universe() -> None:
    panel = _forced_mr_panel(["A", "B"])
    universe = _universe_of("A")    # B is in panel but not universe
    scanner = _build_scanner(universe=universe, market_streak=7)
    results = scanner.scan(
        enriched_panel=panel,
        asof_date=panel["A"].index[-1],
    )
    assert all(r.symbol == "A" for r in results)


# ══════════════════════════════════════════════════════════════════════════════
# Resilience
# ══════════════════════════════════════════════════════════════════════════════

def test_scan_partial_output_on_symbol_failure(caplog) -> None:
    """A broken symbol should not kill the scan — log + skip + continue."""
    panel = _forced_mr_panel(["GOOD"])
    # Insert a broken row for a second symbol.
    broken = pd.DataFrame({"Close": [1.0]}, index=[pd.Timestamp("2024-01-02")])
    panel["BROKEN"] = broken
    universe = _universe_of("GOOD", "BROKEN")
    scanner = _build_scanner(universe=universe, market_streak=7)
    results = scanner.scan(
        enriched_panel=panel,
        asof_date=panel["GOOD"].index[-1],
    )
    # BROKEN either scans to empty (no bar at cutoff) or logs + skips.
    # GOOD must still be present.
    assert any(r.symbol == "GOOD" for r in results)


def test_scan_handles_future_asof_date_before_panel_start() -> None:
    """An asof before the panel start → no bar found → empty output."""
    panel = _forced_mr_panel(["X"])
    universe = _universe_of("X")
    scanner = _build_scanner(universe=universe, market_streak=7)
    too_early = pd.Timestamp("2020-01-01")
    results = scanner.scan(enriched_panel=panel, asof_date=too_early)
    assert results == []


# ══════════════════════════════════════════════════════════════════════════════
# Context wiring
# ══════════════════════════════════════════════════════════════════════════════

def test_scan_calls_market_provider_per_symbol() -> None:
    panel = _forced_mr_panel(["A", "B"])
    universe = _universe_of("A", "B")
    market = _FakeMarketProvider(regime=VIXRegime.HIGH, streak=7)
    registry = StrategyRegistry()
    registry.register(MeanReversionStrategy())
    scanner = Scanner(
        compute_engine=StrategyComputeEngine(), registry=registry,
        providers=ContextProviders(market=market, sector=_FakeSectorProvider()),
        conviction_engine=ConvictionEngine(),
        universe=universe,
    )
    scanner.scan(
        enriched_panel=panel, asof_date=panel["A"].index[-1],
    )
    # One call per symbol (each asks for market context).
    assert len(market.calls) == 2


def test_scan_synthesises_neutral_market_context_when_missing() -> None:
    """If no market provider is injected, the scanner falls back to a
    neutral MarketContext — scan still runs without raising."""
    panel = _forced_mr_panel(["X"])
    universe = _universe_of("X")
    registry = StrategyRegistry()
    registry.register(MeanReversionStrategy())
    scanner = Scanner(
        compute_engine=StrategyComputeEngine(),
        registry=registry,
        providers=ContextProviders(),    # no providers at all
        conviction_engine=ConvictionEngine(),
        universe=universe,
    )
    # Should not raise, even though MR requires vix_streak>=6 (fails gracefully).
    results = scanner.scan(enriched_panel=panel, asof_date=panel["X"].index[-1])
    assert results == []    # MR gate fails due to 0 streak


# ══════════════════════════════════════════════════════════════════════════════
# Research-tier strategy flows through but doesn't influence sizing
# ══════════════════════════════════════════════════════════════════════════════

def test_scan_research_tier_produces_watch_not_take() -> None:
    """A research-tier strategy (production_weight=0) must still appear
    in scan results but always with Verdict.WATCH / Sizing.SKIP."""
    panel = _forced_pullback_panel(["X"])
    universe = _universe_of("X")
    # Only Pullback registered — we want just that signal to fire.
    scanner = _build_scanner(
        universe=universe, market_streak=0,
        market_regime=VIXRegime.NORMAL,
        strategies=[PullbackUptrendStrategy()],
    )
    results = scanner.scan(
        enriched_panel=panel, asof_date=panel["X"].index[-1],
    )
    if results:   # signal must fire to exercise the assertion
        r = results[0]
        assert r.strategy.production_weight == 0.0
        assert r.conviction.verdict == Verdict.WATCH
        assert r.conviction.sizing == Sizing.SKIP
        assert r.conviction.override_reason is not None


# ══════════════════════════════════════════════════════════════════════════════
# Sort-stability / priority tiebreak
# ══════════════════════════════════════════════════════════════════════════════

def test_multiple_strategies_same_symbol_both_appear() -> None:
    """If MR AND Pullback both fire on the same symbol on the same bar,
    the scanner emits two ScanResult rows (one per strategy)."""
    panel = _multi_fire_panel(["X"])
    universe = _universe_of("X")
    scanner = _build_scanner(
        universe=universe, market_streak=7,
        strategies=[MeanReversionStrategy(), PullbackUptrendStrategy()],
    )
    results = scanner.scan(
        enriched_panel=panel, asof_date=panel["X"].index[-1],
    )
    # One symbol, but potentially multiple results (one per firing strategy).
    if len(results) > 1:
        strategy_names = {r.strategy.name for r in results}
        assert len(strategy_names) == len(results)


# ══════════════════════════════════════════════════════════════════════════════
# Panel crafters — these produce synthetic enriched DataFrames where
# specific gates pass at the LAST bar. They're intentionally narrow;
# each one exists for one test's purpose.
# ══════════════════════════════════════════════════════════════════════════════

def _forced_mr_panel(
    symbols: list[str], *, n_days: int = 400, seed_offset: int = 0,
) -> dict[str, pd.DataFrame]:
    """Panel where the LAST bar satisfies MR's gates
    (roc_5<-3, bbw_pctl<40). We achieve this by appending a 3%
    drop followed by a calm-BBW stretch."""
    panel = _synthetic_enriched_panel(
        symbols, n_days=n_days, seed=seed_offset,
    )
    # Mutate in-place: set the last bar's roc_5 and bbw_20_2s_pctl
    # directly to values that satisfy the MR gates. This is a
    # narrow hack for testing — we're not inventing a whole price
    # series; we only need the indicator columns to read correctly
    # when the strategy queries them.
    for sym, df in panel.items():
        df.loc[df.index[-1], "roc_5"] = -4.0
        df.loc[df.index[-1], "bbw_20_2s_pctl"] = 25.0
        df.loc[df.index[-1], "data_sufficient"] = True
        df.loc[df.index[-1], "mfi_14"] = 25.0   # oversold (pushes score up)
        df.loc[df.index[-1], "rsi_14"] = 30.0
        df.loc[df.index[-1], "mfi_slope_3"] = 1.5
        df.loc[df.index[-1], "vol_ratio_20"] = 1.6
    return panel


def _forced_pullback_panel(
    symbols: list[str], *, n_days: int = 400,
) -> dict[str, pd.DataFrame]:
    """Panel where the LAST bar satisfies PullbackUptrend's gates."""
    panel = _synthetic_enriched_panel(symbols, n_days=n_days, seed=7)
    for sym, df in panel.items():
        df.loc[df.index[-1], "above_sma_50"] = True
        df.loc[df.index[-1], "above_sma_200"] = True
        df.loc[df.index[-1], "adx_14"] = 25.0
        df.loc[df.index[-1], "pct_from_sma_20"] = -1.5
        df.loc[df.index[-1], "data_sufficient"] = True
    return panel


def _multi_fire_panel(
    symbols: list[str], *, n_days: int = 400,
) -> dict[str, pd.DataFrame]:
    """Panel where the LAST bar satisfies BOTH MR and Pullback gates.

    This is a diagnostic edge case — in practice, MR (oversold) and
    Pullback (small dip in uptrend) don't overlap often. But the
    scanner must handle it.
    """
    panel = _synthetic_enriched_panel(symbols, n_days=n_days, seed=11)
    for sym, df in panel.items():
        # MR gates
        df.loc[df.index[-1], "roc_5"] = -4.0
        df.loc[df.index[-1], "bbw_20_2s_pctl"] = 25.0
        # Pullback gates
        df.loc[df.index[-1], "above_sma_50"] = True
        df.loc[df.index[-1], "above_sma_200"] = True
        df.loc[df.index[-1], "adx_14"] = 25.0
        df.loc[df.index[-1], "pct_from_sma_20"] = -1.5
        df.loc[df.index[-1], "data_sufficient"] = True
    return panel


# ══════════════════════════════════════════════════════════════════════════════
# Phase 11 Turn C-1: scan_with_snapshot
# ══════════════════════════════════════════════════════════════════════════════

from nimbus_v3.scanner.engine import ScanSnapshot


def test_scan_with_snapshot_returns_scan_snapshot() -> None:
    """scan_with_snapshot returns a ScanSnapshot, not a bare list."""
    panel = _forced_mr_panel(["AAA"], n_days=400)
    scanner = _build_scanner(universe=_universe_of("AAA"))
    snap = scanner.scan_with_snapshot(
        enriched_panel=panel, asof_date=panel["AAA"].index[-1],
    )
    assert isinstance(snap, ScanSnapshot)


def test_scan_with_snapshot_results_match_scan() -> None:
    """snapshot.results equals scan() return (same sort, same entries)."""
    panel = _forced_mr_panel(["AAA", "BBB"], n_days=400)
    scanner = _build_scanner(universe=_universe_of("AAA", "BBB"))
    asof = panel["AAA"].index[-1]

    plain_results = scanner.scan(enriched_panel=panel, asof_date=asof)
    snap = scanner.scan_with_snapshot(enriched_panel=panel, asof_date=asof)

    assert len(snap.results) == len(plain_results)
    # Same symbols in same order.
    assert [r.symbol for r in snap.results] == [r.symbol for r in plain_results]
    # Same scores.
    assert [r.conviction.score for r in snap.results] == \
           [r.conviction.score for r in plain_results]


def test_scan_with_snapshot_captures_state_for_firing_symbols() -> None:
    """Symbols that fire at least one signal have their SignalState
    captured in snapshot.state_by_symbol."""
    panel = _forced_mr_panel(["AAA"], n_days=400)
    scanner = _build_scanner(universe=_universe_of("AAA"))
    snap = scanner.scan_with_snapshot(
        enriched_panel=panel, asof_date=panel["AAA"].index[-1],
    )
    assert "AAA" in snap.state_by_symbol
    state = snap.state_by_symbol["AAA"]
    # State is a real SignalState with populated fields.
    assert state.symbol == "AAA"
    assert state.close > 0


def test_scan_with_snapshot_captures_contexts_for_firing_symbols() -> None:
    """Symbols that fire at least one signal have their ContextBundle
    captured in snapshot.contexts_by_symbol."""
    panel = _forced_mr_panel(["AAA"], n_days=400)
    scanner = _build_scanner(universe=_universe_of("AAA"))
    snap = scanner.scan_with_snapshot(
        enriched_panel=panel, asof_date=panel["AAA"].index[-1],
    )
    assert "AAA" in snap.contexts_by_symbol
    ctx = snap.contexts_by_symbol["AAA"]
    assert ctx.symbol == "AAA"
    assert ctx.market is not None


def test_scan_with_snapshot_skips_non_firing_symbols() -> None:
    """Symbols that didn't fire are NOT captured in the snapshot dicts."""
    # Build a panel where AAA fires but BBB doesn't.
    firing = _forced_mr_panel(["AAA"], n_days=400)
    neutral = _synthetic_enriched_panel(["BBB"], n_days=400)
    panel = {**firing, **neutral}
    scanner = _build_scanner(universe=_universe_of("AAA", "BBB"))
    snap = scanner.scan_with_snapshot(
        enriched_panel=panel, asof_date=firing["AAA"].index[-1],
    )
    # AAA fired → captured.
    assert "AAA" in snap.state_by_symbol
    # BBB did not fire → not captured.
    assert "BBB" not in snap.state_by_symbol
    assert "BBB" not in snap.contexts_by_symbol


def test_scan_with_snapshot_preserves_enriched_panel_and_asof() -> None:
    """Snapshot carries through the panel reference + asof_date as-is
    so the Dashboard can use them for charting without re-fetching."""
    panel = _forced_mr_panel(["AAA"], n_days=400)
    scanner = _build_scanner(universe=_universe_of("AAA"))
    asof = panel["AAA"].index[-1]
    snap = scanner.scan_with_snapshot(enriched_panel=panel, asof_date=asof)
    assert snap.enriched_panel is panel      # same object, no copy
    assert snap.asof_date == asof


def test_scan_with_snapshot_empty_when_no_signals() -> None:
    """Scan with zero firing symbols → snapshot has empty results and
    empty per-symbol dicts."""
    panel = _synthetic_enriched_panel(["AAA"], n_days=400)
    scanner = _build_scanner(universe=_universe_of("AAA"))
    snap = scanner.scan_with_snapshot(
        enriched_panel=panel, asof_date=panel["AAA"].index[-1],
    )
    assert snap.results == []
    assert snap.state_by_symbol == {}
    assert snap.contexts_by_symbol == {}
