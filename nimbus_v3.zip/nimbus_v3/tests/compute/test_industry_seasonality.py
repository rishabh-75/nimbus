"""Tests for nimbus_v3.compute.industry_seasonality."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.industry_seasonality import (
    compute_industry_seasonality,
    IndustrySeasonality,
    SeasonalityGrid,
)


def _series_panel(n_members=6, years=4, strong_month=4, freq="B"):
    idx = pd.date_range("2021-06-01", periods=int(252 * years), freq=freq)
    rng = np.random.default_rng(0)
    panel, syms = {}, []
    for j in range(n_members):
        rets = rng.normal(0.0002, 0.01, len(idx))
        bump = np.array([0.004 if d.month == strong_month else 0.0
                         for d in idx])
        close = 100 * np.cumprod(1 + rets + bump)
        panel[f"S{j}"] = pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(idx), 1e6 * (j + 1))},
            index=idx)
        syms.append(f"S{j}")
    return panel, syms


def test_empty_grid_no_members():
    g = compute_industry_seasonality({}, {})
    assert not g.has_data
    assert g.rows == ()


def test_min_members_enforced():
    panel, syms = _series_panel(n_members=6)
    small = {"Small": syms[:3]}      # below MIN_MEMBERS=5
    big = {"Big": syms}
    assert compute_industry_seasonality(small, panel).rows == ()
    assert len(compute_industry_seasonality(big, panel).rows) == 1


def test_all_and_unknown_skipped():
    panel, syms = _series_panel()
    g = compute_industry_seasonality(
        {"ALL": syms, "Unknown": syms, "Real": syms}, panel)
    inds = [r.industry for r in g.rows]
    assert inds == ["Real"]


def test_twelve_months_per_row():
    panel, syms = _series_panel()
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    assert len(r.avg_returns) == 12
    assert len(r.hit_rates) == 12


def test_strong_month_is_highest():
    panel, syms = _series_panel(strong_month=4)    # April bump
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    avgs = [v for v in r.avg_returns]
    # April (index 3) should be the strongest month.
    assert np.nanargmax(avgs) == 3
    assert r.has_data


def test_insufficient_history_flagged():
    # ~1.5 years → below MIN_YEARS=3 → has_data False
    panel, syms = _series_panel(years=1)
    g = compute_industry_seasonality({"X": syms}, panel)
    assert g.rows
    assert g.rows[0].has_data is False


def test_populated_rows_sorted_first():
    panel_long, syms_long = _series_panel(years=4, strong_month=2)
    panel_short, syms_short = _series_panel(years=1, strong_month=2)
    # rename short syms to avoid key collision
    panel = dict(panel_long)
    short_map = {}
    for s in syms_short:
        panel[f"SH_{s}"] = panel_short[s]
        short_map[s] = f"SH_{s}"
    g = compute_industry_seasonality(
        {"HasData": syms_long, "NoData": [short_map[s] for s in syms_short]},
        panel)
    # industry with data should sort before the one without
    assert g.rows[0].industry == "HasData"
    assert g.rows[0].has_data


def test_std_returns_populated():
    panel, syms = _series_panel(years=4)
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    assert len(r.std_returns) == 12
    # at least the data months have a finite std (>=2 obs)
    finite = [s for s in r.std_returns if s == s]
    assert len(finite) >= 10


def test_outlier_month_has_high_dispersion():
    """A month whose mean is driven by one freak year should have a
    large std relative to a steadily-seasonal month."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    # consistent April every year vs one-freak-year September
    panel, syms = {}, []
    for j in range(6):
        rng = np.random.default_rng(j)
        rets = rng.normal(0.0002, 0.01, len(idx))
        april = np.array([0.003 if d.month == 4 else 0.0 for d in idx])
        sept_freak = np.array(
            [0.05 if (d.month == 9 and d.year == 2023) else 0.0 for d in idx])
        close = 100 * np.cumprod(1 + rets + april + sept_freak)
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(idx), 1e6)}, index=idx),
            f"S{j}")
        syms.append(f"S{j}")
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    # September (idx 8) freak year → higher dispersion than April (idx 3)
    assert r.std_returns[8] > r.std_returns[3]


def test_market_baseline_computed():
    panel, syms = _series_panel(n_members=6, years=4, strong_month=4)
    # two industries so the baseline is a real cross-industry mean
    panel2, syms2 = _series_panel(n_members=6, years=4, strong_month=4)
    panel.update({f"B_{k}": v for k, v in panel2.items()})
    g = compute_industry_seasonality(
        {"A": syms, "B": [f"B_{s}" for s in syms2]}, panel)
    assert len(g.market_baseline) == 12
    # April (idx 3) baseline should be clearly positive (both strong there)
    assert g.market_baseline[3] > 0


def test_relative_nets_out_market_pattern():
    """A market-wide bump applied to ALL industries should cancel in the
    relative (avg - baseline) read, while an industry-specific bump
    survives."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, mbi = {}, {}
    for gi, name in enumerate(["X", "Y", "Z"]):
        syms = []
        for j in range(6):
            rng = np.random.default_rng(gi * 7 + j)
            rets = rng.normal(0.0002, 0.008, len(idx))
            # market-wide April bump for everyone
            april = np.array([0.005 if d.month == 4 else 0.0 for d in idx])
            # X also gets a unique January bump
            jan = np.array([0.006 if (d.month == 1 and gi == 0) else 0.0
                            for d in idx])
            close = 100 * np.cumprod(1 + rets + april + jan)
            panel[f"{name}{j}"] = eng.enrich(pd.DataFrame(
                {"Open": close, "High": close * 1.01, "Low": close * 0.99,
                 "Close": close, "Volume": np.full(len(idx), 1e6)},
                index=idx), f"{name}{j}")
            syms.append(f"{name}{j}")
        mbi[name] = syms
    g = compute_industry_seasonality(mbi, panel)
    by = {r.industry: r for r in g.rows}
    # April relative for X ≈ 0 (everyone shared it); January relative for
    # X clearly positive (X-only bump).
    x_apr_rel = by["X"].avg_returns[3] - g.market_baseline[3]
    x_jan_rel = by["X"].avg_returns[0] - g.market_baseline[0]
    assert abs(x_apr_rel) < 2.0
    assert x_jan_rel > 3.0


def test_cell_contributions_basic():
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    panel, syms = _series_panel(n_members=6, years=4, strong_month=4)
    cc = compute_cell_contributions("X", 4, syms, panel)
    assert cc.has_data
    assert len(cc.members) == 6
    # weights sum ~1
    assert abs(sum(m.weight for m in cc.members) - 1.0) < 1e-6
    # magnitude contributions ~ sum to cell avg
    tot = sum(m.magnitude_contribution for m in cc.members
              if m.magnitude_contribution == m.magnitude_contribution)
    assert abs(tot - cc.cell_avg) < 1e-6


def test_cell_contributions_outlier_drags_reliability():
    """A high-weight erratic member should have negative reliability
    impact even if its magnitude contribution is sizable."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, syms = {}, []
    for j in range(5):
        rng = np.random.default_rng(j)
        rets = rng.normal(0.0002, 0.008, len(idx))
        if j == 0:    # erratic: huge April only one year, big weight
            apr = np.array([0.05 if (d.month == 4 and d.year == 2023)
                            else 0.0 for d in idx])
            vol = 5e6
        else:
            apr = np.array([0.003 if d.month == 4 else 0.0 for d in idx])
            vol = 1e6
        close = 100 * np.cumprod(1 + rets + apr)
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(idx), vol)}, index=idx),
            f"S{j}")
        syms.append(f"S{j}")
    cc = compute_cell_contributions("X", 4, syms, panel)
    by = {m.symbol: m for m in cc.members}
    # S0 is the erratic high-weight member → negative reliability impact
    assert by["S0"].reliability_impact < 0
    # a steady member should have higher reliability impact than S0
    steady = max(cc.members, key=lambda m: m.reliability_impact)
    assert steady.symbol != "S0"


def test_cell_contributions_empty_for_no_members():
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    cc = compute_cell_contributions("X", 1, [], {})
    assert not cc.has_data


def test_member_remark_branches():
    from nimbus_v3.compute.industry_seasonality import _member_remark
    nan = float("nan")
    assert "single year" in _member_remark(
        avg=29.0, std=nan, hit=100, weight=0.1, mag=3.0,
        rel_impact=nan, n_years=1)
    assert "2 yrs" in _member_remark(
        avg=10.0, std=5.0, hit=100, weight=0.1, mag=1.0,
        rel_impact=0.05, n_years=2)
    assert "destabilis" in _member_remark(
        avg=5.0, std=15.0, hit=60, weight=0.28, mag=1.4,
        rel_impact=-0.15, n_years=5)
    assert "steady" in _member_remark(
        avg=22.6, std=6.9, hit=100, weight=0.13, mag=3.08,
        rel_impact=0.14, n_years=5)
    assert "lumpy" in _member_remark(
        avg=9.0, std=18.0, hit=80, weight=0.10, mag=0.9,
        rel_impact=0.05, n_years=5)


def test_contribution_includes_remark():
    panel, syms = _series_panel(n_members=6, years=4, strong_month=4)
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    cc = compute_cell_contributions("X", 4, syms, panel)
    assert all(isinstance(m.remark, str) for m in cc.members)


def test_remark_negative_consistency_is_not_reassuring():
    """A tightly-clustered NEGATIVE return must be flagged as a reliable
    drag, never as a reassuring 'consistent' positive."""
    from nimbus_v3.compute.industry_seasonality import _member_remark
    # tight, negative, never positive across years → reliably weak
    r = _member_remark(avg=-11.5, std=2.2, hit=0, weight=0.14, mag=-1.56,
                       rel_impact=0.14, n_years=5)
    assert "reliably weak" in r or "negative" in r
    assert "dependable" not in r and "gain" not in r
    # tight, positive → a good label
    r2 = _member_remark(avg=11.5, std=2.2, hit=100, weight=0.14, mag=1.56,
                        rel_impact=0.14, n_years=5)
    assert "dependable" in r2 or "gain" in r2


def test_remark_color_negative_not_green():
    from nimbus_v3.ui.widgets.seasonality_heatmap import _remark_color
    from nimbus_v3.ui.theme import GREEN
    assert _remark_color("reliably weak — steady drag") != GREEN
    assert _remark_color("consistently negative") != GREEN
    assert _remark_color("steady & dependable") == GREEN


def test_remark_recognises_anchor_and_dependable():
    """The dominant healthy driver and up-every-year names must NOT be
    blank — that was the gap where good constituents got no remark."""
    from nimbus_v3.compute.industry_seasonality import _member_remark
    # anchor: dominant weight, positive, steadies the cell
    anchor = _member_remark(avg=5.0, std=3.8, hit=80, weight=0.70,
                            mag=3.52, rel_impact=0.24, n_years=5)
    assert "anchor" in anchor
    # up every year: perfect hit, positive, moderate dispersion
    dep = _member_remark(avg=10.4, std=8.7, hit=100, weight=0.25,
                         mag=2.61, rel_impact=0.05, n_years=5)
    assert "up every year" in dep or "dependable" in dep
    # genuine middle: positive, moderate, not blank
    mid = _member_remark(avg=6.0, std=5.7, hit=60, weight=0.087,
                         mag=0.52, rel_impact=0.0, n_years=5)
    assert mid != ""


def test_remark_good_cases_coloured_green():
    from nimbus_v3.ui.widgets.seasonality_heatmap import _remark_color
    from nimbus_v3.ui.theme import GREEN
    assert _remark_color("anchor — drives & steadies") == GREEN
    assert _remark_color("up every year — dependable") == GREEN
    assert _remark_color("solid — moderate swing") == GREEN


def test_contribution_table_has_ratio_column():
    from nimbus_v3.ui.widgets.seasonality_heatmap import _ContributionTable
    assert "σ/avg" in _ContributionTable._COLS
