"""Regression tests: no computation may use data from the future.

Two distinct leaks are pinned here.

1. CENTERED SMOOTHING (industry_rotation). A ``center=True`` rolling mean
   is lookahead by construction: with window=3 the value plotted for day t
   averaged days t-1, t and t+1, so every interior point on the rotation
   chart was moved by a bar that had not happened yet. The ranking value
   escaped — it is the LAST point, computed from the available past only —
   but that also made it a 2-bar mean where interior points were 3-bar, so
   the leaderboard number and the line end were not the same quantity.

2. INCOMPLETE CURRENT MONTH (seasonality). ``resample("ME")`` labels each
   bucket with its month END, so a series ending 3 July yields a row
   labelled 31 July holding a three-day return — indistinguishable
   downstream from a complete July. It added a phantom observation to
   July's sample and pulled July's mean and reliability with it.

The general property both share: a value computed for date t must depend
only on data at or before t, and a period must be complete before it
counts as an observation.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.industry_rotation import (
    SMOOTH_WINDOW,
    compute_industry_rotation,
)
from nimbus_v3.compute.seasonality import _monthly_returns


# ── 1. rotation smoothing must be causal ────────────────────────────────
def _panel_with_late_spike(n_bars=120, spike_at=-2, spike=1.25):
    """Flat members except a jump near the very end of ONE symbol.

    A causal filter cannot let that jump affect any earlier point.
    """
    dates = pd.bdate_range("2025-01-01", periods=n_bars)
    panel, members = {}, {"Flat": [], "Spiky": []}
    for k in range(6):          # MIN_MEMBERS is 5

        c = np.full(n_bars, 100.0)
        panel[f"F{k}"] = pd.DataFrame(
            {"Close": c, "Volume": np.full(n_bars, 5e5)}, index=dates)
        members["Flat"].append(f"F{k}")
    for k in range(6):
        c = np.full(n_bars, 100.0)
        c[spike_at:] *= spike
        panel[f"S{k}"] = pd.DataFrame(
            {"Close": c, "Volume": np.full(n_bars, 5e5)}, index=dates)
        members["Spiky"].append(f"S{k}")
    return panel, members


def test_rotation_smoothing_does_not_look_ahead():
    """A jump on day t must not move the line before day t.

    With the old centered window the point at t-1 was already lifted by
    the day-t bar — a chart the operator could not have seen at the time.
    """
    panel, members = _panel_with_late_spike()
    res = compute_industry_rotation(members, panel, lookback=60)
    spiky = next(r for r in res.industries if r.industry == "Spiky")
    series = np.asarray(spiky.cum_return, dtype=float)

    # The spike enters at index -2. Everything strictly before it must be
    # unchanged from the flat baseline.
    pre = series[:-2]
    assert np.allclose(pre, pre[0], atol=1e-9), (
        "values before the jump moved — smoothing is reading the future")


def test_rotation_last_point_uses_full_window():
    """The ranking value and the line end must be the same quantity.

    Under the centered window the last point was a partial (2-bar) mean
    while interior points were 3-bar. Trailing makes every point — the
    last one included — a mean of the same number of bars.
    """
    n = 80
    dates = pd.bdate_range("2025-01-01", periods=n)
    panel, members = {}, {"Ramp": []}
    for k in range(6):          # MIN_MEMBERS is 5
        c = np.linspace(100.0, 140.0, n)          # strictly increasing
        panel[f"R{k}"] = pd.DataFrame(
            {"Close": c, "Volume": np.full(n, 5e5)}, index=dates)
        members["Ramp"].append(f"R{k}")

    res = compute_industry_rotation(members, panel, lookback=60)
    ramp = next(r for r in res.industries if r.industry == "Ramp")
    series = np.asarray(ramp.cum_return, dtype=float)

    # On a linear ramp a trailing k-bar mean sits exactly (k-1)/2 bars
    # behind the raw value; the gap between consecutive smoothed points is
    # therefore constant right to the end. A short final window would show
    # up as a different last step.
    steps = np.diff(series[-6:])
    assert np.allclose(steps, steps[0], atol=1e-9), (
        f"final step differs — last point uses a shorter window: {steps}")
    assert ramp.roc == series[-1], "roc must be the smoothed line end"


def test_smoothing_window_is_causal_by_construction():
    """Guard the parameter itself, so a future edit cannot silently
    reintroduce centering without this file failing."""
    import inspect

    from nimbus_v3.compute import industry_rotation as mod
    src = inspect.getsource(mod)
    assert "center=True" not in src, (
        "centered rolling reintroduced — that is lookahead")
    assert SMOOTH_WINDOW >= 1


# ── 2. seasonality must not count an unfinished month ───────────────────
def test_incomplete_current_month_excluded():
    idx = pd.bdate_range("2023-01-02", "2026-07-03")   # July barely started
    close = pd.Series(np.linspace(100, 200, len(idx)), index=idx)
    julys = [d for d in _monthly_returns(close).index if d.month == 7]
    assert len(julys) == 3, (
        f"expected 3 complete Julys, got {len(julys)} — an unfinished "
        f"month is being counted as an observation")
    assert max(d.year for d in julys) == 2025


def test_complete_final_month_is_kept():
    """The guard must only drop a month that genuinely has not ended —
    dropping a complete one would throw away real evidence."""
    idx = pd.bdate_range("2023-01-02", "2026-07-31")
    close = pd.Series(np.linspace(100, 200, len(idx)), index=idx)
    julys = [d for d in _monthly_returns(close).index if d.month == 7]
    assert len(julys) == 4
    assert max(d.year for d in julys) == 2026


def test_partial_month_does_not_move_the_mean():
    """The concrete harm: a 3-day return dragging a month's average."""
    full = pd.bdate_range("2021-01-04", "2025-12-31")
    close_full = pd.Series(
        100 * np.exp(np.cumsum(np.full(len(full), 0.0004))), index=full)
    ref = _monthly_returns(close_full)
    ref_july = float(np.mean([v for d, v in ref.items() if d.month == 7]))

    # Same history, then three flat days into January.
    ext = pd.bdate_range("2021-01-04", "2026-01-05")
    close_ext = close_full.reindex(ext).ffill()
    got = _monthly_returns(close_ext)
    got_july = float(np.mean([v for d, v in got.items() if d.month == 7]))

    assert got_july == ref_july, (
        "July's mean changed when an unfinished January was appended")
    assert not any(d.year == 2026 for d in got.index), (
        "the unfinished January leaked into the monthly sample")


def test_empty_series_is_safe():
    assert _monthly_returns(pd.Series(dtype=float)).empty
