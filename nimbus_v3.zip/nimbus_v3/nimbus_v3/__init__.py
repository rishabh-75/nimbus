"""nimbus_v3 — unified trading terminal for NSE.

This package intentionally exports nothing from its root. Consumers
import specific subpackages explicitly:

    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.compute.ride_initiation import RideEngine, RidePhase
    from nimbus_v3.data.price_loader import PriceLoader
    from nimbus_v3.data.options_loader import OptionsLoader
    from nimbus_v3.data.industry_db import load_industry_db
    from nimbus_v3.ui.main_window import MainWindow

See ``docs/ARCHITECTURE.md`` for the layered design.
"""

__version__ = "0.2.0a0"
