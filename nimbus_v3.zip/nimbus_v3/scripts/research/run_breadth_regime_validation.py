"""run_breadth_regime_validation.py — does the market-breadth regime at
entry predict whether a ride sustains?

Research question
-----------------
Thesis: rides fired when the broad market is *confirming* (price up +
breadth expanding + A/D confirming + new-high/low positive) sustain more
often than rides fired when it isn't. If true, the breadth regime earns
a place as an entry gate ("only take rides in a confirming tape"). If
not — as happened with VIX regime — we don't gate on it.

This is a VALIDATION, not a display feature. It does not modify the live
scorer. It joins a daily breadth-regime state onto each historical ride
event (by trigger date) and compares ride outcomes across regimes.

Method
------
1. Load the equity panel from the cache (load_equity_panel).
2. compute_breadth(panel) → daily breadth series.
3. Build a daily regime state from breadth (+ optional CNX500 trend),
   under TWO definitions so we can see which discriminates better:
     - COUNT : how many of 5 signals are "on" → RISK_ON (4-5) /
               NEUTRAL (2-3) / RISK_OFF (0-1)
     - STRICT: RISK_ON only if ALL of {price>SMA50, %>50, %rising,
               A/D rising, NH-NL>0}; else RISK_OFF.
4. Load the labelled events (events.parquet) — resolved, dated, with
   return_pct + hold_bars.
5. Join regime onto each event by trigger_date; report, per regime:
   n, win-rate (held >= phase-median hold), mean/median return_pct.
6. Print a verdict: does RISK_ON beat RISK_OFF by a margin that would
   justify gating, for either definition?

Usage
-----
    python -m scripts.research.run_breadth_regime_validation \
        --cache-dir /path/to/cache/equity_price \
        --symbols-from-cache \
        --events /path/to/events.parquet \
        [--index-csv /path/to/cnx500.csv]   # optional CNX500 Close

The --index-csv (date,Close) lets the price-trend signal participate;
omit it and the regime is built from the 4 breadth signals only.
"""
from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np
import pandas as pd

from nimbus_v3.compute.market_breadth import compute_breadth
from nimbus_v3.research.equity_universe import DEFAULT_SYMBOLS, load_equity_panel

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("breadth_regime")

#: Lookback (trading days) for the "expanding / rising" slope signals.
_SLOPE_LOOKBACK = 10


# ── regime construction ───────────────────────────────────────────────────────

def _rising(s: pd.Series, lookback: int) -> pd.Series:
    """Boolean: value today greater than `lookback` bars ago."""
    return s > s.shift(lookback)


def build_regime(
    breadth: pd.DataFrame, index_close: pd.Series | None,
) -> pd.DataFrame:
    """Return a frame indexed by date with the 5 signals + two regime
    labels (`regime_count`, `regime_strict`)."""
    df = breadth.copy()

    # Signal 1 — price trend: CNX500 above its own SMA50. Optional.
    if index_close is not None and not index_close.empty:
        idx = index_close.reindex(df.index).ffill()
        idx_sma50 = idx.rolling(50, min_periods=50).mean()
        sig_price = (idx > idx_sma50)
    else:
        sig_price = pd.Series(False, index=df.index)
        log.info("no index series — price-trend signal disabled "
                 "(regime built from 4 breadth signals)")

    # Signals 2-5 — breadth.
    sig_level = df["pct_above_sma50"] > 50.0
    sig_expand = _rising(df["pct_above_sma50"], _SLOPE_LOOKBACK)
    sig_ad = _rising(df["ad_line"], _SLOPE_LOOKBACK)
    sig_nhnl = df["nh_nl_diff"] > 0

    have_price = (index_close is not None and not index_close.empty)
    signals = [sig_level, sig_expand, sig_ad, sig_nhnl]
    if have_price:
        signals = [sig_price] + signals
    n_sig = len(signals)

    on_count = sum(s.astype(int) for s in signals)
    df["signals_on"] = on_count
    df["n_signals"] = n_sig

    # COUNT regime — proportional buckets so it works for 4 or 5 signals.
    hi = n_sig - 1          # 4/5 (or 3/4) → RISK_ON
    lo = 1                  # 0-1 → RISK_OFF
    df["regime_count"] = np.where(
        on_count >= hi, "RISK_ON",
        np.where(on_count <= lo, "RISK_OFF", "NEUTRAL"),
    )
    # STRICT regime — every signal must be on.
    df["regime_strict"] = np.where(on_count == n_sig, "RISK_ON", "RISK_OFF")
    return df


# ── events join + analysis ─────────────────────────────────────────────────────

def _build_events_from_panel(panel: dict) -> pd.DataFrame:
    """Build labelled fire events inline from the same panel breadth is
    computed over — so events and regime share one universe (no separate
    events.parquet, and no universe mismatch). Mirrors the MFI script's
    inline replay.
    """
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.compute.ride_initiation import RideEngine
    from nimbus_v3.research.phase_p_win.extract import extract_fire_events

    engine = StrategyComputeEngine()
    ride = RideEngine()
    rows: list[dict] = []
    for sym, raw in panel.items():
        try:
            enr = engine.enrich(raw, sym)
            res = ride.classify(enr)
            events = extract_fire_events(sym, enr, res)
        except Exception:    # noqa: BLE001
            log.exception("event build failed for %s", sym)
            continue
        for ev in events:
            rows.append({
                "symbol": ev.symbol, "phase": ev.phase,
                "trigger_date": ev.trigger_date,
                "hold_bars": ev.hold_bars, "return_pct": ev.return_pct,
                "is_resolved": ev.is_resolved,
            })
    df = pd.DataFrame(rows)
    log.info("built %d events inline across %d symbols",
             len(df), df["symbol"].nunique() if len(df) else 0)
    return df


def _load_index_csv(path: Path) -> pd.Series | None:
    try:
        idx = pd.read_csv(path)
        date_col = next(c for c in idx.columns if c.lower() in ("date", "datetime"))
        close_col = next(c for c in idx.columns if c.lower() == "close")
        s = pd.Series(idx[close_col].to_numpy(dtype=float),
                      index=pd.to_datetime(idx[date_col]))
        return s.sort_index()
    except Exception:    # noqa: BLE001
        log.exception("could not read --index-csv at %s", path)
        return None


def _regime_outcome_table(ev: pd.DataFrame, regime_col: str) -> pd.DataFrame:
    # win = held at least the phase-median hold (continued well)
    med = ev.groupby("phase")["hold_bars"].transform("median")
    ev = ev.assign(win=(ev["hold_bars"] >= med).astype(int))
    g = ev.groupby(regime_col)
    return pd.DataFrame({
        "n": g.size(),
        "win_rate": g["win"].mean(),
        "mean_return": g["return_pct"].mean(),
        "median_return": g["return_pct"].median(),
    }).reindex(["RISK_ON", "NEUTRAL", "RISK_OFF"]).dropna(how="all")


def analyse(ev: pd.DataFrame, regime: pd.DataFrame) -> None:
    # Join regime onto events by date.
    regime_by_date = regime[["regime_count", "regime_strict",
                             "signals_on", "n_signals"]].copy()
    regime_by_date.index = pd.to_datetime(regime_by_date.index).normalize()
    ev = ev.copy()
    ev["d"] = pd.to_datetime(ev["trigger_date"]).dt.normalize()
    ev = ev.merge(regime_by_date, left_on="d", right_index=True, how="inner")
    ev = ev[ev["is_resolved"] & ev["return_pct"].notna()
            & ev["hold_bars"].notna()]
    log.info("joined %d resolved events onto regime dates", len(ev))
    if len(ev) < 100:
        log.warning("few joined events (%d) — date overlap between the "
                    "cache-derived regime and events may be small", len(ev))

    overall_win = (ev["hold_bars"] >= ev.groupby("phase")["hold_bars"]
                   .transform("median")).mean()
    print("\n" + "=" * 68)
    print(f"BREADTH-REGIME VALIDATION — {len(ev)} resolved events")
    print(f"baseline win-rate (held >= phase-median): {overall_win:.3f}")
    print("=" * 68)

    for col, label in [("regime_count", "COUNT (4-5/2-3/0-1)"),
                       ("regime_strict", "STRICT (all signals on)")]:
        print(f"\n── {label} ──")
        tbl = _regime_outcome_table(ev, col)
        print(f"{'regime':<10}{'n':>7}{'win_rate':>11}{'mean_ret%':>11}{'med_ret%':>10}")
        for reg, r in tbl.iterrows():
            print(f"{reg:<10}{int(r['n']):>7}{r['win_rate']:>11.3f}"
                  f"{r['mean_return']:>11.2f}{r['median_return']:>10.2f}")
        if {"RISK_ON", "RISK_OFF"}.issubset(tbl.index):
            d_win = tbl.loc["RISK_ON", "win_rate"] - tbl.loc["RISK_OFF", "win_rate"]
            d_ret = tbl.loc["RISK_ON", "mean_return"] - tbl.loc["RISK_OFF", "mean_return"]
            print(f"  RISK_ON − RISK_OFF: win {d_win:+.3f}, mean_ret {d_ret:+.2f}pp")
            verdict = (
                "regime DISCRIMINATES — gating on it is justified"
                if (d_win >= 0.03 or d_ret >= 0.5)
                else "regime does NOT meaningfully discriminate — don't gate"
            )
            print(f"  VERDICT [{label}]: {verdict}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cache-dir", type=str, default="")
    ap.add_argument("--symbols", type=str, default="")
    ap.add_argument("--symbols-from-cache", action="store_true")
    ap.add_argument("--events", type=str, default="",
                    help="Optional path to a pre-built events.parquet "
                         "(resolved, dated). If omitted, events are built "
                         "inline from --cache-dir — recommended, since it "
                         "guarantees events and breadth share one universe.")
    ap.add_argument("--index-csv", type=str, default="",
                    help="Optional CNX500 Close CSV (date,Close).")
    args = ap.parse_args()

    cache_dir = Path(args.cache_dir).expanduser() if args.cache_dir else None
    if args.symbols:
        symbols = tuple(s.strip().upper() for s in args.symbols.split(",") if s.strip())
    elif args.symbols_from_cache and cache_dir is not None:
        symbols = tuple(sorted(p.stem for p in cache_dir.glob("*.parquet")))
    else:
        symbols = DEFAULT_SYMBOLS
    if not symbols:
        log.error("no symbols resolved — check --cache-dir / --symbols")
        return 1
    log.info("computing breadth over %d symbols", len(symbols))

    panel = load_equity_panel(symbols=symbols, cache_dir=cache_dir)
    breadth = compute_breadth(panel)
    if breadth.empty:
        log.error("empty breadth — check the cache")
        return 1

    index_close = (_load_index_csv(Path(args.index_csv).expanduser())
                   if args.index_csv else None)
    regime = build_regime(breadth, index_close)

    if args.events:
        ev = pd.read_parquet(args.events)
        log.info("loaded %d events from %s", len(ev), args.events)
    else:
        ev = _build_events_from_panel(panel)
    if ev.empty:
        log.error("no events — check the cache / --events")
        return 1
    analyse(ev, regime)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
