"""tests.compute.test_correlation_regime — classifier unit tests."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.correlation_regime import (
    CORR_WINDOW,
    CorrelationRegimeClassifier,
    CorrelationRegimeState,
    HIGH_PCTILE,
    LOW_PCTILE,
    MIN_INDUSTRIES,
    PCTILE_WINDOW,
    REGIME_HIGH,
    REGIME_LOW,
    REGIME_NORMAL,
    REGIME_UNKNOWN,
    schema_hash,
)


def _synthetic_panel(
    n_industries: int,
    n_bars: int,
    common_factor_weight: float,
    seed: int,
) -> pd.DataFrame:
    """Build N industries' return series. ``common_factor_weight``=1
    means everyone moves together (corr ≈ 1); 0 means independent
    (corr ≈ 0)."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2020-01-01", periods=n_bars)
    common = rng.normal(0, 0.01, n_bars)
    cols = {}
    for i in range(n_industries):
        idiosync = rng.normal(0, 0.01, n_bars)
        rets = (
            common_factor_weight * common
            + (1 - common_factor_weight) * idiosync
        )
        cols[f"IND{i}"] = pd.Series(rets, index=idx)
    return pd.DataFrame(cols)


# ══════════════════════════════════════════════════════════════════════
# Regime classification
# ══════════════════════════════════════════════════════════════════════

class TestRegimeClassification:

    def test_high_common_factor_in_recent_bars_classifies_high(self):
        """Build a panel where the trailing 252 bars have moderate
        correlation, then the latest 60-day window shifts to high
        correlation. The latest bar should classify as HIGH."""
        # Need at least CORR_WINDOW + PCTILE_WINDOW + 1 bars to
        # produce a non-UNKNOWN classification.
        n_total = CORR_WINDOW + PCTILE_WINDOW + 30
        # First half: low correlation regime
        low_part = _synthetic_panel(
            n_industries=15, n_bars=n_total - 60,
            common_factor_weight=0.2, seed=1,
        )
        # Last 60 bars: very high correlation
        high_part = _synthetic_panel(
            n_industries=15, n_bars=60,
            common_factor_weight=0.95, seed=2,
        )
        # Concatenate (need consistent column names)
        high_part.columns = low_part.columns
        idx_high = pd.bdate_range(
            low_part.index[-1] + pd.Timedelta(days=1), periods=60,
        )
        high_part.index = idx_high
        panel = pd.concat([low_part, high_part])

        state = CorrelationRegimeClassifier().classify_current(panel)
        assert state.regime == REGIME_HIGH, (
            f"Expected HIGH, got {state.regime} "
            f"(corr={state.mean_correlation:.3f}, pct={state.pctile:.2f})"
        )

    def test_low_correlation_in_recent_bars_classifies_low(self):
        n_total = CORR_WINDOW + PCTILE_WINDOW + 30
        high_part = _synthetic_panel(
            n_industries=15, n_bars=n_total - 60,
            common_factor_weight=0.7, seed=3,
        )
        low_part = _synthetic_panel(
            n_industries=15, n_bars=60,
            common_factor_weight=0.0, seed=4,
        )
        low_part.columns = high_part.columns
        idx_low = pd.bdate_range(
            high_part.index[-1] + pd.Timedelta(days=1), periods=60,
        )
        low_part.index = idx_low
        panel = pd.concat([high_part, low_part])

        state = CorrelationRegimeClassifier().classify_current(panel)
        assert state.regime == REGIME_LOW

    def test_steady_correlation_in_middle_quintiles_classifies_normal(self):
        """Constant-regime panel — the latest correlation reading
        should sit near the median of the trailing distribution and
        classify NORMAL."""
        n_total = CORR_WINDOW + PCTILE_WINDOW + 60
        panel = _synthetic_panel(
            n_industries=15, n_bars=n_total,
            common_factor_weight=0.5, seed=5,
        )
        state = CorrelationRegimeClassifier().classify_current(panel)
        # In a steady regime the latest reading is approximately a
        # random draw from the trailing distribution, so percentile
        # is roughly uniform on [0, 1]. Most seeds will land in
        # NORMAL but some near boundaries land HIGH/LOW. Run 5 seeds
        # and assert majority NORMAL.
        regimes = []
        for seed in (5, 6, 7, 8, 9):
            p = _synthetic_panel(
                n_industries=15, n_bars=n_total,
                common_factor_weight=0.5, seed=seed,
            )
            regimes.append(
                CorrelationRegimeClassifier().classify_current(p).regime
            )
        n_normal = sum(1 for r in regimes if r == REGIME_NORMAL)
        assert n_normal >= 3, (
            f"Expected majority NORMAL, got {regimes}"
        )


# ══════════════════════════════════════════════════════════════════════
# Edge cases
# ══════════════════════════════════════════════════════════════════════

class TestEdgeCases:

    def test_short_panel_returns_unknown(self):
        """Panel shorter than CORR_WINDOW — UNKNOWN."""
        panel = _synthetic_panel(
            n_industries=15, n_bars=30,    # < CORR_WINDOW=60
            common_factor_weight=0.5, seed=10,
        )
        state = CorrelationRegimeClassifier().classify_current(panel)
        assert state.regime == REGIME_UNKNOWN

    def test_warmup_period_returns_unknown(self):
        """Long enough for correlation but not enough trailing
        history for percentile-rank — UNKNOWN."""
        n_total = CORR_WINDOW + 50    # has correlation, no full pctile window
        panel = _synthetic_panel(
            n_industries=15, n_bars=n_total,
            common_factor_weight=0.5, seed=11,
        )
        state = CorrelationRegimeClassifier().classify_current(panel)
        assert state.regime == REGIME_UNKNOWN

    def test_thin_panel_returns_unknown(self):
        """Fewer than MIN_INDUSTRIES columns — can't form a
        correlation matrix, UNKNOWN."""
        n_total = CORR_WINDOW + PCTILE_WINDOW + 30
        panel = _synthetic_panel(
            n_industries=MIN_INDUSTRIES - 2, n_bars=n_total,
            common_factor_weight=0.5, seed=12,
        )
        state = CorrelationRegimeClassifier().classify_current(panel)
        assert state.regime == REGIME_UNKNOWN

    def test_state_carries_diagnostic_fields(self):
        """The state dataclass exposes mean_correlation, pctile,
        n_industries — used by tooltip rendering."""
        n_total = CORR_WINDOW + PCTILE_WINDOW + 30
        panel = _synthetic_panel(
            n_industries=15, n_bars=n_total,
            common_factor_weight=0.5, seed=13,
        )
        state = CorrelationRegimeClassifier().classify_current(panel)
        assert isinstance(state.mean_correlation, float)
        assert isinstance(state.pctile, float)
        assert state.n_industries == 15


# ══════════════════════════════════════════════════════════════════════
# Dataclass + schema hash
# ══════════════════════════════════════════════════════════════════════

class TestStateAndHash:

    def test_state_is_frozen(self):
        s = CorrelationRegimeState(
            regime=REGIME_HIGH, mean_correlation=0.65,
            pctile=0.85, n_industries=15,
        )
        with pytest.raises((AttributeError, Exception)):
            s.regime = REGIME_LOW

    def test_schema_hash_is_deterministic(self):
        h1 = schema_hash()
        h2 = schema_hash()
        assert h1 == h2

    def test_schema_hash_is_short(self):
        h = schema_hash()
        assert len(h) == 8
