"""Tests for scripts/run_vix_pace_research.py.

Tests the pure classification logic plus an end-to-end smoke test of
the reporting pipeline using synthetic data. The real script can only
be run on a machine with yfinance access + a populated VIX cache; this
test harness lets us verify the transformation pipeline is correct in
isolation.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(_ROOT / "scripts"))

from run_vix_pace_research import (                                   # noqa: E402
    _Z_CUT,
    _Z_WIN,
    _SLOPE_WIN,
    classify_vix_pace,
    report_regime_distribution,
    report_industry_regime_grid,
)


# ══════════════════════════════════════════════════════════════════════
# Unit: classify_vix_pace
# ══════════════════════════════════════════════════════════════════════

class TestClassifyVixPace:

    def test_output_has_expected_columns(self):
        vix = pd.Series(
            np.full(400, 15.0),
            index=pd.bdate_range("2022-01-01", periods=400),
        )
        out = classify_vix_pace(vix)
        assert set(out.columns) == {"vix", "slope", "z", "regime"}

    def test_labels_only_in_known_set(self):
        rng = np.random.default_rng(0)
        vix = pd.Series(
            16 + rng.normal(0, 1, 400).cumsum() * 0.05,
            index=pd.bdate_range("2022-01-01", periods=400),
        )
        out = classify_vix_pace(vix)
        labels = set(out["regime"].unique())
        assert labels.issubset({"RISING", "FALLING", "STABLE", "UNKNOWN"})

    def test_baseline_warmup_is_unknown(self):
        """The first _SLOPE_WIN + _Z_WIN bars should all be UNKNOWN —
        the baseline z-score has no history to normalize against."""
        vix = pd.Series(
            np.full(400, 15.0),
            index=pd.bdate_range("2022-01-01", periods=400),
        )
        out = classify_vix_pace(vix)
        required_warmup = _SLOPE_WIN + _Z_WIN
        # All bars before warmup are UNKNOWN (z is NaN)
        assert (out["regime"].iloc[:required_warmup] == "UNKNOWN").all()

    def test_sustained_rise_is_classified_rising(self):
        """A synthetic series that flatlines then rises monotonically
        should be labeled RISING during the rise, after warmup."""
        rng = np.random.default_rng(42)
        # 300 flat days (noise only), then 100 days of rising from 16→30
        flat = 16 + rng.normal(0, 0.3, 300)
        rise = np.linspace(16, 30, 100) + rng.normal(0, 0.3, 100)
        vix = pd.Series(
            np.concatenate([flat, rise]),
            index=pd.bdate_range("2020-01-01", periods=400),
        )
        out = classify_vix_pace(vix)
        # During the rise period, the majority of labels should be RISING
        rise_labels = out["regime"].iloc[300:]
        rising_frac = (rise_labels == "RISING").sum() / len(rise_labels)
        assert rising_frac > 0.8, (
            f"Expected >80% RISING during rise, got {rising_frac:.0%}. "
            f"Counts: {rise_labels.value_counts().to_dict()}"
        )

    def test_sustained_fall_is_classified_falling(self):
        """Symmetric: sustained decline should yield majority FALLING."""
        rng = np.random.default_rng(42)
        flat = 30 + rng.normal(0, 0.3, 300)
        fall = np.linspace(30, 15, 100) + rng.normal(0, 0.3, 100)
        vix = pd.Series(
            np.concatenate([flat, fall]),
            index=pd.bdate_range("2020-01-01", periods=400),
        )
        out = classify_vix_pace(vix)
        fall_labels = out["regime"].iloc[300:]
        falling_frac = (fall_labels == "FALLING").sum() / len(fall_labels)
        assert falling_frac > 0.8

    def test_flat_after_warmup_is_stable(self):
        """Post-warmup flat noise should be mostly STABLE."""
        rng = np.random.default_rng(42)
        vix = pd.Series(
            16 + rng.normal(0, 0.3, 400),
            index=pd.bdate_range("2020-01-01", periods=400),
        )
        out = classify_vix_pace(vix)
        post_warmup = out["regime"].iloc[_SLOPE_WIN + _Z_WIN:]
        stable_frac = (post_warmup == "STABLE").sum() / len(post_warmup)
        assert stable_frac > 0.6

    def test_indexed_aligns_with_input(self):
        """Output index must match input exactly — no date loss."""
        idx = pd.bdate_range("2022-01-01", periods=400)
        vix = pd.Series(np.full(400, 15.0), index=idx)
        out = classify_vix_pace(vix)
        assert (out.index == idx).all()

    def test_threshold_parameters_respected(self):
        """The classifier splits on z > +_Z_CUT and z < -_Z_CUT. If we
        artificially construct a series where z is well above the cut,
        the label should be RISING, not STABLE."""
        # Construct VIX where we can predict the exact z at the last bar:
        # a long flat prefix then a sharp rise over exactly 20 days.
        n = 400
        prefix = np.full(n - 20, 15.0)
        spike = np.linspace(15.0, 35.0, 20)    # +1/day = strong rise
        vix = pd.Series(
            np.concatenate([prefix, spike]),
            index=pd.bdate_range("2020-01-01", periods=n),
        )
        out = classify_vix_pace(vix)
        # Last bar's regime should be RISING
        assert out["regime"].iloc[-1] == "RISING"


class TestMultiWindow:
    """The classifier accepts a slope_win kwarg so the orchestrator
    can run the same pipeline at 5d / 10d / 20d / 60d."""

    def test_classifier_accepts_slope_win_kwarg(self):
        """Passing slope_win=5 should produce a different slope series
        than the default 20, demonstrating the parameter flows through."""
        rng = np.random.default_rng(13)
        vix = pd.Series(
            16 + rng.normal(0, 1, 500).cumsum() * 0.05,
            index=pd.bdate_range("2020-01-01", periods=500),
        )
        out_5 = classify_vix_pace(vix, slope_win=5)
        out_20 = classify_vix_pace(vix, slope_win=20)
        # The slope column values must differ across windows
        assert not out_5["slope"].equals(out_20["slope"])

    def test_classifier_default_matches_20d(self):
        """The default slope_win (no kwarg passed) must equal explicit
        slope_win=20. Prevents regressions if _SLOPE_WIN changes."""
        rng = np.random.default_rng(13)
        vix = pd.Series(
            16 + rng.normal(0, 1, 500).cumsum() * 0.05,
            index=pd.bdate_range("2020-01-01", periods=500),
        )
        out_default = classify_vix_pace(vix)
        out_20 = classify_vix_pace(vix, slope_win=20)
        pd.testing.assert_series_equal(
            out_default["regime"], out_20["regime"], check_names=False,
        )

    def test_windows_constant_is_the_agreed_set(self):
        """The research scope is pinned to 5/10/20/60. If someone
        changes this, the summary file's 'cross-window bake-off' shifts
        and all prior interpretation becomes invalid."""
        from run_vix_pace_research import _WINDOWS
        assert _WINDOWS == (5, 10, 20, 60)

    def test_z_baseline_stays_252(self):
        """Fixed 252d baseline across windows is a deliberate design
        choice. Don't let it drift."""
        from run_vix_pace_research import _Z_WIN
        assert _Z_WIN == 252


# ══════════════════════════════════════════════════════════════════════
# Integration: reporting pipeline on synthetic data
# ══════════════════════════════════════════════════════════════════════

class TestReportingPipeline:
    """Exercise the report functions to make sure they don't crash
    and produce the expected shape, using synthetic fwd-return panels."""

    @pytest.fixture
    def synth_regime(self):
        """A 400-day regime series — balanced across RISING/STABLE/FALLING."""
        rng = np.random.default_rng(7)
        flat = 16 + rng.normal(0, 0.3, 300)
        rise = np.linspace(16, 30, 100) + rng.normal(0, 0.3, 100)
        vix = pd.Series(
            np.concatenate([flat, rise]),
            index=pd.bdate_range("2020-01-01", periods=400),
        )
        regime_df = classify_vix_pace(vix)
        return regime_df["regime"]

    @pytest.fixture
    def synth_panel(self, synth_regime):
        """Fake equity panel: 3 industries × 5 symbols. Each symbol has
        random fwd_ret_10d. Aligned to the regime series index."""
        rng = np.random.default_rng(11)
        panel = {}
        for industry_i in range(3):
            for sym_i in range(5):
                sym = f"IND{industry_i}_SYM{sym_i}"
                df = pd.DataFrame({
                    "fwd_ret_10d": rng.normal(0.01, 0.05, len(synth_regime)),
                }, index=synth_regime.index)
                panel[sym] = df
        return panel

    @pytest.fixture
    def synth_industry_map(self, synth_panel):
        """Map each fake symbol to its fake industry."""
        return {
            sym: f"INDUSTRY_{sym.split('_')[0][-1]}"
            for sym in synth_panel.keys()
        }

    def test_regime_distribution_runs(self, synth_regime, capsys):
        """report_regime_distribution should print tables without
        crashing."""
        report_regime_distribution(synth_regime.to_frame("regime"))
        captured = capsys.readouterr()
        # Output should mention all three regime labels
        assert "RISING" in captured.out
        assert "STABLE" in captured.out
        assert "FALLING" in captured.out

    def test_industry_regime_grid_runs(
        self, synth_panel, synth_industry_map, synth_regime, capsys,
    ):
        """report_industry_regime_grid should print a pivot table
        without crashing and populate rows for every industry."""
        out = report_industry_regime_grid(
            synth_panel, synth_industry_map, synth_regime,
        )
        captured = capsys.readouterr()
        # The output DataFrame should have one row per (industry, regime)
        assert len(out) > 0
        assert "industry" in out.columns
        assert "regime" in out.columns
        assert "mean_fwd10" in out.columns
        # Three industries × three regimes
        n_industries = len({v for v in synth_industry_map.values()})
        assert len(out) == n_industries * 3
