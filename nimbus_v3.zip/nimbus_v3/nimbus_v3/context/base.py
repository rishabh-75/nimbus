"""nimbus_v3.context.base — ``ContextProvider[T]`` protocol.

The single extension point for Phase 2. Every concrete provider (VIX,
sector, options, filings, flow, events, deals) implements this protocol
with a concrete context type ``T``.

Two mandatory design rules:

1. **``asof_date`` is mandatory on every build() call.** No provider is
   allowed to peek at ``datetime.now()``. This is the property that
   gives live/backtest parity for free — callers pass ``asof_date=today``
   live and ``asof_date=<historical>`` during walk-forward; the provider
   does the same thing either way.

2. **Data missing is a first-class outcome, not an exception.** Providers
   return ``None`` when the underlying data is unavailable (symbol has
   no options listed, VIX couldn't be fetched, etc.). Raising is
   reserved for programming errors (bad arguments, corrupt cache).
"""
from __future__ import annotations

from typing import Protocol, TypeVar

import pandas as pd


T_co = TypeVar("T_co", covariant=True)


class ContextProvider(Protocol[T_co]):
    """Produces a context object for a ``(symbol, asof_date)`` pair.

    ``T_co`` is the concrete context type (``MarketContext``,
    ``SectorContext``, etc.). Market-wide providers (no per-symbol
    component) accept ``symbol=None``.

    Providers are expected to be stateless or cache-backed. Callers may
    construct one instance per process and share it across threads.
    """

    def build(
        self,
        *,
        symbol: str | None,
        asof_date: pd.Timestamp,
    ) -> T_co | None:
        """Return the context object, or ``None`` if unavailable.

        Must not raise for missing data. Must not read wall-clock time —
        ``asof_date`` is the sole temporal input.
        """
        ...
