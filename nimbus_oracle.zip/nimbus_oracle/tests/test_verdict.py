"""
tests/test_verdict.py — Verdict output tests for conviction engine.

Tests the verdict string format, content, and paths:
  - Entry verdicts show grade, catalysts (flow/momentum), and risks (depth)
  - Non-entry verdicts explain WHY (MFI weak, forming, not oversold)
  - TRAP/AVOID for score ≤30 when entry triggered
  - VIX gate, Friday gate paths
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

_PASS = 0; _FAIL = 0; _ERRORS = []
def _run(name, fn):
    global _PASS, _FAIL
    try: fn(); _PASS += 1; print(f"  ✓ {name}")
    except Exception as e: _FAIL += 1; _ERRORS.append((name, str(e))); print(f"  ✗ {name}: {e}")

def _row(**kwargs):
    base = {
        "dm_tier": "NONE", "dm_score": 50, "dm_sizing": "SKIP",
        "dm_mfi": 40, "dm_wr": -40, "dm_dd": -5.0,
        "dm_streak": 2, "dm_entry": False, "dm_pct_sma": -3.0,
        "dm_bbw_slope": 0, "vix_regime": "LOW", "dm_grade": "—",
        "dm_vol_ratio": 1.0, "dm_rsi": 45,
    }
    base.update(kwargs)
    return base

from modules.scanner import _compute_verdict


# ══════════════════════════════════════════════════════════════════════════════
# PRIMARY TIER
# ══════════════════════════════════════════════════════════════════════════════

def test_primary():
    print("\n── PRIMARY TIER ──")

    def t_primary_full():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_score=85, dm_sizing="FULL",
                                  dm_entry=True, dm_mfi=55, dm_wr=-55, dm_dd=-8,
                                  dm_rsi=50, dm_vol_ratio=1.6, vix_regime="LOW"))
        assert "BUY FULL" in v, f"Got: {v}"
        assert "[" in v and "]" in v, f"Should show grade bracket. Got: {v}"
    _run("primary_buy_full", t_primary_full)

    def t_primary_strong_flow():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_score=80, dm_sizing="FULL",
                                  dm_entry=True, dm_mfi=62, dm_rsi=52, dm_vol_ratio=1.8))
        assert "money flow" in v or "flow" in v.lower(), f"Should mention flow. Got: {v}"
    _run("primary_strong_flow", t_primary_strong_flow)


# ══════════════════════════════════════════════════════════════════════════════
# SECONDARY TIER
# ══════════════════════════════════════════════════════════════════════════════

def test_secondary():
    print("\n── SECONDARY TIER ──")

    def t_secondary_half():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=70, dm_sizing="HALF",
                                  dm_entry=True, dm_mfi=50, dm_wr=-45, dm_rsi=45))
        assert "BUY HALF" in v, f"Got: {v}"
    _run("secondary_half", t_secondary_half)

    def t_normal_vix_skip():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=65, dm_sizing="SKIP",
                                  dm_entry=True, dm_mfi=45, dm_wr=-40,
                                  vix_regime="NORMAL"))
        assert "SKIP" in v or "WATCH" in v, f"Got: {v}"
        assert "Normal VIX" in v or "grade" in v.lower(), f"Should mention Normal VIX or grade. Got: {v}"
    _run("normal_vix_grade_gate", t_normal_vix_skip)

    def t_secondary_panic():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=65, dm_sizing="HALF",
                                  dm_entry=True, dm_mfi=55, dm_wr=-45, dm_rsi=50,
                                  dm_vol_ratio=1.5, vix_regime="PANIC"))
        # Grade-based sizing: A+/A → FULL regardless of tier
        assert "BUY FULL" in v or "BUY HALF" in v, f"Should be actionable. Got: {v}"
        assert "panic" not in v.lower(), f"VIX should NOT be in verdict (shown in status bar). Got: {v}"
    _run("secondary_panic_graded", t_secondary_panic)


# ══════════════════════════════════════════════════════════════════════════════
# TRAP / AVOID
# ══════════════════════════════════════════════════════════════════════════════

def test_trap():
    print("\n── TRAP / AVOID ──")

    def t_score_30_avoid():
        v = _compute_verdict(_row(dm_score=30, dm_entry=True, dm_tier="PRIMARY",
                                  dm_sizing="FULL", dm_mfi=20, dm_wr=-60))
        assert "AVOID" in v, f"Score 30+entry should AVOID. Got: {v}"
    _run("score_30_avoid", t_score_30_avoid)

    def t_score_20_avoid():
        v = _compute_verdict(_row(dm_score=20, dm_entry=True, dm_tier="SECONDARY",
                                  dm_sizing="HALF", dm_mfi=15, dm_wr=-70))
        assert "AVOID" in v, f"Score 20+entry should AVOID. Got: {v}"
    _run("score_20_avoid", t_score_20_avoid)

    def t_score_0_avoid():
        v = _compute_verdict(_row(dm_score=0, dm_entry=True, dm_tier="PRIMARY",
                                  dm_sizing="FULL", dm_mfi=10, dm_wr=-90))
        assert "AVOID" in v, f"Score 0+entry should AVOID. Got: {v}"
    _run("score_0_avoid", t_score_0_avoid)

    def t_trap_overrides_panic():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_score=25, dm_entry=True,
                                  dm_sizing="FULL", dm_mfi=20, dm_wr=-60,
                                  vix_regime="PANIC", is_trap=True))
        assert "AVOID" in v or "TRAP" in v, f"TRAP should override. Got: {v}"
    _run("trap_overrides_panic", t_trap_overrides_panic)


# ══════════════════════════════════════════════════════════════════════════════
# NON-ENTRY PATHS
# ══════════════════════════════════════════════════════════════════════════════

def test_non_entry():
    print("\n── NON-ENTRY PATHS ──")

    def t_capitulation():
        v = _compute_verdict(_row(dm_mfi=15, dm_wr=-65, dm_dd=-12, dm_score=60))
        assert "CAPITULATION" in v, f"Got: {v}"
    _run("capitulation_deep_dip", t_capitulation)

    def t_oversold_low_mfi():
        v = _compute_verdict(_row(dm_mfi=25, dm_wr=-40, dm_score=55))
        assert "OVERSOLD" in v, f"Got: {v}"
    _run("oversold_low_mfi", t_oversold_low_mfi)

    def t_forming():
        v = _compute_verdict(_row(dm_mfi=45, dm_wr=-35, dm_score=65))
        assert "FORMING" in v, f"Got: {v}"
    _run("forming_above_60", t_forming)

    def t_below_threshold():
        v = _compute_verdict(_row(dm_score=40, dm_mfi=35, dm_wr=-25))
        assert "below" in v.lower() or "score" in v.lower(), f"Got: {v}"
    _run("below_threshold", t_below_threshold)


# ══════════════════════════════════════════════════════════════════════════════
# VERDICT CONTENT — FLOW AS CONVICTION, DEPTH AS RISK
# ══════════════════════════════════════════════════════════════════════════════

def test_content():
    print("\n── VERDICT CONTENT ──")

    def t_flow_as_conviction():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_entry=True, dm_sizing="HALF",
                                  dm_mfi=62, dm_rsi=52, dm_vol_ratio=1.8,
                                  dm_wr=-45, dm_dd=-6))
        assert "money flow" in v.lower() or "flow" in v.lower(), f"Should mention flow. Got: {v}"
    _run("flow_as_conviction", t_flow_as_conviction)

    def t_depth_as_risk():
        # With strong flow, catalysts dominate — depth appears as risk, not positive
        # The key test: depth should NEVER be framed as "extreme oversold" or "capitulation"
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_entry=True, dm_sizing="HALF",
                                  dm_mfi=55, dm_wr=-85, dm_dd=-22, dm_rsi=50,
                                  dm_vol_ratio=1.6, vix_regime="ELEVATED"))
        assert "extreme oversold" not in v, f"Depth should NOT be positive catalyst. Got: {v}"
        assert "capitulation" not in v, f"Capitulation should NOT be positive. Got: {v}"
        assert "deep oversold" not in v, f"Deep oversold should NOT be positive. Got: {v}"
    _run("depth_not_positive", t_depth_as_risk)

    def t_shallow_dip_good():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_entry=True, dm_sizing="HALF",
                                  dm_mfi=55, dm_rsi=48, dm_pct_sma=-2.0,
                                  dm_wr=-35, dm_dd=-4))
        assert "shallow" in v.lower() or "clean" in v.lower() or "flow" in v.lower(), \
            f"Shallow dip should be positive. Got: {v}"
    _run("shallow_dip_positive", t_shallow_dip_good)


# ══════════════════════════════════════════════════════════════════════════════
# GRADE IN VERDICT
# ══════════════════════════════════════════════════════════════════════════════

def test_grade_in_verdict():
    print("\n── GRADE IN VERDICT ──")

    def t_grade_present():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_entry=True, dm_sizing="FULL",
                                  dm_score=80, dm_mfi=55, dm_rsi=50, dm_vol_ratio=1.5))
        assert "[" in v and "]" in v, f"Should have grade bracket. Got: {v}"
    _run("grade_bracket_present", t_grade_present)

    def t_no_grade_for_noentry():
        v = _compute_verdict(_row(dm_score=40, dm_mfi=35, dm_wr=-25))
        assert "[A" not in v and "[B" not in v, f"No-entry should not have grade. Got: {v}"
    _run("no_grade_for_noentry", t_no_grade_for_noentry)


# ══════════════════════════════════════════════════════════════════════════════
# VIX REGIME SUFFIX
# ══════════════════════════════════════════════════════════════════════════════

def test_vix_suffix():
    print("\n── VIX SUFFIX ──")

    def t_panic_suffix():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_entry=True, dm_sizing="FULL",
                                  dm_score=80, dm_mfi=55, dm_rsi=50,
                                  vix_regime="PANIC"))
        count = v.lower().count("panic")
        assert count <= 1, f"'panic' appears {count} times. Got: {v}"
        assert "panic" not in v.lower(), f"VIX should NOT be in verdict (shown in status bar). Got: {v}"
    _run("panic_suffix_once", t_panic_suffix)

    def t_normal_no_suffix():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_entry=True, dm_sizing="FULL",
                                  dm_score=80, dm_mfi=55, dm_rsi=50,
                                  vix_regime="NORMAL"))
        assert "panic" not in v.lower(), f"Normal should not mention panic. Got: {v}"
    _run("normal_no_panic", t_normal_no_suffix)


# ══════════════════════════════════════════════════════════════════════════════
# VERDICT DIFFERENTIATES STOCKS
# ══════════════════════════════════════════════════════════════════════════════

def test_differentiation():
    print("\n── DIFFERENTIATION ──")

    def t_different_quality():
        v1 = _compute_verdict(_row(dm_tier="SECONDARY", dm_entry=True, dm_sizing="HALF",
                                   dm_mfi=62, dm_rsi=52, dm_vol_ratio=1.8,
                                   dm_wr=-45, dm_dd=-4, vix_regime="PANIC"))
        v2 = _compute_verdict(_row(dm_tier="SECONDARY", dm_entry=True, dm_sizing="HALF",
                                   dm_mfi=35, dm_rsi=28, dm_vol_ratio=0.5,
                                   dm_wr=-90, dm_dd=-25, vix_regime="PANIC"))
        assert v1 != v2, f"Different quality must differ: {v1} vs {v2}"
    _run("quality_differentiates", t_different_quality)


if __name__ == "__main__":
    print("=" * 60)
    print("NIMBUS Verdict Tests (conviction engine)")
    print("=" * 60)
    test_primary()
    test_secondary()
    test_trap()
    test_non_entry()
    test_content()
    test_grade_in_verdict()
    test_vix_suffix()
    test_differentiation()
    print(f"\n{'=' * 60}")
    print(f"RESULTS: {_PASS} passed, {_FAIL} failed")
    print("=" * 60)
    if _ERRORS:
        for n, e in _ERRORS: print(f"  {n}: {e}")
    import sys; sys.exit(1 if _FAIL > 0 else 0)
