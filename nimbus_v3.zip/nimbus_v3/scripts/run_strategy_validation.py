"""scripts/run_strategy_validation.py — gate ablation + parameter sweep
for the v3 equity strategies.

Methodology
───────────

For each strategy (MR, BO, Ride):

A) **Baseline**: enforce all gates with current parameters; record
   triggered trade count, mean 10-day forward return, win rate.

B) **Single-gate ablation**: for each gate G, build a relaxed predicate
   that omits G; record the same stats. Compare delta:
   - If trade count balloons but mean return is unchanged → G filters
     for value (essential).
   - If trade count balloons AND mean return improves or holds → G is
     overspecified (drop or loosen).
   - If trade count is similar → G is redundant with the other gates.

C) **Parameter sensitivity**: sweep each numeric threshold across a
   ±50% band around the baseline value. Plot trade count and mean
   forward return per setting. Flat curves → noise; sharp curves →
   real discriminator.

Universe: the v2 cached panel (NIFTY 200 names, 2020-03 → 2026-04).
VIX: synthesised proxy from cross-sectional |daily return| median (see
``research.harness.build_vix_proxy``).

Sector and filing contexts are stubbed — the gates we're studying don't
read those fields. The TRAP and ETF momentum strategies are out of
scope here: TRAP needs historical filing tags (we don't have them);
ETF momentum needs ETF history (the cache has equities only).
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

# Ensure the v3 package is importable when this script is run directly.
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import (
    add_forward_returns,
    build_vix_proxy,
    compute_vix_streaks,
    evaluate_vector_predicate_panel,
    summarise,
)


# ══════════════════════════════════════════════════════════════════════════════
# Vectorised gates — each returns a boolean Series of the DataFrame's length
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class GateDef:
    """One named gate: a vectorised boolean predicate over an enriched frame."""
    name: str
    test: Callable[[pd.DataFrame, pd.Series], pd.Series]


# Mean Reversion gates --------------------------------------------------------
def mr_gates(*, roc_5_max=-3.0, bbw_pctl_max=30.0, vix_streak_min=6) -> list[GateDef]:
    return [
        GateDef("data_sufficient",
                  lambda df, _: df["data_sufficient"].astype(bool)),
        GateDef(f"roc_5 < {roc_5_max}",
                  lambda df, _: df["roc_5"] < roc_5_max),
        GateDef(f"bbw_20_2s_pctl < {bbw_pctl_max}",
                  lambda df, _: df["bbw_20_2s_pctl"] < bbw_pctl_max),
        GateDef(f"vix_streak >= {vix_streak_min}",
                  lambda _, st: st >= vix_streak_min),
    ]


# Breakout gates --------------------------------------------------------------
def bo_gates(*, roc_20_min=5.0, vol_ratio_min=1.5, vix_streak_min=4) -> list[GateDef]:
    return [
        GateDef("data_sufficient",
                  lambda df, _: df["data_sufficient"].astype(bool)),
        GateDef(f"roc_20 > {roc_20_min}",
                  lambda df, _: df["roc_20"] > roc_20_min),
        GateDef(f"vol_ratio_20 >= {vol_ratio_min}",
                  lambda df, _: df["vol_ratio_20"] >= vol_ratio_min),
        GateDef(f"vix_streak >= {vix_streak_min}",
                  lambda _, st: st >= vix_streak_min),
    ]


# Ride gates ------------------------------------------------------------------
def ride_gates(*, wr_30_min=-20.0) -> list[GateDef]:
    return [
        GateDef("data_sufficient",
                  lambda df, _: df["data_sufficient"].astype(bool)),
        GateDef("Close in [bb_1s_upper, bb_2s_upper]",
                  lambda df, _: (df["bb_20_1s_upper"] <= df["Close"])
                                 & (df["Close"] <= df["bb_20_2s_upper"])),
        GateDef(f"wr_30 > {wr_30_min}",
                  lambda df, _: df["wr_30"] > wr_30_min),
    ]


def _all_gates(gates: list[GateDef]) -> Callable[[pd.DataFrame, pd.Series], pd.Series]:
    def fn(df, st):
        result = None
        for g in gates:
            mask = g.test(df, st)
            result = mask if result is None else (result & mask)
        return result
    return fn


def _all_except(gates: list[GateDef], drop: GateDef) -> Callable[[pd.DataFrame, pd.Series], pd.Series]:
    def fn(df, st):
        result = None
        for g in gates:
            if g is drop:
                continue
            mask = g.test(df, st)
            result = mask if result is None else (result & mask)
        return result if result is not None else pd.Series(True, index=df.index)
    return fn


# ══════════════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════════════

def _print_header(text: str) -> None:
    print()
    print("═" * 80)
    print(f"  {text}")
    print("═" * 80)


def _row(label: str, stats) -> str:
    if stats.n == 0:
        return f"  {label:50s}  n=     0   mean10d=  --     wr10d=  --     t=  --"
    return (
        f"  {label:50s}  n={stats.n:6d}   "
        f"mean10d={stats.mean_10d * 100:+5.2f}%   "
        f"wr10d={stats.win_rate_10d * 100:5.1f}%   "
        f"t={stats.t_stat_10d:+5.2f}"
    )


def run_ablation(
    *,
    strategy_name: str,
    enriched_panel: dict[str, pd.DataFrame],
    vix_streak: pd.Series,
    gates: list[GateDef],
) -> list[dict]:
    """Run the gate ablation for one strategy. Prints + returns rows."""
    _print_header(f"{strategy_name} — gate ablation")
    rows: list[dict] = []

    def _capture(label: str, stats, *, delta_n=None, delta_mean=None):
        rows.append({
            "strategy": strategy_name, "type": "ablation",
            "label": label, "n": stats.n,
            "mean_10d": round(stats.mean_10d * 100, 3) if stats.n else None,
            "wr_10d": round(stats.win_rate_10d * 100, 1) if stats.n else None,
            "t_stat": round(stats.t_stat_10d, 2) if stats.n else None,
            "delta_n": delta_n, "delta_mean_pp": delta_mean,
        })

    # Baseline: all gates enforced.
    baseline = evaluate_vector_predicate_panel(
        strategy_name=strategy_name,
        enriched_panel=enriched_panel,
        vix_streak=vix_streak,
        predicate=_all_gates(gates),
    )
    base_stats = summarise(baseline)
    print(_row("BASELINE (all gates)", base_stats))
    _capture("BASELINE", base_stats)

    # Drop one gate at a time.
    for g in gates:
        relaxed = evaluate_vector_predicate_panel(
            strategy_name=strategy_name,
            enriched_panel=enriched_panel,
            vix_streak=vix_streak,
            predicate=_all_except(gates, g),
        )
        s = summarise(relaxed)
        delta_n = s.n - base_stats.n
        delta_mean = (s.mean_10d - base_stats.mean_10d) * 100 if base_stats.n > 0 else float("nan")
        annotation = f"  →  Δn={delta_n:+6d}, Δmean10d={delta_mean:+5.2f}pp"
        print(_row(f"WITHOUT [{g.name}]", s) + annotation)
        _capture(f"WITHOUT [{g.name}]", s, delta_n=delta_n, delta_mean_pp=round(delta_mean, 3))

    # Universe baseline (no gates at all): every (symbol, bar) → forward return.
    universe = evaluate_vector_predicate_panel(
        strategy_name=strategy_name,
        enriched_panel=enriched_panel,
        vix_streak=vix_streak,
        predicate=lambda s, _: True,
    )
    u_stats = summarise(universe)
    print(_row("UNIVERSE (no gates — every bar)", u_stats))
    _capture("UNIVERSE", u_stats)

    return rows


def run_param_sweep(
    *,
    strategy_name: str,
    param_name: str,
    values: list,
    gate_builder: Callable[..., list[GateDef]],
    enriched_panel: dict[str, pd.DataFrame],
    vix_streak: pd.Series,
) -> list[dict]:
    """Sweep one parameter. Prints + returns rows."""
    _print_header(f"{strategy_name} — sensitivity to {param_name}")
    rows: list[dict] = []
    for v in values:
        gates = gate_builder(**{param_name: v})
        trades = evaluate_vector_predicate_panel(
            strategy_name=strategy_name,
            enriched_panel=enriched_panel,
            vix_streak=vix_streak,
            predicate=_all_gates(gates),
        )
        s = summarise(trades)
        print(_row(f"{param_name} = {v}", s))
        rows.append({
            "strategy": strategy_name, "type": "sweep",
            "param": param_name, "value": v, "n": s.n,
            "mean_10d": round(s.mean_10d * 100, 3) if s.n else None,
            "wr_10d": round(s.win_rate_10d * 100, 1) if s.n else None,
            "t_stat": round(s.t_stat_10d, 2) if s.n else None,
        })
    return rows


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    panel = load_equity_panel()
    if not panel:
        print("No equity panel loaded — yfinance unreachable? Stopping.")
        return

    print("Building VIX proxy from cross-sectional realised vol …")
    vix_df = build_vix_proxy(panel, smoothing=5)
    print(
        f"  proxy: {len(vix_df)} bars, range "
        f"{vix_df['Close'].min():.1f}–{vix_df['Close'].max():.1f}, "
        f"mean {vix_df['Close'].mean():.1f}"
    )
    # Use a HIGH threshold inside the proxy's empirical distribution.
    high_threshold = float(vix_df["Close"].quantile(0.65))
    print(f"  HIGH threshold = {high_threshold:.2f} (65th percentile)")
    vix_streak = compute_vix_streaks(vix_df, high_threshold=high_threshold)
    print(
        f"  streak series: max={int(vix_streak.max())}, "
        f"days with streak≥4 = {int((vix_streak >= 4).sum())}, "
        f"days with streak≥6 = {int((vix_streak >= 6).sum())}"
    )

    print("Enriching every symbol with indicators + forward returns …")
    engine = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            e = engine.enrich(df, sym)
            e = add_forward_returns(e, horizons=(5, 10, 20))
            enriched[sym] = e
        except Exception:    # noqa: BLE001
            continue
    print(f"  enriched {len(enriched)}/{len(panel)} symbols")

    all_rows: list[dict] = []

    # ── Strategy 1: Mean Reversion ────────────────────────────────────────────
    all_rows.extend(run_ablation(
        strategy_name="MeanReversion",
        enriched_panel=enriched,
        vix_streak=vix_streak,
        gates=mr_gates(),
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="MeanReversion", param_name="roc_5_max",
        values=[-1.0, -2.0, -3.0, -4.0, -5.0],
        gate_builder=mr_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="MeanReversion", param_name="bbw_pctl_max",
        values=[15, 25, 30, 40, 50, 75, 100],
        gate_builder=mr_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="MeanReversion", param_name="vix_streak_min",
        values=[0, 1, 2, 4, 6, 8, 10],
        gate_builder=mr_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))

    # ── Strategy 2: Breakout ──────────────────────────────────────────────────
    all_rows.extend(run_ablation(
        strategy_name="Breakout",
        enriched_panel=enriched,
        vix_streak=vix_streak,
        gates=bo_gates(),
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="Breakout", param_name="roc_20_min",
        values=[2.0, 4.0, 5.0, 7.0, 10.0, 15.0],
        gate_builder=bo_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="Breakout", param_name="vol_ratio_min",
        values=[1.0, 1.25, 1.5, 1.75, 2.0, 3.0],
        gate_builder=bo_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="Breakout", param_name="vix_streak_min",
        values=[0, 1, 2, 4, 6, 8],
        gate_builder=bo_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))

    # ── Strategy 3: Ride ──────────────────────────────────────────────────────
    all_rows.extend(run_ablation(
        strategy_name="Ride",
        enriched_panel=enriched,
        vix_streak=vix_streak,
        gates=ride_gates(),
    ))
    all_rows.extend(run_param_sweep(
        strategy_name="Ride", param_name="wr_30_min",
        values=[-50, -40, -30, -20, -10, -5],
        gate_builder=ride_gates,
        enriched_panel=enriched, vix_streak=vix_streak,
    ))

    # ── Export ────────────────────────────────────────────────────────────────
    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("data/research")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"strategy_validation_{ts}.csv"
    pd.DataFrame(all_rows).to_csv(out_path, index=False)

    print()
    print("═" * 80)
    print(f"  Done. Exported → {out_path}")
    print("═" * 80)


if __name__ == "__main__":
    main()
