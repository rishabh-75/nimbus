"""nimbus_v3.data.enriched_cache — on-disk cache for enriched panels.

The enriched DataFrame for a symbol is a pure function of:
  1. The raw OHLCV DataFrame for that symbol
  2. The enrichment recipe (``StrategyComputeEngine._ENRICHMENT_STEPS``)

Both inputs are stable across launches when nothing changes. Today's
startup path re-enriches 463 symbols on every launch because the
enriched result isn't persisted — ~7.3s of compute that repeats.

This module caches enriched DataFrames to disk keyed by (symbol,
schema_hash). Freshness is determined by comparing mtimes against the
raw price cache: if the raw file is newer than the enriched file, the
cache is stale. The schema hash (from
``StrategyComputeEngine.enrichment_schema_hash()``) namespaces the
cache per-schema-version so a recipe change (new indicator, tweaked
period) transparently invalidates every cached entry without leaving
wrong-column rows on disk being served.

Usage::

    raw_cache = ParquetCache(Path("data/cache/equity_price"))
    enriched_cache = EnrichedPanelCache(
        raw_cache=raw_cache,
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    hit = enriched_cache.get_if_fresh("RELIANCE")
    if hit is None:
        enriched = engine.enrich(raw_cache.get("RELIANCE"), "RELIANCE")
        enriched_cache.set("RELIANCE", enriched)
"""
from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from nimbus_v3.data.cache import ParquetCache


logger = logging.getLogger(__name__)


class EnrichedPanelCache:
    """Persistent cache of enriched per-symbol DataFrames.

    Delegates parquet IO to ``ParquetCache`` (reuses the atomic-write
    path) and adds:
      - Schema-hash namespacing: each enrichment recipe gets its own
        subdirectory; recipe changes produce unreachable-but-harmless
        orphans rather than served-but-wrong cached rows.
      - Freshness-checking against the raw cache: if the raw parquet
        is newer than the enriched one, the cached enriched is stale
        and the caller must re-enrich.

    Thread-safe for reads and writes to different symbols. Concurrent
    writes to the same symbol follow ``ParquetCache``'s rules (atomic
    rename, last-writer-wins).
    """

    def __init__(
        self,
        *,
        raw_cache: ParquetCache,
        schema_hash: str,
        root: Path | None = None,
    ) -> None:
        """Args:
            raw_cache: The raw-panel cache whose mtimes determine
                freshness of enriched entries.
            schema_hash: Short hex string identifying the enrichment
                recipe version. Typically from
                ``StrategyComputeEngine.enrichment_schema_hash()``.
                Used as subdirectory name under ``root``.
            root: Where enriched caches live. ``None`` (default) →
                resolves via :func:`nimbus_v3.data.paths.cache_dir`
                so the directory tracks the ``NIMBUS_DATA_DIR`` env
                override. Per-schema subdirs are created below it.
        """
        self._raw_cache = raw_cache
        self._schema_hash = schema_hash
        if root is None:
            from nimbus_v3.data.paths import cache_dir
            root = cache_dir("equity_enriched")
        self._root = Path(root)
        self._ns_dir = self._root / schema_hash
        self._inner = ParquetCache(base_dir=self._ns_dir)

    # ══════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════

    def get_if_fresh(self, symbol: str) -> pd.DataFrame | None:
        """Return the cached enriched frame for ``symbol`` iff it's
        still fresh (raw mtime ≤ enriched mtime). Returns ``None``
        when the cache is missing, stale, or unreadable.

        The comparison is "raw mtime ≤ enriched mtime". If they're
        equal (clock granularity, or raw never changed), the cached
        entry is considered fresh. If raw is strictly newer, stale.
        """
        enriched_path = self._inner_path(symbol)
        if not enriched_path.is_file():
            return None

        raw_path = self._raw_path(symbol)
        if not raw_path.is_file():
            # No raw data to compare against — the cached entry may
            # be orphaned from a deleted raw symbol. Return it anyway;
            # the caller can decide whether to use it or discard.
            try:
                return pd.read_parquet(enriched_path)
            except Exception:    # noqa: BLE001
                logger.warning(
                    "enriched_cache: read failed for %r, returning None",
                    symbol,
                )
                return None

        enriched_mtime = enriched_path.stat().st_mtime
        raw_mtime = raw_path.stat().st_mtime
        if raw_mtime > enriched_mtime:
            return None    # stale

        try:
            return pd.read_parquet(enriched_path)
        except Exception:    # noqa: BLE001
            # Corrupt cache — best-effort: remove the file so next
            # call returns None deterministically, and don't crash.
            logger.warning(
                "enriched_cache: corrupt entry for %r; removing",
                symbol,
            )
            try:
                enriched_path.unlink()
            except OSError:
                pass
            return None

    def get_stale(self, symbol: str) -> pd.DataFrame | None:
        """Return the cached enriched frame REGARDLESS of freshness.

        For offline fallback: when there's no connectivity we'd rather
        serve a stale entry than nothing. Returns ``None`` only when the
        entry is missing or unreadable.
        """
        enriched_path = self._inner_path(symbol)
        if not enriched_path.is_file():
            return None
        try:
            return pd.read_parquet(enriched_path)
        except Exception:    # noqa: BLE001
            logger.warning(
                "enriched_cache: stale read failed for %r", symbol,
            )
            return None

    def set(self, symbol: str, df: pd.DataFrame) -> None:
        """Persist an enriched frame for ``symbol``. Overwrites any
        existing cached entry atomically."""
        self._inner.set(symbol, df)

    def exists(self, symbol: str) -> bool:
        """True if there's any cached entry for ``symbol`` regardless
        of freshness. Useful for diagnostics; callers that need
        semantic freshness should use :meth:`get_if_fresh`."""
        return self._inner.exists(symbol)

    # ══════════════════════════════════════════════════════════════════
    # Internals
    # ══════════════════════════════════════════════════════════════════

    def _raw_path(self, symbol: str) -> Path:
        """Filesystem path of the raw cache entry for ``symbol``."""
        # Assumes ParquetCache uses ``{base_dir}/{key}.parquet``. This
        # coupling is acceptable because ParquetCache is a sibling
        # class in the same package. If ParquetCache's layout ever
        # changes, this breaks loudly rather than silently.
        return self._raw_cache.base_dir / f"{symbol}{ParquetCache._SUFFIX}"

    def _inner_path(self, symbol: str) -> Path:
        """Filesystem path of the enriched cache entry for ``symbol``."""
        return self._ns_dir / f"{symbol}{ParquetCache._SUFFIX}"

    @property
    def schema_hash(self) -> str:
        """The schema hash this cache is keyed to. Exposed for
        diagnostic logging."""
        return self._schema_hash

    @property
    def root(self) -> Path:
        """Root directory of the cache (parent of the schema-hash
        subdirectory). Exposed for diagnostic logging and manual
        inspection/cleanup."""
        return self._root
