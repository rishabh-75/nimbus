"""nimbus_v3.compute.rrg — Relative Rotation Graph engine.

Stateless. Computes, per industry, the two RRG coordinates plus a
volatility read and a short tail showing direction of travel:

  - RS-Ratio (x-axis): the industry's relative strength vs a benchmark
    (CNX500), normalised so 100 = matching the market. >100 leads,
    <100 lags. Computed as the industry/benchmark price ratio, indexed
    to its own recent mean and centred at 100.
  - RS-Momentum (y-axis): the rate of change of RS-Ratio, centred at
    100. >100 = relative strength rising (gaining), <100 = falling.
  - Volatility: ADTV-weighted mean of members' ``atr_14_pct`` — encodes
    "how clean is this leadership" (low vol = calmer trend).
  - Tail: the last ``tail_len`` (RS-Ratio, RS-Momentum) points, so the
    UI can draw direction of travel.

Quadrants (standard RRG):
  Leading   = RS>100 & Mom>100  (strong, gaining)   — top right
  Weakening = RS>100 & Mom<100  (strong, losing)    — bottom right
  Lagging   = RS<100 & Mom<100  (weak, falling)     — bottom left
  Improving = RS<100 & Mom>100  (weak, gaining)     — top left
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np
import pandas as pd

from nimbus_v3.compute.industry_composite import build_industry_composite
from nimbus_v3.compute.industry_rotation import (
    MIN_MEMBERS,
    _MIN_BARS,
)

#: Lookback window (trading days) for the RS computation.
DEFAULT_LOOKBACK: int = 60
#: Smoothing window for the RS-Ratio (bars) — tames daily noise.
RS_SMOOTH: int = 5
#: Momentum lookback (bars) — RS-Ratio rate-of-change horizon.
MOM_LOOKBACK: int = 10
#: Number of trailing points in each industry's tail.
DEFAULT_TAIL: int = 8


class Quadrant(str, Enum):
    LEADING = "Leading"
    WEAKENING = "Weakening"
    LAGGING = "Lagging"
    IMPROVING = "Improving"


def _quadrant(rs: float, mom: float) -> Quadrant:
    if rs >= 100 and mom >= 100:
        return Quadrant.LEADING
    if rs >= 100 and mom < 100:
        return Quadrant.WEAKENING
    if rs < 100 and mom < 100:
        return Quadrant.LAGGING
    return Quadrant.IMPROVING


class Maturity(str, Enum):
    """How 'mature' an industry's move is, from the momentum slope over
    its tail — independent of which quadrant it currently sits in.

    FRESH    = momentum accelerating in a favourable direction (early in
               the move — best for an early entry).
    STABLE   = momentum roughly flat (move is steady / unremarkable).
    MATURING = momentum decelerating while still strong (Leading but
               losing steam — the pre-Weakening warning; you may be late).
    TURNING  = momentum accelerating out of weakness (Lagging but
               recovering — pre-Improving; an early-rotation candidate).
    """
    FRESH = "Fresh"
    STABLE = "Stable"
    MATURING = "Maturing"
    TURNING = "Turning"


#: |slope| below this (RS-Momentum units per bar) is treated as flat.
_SLOPE_FLAT_EPS: float = 0.15


def _maturity(quadrant: "Quadrant", mom_slope: float) -> "Maturity":
    """Classify maturity from the current quadrant + momentum slope.

    The slope is the per-bar trend of RS-Momentum across the tail:
    positive = momentum building, negative = momentum fading.
    """
    rising = mom_slope > _SLOPE_FLAT_EPS
    falling = mom_slope < -_SLOPE_FLAT_EPS

    if quadrant in (Quadrant.LEADING, Quadrant.WEAKENING):
        # Strong-RS side: decelerating is the pre-Weakening warning.
        if falling:
            return Maturity.MATURING
        if rising:
            return Maturity.FRESH
        return Maturity.STABLE
    # Weak-RS side (Lagging / Improving): accelerating is the recovery.
    if rising:
        return Maturity.TURNING
    if falling:
        return Maturity.MATURING    # weak and getting weaker
    return Maturity.STABLE


@dataclass(frozen=True)
class RRGPoint:
    """One industry's RRG position + tail + volatility + maturity."""

    industry: str
    rs_ratio: float            # x — current
    rs_momentum: float         # y — current
    volatility: float          # ADTV-weighted atr_14_pct
    quadrant: Quadrant
    n_members: int
    #: Trailing (rs_ratio, rs_momentum) points, oldest → newest.
    tail: tuple[tuple[float, float], ...]
    #: Per-bar slope of RS-Momentum across the tail (>0 = accelerating).
    mom_slope: float = 0.0
    #: Maturity read derived from quadrant + mom_slope.
    maturity: Maturity = Maturity.STABLE


#: Quadrant ordering for the "best forward odds" / early-entry reading.
#: Improving (weak but gaining — catch rotation as it starts) ranks
#: highest, then Leading (confirmed + still accelerating), then
#: Weakening (a fading leader — high RS but momentum rolled over, the
#: counter-intuitive trap), then Lagging (weak + falling). Within a
#: quadrant we sort by momentum (the forward-looking axis) descending.
_ODDS_QUADRANT_RANK = {
    Quadrant.IMPROVING: 0,
    Quadrant.LEADING:   1,
    Quadrant.WEAKENING: 2,
    Quadrant.LAGGING:   3,
}


def _odds_key(p: "RRGPoint") -> tuple[int, float]:
    return (_ODDS_QUADRANT_RANK[p.quadrant], -p.rs_momentum)


@dataclass(frozen=True)
class RRGResult:
    points: tuple[RRGPoint, ...]
    lookback: int

    @property
    def has_data(self) -> bool:
        return len(self.points) > 0

    def odds_ranked(self) -> tuple[RRGPoint, ...]:
        """Points ordered by forward-odds / early-entry reading:
        Improving → Leading → Weakening → Lagging, momentum-desc within
        each. This is the order the leaderboard uses — it answers "best
        odds going forward", not "strongest right now" (raw RS), so a
        fading leader (high RS, falling momentum) ranks below a fresh
        accelerating name."""
        return tuple(sorted(self.points, key=_odds_key))


def _industry_composite_price(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    lookback: int,
) -> tuple[pd.Series | None, float, int]:
    """ADTV-weighted composite price series for an industry, plus its
    ADTV-weighted volatility (atr_14_pct) and member count.

    Returns (price_series, volatility, n_members). price_series is None
    when too few members have usable data. The composite is built by the
    shared ``build_industry_composite``; volatility is then ADTV-weighted
    over the same members using the weights it reports.
    """
    composite, member_weights = build_industry_composite(
        members, panel, min_members=MIN_MEMBERS, min_bars=_MIN_BARS,
        lookback=lookback)
    if composite is None:
        return None, float("nan"), 0

    # ADTV-weighted volatility (atr_14_pct) over the members used, with
    # the same weights the composite used.
    atr_acc = 0.0
    wsum = 0.0
    for sym, w in member_weights:
        df = panel.get(sym)
        if df is None or "atr_14_pct" not in df.columns:
            continue
        v = df["atr_14_pct"].iloc[-1]
        if v == v:
            atr_acc += float(v) * w
            wsum += w
    vol = (atr_acc / wsum) if wsum > 0 else float("nan")

    return composite, vol, len(member_weights)


def compute_rrg(
    members_by_industry: dict[str, list[str]],
    panel: dict[str, pd.DataFrame],
    benchmark_close: pd.Series | None,
    *,
    lookback: int = DEFAULT_LOOKBACK,
    tail_len: int = DEFAULT_TAIL,
) -> RRGResult:
    """Compute RRG points for every qualifying industry.

    Args:
        members_by_industry: ``{industry: [symbols]}``.
        panel: ``{symbol: enriched_df}``.
        benchmark_close: CNX500 (or other) close series. When None, the
            equal-weighted mean of all industry composites is used as a
            synthetic benchmark so the view still renders.
        lookback: RS window (trading days).
        tail_len: trailing points per industry.
    """
    # 1) Build composite price per industry.
    comps: dict[str, pd.Series] = {}
    vols: dict[str, float] = {}
    counts: dict[str, int] = {}
    for industry, members in members_by_industry.items():
        if industry in ("ALL", "Unknown", ""):
            continue
        comp, vol, n = _industry_composite_price(members, panel, lookback)
        if comp is None:
            continue
        comps[industry] = comp
        vols[industry] = vol
        counts[industry] = n

    if not comps:
        return RRGResult(points=(), lookback=lookback)

    # 2) Benchmark series — provided, else synthetic (mean of composites).
    if benchmark_close is not None and not benchmark_close.empty:
        bench = benchmark_close.dropna().tail(lookback)
    else:
        bench = pd.concat(comps.values(), axis=1, sort=False).mean(axis=1)

    points: list[RRGPoint] = []
    for industry, comp in comps.items():
        # Align industry + benchmark on common dates.
        joined = pd.concat(
            [comp.rename("ind"), bench.rename("bench")],
            axis=1, sort=False,
        ).dropna()
        if len(joined) < max(_MIN_BARS, MOM_LOOKBACK + 1):
            continue

        # Relative strength = industry / benchmark, normalised to its own
        # mean and centred at 100.
        rs = joined["ind"] / joined["bench"]
        rs = rs / rs.mean() * 100.0
        rs = rs.rolling(RS_SMOOTH, min_periods=1).mean()

        # RS-Momentum = rate of change of RS over MOM_LOOKBACK, centred 100.
        mom = (rs / rs.shift(MOM_LOOKBACK) - 1.0) * 100.0 + 100.0
        mom = mom.dropna()
        rs = rs.loc[mom.index]
        if len(mom) < 2:
            continue

        # Tail: last tail_len (rs, mom) points.
        tail_rs = rs.tail(tail_len).to_numpy(dtype=float)
        tail_mom = mom.tail(tail_len).to_numpy(dtype=float)
        tail = tuple((float(a), float(b)) for a, b in zip(tail_rs, tail_mom))

        cur_rs = float(rs.iloc[-1])
        cur_mom = float(mom.iloc[-1])
        if cur_rs != cur_rs or cur_mom != cur_mom:
            continue

        # Momentum slope across the tail — least-squares fit of the
        # tail's RS-Momentum vs bar index. Positive = accelerating,
        # negative = decelerating. This is what distinguishes a fresh
        # Leading name (slope up) from a maturing one about to roll into
        # Weakening (slope down) before it actually crosses the boundary.
        quad = _quadrant(cur_rs, cur_mom)
        if len(tail_mom) >= 3:
            xs = np.arange(len(tail_mom), dtype=float)
            slope = float(np.polyfit(xs, tail_mom, 1)[0])
        else:
            slope = 0.0
        maturity = _maturity(quad, slope)

        points.append(RRGPoint(
            industry=industry,
            rs_ratio=cur_rs,
            rs_momentum=cur_mom,
            volatility=vols.get(industry, float("nan")),
            quadrant=quad,
            n_members=counts.get(industry, 0),
            tail=tail,
            mom_slope=slope,
            maturity=maturity,
        ))

    # Sort by quadrant priority then RS for stable ordering.
    points.sort(key=lambda p: (-p.rs_ratio, -p.rs_momentum))
    return RRGResult(points=tuple(points), lookback=lookback)
