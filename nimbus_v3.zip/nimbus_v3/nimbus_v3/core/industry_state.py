"""nimbus_v3.core.industry_state — per-(industry, bar) aggregate state.

``IndustryState`` is the frozen dataclass that captures what an
industry's equal-weight index is doing on a given bar. It is the
output of ``compute/industry_analytics.py::IndustryAnalyticsEngine.
extract_industry_state`` and the input to anything downstream that
needs industry-level context: conditional phase labels, the Market
Pulse industry table, ranking penalties/bonuses, and so on.

Design principles
─────────────────
- **Frozen**: once constructed, an ``IndustryState`` never changes.
  Safe to share across threads, use as dict keys, include in tests.
- **Self-describing**: every field is documented inline and organised
  by logical group (identity, EW price, momentum, volume, phase,
  breadth, data quality) to match the ordering in the engine.
- **No external context**: industry state carries only aggregates
  derived from its members' OHLCV. Sector / macro context belongs
  elsewhere.
- **No behaviour**: no methods beyond what ``@dataclass(frozen=True)``
  gives us. Helpers that operate on an ``IndustryState`` live in
  the engine or in consumer code.

Parallel to ``SignalState``
───────────────────────────
Where ``SignalState`` is per-(symbol, bar), ``IndustryState`` is
per-(industry, bar). The two are consumed together: a stock's
ranking decision reads its own ``SignalState`` AND the ``IndustryState``
of its industry on the same bar, then blends them via
``IndustryRelativeState`` (which captures the join).

Warmup / data sufficiency
─────────────────────────
The longest-lookback field is ``ew_vol_chg_60`` which needs 120 bars
(60 for the window + 60 prior). Bars before warmup have NaN in
those fields and ``data_sufficient=False``. Consumers MUST check
``data_sufficient`` before trusting any field.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class IndustryState:
    """Per-(industry, bar) aggregate state for an equal-weight
    industry index.

    Field groups match the enrichment order in
    ``compute/industry_analytics.py::IndustryAnalyticsEngine.enrich_industry``.
    All numeric fields are native ``float`` (not ``np.float64``) to
    avoid subtle dtype comparison bugs in tests.
    """

    # ── Identity ─────────────────────────────────────────────────────────
    industry: str                       #: e.g. "Banks", "IT - Software"
    bar_date: pd.Timestamp              #: the date this state applies to
    member_count: int                   #: stocks contributing to the EW index

    # ── EW price + basic technicals ──────────────────────────────────────
    ew_close: float                     #: equal-weight close (mean of member closes)
    ew_sma_20: float                    #: 20-day SMA of ew_close
    ew_sma_50: float                    #: 50-day SMA of ew_close
    ew_bb_pct: float                    #: Bollinger %B on ew_close (1σ bands)

    # ── Momentum windows ─────────────────────────────────────────────────
    ew_roc_5: float                     #: 5-day ROC (%) on ew_close
    ew_roc_10: float                    #: 10-day ROC (%) on ew_close
    ew_roc_20: float                    #: 20-day ROC (%) on ew_close

    # ── Volume regime ────────────────────────────────────────────────────
    #: 20d-vs-prior-20d total-volume change (%, e.g. +30.0 = +30%).
    #: Used for display consistency with the legacy Market Pulse column.
    ew_vol_chg_20: float
    #: 60d-vs-prior-60d total-volume change (%). The preferred window
    #: for distribution / accumulation detection per the ablation
    #: (-0.57pp delta at 20d horizon, t=-8.93 vs -0.32pp, t=-5.60 for
    #: the 20d window — same signature, stronger signal).
    ew_vol_chg_60: float

    # ── Phase classification ─────────────────────────────────────────────
    #: Output of ``classify_phase`` on the EW series. One of
    #: ``"EARLY"``, ``"MID"``, ``"LATE"``, ``"EUPHORIA"``, ``"NEUTRAL"``,
    #: ``"DECLINE"``. String (not enum) for easy UI rendering and
    #: serialisation.
    phase: str

    # ── Breadth ──────────────────────────────────────────────────────────
    #: Fraction of members with close > SMA_20 on this bar (0.0-1.0).
    #: High breadth means the industry's move is broad-based; low
    #: breadth means a few names are carrying the EW index.
    pct_above_sma_20: float
    #: Fraction of members with close > SMA_50 on this bar (0.0-1.0).
    pct_above_sma_50: float

    # ── Data quality ─────────────────────────────────────────────────────
    #: ``True`` when all fields have reliable values (sufficient bars
    #: have elapsed for the longest-lookback computation — 120 bars
    #: for ``ew_vol_chg_60``). ``False`` bars have NaN in long-lookback
    #: fields and should not be read by consumers.
    data_sufficient: bool
