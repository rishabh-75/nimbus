#!/usr/bin/env python3
"""
tests/test_vix_gate.py — Tests for rebuilt grade formula (factor-backtest validated).

Grade now uses ONLY factors with positive r(PnL):
  MFI level (r=+0.039), Vol ratio (r=+0.042), RSI (r=+0.079), VIX flat (r=+0.096)

DROPPED (inverted per leave-one-out backtest):
  Score band, WR depth, DD+streak, BBW squeeze
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

PASS = 0; FAIL = 0; ERRORS = []
def _run(name, fn):
    global PASS, FAIL
    try:
        fn(); print(f"  ✓ {name}"); PASS += 1
    except (AssertionError, Exception) as e:
        print(f"  ✗ {name}: {e}"); FAIL += 1; ERRORS.append((name, str(e)))

from modules.scanner import _compute_verdict, _compute_grade

GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6, "—": 7}

def _row(**kw):
    base = {
        "dm_tier": "NONE", "dm_score": 50, "dm_entry": False,
        "dm_sizing": "SKIP", "dm_mfi": 40, "dm_wr": -40,
        "dm_dd": -5.0, "dm_streak": 2, "dm_bbw_slope": 0,
        "dm_pct_sma": -3.0, "vix_regime": "LOW", "dm_grade": "—",
        "is_friday": False, "dm_vol_ratio": 1.0, "dm_rsi": 45,
    }
    base.update(kw)
    return base

def _g(**kw):
    """Shorthand for _compute_grade with defaults."""
    defaults = dict(score=65, tier="SECONDARY", entry=True, wr=-50, mfi=45,
                    dd=-8, streak=2, bbw_slope=0, vix_regime="LOW",
                    vol_ratio=1.0, mfi_slope=0, bbw_pctl=50, rsi=45)
    defaults.update(kw)
    return _compute_grade(**defaults)


# ══════════════════════════════════════════════════════════════════════════════
# 1. MFI IS THE PRIMARY QUALITY FACTOR
# ══════════════════════════════════════════════════════════════════════════════

def test_mfi_factor():
    print("\n── MFI FACTOR (r=+0.039) ──")

    def t_mfi_high_beats_low():
        g_high = _g(mfi=60, rsi=45, vol_ratio=1.0)
        g_low = _g(mfi=35, rsi=45, vol_ratio=1.0)
        assert GRADE_ORD[g_high] < GRADE_ORD[g_low], f"MFI 60 ({g_high}) should beat MFI 35 ({g_low})"
    _run("mfi_high_beats_low", t_mfi_high_beats_low)

    def t_mfi_thresholds():
        g55 = _g(mfi=55, rsi=45, vol_ratio=1.0, vix_regime="LOW")
        g45 = _g(mfi=45, rsi=45, vol_ratio=1.0, vix_regime="LOW")
        g35 = _g(mfi=35, rsi=45, vol_ratio=1.0, vix_regime="LOW")
        assert GRADE_ORD[g55] <= GRADE_ORD[g45] <= GRADE_ORD[g35], \
            f"MFI should be monotonic: 55→{g55}, 45→{g45}, 35→{g35}"
    _run("mfi_thresholds_monotonic", t_mfi_thresholds)


# ══════════════════════════════════════════════════════════════════════════════
# 2. RSI ADDED AS QUALITY FACTOR
# ══════════════════════════════════════════════════════════════════════════════

def test_rsi_factor():
    print("\n── RSI FACTOR (r=+0.079, NEW) ──")

    def t_rsi_high_beats_low():
        g_high = _g(rsi=55, mfi=45, vol_ratio=1.0)
        g_low = _g(rsi=30, mfi=45, vol_ratio=1.0)
        assert GRADE_ORD[g_high] < GRADE_ORD[g_low], f"RSI 55 ({g_high}) should beat RSI 30 ({g_low})"
    _run("rsi_high_beats_low", t_rsi_high_beats_low)

    def t_rsi_none_doesnt_crash():
        g = _g(rsi=None)
        assert g in GRADE_ORD, f"RSI=None should not crash, got {g}"
    _run("rsi_none_no_crash", t_rsi_none_doesnt_crash)


# ══════════════════════════════════════════════════════════════════════════════
# 3. VOLUME RATIO — ONLY VALIDATED QUALITY FACTOR
# ══════════════════════════════════════════════════════════════════════════════

def test_vol_factor():
    print("\n── VOL RATIO (r=+0.042, only LOO-validated quality factor) ──")

    def t_vol_surge_helps():
        g_surge = _g(vol_ratio=2.0, mfi=45, rsi=45)
        g_dry = _g(vol_ratio=0.5, mfi=45, rsi=45)
        assert GRADE_ORD[g_surge] <= GRADE_ORD[g_dry], f"Vol 2.0 ({g_surge}) should >= Vol 0.5 ({g_dry})"
    _run("vol_surge_helps", t_vol_surge_helps)


# ══════════════════════════════════════════════════════════════════════════════
# 4. DROPPED FACTORS DON'T AFFECT GRADE
# ══════════════════════════════════════════════════════════════════════════════

def test_dropped_factors():
    print("\n── DROPPED FACTORS (should NOT affect grade) ──")

    def t_score_doesnt_matter():
        """Score band was inverted (r=-0.032). Removing improved r by +0.040."""
        g_high = _g(score=85, mfi=45, rsi=45, vol_ratio=1.0)
        g_low = _g(score=40, mfi=45, rsi=45, vol_ratio=1.0)
        assert g_high == g_low, f"Score should NOT affect grade: 85→{g_high}, 40→{g_low}"
    _run("score_band_dropped", t_score_doesnt_matter)

    def t_wr_depth_doesnt_matter():
        """WR depth was inverted. Removing improved r by +0.027."""
        g_deep = _g(wr=-90, mfi=45, rsi=45, vol_ratio=1.0)
        g_mod = _g(wr=-35, mfi=45, rsi=45, vol_ratio=1.0)
        assert g_deep == g_mod, f"WR depth should NOT affect grade: -90→{g_deep}, -35→{g_mod}"
    _run("wr_depth_dropped", t_wr_depth_doesnt_matter)

    def t_dd_doesnt_matter():
        """DD+streak was noise. Removing improved r by +0.006."""
        g_deep = _g(dd=-20, streak=5, mfi=45, rsi=45, vol_ratio=1.0)
        g_shallow = _g(dd=-3, streak=0, mfi=45, rsi=45, vol_ratio=1.0)
        assert g_deep == g_shallow, f"DD should NOT affect grade: -20→{g_deep}, -3→{g_shallow}"
    _run("dd_streak_dropped", t_dd_doesnt_matter)

    def t_bbw_doesnt_matter():
        """BBW squeeze was noise. Removing improved r by +0.008."""
        g_tight = _g(bbw_pctl=10, mfi=45, rsi=45, vol_ratio=1.0)
        g_wide = _g(bbw_pctl=90, mfi=45, rsi=45, vol_ratio=1.0)
        assert g_tight == g_wide, f"BBW should NOT affect grade: 10→{g_tight}, 90→{g_wide}"
    _run("bbw_pctl_dropped", t_bbw_doesnt_matter)

    def t_tier_doesnt_matter():
        """Tier bonus was noise (+0.001). PRIMARY and SEC get same grade."""
        g_pri = _g(tier="PRIMARY", mfi=45, rsi=45, vol_ratio=1.0)
        g_sec = _g(tier="SECONDARY", mfi=45, rsi=45, vol_ratio=1.0)
        assert g_pri == g_sec, f"Tier should NOT affect grade: PRI→{g_pri}, SEC→{g_sec}"
    _run("tier_bonus_dropped", t_tier_doesnt_matter)


# ══════════════════════════════════════════════════════════════════════════════
# 5. VIX FLAT ADDITION (backtest winner, r=+0.096)
# ══════════════════════════════════════════════════════════════════════════════

def test_vix_flat():
    print("\n── VIX FLAT (backtest winner, corr=+0.034) ──")

    def t_vix_ordering():
        """Panic > Elevated > Low > Normal for same quality."""
        grades = {}
        for vr in ("PANIC", "ELEVATED", "LOW", "NORMAL"):
            grades[vr] = GRADE_ORD[_g(vix_regime=vr, mfi=50, rsi=45, vol_ratio=1.2)]
        assert grades["PANIC"] <= grades["ELEVATED"] <= grades["LOW"] <= grades["NORMAL"], \
            f"VIX ordering broken: {grades}"
    _run("vix_ordering", t_vix_ordering)

    def t_panic_lifts_all():
        """Panic VIX +4 pts should lift grade for any quality."""
        g_norm = _g(vix_regime="NORMAL", mfi=35, rsi=35, vol_ratio=0.5)
        g_panic = _g(vix_regime="PANIC", mfi=35, rsi=35, vol_ratio=0.5)
        assert GRADE_ORD[g_panic] < GRADE_ORD[g_norm], \
            f"Panic should lift: NORMAL={g_norm}, PANIC={g_panic}"
    _run("panic_lifts_all", t_panic_lifts_all)

    def t_normal_no_vix_bonus():
        """Normal VIX = +0 (the dead zone, Sh 0.60)."""
        g = _g(vix_regime="NORMAL", mfi=35, rsi=35, vol_ratio=0.5)
        # With 0 quality pts + 0 VIX = D
        assert g == "D", f"Normal VIX + weak quality should be D, got {g}"
    _run("normal_no_vix_bonus", t_normal_no_vix_bonus)


# ══════════════════════════════════════════════════════════════════════════════
# 6. FRIDAY PENALTY
# ══════════════════════════════════════════════════════════════════════════════

def test_friday():
    print("\n── FRIDAY PENALTY ──")

    def t_friday_downgrades():
        g_mon = _g(is_friday=False, vix_regime="PANIC", mfi=50, rsi=50, vol_ratio=1.5)
        g_fri = _g(is_friday=True, vix_regime="PANIC", mfi=50, rsi=50, vol_ratio=1.5)
        assert GRADE_ORD[g_fri] > GRADE_ORD[g_mon], f"Friday should downgrade: Mon={g_mon}, Fri={g_fri}"
    _run("friday_downgrades", t_friday_downgrades)

    def t_friday_stressed_worse():
        g_fri_low = _g(is_friday=True, vix_regime="LOW", mfi=50, rsi=50, vol_ratio=1.5)
        g_fri_panic = _g(is_friday=True, vix_regime="PANIC", mfi=50, rsi=50, vol_ratio=1.5)
        # Both get Friday penalty but Panic gets -2 vs -1
        # Net: Panic still ahead because +4 VIX - 2 Friday = +2 net, vs LOW +2 VIX - 1 Friday = +1
        # So panic+friday should still be better than low+friday
        pass  # just verify no crash
    _run("friday_stressed_no_crash", t_friday_stressed_worse)


# ══════════════════════════════════════════════════════════════════════════════
# 7. SIZING — NO PANIC UPGRADE
# ══════════════════════════════════════════════════════════════════════════════

def test_sizing():
    print("\n── SIZING (grade-based, tier p=0.74) ──")

    def t_a_grade_gets_full():
        """A-grade SECONDARY → FULL (grade drives sizing, not tier)"""
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=80, dm_entry=True,
                                  dm_sizing="HALF", dm_grade="A", dm_wr=-55, dm_mfi=55,
                                  dm_rsi=50, dm_vol_ratio=1.5, vix_regime="PANIC"))
        assert "FULL" in v, f"A-grade should get FULL. Got: {v}"
    _run("a_grade_gets_full", t_a_grade_gets_full)

    def t_normal_vix_grade_gate():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=65, dm_entry=True,
                                  dm_sizing="SKIP", dm_grade="C+", dm_wr=-40, dm_mfi=45,
                                  vix_regime="NORMAL"))
        assert "SKIP" in v or "WATCH" in v, f"Normal VIX should gate low grades. Got: {v}"
        assert "Normal VIX" in v or "grade" in v.lower(), f"Should mention Normal VIX or grade. Got: {v}"
    _run("normal_vix_grade_gate", t_normal_vix_grade_gate)

    def t_trap_overrides_all():
        v = _compute_verdict(_row(dm_tier="PRIMARY", dm_score=25, dm_entry=True,
                                  dm_sizing="FULL", vix_regime="PANIC"))
        assert "AVOID" in v, f"TRAP overrides Panic. Got: {v}"
    _run("trap_overrides_panic", t_trap_overrides_all)


# ══════════════════════════════════════════════════════════════════════════════
# 8. VERDICT CONTENT — FLOW AS CONVICTION, DEPTH AS RISK
# ══════════════════════════════════════════════════════════════════════════════

def test_verdict_content():
    print("\n── VERDICT CONTENT (flow=conviction, depth=risk) ──")

    def t_strong_flow_in_verdict():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=75, dm_entry=True,
                                  dm_sizing="HALF", dm_grade="A", dm_mfi=62,
                                  dm_wr=-45, dm_dd=-6, dm_rsi=52, dm_vol_ratio=1.8,
                                  vix_regime="ELEVATED"))
        assert "money flow" in v or "flow" in v.lower(), f"Should mention flow: {v}"
    _run("strong_flow_in_verdict", t_strong_flow_in_verdict)

    def t_depth_as_risk():
        v = _compute_verdict(_row(dm_tier="SECONDARY", dm_score=70, dm_entry=True,
                                  dm_sizing="HALF", dm_grade="B", dm_mfi=40,
                                  dm_wr=-85, dm_dd=-22, dm_rsi=28,
                                  vix_regime="PANIC"))
        # Deep indicators should appear as warnings, not positive catalysts
        assert "extreme oversold" not in v or "capitulation" not in v, \
            f"Depth should be risk warning, not conviction: {v}"
    _run("depth_as_risk_not_conviction", t_depth_as_risk)

    def t_no_entry_unchanged():
        v = _compute_verdict(_row(dm_score=60, dm_mfi=15, dm_wr=-80, dm_dd=-18))
        assert "CAPITULATION" in v, f"No-entry path unchanged: {v}"
    _run("no_entry_path_intact", t_no_entry_unchanged)


# ══════════════════════════════════════════════════════════════════════════════
# 9. FULL QUALITY GRID — NEW FORMULA
# ══════════════════════════════════════════════════════════════════════════════

def test_quality_grid():
    print("\n── QUALITY GRID (new formula) ──")

    def t_grid_print():
        print(f"\n  {'Quality':14s}", end="")
        for vr in ("LOW", "NORMAL", "ELEVATED", "PANIC"):
            print(f"  {vr:10s}", end="")
        print()

        setups = [
            ("Weak flow",     35, 30, 0.5),
            ("OK flow",       45, 42, 1.0),
            ("Strong flow",   58, 52, 1.6),
            ("Max quality",   65, 55, 2.0),
        ]

        for label, mfi, rsi, vol in setups:
            print(f"  {label:14s}", end="")
            for vr in ("LOW", "NORMAL", "ELEVATED", "PANIC"):
                g = _g(mfi=mfi, rsi=rsi, vol_ratio=vol, vix_regime=vr)
                print(f"  {g:10s}", end="")
            print()
        print()
    _run("grid_visual", t_grid_print)

    def t_max_quality_gets_a_plus():
        g = _g(mfi=60, rsi=55, vol_ratio=2.0, vix_regime="PANIC")
        assert g == "A+", f"Max quality + Panic should be A+, got {g}"
    _run("max_quality_a_plus", t_max_quality_gets_a_plus)

    def t_weak_quality_panic_limited():
        g = _g(mfi=35, rsi=30, vol_ratio=0.5, vix_regime="PANIC")
        assert g not in ("A+", "A"), f"Weak + Panic should NOT be A/A+, got {g}"
    _run("weak_panic_capped", t_weak_quality_panic_limited)

    def t_strong_normal_beats_weak_panic():
        g_sn = _g(mfi=60, rsi=55, vol_ratio=2.0, vix_regime="NORMAL")
        g_wp = _g(mfi=35, rsi=30, vol_ratio=0.5, vix_regime="PANIC")
        assert GRADE_ORD[g_sn] <= GRADE_ORD[g_wp], \
            f"Strong+Normal ({g_sn}) should >= Weak+Panic ({g_wp})"
    _run("strong_normal_beats_weak_panic", t_strong_normal_beats_weak_panic)

    def t_grade_spread():
        """Must produce at least 4 distinct grades across scenarios."""
        grades = set()
        for mfi, rsi, vol, vr in [(35, 30, 0.5, "NORMAL"), (45, 40, 1.0, "NORMAL"),
                                    (50, 45, 1.0, "LOW"), (45, 42, 1.2, "ELEVATED"),
                                    (55, 50, 1.5, "ELEVATED"), (65, 55, 2.0, "PANIC")]:
            grades.add(_g(mfi=mfi, rsi=rsi, vol_ratio=vol, vix_regime=vr))
        assert len(grades) >= 4, f"Should produce ≥4 grades, got {len(grades)}: {grades}"
    _run("grade_spread_4plus", t_grade_spread)


# ══════════════════════════════════════════════════════════════════════════════
# 10. EDGE CASES
# ══════════════════════════════════════════════════════════════════════════════

def test_edge_cases():
    print("\n── EDGE CASES ──")

    def t_no_entry():
        assert _g(entry=False) == "—"
        assert _g(entry=False, tier="NONE") == "—"
    _run("no_entry_returns_dash", t_no_entry)

    def t_all_none():
        g = _compute_grade(0, "SECONDARY", True, None, 0, 0, 0, 0, "UNKNOWN", 0, 0, 0)
        assert g in GRADE_ORD
    _run("all_zeros_no_crash", t_all_none)

    def t_verdict_empty_dict():
        v = _compute_verdict({})
        assert isinstance(v, str)
    _run("verdict_empty_dict", t_verdict_empty_dict)


def test_sector_rs():
    """Sector RS + rotation divergence grade factors."""
    print("\n── SECTOR RS FACTOR ──")
    from modules.conviction import ConvictionEngine
    from modules.dual_mode import DualModeSignal

    eng = ConvictionEngine()

    def _sig(**kw):
        s = DualModeSignal()
        s.data_sufficient = True
        s.entry_triggered = True
        s.tier = "PRIMARY"
        s.wr_30 = -50; s.mfi = 50; s.vol_ratio = 1.0; s.rsi = 45
        s.dd_from_high = -6; s.red_streak = 2; s.pct_from_sma = -3.0
        s.above_sma = False; s.dual_score = 65; s.bbw_slope = 0
        s.bbw_pctl = 50; s.options_overlay = 0; s.options_detail = ""
        s.filing_overlay = 0; s.filing_detail = ""; s.is_trap = False
        s.dual_sizing = "HALF"; s.dual_label = "GOOD"
        s.entry_reason = "test"; s.core_met = True; s.atr = 10
        s.close = 1000; s.sma_20 = 1030; s.mfi_slope = 0
        for k, v in kw.items(): setattr(s, k, v)
        return s

    def _grade_with_ctx(rotation_label, div_lag=0, div_pair="", div_spread=0.0):
        sc = None
        if rotation_label is not None:
            sc = {"name": "Nifty Bank", "rotation": rotation_label,
                  "div_lag_count": div_lag, "div_top_pair": div_pair,
                  "div_top_spread": div_spread}
        r = eng.compute(_sig(), vix=20.0, sector_ctx=sc)
        return r.grade, r.sector_rs_impact, r.div_impact, r

    # LEADING should boost grade by +1 point
    def leading_boosts():
        g_lead, rs, _, _ = _grade_with_ctx("LEADING")
        g_none, _, _, _ = _grade_with_ctx(None)
        assert rs == 1, f"LEADING should give +1 impact, got {rs}"
        assert GRADE_ORD.get(g_lead, 7) <= GRADE_ORD.get(g_none, 7), \
            f"LEADING grade {g_lead} should be ≥ no-sector grade {g_none}"
    _run("leading_boosts_grade", leading_boosts)

    # LAGGING should penalize grade by -1 point
    def lagging_penalizes():
        g_lag, rs, _, _ = _grade_with_ctx("LAGGING")
        g_none, _, _, _ = _grade_with_ctx(None)
        assert rs == -1, f"LAGGING should give -1 impact, got {rs}"
        assert GRADE_ORD.get(g_lag, 7) >= GRADE_ORD.get(g_none, 7), \
            f"LAGGING grade {g_lag} should be ≤ no-sector grade {g_none}"
    _run("lagging_penalizes_grade", lagging_penalizes)

    # IMPROVING is neutral (0) — divergence handles catch-up directly
    def improving_neutral():
        _, rs, _, _ = _grade_with_ctx("IMPROVING")
        assert rs == 0, f"IMPROVING should give 0, got {rs}"
    _run("improving_neutral", improving_neutral)

    # INLINE is neutral (0)
    def inline_neutral():
        _, rs, _, _ = _grade_with_ctx("INLINE")
        assert rs == 0, f"INLINE should give 0, got {rs}"
    _run("inline_neutral", inline_neutral)

    # No sector data = no impact
    def no_sector_zero():
        _, rs, div, _ = _grade_with_ctx(None)
        assert rs == 0, f"No sector ctx should give 0 RS impact, got {rs}"
        assert div == 0, f"No sector ctx should give 0 div impact, got {div}"
    _run("no_sector_zero_impact", no_sector_zero)

    # Sector fields populate on ConvictionResult
    def result_fields():
        sc = {"name": "IT", "rotation": "LEADING", "div_lag_count": 0,
              "div_top_pair": "", "div_top_spread": 0.0}
        r = eng.compute(_sig(), vix=15.0, sector_ctx=sc)
        assert r.sector_name == "IT", f"Expected sector_name='IT', got '{r.sector_name}'"
        assert r.sector_rotation == "LEADING", f"Expected rotation='LEADING', got '{r.sector_rotation}'"
        assert r.sector_rs_impact == 1, f"Expected RS impact=1, got {r.sector_rs_impact}"
    _run("result_fields_populated", result_fields)

    # Checklist includes Sector RS row
    def checklist_has_sector_rs():
        sc = {"name": "Metal", "rotation": "LAGGING", "div_lag_count": 0,
              "div_top_pair": "", "div_top_spread": 0.0}
        r = eng.compute(_sig(), vix=20.0, sector_ctx=sc)
        rs_items = [c for c in r.checklist if c[1] == "Sector RS"]
        assert len(rs_items) == 1, f"Expected 1 Sector RS checklist item, got {len(rs_items)}"
        assert rs_items[0][0] == "fail", f"LAGGING should be 'fail' status, got '{rs_items[0][0]}'"
    _run("checklist_has_sector_rs", checklist_has_sector_rs)

    # Catalysts include sector when LEADING
    def catalysts_include_sector():
        sc = {"name": "Energy", "rotation": "LEADING", "div_lag_count": 0,
              "div_top_pair": "", "div_top_spread": 0.0}
        r = eng.compute(_sig(), vix=20.0, sector_ctx=sc)
        has_sector = any("leading" in c.lower() or "energy" in c.lower() for c in r.catalysts)
        assert has_sector, f"LEADING should appear in catalysts: {r.catalysts}"
    _run("catalysts_include_sector", catalysts_include_sector)

    # Risks include sector when LAGGING (no divergence)
    def risks_include_sector():
        sc = {"name": "IT", "rotation": "LAGGING", "div_lag_count": 0,
              "div_top_pair": "", "div_top_spread": 0.0}
        r = eng.compute(_sig(), vix=20.0, sector_ctx=sc)
        has_sector = any("lagging" in c.lower() for c in r.risks)
        assert has_sector, f"LAGGING should appear in risks: {r.risks}"
    _run("risks_include_sector", risks_include_sector)

    # ── ROTATION DIVERGENCE ───────────────────────────────────────────
    print("\n── ROTATION DIVERGENCE ──")

    # Divergence lag_count ≥ 1 gives +1 grade point
    def div_boosts_grade():
        g_div, _, div, _ = _grade_with_ctx("INLINE", div_lag=3, div_pair="CPSE", div_spread=12.0)
        g_none, _, _, _ = _grade_with_ctx("INLINE", div_lag=0)
        assert div == 1, f"div_lag_count≥1 should give +1, got {div}"
        assert GRADE_ORD.get(g_div, 7) <= GRADE_ORD.get(g_none, 7), \
            f"Divergence grade {g_div} should be ≥ no-div grade {g_none}"
    _run("div_boosts_grade", div_boosts_grade)

    # No divergence = no impact
    def div_zero_when_none():
        _, _, div, _ = _grade_with_ctx("INLINE", div_lag=0)
        assert div == 0, f"No divergence should give 0, got {div}"
    _run("div_zero_when_no_divergence", div_zero_when_none)

    # Divergence fields populate on ConvictionResult
    def div_result_fields():
        _, _, _, r = _grade_with_ctx("LAGGING", div_lag=5, div_pair="Energy", div_spread=15.3)
        assert r.div_lag_count == 5, f"Expected div_lag_count=5, got {r.div_lag_count}"
        assert r.div_top_pair == "Energy", f"Expected div_top_pair='Energy', got '{r.div_top_pair}'"
        assert r.div_top_spread == 15.3, f"Expected div_top_spread=15.3, got {r.div_top_spread}"
        assert r.div_impact == 1, f"Expected div_impact=1, got {r.div_impact}"
    _run("div_result_fields", div_result_fields)

    # Checklist shows rotation catch-up row when divergence active
    def div_checklist():
        _, _, _, r = _grade_with_ctx("INLINE", div_lag=3, div_pair="CPSE", div_spread=12.0)
        cu_items = [c for c in r.checklist if c[1] == "Rotation CU"]
        assert len(cu_items) == 1, f"Expected 1 Rotation CU item, got {len(cu_items)}"
        assert cu_items[0][0] == "pass", f"Catch-up should be 'pass', got '{cu_items[0][0]}'"
        assert "CPSE" in cu_items[0][3], f"Should mention top pair CPSE: {cu_items[0]}"
    _run("div_checklist_shown", div_checklist)

    # No checklist row when no divergence and sector data exists
    def div_no_checklist_when_zero():
        _, _, _, r = _grade_with_ctx("LEADING", div_lag=0)
        cu_items = [c for c in r.checklist if c[1] == "Rotation CU"]
        assert len(cu_items) == 0, f"No divergence should skip Rotation CU row, got {len(cu_items)}"
    _run("div_no_checklist_when_zero", div_no_checklist_when_zero)

    # LAGGING + divergence: catch-up catalyst overrides risk
    def div_overrides_lagging_risk():
        _, _, _, r = _grade_with_ctx("LAGGING", div_lag=4, div_pair="PSE", div_spread=10.0)
        has_catchup = any("catch-up" in c.lower() or "rotation" in c.lower() for c in r.catalysts)
        has_lagging_risk = any("lagging" in c.lower() for c in r.risks)
        assert has_catchup, f"Divergence should add catch-up catalyst: {r.catalysts}"
        assert not has_lagging_risk, f"Divergence should suppress lagging risk: {r.risks}"
    _run("div_overrides_lagging_risk", div_overrides_lagging_risk)

    # LAGGING + divergence: -1 RS + +1 div = net 0 grade change
    def div_offsets_lagging():
        g_lag_div, rs, div, _ = _grade_with_ctx("LAGGING", div_lag=2, div_pair="X", div_spread=8.0)
        g_none, _, _, _ = _grade_with_ctx(None)
        assert rs == -1 and div == 1, f"Expected RS=-1, div=+1, got RS={rs}, div={div}"
        assert g_lag_div == g_none, f"LAGGING(-1)+div(+1) should equal no-sector: {g_lag_div} vs {g_none}"
    _run("div_offsets_lagging_penalty", div_offsets_lagging)


def test_quality_rank():
    """Quality rank — continuous within-grade ordering."""
    print("\n── QUALITY RANK ──")
    from modules.conviction import ConvictionEngine
    from modules.dual_mode import DualModeSignal

    eng = ConvictionEngine()

    def _sig(**kw):
        s = DualModeSignal()
        s.data_sufficient = True; s.entry_triggered = True; s.tier = "PRIMARY"
        s.wr_30 = -50; s.mfi = 50; s.vol_ratio = 1.0; s.rsi = 45
        s.dd_from_high = -7; s.red_streak = 2; s.pct_from_sma = -3.0
        s.above_sma = False; s.dual_score = 65; s.bbw_slope = 0; s.bbw_pctl = 50
        s.options_overlay = 0; s.options_detail = ""; s.filing_overlay = 0
        s.filing_detail = ""; s.is_trap = False; s.dual_sizing = "HALF"
        s.dual_label = "GOOD"; s.entry_reason = "test"; s.core_met = True
        s.atr = 10; s.close = 1000; s.sma_20 = 1030; s.mfi_slope = 0
        for k, v in kw.items(): setattr(s, k, v)
        return s

    # Higher MFI → higher QR
    def mfi_ranks():
        r_hi = eng.compute(_sig(mfi=72), vix=20.0)
        r_lo = eng.compute(_sig(mfi=40), vix=20.0)
        assert r_hi.quality_rank > r_lo.quality_rank, \
            f"MFI 72 ({r_hi.quality_rank}) should rank above MFI 40 ({r_lo.quality_rank})"
    _run("qr_mfi_ranks", mfi_ranks)

    # Moderate DD beats deep DD
    def dd_sweet_spot():
        r_mod = eng.compute(_sig(dd_from_high=-7.0), vix=20.0)
        r_deep = eng.compute(_sig(dd_from_high=-25.0), vix=20.0)
        assert r_mod.quality_rank > r_deep.quality_rank, \
            f"DD -7% ({r_mod.quality_rank}) should rank above DD -25% ({r_deep.quality_rank})"
    _run("qr_dd_sweet_spot", dd_sweet_spot)

    # SMA sweet spot
    def sma_sweet_spot():
        r_sweet = eng.compute(_sig(pct_from_sma=-3.0), vix=20.0)
        r_far = eng.compute(_sig(pct_from_sma=-12.0), vix=20.0)
        assert r_sweet.quality_rank > r_far.quality_rank, \
            f"SMA -3% ({r_sweet.quality_rank}) should rank above SMA -12% ({r_far.quality_rank})"
    _run("qr_sma_sweet_spot", sma_sweet_spot)

    # Volume surge helps
    def vol_ranks():
        r_hi = eng.compute(_sig(vol_ratio=2.0), vix=20.0)
        r_lo = eng.compute(_sig(vol_ratio=0.3), vix=20.0)
        assert r_hi.quality_rank > r_lo.quality_rank, \
            f"Vol 2.0x ({r_hi.quality_rank}) should rank above Vol 0.3x ({r_lo.quality_rank})"
    _run("qr_vol_ranks", vol_ranks)

    # No entry → QR = 0
    def no_entry_zero():
        s = _sig()
        s.entry_triggered = False
        r = eng.compute(s, vix=20.0)
        assert r.quality_rank == 0, f"No entry should give QR=0, got {r.quality_rank}"
    _run("qr_no_entry_zero", no_entry_zero)

    # Range: 0-100
    def qr_range():
        r_best = eng.compute(_sig(mfi=95, rsi=90, vol_ratio=3.0, dd_from_high=-7.0,
                                   pct_from_sma=-3.0, options_overlay=8), vix=27.9)
        r_worst = eng.compute(_sig(mfi=5, rsi=10, vol_ratio=0.1, dd_from_high=-30.0,
                                    pct_from_sma=-15.0, options_overlay=-8), vix=27.9)
        assert 0 <= r_worst.quality_rank <= 100, f"QR out of range: {r_worst.quality_rank}"
        assert 0 <= r_best.quality_rank <= 100, f"QR out of range: {r_best.quality_rank}"
        assert r_best.quality_rank > 70, f"Perfect setup should have QR>70, got {r_best.quality_rank}"
        assert r_worst.quality_rank < 30, f"Terrible setup should have QR<30, got {r_worst.quality_rank}"
    _run("qr_range", qr_range)

    # Composite: ABB-like > ASIANPAINT-like
    def abb_beats_asianpaint():
        abb = eng.compute(_sig(mfi=72, rsi=49, vol_ratio=0.9, dd_from_high=-9.0, pct_from_sma=-3.4), vix=27.9)
        ap = eng.compute(_sig(mfi=45, rsi=46, vol_ratio=1.2, dd_from_high=-23.4, pct_from_sma=-3.3), vix=27.9)
        assert abb.quality_rank > ap.quality_rank, \
            f"ABB-like ({abb.quality_rank}) should rank above ASIANPAINT-like ({ap.quality_rank})"
    _run("qr_abb_beats_asianpaint", abb_beats_asianpaint)


if __name__ == "__main__":
    print("=" * 60)
    print("NIMBUS Grade Tests (rebuilt — factor-backtest validated)")
    print("=" * 60)
    test_mfi_factor()
    test_rsi_factor()
    test_vol_factor()
    test_dropped_factors()
    test_vix_flat()
    test_friday()
    test_sizing()
    test_verdict_content()
    test_quality_grid()
    test_edge_cases()
    test_sector_rs()
    test_quality_rank()
    print(f"\n{'=' * 60}")
    print(f"RESULTS: {PASS} passed, {FAIL} failed")
    print("=" * 60)
    if ERRORS:
        for n, e in ERRORS: print(f"  {n}: {e}")
    import sys; sys.exit(1 if FAIL > 0 else 0)
