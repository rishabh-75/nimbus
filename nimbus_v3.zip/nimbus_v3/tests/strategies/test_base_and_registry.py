"""Tests for strategies.base and strategies.registry."""
from __future__ import annotations

import dataclasses

import pandas as pd
import pytest

from nimbus_v3.core.context import (
    ContextBundle, MarketContext, SectorContext,
)
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import RSRegime, SetupType, VIXRegime
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal
from nimbus_v3.strategies.registry import StrategyRegistry


# ══════════════════════════════════════════════════════════════════════════════
# StrategySignal
# ══════════════════════════════════════════════════════════════════════════════

def _signal(**overrides) -> StrategySignal:
    base = dict(
        strategy_name="Test",
        symbol="RELIANCE",
        setup_type=SetupType.MEAN_REVERSION,
        asof_date=pd.Timestamp("2024-05-01"),
        priority=50,
    )
    base.update(overrides)
    return StrategySignal(**base)


def test_signal_is_frozen() -> None:
    s = _signal()
    with pytest.raises(dataclasses.FrozenInstanceError):
        s.priority = 99  # type: ignore[misc]


def test_signal_asof_date_coerced_to_timestamp() -> None:
    s = _signal(asof_date="2024-05-01")
    assert isinstance(s.asof_date, pd.Timestamp)


def test_signal_direction_validation() -> None:
    _signal(direction="LONG")
    _signal(direction="SHORT")
    with pytest.raises(ValueError, match="direction"):
        _signal(direction="invalid")


# ══════════════════════════════════════════════════════════════════════════════
# Registry
# ══════════════════════════════════════════════════════════════════════════════

class _FakeStrategy:
    """Minimal Strategy implementation for registry tests."""
    def __init__(self, *, name, setup_type, priority, fires=True, accepts_all=True):
        self.name = name
        self.setup_type = setup_type
        self.priority = priority
        self._fires = fires
        self._accepts_all = accepts_all

    def accepts(self, symbol_meta):    # noqa: ARG002
        return self._accepts_all

    def evaluate(self, *, symbol, state, contexts):
        if not self._fires:
            return None
        return StrategySignal(
            strategy_name=self.name, symbol=symbol,
            setup_type=self.setup_type,
            asof_date=contexts.asof_date, priority=self.priority,
        )


def _ctx_bundle() -> ContextBundle:
    asof = pd.Timestamp("2024-05-01")
    return ContextBundle(
        symbol="R", asof_date=asof,
        market=MarketContext(asof_date=asof, vix_value=None,
                              vix_regime=VIXRegime.NORMAL, vix_high_streak=0),
        sector=SectorContext(asof_date=asof, symbol="R", sector_name="X",
                               sector_type=None, rs_regime=RSRegime.NEUTRAL,
                               rs_20d=0.0, realized_vol_20d=0.0),
    )


def _dummy_state() -> SignalState:
    return SignalState(
        symbol="R", bar_date=pd.Timestamp("2024-05-01"), bar_index=200,
        open=100.0, high=100.0, low=100.0, close=100.0, volume=1e6,
        sma_10=100.0, sma_20=100.0, sma_50=100.0, sma_200=100.0,
        wr_14=0.0, wr_20=0.0, wr_30=0.0, wr_50=0.0,
        rsi_14=50.0, mfi_14=50.0, mfi_slope_3=0.0,
        adx_14=20.0, atr_14=1.0, atr_14_pct=1.0,
        bb_20_1s_upper=102.0, bb_20_1s_mid=100.0, bb_20_1s_lower=98.0, bb_20_1s_pct=0.5,
        bb_20_2s_upper=104.0, bb_20_2s_lower=96.0,
        bbw_20_2s=8.0, bbw_20_2s_slope=0.0, bbw_20_2s_pctl=50.0,
        pct_from_sma_20=0.0, pct_from_sma_50=0.0, pct_from_sma_200=0.0,
        above_sma_20=True, above_sma_50=True, above_sma_200=True,
        dd_from_high_20=0.0, dd_from_high_50=0.0,
        red_streak=0, green_streak=0,
        vol_ratio_20=1.0, roc_5=0.0, roc_10=0.0, roc_20=0.0,
        data_sufficient=True,
    )


def test_registry_sorts_by_priority_desc() -> None:
    reg = StrategyRegistry()
    low = _FakeStrategy(name="Low", setup_type=SetupType.MEAN_REVERSION, priority=10)
    high = _FakeStrategy(name="High", setup_type=SetupType.BREAKOUT, priority=90)
    mid = _FakeStrategy(name="Mid", setup_type=SetupType.RIDE, priority=50)
    # Register in random order.
    reg.register(mid)
    reg.register(low)
    reg.register(high)

    meta = SymbolMeta(symbol="R")
    results = reg.evaluate_all(symbol="R", symbol_meta=meta,
                                 state=_dummy_state(), contexts=_ctx_bundle())
    assert [s.strategy_name for s in results] == ["High", "Mid", "Low"]


def test_registry_honors_accepts() -> None:
    reg = StrategyRegistry()
    reg.register(_FakeStrategy(
        name="EquityOnly", setup_type=SetupType.BREAKOUT,
        priority=50, accepts_all=False,
    ))
    meta = SymbolMeta(symbol="R")
    results = reg.evaluate_all(symbol="R", symbol_meta=meta,
                                 state=_dummy_state(), contexts=_ctx_bundle())
    assert results == []


def test_registry_drops_none_results() -> None:
    reg = StrategyRegistry()
    reg.register(_FakeStrategy(
        name="NeverFires", setup_type=SetupType.BREAKOUT,
        priority=50, fires=False,
    ))
    reg.register(_FakeStrategy(
        name="AlwaysFires", setup_type=SetupType.MEAN_REVERSION,
        priority=40, fires=True,
    ))
    meta = SymbolMeta(symbol="R")
    results = reg.evaluate_all(symbol="R", symbol_meta=meta,
                                 state=_dummy_state(), contexts=_ctx_bundle())
    assert len(results) == 1
    assert results[0].strategy_name == "AlwaysFires"


def test_registry_iteration_and_len() -> None:
    reg = StrategyRegistry()
    assert len(reg) == 0
    reg.register(_FakeStrategy(
        name="A", setup_type=SetupType.RIDE, priority=30,
    ))
    reg.register(_FakeStrategy(
        name="B", setup_type=SetupType.RIDE, priority=30,
    ))
    assert len(reg) == 2
    names = [s.name for s in reg]
    assert names == ["A", "B"]
