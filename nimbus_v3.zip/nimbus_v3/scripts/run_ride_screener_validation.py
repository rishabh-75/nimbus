"""Validation/calibration script for the shipped RIDE screener.

Two distinct sections, each with its own epistemic framing:

  SECTION 1 — CALIBRATION CHECK
    Purpose: confirm the shipped screener matches operator visual
    expectations on 8 known example symbols. Sanity check on the
    implementation, NOT an edge claim.

    For each example, looks at whether the screener fired in the
    expected window (positive examples) or correctly stayed quiet
    (failure-mode examples).

  SECTION 2 — DESCRIPTIVE WALK-FORWARD
    Purpose: report the universe-wide forward-return profile of the
    shipped screener. Operational context — "what kind of fwd lift
    does this screener show in aggregate?" — NOT validation.

    NO ship rule. NO pass/fail verdict line. The screener's
    classification (screener for manual chart selection, NOT
    validated forward-return alpha) is UNCHANGED regardless of
    what the numbers show.

    This matters because the screener's parameters were calibrated
    to charts AFTER the original walk-forward failed. Re-running
    walk-forward on those calibrated parameters and using the
    result as ship evidence would be methodologically tainted (same
    universe, calibration loop). The output here is descriptive
    only — for operator awareness of what the screener's bar-level
    return profile looks like, not for promotion.

If the descriptive numbers happen to be very strong, that would be
INTERESTING but not actionable here. The legitimate next step would
be a fresh research thread with a properly held-out test set that
hasn't been touched by parameter calibration.

Output: scripts/output/ride_screener_validation.txt
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

# Make project root importable
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import (
    ACTIVE_WINDOW,
    compute_ride_init_active,
)
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("ride_screener_validation")


_EQ_CACHE_DIR: Path = _ROOT / "data" / "cache" / "enriched"
_OUT_PATH: Path = _ROOT / "scripts" / "output" / "ride_screener_validation.txt"


# ══════════════════════════════════════════════════════════════════════
# Calibration set — 8 example symbols from operator screenshots
# ══════════════════════════════════════════════════════════════════════

#: Positive examples — operator marked these as showing successful
#: ride initiation. Date is the approximate transition bar in IST;
#: we look for active fire within ±15 bars of that date.
_POSITIVE_EXAMPLES: tuple[tuple[str, str], ...] = (
    ("MOSCHIP",   "2026-04-01"),
    ("DATAPATTNS", "2026-04-15"),
    ("TATACONSUM", "2026-04-15"),
    ("BEML",      "2026-04-01"),
)

#: Failure-mode examples — operator marked these as patterns the
#: screener should NOT fire on (or should suppress quickly).
_FAILURE_EXAMPLES: tuple[tuple[str, str, str], ...] = (
    ("KIRLOSENG", "2026-03-20", "detached_breakout"),
    ("TITAN",    "2026-03-20", "detached_breakout"),
    ("ONGC",     "2026-04-01", "single_bar_gap_through"),
    ("HINDALCO", "2022-01-04", "ride_didnt_materialize"),
)

#: Window around the marked date to inspect for fire.
_CHECK_WINDOW_DAYS: int = 15


# ══════════════════════════════════════════════════════════════════════
# Walk-forward parameters (descriptive only)
# ══════════════════════════════════════════════════════════════════════

_N_FOLDS: int = 4
_PURGE_BARS: int = 10

_DIV_WIDE: str = "═" * 78
_DIV_THIN: str = "─" * 78


# ══════════════════════════════════════════════════════════════════════
# Data prep — same pattern as other research scripts
# ══════════════════════════════════════════════════════════════════════

def _prepare_data() -> dict:
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    if not raw_panel:
        raise RuntimeError("Equity panel empty — no cached data available")
    log.info("Equity panel: %d symbols", len(raw_panel))

    log.info("Enriching (cache-first)...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    hits = misses = 0
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
            hits += 1
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
                misses += 1
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched: %d symbols (%d hits, %d misses)",
             len(enriched_panel), hits, misses)

    log.info("Attaching forward returns...")
    panel_w_fwd: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        panel_w_fwd[sym] = add_forward_returns(df)

    return {"panel_w_fwd": panel_w_fwd}


# ══════════════════════════════════════════════════════════════════════
# Section 1 — Calibration check
# ══════════════════════════════════════════════════════════════════════

def _check_positive_example(
    sym: str, date_str: str, panel: dict[str, pd.DataFrame],
) -> dict:
    """For a positive example, check whether RIDE fires within
    ±_CHECK_WINDOW_DAYS of the marked date."""
    df = panel.get(sym)
    if df is None:
        return {
            "sym": sym, "marked_date": date_str,
            "found": False, "reason": "symbol not in panel",
        }
    target = pd.Timestamp(date_str)
    active = compute_ride_init_active(df)
    # Date-window mask: bars within ±_CHECK_WINDOW_DAYS of target
    window_start = target - pd.Timedelta(days=_CHECK_WINDOW_DAYS)
    window_end = target + pd.Timedelta(days=_CHECK_WINDOW_DAYS)
    in_window = (active.index >= window_start) & (active.index <= window_end)
    fires_in_window = active[in_window]
    if not fires_in_window.any():
        return {
            "sym": sym, "marked_date": date_str,
            "found": False, "reason": "no active fire in window",
            "n_bars_active": 0,
        }
    fire_dates = fires_in_window.index[fires_in_window].tolist()
    return {
        "sym": sym, "marked_date": date_str,
        "found": True,
        "n_bars_active": int(fires_in_window.sum()),
        "first_fire": fire_dates[0].date(),
        "last_fire": fire_dates[-1].date(),
    }


def _check_failure_example(
    sym: str, date_str: str, mode: str, panel: dict[str, pd.DataFrame],
) -> dict:
    """For a failure-mode example, check whether the screener
    correctly stays quiet (or quickly disengages) around the
    marked date."""
    df = panel.get(sym)
    if df is None:
        return {
            "sym": sym, "marked_date": date_str, "mode": mode,
            "checked": False, "reason": "symbol not in panel",
        }
    target = pd.Timestamp(date_str)
    active = compute_ride_init_active(df)
    window_start = target - pd.Timedelta(days=_CHECK_WINDOW_DAYS)
    window_end = target + pd.Timedelta(days=_CHECK_WINDOW_DAYS)
    in_window = (active.index >= window_start) & (active.index <= window_end)
    fires_in_window = active[in_window]
    n_active = int(fires_in_window.sum())
    return {
        "sym": sym, "marked_date": date_str, "mode": mode,
        "checked": True,
        "n_bars_active_in_window": n_active,
        # For failure modes we WANT n_active to be small/zero. Note
        # n_active > 0 doesn't strictly mean "broken" — the
        # screener could fire correctly on a different bar in the
        # ±15d window that ISN'T the bad pattern. But if n_active
        # is high (say >5), it's worth investigating.
    }


# ══════════════════════════════════════════════════════════════════════
# Section 2 — Descriptive walk-forward
# ══════════════════════════════════════════════════════════════════════

def _make_folds(
    dates: pd.DatetimeIndex, n_folds: int,
) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    start = dates.min()
    end = dates.max()
    total = end - start
    chunk = total / (n_folds + 1)
    folds = []
    for i in range(n_folds):
        train_end = start + chunk * (i + 1)
        test_start = train_end + pd.Timedelta(days=_PURGE_BARS)
        test_end = start + chunk * (i + 2)
        folds.append((train_end, test_start, test_end))
    return folds


def _compute_active_for_panel(panel: dict[str, pd.DataFrame]) -> dict:
    """Pre-compute the active series for every symbol once. Returns
    {sym: active_series}."""
    out = {}
    for sym, df in panel.items():
        try:
            out[sym] = compute_ride_init_active(df)
        except Exception:    # noqa: BLE001
            out[sym] = pd.Series(dtype=bool)
    return out


def _aggregate_lift(
    panel: dict[str, pd.DataFrame],
    active_by_sym: dict[str, pd.Series],
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
    horizon: int,
) -> dict:
    fwd_col = f"fwd_ret_{horizon}d"
    active_returns: list[float] = []
    baseline_returns: list[float] = []
    for sym, df in panel.items():
        if fwd_col not in df.columns:
            continue
        active = active_by_sym.get(sym)
        if active is None or active.empty:
            continue
        in_range = (df.index >= date_start) & (df.index <= date_end)
        sub_df = df.loc[in_range]
        if sub_df.empty:
            continue
        # Align active to sub_df
        sub_active = active.reindex(sub_df.index, fill_value=False)
        fwd = sub_df[fwd_col]
        valid = fwd.notna()
        active_vals = fwd[sub_active & valid].values
        baseline_vals = fwd[valid].values
        active_returns.extend(active_vals.tolist())
        baseline_returns.extend(baseline_vals.tolist())

    if not active_returns or not baseline_returns:
        return {
            "n_active": len(active_returns),
            "n_baseline": len(baseline_returns),
            "mean_active_pp": 0.0,
            "mean_baseline_pp": 0.0,
            "lift_pp": 0.0,
        }
    mean_a = float(np.mean(active_returns)) * 100
    mean_b = float(np.mean(baseline_returns)) * 100
    return {
        "n_active": len(active_returns),
        "n_baseline": len(baseline_returns),
        "mean_active_pp": mean_a,
        "mean_baseline_pp": mean_b,
        "lift_pp": mean_a - mean_b,
    }


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data...")
    try:
        prepared = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return
    panel = prepared["panel_w_fwd"]

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("RIDE SCREENER — VALIDATION & CALIBRATION")
        emit(_DIV_WIDE)
        emit("This script measures the SHIPPED RIDE screener's")
        emit("behavior. It does NOT validate edge or upgrade the")
        emit("screener's classification.")
        emit("")
        emit("The shipped screener is, and remains, a SCREENER for")
        emit("manual chart review — NOT a validated forward-return")
        emit("alpha signal. The original walk-forward (with longer")
        emit("parameters) showed no shippable edge across the")
        emit("universe; current parameters were calibrated to")
        emit("operator visual judgment, not to forward returns.")
        emit("")
        emit("Numbers below are descriptive context. They are NOT")
        emit("ship evidence — running walk-forward on calibrated")
        emit("parameters and treating the result as validation would")
        emit("be a methodological loop we explicitly avoid.")
        emit("")

        # ════════════════════════════════════════════════════════
        # SECTION 1 — Calibration check
        # ════════════════════════════════════════════════════════
        emit(_DIV_WIDE)
        emit("SECTION 1 — CALIBRATION CHECK")
        emit(_DIV_WIDE)
        emit("Goal: confirm the shipped screener matches operator")
        emit("visual expectations on 8 known example charts.")
        emit("Implementation correctness, NOT edge validation.")
        emit("")
        emit(f"Window per example: ±{_CHECK_WINDOW_DAYS} calendar days")
        emit("around the marked transition date.")
        emit("")

        emit("─── Positive examples (screener should fire) ───")
        emit("")
        positive_results = []
        for sym, date_str in _POSITIVE_EXAMPLES:
            r = _check_positive_example(sym, date_str, panel)
            positive_results.append(r)
            if not r["found"]:
                emit(f"  ✗ {sym:<14} marked={date_str}  "
                     f"NO ACTIVE FIRE — {r['reason']}")
            else:
                emit(f"  ✓ {sym:<14} marked={date_str}  "
                     f"fired {r['n_bars_active']} bars "
                     f"({r['first_fire']} → {r['last_fire']})")
        emit("")

        emit("─── Failure-mode examples (screener should suppress) ───")
        emit("")
        failure_results = []
        for sym, date_str, mode in _FAILURE_EXAMPLES:
            r = _check_failure_example(sym, date_str, mode, panel)
            failure_results.append(r)
            if not r["checked"]:
                emit(f"  ? {sym:<14} marked={date_str}  "
                     f"COULD NOT CHECK — {r['reason']}")
                continue
            n = r["n_bars_active_in_window"]
            note = (
                "GOOD — quiet" if n == 0 else
                f"WORTH INSPECTING — {n} active bars in ±{_CHECK_WINDOW_DAYS}d window"
            )
            emit(f"    {sym:<14} marked={date_str:<11} mode={mode:<24} "
                 f"n_active={n:>3}  ({note})")
        emit("")

        # Calibration summary
        n_pos_found = sum(1 for r in positive_results if r["found"])
        n_pos_total = len(positive_results)
        n_fail_quiet = sum(
            1 for r in failure_results
            if r.get("checked") and r.get("n_bars_active_in_window", 999) == 0
        )
        n_fail_total = sum(1 for r in failure_results if r.get("checked"))
        emit("Calibration summary:")
        emit(f"  Positive examples firing: {n_pos_found}/{n_pos_total}")
        emit(f"  Failure examples staying quiet: {n_fail_quiet}/{n_fail_total}")
        emit("")
        emit("Interpretation: this measures whether the SHIPPED")
        emit("screener's mechanical criteria match the patterns")
        emit("operator visually identifies. Failures of either")
        emit("count are debugging signals, NOT edge signals.")
        emit("")

        # ════════════════════════════════════════════════════════
        # SECTION 2 — Descriptive walk-forward
        # ════════════════════════════════════════════════════════
        emit(_DIV_WIDE)
        emit("SECTION 2 — DESCRIPTIVE WALK-FORWARD")
        emit(_DIV_WIDE)
        emit("Universe-wide forward-return profile of bars where")
        emit("the shipped screener is active. Reported across 4")
        emit("walk-forward folds at fwd_5d / fwd_10d / fwd_20d.")
        emit("")
        emit("THIS IS NOT VALIDATION. The screener's classification")
        emit("(screener for manual review, NOT alpha) is unchanged")
        emit("regardless of these numbers. They are operational")
        emit("context only — what the screener's aggregate forward-")
        emit("return profile looks like.")
        emit("")
        emit("If you want to act on these numbers as edge evidence,")
        emit("the legitimate path is a fresh research thread with a")
        emit("properly held-out test set. NOT this.")
        emit("")

        # Pre-compute active series once
        log.info("Computing active series for all symbols...")
        active_by_sym = _compute_active_for_panel(panel)
        n_total_active = sum(
            int(s.sum()) for s in active_by_sym.values() if not s.empty
        )
        log.info("Total active bar-symbols in panel: %d", n_total_active)
        emit(f"Total active bar-symbols across panel: {n_total_active:,}")
        emit("")

        # Find date range
        all_dates = pd.DatetimeIndex([])
        for s in active_by_sym.values():
            if not s.empty:
                all_dates = all_dates.union(s.index)
        valid_dates = all_dates.sort_values()
        folds = _make_folds(valid_dates, _N_FOLDS)
        emit("Fold boundaries:")
        for i, (te, ts_s, ts_e) in enumerate(folds):
            emit(f"  Fold {i+1}: train → {te.date()}, "
                 f"test {ts_s.date()} → {ts_e.date()}")
        emit("")

        # Descriptive numbers per fold per horizon
        for horizon in (5, 10, 20):
            emit(_DIV_THIN)
            emit(f"  fwd_{horizon}d profile")
            emit(_DIV_THIN)
            emit(f"  {'FOLD':<5} {'TRAIN_LIFT':>11} {'TRAIN_N':>10} "
                 f"{'TEST_LIFT':>11} {'TEST_N':>10}")
            train_test_lifts = []
            for fi, (train_end, test_start, test_end) in enumerate(folds):
                train_start = valid_dates.min()
                train_stats = _aggregate_lift(
                    panel, active_by_sym, train_start, train_end, horizon,
                )
                test_stats = _aggregate_lift(
                    panel, active_by_sym, test_start, test_end, horizon,
                )
                train_test_lifts.append(test_stats["lift_pp"])
                emit(f"  {fi+1:<5} "
                     f"{train_stats['lift_pp']:>+10.2f}pp "
                     f"{train_stats['n_active']:>10d} "
                     f"{test_stats['lift_pp']:>+10.2f}pp "
                     f"{test_stats['n_active']:>10d}")
            mean_test_lift = float(np.mean(train_test_lifts))
            same_sign = sum(
                1 for li in train_test_lifts
                if (li >= 0) == (mean_test_lift >= 0)
            )
            agreement = (
                same_sign / len(train_test_lifts)
                if train_test_lifts else 0.0
            )
            emit("")
            emit(f"  Mean test lift: {mean_test_lift:+.2f}pp  |  "
                 f"Sign agreement: {agreement:.0%}")
            emit("")

        emit(_DIV_WIDE)
        emit("FINAL NOTE")
        emit(_DIV_WIDE)
        emit("Section 1 tells you whether the implementation matches")
        emit("operator visual expectations. Failures are debugging")
        emit("signals.")
        emit("")
        emit("Section 2 tells you the descriptive forward-return")
        emit("profile of the screener. It is NOT a ship verdict and")
        emit("the screener's classification is unchanged either way.")
        emit("")
        emit("Methodological note: parameters were calibrated to")
        emit("operator-marked charts AFTER the original walk-forward")
        emit("with longer parameters showed no shippable edge.")
        emit("Re-running walk-forward on the calibrated parameters")
        emit("inside the SAME universe used for calibration creates a")
        emit("methodological loop. Treating these numbers as ship")
        emit("evidence requires a fresh research thread with held-")
        emit("out data — not this script.")
        emit(_DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
