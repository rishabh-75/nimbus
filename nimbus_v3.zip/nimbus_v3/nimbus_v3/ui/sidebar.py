"""nimbus_v3.ui.sidebar — fixed-width left-rail trading controls.

Responsibilities
────────────────
1. **Symbol selection.** Combo + manual-entry + GO button emit
   :attr:`symbol_changed(str)` when the operator picks a symbol.
2. **Refresh trigger.** :attr:`refresh_clicked` fires when the
   operator asks to reload the current symbol.
3. **Rendering view models.** ``set_breadth(...)``,
   ``apply_industry_view(IndustryClassificationView)``,
   ``set_options_context(OptionsContext)`` — pure label updates
   against frozen dataclasses produced by the
   :mod:`nimbus_v3.ui.presenters` builders.

The sidebar carries every contextual readout for the active symbol
— industry hierarchy, options overlay levels + greeks, BB ride
status (``KEY LEVELS & STATS``). The chart now occupies the full
width of the centre column, with the previous Workflow Analysis
right-rail eliminated.

Non-responsibilities (deliberately)
───────────────────────────────────
- No symbol/spot/Δ% echo. The Dashboard's centre header carries that
  already; sidebar duplication was a redundancy.
- No domain-type interpretation. Threshold bucketing, colour rules,
  and label phrasing live in the presenter package.
- No strategy-mode toggle, no MR/Ride dual panels — those concepts
  were deleted with the strategies / scanner / conviction refactor.

Public API (locked)
───────────────────
    Signals:
        :attr:`symbol_changed(str)`
        :attr:`refresh_clicked()`

    Methods — selection:
        :meth:`set_universe(universe)`
        :meth:`set_default_symbols(symbols)`
        :meth:`set_selected_symbol(symbol)`
        :meth:`current_symbol`

    Methods — rendering:
        :meth:`set_breadth(BreadthSnapshot, RegimeState)`
        :meth:`apply_industry_view(IndustryClassificationView)`
        :meth:`set_options_context(OptionsContext | None)`
        :meth:`clear()`
"""
from __future__ import annotations

import logging
from collections.abc import Iterable

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QComboBox, QCheckBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QScrollArea, QVBoxLayout, QWidget,
)

from nimbus_v3.core.context import OptionsContext
from nimbus_v3.core.types import ExpiryRisk, GEXRegime
from nimbus_v3.core.universe import Universe
from nimbus_v3.ui.presenters import (
    EMPTY_INDUSTRY_VIEW,
    IndustryClassificationView,
)
from nimbus_v3.ui.theme import (
    BORDER, EM, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED, SURFACE,
    VIOLET, WHITE,
)
from nimbus_v3.ui.widgets.components import PanelFrame


logger = logging.getLogger(__name__)


def _fmt_price(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    return f"{v:,.2f}"


def _fmt_ratio(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    return f"{v:.2f}"


def _fmt_signed(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    if abs(v) >= 1_000_000:
        return f"{v/1_000_000:+,.1f}M"
    if abs(v) >= 1_000:
        return f"{v/1_000:+,.1f}K"
    return f"{v:+,.0f}"


def _fmt_pct(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    return f"{v:.1f}%"


def _fmt_gex_regime(regime: GEXRegime | None) -> str:
    if regime is None:
        return "—"
    return regime.value.replace("_", " ")


def _gex_color(regime: GEXRegime | None) -> str:
    if regime is None:
        return MUTED
    if regime is GEXRegime.TREND_FRIENDLY:
        return GREEN
    return GOLD    # PINNING


def _fmt_expiry_risk(risk) -> str:    # noqa: ANN001
    return risk.value if risk is not None else "—"


def _expiry_color(risk) -> str:    # noqa: ANN001
    if risk is ExpiryRisk.HIGH:
        return RED
    if risk is ExpiryRisk.ELEVATED:
        return GOLD
    return GREEN


def _kv_row(label: str) -> tuple[QWidget, QLabel]:
    """Build a fixed-label / value row for the sidebar panels.

    Returns ``(container, value_label)``: the container is a QWidget
    holding a horizontal label-on-left / value-on-right layout; the
    value_label is returned so callers can update it later (e.g. the
    options overlay stashes them in ``self._option_values``).

    Mirrors the inline pattern used by the industry-classification
    rows — 8pt mono, muted key, bold white value, key fixed-width so
    values left-align in a column.
    """
    container = QWidget()
    row = QHBoxLayout(container)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(6)
    k = QLabel(label)
    k.setFont(QFont(FONT_MONO, 8))
    k.setStyleSheet(f"color: {MUTED};")
    k.setFixedWidth(72)
    row.addWidget(k)
    v = QLabel("—")
    v.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
    v.setStyleSheet(f"color: {WHITE};")
    v.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    row.addWidget(v, stretch=1)
    return container, v


class Sidebar(QWidget):
    """Fixed-width sidebar — pure renderer over view models."""

    symbol_changed = pyqtSignal(str)
    refresh_clicked = pyqtSignal()
    add_to_watchlist = pyqtSignal(str)        # emits the symbol to add
    options_overlay_toggled = pyqtSignal(bool)  # True = enabled

    def __init__(
        self,
        default_symbols: Iterable[str] = (),
        universe: Universe | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("nimbus-sidebar")
        self.setFixedWidth(280)
        self.setStyleSheet(
            f"QWidget#nimbus-sidebar {{ background: {SURFACE}; "
            f"border-right: 1px solid {BORDER}; }}"
        )

        # Default symbol list shown before a live universe is wired.
        # Caller-supplied (typically ``sorted(industry_map.keys())``).
        # Manual entry always accepts anything — the combo is a
        # convenience, not a gate.
        self._default_symbols: tuple[str, ...] = tuple(
            s.upper() for s in default_symbols
        )
        self._universe = universe
        self._current_symbol: str = ""

        self._build_ui()
        self._populate_symbols()
        if not self._current_symbol and self._symbol_combo.count() > 0:
            self._current_symbol = self._symbol_combo.currentText()

        # Prime panels with their empty-state view models so the initial
        # render is explicit rather than implicit. The KEY LEVELS panel
        # is now MARKET BREADTH (universe-wide), so it primes via
        # set_breadth(None) — NOT the old per-symbol ride view, which
        # would leave a stale "PHASE — / Bars since fire" layout showing
        # before the panel loads.
        self.set_breadth(None)
        self.apply_industry_view(EMPTY_INDUSTRY_VIEW)
        self.set_options_context(None)

    # ══════════════════════════════════════════════════════════════════════
    # Public API — symbol selection
    # ══════════════════════════════════════════════════════════════════════

    def set_universe(self, universe: Universe | None) -> None:
        """Swap the combo's source universe."""
        self._universe = universe
        self._populate_symbols()

    def set_default_symbols(self, symbols: Iterable[str]) -> None:
        """Replace the default symbol list. No-op when a live universe
        has already been wired (the universe wins).
        """
        self._default_symbols = tuple(s.upper() for s in symbols)
        if self._universe is None:
            self._populate_symbols()

    def set_selected_symbol(self, symbol: str) -> None:
        """Set the visible symbol without re-emitting :attr:`symbol_changed`.

        Used by MainWindow to propagate cross-tab selection changes
        without re-triggering a load.
        """
        if not symbol:
            return
        sym = symbol.strip().upper()
        if sym == self._current_symbol:
            return
        self._current_symbol = sym
        try:
            self._symbol_combo.blockSignals(True)
            idx = self._symbol_combo.findText(sym, Qt.MatchFlag.MatchExactly)
            if idx >= 0:
                self._symbol_combo.setCurrentIndex(idx)
        finally:
            self._symbol_combo.blockSignals(False)
        self._symbol_input.clear()

    def current_symbol(self) -> str:
        """The symbol the sidebar currently considers selected.

        Reflects the last manual / combo selection. May be empty if
        the universe is empty and the operator has not typed anything.
        """
        return self._current_symbol

    # ══════════════════════════════════════════════════════════════════════
    # Public API — rendering
    # ══════════════════════════════════════════════════════════════════════

    def set_breadth(self, snap, regime=None) -> None:    # noqa: ANN001
        """Populate the MARKET BREADTH panel from a
        :class:`~nimbus_v3.compute.market_breadth.BreadthSnapshot`,
        plus an optional
        :class:`~nimbus_v3.compute.breadth_regime.RegimeState`.

        Universe-wide and symbol-independent — driven once when the
        panel loads, not per symbol selection. Replaces the former
        per-symbol KEY LEVELS / phase readout.

        Layout (reusing the panel's two header rows + four detail rows
        + the verdict line for the regime state):
            REGIME      RISK-ON  (4/4)     (verdict — coloured by state)
            ADV / DEC   312 / 165          (header — green/red by tilt)
            > SMA50     58%                (header)
            > SMA200    52%
            A/D line    -82
            New H-L     +1
            Breadth Δ   +2.1%

        The regime is DISPLAY-ONLY context (validated in RT-004); it
        does not gate or score rides.
        """
        if snap is None or snap.universe == 0:
            self._breadth_adv_lbl.setText("ADV / DEC   —")
            self._breadth_adv_lbl.setStyleSheet(f"color: {MUTED};")
            self._breadth_sma_lbl.setText("> SMA50     —")
            self._breadth_sma_lbl.setStyleSheet(f"color: {MUTED};")
            for lbl in self._breadth_row_lbls:
                lbl.setText("")
            self._breadth_regime_lbl.setText("")
            self._breadth_footer_lbl.setText("")
            return

        # Header 1: advancers / decliners, coloured by tilt.
        ad_color = (
            GREEN if snap.adv > snap.dec
            else RED if snap.dec > snap.adv
            else MUTED
        )
        self._breadth_adv_lbl.setText(
            f"ADV / DEC   {snap.adv} / {snap.dec}"
        )
        self._breadth_adv_lbl.setStyleSheet(f"color: {ad_color};")

        # Header 2: % above SMA50.
        def _pct(v: float) -> str:
            return f"{v:.0f}%" if v == v else "—"

        self._breadth_sma_lbl.setText(f"> SMA50     {_pct(snap.pct_above_sma50)}")
        self._breadth_sma_lbl.setStyleSheet(f"color: {WHITE};")

        # Detail rows.
        rows: list[tuple[str, str, str]] = [
            ("> SMA200", _pct(snap.pct_above_sma200), WHITE),
            ("A/D line", f"{snap.ad_line:+,.0f}",
             GREEN if snap.ad_line > 0 else RED if snap.ad_line < 0 else MUTED),
            ("New H-L", f"{snap.nh_nl_diff:+d}",
             GREEN if snap.nh_nl_diff > 0 else RED if snap.nh_nl_diff < 0 else MUTED),
            ("Breadth \u0394",
             f"{snap.breadth_delta:+.1f}pp" if snap.breadth_delta == snap.breadth_delta else "—",
             GREEN if (snap.breadth_delta == snap.breadth_delta and snap.breadth_delta > 0)
             else RED if (snap.breadth_delta == snap.breadth_delta and snap.breadth_delta < 0)
             else MUTED),
        ]
        for lbl in self._breadth_row_lbls:
            lbl.setText("")
            lbl.setStyleSheet(f"color: {MUTED};")
        for lbl, (label, value, color) in zip(self._breadth_row_lbls, rows):
            lbl.setText(f"{label:<12} {value}")
            lbl.setStyleSheet(f"color: {color};")

        # Footer: as-of date.
        asof = snap.asof.strftime("%d %b %Y") if snap.asof is not None else ""
        # Regime state on the verdict line (display-only, RT-004).
        if regime is not None and regime.label != "—":
            _regime_color = {
                "RISK_ON": GREEN, "NEUTRAL": GOLD, "RISK_OFF": RED,
            }.get(regime.label, MUTED)
            _regime_text = {
                "RISK_ON": "RISK-ON", "NEUTRAL": "NEUTRAL", "RISK_OFF": "RISK-OFF",
            }.get(regime.label, regime.label)
            self._breadth_regime_lbl.setText(
                f"REGIME      {_regime_text}  ({regime.signals_on}/{regime.n_signals})"
            )
            self._breadth_regime_lbl.setStyleSheet(f"color: {_regime_color};")
        else:
            self._breadth_regime_lbl.setText("")
        self._breadth_footer_lbl.setText(
            f"{snap.universe} symbols · {asof}" if asof else ""
        )
        self._breadth_footer_lbl.setStyleSheet(f"color: {MUTED};")

    def apply_industry_view(self, view: IndustryClassificationView) -> None:
        """Populate the four-level NSE industry classification rows."""
        self._ic_rows["Macro"].setText(view.macro)
        self._ic_rows["Sector"].setText(view.sector)
        self._ic_rows["Industry"].setText(view.industry)
        self._ic_rows["Basic"].setText(view.basic)

    def set_options_context(self, ctx: OptionsContext | None) -> None:
        """Render the OptionsContext panel.

        Mirrors the price-chart's options-overlay (resistance /
        support / max-pain / HVL) plus the greek strip
        (PCR-OI / NET GEX / GEX REG / IV-ATM / IVR / DTE / EXPIRY).
        Called by MainWindow whenever a fresh context arrives. Pass
        ``None`` to reset to em-dash placeholder state — useful when
        the symbol is a pure equity (no F&O) or the options feed
        404s.
        """
        if ctx is None:
            self._options_panel.set_accent(BORDER)
            for v in self._option_values.values():
                v.setText("—")
                v.setStyleSheet(f"color: {MUTED};")
            return

        self._set_opt("RESIST",   _fmt_price(ctx.resistance_wall),  RED)
        self._set_opt("SUPPORT",  _fmt_price(ctx.support_wall),     GREEN)
        self._set_opt("MAX PAIN", _fmt_price(ctx.max_pain),         GOLD)
        self._set_opt("HVL",      _fmt_price(ctx.hvl),              VIOLET)

        self._set_opt("PCR OI",   _fmt_ratio(ctx.pcr_oi),           WHITE)
        self._set_opt(
            "NET GEX", _fmt_signed(ctx.net_gex),
            GREEN if (ctx.net_gex or 0.0) > 0 else
            RED if (ctx.net_gex or 0.0) < 0 else WHITE,
        )
        self._set_opt(
            "GEX REG", _fmt_gex_regime(ctx.gex_regime),
            _gex_color(ctx.gex_regime),
        )
        self._set_opt("IV ATM",   _fmt_pct(ctx.iv_atm),             WHITE)
        self._set_opt("IVR",      _fmt_pct(ctx.ivr),                WHITE)

        dte_text = "—" if ctx.dte is None else f"{ctx.dte}d"
        self._set_opt("DTE",      dte_text,                         WHITE)
        self._set_opt(
            "EXPIRY", _fmt_expiry_risk(ctx.expiry_risk),
            _expiry_color(ctx.expiry_risk),
        )

        # Header tint reflects expiry risk — a glanceable cue that
        # this is a hot expiry without scanning the rows.
        self._options_panel.set_accent(_expiry_color(ctx.expiry_risk))

    def _set_opt(self, key: str, text: str, color: str) -> None:
        lbl = self._option_values.get(key)
        if lbl is None:
            return
        lbl.setText(text)
        lbl.setStyleSheet(f"color: {color};")

    def clear(self) -> None:
        """Reset the per-symbol panels to empty-state.

        Does NOT touch the MARKET BREADTH panel — that's universe-wide
        and stays populated regardless of which (or whether a) symbol is
        selected. It's driven only by set_breadth() at panel load.
        """
        self.apply_industry_view(EMPTY_INDUSTRY_VIEW)
        self.set_options_context(None)

    # ══════════════════════════════════════════════════════════════════════
    # Build
    # ══════════════════════════════════════════════════════════════════════

    def _build_ui(self) -> None:
        # Outer column = fixed top (logo + symbol picker) /
        # scrollable middle (panels) / fixed bottom (REFRESH +
        # version footer). The scroll area lets the sidebar carry
        # OPTIONS OVERLAY + KEY LEVELS without overflowing on
        # smaller screens; on tall screens it just becomes a
        # regular layout.
        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 16, 14, 12)
        outer.setSpacing(6)

        # ── Fixed top: logo + symbol picker ─────────────────────────
        logo = QLabel("NIMBUS")
        logo.setObjectName("nimbus-logo")
        logo.setStyleSheet(
            f"color: {WHITE}; font-family: '{FONT_UI}'; font-size: 16pt; "
            f"font-weight: 700; letter-spacing: 4px;"
        )
        outer.addWidget(logo)
        subtitle = QLabel("EMERALD SLATE")
        subtitle.setStyleSheet(
            f"color: {MUTED}; font-size: 8px; letter-spacing: 2px;"
        )
        outer.addWidget(subtitle)
        outer.addSpacing(14)

        outer.addWidget(self._section_label("SYMBOL"))
        self._symbol_combo = QComboBox()
        self._symbol_combo.setEditable(False)
        self._symbol_combo.currentTextChanged.connect(self._on_combo_changed)
        outer.addWidget(self._symbol_combo)

        manual_row = QHBoxLayout()
        manual_row.setSpacing(4)
        self._symbol_input = QLineEdit()
        self._symbol_input.setPlaceholderText("Enter symbol…")
        self._symbol_input.setMaxLength(20)
        self._symbol_input.returnPressed.connect(self._on_manual_entry)
        manual_row.addWidget(self._symbol_input, stretch=1)
        go_btn = QPushButton("GO")
        go_btn.setObjectName("primary")
        go_btn.setFixedSize(42, 28)
        go_btn.setFont(QFont(FONT_UI, 10))
        go_btn.clicked.connect(self._on_manual_entry)
        manual_row.addWidget(go_btn)
        outer.addLayout(manual_row)

        # ── Add-to-watchlist button (adds the current symbol) ──────
        self._watchlist_btn = QPushButton("+ ADD TO WATCHLIST")
        self._watchlist_btn.setFont(QFont(FONT_UI, 9))
        self._watchlist_btn.setFixedHeight(26)
        self._watchlist_btn.clicked.connect(self._on_add_watchlist_clicked)
        outer.addSpacing(6)
        outer.addWidget(self._watchlist_btn)

        # ── Options-overlay toggle ─────────────────────────────────
        # When OFF, MainWindow skips the options fetch entirely so a
        # symbol loads from price cache alone (much faster); the
        # display behaves exactly as if no options data exists.
        self._options_toggle = QCheckBox("Options overlay")
        self._options_toggle.setChecked(False)
        self._options_toggle.setFont(QFont(FONT_UI, 9))
        self._options_toggle.toggled.connect(self.options_overlay_toggled.emit)
        outer.addSpacing(4)
        outer.addWidget(self._options_toggle)

        outer.addSpacing(10)

        # ── Scrollable middle: INDUSTRY / OPTIONS OVERLAY / KEY LEVELS
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background: transparent; }")

        scroll_inner = QWidget()
        scroll_inner.setStyleSheet("background: transparent;")
        panels = QVBoxLayout(scroll_inner)
        panels.setContentsMargins(0, 0, 0, 0)
        panels.setSpacing(10)

        # ── Industry classification panel ─────────────────────────
        # Wraps the four-row hierarchy (Macro / Sector / Industry /
        # Basic) in a PanelFrame so it visually echoes the
        # OPTIONS OVERLAY + KEY LEVELS panels below — same rounded
        # card chrome, same coloured-accent top edge.
        industry_frame = PanelFrame(title="INDUSTRY", accent=EM)
        ic_body = industry_frame.content_layout()
        ic_body.setSpacing(4)

        self._ic_rows: dict[str, QLabel] = {}
        for label_text in ("Macro", "Sector", "Industry", "Basic"):
            row = QHBoxLayout()
            row.setSpacing(6)
            k = QLabel(label_text)
            k.setFont(QFont(FONT_MONO, 8))
            k.setStyleSheet(f"color: {MUTED};")
            k.setFixedWidth(56)
            row.addWidget(k)
            v = QLabel("—")
            v.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
            v.setStyleSheet(f"color: {WHITE};")
            v.setWordWrap(True)
            row.addWidget(v, stretch=1)
            self._ic_rows[label_text] = v
            ic_body.addLayout(row)
        panels.addWidget(industry_frame)

        # ── Options overlay panel ─────────────────────────────────
        # Moved here from the deleted Workflow Analysis right rail.
        # Format mirrors the original OptionsOverlayPanel: row of
        # label-value pairs for resistance / support / max-pain /
        # HVL, then the greek strip (PCR-OI / NET GEX / GEX REG /
        # IV-ATM / IVR / DTE / EXPIRY). Header tint reflects expiry
        # risk via :meth:`set_options_context`.
        self._options_panel = PanelFrame(title="OPTIONS OVERLAY", accent=BORDER)
        opt_body = self._options_panel.content_layout()
        opt_body.setSpacing(4)
        self._option_values: dict[str, QLabel] = {}
        for label in (
            "RESIST", "SUPPORT", "MAX PAIN", "HVL",
            "PCR OI", "NET GEX", "GEX REG",
            "IV ATM", "IVR", "DTE", "EXPIRY",
        ):
            row, v = _kv_row(label)
            opt_body.addWidget(row)
            self._option_values[label] = v
        panels.addWidget(self._options_panel)

        # ── Key levels & stats panel ──────────────────────────────
        # Universe-wide MARKET BREADTH panel. Populated once at panel
        # load via set_breadth() — ADV/DEC, % above SMA50/200, A/D
        # line, new-highs-minus-lows, breadth delta, and the RT-004
        # regime line.
        self._levels_frame = PanelFrame(
            title="MARKET BREADTH", accent=EM,
        )
        lev_body = self._levels_frame.content_layout()
        lev_body.setSpacing(4)

        # ADV/DEC headline — large bold mono, coloured by tilt.
        # (Driven by set_breadth.)
        self._breadth_adv_lbl = QLabel("ADV / DEC   —")
        self._breadth_adv_lbl.setFont(QFont(FONT_MONO, 10, QFont.Weight.Bold))
        self._breadth_adv_lbl.setStyleSheet(f"color: {MUTED};")
        lev_body.addWidget(self._breadth_adv_lbl)

        self._breadth_sma_lbl = QLabel("> SMA50     —")
        self._breadth_sma_lbl.setFont(QFont(FONT_MONO, 10, QFont.Weight.Bold))
        self._breadth_sma_lbl.setStyleSheet(f"color: {MUTED};")
        lev_body.addWidget(self._breadth_sma_lbl)

        lev_body.addSpacing(2)

        # Detail rows — populated by set_breadth (> SMA200, A/D line,
        # New H-L, Breadth Δ). Four pre-allocated label slots.
        self._breadth_row_lbls: list[QLabel] = []
        for _ in range(4):
            lbl = QLabel("")
            lbl.setFont(QFont(FONT_MONO, 8))
            lbl.setStyleSheet(f"color: {MUTED};")
            lev_body.addWidget(lbl)
            self._breadth_row_lbls.append(lbl)

        lev_body.addSpacing(4)

        # Regime line + as-of footer (display-only, set by set_breadth).
        self._breadth_regime_lbl = QLabel("")
        self._breadth_regime_lbl.setFont(QFont(FONT_MONO, 9, QFont.Weight.Bold))
        self._breadth_regime_lbl.setWordWrap(True)
        self._breadth_regime_lbl.setStyleSheet(f"color: {MUTED};")
        lev_body.addWidget(self._breadth_regime_lbl)

        self._breadth_footer_lbl = QLabel("")
        self._breadth_footer_lbl.setFont(QFont(FONT_MONO, 7))
        self._breadth_footer_lbl.setWordWrap(True)
        self._breadth_footer_lbl.setStyleSheet(f"color: {MUTED};")
        lev_body.addWidget(self._breadth_footer_lbl)

        panels.addWidget(self._levels_frame)
        panels.addStretch(1)

        scroll.setWidget(scroll_inner)
        outer.addWidget(scroll, stretch=1)

        outer.addSpacing(8)

        # ── Fixed bottom: REFRESH button + version footer ─────────
        self._refresh_btn = QPushButton("REFRESH")
        self._refresh_btn.setObjectName("primary")
        self._refresh_btn.setFixedHeight(34)
        self._refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._refresh_btn.clicked.connect(self.refresh_clicked.emit)
        outer.addWidget(self._refresh_btn)

        version = QLabel("v3 · Qt · Emerald Slate")
        version.setStyleSheet(f"color: {MUTED}; font-size: 8px;")
        version.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.addWidget(version)

    # ══════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════

    @staticmethod
    def _section_label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setFont(QFont(FONT_UI, 7))
        lbl.setStyleSheet(
            f"color: {MUTED}; letter-spacing: 1.6px; font-weight: 600;"
        )
        return lbl

    @staticmethod
    def _separator() -> QFrame:
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"background: {BORDER}; border: none;")
        return sep

    # ══════════════════════════════════════════════════════════════════════
    # Symbol-list management
    # ══════════════════════════════════════════════════════════════════════

    def _populate_symbols(self) -> None:
        """Populate the combo from the live universe (if wired) or the
        caller-supplied default list. Preserves current selection
        where possible.
        """
        previous = self._current_symbol
        symbols: tuple[str, ...]
        if self._universe is not None and len(self._universe) > 0:
            # Universe is the source of truth when wired. Sort
            # alphabetically — there is no longer a curated index
            # block at the top because indices were dropped from the
            # tradeable universe (NIFTY/BANKNIFTY/etc don't fetch
            # cleanly via yfinance and aren't part of the
            # ride-strategy scope).
            symbols = tuple(sorted(self._universe.symbols.keys()))
        else:
            symbols = self._default_symbols

        self._symbol_combo.blockSignals(True)
        try:
            self._symbol_combo.clear()
            self._symbol_combo.addItems(list(symbols))
            if previous:
                idx = self._symbol_combo.findText(
                    previous, Qt.MatchFlag.MatchExactly,
                )
                if idx >= 0:
                    self._symbol_combo.setCurrentIndex(idx)
        finally:
            self._symbol_combo.blockSignals(False)

    # ══════════════════════════════════════════════════════════════════════
    # Slots
    # ══════════════════════════════════════════════════════════════════════

    def _on_combo_changed(self, text: str) -> None:
        sym = text.strip().upper()
        if not sym or sym == self._current_symbol:
            return
        self._current_symbol = sym
        self.symbol_changed.emit(sym)

    def _on_add_watchlist_clicked(self) -> None:
        sym = self._current_symbol.strip().upper()
        if sym:
            self.add_to_watchlist.emit(sym)

    def options_overlay_enabled(self) -> bool:
        """True when the options overlay toggle is on."""
        return self._options_toggle.isChecked()

    def _on_manual_entry(self) -> None:
        sym = self._symbol_input.text().strip().upper()
        if not sym:
            return
        # If the typed symbol matches a combo item, flip the combo to
        # it (with signal block so we don't double-fire).
        idx = self._symbol_combo.findText(sym, Qt.MatchFlag.MatchExactly)
        if idx >= 0:
            self._symbol_combo.blockSignals(True)
            try:
                self._symbol_combo.setCurrentIndex(idx)
            finally:
                self._symbol_combo.blockSignals(False)
        self._symbol_input.clear()
        if sym == self._current_symbol:
            # Manual re-entry of the same symbol is a refresh signal.
            self.refresh_clicked.emit()
            return
        self._current_symbol = sym
        self.symbol_changed.emit(sym)
