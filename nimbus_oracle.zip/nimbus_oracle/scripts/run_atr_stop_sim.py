#!/usr/bin/env python3
"""
scripts/run_atr_stop_sim.py — Counterfactual simulation: what if MR trades had
an ATR-based hard stop loss?

CONTEXT:
  Fold 5 forensics revealed the failure mode is in EXIT logic, not entry:
    - BBW exits flipped from +0.69% avg to -1.01% avg
    - Bottom-decile loss tripled (-2.6% → -9.0%)
    - Worst single trade went from -19% to -36%
    - BBW exits take longer in stressed regimes (11 → 13.5 bars)

  The BBW contraction signal is correct in concept — it works in normal
  regimes — but it lags too much when stocks are in a directional downtrend.
  We need a fail-safe that doesn't depend on band behavior.

HYPOTHESIS:
  A hard stop at N×ATR drawdown from entry would have:
    1. Protected the worst losers in fold 5
    2. Cost minimal performance in folds 2/3/4 (where most trades don't
       drawdown that far before recovering)

SIMULATION:
  For each trade in wf_oos_trades.csv:
    1. Fetch the symbol's price history covering entry → exit
    2. Compute ATR(14) at entry
    3. Walk daily bars from entry+1 forward
    4. If close ≤ entry_price − multiplier×ATR before original exit,
       exit at that close with exit_reason = ATR_STOP
    5. Otherwise keep the original exit unchanged
  Test multipliers: 1.5, 2.0, 2.5, 3.0
  For each multiplier, report per-fold delta and pick the best.

DECISION CRITERIA:
  Best multiplier is the one with:
    - Largest fold 5 improvement (avg PnL or Sharpe)
    - ≤ 0.3pp win rate degradation in folds 2/3/4 combined
    - Stable across multiple folds (not driven by one fold)

  If no multiplier meets the criteria, the fix is rejected and we look
  for a different approach.

USAGE:
    python3 scripts/run_atr_stop_sim.py
    python3 scripts/run_atr_stop_sim.py --multipliers 2.0 2.5
"""
import argparse
import datetime
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("atr_stop_sim")


CSV_PATH = "data/backtest_results/wf_oos_trades.csv"
CACHE_DIR = "data/bbw_pctl_cache"
DEFAULT_MULTIPLIERS = [1.5, 2.0, 2.5, 3.0]
ATR_PERIOD = 14


# ══════════════════════════════════════════════════════════════════════════════
# DATA FETCHING (reuses bbw_pctl_cache)
# ══════════════════════════════════════════════════════════════════════════════

def fetch_symbol_history(symbol: str, start: pd.Timestamp,
                         end: pd.Timestamp) -> pd.DataFrame:
    """
    Get OHLC for a symbol, covering [start, end] inclusive. Uses parquet
    cache if it covers the range, otherwise fetches and caches.
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    cache_path = os.path.join(CACHE_DIR, f"{symbol}.parquet")

    df = pd.DataFrame()
    if os.path.exists(cache_path):
        try:
            df = pd.read_parquet(cache_path)
            if df.empty or df.index.min() > start or df.index.max() < end:
                df = pd.DataFrame()  # cache doesn't cover range
        except Exception:
            df = pd.DataFrame()

    if df.empty:
        # Fall back to fetch
        from scripts.run_bbw_pctl_study import fetch_price_history_range
        # Pad on both sides for ATR + lookhead
        df = fetch_price_history_range(
            symbol,
            start - pd.Timedelta(days=60),
            end + pd.Timedelta(days=5),
        )
        if not df.empty:
            try:
                df.to_parquet(cache_path)
            except Exception:
                pass

    return df


def compute_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    """Standard ATR. Returns series indexed by date."""
    if df.empty or len(df) < period + 1:
        return pd.Series(dtype=float)
    high = df["High"]
    low = df["Low"]
    close = df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()


# ══════════════════════════════════════════════════════════════════════════════
# SIMULATION
# ══════════════════════════════════════════════════════════════════════════════

def simulate_trade_with_stop(trade: dict, price_df: pd.DataFrame,
                              multiplier: float) -> dict:
    """
    Simulate a single trade with an ATR stop applied.

    Returns a dict with:
      - sim_pnl_pct: counterfactual PnL
      - sim_exit_date: counterfactual exit date
      - sim_exit_reason: 'ATR_STOP' or original
      - was_stopped: bool — did the rule fire
    """
    symbol = trade["symbol"]
    entry_date = trade["entry_date"]
    exit_date = trade["exit_date"]
    entry_price = trade["entry_price"]
    orig_pnl = trade["pnl_pct"]
    orig_exit = trade["exit_reason"]

    if price_df.empty:
        return {
            "sim_pnl_pct": orig_pnl,
            "sim_exit_date": exit_date,
            "sim_exit_reason": orig_exit,
            "was_stopped": False,
            "atr_at_entry": np.nan,
            "stop_price": np.nan,
        }

    # Compute ATR at entry
    atr_series = compute_atr(price_df, ATR_PERIOD)
    if atr_series.empty:
        return {
            "sim_pnl_pct": orig_pnl,
            "sim_exit_date": exit_date,
            "sim_exit_reason": orig_exit,
            "was_stopped": False,
            "atr_at_entry": np.nan,
            "stop_price": np.nan,
        }

    # Find ATR value as of entry_date (or most recent prior bar)
    try:
        idx = atr_series.index.get_indexer([entry_date], method="ffill")[0]
        if idx < 0:
            return {
                "sim_pnl_pct": orig_pnl,
                "sim_exit_date": exit_date,
                "sim_exit_reason": orig_exit,
                "was_stopped": False,
                "atr_at_entry": np.nan,
                "stop_price": np.nan,
            }
        atr_at_entry = float(atr_series.iloc[idx])
    except Exception:
        return {
            "sim_pnl_pct": orig_pnl,
            "sim_exit_date": exit_date,
            "sim_exit_reason": orig_exit,
            "was_stopped": False,
            "atr_at_entry": np.nan,
            "stop_price": np.nan,
        }

    if np.isnan(atr_at_entry) or atr_at_entry <= 0:
        return {
            "sim_pnl_pct": orig_pnl,
            "sim_exit_date": exit_date,
            "sim_exit_reason": orig_exit,
            "was_stopped": False,
            "atr_at_entry": np.nan,
            "stop_price": np.nan,
        }

    stop_price = entry_price - multiplier * atr_at_entry

    # Walk daily closes from entry+1 to exit (inclusive)
    # If any close ≤ stop_price, that's our exit
    closes = price_df["Close"]
    try:
        # Get the position window: bars strictly after entry, up to and including exit
        entry_idx = closes.index.get_indexer([entry_date], method="ffill")[0]
        exit_idx = closes.index.get_indexer([exit_date], method="ffill")[0]
    except Exception:
        return {
            "sim_pnl_pct": orig_pnl,
            "sim_exit_date": exit_date,
            "sim_exit_reason": orig_exit,
            "was_stopped": False,
            "atr_at_entry": atr_at_entry,
            "stop_price": stop_price,
        }

    if entry_idx < 0 or exit_idx < entry_idx:
        return {
            "sim_pnl_pct": orig_pnl,
            "sim_exit_date": exit_date,
            "sim_exit_reason": orig_exit,
            "was_stopped": False,
            "atr_at_entry": atr_at_entry,
            "stop_price": stop_price,
        }

    # Look at bars (entry_idx+1) through exit_idx
    for i in range(entry_idx + 1, min(exit_idx + 1, len(closes))):
        bar_close = closes.iloc[i]
        if bar_close <= stop_price:
            # Stop fires here
            sim_pnl = (bar_close / entry_price - 1) * 100
            return {
                "sim_pnl_pct": float(sim_pnl),
                "sim_exit_date": closes.index[i],
                "sim_exit_reason": "ATR_STOP",
                "was_stopped": True,
                "atr_at_entry": atr_at_entry,
                "stop_price": stop_price,
            }

    # Stop never fired — keep original outcome
    return {
        "sim_pnl_pct": orig_pnl,
        "sim_exit_date": exit_date,
        "sim_exit_reason": orig_exit,
        "was_stopped": False,
        "atr_at_entry": atr_at_entry,
        "stop_price": stop_price,
    }


# ══════════════════════════════════════════════════════════════════════════════
# RUN SIMULATION OVER ALL TRADES
# ══════════════════════════════════════════════════════════════════════════════

def run_simulation(trades: pd.DataFrame, multiplier: float) -> pd.DataFrame:
    """
    Run the ATR-stop simulation over every trade. Returns enriched DataFrame
    with sim columns added.
    """
    logger.info(f"  Running simulation with multiplier={multiplier}x ATR")
    rows = []
    symbols_seen = {}

    t0 = time.time()
    for i, (_, trade) in enumerate(trades.iterrows()):
        if i % 500 == 0 and i > 0:
            elapsed = time.time() - t0
            rate = i / elapsed
            eta = (len(trades) - i) / rate
            logger.info(f"    [{i}/{len(trades)}] eta {eta:.0f}s")

        symbol = trade["symbol"]
        # Cache the price history per symbol within a single multiplier run
        if symbol not in symbols_seen:
            entry_d = trade["entry_date"]
            # We'll fetch a generous range — symbol is reused across many trades
            symbols_seen[symbol] = fetch_symbol_history(
                symbol,
                start=trades[trades["symbol"] == symbol]["entry_date"].min() - pd.Timedelta(days=60),
                end=trades[trades["symbol"] == symbol]["exit_date"].max() + pd.Timedelta(days=5),
            )

        price_df = symbols_seen[symbol]
        sim = simulate_trade_with_stop(trade.to_dict(), price_df, multiplier)
        row = trade.to_dict()
        row.update(sim)
        rows.append(row)

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# REPORTING
# ══════════════════════════════════════════════════════════════════════════════

def header(text: str, char: str = "="):
    print("\n" + char * 78)
    print(f"  {text}")
    print(char * 78)


def per_fold_compare(sim_df: pd.DataFrame, multiplier: float):
    """Print per-fold original vs simulated comparison."""
    print(f"\n  multiplier = {multiplier}x ATR")
    print(f"  {'Fold':<6s}  {'N':>5s}  {'Stops':>6s}  "
          f"{'orig win%':>10s}  {'sim win%':>10s}  "
          f"{'orig avg':>10s}  {'sim avg':>10s}  {'Δ avg':>9s}")
    print(f"  {'-'*6}  {'-'*5}  {'-'*6}  {'-'*10}  {'-'*10}  {'-'*10}  {'-'*10}  {'-'*9}")

    summaries = []
    for fold in sorted(sim_df["fold"].unique()):
        f = sim_df[sim_df["fold"] == fold]
        n = len(f)
        n_stops = int(f["was_stopped"].sum())
        orig_win = (f["pnl_pct"] > 0).mean() * 100
        sim_win = (f["sim_pnl_pct"] > 0).mean() * 100
        orig_avg = f["pnl_pct"].mean()
        sim_avg = f["sim_pnl_pct"].mean()
        delta = sim_avg - orig_avg
        summaries.append({
            "fold": fold,
            "n": n,
            "stops": n_stops,
            "orig_win": orig_win,
            "sim_win": sim_win,
            "orig_avg": orig_avg,
            "sim_avg": sim_avg,
            "delta": delta,
            "win_delta": sim_win - orig_win,
        })
        print(f"  fold={fold}  {n:>5d}  {n_stops:>6d}  "
              f"{orig_win:>9.1f}%  {sim_win:>9.1f}%  "
              f"{orig_avg:>+9.2f}%  {sim_avg:>+9.2f}%  {delta:>+8.2f}%")

    return summaries


def overall_compare(sim_df: pd.DataFrame, multiplier: float) -> dict:
    """Aggregate over all trades and per-tier."""
    print(f"\n  AGGREGATE — all 4,511 trades")
    n_stops = int(sim_df["was_stopped"].sum())
    orig_win = (sim_df["pnl_pct"] > 0).mean() * 100
    sim_win = (sim_df["sim_pnl_pct"] > 0).mean() * 100
    orig_avg = sim_df["pnl_pct"].mean()
    sim_avg = sim_df["sim_pnl_pct"].mean()
    print(f"    Stops fired:      {n_stops}/{len(sim_df)} ({n_stops/len(sim_df)*100:.1f}%)")
    print(f"    Win rate:         {orig_win:.1f}% → {sim_win:.1f}% (Δ {sim_win-orig_win:+.1f}pp)")
    print(f"    Avg PnL:          {orig_avg:+.2f}% → {sim_avg:+.2f}% (Δ {sim_avg-orig_avg:+.2f}%)")

    # Tier-specific
    print(f"\n  BY TIER")
    for tier in sorted(sim_df["tier"].unique()):
        t = sim_df[sim_df["tier"] == tier]
        ts = int(t["was_stopped"].sum())
        ow = (t["pnl_pct"] > 0).mean() * 100
        sw = (t["sim_pnl_pct"] > 0).mean() * 100
        oa = t["pnl_pct"].mean()
        sa = t["sim_pnl_pct"].mean()
        print(f"    {tier:<10s}  N={len(t):4d}  stops={ts:3d}  "
              f"win {ow:5.1f}% → {sw:5.1f}% (Δ{sw-ow:+5.1f}pp)  "
              f"avg {oa:+5.2f}% → {sa:+5.2f}% (Δ{sa-oa:+5.2f}%)")

    return {
        "multiplier": multiplier,
        "n_stops": n_stops,
        "orig_win": orig_win,
        "sim_win": sim_win,
        "orig_avg": orig_avg,
        "sim_avg": sim_avg,
        "delta": sim_avg - orig_avg,
    }


def cross_multiplier_summary(all_results: dict):
    """Final side-by-side: which multiplier wins?"""
    header("CROSS-MULTIPLIER SUMMARY")
    print(f"\n  Per-fold avg PnL DELTA from baseline (positive = improvement):")
    print(f"  {'Fold':<6s}  ", end="")
    multipliers = sorted(all_results.keys())
    for m in multipliers:
        print(f"{f'{m}x ATR':>12s}  ", end="")
    print()
    print(f"  {'-'*6}  " + "  ".join("-" * 12 for _ in multipliers))

    folds = sorted({s["fold"] for s in all_results[multipliers[0]]["per_fold"]})
    for fold in folds:
        print(f"  fold={fold}  ", end="")
        for m in multipliers:
            fold_data = next(s for s in all_results[m]["per_fold"] if s["fold"] == fold)
            print(f"{fold_data['delta']:>+10.2f}%   ", end="")
        print()

    print(f"\n  Total fold-5 improvement and good-fold cost:")
    print(f"  {'Mult':<6s}  {'Fold5 Δavg':>12s}  {'Fold4 Δwin':>12s}  {'Folds 2-4 Δwin':>16s}")
    for m in multipliers:
        per = all_results[m]["per_fold"]
        f5 = next(s for s in per if s["fold"] == 5)
        f4 = next(s for s in per if s["fold"] == 4)
        good = [s for s in per if s["fold"] in (2, 3, 4)]
        good_win_delta = np.mean([s["win_delta"] for s in good])
        print(f"  {m}x   {f5['delta']:>+11.2f}%  {f4['win_delta']:>+11.1f}pp  {good_win_delta:>+15.1f}pp")


def recommendation(all_results: dict):
    """Pick the best multiplier based on the decision criteria."""
    header("RECOMMENDATION")

    multipliers = sorted(all_results.keys())
    best = None
    best_score = -float("inf")

    for m in multipliers:
        per = all_results[m]["per_fold"]
        f5 = next((s for s in per if s["fold"] == 5), None)
        good = [s for s in per if s["fold"] in (2, 3, 4)]
        if f5 is None or not good:
            continue

        f5_improvement = f5["delta"]  # positive is good
        good_win_delta = np.mean([s["win_delta"] for s in good])

        # Decision criteria: max improvement while ≤ 0.3pp degradation in good folds
        passes_criteria = good_win_delta >= -0.3
        score = f5_improvement if passes_criteria else (f5_improvement - 100)

        print(f"  {m}x ATR: fold5 Δavg={f5_improvement:+.2f}%  "
              f"good-folds Δwin={good_win_delta:+.2f}pp  "
              f"{'✓ valid' if passes_criteria else '✗ violates good-fold floor'}")

        if score > best_score and passes_criteria:
            best_score = score
            best = m

    print()
    if best is None:
        print("  NO MULTIPLIER PASSES THE DECISION CRITERIA.")
        print("  Either the cost to good folds is too high, or the fix doesn't work.")
        print("  Recommended action: don't ship the ATR stop. Look for a different fix.")
    else:
        f5 = next(s for s in all_results[best]["per_fold"] if s["fold"] == 5)
        print(f"  WINNER: {best}x ATR stop")
        print(f"    Fold 5 avg PnL: {f5['orig_avg']:+.2f}% → {f5['sim_avg']:+.2f}% (Δ {f5['delta']:+.2f}%)")
        print(f"    Fold 5 win rate: {f5['orig_win']:.1f}% → {f5['sim_win']:.1f}% (Δ {f5['win_delta']:+.1f}pp)")
        print(f"    Stops fired in fold 5: {f5['stops']}/{f5['n']} ({f5['stops']/f5['n']*100:.1f}%)")
        print()
        print(f"  Next step: implement {best}x ATR stop in modules/dual_mode.py")
        print(f"  with exit_reason='STOP_LOSS_ATR'.")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--multipliers", type=float, nargs="+", default=DEFAULT_MULTIPLIERS,
                    help=f"ATR multipliers to test (default: {DEFAULT_MULTIPLIERS})")
    args = ap.parse_args()

    if not os.path.exists(CSV_PATH):
        logger.error(f"{CSV_PATH} not found")
        sys.exit(1)

    trades = pd.read_csv(CSV_PATH)
    trades["entry_date"] = pd.to_datetime(trades["entry_date"])
    trades["exit_date"] = pd.to_datetime(trades["exit_date"])
    logger.info(f"Loaded {len(trades):,} trades")

    # Filter to PRIMARY (MR) only — the ATR stop is for MR, not Ride
    # (Ride has its own trailing ATR exit logic in bb_ride.py)
    mr_trades = trades[trades["tier"] == "PRIMARY"].copy()
    logger.info(f"Filtering to PRIMARY (MR) tier: {len(mr_trades):,} trades")

    all_results = {}
    for multiplier in args.multipliers:
        header(f"SIMULATION — {multiplier}x ATR STOP")
        sim_df = run_simulation(mr_trades, multiplier)
        per_fold = per_fold_compare(sim_df, multiplier)
        overall = overall_compare(sim_df, multiplier)
        all_results[multiplier] = {
            "per_fold": per_fold,
            "overall": overall,
            "df": sim_df,
        }

    cross_multiplier_summary(all_results)
    recommendation(all_results)


if __name__ == "__main__":
    main()
