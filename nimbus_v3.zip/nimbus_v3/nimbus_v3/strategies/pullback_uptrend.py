"""nimbus_v3.strategies.pullback_uptrend — research-tier pullback strategy.

⚠ **Research-only signal** — emits trades for SignalTracker but does
not contribute to production conviction grades in v3.0.

Validation summary
──────────────────
Round 2 (with market-trend filter) on fresh data (April 2026):
- Train (2020-03 → 2024-12): n=8,091, lift +0.10pp, t=+1.42
- Test (2025-01 → 2026-04): n=192, lift +1.11pp, **t=+2.38**
- OOS decay: **+1.01pp** (strategy IMPROVED on OOS — not overfit)

Test significance is above the t ≥ 2.0 threshold. Test n=192 falls
just below the 200-bar acceptance threshold, but the trend across the
three validations has been consistent positive OOS lift. With 12
months of additional SignalTracker data the sample will pass the
threshold.

Entry gates (the round-2 variant, including the regime filter)
──────────────────────────────────────────────────────────────
- ``state.above_sma_50`` AND ``state.above_sma_200``  — trend intact
- ``state.adx_14 > 20``                                — trend strength
- ``-3.0 < state.pct_from_sma_20 < 0``                 — small pullback to SMA20

The market-trend regime filter (broad-market index > 200-SMA) that
the validation study applied is NOT encoded here. This is by design:
strategies emit signals unconditionally and the scan engine / conviction
engine apply regime filters as gates on sizing or grading.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class PullbackUptrendParams:
    adx_14_min: float = 20.0
    pct_from_sma_20_min: float = -3.0   # pullback no deeper than 3% below SMA20
    pct_from_sma_20_max: float = 0.0    # must currently be below SMA20


class PullbackUptrendStrategy:
    """Pullback-in-uptrend setup. Research-tier: tracked, not graded.

    Rejects ETFs.
    """

    name: str = "PullbackUptrend"
    setup_type: SetupType = SetupType.PULLBACK_IN_UPTREND
    priority: int = 30     # below MR (50) and Ride (40)
    production_weight: float = 0.0   # research-tier (t=+2.38 OOS but small sample)

    def __init__(
        self, params: PullbackUptrendParams = PullbackUptrendParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — state-driven
    ) -> StrategySignal | None:
        if not (state.above_sma_50 and state.above_sma_200):
            return None
        if state.adx_14 <= self._p.adx_14_min:
            return None
        if not (self._p.pct_from_sma_20_min
                < state.pct_from_sma_20
                < self._p.pct_from_sma_20_max):
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "adx_14": state.adx_14,
                "pct_from_sma_20": state.pct_from_sma_20,
            },
        )
