"""Tests for nimbus_v3.compute.industry_rollup."""
from __future__ import annotations

import pandas as pd

from nimbus_v3.compute.industry_rollup import (
    aggregate_industry,
    body_above_streak,
    last_body_above,
)


def _df(adtv: float, *, above: bool, n: int = 30) -> pd.DataFrame:
    """Frame whose 20-bar mean Close×Volume ≈ ``adtv`` and whose LAST
    bar's body is above (or below) the upper BB, per ``above``.

    body_above_band requires BOTH Open and Close > bb_20_1s_upper.
    """
    idx = pd.bdate_range("2024-01-01", periods=n)
    close = pd.Series(100.0, index=idx)
    upper = pd.Series(105.0, index=idx)
    op = pd.Series(100.0, index=idx)
    if above:
        close.iloc[-1] = 110.0
        op.iloc[-1] = 108.0
    return pd.DataFrame({
        "Open": op,
        "Close": close,
        "Volume": pd.Series(adtv / 100.0, index=idx),
        "bb_20_1s_upper": upper,
    })


def test_returns_none_when_no_member_in_panel():
    assert aggregate_industry(["X", "Y"], {}, {}) is None


def test_riding_counts_body_above_members():
    panel = {
        "A": _df(100, above=True),
        "B": _df(100, above=True),
        "C": _df(100, above=False),
    }
    r = aggregate_industry(["A", "B", "C"], panel, {})
    assert r.riding == 2
    assert r.members == 3


def test_riding_is_phase_independent():
    panel = {"A": _df(100, above=True), "B": _df(100, above=False)}
    r = aggregate_industry(["A", "B"], panel, {})
    assert r.riding == 1


def test_riding_strength_is_adtv_weighted():
    liquid = aggregate_industry(
        ["A", "B"],
        {"A": _df(1000, above=True), "B": _df(50, above=False)}, {})
    illiquid = aggregate_industry(
        ["A", "B"],
        {"A": _df(80, above=True), "B": _df(50, above=False)}, {})
    assert liquid.riding == illiquid.riding == 1
    assert liquid.riding_strength > illiquid.riding_strength


def test_no_riders_gives_nan_strength():
    panel = {"A": _df(500, above=False)}
    r = aggregate_industry(["A"], panel, {})
    assert r.riding == 0
    assert r.riding_strength != r.riding_strength


def test_adtv_total_sums_members():
    panel = {"A": _df(300, above=False), "B": _df(700, above=False)}
    r = aggregate_industry(["A", "B"], panel, {})
    assert abs(r.adtv_total - 1000.0) < 1.0


def test_last_body_above_true_when_open_and_close_above():
    assert last_body_above(_df(100, above=True)) is True


def test_last_body_above_false_otherwise():
    assert last_body_above(_df(100, above=False)) is False


def test_last_body_above_missing_band_is_false():
    df = pd.DataFrame({"Open": [1.0], "Close": [2.0]})
    assert last_body_above(df) is False


def test_body_above_streak_counts_trailing_run():
    idx = pd.bdate_range("2024-01-01", periods=6)
    upper = pd.Series(105.0, index=idx)
    close = pd.Series([100, 100, 100, 110, 110, 110], index=idx, dtype=float)
    op = pd.Series([100, 100, 100, 108, 108, 108], index=idx, dtype=float)
    df = pd.DataFrame({"Open": op, "Close": close, "bb_20_1s_upper": upper})
    assert body_above_streak(df) == 3


def test_body_above_streak_zero_when_last_not_above():
    idx = pd.bdate_range("2024-01-01", periods=4)
    upper = pd.Series(105.0, index=idx)
    close = pd.Series([110, 110, 110, 100], index=idx, dtype=float)
    op = pd.Series([108, 108, 108, 100], index=idx, dtype=float)
    df = pd.DataFrame({"Open": op, "Close": close, "bb_20_1s_upper": upper})
    assert body_above_streak(df) == 0
