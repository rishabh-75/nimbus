"""Tests for nimbus_v3.data.options_loader.OptionsLoader."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd
import pytest

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.options_loader import OptionsLoader, parse_option_chain


@dataclass
class _MockNSE:
    """Two-endpoint mock that matches the real loader's flow.

    The loader makes two kinds of calls:
      1. ``option-chain-contract-info`` to get the expiry list.
      2. ``option-chain-v3`` (one per expiry) to get the chain rows.

    We stash one response per endpoint and dispatch on URL substring.
    This is what the real NSE API does: different endpoints return
    different payload shapes.
    """
    info_response: object = None
    chain_response: object = None
    calls: list = field(default_factory=list)

    def fetch(self, url, *, referer, params=None, extra_headers=None):  # noqa: ANN001, ARG002
        self.calls.append({"url": url, "params": params})
        if "contract-info" in url:
            return self.info_response
        if "option-chain" in url:    # matches option-chain-v3 and legacy variants
            # If the chain response carries rows, stamp the requested
            # expiry onto each row so multi-expiry tests get distinct
            # expiry values. Real NSE behavior: chain-v3 with
            # expiry=X returns rows for X; our mock mirrors that.
            if (
                isinstance(self.chain_response, dict)
                and params is not None
                and "expiry" in params
            ):
                import copy
                resp = copy.deepcopy(self.chain_response)
                rows = resp.get("records", {}).get("data", [])
                for row in rows:
                    row["expiryDate"] = params["expiry"]
                return resp
            return self.chain_response
        return None


def _info_payload(expiries: list[str]) -> dict:
    """Contract-info response shape. Loader tries several key
    variants; ``records.expiryDates`` is the historically-served
    nesting and matches one of the loader's lookup paths."""
    return {"records": {"expiryDates": expiries}}


def _chain_payload(rows: list[dict], spot: float = 2475.0) -> dict:
    return {"records": {
        "data": rows,
        "underlyingValue": spot,
    }}


def _row(strike: float, *, expiry: str = "16-May-2024",
          ce_oi: float = 1000, pe_oi: float = 1000,
          ce_iv: float | None = 20.0, pe_iv: float | None = 20.0) -> dict:
    return {
        "strikePrice": strike,
        "expiryDate": expiry,
        "CE": {"openInterest": ce_oi, "impliedVolatility": ce_iv, "lastPrice": 50},
        "PE": {"openInterest": pe_oi, "impliedVolatility": pe_iv, "lastPrice": 50},
    }


@pytest.fixture
def loader(tmp_path: Path) -> tuple[OptionsLoader, _MockNSE]:
    nse = _MockNSE()
    cache = ParquetCache(tmp_path / "options")
    ol = OptionsLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    return ol, nse


# Backwards-compat alias for the parse tests below — they only need
# a chain-shaped payload, no info call in the mix.
_payload = _chain_payload


# ══════════════════════════════════════════════════════════════════════════════
# Parser
# ══════════════════════════════════════════════════════════════════════════════

def test_parse_returns_dataframe_with_expected_columns() -> None:
    df = parse_option_chain(_payload([_row(2450), _row(2500)]))
    expected = {
        "strike", "expiry", "dte", "spot",
        "ce_oi", "ce_oi_change", "ce_volume", "ce_iv", "ce_last",
        "pe_oi", "pe_oi_change", "pe_volume", "pe_iv", "pe_last",
    }
    assert expected.issubset(df.columns)
    assert len(df) == 2


def test_parse_returns_empty_on_bad_shape() -> None:
    assert parse_option_chain({}).empty
    assert parse_option_chain("garbage").empty
    assert parse_option_chain({"records": "not a dict"}).empty
    assert parse_option_chain({"records": {"data": "not a list"}}).empty


def test_parse_sorts_by_expiry_then_strike() -> None:
    df = parse_option_chain(_payload([
        _row(2500, expiry="30-May-2024"),
        _row(2450, expiry="16-May-2024"),
        _row(2500, expiry="16-May-2024"),
    ]))
    # Nearest first, then strike asc within expiry.
    assert df.iloc[0]["strike"] == 2450
    assert df.iloc[1]["strike"] == 2500
    assert df.iloc[0]["expiry"] < df.iloc[2]["expiry"]


def test_parse_skips_rows_without_strike_or_expiry() -> None:
    df = parse_option_chain(_payload([
        {"expiryDate": "16-May-2024", "CE": {}, "PE": {}},   # no strike
        {"strikePrice": 2450, "CE": {}, "PE": {}},            # no expiry
        _row(2500),
    ]))
    assert len(df) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Loader
# ══════════════════════════════════════════════════════════════════════════════

def test_load_hits_contract_info_first_then_chain_for_equity(
    loader: tuple[OptionsLoader, _MockNSE],
) -> None:
    """The two-call flow: first fetch contract-info for the expiry
    list, then fetch the chain-v3 endpoint with type=Equities."""
    ol, nse = loader
    nse.info_response = _info_payload(["16-May-2024"])
    nse.chain_response = _chain_payload([_row(2450)])
    ol.load("RELIANCE")
    # First call: contract-info lookup
    assert "contract-info" in nse.calls[0]["url"]
    # Second (and later) calls: chain-v3 with type=Equities
    assert any(
        "option-chain-v3" in c["url"]
        and c["params"].get("type") == "Equities"
        for c in nse.calls[1:]
    )


def test_load_hits_contract_info_first_then_chain_for_index(
    loader: tuple[OptionsLoader, _MockNSE],
) -> None:
    """Same flow for indices — chain-v3 calls get type=Indices."""
    ol, nse = loader
    nse.info_response = _info_payload(["16-May-2024"])
    nse.chain_response = _chain_payload([_row(22000)])
    ol.load("NIFTY", is_index=True)
    assert "contract-info" in nse.calls[0]["url"]
    assert any(
        "option-chain-v3" in c["url"]
        and c["params"].get("type") == "Indices"
        for c in nse.calls[1:]
    )


def test_load_caches_and_serves_on_repeat(loader: tuple[OptionsLoader, _MockNSE]) -> None:
    ol, nse = loader
    nse.info_response = _info_payload(["16-May-2024"])
    nse.chain_response = _chain_payload([_row(2450)])
    ol.load("RELIANCE")
    # Null out both responses — if the cache isn't serving, we'd
    # get back an empty frame instead of the cached one.
    nse.info_response = None
    nse.chain_response = None
    df = ol.load("RELIANCE")
    assert len(df) == 1


def test_load_force_refresh_bypasses_cache(loader: tuple[OptionsLoader, _MockNSE]) -> None:
    ol, nse = loader
    nse.info_response = _info_payload(["16-May-2024"])
    nse.chain_response = _chain_payload([_row(2450)])
    ol.load("RELIANCE")
    # Change the chain response; force_refresh should re-fetch and
    # return the new, larger frame.
    nse.chain_response = _chain_payload([_row(2450), _row(2500)])
    df = ol.load("RELIANCE", force_refresh=True)
    assert len(df) == 2


def test_load_empty_returns_empty_with_no_cache(loader: tuple[OptionsLoader, _MockNSE]) -> None:
    ol, nse = loader
    # Neither response populated — contract-info returns None which
    # short-circuits the loader to an empty DataFrame.
    nse.info_response = None
    nse.chain_response = None
    assert ol.load("NOPE").empty


def test_get_expiries_sorted(loader: tuple[OptionsLoader, _MockNSE]) -> None:
    ol, nse = loader
    # Contract-info returns two expiries. The loader fetches both;
    # the mock returns the SAME chain payload for every chain call
    # (rows are identical across expiries in this test, which is
    # fine — we're testing get_expiries on the combined frame).
    nse.info_response = _info_payload(["16-May-2024", "30-May-2024"])
    nse.chain_response = _chain_payload([
        _row(2450, expiry="16-May-2024"),
    ])
    df = ol.load("RELIANCE")
    expiries = ol.get_expiries(df)
    # Both expiry dates should appear, sorted ascending. The rows
    # themselves carry the expiry from their chain-v3 call's
    # ``expiry`` param, stamped by the loader.
    assert pd.Timestamp("2024-05-16") in expiries
    assert pd.Timestamp("2024-05-30") in expiries
    assert expiries == sorted(expiries)
