"""tests.ui.test_sidebar — smoke tests for the slim Sidebar widget.

Each test constructs Sidebar under offscreen Qt, exercises the
public surface (signals, set_*, apply_*, clear), and asserts the
visible label texts where meaningful. The tests do not exercise
real domain types — they push hand-built view models from
:mod:`nimbus_v3.ui.presenters` to keep the Sidebar's contract
explicit.
"""
from __future__ import annotations

import pandas as pd
import pytest

from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.ui.presenters import (
    EMPTY_INDUSTRY_VIEW,
    IndustryClassificationView,
)
from nimbus_v3.ui.sidebar import Sidebar
from nimbus_v3.ui.theme import GREEN, MUTED


_DEFAULT_LIST = ("RELIANCE", "TCS", "INFY", "HDFCBANK")


# ══════════════════════════════════════════════════════════════════════════════
# Construction
# ══════════════════════════════════════════════════════════════════════════════


def test_sidebar_constructs_with_default_symbols(qapp):    # noqa: ARG001
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    assert s.width() == 280
    assert s._symbol_combo.count() == len(_DEFAULT_LIST)
    # Auto-selected to the first item — same uppercase shape the
    # presenter expects.
    assert s.current_symbol() in {x.upper() for x in _DEFAULT_LIST}


def test_sidebar_with_no_default_symbols_has_empty_combo(qapp):    # noqa: ARG001
    s = Sidebar()
    assert s._symbol_combo.count() == 0
    assert s.current_symbol() == ""


def test_sidebar_initial_panels_are_empty(qapp):    # noqa: ARG001
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    # Ride panel reflects empty view — the verdict label is suppressed
    # so the sidebar doesn't show a stray em-dash next to REFRESH.
    assert "—" in s._breadth_adv_lbl.text()
    assert s._breadth_regime_lbl.text() == ""    # suppressed in empty state
    # Industry rows all em-dashed.
    for label in ("Macro", "Sector", "Industry", "Basic"):
        assert s._ic_rows[label].text() == "—"


def test_sidebar_no_longer_has_apply_header(qapp):    # noqa: ARG001
    """The HEADER section + apply_header method were removed —
    sidebar should not echo the dashboard's header any longer."""
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    assert not hasattr(s, "apply_header")
    # And the underlying labels are gone too.
    for attr in ("_h_symbol_lbl", "_h_spot_lbl", "_h_change_lbl", "_h_asof_lbl"):
        assert not hasattr(s, attr), f"unexpected attr {attr}"


# ══════════════════════════════════════════════════════════════════════════════
# Signals
# ══════════════════════════════════════════════════════════════════════════════


def test_sidebar_emits_symbol_changed_on_combo(qapp):    # noqa: ARG001
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    received: list[str] = []
    s.symbol_changed.connect(received.append)

    # Pick the second item to guarantee a change from the auto-selected first.
    target = s._symbol_combo.itemText(1)
    s._symbol_combo.setCurrentIndex(1)

    assert received == [target]
    assert s.current_symbol() == target


def test_sidebar_emits_symbol_changed_on_manual_entry(qapp):    # noqa: ARG001
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    received: list[str] = []
    s.symbol_changed.connect(received.append)

    s._symbol_input.setText("zydus")    # mixed case
    s._on_manual_entry()

    assert received == ["ZYDUS"]
    assert s.current_symbol() == "ZYDUS"
    # Input is cleared after entry.
    assert s._symbol_input.text() == ""


def test_sidebar_manual_re_entry_emits_refresh(qapp):    # noqa: ARG001
    """Re-typing the *current* symbol is the documented refresh shortcut."""
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    refresh_count = []
    s.refresh_clicked.connect(lambda: refresh_count.append(1))

    s._symbol_input.setText("RELIANCE")
    s._on_manual_entry()
    refresh_count.clear()

    s._symbol_input.setText("RELIANCE")
    s._on_manual_entry()
    assert refresh_count == [1]


def test_sidebar_refresh_button_emits_signal(qapp):    # noqa: ARG001
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    received: list[int] = []
    s.refresh_clicked.connect(lambda: received.append(1))
    s._refresh_btn.click()
    assert received == [1]


def test_set_selected_symbol_does_not_re_emit(qapp):    # noqa: ARG001
    """MainWindow uses set_selected_symbol to mirror cross-tab navigation;
    it must not re-trigger a load."""
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    received: list[str] = []
    s.symbol_changed.connect(received.append)
    s.set_selected_symbol("INFY")
    assert s.current_symbol() == "INFY"
    assert received == []


# ══════════════════════════════════════════════════════════════════════════════
# View application
# ══════════════════════════════════════════════════════════════════════════════


def test_apply_industry_view(qapp):    # noqa: ARG001
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    s.apply_industry_view(IndustryClassificationView(
        macro="Commodities",
        sector="Metals & Mining",
        industry="Non - Ferrous Metals",
        basic="Zinc",
    ))
    assert s._ic_rows["Macro"].text() == "Commodities"
    assert s._ic_rows["Basic"].text() == "Zinc"


def test_clear_resets_per_symbol_panels(qapp):    # noqa: ARG001
    """clear() resets the per-symbol panels (industry classification,
    options). It deliberately does NOT touch the MARKET BREADTH panel,
    which is universe-wide and driven only by set_breadth()."""
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    s.apply_industry_view(IndustryClassificationView(macro="A", sector="B"))

    s.clear()

    assert s._ic_rows["Macro"].text() == "—"


def test_clear_preserves_breadth_panel(qapp):    # noqa: ARG001
    """The universe breadth readout survives a symbol-level clear()."""
    from nimbus_v3.compute.market_breadth import BreadthSnapshot
    import pandas as pd
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    snap = BreadthSnapshot(
        asof=pd.Timestamp("2026-06-03"), universe=400, adv=260, dec=140,
        pct_above_sma50=58.0, pct_above_sma200=52.0, ad_line=1240.0,
        nh_nl_diff=18, breadth_delta=2.1,
    )
    s.set_breadth(snap)
    s.clear()
    assert "260 / 140" in s._breadth_adv_lbl.text()
    assert s._breadth_regime_lbl.text() == ""    # suppressed in empty state


# ══════════════════════════════════════════════════════════════════════════════
# Universe + default-symbol wiring
# ══════════════════════════════════════════════════════════════════════════════


def test_set_universe_replaces_default_list(qapp):    # noqa: ARG001
    """Wiring a real Universe replaces the default symbol list — the
    universe is the source of truth once available."""
    s = Sidebar(default_symbols=_DEFAULT_LIST)
    universe = Universe(
        symbols={
            "ALPHA": SymbolMeta(symbol="ALPHA"),
            "BETA":  SymbolMeta(symbol="BETA"),
            "GAMMA": SymbolMeta(symbol="GAMMA"),
        },
        built_at=pd.Timestamp.now("UTC"),
    )
    s.set_universe(universe)
    items = [
        s._symbol_combo.itemText(i)
        for i in range(s._symbol_combo.count())
    ]
    assert items == ["ALPHA", "BETA", "GAMMA"]    # alphabetical


def test_set_universe_does_not_include_indices(qapp):    # noqa: ARG001
    """The universe path must not synthesise an index block — the
    user explicitly removed NIFTY/BANKNIFTY/etc from the default list."""
    s = Sidebar()
    universe = Universe(
        symbols={
            "RELIANCE": SymbolMeta(symbol="RELIANCE"),
            "TCS": SymbolMeta(symbol="TCS"),
        },
        built_at=pd.Timestamp.now("UTC"),
    )
    s.set_universe(universe)
    items = {
        s._symbol_combo.itemText(i)
        for i in range(s._symbol_combo.count())
    }
    assert "NIFTY" not in items
    assert "BANKNIFTY" not in items
    assert "FINNIFTY" not in items


def test_set_default_symbols_late_wiring(qapp):    # noqa: ARG001
    """Caller can change the default list after construction — useful
    when MainWindow loads the industry DB asynchronously."""
    s = Sidebar()    # empty defaults
    assert s._symbol_combo.count() == 0
    s.set_default_symbols(["A", "B", "C"])
    assert s._symbol_combo.count() == 3


def test_set_default_symbols_yields_to_universe(qapp):    # noqa: ARG001
    """Once a universe is wired, late default_symbols updates are
    no-ops — the universe is the source of truth."""
    s = Sidebar(default_symbols=("X", "Y"))
    universe = Universe(
        symbols={"ALPHA": SymbolMeta(symbol="ALPHA")},
        built_at=pd.Timestamp.now("UTC"),
    )
    s.set_universe(universe)
    s.set_default_symbols(["NEW1", "NEW2"])
    items = [
        s._symbol_combo.itemText(i)
        for i in range(s._symbol_combo.count())
    ]
    assert items == ["ALPHA"]


def test_set_breadth_populates_panel(qapp):    # noqa: ARG001
    """Sidebar MARKET BREADTH panel renders universe stats from a
    BreadthSnapshot (replaces the former per-symbol KEY LEVELS)."""
    from nimbus_v3.compute.market_breadth import BreadthSnapshot
    import pandas as pd
    sb = Sidebar(default_symbols=["A", "B"])
    snap = BreadthSnapshot(
        asof=pd.Timestamp("2026-05-06"), universe=400, adv=260, dec=140,
        pct_above_sma50=58.0, pct_above_sma200=52.0, ad_line=1240.0,
        nh_nl_diff=18, breadth_delta=2.1,
    )
    sb.set_breadth(snap)
    assert "260 / 140" in sb._breadth_adv_lbl.text()
    assert "58%" in sb._breadth_sma_lbl.text()
    joined = " ".join(l.text() for l in sb._breadth_row_lbls)
    assert "52%" in joined and "1,240" in joined and "+18" in joined


def test_set_breadth_none_clears(qapp):    # noqa: ARG001
    sb = Sidebar(default_symbols=["A"])
    sb.set_breadth(None)
    assert "—" in sb._breadth_adv_lbl.text()
