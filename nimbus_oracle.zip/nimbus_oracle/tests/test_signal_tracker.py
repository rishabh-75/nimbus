"""
tests/test_signal_tracker.py
─────────────────────────────
Tests for forward validation signal tracker.
"""
from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import datetime
import sqlite3

_PASS = 0; _FAIL = 0; _ERRORS = []
def _run(name, fn):
    global _PASS, _FAIL
    try: fn(); _PASS += 1; print(f"  ✓ {name}")
    except Exception as e: _FAIL += 1; _ERRORS.append((name, str(e))); print(f"  ✗ {name}: {e}")


def _clean_db():
    """Remove test DB before each group."""
    from modules.signal_tracker import _DB_PATH
    if os.path.exists(_DB_PATH):
        os.remove(_DB_PATH)


def _make_signal(symbol="TATASTEEL", mode="MR", entry_triggered=True, score=72):
    """Build a mock DualModeSignal for testing."""
    from types import SimpleNamespace
    return SimpleNamespace(
        symbol=symbol, mode=mode, tier="SECONDARY", segment="UNIFIED",
        close=1500.0, sma_20=1520.0, pct_from_sma=-1.3,
        wr_20=-45.0, wr_30=-42.0, adx_14=18.0,
        mfi=45.0, mfi_slope=2.0, rsi=35.0,
        dd_from_high=-6.0, red_streak=3, vol_ratio=1.2,
        bbw_slope=-0.5, bbw_pctl=40.0,
        base_score=score, options_overlay=3, filing_overlay=0,
        is_trap=False, dual_score=score + 3, dual_label="GOOD",
        dual_sizing="HALF", entry_triggered=entry_triggered,
        entry_reason="SECONDARY: WR(30)=-42 | -1.3% vs SMA | MFI=45",
        input_interval="1D", daily_bars_used=120,
    )


def _make_ride_signal(symbol="RELIANCE", entry_triggered=True, grade="A", grade_pts=5):
    """Build a mock BBRideResult for testing."""
    from types import SimpleNamespace
    return SimpleNamespace(
        symbol=symbol, close=2500.0, bb_upper=2480.0, bb_pct=1.05,
        bbw=4.2, bbw_slope=0.3, vol_ratio=1.5,
        rsi=65.0, mfi=58.0, adx=28.0, atr=50.0, roc_10=2.1,
        pct_from_sma50=4.3, above_sma50=True,
        entry_triggered=entry_triggered, entry_reason="UPPER_BREAK",
        data_sufficient=True,
        grade=grade, grade_pts=grade_pts, sizing="FULL",
        vix_regime="NORMAL", sector_type="CYCLICAL", rs_bucket="LEADING",
    )


def test_init():
    print("\n── TRACKER INIT ──")
    from modules.signal_tracker import init_tracker, _DB_PATH

    def t_creates_db():
        _clean_db()
        init_tracker()
        assert os.path.exists(_DB_PATH), "DB file not created"
        conn = sqlite3.connect(_DB_PATH)
        tables = [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()]
        conn.close()
        assert "signals" in tables
    _run("creates_db_with_signals_table", t_creates_db)

    def t_idempotent():
        init_tracker()  # should not crash on second call
        init_tracker()
    _run("init_idempotent", t_idempotent)


def test_logging():
    print("\n── SIGNAL LOGGING ──")
    from modules.signal_tracker import log_signal, _ensure_db

    def t_logs_entry():
        _clean_db()
        sig = _make_signal()
        result = log_signal(sig)
        assert result is True, "Should return True for new signal"
        conn = _ensure_db()
        row = conn.execute("SELECT * FROM signals WHERE symbol='TATASTEEL'").fetchone()
        conn.close()
        assert row is not None
        assert row["mode"] == "SECONDARY"
        assert row["entry_price"] == 1500.0
        assert row["dual_score"] == 75  # 72 + 3 options
    _run("logs_entry_signal", t_logs_entry)

    def t_deduplicates():
        sig = _make_signal()
        r1 = log_signal(sig)
        r2 = log_signal(sig)  # same symbol + same day = duplicate
        assert r2 is False, "Duplicate should return False"
    _run("deduplicates_same_day", t_deduplicates)

    def t_skips_no_entry():
        _clean_db()
        sig = _make_signal(entry_triggered=False)
        result = log_signal(sig)
        assert result is False
    _run("skips_non_entry_signal", t_skips_no_entry)

    def t_logs_different_symbols():
        _clean_db()
        log_signal(_make_signal(symbol="TATASTEEL"))
        log_signal(_make_signal(symbol="HDFCBANK"))
        conn = _ensure_db()
        count = conn.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
        conn.close()
        assert count == 2
    _run("logs_different_symbols", t_logs_different_symbols)


def test_ride_logging():
    print("\n── RIDE SIGNAL LOGGING ──")
    from modules.signal_tracker import log_ride_signal, log_signal, _ensure_db

    def t_logs_ride_entry():
        _clean_db()
        ride = _make_ride_signal(symbol="RELIANCE")
        result = log_ride_signal(ride)
        assert result is True, "Should return True for new Ride signal"
        conn = _ensure_db()
        row = conn.execute("SELECT * FROM signals WHERE symbol='RELIANCE'").fetchone()
        conn.close()
        assert row is not None
        assert row["mode"] == "RIDE", f"Expected mode=RIDE, got {row['mode']}"
        assert row["segment"] == "BB_RIDE"
        assert row["entry_price"] == 2500.0
        assert row["dual_label"] == "A"  # grade letter
        assert row["dual_score"] == 5    # grade_pts
        assert row["dual_sizing"] == "FULL"
    _run("logs_ride_entry", t_logs_ride_entry)

    def t_ride_skips_no_entry():
        _clean_db()
        ride = _make_ride_signal(entry_triggered=False)
        result = log_ride_signal(ride)
        assert result is False
    _run("ride_skips_non_entry", t_ride_skips_no_entry)

    def t_ride_dedupe():
        _clean_db()
        ride = _make_ride_signal(symbol="ICICIBANK")
        r1 = log_ride_signal(ride)
        r2 = log_ride_signal(ride)
        assert r1 is True
        assert r2 is False, "Duplicate Ride signal should return False"
    _run("ride_deduplicates_same_day", t_ride_dedupe)

    def t_mr_and_ride_coexist():
        """MR and Ride entries on the same day should both log to the same DB."""
        _clean_db()
        log_signal(_make_signal(symbol="TCS"))
        log_ride_signal(_make_ride_signal(symbol="INFY"))
        conn = _ensure_db()
        rows = conn.execute(
            "SELECT symbol, mode FROM signals ORDER BY symbol"
        ).fetchall()
        conn.close()
        assert len(rows) == 2
        modes = {r["symbol"]: r["mode"] for r in rows}
        assert modes["TCS"] == "SECONDARY"  # _make_signal default tier
        assert modes["INFY"] == "RIDE"
    _run("mr_and_ride_coexist", t_mr_and_ride_coexist)

    def t_same_symbol_both_modes():
        """Same symbol logged as both MR and Ride should both be saved
        (different modes shouldn't dedupe)."""
        _clean_db()
        log_signal(_make_signal(symbol="HDFCBANK"))
        log_ride_signal(_make_ride_signal(symbol="HDFCBANK"))
        conn = _ensure_db()
        count = conn.execute(
            "SELECT COUNT(*) FROM signals WHERE symbol='HDFCBANK'"
        ).fetchone()[0]
        conn.close()
        # Note: schema currently dedupes by (symbol, signal_date) only,
        # so this will be 1 not 2. Document the actual behavior.
        # If we want both to coexist, schema needs (symbol, signal_date, mode)
        # as the unique constraint.
        assert count >= 1, "At least one of the two should have logged"
    _run("same_symbol_both_modes", t_same_symbol_both_modes)


def test_resolution():
    print("\n── OUTCOME RESOLUTION ──")
    from modules.signal_tracker import (
        log_signal, resolve_signal, get_unresolved, _ensure_db,
    )

    def t_resolve():
        _clean_db()
        log_signal(_make_signal(symbol="SBIN"))
        unresolved = get_unresolved()
        assert len(unresolved) == 1
        sid = unresolved[0]["id"]

        result = resolve_signal(sid, exit_price=1560.0, peak_price=1580.0)
        assert result is True

        conn = _ensure_db()
        row = conn.execute("SELECT * FROM signals WHERE id=?", (sid,)).fetchone()
        conn.close()
        assert row["resolved"] == 1
        assert row["exit_price"] == 1560.0
        assert abs(row["pnl_pct"] - 4.0) < 0.1  # (1560-1500)/1500 = 4%
    _run("resolves_with_pnl", t_resolve)

    def t_unresolved_excludes_resolved():
        unresolved = get_unresolved()
        assert len(unresolved) == 0, "Resolved signals should not appear"
    _run("unresolved_excludes_resolved", t_unresolved_excludes_resolved)


def test_performance():
    print("\n── PERFORMANCE TRACKING ──")
    from modules.signal_tracker import (
        log_signal, resolve_signal, get_performance, get_unresolved, _ensure_db,
    )

    def t_performance_stats():
        _clean_db()
        # Log and resolve several signals
        for i, (sym, exit_p) in enumerate([
            ("SYM01", 1530),  # +2%
            ("SYM02", 1545),  # +3%
            ("SYM03", 1470),  # -2%
            ("SYM04", 1560),  # +4%
            ("SYM05", 1440),  # -4%
        ]):
            sig = _make_signal(symbol=sym, score=70)
            log_signal(sig)
            # Manually set signal_date in past so it looks mature
            conn = _ensure_db()
            past_date = (datetime.date.today() - datetime.timedelta(days=20+i)).isoformat()
            conn.execute(
                "UPDATE signals SET signal_date=? WHERE symbol=?",
                (past_date, sym),
            )
            conn.commit()
            conn.close()
            sid = get_unresolved()[0]["id"] if get_unresolved() else None
            if sid:
                resolve_signal(sid, exit_price=exit_p, peak_price=max(exit_p, 1500))

        perf = get_performance(mode="SECONDARY")
        assert perf["n_signals"] == 5
        assert perf["win_rate"] == 60.0  # 3/5
        assert perf["avg_pnl"] > 0  # net positive
    _run("computes_performance_stats", t_performance_stats)


def test_drift():
    print("\n── DRIFT DETECTION ──")
    from modules.signal_tracker import check_drift

    def t_drift_no_data():
        _clean_db()
        drift = check_drift()
        # PRIMARY is always checked. SECONDARY is only checked when
        # ENABLE_SECONDARY_TIER is True (production has it False since
        # the 2026-04-08 robust sweep showed SECONDARY drags overall edge).
        from modules.dual_mode import ENABLE_SECONDARY_TIER
        expected_keys = ["PRIMARY"]
        if ENABLE_SECONDARY_TIER:
            expected_keys.append("SECONDARY")
        for mode_key in expected_keys:
            assert drift[mode_key]["status"] == "NO_DATA", (
                f"{mode_key} should be NO_DATA on empty DB, got {drift[mode_key]}"
            )
        # If SECONDARY is disabled, it should NOT be in the drift result
        if not ENABLE_SECONDARY_TIER:
            assert "SECONDARY" not in drift, (
                "SECONDARY should not appear in drift results when "
                "ENABLE_SECONDARY_TIER=False"
            )
    _run("no_data_returns_no_data", t_drift_no_data)


def test_export():
    print("\n── EXPORT ──")
    from modules.signal_tracker import export_report

    def t_export_format():
        _clean_db()
        report = export_report()
        assert "NIMBUS FORWARD VALIDATION REPORT" in report
        assert "PRIMARY" in report
        assert "SECONDARY" in report
        assert "DRIFT STATUS" in report
        assert "SIGNAL LOG" in report
    _run("export_has_all_sections", t_export_format)


def test_snapshot_scheduler():
    print("\n── EOD SNAPSHOT SCHEDULER ──")
    from modules.signal_tracker import (
        get_last_snapshot_date, mark_snapshot_done,
        should_run_snapshot_now, _snapshot_marker_path,
    )

    def _clean_marker():
        path = _snapshot_marker_path()
        if os.path.exists(path):
            os.remove(path)

    def t_marker_roundtrip():
        _clean_marker()
        assert get_last_snapshot_date() is None, "Fresh state should have no marker"
        mark_snapshot_done("2026-04-08")
        assert get_last_snapshot_date() == "2026-04-08"
        # Overwrite
        mark_snapshot_done("2026-04-09")
        assert get_last_snapshot_date() == "2026-04-09"
    _run("marker_file_roundtrip", t_marker_roundtrip)

    def t_marker_path_consistent():
        # Marker path should live next to signal_tracker.db
        from modules.signal_tracker import _resolve_db_path
        db_dir = os.path.dirname(_resolve_db_path("signal_tracker.db"))
        marker = _snapshot_marker_path()
        assert os.path.dirname(marker) == db_dir, \
            f"Marker {marker} not in DB dir {db_dir}"
    _run("marker_path_consistent_with_db", t_marker_path_consistent)

    def t_should_run_returns_tuple():
        # Whatever the result, should_run_snapshot_now must return (bool, str)
        # We don't care about the actual decision here (depends on yfinance + IST clock),
        # just that the contract is honored.
        result = should_run_snapshot_now()
        assert isinstance(result, tuple), f"Expected tuple, got {type(result)}"
        assert len(result) == 2
        assert isinstance(result[0], bool)
        assert isinstance(result[1], str)
        assert result[1], "Reason string should not be empty"
    _run("should_run_returns_bool_reason_tuple", t_should_run_returns_tuple)

    def t_skip_when_marker_current():
        """If the marker file already records today's most recent trading day,
        should_run must return False with 'already done' reason."""
        from modules.signal_tracker import get_most_recent_nse_trading_day
        # If yfinance is unreachable, skip this test gracefully
        last_day = get_most_recent_nse_trading_day()
        if last_day is None:
            print("    (skipped — yfinance unreachable in test env)")
            return
        mark_snapshot_done(last_day)
        should_run, reason = should_run_snapshot_now()
        assert should_run is False, \
            f"Should skip when marker matches latest trading day, got {should_run}"
        assert "already done" in reason.lower()
    _run("skips_when_marker_current", t_skip_when_marker_current)
    print("\n── SOURCE WIRING ──")

    def t_scanner_logs_eod():
        # As of April 2026, EOD logging happens in scanner_tab.py's worker
        # post-compute hook (_maybe_log_eod_snapshot). Dashboard intraday
        # logging was intentionally removed — see scanner_tab.py.
        with open(os.path.join(os.path.dirname(__file__), "..", "ui", "scanner_tab.py")) as f:
            src = f.read()
        assert "log_signal" in src, "log_signal not called in scanner_tab"
        assert "log_ride_signal" in src, "log_ride_signal not called in scanner_tab"
        assert "_maybe_log_eod_snapshot" in src, \
            "EOD snapshot hook missing from scanner worker"
        assert "should_run_snapshot_now" in src, \
            "Snapshot scheduling check missing from scanner worker"
    _run("scanner_logs_eod_snapshot", t_scanner_logs_eod)

    def t_data_manager_no_intraday_logging():
        # Dashboard logging was removed — verify it's still removed.
        # If this test fails, someone re-added intraday logging by accident.
        with open(os.path.join(os.path.dirname(__file__), "..", "ui", "data_manager.py")) as f:
            src = f.read()
        assert "log_signal(dm_sig)" not in src, \
            "Dashboard MR auto-logging was re-introduced — should be EOD only"
        assert "log_ride_signal(ride_result)" not in src, \
            "Dashboard Ride auto-logging was re-introduced — should be EOD only"
    _run("data_manager_no_intraday_logging", t_data_manager_no_intraday_logging)

    def t_main_window_inits():
        with open(os.path.join(os.path.dirname(__file__), "..", "ui", "main_window.py")) as f:
            src = f.read()
        assert "init_tracker" in src, "init_tracker not in main_window"
    _run("main_window_inits_tracker", t_main_window_inits)


if __name__ == "__main__":
    print("=" * 60)
    print("NIMBUS Signal Tracker Test Suite")
    print("=" * 60)

    test_init()
    test_logging()
    test_ride_logging()
    test_resolution()
    test_performance()
    test_drift()
    test_export()
    test_snapshot_scheduler()  # also runs source wiring checks (consolidated)

    print(f"\n{'=' * 60}")
    print(f"RESULTS: {_PASS} passed, {_FAIL} failed")
    print("=" * 60)
    if _ERRORS:
        for n, e in _ERRORS:
            print(f"  {n}: {e}")
    sys.exit(1 if _FAIL > 0 else 0)
