"""tests.ui.test_industry_context_card — smoke tests for the
synthetic-index industry context card.

The card has three render branches: active (RideResult present and
member_count high enough), thin-peer (member_count below threshold),
and unavailable (industry None or RideResult empty). These tests
exercise each, plus :meth:`clear`.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.ride_initiation import RidePhase, RideResult
from nimbus_v3.ui.theme import BORDER, EM, MUTED
from nimbus_v3.ui.widgets.industry_context_card import IndustryContextCard


# ══════════════════════════════════════════════════════════════════════════════
# Helpers — synthesise RideResult instances directly rather than running
# the engine, so tests don't depend on RideEngine's threshold tuning.
# ══════════════════════════════════════════════════════════════════════════════


def _ride_result(
    phase: RidePhase,
    score: float = 75.0,
    n: int = 10,
) -> RideResult:
    """Build a RideResult whose latest bar carries (phase, score, fire)."""
    idx = pd.date_range("2024-01-01", periods=n, freq="B")
    phase_series = pd.Series(
        [RidePhase.NONE.value] * (n - 1) + [phase.value],
        index=idx,
        dtype=object,
    )
    score_series = pd.Series(
        [np.nan] * (n - 1) + [score],
        index=idx,
        dtype=float,
    )
    fire_series = pd.Series(
        [False] * (n - 1) + [phase is not RidePhase.NONE],
        index=idx,
        dtype=bool,
    )
    return RideResult(
        phase=phase_series,
        score=score_series,
        fire=fire_series,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Construction
# ══════════════════════════════════════════════════════════════════════════════


def test_card_constructs_in_empty_state(qapp):    # noqa: ARG001
    c = IndustryContextCard()
    assert c._industry_lbl.text() == "—"
    assert c._note_lbl.text() == "Industry context unavailable."


# ══════════════════════════════════════════════════════════════════════════════
# Unavailable branch
# ══════════════════════════════════════════════════════════════════════════════


def test_set_state_with_none_industry_renders_unavailable(qapp):    # noqa: ARG001
    c = IndustryContextCard()
    c.set_state(None, _ride_result(RidePhase.INITIATION), member_count=10)
    assert c._industry_lbl.text() == "—"
    assert "unavailable" in c._note_lbl.text().lower()


def test_set_state_with_none_ride_result_is_unavailable(qapp):    # noqa: ARG001
    c = IndustryContextCard()
    c.set_state("Banks", None, member_count=8)
    assert c._industry_lbl.text() == "Banks"
    assert "unavailable" in c._note_lbl.text().lower()


def test_set_state_with_thin_industry_uses_thin_branch(qapp):    # noqa: ARG001
    """Member count below ``min_members`` flips to the thin branch
    even if a ride_result is present."""
    c = IndustryContextCard()
    c.set_state(
        "Banks",
        _ride_result(RidePhase.INITIATION),
        member_count=2,
        min_members=3,
    )
    assert c._industry_lbl.text() == "Banks"
    note = c._note_lbl.text()
    assert "≥3" in note or "members" in note.lower()


# ══════════════════════════════════════════════════════════════════════════════
# Active branch
# ══════════════════════════════════════════════════════════════════════════════


def test_active_init_renders_emerald_accent(qapp):    # noqa: ARG001
    c = IndustryContextCard()
    c.set_state(
        "Banks",
        _ride_result(RidePhase.INITIATION, score=80.0),
        member_count=12,
    )
    assert c._industry_lbl.text() == "Banks"
    # Phase row content surfaces somewhere in the card body.
    row_texts = [
        c._rows_layout.itemAt(i).widget().findChildren(type(c._industry_lbl))
        for i in range(c._rows_layout.count())
    ]
    flat = [w.text() for sub in row_texts for w in sub]
    assert "INIT" in " ".join(flat)
    assert "80" in " ".join(flat)
    # Note line reflects initiation phrasing.
    assert "initiat" in c._note_lbl.text().lower()
    # Accent border on the panel is the INIT colour (emerald).
    assert EM in c._panel.styleSheet()


def test_active_retest_renders_blue_accent(qapp):    # noqa: ARG001
    from nimbus_v3.ui.theme import BLUE

    c = IndustryContextCard()
    c.set_state(
        "Software",
        _ride_result(RidePhase.RETEST, score=62.0),
        member_count=15,
    )
    assert "resuming" in c._note_lbl.text().lower()
    assert BLUE in c._panel.styleSheet()


def test_active_continuation_uses_muted_accent(qapp):    # noqa: ARG001
    c = IndustryContextCard()
    c.set_state(
        "Cement",
        _ride_result(RidePhase.CONTINUATION, score=55.0),
        member_count=8,
    )
    assert "continuation" in c._note_lbl.text().lower()
    assert MUTED in c._panel.styleSheet()


def test_active_none_phase_uses_neutral_accent(qapp):    # noqa: ARG001
    """A non-empty RideResult whose latest phase is NONE means the
    industry isn't riding right now — neutral accent + 'not riding'
    note."""
    c = IndustryContextCard()
    c.set_state(
        "Pharma",
        _ride_result(RidePhase.NONE, score=float("nan")),
        member_count=12,
    )
    assert "not riding" in c._note_lbl.text().lower()
    assert BORDER in c._panel.styleSheet()


# ══════════════════════════════════════════════════════════════════════════════
# Clear
# ══════════════════════════════════════════════════════════════════════════════


def test_clear_returns_to_empty_state(qapp):    # noqa: ARG001
    c = IndustryContextCard()
    c.set_state(
        "Banks",
        _ride_result(RidePhase.INITIATION, score=80.0),
        member_count=12,
    )
    assert c._industry_lbl.text() == "Banks"
    c.clear()
    assert c._industry_lbl.text() == "—"
    assert c._note_lbl.text() == "Industry context unavailable."
    assert BORDER in c._panel.styleSheet()
