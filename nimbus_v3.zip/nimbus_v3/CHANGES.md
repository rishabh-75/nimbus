# Changes

## v0.2.0a0 — slim ride-strategy refactor

The terminal is now ride-strategy-only. Everything related to the
mean-reversion / breakout / trap / drawdown-reversal / ETF-momentum
strategies, the conviction grading layer, the scan orchestrator, the
macro flow tab, and the conservative/aggressive mode toggle has been
deleted.

### Deleted packages

- `nimbus_v3/scanner/` — entire package (scan engine, ContextProviders).
- `nimbus_v3/strategies/` — every strategy module + registry.
- `nimbus_v3/conviction/` — formula + grade engine + fixtures.
- `nimbus_v3/tracking/` — signal tracker + stats.
- `nimbus_v3/macro/` — flow detector + universe.
- `nimbus_v3/research/` — walk-forward harness + ETF universe builder.
- `nimbus_v3/analysis/` — `trend_phase.py` was the only file.

### Deleted modules

- `compute/industry_analytics.py` (~900 lines, MR-era batched analytics).
- `compute/market_regime.py` (broad-decline guard).
- `compute/flow_analytics.py` (commodity flow).
- `core/industry_state.py`, `core/industry_relative_state.py`,
  `core/signal_state.py`.
- `data/industry_states_cache.py`.
- `ui/widgets/scanner_tab.py`, `ui/widgets/macro_flow_panel.py`.
- `ui/preferences.py` (only persisted `strategy_mode`).
- `ui/models/scan_results_model.py`.
- 31 dependent scripts under `scripts/`.

### Slimmed surfaces

#### `compute/engine.py` — new schema hash `3eb7942e`

`StrategyComputeEngine` now produces only what the BB ride classifier
reads. The 14-family enrichment profile collapsed to four:

```
sma_20
atr_14, atr_14_pct
bb_20_1s_upper / mid / lower / pct
bbw_20_1s, bbw_20_1s_slope, bbw_20_1s_pctl
data_sufficient
```

Dropped indicators: SMA 10/50/200, Williams %R (14/20/30/50), RSI(14),
MFI(14), ADX(14), BB 2σ envelope + bandwidth, drawdowns (20/50),
streaks, volume_ratio_20, ROC 5/10/20, position_vs_ma flags.

`extract_state()`, `validate_enriched()`, and `_EXPECTED_COLUMNS` have
all been removed. There is no `SignalState` dataclass anymore — every
downstream consumer reads enriched columns directly.

**Cache impact**: the schema hash changed from `7cb86ba8` to
`3eb7942e`. Existing parquets under `data/cache/equity_enriched/`
remain on disk but become unreachable by path. First launch after the
upgrade will repopulate the cache from the raw price cache.

#### `compute/indicators.py`

Reduced to five public surfaces: `_require_ohlcv`,
`add_moving_averages`, `add_atr`, `add_bollinger`,
`add_bollinger_bandwidth`, `add_data_sufficiency`.

#### `core/types.py`

Surviving enums (consumed by the four context providers):
`VIXRegime`, `SectorType`, `RSRegime`, `ExpiryRisk`, `GEXRegime`,
`FilingImpact`. Dropped: `SetupType`, `GradeLetter`, `Verdict`,
`Sizing`, `StrategyMode`, `VolState`, `FlowSignal`.

### Rewritten UI

#### Two tabs

`Dashboard` and `Market Pulse`. The Macro / Commodity tab and the
Scanner tab are gone.

#### Sidebar

Dropped: strategy-mode toggle, mean-reversion panel, ACTIVE SIGNALS
panel. New panels: header echo (symbol/spot/Δ%), four-row Industry
classification, BB Ride (phase, score, four detail rows, verdict
line, footer note). Public API:

```
signals:  symbol_changed(str), refresh_clicked()
methods:  set_universe, set_selected_symbol, current_symbol,
          apply_header(HeaderView),
          apply_ride_view(RideView),
          apply_industry_view(IndustryClassificationView),
          clear()
```

#### Dashboard tab

Workflow Analysis collapsed from 13 sections to two: **Options
Overlay** (the 11 fields the chart already overlays as horizontal
lines, plus PCR/GEX/IV regime cells) and **Industry Context** (the
synthetic-index ride state for the active symbol's industry).

Dropped: badge row, KPI tile row, filing strip, MR verdict strip,
Ride verdict strip, Panel B Key Levels, Panel C Checklist. The new
right rail is fixed 280px; the chart gets the rest.

#### Industry Context card

Wired to `RideEngine.classify_industry` (synthetic-index path).
Renders one of three states: active (Phase + Score + Members + a
contextual note, accent coloured by phase), thin-peer (Members
count + caveat when fewer than 3 peers in the panel), or unavailable
(muted placeholder).

#### MainWindow

`Sidebar | (Dashboard | Market Pulse)` with status bar carrying
freshness + EOD labels. Sidebar drives the Dashboard only — Market
Pulse runs independently and triggers its own panel-load on first
show.

### Lazy providers

NSE client warm, Options provider, Filing provider, VIX provider are
no longer constructed at startup. `main.py` now only builds:
- the `StrategyComputeEngine`
- the panel-loader closure
- the `DataManager` for async per-symbol I/O
- a zero-arg `options_builder` closure

The options builder fires on the first `OptionsResult` arrival. The
filing / VIX surfaces are not yet wired into the slim Dashboard;
they'll be re-introduced if a concrete dashboard panel needs them.

### Synthetic-index industry classifier

Carried over from the previous session and untouched in this
refactor. `RideEngine.classify_industry()` and `classify_universe()`
return a full `RideResult` from an ADTV-weighted synthetic OHLCV
series — heavyweights by liquidity dominate the aggregate
naturally, no consensus voting. Used by both the Market Pulse
group / constituent tables and the new Industry Context card on the
Dashboard.

### Tests

- `tests/compute/test_indicators.py` rewritten to cover only the
  surviving five surfaces (19 cases).
- `tests/compute/test_engine.py` deleted (covered the
  removed `extract_state` / `validate_enriched` API).
- `tests/core/test_types.py` rewritten for the surviving six enums.
- `tests/core/test_signal_state.py` deleted.
- All UI tests for deleted widgets dropped (`test_scanner_tab*.py`,
  `test_industry_context_card*.py`, `test_dashboard_tab.py`,
  `test_main_window*.py`, `test_macro_flow_panel.py`,
  `test_sidebar.py`, `test_widgets.py`, `test_components.py`,
  `test_price_chart.py`, `test_main_entrypoint.py`,
  `test_market_context_tab_adtv_bb.py`).
- `tests/scripts/`, `tests/scanner/`, `tests/strategies/`,
  `tests/conviction/`, `tests/tracking/`, `tests/macro/`,
  `tests/analysis/`, `tests/research/`, `tests/classifiers/`,
  `tests/events/`, `tests/integration/` — all deleted.
- New UI smoke tests for the rewritten surfaces (Sidebar,
  IndustryContextCard, DashboardTab, MainWindow construction).

**Final test count**: 387 + new UI smokes; ride_initiation stays at
35/35. Schema hash `3eb7942e`.

### `pyproject.toml`

Console-script entries trimmed to surviving scripts only:

```toml
[project.scripts]
nimbus-download-universe = "scripts.download_universe:main"
nimbus-build-industry-db = "scripts.build_industry_db:main"
```

Version bumped to `0.2.0a0`.
