"""nimbus_v3.compute.correlation_regime — cross-industry correlation
regime classifier.

Computes the **mean off-diagonal pairwise correlation** of industry
returns across a rolling 60-day window, then classifies the latest
bar against its own trailing 252-day distribution into one of:

  HIGH    — top 20% of trailing distribution (≥ 80th percentile)
  NORMAL  — 20-80th percentile (the muddled middle)
  LOW     — bottom 20% (≤ 20th percentile)
  UNKNOWN — insufficient history (warmup)

The percentile-rank classification is adaptive: a "HIGH" reading
in 2024 is high *relative to recent history*, not against an
absolute correlation level. This matters because base correlation
levels drift over time as the panel composition and broad-market
regime change.

Validated by walk-forward testing on 2022-2026 NSE Nifty 500 data
(see ``docs/research_notes/correlation_regime/``). Headline finding:

  HIGH    → fwd_10d +1.6pp lift (robust mean across folds, post-
             stress recovery regime — V-shape recoveries from fear
             events)
  NORMAL  → fwd_10d -1.1pp lift (transitional regime, no clear
             cohesion or rotation — the worst forward-return state)
  LOW     → fwd_10d ~+0.0pp lift (orderly bull-market regime,
             dispersed sectoral rotation, no specific tilt)

CRITICAL CAVEAT: the validated sample (2022-2026) is a structural
Indian bull market. HIGH_CORR's positive tilt is contingent on the
"buy the dip" pattern that resolved every fear event upward within
the 10-day forward window. **In a sustained bear market or
1990s-style sideways regime, HIGH_CORR may flip to negative
forward-return predictor.** Operators using this badge should treat
the directional implication as empirically true on recent data, not
as a regime-invariant truth.

Consumed by:
  - Currently no UI surface — the regime classifier is preserved
    as a research artefact for future re-introduction. The previous
    Market Pulse tab's header badge was dropped during the
    Dashboard / Market Pulse unification.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd


# ══════════════════════════════════════════════════════════════════════
# Tunable constants (changing any invalidates downstream caches via
# schema_hash())
# ══════════════════════════════════════════════════════════════════════

#: Rolling window for computing the pairwise-correlation matrix on
#: industry returns. 60 trading days ≈ 3 months. Long enough for
#: matrix stability, short enough to capture regime shifts.
CORR_WINDOW: Final[int] = 60

#: Trailing window for percentile-rank classification. 252 days ≈ 1
#: year of trading. Each bar's correlation reading is ranked against
#: the prior year's distribution so the classifier adapts to drift
#: in base correlation levels.
PCTILE_WINDOW: Final[int] = 252

#: Top quintile cutoff for HIGH regime classification.
HIGH_PCTILE: Final[float] = 0.80

#: Bottom quintile cutoff for LOW regime classification.
LOW_PCTILE: Final[float] = 0.20

#: Minimum number of industries needed for a meaningful correlation
#: matrix on a given bar. Below this we emit UNKNOWN.
MIN_INDUSTRIES: Final[int] = 10


# ══════════════════════════════════════════════════════════════════════
# Regime labels — exported as constants so callers don't reference
# string literals. Kept separate from VIXPaceClassifier's labels
# (RISING/STABLE/FALLING) to avoid namespace collision.
# ══════════════════════════════════════════════════════════════════════

REGIME_HIGH: Final[str] = "HIGH"
REGIME_NORMAL: Final[str] = "NORMAL"
REGIME_LOW: Final[str] = "LOW"
REGIME_UNKNOWN: Final[str] = "UNKNOWN"

ALL_REGIMES: Final[tuple[str, ...]] = (
    REGIME_HIGH, REGIME_NORMAL, REGIME_LOW, REGIME_UNKNOWN,
)


# ══════════════════════════════════════════════════════════════════════
# State dataclass
# ══════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class CorrelationRegimeState:
    """Classification result for the latest bar of an industry-returns
    panel.

    Carries the regime label plus diagnostic numerics so the UI can
    render a tooltip explaining *why* the regime fired.
    """

    #: Regime label: ``HIGH`` / ``NORMAL`` / ``LOW`` / ``UNKNOWN``.
    regime: str

    #: Mean off-diagonal pairwise correlation on the latest bar.
    #: Range typically [0.2, 0.8] for NSE industries.
    mean_correlation: float

    #: Percentile of ``mean_correlation`` against the trailing
    #: ``PCTILE_WINDOW``-day distribution. Range [0, 1].
    pctile: float

    #: Number of industries that had usable data on the latest bar.
    #: When < ``MIN_INDUSTRIES``, regime is forced to UNKNOWN.
    n_industries: int


# ══════════════════════════════════════════════════════════════════════
# Classifier
# ══════════════════════════════════════════════════════════════════════

class CorrelationRegimeClassifier:
    """Classify the latest bar of industry returns into a correlation
    regime.

    Stateless — instances carry no per-call state. Constants are
    read from module-level so subclassing for parameter sweeps is
    not supported (use research scripts instead).
    """

    def classify_current(
        self, industry_returns: pd.DataFrame,
    ) -> CorrelationRegimeState:
        """Return the regime state for the LATEST bar of the
        industry returns panel.

        ``industry_returns`` is a wide DataFrame: index = trading
        dates, columns = industry names, values = daily simple
        returns. Industries with NaN returns on the latest window
        are dropped from the correlation matrix.

        Returns ``UNKNOWN`` regime when:
          - Fewer than ``CORR_WINDOW`` bars in the panel
          - Fewer than ``MIN_INDUSTRIES`` columns with valid data
            on the latest window
          - Fewer than ``PCTILE_WINDOW`` historical correlation
            values to rank against (warmup)
        """
        # Drop bars where every industry is NaN
        ind_ret = industry_returns.dropna(how="all")
        if len(ind_ret) < CORR_WINDOW:
            return CorrelationRegimeState(
                regime=REGIME_UNKNOWN,
                mean_correlation=float("nan"),
                pctile=float("nan"),
                n_industries=ind_ret.shape[1],
            )

        # Compute the full correlation series (so we can rank the
        # latest value against the trailing distribution).
        corr_series = self._mean_pairwise_correlation_series(ind_ret)

        latest_corr = corr_series.iloc[-1]
        if np.isnan(latest_corr):
            return CorrelationRegimeState(
                regime=REGIME_UNKNOWN,
                mean_correlation=float("nan"),
                pctile=float("nan"),
                n_industries=ind_ret.shape[1],
            )

        # Trailing PCTILE_WINDOW bars (excluding the latest itself
        # so we're not ranking against ourselves)
        trailing = corr_series.iloc[-(PCTILE_WINDOW + 1):-1].dropna()
        if len(trailing) < PCTILE_WINDOW:
            return CorrelationRegimeState(
                regime=REGIME_UNKNOWN,
                mean_correlation=float(latest_corr),
                pctile=float("nan"),
                n_industries=ind_ret.shape[1],
            )

        # Empirical CDF: fraction of trailing values strictly less
        # than the latest. (≤ would conflate ties with strict
        # below-rank; using strict < gives "more extreme" semantics.)
        pctile = float((trailing < latest_corr).sum()) / len(trailing)

        if pctile >= HIGH_PCTILE:
            regime = REGIME_HIGH
        elif pctile <= LOW_PCTILE:
            regime = REGIME_LOW
        else:
            regime = REGIME_NORMAL

        return CorrelationRegimeState(
            regime=regime,
            mean_correlation=float(latest_corr),
            pctile=pctile,
            n_industries=ind_ret.shape[1],
        )

    # ── helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _mean_pairwise_correlation_series(
        industry_returns: pd.DataFrame,
    ) -> pd.Series:
        """Mean off-diagonal cell of the rolling-window correlation
        matrix at each bar.

        Same math as ``scripts/run_correlation_regime_validation.py``
        — the production classifier and the research validator must
        compute identical values for the validated lift to apply.
        """
        arr = industry_returns.values    # (T, N)
        T, N = arr.shape
        out = pd.Series(np.nan, index=industry_returns.index, dtype=float)

        for t in range(CORR_WINDOW - 1, T):
            block = arr[t - CORR_WINDOW + 1:t + 1, :]
            valid_mask = ~np.isnan(block).any(axis=0)
            if valid_mask.sum() < MIN_INDUSTRIES:
                continue
            valid_block = block[:, valid_mask]
            corr_matrix = np.corrcoef(valid_block, rowvar=False)
            n_valid = valid_block.shape[1]
            iu = np.triu_indices(n_valid, k=1)
            if iu[0].size == 0:
                continue
            out.iloc[t] = float(np.nanmean(corr_matrix[iu]))

        return out


# ══════════════════════════════════════════════════════════════════════
# Schema hash — used by downstream caches to invalidate when the
# classifier's parameters change. Same pattern as VIXPaceClassifier.
# ══════════════════════════════════════════════════════════════════════

def schema_hash() -> str:
    """Hash of the tunable constants. Cache keys derived from this
    invalidate automatically when any classifier parameter changes.
    """
    payload = (
        f"corr_window={CORR_WINDOW}|"
        f"pctile_window={PCTILE_WINDOW}|"
        f"high_pctile={HIGH_PCTILE}|"
        f"low_pctile={LOW_PCTILE}|"
        f"min_industries={MIN_INDUSTRIES}"
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:8]
