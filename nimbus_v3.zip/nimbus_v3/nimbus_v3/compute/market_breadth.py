"""nimbus_v3.compute.market_breadth — universe-wide breadth metrics.

Stateless. Given the equity panel (``{symbol: daily OHLCV}``), builds a
single daily DataFrame of market-breadth series, plus a small snapshot
of the latest values for the sidebar readout. Symbol-independent: the
same result regardless of which symbol is selected, so it's computed
once when the panel loads.

Metrics (all daily, indexed by date):
  adv, dec            advancers / decliners (Close vs prior Close)
  ad_line             cumulative Σ(adv − dec) — the advance/decline line
  pct_above_sma50     % of universe with Close > its own 50-day SMA
  pct_above_sma200    % of universe with Close > its own 200-day SMA
  new_highs, new_lows count making a `NH_NL_WINDOW`-day high / low
  nh_nl_diff          new_highs − new_lows

These are deliberately computed from raw Close (not the ride
enrichment, which only carries SMA20) so breadth stays an independent
concern. ``breadth_snapshot`` reduces the frame to the latest row for
the sidebar panel.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

#: Lookback for the new-high / new-low count. ~1 trading year; capped by
#: available history per symbol (min_periods lets shorter histories still
#: contribute once they have enough bars).
NH_NL_WINDOW: int = 252
_SMA_FAST: int = 50
_SMA_SLOW: int = 200


@dataclass(frozen=True)
class BreadthSnapshot:
    """Latest-bar breadth readout for the sidebar panel."""

    asof: pd.Timestamp | None
    universe: int               # symbols with usable data on the last bar
    adv: int
    dec: int
    pct_above_sma50: float      # 0..100
    pct_above_sma200: float     # 0..100
    ad_line: float              # cumulative advance/decline line level
    nh_nl_diff: int             # new highs − new lows
    breadth_delta: float        # day-over-day change in pct_above_sma50 (pp)


def compute_breadth(panel: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Build the daily breadth DataFrame from the equity panel.

    Args:
        panel: ``{symbol: daily OHLCV}``. Each frame must have a
            DatetimeIndex and a ``Close`` column; ``High``/``Low`` are
            used for new-high/low if present.

    Returns:
        DataFrame indexed by date with the breadth columns. Empty frame
        if the panel has no usable members.
    """
    closes: dict[str, pd.Series] = {}
    highs: dict[str, pd.Series] = {}
    lows: dict[str, pd.Series] = {}
    for sym, df in panel.items():
        if df is None or df.empty or "Close" not in df.columns:
            continue
        closes[sym] = df["Close"]
        if "High" in df.columns:
            highs[sym] = df["High"]
        if "Low" in df.columns:
            lows[sym] = df["Low"]
    if not closes:
        return pd.DataFrame()

    close_df = pd.DataFrame(closes).sort_index()

    # Advancers / decliners — sign of the daily Close change per symbol.
    chg = close_df.diff()
    adv = (chg > 0).sum(axis=1).astype(int)
    dec = (chg < 0).sum(axis=1).astype(int)
    ad_line = (adv - dec).cumsum()

    # % above own SMA50 / SMA200. count(Close>SMA) / count(valid SMA).
    sma50 = close_df.rolling(_SMA_FAST, min_periods=_SMA_FAST).mean()
    sma200 = close_df.rolling(_SMA_SLOW, min_periods=_SMA_SLOW).mean()
    above50 = (close_df > sma50).sum(axis=1)
    valid50 = sma50.notna().sum(axis=1)
    above200 = (close_df > sma200).sum(axis=1)
    valid200 = sma200.notna().sum(axis=1)
    pct50 = (above50 / valid50.replace(0, np.nan) * 100.0)
    pct200 = (above200 / valid200.replace(0, np.nan) * 100.0)

    # New highs / lows over the rolling window (use High/Low when we have
    # them, else Close).
    high_df = pd.DataFrame(highs).sort_index() if highs else close_df
    low_df = pd.DataFrame(lows).sort_index() if lows else close_df
    roll_hi = high_df.rolling(NH_NL_WINDOW, min_periods=20).max()
    roll_lo = low_df.rolling(NH_NL_WINDOW, min_periods=20).min()
    new_highs = (high_df >= roll_hi).sum(axis=1).astype(int)
    new_lows = (low_df <= roll_lo).sum(axis=1).astype(int)

    out = pd.DataFrame({
        "adv": adv,
        "dec": dec,
        "ad_line": ad_line,
        "pct_above_sma50": pct50,
        "pct_above_sma200": pct200,
        "new_highs": new_highs,
        "new_lows": new_lows,
        "nh_nl_diff": (new_highs - new_lows).astype(int),
    })
    return out


def breadth_snapshot(breadth: pd.DataFrame) -> BreadthSnapshot:
    """Reduce the breadth frame to its latest-bar snapshot."""
    if breadth is None or breadth.empty:
        return BreadthSnapshot(
            asof=None, universe=0, adv=0, dec=0,
            pct_above_sma50=float("nan"), pct_above_sma200=float("nan"),
            ad_line=float("nan"), nh_nl_diff=0, breadth_delta=float("nan"),
        )
    last = breadth.iloc[-1]
    prev_pct50 = (
        float(breadth["pct_above_sma50"].iloc[-2])
        if len(breadth) >= 2 else float("nan")
    )
    cur_pct50 = float(last["pct_above_sma50"])
    delta = (cur_pct50 - prev_pct50) if (
        cur_pct50 == cur_pct50 and prev_pct50 == prev_pct50
    ) else float("nan")
    return BreadthSnapshot(
        asof=breadth.index[-1],
        universe=int(last["adv"] + last["dec"]),
        adv=int(last["adv"]),
        dec=int(last["dec"]),
        pct_above_sma50=cur_pct50,
        pct_above_sma200=float(last["pct_above_sma200"]),
        ad_line=float(last["ad_line"]),
        nh_nl_diff=int(last["nh_nl_diff"]),
        breadth_delta=delta,
    )
