#!/usr/bin/env python3
"""
scripts/validate_q_score.py — Meta-validation of regime detector Q score.

Question: Is the Q score from modules/strategy_regime.py a reliable predictor
of forward strategy performance? Or is it just noise?

Methodology:
    1. Take a long trade history CSV (any strategy, any source). Required
       columns: entry_date, exit_date, pnl_pct.
    2. Sort chronologically by entry_date.
    3. For each trade T, compute the rolling Q score using all PRIOR
       resolved trades within the last 90 calendar days (mirroring
       compute_strategy_regimes() in strategy_regime.py exactly).
    4. Classify the state at T: ACTIVE (Q ≥ 0), DORMANT (Q < 0), or
       CALIBRATING (n < 15 in the rolling window).
    5. Look forward at the next M trades from T (default M=10) and measure
       what actually happened: avg pnl, win rate, sharpe.
    6. Aggregate forward stats per state.

Reliable Q score: ACTIVE-state forward stats >> DORMANT-state forward stats.
Unreliable Q score: forward stats are similar regardless of state classification.

Also produces a confusion matrix:
    - True Positive:  state=ACTIVE,  forward profitable
    - True Negative:  state=DORMANT, forward unprofitable
    - False Positive: state=ACTIVE,  forward unprofitable (Q said go, lost money)
    - False Negative: state=DORMANT, forward profitable (Q said sit out, missed gains)

Usage:
    python3 scripts/validate_q_score.py path/to/trades.csv
    python3 scripts/validate_q_score.py path/to/trades.csv --forward 20
    python3 scripts/validate_q_score.py path/to/trades.csv --window 60

Output:
    Console + auto-saved report
"""
import sys, os, argparse, datetime, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.output import enable_export
enable_export()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("validate_q")

import numpy as np
import pandas as pd

# Import the EXACT constants from the production regime detector — no
# reimplementation drift. If strategy_regime.py changes, this script
# automatically follows.
from modules.strategy_regime import (
    _RFR_ANNUAL,
    _AVG_HOLD_DAYS,
    _TRADE_RFR_PCT,
    _ANNUALIZATION_FACTOR,
    _DORMANT_THRESHOLD,
    _MIN_TRADES_FOR_REGIME,
)


def compute_q_score(pnls):
    """Mirror compute_strategy_regimes() Q calculation exactly.
    Returns (q_score, state) where state is ACTIVE, DORMANT, or CALIBRATING."""
    n = len(pnls)
    if n < _MIN_TRADES_FOR_REGIME:
        return None, "CALIBRATING"
    arr = np.array(pnls)
    std = arr.std()
    if std == 0:
        return 0.0, "ACTIVE"
    excess = arr - _TRADE_RFR_PCT
    q = float(excess.mean() / std * _ANNUALIZATION_FACTOR)
    state = "DORMANT" if q < _DORMANT_THRESHOLD else "ACTIVE"
    return q, state


def calc_stats(pnls):
    if not pnls:
        return {"n": 0, "win": 0, "avg": 0, "sharpe": 0}
    arr = np.array(pnls)
    avg = float(arr.mean())
    std = float(arr.std())
    return {
        "n": len(arr),
        "win": float((arr > 0).mean() * 100),
        "avg": avg,
        "sharpe": (avg / std * np.sqrt(252 / _AVG_HOLD_DAYS)) if std > 0 else 0,
    }


def validate(trades_df, window_days=90, forward_n=10):
    """
    Walk through trades chronologically, compute rolling Q score at each
    position, measure forward N-trade performance, classify each window.

    Returns a dict with per-state aggregates and confusion matrix counts.
    """
    # Sort by entry_date ascending
    df = trades_df.copy()
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    df["exit_date"] = pd.to_datetime(df["exit_date"])
    df = df.sort_values("entry_date").reset_index(drop=True)

    n_total = len(df)
    if n_total < _MIN_TRADES_FOR_REGIME + forward_n:
        logger.error("Need at least %d trades for validation, got %d",
                     _MIN_TRADES_FOR_REGIME + forward_n, n_total)
        return None

    logger.info("Trade history: %d trades, %s → %s",
                n_total, df["entry_date"].iloc[0].date(), df["entry_date"].iloc[-1].date())
    logger.info("Window: %d days rolling | Forward measurement: next %d trades",
                window_days, forward_n)
    logger.info("")

    # State classifications and forward outcomes
    by_state = {"ACTIVE": [], "DORMANT": [], "CALIBRATING": []}
    confusion = {"TP": 0, "TN": 0, "FP": 0, "FN": 0}

    # For each position T (skip the last forward_n positions since they
    # don't have a complete forward window)
    for t in range(n_total - forward_n):
        cur_entry = df["entry_date"].iloc[t]
        cutoff = cur_entry - pd.Timedelta(days=window_days)

        # Rolling window: trades with entry_date in [cutoff, cur_entry) AND
        # already resolved (exit_date < cur_entry). Mirrors the regime
        # detector's "resolved trades within window" logic.
        prior_mask = (
            (df["entry_date"] >= cutoff) &
            (df["entry_date"] < cur_entry) &
            (df["exit_date"] < cur_entry)
        )
        prior_pnls = df.loc[prior_mask, "pnl_pct"].tolist()

        q, state = compute_q_score(prior_pnls)

        # Forward window: trades from T to T+forward_n-1
        forward_pnls = df["pnl_pct"].iloc[t : t + forward_n].tolist()
        forward_avg = np.mean(forward_pnls) if forward_pnls else 0.0
        forward_win = float((np.array(forward_pnls) > 0).mean() * 100)

        by_state[state].append({
            "q_score": q if q is not None else 0.0,
            "forward_avg": forward_avg,
            "forward_win": forward_win,
            "forward_pnls": forward_pnls,
        })

        # Confusion matrix (only for non-calibrating states)
        if state == "ACTIVE":
            if forward_avg > 0:
                confusion["TP"] += 1
            else:
                confusion["FP"] += 1
        elif state == "DORMANT":
            if forward_avg <= 0:
                confusion["TN"] += 1
            else:
                confusion["FN"] += 1

    return {
        "by_state": by_state,
        "confusion": confusion,
        "n_total": n_total,
        "n_evaluated": n_total - forward_n,
    }


def report(result, label):
    by_state = result["by_state"]
    confusion = result["confusion"]
    n_evaluated = result["n_evaluated"]

    logger.info("=" * 80)
    logger.info("Q SCORE RELIABILITY: %s", label)
    logger.info("=" * 80)
    logger.info("Trade positions evaluated: %d", n_evaluated)
    logger.info("")

    # Per-state aggregates
    logger.info("FORWARD PERFORMANCE BY Q SCORE STATE")
    logger.info("-" * 80)
    logger.info("%-12s  %5s  %8s  %8s  %8s  %8s  %s",
                "State", "N", "% time", "Avg pnl", "Win%", "F. Sh", "Mean Q")
    logger.info("-" * 80)

    for state in ["ACTIVE", "DORMANT", "CALIBRATING"]:
        entries = by_state[state]
        if not entries:
            logger.info("%-12s  %5d  %7.1f%%  %s",
                        state, 0, 0.0, "(no instances)")
            continue

        n = len(entries)
        pct_time = n / n_evaluated * 100

        # Pool all forward pnls for this state
        all_forward_pnls = []
        for e in entries:
            all_forward_pnls.extend(e["forward_pnls"])
        s = calc_stats(all_forward_pnls)
        mean_q = float(np.mean([e["q_score"] for e in entries]))

        logger.info("%-12s  %5d  %7.1f%%  %+7.3f%%  %6.1f%%  %+7.2f  %+5.2f",
                     state, n, pct_time, s["avg"], s["win"], s["sharpe"], mean_q)

    logger.info("")

    # Reliability check
    active_entries = by_state["ACTIVE"]
    dormant_entries = by_state["DORMANT"]
    if active_entries and dormant_entries:
        active_forward = []
        dormant_forward = []
        for e in active_entries: active_forward.extend(e["forward_pnls"])
        for e in dormant_entries: dormant_forward.extend(e["forward_pnls"])
        active_avg = np.mean(active_forward)
        dormant_avg = np.mean(dormant_forward)
        spread = active_avg - dormant_avg

        logger.info("RELIABILITY METRIC")
        logger.info("-" * 80)
        logger.info("Forward avg pnl when ACTIVE:  %+.3f%%", active_avg)
        logger.info("Forward avg pnl when DORMANT: %+.3f%%", dormant_avg)
        logger.info("Spread (ACTIVE - DORMANT):    %+.3f%%", spread)

        if spread > 0.5:
            logger.info("→ Q SCORE IS RELIABLE: ACTIVE forward >> DORMANT forward")
        elif spread > 0.1:
            logger.info("→ Q SCORE IS WEAKLY USEFUL: small but positive spread")
        elif spread > -0.1:
            logger.info("→ Q SCORE IS NOT INFORMATIVE: states have similar forward returns")
        else:
            logger.info("→ Q SCORE IS INVERTED: DORMANT outperforms ACTIVE forward (suspicious)")
        logger.info("")

    # Confusion matrix
    tp, tn, fp, fn = confusion["TP"], confusion["TN"], confusion["FP"], confusion["FN"]
    n_classified = tp + tn + fp + fn
    if n_classified > 0:
        logger.info("CONFUSION MATRIX (excludes CALIBRATING)")
        logger.info("-" * 80)
        logger.info("                          Forward profitable    Forward unprofitable")
        logger.info("Q says ACTIVE  (go):              %5d (TP)              %5d (FP)",
                     tp, fp)
        logger.info("Q says DORMANT (sit out):         %5d (FN)              %5d (TN)",
                     fn, tn)
        logger.info("")

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        accuracy = (tp + tn) / n_classified
        # When Q says sit out, how often is it right?
        sit_out_precision = tn / (tn + fn) if (tn + fn) > 0 else 0

        logger.info("Accuracy (overall):           %.1f%%", accuracy * 100)
        logger.info("Precision when ACTIVE:        %.1f%%  (TP / (TP+FP))", precision * 100)
        logger.info("Recall (catch profitable):    %.1f%%  (TP / (TP+FN))", recall * 100)
        logger.info("Precision when DORMANT:       %.1f%%  (TN / (TN+FN))", sit_out_precision * 100)
        logger.info("")

        logger.info("Interpretation:")
        if sit_out_precision > 0.6:
            logger.info("  When Q says SIT OUT, it's right %.0f%% of the time — trust it.",
                         sit_out_precision * 100)
        elif sit_out_precision > 0.5:
            logger.info("  When Q says SIT OUT, it's slightly more often right than wrong (%.0f%%).",
                         sit_out_precision * 100)
            logger.info("  Useful but not decisive — combine with judgment.")
        else:
            logger.info("  When Q says SIT OUT, it's wrong more often than right (%.0f%%).",
                         sit_out_precision * 100)
            logger.info("  The DORMANT signal is unreliable for this strategy.")

    logger.info("")


def main():
    ap = argparse.ArgumentParser(description="Validate Q score reliability")
    ap.add_argument("trades_csv", type=str,
                    help="Path to trades CSV with entry_date, exit_date, pnl_pct columns")
    ap.add_argument("--window", type=int, default=90,
                    help="Rolling window in days (default 90, matches strategy_regime.py)")
    ap.add_argument("--forward", type=int, default=10,
                    help="Forward measurement window in trades (default 10)")
    ap.add_argument("--label", type=str, default=None,
                    help="Label for the report (defaults to filename)")
    args = ap.parse_args()

    if not os.path.exists(args.trades_csv):
        logger.error("File not found: %s", args.trades_csv)
        sys.exit(1)

    df = pd.read_csv(args.trades_csv)
    required = ["entry_date", "exit_date", "pnl_pct"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        logger.error("Missing required columns: %s", missing)
        logger.error("CSV columns: %s", list(df.columns))
        sys.exit(1)

    # Drop NaN pnls
    df = df.dropna(subset=["pnl_pct"])
    df["pnl_pct"] = df["pnl_pct"].astype(float)

    label = args.label or os.path.basename(args.trades_csv)

    logger.info("Constants from modules/strategy_regime.py:")
    logger.info("  RFR_ANNUAL          = %.1f%%", _RFR_ANNUAL * 100)
    logger.info("  AVG_HOLD_DAYS       = %d", _AVG_HOLD_DAYS)
    logger.info("  TRADE_RFR_PCT       = %.3f%%", _TRADE_RFR_PCT)
    logger.info("  ANNUALIZATION       = %.2f", _ANNUALIZATION_FACTOR)
    logger.info("  DORMANT_THRESHOLD   = %.1f", _DORMANT_THRESHOLD)
    logger.info("  MIN_TRADES_FOR_REGIME = %d", _MIN_TRADES_FOR_REGIME)
    logger.info("")

    result = validate(df, window_days=args.window, forward_n=args.forward)
    if result is None:
        return
    report(result, label)


if __name__ == "__main__":
    main()
