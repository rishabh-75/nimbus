"""
modules/regime.py
─────────────────
Regime orchestrator: VIX-based strategy allocation.

Determines which strategy is primary (mean reversion vs ETF momentum)
based on current VIX level. Tracks VIX transitions and flags positions
that are in the "wrong" regime.

This is a PURE LOGIC class — no UI, no data fetching, no side effects.
data_manager computes regime ONCE, emits the result to all UI consumers.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# RESULT DATACLASS
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class RegimeResult:
    """Immutable regime output — computed once, read everywhere."""

    # Current state
    vix_value: Optional[float] = None
    vix_regime: str = "UNKNOWN"          # LOW, NORMAL, ELEVATED, PANIC
    active_strategy: str = "MR"          # MR (mean reversion) or MOMENTUM
    strategy_label: str = "—"            # human-readable

    # Allocation guidance (not a hard rule — trader decides)
    mr_allocation: str = "FULL"          # FULL, REDUCED, DORMANT
    etf_allocation: str = "DORMANT"      # FULL, REDUCED, DORMANT

    # Transition alerts (empty if no transition)
    transition: Optional[str] = None     # e.g. "NORMAL → ELEVATED"
    transition_alert: str = ""           # human-readable alert text
    etf_risk_flag: bool = False          # True when ETF positions should be reviewed
    mr_wind_down: bool = False           # True when MR positions should tighten

    # Position flags for watchlist
    position_warnings: list = field(default_factory=list)


# ══════════════════════════════════════════════════════════════════════════════
# ORCHESTRATOR
# ══════════════════════════════════════════════════════════════════════════════

class RegimeOrchestrator:
    """
    Stateful regime tracker. Holds previous VIX regime to detect transitions.

    Usage:
        orchestrator = RegimeOrchestrator()
        result = orchestrator.update(vix=26.8)
        # result.active_strategy == "MR"
        # result.etf_risk_flag == True (if VIX just crossed above 20)

    Lifecycle: one instance per DataManager, persists across symbol changes.
    VIX is market-wide — regime doesn't change per symbol.
    """

    # VIX thresholds (same as ConvictionEngine for consistency)
    VIX_LOW = 13.0
    VIX_NORMAL = 18.0       # below this → ETF momentum preferred
    VIX_ELEVATED = 20.0     # above this → mean reversion preferred
    VIX_PANIC = 25.0

    # Strategy allocation by regime
    _REGIME_CONFIG = {
        "PANIC": {
            "active": "MR",
            "label": "Mean reversion — panic VIX, high-prob setups",
            "mr": "FULL",
            "etf": "DORMANT",
        },
        "ELEVATED": {
            "active": "MR",
            "label": "Mean reversion — elevated VIX, pullback buying",
            "mr": "FULL",
            "etf": "REDUCED",
        },
        "NORMAL": {
            "active": "MOMENTUM",
            "label": "ETF momentum — normal VIX, trend following",
            "mr": "DORMANT",
            "etf": "FULL",
        },
        "LOW": {
            "active": "MOMENTUM",
            "label": "ETF momentum — low VIX, clean trends",
            "mr": "DORMANT",
            "etf": "FULL",
        },
    }

    def __init__(self):
        self._prev_regime: Optional[str] = None
        self._prev_vix: Optional[float] = None

    def update(self, vix: Optional[float]) -> RegimeResult:
        """
        Compute regime from current VIX. Detects transitions.

        Called ONCE per data refresh in data_manager.
        All UI components read the result — never call this independently.
        """
        r = RegimeResult()
        r.vix_value = vix

        if vix is None:
            r.vix_regime = "UNKNOWN"
            r.active_strategy = "MR"
            r.strategy_label = "Unknown VIX — defaulting to mean reversion"
            r.mr_allocation = "FULL"
            r.etf_allocation = "REDUCED"
            return r

        # ── Classify regime ───────────────────────────────────────────
        if vix > self.VIX_PANIC:
            r.vix_regime = "PANIC"
        elif vix >= self.VIX_ELEVATED:
            r.vix_regime = "ELEVATED"
        elif vix >= self.VIX_LOW:
            r.vix_regime = "NORMAL"
        else:
            r.vix_regime = "LOW"

        cfg = self._REGIME_CONFIG[r.vix_regime]
        r.active_strategy = cfg["active"]
        r.strategy_label = cfg["label"]
        r.mr_allocation = cfg["mr"]
        r.etf_allocation = cfg["etf"]

        # ── Detect transitions ────────────────────────────────────────
        if self._prev_regime is not None and self._prev_regime != r.vix_regime:
            r.transition = f"{self._prev_regime} → {r.vix_regime}"
            r = self._handle_transition(r, self._prev_regime, r.vix_regime)
            logger.info("Regime transition: %s (VIX %.1f → %.1f)",
                        r.transition, self._prev_vix or 0, vix)

        # ── Update state ──────────────────────────────────────────────
        self._prev_regime = r.vix_regime
        self._prev_vix = vix

        return r

    def flag_positions(self, positions: list[dict], regime: RegimeResult) -> list[dict]:
        """
        Flag watchlist positions that are in the wrong regime.

        Each position dict must have 'strategy' key: 'MR' or 'MOMENTUM'.
        Returns the same list with 'regime_warning' added to flagged entries.

        Called by watchlist refresh — not per-symbol, once per batch.
        """
        for pos in positions:
            strat = pos.get("strategy", "MR")
            warning = None

            if strat == "MOMENTUM" and regime.etf_risk_flag:
                warning = f"Regime risk — VIX {regime.vix_value:.0f} ({regime.vix_regime}), review stop"
            elif strat == "MOMENTUM" and regime.vix_regime in ("ELEVATED", "PANIC"):
                warning = f"Wrong regime — VIX {regime.vix_value:.0f}, momentum headwind"
            elif strat == "MR" and regime.mr_wind_down:
                warning = f"VIX falling — tighten stops, MR setups losing tailwind"

            pos["regime_warning"] = warning

        return positions

    # ── Private ───────────────────────────────────────────────────────

    def _handle_transition(self, r: RegimeResult, from_regime: str, to_regime: str) -> RegimeResult:
        """Generate alerts for regime transitions."""

        # VIX rising: ETF momentum → mean reversion
        if self._is_vix_rising(from_regime, to_regime):
            r.etf_risk_flag = True
            if to_regime == "PANIC":
                r.transition_alert = (
                    f"VIX spike to {r.vix_value:.1f} — PANIC regime. "
                    f"Review all ETF momentum positions. MR scanner: high-prob setups expected."
                )
            elif to_regime == "ELEVATED":
                r.transition_alert = (
                    f"VIX rising to {r.vix_value:.1f} — ELEVATED. "
                    f"Tighten ETF stops. MR scanner now primary."
                )
            else:
                r.transition_alert = (
                    f"VIX rising to {r.vix_value:.1f}. "
                    f"Monitor ETF positions for stop triggers."
                )

        # VIX falling: mean reversion → ETF momentum
        elif self._is_vix_falling(from_regime, to_regime):
            r.mr_wind_down = True
            if to_regime in ("LOW", "NORMAL"):
                r.transition_alert = (
                    f"VIX normalizing to {r.vix_value:.1f} — switching to ETF momentum. "
                    f"Let existing MR positions exit via BBW/SMA. ETF scanner now primary."
                )
            else:
                r.transition_alert = (
                    f"VIX easing to {r.vix_value:.1f}. "
                    f"MR setups becoming fewer. Watch for ETF opportunities."
                )

        return r

    @staticmethod
    def _is_vix_rising(from_r: str, to_r: str) -> bool:
        order = ["LOW", "NORMAL", "ELEVATED", "PANIC"]
        return order.index(to_r) > order.index(from_r)

    @staticmethod
    def _is_vix_falling(from_r: str, to_r: str) -> bool:
        order = ["LOW", "NORMAL", "ELEVATED", "PANIC"]
        return order.index(to_r) < order.index(from_r)


# ══════════════════════════════════════════════════════════════════════════════
# MODULE-LEVEL CONVENIENCE
# ══════════════════════════════════════════════════════════════════════════════

def compute_regime(vix: Optional[float], orchestrator: RegimeOrchestrator) -> RegimeResult:
    """Convenience wrapper — same pattern as compute_conviction."""
    return orchestrator.update(vix)
