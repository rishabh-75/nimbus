#!/usr/bin/env python3
"""
scripts/train_conviction.py — Train ML conviction model from walk-forward OOS trades.

Pipeline:
  1. Load OOS trades (symbol, entry_date, pnl_pct, tier, ...)
  2. Reconstruct entry-time features (WR, MFI, DD, etc.) from price data
  3. Fetch India VIX history and match to entry dates
  4. Train XGBoost classifier with time-series-aware cross-validation
  5. Evaluate: ROC-AUC, calibration, comparison with rules-based grade
  6. Save model to data/models/conviction_model.pkl

Usage:
    python3 scripts/train_conviction.py
    python3 scripts/train_conviction.py --trades data/backtest_results/wf_oos_trades.csv
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("train_conv")

MODEL_DIR = "data/models"
MODEL_PATH = os.path.join(MODEL_DIR, "conviction_model.pkl")


# ── Feature engineering ──────────────────────────────────────────────────────

def compute_features_for_trades(trades_df, cache_dir="data/backtest_cache"):
    """
    Reconstruct dual-mode features at each trade's entry date.
    Uses the same indicator computation as dual_mode.py.
    """
    from modules.dual_mode import compute_dual_mode

    # Load price data per symbol
    price_data = {}
    for sym in trades_df["symbol"].unique():
        cache_file = os.path.join(cache_dir, f"{sym}_1d.parquet")
        if os.path.exists(cache_file):
            try:
                df = pd.read_parquet(cache_file)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_data[sym] = df
            except Exception:
                pass

    missing = [s for s in trades_df["symbol"].unique() if s not in price_data]
    if missing:
        logger.info("Fetching %d symbols not in cache...", len(missing))
        try:
            import yfinance as yf
            for sym in missing:
                try:
                    df = yf.download(f"{sym}.NS", period="5y", progress=False, timeout=10)
                    if df is not None and not df.empty:
                        if isinstance(df.columns, pd.MultiIndex):
                            df.columns = df.columns.get_level_values(0)
                        df.index = pd.to_datetime(df.index)
                        if hasattr(df.index, "tz") and df.index.tz is not None:
                            df.index = df.index.tz_localize(None)
                        price_data[sym] = df
                except Exception:
                    pass
        except ImportError:
            pass

    logger.info("Price data: %d/%d symbols", len(price_data), trades_df["symbol"].nunique())

    # Extract features for each trade
    feature_rows = []
    skipped = 0

    for idx, trade in trades_df.iterrows():
        sym = trade["symbol"]
        entry_date = trade["entry_date"]

        if sym not in price_data:
            skipped += 1
            continue

        df = price_data[sym]
        # Get price data up to and including entry date
        mask = df.index <= entry_date
        if mask.sum() < 40:
            skipped += 1
            continue

        window = df.loc[mask]

        try:
            sig = compute_dual_mode(window, symbol=sym)
            if not sig.data_sufficient:
                skipped += 1
                continue

            feature_rows.append({
                "trade_idx": idx,
                "symbol": sym,
                "entry_date": entry_date,
                "pnl_pct": trade["pnl_pct"],
                "win": 1 if trade["pnl_pct"] > 0 else 0,
                "tier": trade["tier"],
                "exit_reason": trade.get("exit_reason", ""),
                "bars_held": trade.get("bars_held", 0),
                # Features
                "wr_30": sig.wr_30,
                "mfi": sig.mfi,
                "mfi_slope": sig.mfi_slope,
                "dd_from_high": sig.dd_from_high,
                "red_streak": sig.red_streak,
                "vol_ratio": sig.vol_ratio,
                "bbw_pctl": sig.bbw_pctl,
                "pct_from_sma": sig.pct_from_sma,
                "base_score": sig.base_score,
                "options_overlay": sig.options_overlay,
                "filing_overlay": sig.filing_overlay,
                "adx": sig.adx_14,
                "rsi": sig.rsi,
                "bbw_slope": sig.bbw_slope,
                "is_friday": 1 if entry_date.weekday() == 4 else 0,
            })
        except Exception:
            skipped += 1

        if (len(feature_rows) + skipped) % 200 == 0:
            logger.info("  %d/%d processed (%d skipped)",
                       len(feature_rows), len(trades_df), skipped)

    logger.info("Features: %d trades (%d skipped)", len(feature_rows), skipped)
    return pd.DataFrame(feature_rows)


def add_vix(features_df):
    """Match India VIX to trade entry dates."""
    try:
        import yfinance as yf
        start = features_df["entry_date"].min() - pd.Timedelta(days=30)
        end = features_df["entry_date"].max() + pd.Timedelta(days=5)
        vix = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                          end=end.strftime("%Y-%m-%d"), progress=False)
        if isinstance(vix.columns, pd.MultiIndex):
            vix.columns = vix.columns.get_level_values(0)
        vix.index = pd.to_datetime(vix.index)
        if hasattr(vix.index, "tz") and vix.index.tz is not None:
            vix.index = vix.index.tz_localize(None)
        vix_series = vix["Close"]

        vix_vals = []
        for _, row in features_df.iterrows():
            dt = row["entry_date"]
            mask = vix_series.index <= dt
            vix_vals.append(float(vix_series[mask].iloc[-1]) if mask.any() else 15.0)
        features_df["vix"] = vix_vals
        logger.info("VIX matched: %d trades", len(vix_vals))
    except Exception as e:
        logger.warning("VIX fetch failed: %s — using default 15.0", e)
        features_df["vix"] = 15.0

    return features_df


# ── Training ─────────────────────────────────────────────────────────────────

FEATURE_COLS = [
    "wr_30", "mfi", "mfi_slope", "dd_from_high", "red_streak",
    "vol_ratio", "bbw_pctl", "pct_from_sma", "base_score",
    "options_overlay", "filing_overlay",
    "vix", "adx", "rsi", "bbw_slope", "is_friday",
]


def train_model(features_df):
    """Train XGBoost classifier with time-aware cross-validation."""
    try:
        from xgboost import XGBClassifier
    except ImportError:
        logger.error("xgboost not installed. Run: pip install xgboost")
        logger.error("Also needed: pip install scikit-learn joblib")
        return None, {}

    from sklearn.model_selection import TimeSeriesSplit
    from sklearn.metrics import roc_auc_score, brier_score_loss, accuracy_score
    from sklearn.calibration import CalibratedClassifierCV

    # Sort by date for time-series split
    features_df = features_df.sort_values("entry_date").reset_index(drop=True)

    X = features_df[FEATURE_COLS].fillna(0).values
    y = features_df["win"].values

    logger.info("Training data: %d trades, %.1f%% wins", len(y), y.mean() * 100)
    logger.info("Features: %d", X.shape[1])

    # Time-series cross-validation (respects temporal ordering)
    tscv = TimeSeriesSplit(n_splits=5)
    aucs = []; briers = []; accs = []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X)):
        X_tr, X_te = X[train_idx], X[test_idx]
        y_tr, y_te = y[train_idx], y[test_idx]

        model = XGBClassifier(
            n_estimators=200,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            min_child_weight=5,
            reg_alpha=0.1,
            reg_lambda=1.0,
            use_label_encoder=False,
            eval_metric="logloss",
            random_state=42,
            verbosity=0,
        )
        model.fit(X_tr, y_tr, eval_set=[(X_te, y_te)], verbose=False)

        probs = model.predict_proba(X_te)[:, 1]
        auc = roc_auc_score(y_te, probs)
        brier = brier_score_loss(y_te, probs)
        acc = accuracy_score(y_te, (probs >= 0.5).astype(int))

        aucs.append(auc)
        briers.append(brier)
        accs.append(acc)
        logger.info("  Fold %d: AUC=%.3f  Brier=%.4f  Acc=%.1f%%  (N=%d, W=%.0f%%)",
                    fold + 1, auc, brier, acc * 100, len(y_te), y_te.mean() * 100)

    logger.info("\nCV Results:")
    logger.info("  AUC:   %.3f ± %.3f", np.mean(aucs), np.std(aucs))
    logger.info("  Brier: %.4f ± %.4f", np.mean(briers), np.std(briers))
    logger.info("  Acc:   %.1f%% ± %.1f%%", np.mean(accs) * 100, np.std(accs) * 100)

    # Train final model on all data with Platt calibration
    logger.info("\nTraining final calibrated model on all %d trades...", len(y))
    base_model = XGBClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, min_child_weight=5,
        reg_alpha=0.1, reg_lambda=1.0,
        use_label_encoder=False, eval_metric="logloss",
        random_state=42, verbosity=0,
    )
    # Calibrate probabilities (Platt scaling)
    cal_model = CalibratedClassifierCV(base_model, cv=5, method="sigmoid")
    cal_model.fit(X, y)

    # Feature importance
    base_model.fit(X, y)
    importances = dict(zip(FEATURE_COLS, base_model.feature_importances_))
    sorted_imp = sorted(importances.items(), key=lambda x: -x[1])

    logger.info("\nFeature importance:")
    for name, imp in sorted_imp:
        bar = "█" * int(imp * 100)
        logger.info("  %18s  %.3f  %s", name, imp, bar)

    metrics = {
        "auc_mean": round(np.mean(aucs), 4),
        "auc_std": round(np.std(aucs), 4),
        "brier_mean": round(np.mean(briers), 4),
        "accuracy_mean": round(np.mean(accs), 4),
        "n_trades": len(y),
        "win_rate": round(y.mean(), 4),
        "feature_importance": {k: round(v, 4) for k, v in sorted_imp},
        "train_date": datetime.datetime.now().isoformat(),
    }

    return cal_model, metrics


def compare_with_grade(features_df, model):
    """Compare ML predictions with the rules-based grade system."""
    from modules.scanner import _compute_grade

    X = features_df[FEATURE_COLS].fillna(0).values
    ml_probs = model.predict_proba(X)[:, 1]

    # Compute grades
    grade_ord = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6, "—": 7}

    grades = []
    for _, row in features_df.iterrows():
        vix = row.get("vix", 15)
        if vix > 22: vr = "PANIC"
        elif vix >= 18: vr = "ELEVATED"
        elif vix >= 13: vr = "NORMAL"
        else: vr = "LOW"

        g = _compute_grade(
            int(row["base_score"]), "SECONDARY",  # tier not used in grade
            True, row["wr_30"], row["mfi"], row["dd_from_high"],
            int(row["red_streak"]), row["bbw_slope"], vr,
            row["vol_ratio"], row["mfi_slope"], row["bbw_pctl"],
            rsi=row.get("rsi"),
        )
        grades.append(g)

    features_df["ml_prob"] = ml_probs
    features_df["grade"] = grades

    logger.info("\n" + "=" * 60)
    logger.info("COMPARISON: ML P(win) vs Rules-Based Grade")
    logger.info("=" * 60)

    # Win rate by grade
    logger.info("\nGrade system:")
    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        mask = features_df["grade"] == g
        if mask.sum() < 5:
            continue
        subset = features_df[mask]
        actual_wr = subset["win"].mean() * 100
        avg_prob = subset["ml_prob"].mean() * 100
        logger.info("  %3s: N=%4d  actual_win=%.1f%%  avg_P(win)=%.1f%%",
                    g, mask.sum(), actual_wr, avg_prob)

    # Win rate by ML probability bucket
    logger.info("\nML P(win) buckets:")
    for lo, hi in [(0, 0.5), (0.5, 0.6), (0.6, 0.7), (0.7, 0.8), (0.8, 0.9), (0.9, 1.01)]:
        mask = (ml_probs >= lo) & (ml_probs < hi)
        if mask.sum() < 5:
            continue
        actual = features_df.loc[mask, "win"].mean() * 100
        logger.info("  P(win) %.0f-%.0f%%: N=%4d  actual_win=%.1f%%  (calibration: %+.1fpp)",
                    lo * 100, hi * 100, mask.sum(), actual, actual - (lo + hi) / 2 * 100)

    # Agreement check
    ml_buy = ml_probs >= 0.65
    grade_buy = features_df["grade"].isin(["A+", "A", "B+"])
    agree = (ml_buy == grade_buy).mean() * 100
    logger.info("\nAgreement (ML ≥65%% vs Grade ≥B+): %.1f%%", agree)

    # Where they disagree — who's right?
    ml_yes_grade_no = ml_buy & ~grade_buy
    ml_no_grade_yes = ~ml_buy & grade_buy
    if ml_yes_grade_no.sum() > 5:
        wr = features_df.loc[ml_yes_grade_no, "win"].mean() * 100
        logger.info("  ML says buy, Grade says no: N=%d  actual_win=%.1f%%",
                    ml_yes_grade_no.sum(), wr)
    if ml_no_grade_yes.sum() > 5:
        wr = features_df.loc[ml_no_grade_yes, "win"].mean() * 100
        logger.info("  Grade says buy, ML says no: N=%d  actual_win=%.1f%%",
                    ml_no_grade_yes.sum(), wr)


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Train ML conviction model")
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    args = parser.parse_args()

    # Check for uploaded trades
    if not os.path.exists(args.trades):
        alt = "/mnt/user-data/uploads/wf_oos_trades.csv"
        if os.path.exists(alt):
            args.trades = alt
        else:
            logger.error("No OOS trades found at %s", args.trades)
            return

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    logger.info("Loaded %d OOS trades", len(trades_df))

    # Step 1: Reconstruct features
    logger.info("\n── STEP 1: Feature engineering ──")
    features_df = compute_features_for_trades(trades_df)
    if len(features_df) < 100:
        logger.error("Too few trades with features (%d) — need at least 100", len(features_df))
        return

    # Step 2: Add VIX
    logger.info("\n── STEP 2: Match VIX ──")
    features_df = add_vix(features_df)

    # Step 3: Train
    logger.info("\n── STEP 3: Train XGBoost ──")
    model, metrics = train_model(features_df)
    if model is None:
        return

    # Step 4: Compare with grade system
    logger.info("\n── STEP 4: Compare with rules-based grade ──")
    compare_with_grade(features_df, model)

    # Step 5: Save
    logger.info("\n── STEP 5: Save model ──")
    os.makedirs(MODEL_DIR, exist_ok=True)
    try:
        import joblib
        joblib.dump({
            "model": model,
            "feature_names": FEATURE_COLS,
            "metrics": metrics,
        }, MODEL_PATH)
        logger.info("Model saved: %s", MODEL_PATH)
    except ImportError:
        logger.error("joblib not installed — cannot save model")
        return

    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("TRAINING COMPLETE")
    logger.info("=" * 60)
    logger.info("  Model: %s", MODEL_PATH)
    logger.info("  AUC: %.3f ± %.3f", metrics["auc_mean"], metrics["auc_std"])
    logger.info("  Accuracy: %.1f%%", metrics["accuracy_mean"] * 100)
    logger.info("  Trades: %d (%.1f%% win rate)",
                metrics["n_trades"], metrics["win_rate"] * 100)
    logger.info("\nTo use: the scanner will auto-load this model on next scan.")
    logger.info("To retrain: run this script again after a new walk-forward.")


if __name__ == "__main__":
    main()
