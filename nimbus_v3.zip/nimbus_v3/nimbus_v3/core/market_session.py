"""NSE market-session helpers.

IST-based utilities for answering "is the market open right now" and
"what's the current IST wall-clock time" — questions that recur in
several places (status-bar labels, data-loader freshness decisions,
auto-refresh scheduling).

Kept deliberately tiny: only two functions. More session-semantics
like "last expected bar date" or "is a trading day" can be added here
later as callers appear.

NSE cash-market hours:
    Monday–Friday, 09:15–15:30 IST.

We do NOT check the NSE holiday calendar. The failure mode on a
holiday is cosmetic (the label might say "live" when the exchange
is actually closed); it doesn't corrupt any data. Adding holiday
awareness would require a maintained calendar file, which isn't
worth the complexity for the cost of the edge case.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Final

#: India Standard Time — UTC+05:30. Matches oracle's convention in
#: ``modules/data.py::is_market_open`` so behavior is identical.
_IST: Final[timezone] = timezone(timedelta(hours=5, minutes=30))


def now_ist() -> datetime:
    """Return the current wall-clock time in IST.

    Used anywhere session-aware logic needs a "now" reference.
    Always tz-aware so arithmetic with other tz-aware datetimes is
    well-defined.
    """
    return datetime.now(tz=_IST)


def is_market_open(now: datetime | None = None) -> bool:
    """Return ``True`` iff NSE's cash market is currently open.

    Window: Monday–Friday, 09:15–15:30 IST. Weekends return ``False``.
    Holidays are NOT checked — see module docstring.

    Args:
        now: Optional override for testing. When ``None`` (the
            production path), reads :func:`now_ist`.
    """
    if now is None:
        now = now_ist()
    # Weekday is 0-6 with Monday=0, Sunday=6; weekends are >=5.
    if now.weekday() >= 5:
        return False
    open_ = now.replace(hour=9, minute=15, second=0, microsecond=0)
    close_ = now.replace(hour=15, minute=30, second=0, microsecond=0)
    return open_ <= now <= close_


def is_todays_bar_incomplete(now: datetime | None = None) -> bool:
    """Return ``True`` iff a bar dated today (IST) would still be forming.

    This is the question the data layer must ask before persisting a
    vendor frame. It is NOT the same as :func:`is_market_open`:

        08:00 IST  market closed, but today's bar does not exist yet and
                   anything dated today is a pre-open stub  → incomplete
        11:00 IST  market open, bar is half-formed             → incomplete
        16:00 IST  market closed, session done, bar is final   → COMPLETE
        Saturday   no session today; nothing dated today is a
                   partial NSE bar                             → complete

    The distinction matters because a bar fetched at 11:00 has a real
    Open but an as-of-now High/Low/Close and roughly a third of the day's
    volume. Cached and enriched, it silently contaminates every trailing
    indicator and — worse for a cross-sectional tool — puts some symbols
    on today's half-bar while the rest sit on yesterday's close.

    Holidays are not checked (see module docstring). On a holiday this
    returns ``True`` before 15:30, but the vendor has no bar dated that
    day to drop, so the failure mode is inert.

    Args:
        now: Optional override for testing.
    """
    if now is None:
        now = now_ist()
    if now.weekday() >= 5:
        return False        # no NSE session today
    close_ = now.replace(hour=15, minute=30, second=0, microsecond=0)
    return now < close_


def last_completed_session_date(now: datetime | None = None) -> date:
    """Date of the most recent COMPLETED NSE session as of ``now`` (IST).

    A session counts as completed once its 15:30 close has passed. Used by
    the loaders to decide whether a cache is CONTENT-fresh — i.e. actually
    contains the latest finished session — independent of how long ago the
    cache file was written. Age-based freshness alone misses the case where
    a cache written intraday (with today's forming bar dropped) is left one
    session behind and never refilled once that session closes.

    Rules (weekends handled; holidays intentionally NOT — see module
    docstring; a holiday makes this over-estimate by one day, causing at
    most one harmless extra refetch):

        weekday, ≥15:30   → today
        weekday, <15:30   → previous weekday (today's session unfinished)
        Saturday          → Friday
        Sunday            → Friday
    """
    if now is None:
        now = now_ist()
    d = now.date()
    close_passed = now >= now.replace(hour=15, minute=30, second=0,
                                      microsecond=0)
    # Step back to the most recent weekday whose session has completed.
    if now.weekday() < 5 and close_passed:
        return d
    # Otherwise the last completed session is the previous weekday.
    step = timedelta(days=1)
    d = d - step
    while d.weekday() >= 5:
        d = d - step
    return d
