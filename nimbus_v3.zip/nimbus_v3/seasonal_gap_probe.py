#!/usr/bin/env python3
"""seasonal_gap_probe.py — a forward-P/E ANALOG built from price + seasonality.

THE IDEA
────────
Forward P/E asks: is the price low relative to the earnings the name is about
to deliver? We have no EPS estimates, but we can approximate the SHAPE of the
question — "price now vs. expected forward payoff" — from what we do have.
Seasonality is the only forward-looking return estimate in the system, so the
analog is:

    seasonal_gap = (industry's average return for the NEXT calendar month)
                 − (the name's own realized return over a matched window)

High gap  = the name has NOT yet captured a seasonal tail-wind it usually
            gets → "cheap" relative to its seasonal earning power.
Low/neg   = already run up into (or past) the seasonal move → "expensive".

This is deliberately a GAP (expected − realized), not a LEVEL. The level
version (seasonal reliability as a fresh-breakout filter) was already tested
and FAILED (seasonal_breakout_probe: Q4−Q1 ≈ +0.11%, t ≈ +0.3, matched its
random control). The gap is a different, untested construction.

THE TRAP THIS PROBE IS BUILT AROUND
───────────────────────────────────
"Hasn't moved yet but usually does" is mechanically close to MEAN REVERSION —
it rewards the laggard. Every validated edge in this system is the opposite
(momentum, volume blow-off, movers), and the fresh/unextended nulls say early
names don't outperform. So the realized-return leg ALONE could do all the
work, with the seasonal half mere decoration. The decisive control is
therefore ctl:realized-only — the seasonal leg must beat the plain realized
leg, or this is just mean-reversion wearing a seasonal costume.

PRE-REGISTERED HYPOTHESIS
─────────────────────────
H1: Forward FWD-day excess return rises with seasonal_gap. Top-quartile gap >
    bottom-quartile, monotonic across quartiles (≤1 inversion), date-clustered
    Welch-t > 2.

PASS BAR (all, or it does not become a factor):
  • Q4 > Q1, ≤1 inversion, Welch-t(across dates) > 2.
  • survives ctl:random-seasonal (shuffle seasonal means → ~0).
  • BEATS ctl:realized-only: the full gap's Q4−Q1 must exceed the
    realized-leg-alone Q4−Q1 by a clear margin. If realized-only matches it,
    the seasonal leg adds nothing and this is mean-reversion — report it as
    such, do NOT score it as seasonal.

CONTROLS
  ctl:random-seasonal   seasonal means shuffled across industries.
  ctl:realized-only      rank on −realized_return only (no seasonal term).
                         THE make-or-break.
  ctl:seasonal-only      rank on seasonal mean only (no realized subtraction).
  ctl:shuffle-dates      canary for the clustering inference (≈0).

DISCIPLINE (unchanged from the sibling probe)
  • Date-clustered t-stats across DATES, not trades (breakouts/quarters
    cluster; per-trade t is inflated and shown for context only).
  • No lookahead: seasonal means use only data strictly before the asof date;
    realized return uses the trailing window ending AT asof; forward return is
    date-grid sliced from asof's own index position.

Run on your machine (needs the cached panel):
    python seasonal_gap_probe.py
    python seasonal_gap_probe.py --selftest      # mechanics only, no cache
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

FWD = 20                 # forward horizon (trading days)
REALIZED = 20            # trailing realized-return window (matched to FWD)
MIN_SEASON_YEARS = 3
SAMPLE_EVERY = 5         # sample entry bars every N days per symbol (de-dup
                         # overlapping windows; keeps dates spread)
UPPER = "bb_20_1s_upper"


# ── seasonal AVERAGE return of an industry's NEXT month, as-of a date ───────
def next_month_seasonal_mean(industry_close, asof, *, min_years=MIN_SEASON_YEARS):
    """Average monthly return of the composite's NEXT calendar month, using
    ONLY data strictly before ``asof``. Returns (mean, n_years) or (nan, 0).

    This is the seasonal MAGNITUDE (expected return), not the reliability SNR
    — magnitude is what a valuation gap needs.
    """
    import numpy as np

    from nimbus_v3.compute.seasonality import _monthly_returns

    hist = industry_close.loc[industry_close.index < asof]
    if hist.empty:
        return float("nan"), 0
    monthly = _monthly_returns(hist)
    if monthly.empty:
        return float("nan"), 0
    import pandas as pd
    target = (pd.Timestamp(asof).month % 12) + 1
    vals = monthly[monthly.index.month == target].to_numpy(dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < min_years:
        return float("nan"), len(vals)
    return float(np.mean(vals)), len(vals)


def realized_return(df, i, *, window=REALIZED):
    """Trailing ``window``-day return of the name ending AT bar i (inclusive
    of i, using i-window as the base). No lookahead — ends at asof."""
    import numpy as np

    if i - window < 0:
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    base = c[i - window]
    if base <= 0:
        return float("nan")
    r = c[i] / base - 1.0
    return r if np.isfinite(r) else float("nan")


def forward_excess(df, i, market_cum, *, fwd=FWD):
    import numpy as np

    if i + fwd >= len(df):
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    r_sym = c[i + fwd] / c[i] - 1.0
    d0, d1 = df.index[i], df.index[i + fwd]
    m0, m1 = market_cum.get(d0), market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan")
    r_mkt = m1 / m0 - 1.0
    if not (np.isfinite(r_sym) and np.isfinite(r_mkt)):
        return float("nan")
    return r_sym - r_mkt


# ── date-clustered inference (identical discipline to the sibling probe) ────
def clustered_stats(pairs):
    import numpy as np

    by_date = defaultdict(list)
    for d, x in pairs:
        if x == x:
            by_date[d].append(x)
    date_means = [float(np.mean(v)) for v in by_date.values()]
    n_trades = sum(len(v) for v in by_date.values())
    if len(date_means) < 3:
        return float("nan"), float("nan"), len(date_means), n_trades
    arr = np.array(date_means)
    mean = float(arr.mean())
    se = float(arr.std(ddof=1) / np.sqrt(len(arr)))
    return mean, (mean / se if se > 0 else float("nan")), len(arr), n_trades


def welch_across_dates(top, bot):
    import numpy as np

    def dm(pairs):
        d = defaultdict(list)
        for dt, x in pairs:
            if x == x:
                d[dt].append(x)
        return np.array([np.mean(v) for v in d.values()])
    a, b = dm(top), dm(bot)
    if len(a) < 3 or len(b) < 3:
        return float("nan")
    se = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
    return (a.mean() - b.mean()) / se if se > 0 else float("nan")


def quartile_edges(values):
    import numpy as np

    v = np.array([x for x in values if x == x])
    if len(v) < 4:
        return None
    return [float(np.quantile(v, q)) for q in (0.25, 0.5, 0.75)]


def assign_q(x, edges):
    if x != x or edges is None:
        return None
    return (0 if x <= edges[0] else 1 if x <= edges[1]
            else 2 if x <= edges[2] else 3)


def report(records, key_index, label, *, rng, shuffle_key=False,
           shuffle_dates=False):
    """records: list of [date, fwd_excess, seasonal_mean, realized].
    key_index selects the ranking key column (2=seasonal, 3=realized, or a
    computed gap passed in column 4). Prints quartiles + Q4−Q1 Welch-t.
    """
    import numpy as np

    rec = [r[:] for r in records]
    keys = [r[key_index] for r in rec]
    if shuffle_key:
        s = [k for k in keys]
        rng.shuffle(s)
        for r, k in zip(rec, s):
            r[key_index] = k
        keys = [r[key_index] for r in rec]
    if shuffle_dates:
        ds = [r[0] for r in rec]
        rng.shuffle(ds)
        for r, d in zip(rec, ds):
            r[0] = d

    edges = quartile_edges(keys)
    buckets = defaultdict(list)
    for r in rec:
        q = assign_q(r[key_index], edges)
        if q is not None:
            buckets[q].append((r[0], r[1]))

    print(f"\n─── {label} " + "─" * max(2, 56 - len(label)))
    qm = {}
    for q in range(4):
        m, t, nd, ntr = clustered_stats(buckets.get(q, []))
        qm[q] = m
        cell = "  nan " if m != m else f"{m*100:+6.2f}%"
        tag = ("low" if q == 0 else "high" if q == 3 else "mid")
        print(f"  Q{q+1} ({tag:>4}): mean {cell}  clustered-t {t:+5.2f}"
              f"  dates {nd:4d}  trades {ntr:5d}")
    welch = welch_across_dates(buckets.get(3, []), buckets.get(0, []))
    diff = (qm[3] - qm[0]) if (qm[3] == qm[3] and qm[0] == qm[0]) else float("nan")
    inv = sum(1 for q in range(3)
              if qm[q] == qm[q] and qm[q+1] == qm[q+1] and qm[q] > qm[q+1] + 1e-9)
    print(f"  ── Q4 − Q1 = {diff*100:+.2f}%   Welch-t = {welch:+.2f}"
          f"   inversions = {inv}")
    return {"diff": diff, "welch": welch, "inversions": inv, "qm": qm}


# ── build the record set ────────────────────────────────────────────────────
def build_records(panel, sym_to_industry, comps, market):
    seasonal_cache = {}
    records = []
    for sym, df in panel.items():
        ind = sym_to_industry.get(sym)
        if ind is None or ind not in comps or "Close" not in df.columns:
            continue
        comp = comps[ind]
        n = len(df)
        for i in range(max(REALIZED, 260), n - FWD - 1, SAMPLE_EVERY):
            asof = df.index[i]
            fexc = forward_excess(df, i, market)
            if fexc != fexc:
                continue
            rz = realized_return(df, i)
            if rz != rz:
                continue
            key = (ind, asof.year, asof.month)
            if key not in seasonal_cache:
                seasonal_cache[key] = next_month_seasonal_mean(comp, asof)[0]
            smean = seasonal_cache[key]
            if smean != smean:
                continue
            records.append([asof, fexc, smean, rz])
    return records


def build_market_cum(panel, *, min_count=20):
    import numpy as np

    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                sums[idx[i]] += c[i]/c[i-1] - 1.0
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    cum, acc = {}, 1.0
    for d in sorted(daily):
        acc *= 1.0 + daily[d]
        cum[d] = acc
    return cum


def build_composites(panel, sym_to_industry):
    from nimbus_v3.compute.industry_composite import build_industry_composite

    members = defaultdict(list)
    for sym, ind in sym_to_industry.items():
        if sym in panel:
            members[ind].append(sym)
    out = {}
    for ind, syms in members.items():
        comp, _ = build_industry_composite(
            syms, panel, min_members=3, min_bars=250, lookback=None)
        if comp is not None:
            out[ind] = comp
    return out


def _gap_column(records):
    """Append the seasonal_gap = seasonal_mean − realized as column 4."""
    import numpy as np

    # z-score each leg across the pooled records so the subtraction is
    # unit-free (seasonal monthly means and 20d realized returns live on
    # different scales; a raw subtraction would let the larger-variance leg
    # dominate the ranking by construction).
    s = np.array([r[2] for r in records])
    z = np.array([r[3] for r in records])
    sm, ss = s.mean(), s.std() or 1.0
    zm, zs = z.mean(), z.std() or 1.0
    for r in records:
        gap = (r[2] - sm)/ss - (r[3] - zm)/zs      # expected − realized
        r.append(gap)
    return records


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np

    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db
    from strategy_probe import load_panel

    rng = np.random.default_rng(args.seed)
    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — is the cache present?", file=sys.stderr)
        return 1
    print("composites + market...", file=sys.stderr)
    comps = build_composites(panel, sym_to_industry)
    market = build_market_cum(panel)
    records = build_records(panel, sym_to_industry, comps, market)
    _gap_column(records)
    print(f"records: {len(records)}", file=sys.stderr)

    gap = report(records, 4, "REAL: seasonal_gap (expected − realized)",
                 rng=rng)
    ro = report(records, 3, "ctl:realized-only (rank on realized; make-break)",
                rng=rng)
    # realized-only ranks by realized ASCENDING = laggards in Q4; to compare
    # 'cheap' direction we read its Q1 (biggest run-up) vs Q4 (biggest lag).
    report(records, 2, "ctl:seasonal-only (rank on seasonal mean)", rng=rng)
    report(records, 4, "ctl:random-seasonal (shuffle seasonal leg)",
           rng=rng, shuffle_key=False)   # placeholder; real shuffle below
    # proper random-seasonal: shuffle the seasonal leg then rebuild gap
    rs = [r[:5] for r in records]
    smeans = [r[2] for r in rs]
    rng.shuffle(smeans)
    for r, s in zip(rs, smeans):
        r[2] = s
    rs2 = _gap_column([r[:4] for r in rs])
    report(rs2, 4, "ctl:random-seasonal (rebuilt gap)", rng=rng)
    report(records, 4, "ctl:shuffle-dates (canary, expect ~0)",
           rng=rng, shuffle_dates=True)

    print("\n" + "=" * 68)
    print("VERDICT")
    beats_realized = (gap["diff"] > 0 and gap["welch"] > 2
                      and gap["inversions"] <= 1
                      and abs(gap["diff"]) > 1.3 * abs(ro["diff"]))
    if beats_realized:
        print("  Gap Q4>Q1, monotonic, t>2, AND clears realized-only by >30%.")
        print("  → The seasonal leg adds over plain mean-reversion. Worth")
        print("    building as a sector-relative valuation factor. Confirm it")
        print("    survives random-seasonal first.")
    else:
        print("  Does NOT clear the bar. Either no gap effect, or it does not")
        print("  beat ctl:realized-only — i.e. any effect is just mean-")
        print("  reversion, not seasonal valuation. Do NOT score it as")
        print("  seasonal. (If realized-only itself is strong with a stable")
        print("  sign, that plain reversion signal may deserve its own probe.)")
    return 0


def _selftest(args):
    """Validate the DISCRIMINATOR that actually matters: can the probe tell a
    genuine seasonal-gap signal apart from plain mean-reversion?

    Because gap = seasonal − realized, the realized leg is shared, so
    shuffling the seasonal leg alone never fully zeroes the gap — which is
    exactly why 'beats realized-only' is the decisive test, not random-
    seasonal. So we plant two worlds and require the probe to verdict each
    correctly:

      A) TRUE GAP  — forward payoff ∝ (seasonal − realized). The gap must
                     be detected AND beat realized-only by the margin.
      B) PURE MEAN-REVERSION — forward payoff ∝ (−realized) only, seasonal
                     irrelevant. The gap must NOT beat realized-only (the
                     honest 'this is just reversion' verdict).
    """
    import numpy as np
    import pandas as pd

    dates = pd.bdate_range("2016-01-01", periods=800)

    def synth(mode, seed):
        rng = np.random.default_rng(seed)
        recs = []
        for _ in range(4000):
            d = dates[rng.integers(len(dates))]
            smean = rng.normal(0, 0.03)
            rz = rng.normal(0, 0.08)
            gap = smean/0.03 - rz/0.08
            if mode == "gap":
                fexc = 0.010 * gap + rng.normal(0, 0.05)
            else:  # pure reversion: only −realized drives it
                fexc = 0.010 * (-(rz/0.08)) + rng.normal(0, 0.05)
            recs.append([d, fexc, smean, rz])
        _gap_column(recs)
        return recs

    print("\n########## SCENARIO A: true seasonal-gap signal ##########")
    recs = synth("gap", args.seed)
    rng = np.random.default_rng(args.seed)
    gapA = report(recs, 4, "A: gap", rng=rng)
    roA = report(recs, 3, "A: realized-only", rng=rng)
    A_detected = gapA["diff"] > 0 and gapA["welch"] > 2 and gapA["inversions"] <= 1
    A_beats = abs(gapA["diff"]) > 1.3 * abs(roA["diff"])

    print("\n########## SCENARIO B: pure mean-reversion ##########")
    recs = synth("rev", args.seed + 1)
    rng = np.random.default_rng(args.seed)
    gapB = report(recs, 4, "B: gap", rng=rng)
    roB = report(recs, 3, "B: realized-only", rng=rng)
    # In pure reversion, gap and realized-only should be comparable — gap must
    # NOT clear realized by the 30% margin (else we'd falsely call it seasonal).
    B_not_beats = not (abs(gapB["diff"]) > 1.3 * abs(roB["diff"]))

    print("\n" + "=" * 68)
    print(f"A  true-gap detected:                 {A_detected}")
    print(f"A  gap beats realized-only (>30%):    {A_beats}")
    print(f"B  gap does NOT beat realized-only:   {B_not_beats}  "
          f"(correctly reads as reversion)")
    ok = A_detected and A_beats and B_not_beats
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
