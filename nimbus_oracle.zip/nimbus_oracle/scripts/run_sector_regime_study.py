#!/usr/bin/env python3
"""
scripts/run_sector_regime_study.py — Two hypotheses in one script.

HYPOTHESIS 1: SECTOR REGIME + ROTATION
  Does a stock's sector context predict MR trade outcomes?
  - Map each stock → sector index (NIFTY BANK, NIFTY IT, etc.)
  - Compute sector regime at entry: TRENDING / PULLBACK / CRASH (absolute)
  - Compute relative strength vs NIFTY: LEADING / INLINE / LAGGING
  - Classify sector type: DEFENSIVE (Pharma/FMCG/IT) vs CYCLICAL (Banks/Metals/Auto)
  - Cross all dimensions with VIX regime
  - Key question: Does MR in cyclical+lagging sectors during panic outperform?
    (Metals crash 2025 → mean reversion goldmine?)
  - Does defensive+leading during panic mean "don't bother with MR"?

HYPOTHESIS 2: MOMENTUM IN EQUITIES BY VIX REGIME
  Was momentum discarded prematurely (before VIX was factored)?
  - For each NIFTY 100 stock, detect momentum entries:
    above SMA, WR not oversold, strong MFI
  - Measure forward 5d/10d/21d returns
  - Slice by VIX regime at entry (LOW / NORMAL / ELEVATED / PANIC)
  - Compare momentum vs MR win rates per VIX bucket

Data: 4,512 walk-forward OOS trades + India VIX daily + sector index prices

Usage:
    python3 scripts/run_sector_regime_study.py
    python3 scripts/run_sector_regime_study.py --hypothesis 1   # sector only
    python3 scripts/run_sector_regime_study.py --hypothesis 2   # momentum only
    python3 scripts/run_sector_regime_study.py --years 5        # history depth
"""
import argparse, datetime, logging, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("sector_regime_study")

# ══════════════════════════════════════════════════════════════════════════════
# SECTOR INDEX MAPPING
# ══════════════════════════════════════════════════════════════════════════════

# NSE sector index → yfinance ticker
SECTOR_INDEX_TICKERS = {
    "Banks":     "^NSEBANK",
    "IT":        "^CNXIT",
    "Pharma":    "^CNXPHARMA",
    "Auto":      "^CNXAUTO",
    "Metals":    "^CNXMETAL",
    "Energy":    "^CNXENERGY",
    "FMCG":      "^CNXFMCG",
    "Infra":     "^CNXINFRA",
    "Finance":   "^NSEBANK",     # overlap, NIFTY Financial uses bank as proxy
    "Realty":    "^CNXREALTY",
    "Media":     "^CNXMEDIA",
    "Consumer":  "^CNXFMCG",     # proxy
}

# Fallback: stock → sector (hardcoded for NIFTY 100 coverage)
_STOCK_SECTOR = {
    # Banks
    "HDFCBANK": "Banks", "ICICIBANK": "Banks", "SBIN": "Banks",
    "AXISBANK": "Banks", "KOTAKBANK": "Banks", "INDUSINDBK": "Banks",
    "BANKBARODA": "Banks", "PNB": "Banks", "FEDERALBNK": "Banks",
    "IDFCFIRSTB": "Banks", "CANBK": "Banks", "AUBANK": "Banks",
    # Finance
    "BAJFINANCE": "Finance", "BAJAJFINSV": "Finance", "HDFCLIFE": "Finance",
    "SBILIFE": "Finance", "ICICIPRULI": "Finance", "CHOLAFIN": "Finance",
    "MUTHOOTFIN": "Finance", "SHRIRAMFIN": "Finance", "PFC": "Finance",
    "RECLTD": "Finance",
    # IT
    "TCS": "IT", "INFY": "IT", "WIPRO": "IT", "HCLTECH": "IT",
    "TECHM": "IT", "LTIM": "IT", "PERSISTENT": "IT", "COFORGE": "IT",
    "MPHASIS": "IT",
    # Pharma
    "SUNPHARMA": "Pharma", "CIPLA": "Pharma", "DRREDDY": "Pharma",
    "DIVISLAB": "Pharma", "APOLLOHOSP": "Pharma", "BIOCON": "Pharma",
    "TORNTPHARM": "Pharma", "AUROPHARMA": "Pharma",
    # Auto
    "MARUTI": "Auto", "TATAMOTORS": "Auto", "BAJAJ-AUTO": "Auto",
    "HEROMOTOCO": "Auto", "EICHERMOT": "Auto", "M&M": "Auto",
    "ASHOKLEY": "Auto", "TVSMOTOR": "Auto", "BOSCHLTD": "Auto",
    # Metals
    "TATASTEEL": "Metals", "JSWSTEEL": "Metals", "HINDALCO": "Metals",
    "VEDL": "Metals", "COALINDIA": "Metals", "NMDC": "Metals",
    # Energy
    "RELIANCE": "Energy", "NTPC": "Energy", "POWERGRID": "Energy",
    "ONGC": "Energy", "BPCL": "Energy", "IOC": "Energy",
    "ADANIENT": "Energy", "ADANIPORTS": "Energy", "ADANIGREEN": "Energy",
    "GAIL": "Energy", "TATAPOWER": "Energy",
    # FMCG / Consumer
    "ITC": "FMCG", "HINDUNILVR": "FMCG", "NESTLEIND": "FMCG",
    "BRITANNIA": "FMCG", "TATACONSUM": "FMCG", "DABUR": "FMCG",
    "GODREJCP": "FMCG", "MARICO": "FMCG", "COLPAL": "FMCG",
    "TITAN": "Consumer", "ASIANPAINT": "Consumer", "PIDILITIND": "Consumer",
    # Infra / Cement
    "LT": "Infra", "ULTRACEMCO": "Infra", "GRASIM": "Infra",
    "AMBUJACEM": "Infra", "SHREECEM": "Infra", "ACC": "Infra",
    "DLF": "Realty", "GODREJPROP": "Realty",
    # Telecom
    "BHARTIARTL": "IT",   # maps to IT as proxy (telecom index sparse)
    # Other mega-caps
    "HDFCAMC": "Finance", "NAUKRI": "IT",
}


def get_stock_sector(symbol: str) -> str:
    """Map stock to its sector index. Falls back to index_constituents."""
    sym = symbol.strip().upper().replace(".NS", "")
    if sym in _STOCK_SECTOR:
        return _STOCK_SECTOR[sym]
    try:
        from modules.index_constituents import get_sector
        s = get_sector(sym)
        if s != "Other":
            return s
    except Exception:
        pass
    return "Other"


# ══════════════════════════════════════════════════════════════════════════════
# DATA FETCH
# ══════════════════════════════════════════════════════════════════════════════

def fetch_daily(ticker: str, years: int = 7) -> pd.DataFrame:
    """Fetch daily OHLCV. Multi-ticker fallback."""
    import yfinance as yf
    start = (datetime.date.today() - datetime.timedelta(days=years * 365)).strftime("%Y-%m-%d")
    for t in [ticker, ticker.replace("^", "") + ".NS"]:
        try:
            df = yf.download(t, start=start, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if not df.empty and len(df) > 100:
                return df
        except Exception:
            continue
    return pd.DataFrame()


def fetch_vix_daily(years: int = 7) -> pd.Series:
    """Fetch India VIX daily close."""
    import yfinance as yf
    start = (datetime.date.today() - datetime.timedelta(days=years * 365)).strftime("%Y-%m-%d")
    for t in ["^INDIAVIX", "INDIAVIX.NS"]:
        try:
            df = yf.download(t, start=start, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if not df.empty and len(df) > 100:
                s = df["Close"].dropna()
                if isinstance(s, pd.DataFrame):
                    s = s.iloc[:, 0]
                return s
        except Exception:
            continue
    return pd.Series(dtype=float)


# ══════════════════════════════════════════════════════════════════════════════
# SECTOR TYPE CLASSIFICATION
# ══════════════════════════════════════════════════════════════════════════════

# Defensive: outperform in panics (flight to safety, stable earnings)
# Cyclical: outperform in hype cycles (leverage to growth, commodities)
SECTOR_TYPE = {
    "Banks":    "CYCLICAL",    # rate-sensitive, leverage
    "Finance":  "CYCLICAL",    # credit cycle
    "IT":       "DEFENSIVE",   # USD hedge, stable demand
    "Pharma":   "DEFENSIVE",   # non-discretionary
    "FMCG":     "DEFENSIVE",   # staples, inelastic demand
    "Consumer": "CYCLICAL",    # discretionary
    "Auto":     "CYCLICAL",    # big-ticket discretionary
    "Metals":   "CYCLICAL",    # commodity supercycle, China demand
    "Energy":   "CYCLICAL",    # oil/gas cycle
    "Infra":    "CYCLICAL",    # capex cycle, govt spend
    "Realty":   "CYCLICAL",    # rate + liquidity sensitive
    "Media":    "CYCLICAL",    # ad spend, discretionary
    "Other":    "CYCLICAL",    # default assumption
}


# ══════════════════════════════════════════════════════════════════════════════
# SECTOR REGIME CLASSIFICATION (absolute + relative)
# ══════════════════════════════════════════════════════════════════════════════

def compute_sector_regime(sector_prices: pd.Series, nifty_prices: pd.Series,
                          date: pd.Timestamp) -> dict:
    """
    Classify sector regime at a given date — absolute, relative, and volatility.

    Returns dict with:
      - regime: TRENDING / PULLBACK / CRASH (absolute)
      - rs_regime: LEADING / INLINE / LAGGING (relative to NIFTY)
      - rs_20d: 20-day relative strength (sector return − NIFTY return)
      - rs_50d: 50-day relative strength
      - sma_pct: % from 50-day SMA (absolute)
      - dd_from_high: drawdown from 50-day high
      - momentum_20d: 20-day return (absolute)
      - sector_rvol_20d: sector 20-day realized vol (annualized %)
      - nifty_rvol_20d: NIFTY 20-day realized vol (annualized %)
      - vol_ratio: sector vol / NIFTY vol (>1 = sector more volatile)
      - sector_vol_regime: CALM / NORMAL / HOT / EXTREME
      - sector_vol_z: sector vol z-score vs its own 1yr history
    """
    default = {"regime": "UNKNOWN", "rs_regime": "UNKNOWN",
               "sma_pct": 0, "dd_from_high": 0, "momentum_20d": 0,
               "rs_20d": 0, "rs_50d": 0,
               "sector_rvol_20d": 0, "nifty_rvol_20d": 0, "vol_ratio": 1.0,
               "sector_vol_regime": "UNKNOWN", "sector_vol_z": 0}

    # Find nearest date in both series
    def _nearest(series, dt):
        valid = series.index[series.index <= dt]
        return valid[-1] if len(valid) > 0 else None

    sdate = _nearest(sector_prices, date)
    ndate = _nearest(nifty_prices, date)
    if sdate is None or ndate is None:
        return default

    sloc = sector_prices.index.get_loc(sdate)
    nloc = nifty_prices.index.get_loc(ndate)
    if isinstance(sloc, slice): sloc = sloc.start
    if isinstance(nloc, slice): nloc = nloc.start
    if sloc < 50 or nloc < 50:
        return default

    # ── Absolute metrics ──────────────────────────────────────────────
    close = float(sector_prices.iloc[sloc])
    sma50 = float(sector_prices.iloc[max(0, sloc-49):sloc+1].mean())
    high50 = float(sector_prices.iloc[max(0, sloc-49):sloc+1].max())
    close_20d = float(sector_prices.iloc[max(0, sloc-20)])
    close_50d = float(sector_prices.iloc[max(0, sloc-50)])

    sma_pct = (close / sma50 - 1) * 100
    dd = (close / high50 - 1) * 100
    mom_20d = (close / close_20d - 1) * 100

    if sma_pct > 2 and dd > -5 and mom_20d > 0:
        regime = "TRENDING"
    elif dd < -10:
        regime = "CRASH"
    else:
        regime = "PULLBACK"

    # ── Relative strength vs NIFTY ────────────────────────────────────
    n_close = float(nifty_prices.iloc[nloc])
    n_close_20d = float(nifty_prices.iloc[max(0, nloc-20)])
    n_close_50d = float(nifty_prices.iloc[max(0, nloc-50)])

    sector_ret_20d = (close / close_20d - 1) * 100
    nifty_ret_20d = (n_close / n_close_20d - 1) * 100
    rs_20d = sector_ret_20d - nifty_ret_20d

    sector_ret_50d = (close / close_50d - 1) * 100
    nifty_ret_50d = (n_close / n_close_50d - 1) * 100
    rs_50d = sector_ret_50d - nifty_ret_50d

    if rs_20d > 2 and rs_50d > 3:
        rs_regime = "LEADING"
    elif rs_20d < -2 and rs_50d < -3:
        rs_regime = "LAGGING"
    else:
        rs_regime = "INLINE"

    # ── Sector realized volatility ────────────────────────────────────
    # 20-day realized vol (annualized) for both sector and NIFTY
    s_start = max(0, sloc - 20)
    n_start = max(0, nloc - 20)
    s_returns = sector_prices.iloc[s_start:sloc+1].pct_change().dropna()
    n_returns = nifty_prices.iloc[n_start:nloc+1].pct_change().dropna()

    sector_rvol = float(s_returns.std() * np.sqrt(252) * 100) if len(s_returns) > 5 else 0
    nifty_rvol = float(n_returns.std() * np.sqrt(252) * 100) if len(n_returns) > 5 else 0
    vol_ratio = round(sector_rvol / nifty_rvol, 2) if nifty_rvol > 0 else 1.0

    # Sector vol z-score vs its own 1-year history
    yr_start = max(0, sloc - 252)
    if sloc - yr_start > 60:
        # Rolling 20-day vol for the past year
        yr_returns = sector_prices.iloc[yr_start:sloc+1].pct_change().dropna()
        rolling_vol = yr_returns.rolling(20).std() * np.sqrt(252) * 100
        rolling_vol = rolling_vol.dropna()
        if len(rolling_vol) > 20:
            vol_mean = float(rolling_vol.mean())
            vol_std = float(rolling_vol.std())
            vol_z = round((sector_rvol - vol_mean) / vol_std, 2) if vol_std > 0 else 0
        else:
            vol_z = 0
    else:
        vol_z = 0

    # Sector vol regime: own vol vs its history
    if vol_z > 2.0:
        sector_vol_regime = "EXTREME"
    elif vol_z > 1.0:
        sector_vol_regime = "HOT"
    elif vol_z > -0.5:
        sector_vol_regime = "NORMAL"
    else:
        sector_vol_regime = "CALM"

    return {
        "regime": regime,
        "rs_regime": rs_regime,
        "sma_pct": round(sma_pct, 2),
        "dd_from_high": round(dd, 2),
        "momentum_20d": round(mom_20d, 2),
        "rs_20d": round(rs_20d, 2),
        "rs_50d": round(rs_50d, 2),
        "sector_rvol_20d": round(sector_rvol, 1),
        "nifty_rvol_20d": round(nifty_rvol, 1),
        "vol_ratio": vol_ratio,
        "sector_vol_regime": sector_vol_regime,
        "sector_vol_z": vol_z,
    }


def compute_stock_beta(stock_prices: pd.Series, sector_prices: pd.Series,
                       date: pd.Timestamp, lookback: int = 60) -> float:
    """Rolling beta of stock vs sector index."""
    end = stock_prices.index.searchsorted(date, side="right")
    start = max(0, end - lookback)
    if end - start < 30:
        return 1.0
    stock_ret = stock_prices.iloc[start:end].pct_change().dropna()
    # Align
    common = stock_ret.index.intersection(sector_prices.index)
    if len(common) < 20:
        return 1.0
    sr = stock_ret.reindex(common)
    secr = sector_prices.reindex(common).pct_change().dropna()
    common2 = sr.index.intersection(secr.index)
    if len(common2) < 20:
        return 1.0
    sr = sr.reindex(common2)
    secr = secr.reindex(common2)
    cov = np.cov(sr, secr)
    if cov[1, 1] == 0:
        return 1.0
    return round(float(cov[0, 1] / cov[1, 1]), 2)


# ══════════════════════════════════════════════════════════════════════════════
# VIX REGIME
# ══════════════════════════════════════════════════════════════════════════════

def classify_vix(vix_val: float) -> str:
    """Same thresholds as regime.py."""
    if vix_val > 25:
        return "PANIC"
    elif vix_val >= 20:
        return "ELEVATED"
    elif vix_val >= 13:
        return "NORMAL"
    return "LOW"


# ══════════════════════════════════════════════════════════════════════════════
# HYPOTHESIS 1: SECTOR REGIME × MR TRADE OUTCOMES
# ══════════════════════════════════════════════════════════════════════════════

def run_hypothesis_1(trades: pd.DataFrame, vix: pd.Series, years: int):
    """Do sector regimes and rotation predict MR trade outcomes?"""
    logger.info("=" * 70)
    logger.info("HYPOTHESIS 1: SECTOR REGIME + ROTATION × MR OUTCOMES")
    logger.info("=" * 70)

    # Fetch NIFTY 50 as benchmark
    logger.info("  Fetching NIFTY 50 benchmark...")
    nifty_df = fetch_daily("^NSEI", years)
    if nifty_df.empty:
        nifty_df = fetch_daily("NIFTY_50.NS", years)
    if nifty_df.empty:
        logger.error("Cannot fetch NIFTY — aborting H1")
        return None
    nifty = nifty_df["Close"].dropna()
    if isinstance(nifty, pd.DataFrame): nifty = nifty.iloc[:, 0]
    if hasattr(nifty.index, "tz") and nifty.index.tz is not None:
        nifty.index = nifty.index.tz_localize(None)
    logger.info("    → NIFTY: %d bars", len(nifty))

    # Fetch sector index data
    sector_data = {}
    fetched_tickers = set()
    for sector, ticker in SECTOR_INDEX_TICKERS.items():
        if ticker in fetched_tickers:
            sector_data[sector] = sector_data[
                [s for s, t in SECTOR_INDEX_TICKERS.items() if t == ticker and s in sector_data][0]
            ]
            continue
        logger.info("  Fetching %s (%s)...", sector, ticker)
        df = fetch_daily(ticker, years)
        if not df.empty:
            s = df["Close"].dropna()
            if isinstance(s, pd.DataFrame): s = s.iloc[:, 0]
            if hasattr(s.index, "tz") and s.index.tz is not None:
                s.index = s.index.tz_localize(None)
            sector_data[sector] = s
            fetched_tickers.add(ticker)
            logger.info("    → %d bars", len(s))
        else:
            logger.warning("    → FAILED")

    if not sector_data:
        logger.error("No sector data fetched — skipping hypothesis 1")
        return None

    # Enrich trades with sector regime + relative strength + sector type
    rows = []
    for _, t in trades.iterrows():
        sym = t["symbol"]
        sector = get_stock_sector(sym)
        entry_date = pd.Timestamp(t["entry_date"])

        if sector in sector_data:
            regime = compute_sector_regime(sector_data[sector], nifty, entry_date)
        else:
            regime = {"regime": "UNKNOWN", "rs_regime": "UNKNOWN",
                      "sma_pct": 0, "dd_from_high": 0, "momentum_20d": 0,
                      "rs_20d": 0, "rs_50d": 0,
                      "sector_rvol_20d": 0, "nifty_rvol_20d": 0, "vol_ratio": 1.0,
                      "sector_vol_regime": "UNKNOWN", "sector_vol_z": 0}

        # VIX at entry
        vix_val = None
        if not vix.empty:
            valid = vix.index[vix.index <= entry_date]
            if len(valid) > 0:
                vix_val = float(vix.loc[valid[-1]])

        rows.append({
            **t.to_dict(),
            "sector": sector,
            "sector_type": SECTOR_TYPE.get(sector, "CYCLICAL"),
            "sector_regime": regime["regime"],
            "sector_rs_regime": regime["rs_regime"],
            "sector_sma_pct": regime["sma_pct"],
            "sector_dd": regime["dd_from_high"],
            "sector_mom_20d": regime["momentum_20d"],
            "sector_rs_20d": regime["rs_20d"],
            "sector_rs_50d": regime["rs_50d"],
            "sector_rvol_20d": regime["sector_rvol_20d"],
            "nifty_rvol_20d": regime["nifty_rvol_20d"],
            "vol_ratio": regime["vol_ratio"],
            "sector_vol_regime": regime["sector_vol_regime"],
            "sector_vol_z": regime["sector_vol_z"],
            "vix_at_entry": vix_val,
            "vix_regime": classify_vix(vix_val) if vix_val else "UNKNOWN",
        })

    enriched = pd.DataFrame(rows)
    enriched["win"] = enriched["pnl_pct"] > 0

    # ── Results ──────────────────────────────────────────────────────
    def _report(title, group_col, sub_df=None):
        df = sub_df if sub_df is not None else enriched
        logger.info("\n%s", "─" * 70)
        logger.info(title)
        logger.info("─" * 70)
        logger.info("  %-14s  %5s  %5s  %8s  %8s  %6s", "GROUP", "N", "WR%", "AVG%", "MED%", "SHARPE")
        for g in sorted(df[group_col].unique()):
            sub = df[df[group_col] == g]
            if len(sub) < 5: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            med = sub["pnl_pct"].median()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            logger.info("  %-14s  %5d  %4.1f%%  %+7.2f%%  %+7.2f%%  %5.2f",
                        g, len(sub), wr, avg, med, sh)

    _report("MR OUTCOMES BY ABSOLUTE SECTOR REGIME", "sector_regime")
    _report("MR OUTCOMES BY RELATIVE STRENGTH (vs NIFTY)", "sector_rs_regime")
    _report("MR OUTCOMES BY SECTOR TYPE", "sector_type")

    # ── Cross: Sector type × VIX regime ──────────────────────────────
    logger.info("\n%s", "─" * 70)
    logger.info("SECTOR TYPE × VIX REGIME (the rotation question)")
    logger.info("Defensive = Pharma/FMCG/IT  ·  Cyclical = Banks/Metals/Auto/Energy")
    logger.info("─" * 70)
    logger.info("  %-11s  %-10s  %5s  %5s  %8s  %6s",
                "SECTOR TYPE", "VIX", "N", "WR%", "AVG%", "SHARPE")
    for st in ["DEFENSIVE", "CYCLICAL"]:
        for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            sub = enriched[(enriched["sector_type"] == st) & (enriched["vix_regime"] == vr)]
            if len(sub) < 5: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            logger.info("  %-11s  %-10s  %5d  %4.1f%%  %+7.2f%%  %5.2f",
                        st, vr, len(sub), wr, avg, sh)

    # ── Cross: RS regime × VIX regime ────────────────────────────────
    logger.info("\n%s", "─" * 70)
    logger.info("RELATIVE STRENGTH × VIX REGIME")
    logger.info("LEADING = sector outperforming NIFTY  ·  LAGGING = underperforming")
    logger.info("─" * 70)
    logger.info("  %-10s  %-10s  %5s  %5s  %8s  %6s",
                "RS REGIME", "VIX", "N", "WR%", "AVG%", "SHARPE")
    for rs in ["LEADING", "INLINE", "LAGGING"]:
        for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            sub = enriched[(enriched["sector_rs_regime"] == rs) & (enriched["vix_regime"] == vr)]
            if len(sub) < 5: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            logger.info("  %-10s  %-10s  %5d  %4.1f%%  %+7.2f%%  %5.2f",
                        rs, vr, len(sub), wr, avg, sh)

    # ── The metals question: cyclical + leading ──────────────────────
    logger.info("\n%s", "─" * 70)
    logger.info("ROTATION EDGE: SECTOR TYPE × RS REGIME (all VIX)")
    logger.info("Key Q: MR in cyclical+lagging vs defensive+leading")
    logger.info("─" * 70)
    logger.info("  %-11s  %-10s  %5s  %5s  %8s  %6s",
                "TYPE", "RS", "N", "WR%", "AVG%", "SHARPE")
    for st in ["DEFENSIVE", "CYCLICAL"]:
        for rs in ["LEADING", "INLINE", "LAGGING"]:
            sub = enriched[(enriched["sector_type"] == st) & (enriched["sector_rs_regime"] == rs)]
            if len(sub) < 5: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            logger.info("  %-11s  %-10s  %5d  %4.1f%%  %+7.2f%%  %5.2f",
                        st, rs, len(sub), wr, avg, sh)

    # ── Sector 20d RS buckets ────────────────────────────────────────
    logger.info("\n%s", "─" * 70)
    logger.info("SECTOR 20d RELATIVE STRENGTH BUCKETS × MR OUTCOMES")
    logger.info("─" * 70)
    enriched["rs_bucket"] = pd.cut(enriched["sector_rs_20d"],
                                    bins=[-100, -5, -2, 0, 2, 5, 100],
                                    labels=["RS<-5%", "RS -5/-2%", "RS -2/0%",
                                            "RS 0/+2%", "RS +2/+5%", "RS>+5%"])
    for bucket in ["RS<-5%", "RS -5/-2%", "RS -2/0%", "RS 0/+2%", "RS +2/+5%", "RS>+5%"]:
        sub = enriched[enriched["rs_bucket"] == bucket]
        if len(sub) < 5: continue
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        logger.info("  %-12s  n=%4d  WR=%.1f%%  avg=%+.2f%%", bucket, len(sub), wr, avg)

    # ── Sector realized volatility regime ────────────────────────────
    _report("MR OUTCOMES BY SECTOR VOL REGIME (own history)", "sector_vol_regime")

    # ── Sector vol vs market vol ─────────────────────────────────────
    logger.info("\n%s", "─" * 70)
    logger.info("SECTOR VOL RATIO BUCKETS (sector rvol / NIFTY rvol)")
    logger.info("vol_ratio > 1.5 = sector way more volatile than market")
    logger.info("─" * 70)
    enriched["vr_bucket"] = pd.cut(enriched["vol_ratio"],
                                    bins=[0, 0.7, 1.0, 1.3, 1.7, 10],
                                    labels=["<0.7×", "0.7-1.0×", "1.0-1.3×",
                                            "1.3-1.7×", ">1.7×"])
    for bucket in ["<0.7×", "0.7-1.0×", "1.0-1.3×", "1.3-1.7×", ">1.7×"]:
        sub = enriched[enriched["vr_bucket"] == bucket]
        if len(sub) < 5: continue
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        std = sub["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        logger.info("  %-10s  n=%4d  WR=%.1f%%  avg=%+.2f%%  Sh=%.2f",
                    bucket, len(sub), wr, avg, sh)

    # ── Sector vol regime × VIX regime ───────────────────────────────
    logger.info("\n%s", "─" * 70)
    logger.info("SECTOR VOL REGIME × VIX REGIME")
    logger.info("Key: VIX = market-wide implied vol, sector_vol = sector-specific realized")
    logger.info("Divergence = sector hot but VIX calm (or vice versa)")
    logger.info("─" * 70)
    logger.info("  %-10s  %-10s  %5s  %5s  %8s  %6s",
                "SECT VOL", "MKT VIX", "N", "WR%", "AVG%", "SHARPE")
    for sv in ["CALM", "NORMAL", "HOT", "EXTREME"]:
        for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            sub = enriched[(enriched["sector_vol_regime"] == sv) & (enriched["vix_regime"] == vr)]
            if len(sub) < 5: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            logger.info("  %-10s  %-10s  %5d  %4.1f%%  %+7.2f%%  %5.2f",
                        sv, vr, len(sub), wr, avg, sh)

    # ── Vol divergence: sector hot + VIX calm, sector calm + VIX high ─
    logger.info("\n%s", "─" * 70)
    logger.info("VOL DIVERGENCE — sector vol vs market VIX mismatch")
    logger.info("─" * 70)
    # Sector hot/extreme but VIX low/normal → sector-specific stress
    sect_stress = enriched[
        enriched["sector_vol_regime"].isin(["HOT", "EXTREME"]) &
        enriched["vix_regime"].isin(["LOW", "NORMAL"])
    ]
    if len(sect_stress) >= 5:
        wr = sect_stress["win"].mean() * 100
        avg = sect_stress["pnl_pct"].mean()
        logger.info("  Sector HOT + VIX calm   n=%4d  WR=%.1f%%  avg=%+.2f%%  (sector-specific selloff)",
                    len(sect_stress), wr, avg)

    # VIX high but sector calm → broad panic, sector resilient
    mkt_stress = enriched[
        enriched["sector_vol_regime"].isin(["CALM", "NORMAL"]) &
        enriched["vix_regime"].isin(["ELEVATED", "PANIC"])
    ]
    if len(mkt_stress) >= 5:
        wr = mkt_stress["win"].mean() * 100
        avg = mkt_stress["pnl_pct"].mean()
        logger.info("  VIX high + Sector calm  n=%4d  WR=%.1f%%  avg=%+.2f%%  (defensive rotation?)",
                    len(mkt_stress), wr, avg)

    # Both hot
    both_hot = enriched[
        enriched["sector_vol_regime"].isin(["HOT", "EXTREME"]) &
        enriched["vix_regime"].isin(["ELEVATED", "PANIC"])
    ]
    if len(both_hot) >= 5:
        wr = both_hot["win"].mean() * 100
        avg = both_hot["pnl_pct"].mean()
        logger.info("  Both HOT               n=%4d  WR=%.1f%%  avg=%+.2f%%  (full panic, max opportunity?)",
                    len(both_hot), wr, avg)

    # Both calm
    both_calm = enriched[
        enriched["sector_vol_regime"].isin(["CALM"]) &
        enriched["vix_regime"].isin(["LOW"])
    ]
    if len(both_calm) >= 5:
        wr = both_calm["win"].mean() * 100
        avg = both_calm["pnl_pct"].mean()
        logger.info("  Both CALM              n=%4d  WR=%.1f%%  avg=%+.2f%%  (nothing moving, skip?)",
                    len(both_calm), wr, avg)

    # Save enriched data
    out_path = "data/backtest_results/sector_regime_trades.csv"
    enriched.to_csv(out_path, index=False)
    logger.info("\nSaved enriched trades → %s (%d rows)", out_path, len(enriched))

    return enriched


# ══════════════════════════════════════════════════════════════════════════════
# HYPOTHESIS 2: MOMENTUM IN EQUITIES BY VIX REGIME
# ══════════════════════════════════════════════════════════════════════════════

def run_hypothesis_2(vix: pd.Series, years: int, n_stocks: int = 30):
    """Does momentum work in equities under specific VIX + sector regimes?"""
    logger.info("\n" + "=" * 70)
    logger.info("HYPOTHESIS 2: EQUITY MOMENTUM BY VIX × SECTOR REGIME")
    logger.info("=" * 70)

    # Get NIFTY 100 universe
    try:
        from modules.index_constituents import get_nifty100
        symbols = list(get_nifty100())[:n_stocks]
    except Exception:
        symbols = []

    # Fallback to hardcoded _STOCK_SECTOR when NSE API returns empty
    if not symbols:
        logger.info("NSE index fetch returned empty — using hardcoded universe")
        symbols = list(_STOCK_SECTOR.keys())[:n_stocks]

    logger.info("Testing %d stocks × %d years", len(symbols), years)

    if vix.empty:
        logger.error("No VIX data — cannot run hypothesis 2")
        return None

    # Fetch NIFTY benchmark for relative strength
    logger.info("  Fetching NIFTY 50 benchmark...")
    nifty_df = fetch_daily("^NSEI", years)
    if nifty_df.empty:
        nifty_df = fetch_daily("NIFTY_50.NS", years)
    nifty_close = pd.Series(dtype=float)
    if not nifty_df.empty:
        nifty_close = nifty_df["Close"].dropna()
        if isinstance(nifty_close, pd.DataFrame): nifty_close = nifty_close.iloc[:, 0]
        if hasattr(nifty_close.index, "tz") and nifty_close.index.tz is not None:
            nifty_close.index = nifty_close.index.tz_localize(None)
        logger.info("    → NIFTY: %d bars", len(nifty_close))

    # Fetch sector indices
    sector_data = {}
    fetched_tickers = set()
    for sector, ticker in SECTOR_INDEX_TICKERS.items():
        if ticker in fetched_tickers:
            for s, t in SECTOR_INDEX_TICKERS.items():
                if t == ticker and s in sector_data:
                    sector_data[sector] = sector_data[s]
                    break
            continue
        df = fetch_daily(ticker, years)
        if not df.empty:
            s = df["Close"].dropna()
            if isinstance(s, pd.DataFrame): s = s.iloc[:, 0]
            if hasattr(s.index, "tz") and s.index.tz is not None:
                s.index = s.index.tz_localize(None)
            sector_data[sector] = s
            fetched_tickers.add(ticker)
    logger.info("  Fetched %d sector indices", len(fetched_tickers))

    all_signals = []
    failed = 0

    for i, sym in enumerate(symbols):
        logger.info("  [%d/%d] %s", i+1, len(symbols), sym)
        df = fetch_daily(f"{sym}.NS", years)
        if df.empty or len(df) < 100:
            failed += 1
            continue

        close = df["Close"]
        if isinstance(close, pd.DataFrame): close = close.iloc[:, 0]
        if hasattr(close.index, "tz") and close.index.tz is not None:
            close.index = close.index.tz_localize(None)

        # Stock's sector context
        sector = get_stock_sector(sym)
        sector_type = SECTOR_TYPE.get(sector, "CYCLICAL")

        # Compute indicators
        sma50 = close.rolling(50).mean()
        sma20 = close.rolling(20).mean()

        h30 = df["High"].rolling(30).max()
        l30 = df["Low"].rolling(30).min()
        if isinstance(h30, pd.DataFrame): h30 = h30.iloc[:, 0]
        if isinstance(l30, pd.DataFrame): l30 = l30.iloc[:, 0]
        wr30 = -100 * (h30 - close) / (h30 - l30 + 1e-9)

        tp = (df["High"] + df["Low"] + df["Close"]) / 3
        if isinstance(tp, pd.DataFrame): tp = tp.iloc[:, 0]
        vol = df["Volume"]
        if isinstance(vol, pd.DataFrame): vol = vol.iloc[:, 0]
        mf = tp * vol
        pos_mf = mf.where(tp > tp.shift(1), 0).rolling(14).sum()
        neg_mf = mf.where(tp < tp.shift(1), 0).rolling(14).sum()
        if isinstance(pos_mf, pd.DataFrame): pos_mf = pos_mf.iloc[:, 0]
        if isinstance(neg_mf, pd.DataFrame): neg_mf = neg_mf.iloc[:, 0]
        mfi = 100 - 100 / (1 + pos_mf / (neg_mf + 1e-9))

        # ── Mean Reversion signals ────────────────────────────────────
        mr_entry = (
            (wr30 < -30) &
            (close < sma50) &
            (mfi > 30)
        )

        # ── Momentum signals ──────────────────────────────────────────
        mom_entry = (
            (close > sma50) &
            (close > sma20) &
            (wr30 > -30) &
            (wr30 < -10) &
            (mfi > 45)
        )

        # Forward returns
        fwd_5d = close.shift(-5) / close - 1
        fwd_10d = close.shift(-10) / close - 1
        fwd_21d = close.shift(-21) / close - 1

        for idx in close.index[60:-25]:
            valid_vix = vix.index[vix.index <= idx]
            if len(valid_vix) == 0:
                continue
            vix_val = float(vix.loc[valid_vix[-1]])
            vix_regime = classify_vix(vix_val)

            for signal_type, mask in [("MR", mr_entry), ("MOMENTUM", mom_entry)]:
                if idx in mask.index and bool(mask.loc[idx]):
                    # Sector regime at signal date
                    if sector in sector_data and not nifty_close.empty:
                        sr = compute_sector_regime(sector_data[sector], nifty_close, idx)
                    else:
                        sr = {"regime": "UNKNOWN", "rs_regime": "UNKNOWN",
                              "sector_rvol_20d": 0, "vol_ratio": 1.0,
                              "sector_vol_regime": "UNKNOWN",
                              "sma_pct": 0, "dd_from_high": 0, "momentum_20d": 0,
                              "rs_20d": 0, "rs_50d": 0, "sector_vol_z": 0}

                    row = {
                        "symbol": sym,
                        "date": idx,
                        "signal": signal_type,
                        "sector": sector,
                        "sector_type": sector_type,
                        "sector_regime": sr["regime"],
                        "sector_rs_regime": sr["rs_regime"],
                        "sector_rs_20d": sr["rs_20d"],
                        "sector_rvol_20d": sr["sector_rvol_20d"],
                        "sector_vol_regime": sr["sector_vol_regime"],
                        "vol_ratio": sr["vol_ratio"],
                        "vix": vix_val,
                        "vix_regime": vix_regime,
                        "wr30": float(wr30.loc[idx]) if idx in wr30.index else np.nan,
                        "mfi": float(mfi.loc[idx]) if idx in mfi.index else np.nan,
                        "fwd_5d": float(fwd_5d.loc[idx]) * 100 if idx in fwd_5d.index else np.nan,
                        "fwd_10d": float(fwd_10d.loc[idx]) * 100 if idx in fwd_10d.index else np.nan,
                        "fwd_21d": float(fwd_21d.loc[idx]) * 100 if idx in fwd_21d.index else np.nan,
                    }
                    all_signals.append(row)

        if (i + 1) % 10 == 0:
            time.sleep(1)

    if not all_signals:
        logger.error("No signals detected — check data")
        return None

    signals = pd.DataFrame(all_signals)
    signals["win_5d"] = signals["fwd_5d"] > 0
    signals["win_10d"] = signals["fwd_10d"] > 0
    signals["win_21d"] = signals["fwd_21d"] > 0

    logger.info("\nTotal signals: %d MR + %d MOMENTUM (%d stocks, %d failed)",
                len(signals[signals["signal"] == "MR"]),
                len(signals[signals["signal"] == "MOMENTUM"]),
                len(symbols) - failed, failed)

    # ══════════════════════════════════════════════════════════════════
    # ANALYSIS TABLES
    # ══════════════════════════════════════════════════════════════════

    def _table(title, df, group_cols, sig_filter=None, horizon="fwd_21d", win_col="win_21d"):
        logger.info("\n%s", "─" * 70)
        logger.info(title)
        logger.info("─" * 70)
        d = df if sig_filter is None else df[df["signal"] == sig_filter]
        if isinstance(group_cols, str):
            group_cols = [group_cols]
        for keys, sub in d.groupby(group_cols):
            sub = sub.dropna(subset=[horizon])
            if len(sub) < 10:
                continue
            wr = sub[win_col].mean() * 100
            avg = sub[horizon].mean()
            med = sub[horizon].median()
            std = sub[horizon].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            label = " × ".join(str(k) for k in (keys if isinstance(keys, tuple) else [keys]))
            logger.info("  %-38s  n=%5d  WR=%5.1f%%  avg=%+6.2f%%  med=%+6.2f%%  Sh=%5.2f",
                        label, len(sub), wr, avg, med, sh)

    # ── 1. Baseline: MR vs Momentum by VIX ───────────────────────────
    for horizon, col, win_col in [("5D", "fwd_5d", "win_5d"),
                                   ("10D", "fwd_10d", "win_10d"),
                                   ("21D", "fwd_21d", "win_21d")]:
        _table(f"FORWARD {horizon}: VIX REGIME × SIGNAL TYPE",
               signals, ["vix_regime", "signal"], horizon=col, win_col=win_col)

    # ── 2. The metals question: Momentum in CYCLICAL + LEADING sectors ─
    _table("MOMENTUM 21D: SECTOR TYPE × RS REGIME (the metals question)",
           signals, ["sector_type", "sector_rs_regime"], sig_filter="MOMENTUM")

    _table("MR 21D: SECTOR TYPE × RS REGIME (for comparison)",
           signals, ["sector_type", "sector_rs_regime"], sig_filter="MR")

    # ── 3. The full cross: signal × sector_type × vix_regime ─────────
    _table("MOMENTUM 21D: SECTOR TYPE × VIX REGIME",
           signals, ["sector_type", "vix_regime"], sig_filter="MOMENTUM")

    _table("MR 21D: SECTOR TYPE × VIX REGIME",
           signals, ["sector_type", "vix_regime"], sig_filter="MR")

    # ── 4. Triple cross: signal × sector_type × rs × vix ─────────────
    logger.info("\n%s", "═" * 70)
    logger.info("THE MONEY TABLE: MOMENTUM signals in CYCLICAL + LEADING sectors by VIX")
    logger.info("(This is the metals-2025 signal)")
    logger.info("═" * 70)
    cyc_lead_mom = signals[
        (signals["signal"] == "MOMENTUM") &
        (signals["sector_type"] == "CYCLICAL") &
        (signals["sector_rs_regime"] == "LEADING")
    ]
    for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
        sub = cyc_lead_mom[cyc_lead_mom["vix_regime"] == vr].dropna(subset=["fwd_21d"])
        if len(sub) < 5:
            continue
        wr = sub["win_21d"].mean() * 100
        avg = sub["fwd_21d"].mean()
        std = sub["fwd_21d"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        # Show which sectors these are
        top_sectors = sub["sector"].value_counts().head(3).to_dict()
        sec_str = ", ".join(f"{s}({n})" for s, n in top_sectors.items())
        logger.info("  VIX %-10s  n=%4d  WR=%5.1f%%  avg=%+6.2f%%  Sh=%5.2f  sectors: %s",
                    vr, len(sub), wr, avg, sh, sec_str)

    # ── 5. Defensive during panic — does momentum hold? ───────────────
    logger.info("\n%s", "═" * 70)
    logger.info("DEFENSIVE MOMENTUM IN PANIC (flight to safety trade)")
    logger.info("═" * 70)
    def_panic_mom = signals[
        (signals["signal"] == "MOMENTUM") &
        (signals["sector_type"] == "DEFENSIVE") &
        (signals["vix_regime"].isin(["ELEVATED", "PANIC"]))
    ].dropna(subset=["fwd_21d"])
    if len(def_panic_mom) >= 5:
        wr = def_panic_mom["win_21d"].mean() * 100
        avg = def_panic_mom["fwd_21d"].mean()
        top = def_panic_mom["sector"].value_counts().head(3).to_dict()
        logger.info("  n=%d  WR=%.1f%%  avg=%+.2f%%  sectors: %s",
                    len(def_panic_mom), wr, avg,
                    ", ".join(f"{s}({n})" for s, n in top.items()))
    else:
        logger.info("  Insufficient data (n=%d)", len(def_panic_mom))

    # ── 6. Sector vol regime impact on momentum ───────────────────────
    _table("MOMENTUM 21D: SECTOR VOL REGIME (own history)",
           signals, "sector_vol_regime", sig_filter="MOMENTUM")

    _table("MR 21D: SECTOR VOL REGIME (own history)",
           signals, "sector_vol_regime", sig_filter="MR")

    # ── 7. Summary: best regime for each strategy ─────────────────────
    logger.info("\n%s", "═" * 70)
    logger.info("SUMMARY: BEST REGIME FOR EACH STRATEGY (21d forward)")
    logger.info("═" * 70)
    for sig in ["MR", "MOMENTUM"]:
        best_avg = -999
        best_label = ""
        for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            for st in ["CYCLICAL", "DEFENSIVE"]:
                for rs in ["LEADING", "INLINE", "LAGGING"]:
                    sub = signals[
                        (signals["signal"] == sig) &
                        (signals["vix_regime"] == vr) &
                        (signals["sector_type"] == st) &
                        (signals["sector_rs_regime"] == rs)
                    ].dropna(subset=["fwd_21d"])
                    if len(sub) < 10:
                        continue
                    avg = sub["fwd_21d"].mean()
                    wr = sub["win_21d"].mean() * 100
                    if avg > best_avg:
                        best_avg = avg
                        best_label = f"{vr} + {st} + {rs}: WR={wr:.0f}% avg={avg:+.2f}% n={len(sub)}"
        logger.info("  %-10s  Best → %s", sig, best_label)

    # ── 8. Head-to-head: per VIX regime ───────────────────────────────
    logger.info("\n%s", "═" * 70)
    logger.info("HEAD-TO-HEAD: MR vs MOMENTUM (21d forward)")
    logger.info("═" * 70)
    for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
        mr = signals[(signals["vix_regime"] == vr) & (signals["signal"] == "MR")]["fwd_21d"].dropna()
        mom = signals[(signals["vix_regime"] == vr) & (signals["signal"] == "MOMENTUM")]["fwd_21d"].dropna()
        if len(mr) < 10 or len(mom) < 10:
            continue
        mr_wr = (mr > 0).mean() * 100
        mom_wr = (mom > 0).mean() * 100
        winner = "MOMENTUM" if mom.mean() > mr.mean() else "MR"
        logger.info("  %-10s  MR: WR=%4.1f%% avg=%+5.2f%% (n=%d)  MOM: WR=%4.1f%% avg=%+5.2f%% (n=%d)  → %s",
                    vr, mr_wr, mr.mean(), len(mr),
                    mom_wr, mom.mean(), len(mom), winner)

    # Save
    out_path = "data/backtest_results/momentum_by_vix_regime.csv"
    signals.to_csv(out_path, index=False)
    logger.info("\nSaved %d signals → %s", len(signals), out_path)

    return signals


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Sector Regime + Momentum Study")
    parser.add_argument("--hypothesis", type=int, choices=[1, 2],
                       help="Run specific hypothesis (default: both)")
    parser.add_argument("--years", type=int, default=7, help="Years of history")
    parser.add_argument("--stocks", type=int, default=30, help="Stocks for H2")
    args = parser.parse_args()

    # Load VIX
    logger.info("Fetching India VIX daily history...")
    vix = fetch_vix_daily(args.years)
    logger.info("VIX: %d daily bars", len(vix))

    # Load OOS trades for H1
    trades_path = "data/backtest_results/wf_oos_trades.csv"
    if os.path.exists(trades_path):
        trades = pd.read_csv(trades_path)
        logger.info("Loaded %d OOS trades", len(trades))
    else:
        trades = pd.DataFrame()
        logger.warning("No OOS trades found at %s", trades_path)

    if args.hypothesis is None or args.hypothesis == 1:
        if not trades.empty:
            run_hypothesis_1(trades, vix, args.years)
        else:
            logger.warning("Skipping H1 — no OOS trades")

    if args.hypothesis is None or args.hypothesis == 2:
        run_hypothesis_2(vix, args.years, n_stocks=args.stocks)

    logger.info("\nDone.")


if __name__ == "__main__":
    main()
