"""scripts/run_walk_forward.py — walk-forward stability analysis.

Question
────────
A single train/test split at 2025-01-01 told us MR's lift survived OOS
(+2.01pp). But this could be a lucky window. Is the edge stable across
many different cutoffs?

Method
──────
For each monthly cutoff from 2023-07 through 2025-12, split the panel
at that date, compute strategy lift on both train and test halves
(with each half's own universe baseline). Plot the test_lift series.

A stable strategy produces a roughly flat test_lift line. A strategy
whose edge is regime-dependent or single-event-driven will spike or
collapse around specific cutoffs.

This is also the template for Phase 7 post-deployment monitoring:
once SignalTracker has accumulated 6+ months of forward returns, the
same harness will produce rolling stability metrics on production
strategies.

Strategies tested
─────────────────
1. MR (current production: streak≥6, bbw<40)        — confirms stability
2. Breakout (research-only)                           — confirms instability
3. PullbackUptrend (research-tier, regime-conditioned) — characterises
4. DrawdownReversal (research-tier)                    — characterises

The output is a table (cutoff | train n/lift | test n/lift | test t)
plus summary statistics (mean test lift, std test lift, % of cutoffs
above 0).
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Callable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import (
    WalkForwardPoint,
    add_forward_returns,
    build_vix_proxy,
    compute_vix_streaks,
    walk_forward_lift,
)


# ══════════════════════════════════════════════════════════════════════════════
# Strategy predicates (vectorised gates)
# ══════════════════════════════════════════════════════════════════════════════

def _and(*conds):
    def fn(df, st):
        result = None
        for c in conds:
            mask = c(df, st)
            result = mask if result is None else (result & mask)
        return result
    return fn


def mr_strict(df, st):
    return _and(
        lambda d, _: d["roc_5"] < -3.0,
        lambda d, _: d["bbw_20_2s_pctl"] < 40.0,
        lambda _, s: s >= 6,
    )(df, st)


def bo_research(df, st):
    return _and(
        lambda d, _: d["roc_20"] > 7.0,
    )(df, st)


def pullback_uptrend(df, st):
    """Round-2 (regime-conditioned) variant — without the regime filter
    here; the regime filter is applied separately in the validation
    script. The bare gates are tested for stability."""
    return _and(
        lambda d, _: d["above_sma_50"].astype(bool),
        lambda d, _: d["above_sma_200"].astype(bool),
        lambda d, _: d["adx_14"] > 20,
        lambda d, _: (d["pct_from_sma_20"] > -3.0)
                      & (d["pct_from_sma_20"] < 0),
    )(df, st)


def drawdown_reversal(df, st):
    return _and(
        lambda d, _: d["dd_from_high_50"] < -8,
        lambda d, _: d["green_streak"] >= 2,
        lambda d, _: d["mfi_14"] > 40,
    )(df, st)


STRATEGIES: dict[str, Callable] = {
    "MR (production)": mr_strict,
    "Breakout (research)": bo_research,
    "PullbackUptrend (research)": pullback_uptrend,
    "DrawdownReversal (research)": drawdown_reversal,
}


# ══════════════════════════════════════════════════════════════════════════════
# Cutoff schedule
# ══════════════════════════════════════════════════════════════════════════════

def monthly_cutoffs(start: str, end: str) -> list[pd.Timestamp]:
    """Generate first-of-month timestamps from ``start`` to ``end`` inclusive."""
    return list(pd.date_range(start=start, end=end, freq="MS"))


CUTOFFS = monthly_cutoffs("2023-07-01", "2025-12-01")  # 30 cutoffs


# ══════════════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════════════

def _print_table(name: str, points: list[WalkForwardPoint]) -> None:
    print()
    print("=" * 96)
    print(f"  {name}")
    print("=" * 96)
    print(
        f"  {'cutoff':12s}  {'tr n':>5s}  {'tr lift':>8s}  "
        f"{'te n':>4s}  {'te lift':>8s}  {'te t':>5s}"
    )
    print("-" * 96)
    for p in points:
        tr_lift = f"{p.train_lift_pp:>+6.2f}pp" if not np.isnan(p.train_lift_pp) else "    --   "
        te_lift = f"{p.test_lift_pp:>+6.2f}pp" if not np.isnan(p.test_lift_pp) else "    --   "
        te_t = f"{p.test_t_stat_lift:>+5.2f}" if not np.isnan(p.test_t_stat_lift) else "  -- "
        print(
            f"  {p.cutoff.date()!s:12s}  {p.train_n:>5d}  {tr_lift}  "
            f"{p.test_n:>4d}  {te_lift}  {te_t}"
        )

    valid = [p for p in points if p.test_n > 0 and not np.isnan(p.test_lift_pp)]
    if not valid:
        print("\n  No valid OOS observations.")
        return
    test_lifts = np.array([p.test_lift_pp for p in valid])
    pct_positive = float((test_lifts > 0).mean()) * 100.0
    print("-" * 96)
    print(f"  Cutoffs evaluated:    {len(valid)}")
    print(f"  Mean test lift:       {test_lifts.mean():+.2f}pp")
    print(f"  Std test lift:        {test_lifts.std(ddof=1):.2f}pp")
    print(f"  Min / Max test lift:  {test_lifts.min():+.2f}pp / {test_lifts.max():+.2f}pp")
    print(f"  % cutoffs lift > 0:   {pct_positive:.0f}%")


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    panel = load_equity_panel()
    if not panel:
        print("No equity panel loaded — yfinance unreachable? Stopping.")
        return

    print("Building VIX proxy and streak series …")
    vix_df = build_vix_proxy(panel, smoothing=5)
    if vix_df.empty:
        print("VIX proxy empty (insufficient symbols) — cannot proceed.")
        return
    high_threshold = float(vix_df["Close"].quantile(0.65))
    streak = compute_vix_streaks(vix_df, high_threshold=high_threshold)
    print(f"  HIGH threshold = {high_threshold:.2f}, max streak = {int(streak.max())}")

    print("Enriching every symbol with indicators + forward returns …")
    engine = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            e = engine.enrich(df, sym)
            e = add_forward_returns(e, horizons=(5, 10, 20))
            enriched[sym] = e
        except Exception:    # noqa: BLE001
            continue
    print(f"  enriched {len(enriched)} symbols")

    print(f"\nWalk-forward analysis at {len(CUTOFFS)} monthly cutoffs "
          f"({CUTOFFS[0].date()} → {CUTOFFS[-1].date()}) …")

    for name, predicate in STRATEGIES.items():
        points = walk_forward_lift(
            enriched_panel=enriched,
            vix_streak=streak,
            predicate=predicate,
            cutoffs=CUTOFFS,
        )
        _print_table(name, points)

    print()
    print("=" * 96)
    print("  How to read this:")
    print("  - A stable strategy has roughly flat test_lift across cutoffs.")
    print("  - A regime-dependent strategy spikes or collapses at particular dates.")
    print("  - 'Std test lift' < ~1pp suggests the OOS edge is reproducible.")
    print("  - '% cutoffs lift > 0' < 50% means the strategy is no better than coin-flip OOS.")
    print("=" * 96)


if __name__ == "__main__":
    main()
