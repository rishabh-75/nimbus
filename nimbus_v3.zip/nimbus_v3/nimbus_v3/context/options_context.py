"""nimbus_v3.context.options_context — option-chain analytics provider.

Consumes the DataFrame returned by ``OptionsLoader.load`` and produces
an ``OptionsContext`` with the six primary option-derived signals:

- **Max pain** — strike minimising total pain to option writers at
  expiry. Computed per expiry; the provider uses the nearest expiry.
- **Walls** — strikes with the largest call OI above spot (resistance)
  and largest put OI below spot (support).
- **PCR (OI)** — sum(put OI) / sum(call OI), a contrarian sentiment gauge.
- **Net GEX** — sum across strikes of Black-Scholes gamma × OI ×
  multiplier, with calls positive and puts negative to dealers. The
  sign indicates whether dealer-flow hedging stabilises (positive) or
  destabilises (negative) the underlying.
- **HVL (High Volume Level)** — strike with the largest combined OI;
  acts as a magnet/pivot in pinning regimes.
- **IVR** — IV rank proxy derived from the chain's own IV distribution,
  since we don't maintain a 52-week IV history. Values are 0–100.

Regimes and risk levels
───────────────────────
``gex_regime`` is TREND_FRIENDLY when net GEX is negative (dealers short
gamma, trend-following flow) or when GEX is neutral but resistance is
far enough that pinning is unlikely. Otherwise PINNING.

``expiry_risk`` combines DTE and pin proximity:
    LOW        — DTE > 4 OR spot comfortably away from max-pain
    ELEVATED   — DTE in {3, 4} with tightening pin
    HIGH       — DTE ≤ 2 OR spot within 2% of max-pain on a short DTE

These thresholds are lifted from ``nimbus_oracle/modules/analytics.py``
as the starting point; Phase 7 research validates or refines on v3's
universe.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd

from nimbus_v3.core.context import OptionsContext
from nimbus_v3.core.types import ExpiryRisk, GEXRegime
from nimbus_v3.data.options_loader import OptionsLoader


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Tunables
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class OptionsAnalysisParams:
    """Parameters governing the options-context derivation. Constructed
    once at provider construction; tests and Phase 7 research can vary
    these without monkey-patching."""

    #: Risk-free rate for Black-Scholes gamma (India 10Y proxy). Small
    #: errors here have limited effect on gamma.
    risk_free_rate: float = 0.07

    #: Contract multiplier. Indian equity options = 1 lot × lot size,
    #: but since OI is reported in contracts and we're computing
    #: relative GEX, the absolute multiplier is less important than
    #: consistency. 100 is the common US-market convention.
    contract_multiplier: float = 100.0

    #: How far in either direction (as fraction of spot) to scan for
    #: walls. Strikes outside this range are ignored.
    wall_scan_pct: float = 0.15

    #: Minimum % distance to call resistance for a NEUTRAL-GEX regime
    #: to still be classified TREND_FRIENDLY rather than PINNING.
    trend_min_resistance_pct: float = 1.5

    #: Spot-to-max-pain proximity (fraction of spot) that marks a pin.
    pin_proximity_pct: float = 0.02

    #: DTE thresholds for expiry risk levels.
    high_risk_dte: int = 2
    elevated_risk_dte: int = 4


_DEFAULTS: Final[OptionsAnalysisParams] = OptionsAnalysisParams()


# ══════════════════════════════════════════════════════════════════════════════
# Provider
# ══════════════════════════════════════════════════════════════════════════════

class OptionsContextProvider:
    """``ContextProvider[OptionsContext]`` over ``OptionsLoader``.

    Uses the nearest expiry's rows from the chain. Symbols without
    listed options (or where the loader returns empty) produce ``None``.
    """

    def __init__(
        self,
        options_loader: OptionsLoader,
        *,
        params: OptionsAnalysisParams = _DEFAULTS,
        index_symbols: frozenset[str] | None = None,
    ) -> None:
        """Args:
            options_loader: Injected loader.
            params: Tunable thresholds.
            index_symbols: Set of symbols that should be treated as
                index options (hit the index endpoint). Defaults to the
                standard Indian index option set. Case-insensitive.
        """
        self._loader = options_loader
        self._params = params
        self._index_symbols = (
            frozenset(s.upper() for s in index_symbols)
            if index_symbols is not None
            else frozenset({"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"})
        )

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def build(
        self,
        *,
        symbol: str | None,
        asof_date: pd.Timestamp,      # noqa: ARG002  — parity-only; live chain is as-of-now
    ) -> OptionsContext | None:
        """Build an :class:`OptionsContext` for ``symbol`` or return
        ``None`` when a live chain can't be sourced.

        The None-return paths are logged at WARNING so an operator
        watching ``nimbus.log`` can diagnose why an F&O index /
        equity shows "—" for PCR OI / NET GEX / TO EXPIRY on the
        dashboard. Common causes:
            * NSE cookie expired → loader.load returns empty
            * Rate-limited after many symbols in quick succession
            * Symbol not in NSE's F&O universe (equity fetch)
            * Spot row missing (chain shape drift at NSE)
        """
        if not symbol:
            return None

        is_index = symbol.upper() in self._index_symbols
        chain = self._loader.load(symbol, is_index=is_index)
        if chain.empty:
            logger.warning(
                "options: %s (is_index=%s) — loader returned EMPTY chain. "
                "Likely NSE fetch failure (cookie stale, rate-limited, "
                "or symbol not F&O-listed). Dashboard options fields "
                "will show '—'.",
                symbol, is_index,
            )
            return None

        expiries = self._loader.get_expiries(chain)
        if not expiries:
            logger.warning(
                "options: %s — chain has %d rows but get_expiries() "
                "returned empty. Likely parse drift in chain['expiry'].",
                symbol, len(chain),
            )
            return None
        nearest = expiries[0]
        near = chain[chain["expiry"] == nearest].copy()
        if near.empty:
            logger.warning(
                "options: %s — no rows for nearest expiry %s.",
                symbol, nearest,
            )
            return None

        spot = _extract_spot(near)
        if spot is None or spot <= 0:
            logger.warning(
                "options: %s — spot extraction failed (got %r) from "
                "%d rows at expiry %s.",
                symbol, spot, len(near), nearest,
            )
            return None

        dte = int(near["dte"].iloc[0])
        max_pain = _max_pain(near)
        support_wall, resistance_wall = _walls(near, spot, self._params.wall_scan_pct)
        pct_to_support = _pct_gap(spot, support_wall) if support_wall else None
        pct_to_resistance = _pct_gap(spot, resistance_wall) if resistance_wall else None
        net_gex = _net_gex(near, spot, dte, self._params)
        hvl = _hvl(near)
        pcr_oi = _pcr_oi(near)
        iv_atm = _iv_atm(near, spot)
        ivr = _ivr_proxy(near, iv_atm)
        gex_regime = _classify_gex_regime(net_gex, pct_to_resistance, self._params)
        expiry_risk = _classify_expiry_risk(
            dte=dte, spot=spot, max_pain=max_pain, params=self._params,
        )

        ctx = OptionsContext(
            asof_date=pd.Timestamp(asof_date),
            symbol=symbol.upper(),
            spot=float(spot),
            dte=dte,
            max_pain=max_pain,
            support_wall=support_wall,
            resistance_wall=resistance_wall,
            pct_to_support=pct_to_support,
            pct_to_resistance=pct_to_resistance,
            net_gex=net_gex,
            hvl=hvl,
            gex_regime=gex_regime,
            pcr_oi=pcr_oi,
            iv_atm=iv_atm,
            ivr=ivr,
            expiry_risk=expiry_risk,
        )
        logger.info(
            "options: %s → spot=%.2f dte=%d pcr=%.2f net_gex=%s "
            "wallR=%s wallS=%s regime=%s",
            symbol, spot, dte,
            pcr_oi if pcr_oi is not None else float("nan"),
            f"{net_gex/1e6:+.1f}M" if net_gex is not None else "—",
            f"{resistance_wall:,.0f}" if resistance_wall else "—",
            f"{support_wall:,.0f}" if support_wall else "—",
            gex_regime.value if gex_regime is not None else "—",
        )
        return ctx


# ══════════════════════════════════════════════════════════════════════════════
# Computation helpers — all pure, separately testable
# ══════════════════════════════════════════════════════════════════════════════

def _extract_spot(near_expiry: pd.DataFrame) -> float | None:
    """Return the chain-reported spot. All rows carry the same spot."""
    if near_expiry.empty or "spot" not in near_expiry.columns:
        return None
    value = float(near_expiry["spot"].iloc[0])
    return value if value > 0 and not np.isnan(value) else None


def _max_pain(near: pd.DataFrame) -> float | None:
    """Return the strike that minimises total option-writer pain at expiry.

    Pain for a strike K given OI is:
        call_pain(K) = Σ_strikes_below_K (K - strike) × put_oi(strike)
                    + Σ_strikes_above_K (strike - K) × call_oi(strike)
    """
    if near.empty:
        return None
    strikes = near["strike"].to_numpy()
    ce_oi = near["ce_oi"].to_numpy()
    pe_oi = near["pe_oi"].to_numpy()
    pain = np.zeros(len(strikes))
    for i, K in enumerate(strikes):
        call_contrib = np.where(strikes > K, (strikes - K) * ce_oi, 0.0).sum()
        put_contrib = np.where(strikes < K, (K - strikes) * pe_oi, 0.0).sum()
        pain[i] = call_contrib + put_contrib
    idx = int(np.argmin(pain))
    return float(strikes[idx])


def _walls(
    near: pd.DataFrame, spot: float, scan_pct: float,
) -> tuple[float | None, float | None]:
    """Return ``(support_wall, resistance_wall)``.

    Support: strike below spot with the largest PE OI (within ``scan_pct``).
    Resistance: strike above spot with the largest CE OI.
    """
    below = near[near["strike"] < spot]
    above = near[near["strike"] > spot]
    window = spot * scan_pct
    below = below[below["strike"] >= spot - window]
    above = above[above["strike"] <= spot + window]
    support = (
        float(below.loc[below["pe_oi"].idxmax(), "strike"])
        if not below.empty and below["pe_oi"].max() > 0
        else None
    )
    resistance = (
        float(above.loc[above["ce_oi"].idxmax(), "strike"])
        if not above.empty and above["ce_oi"].max() > 0
        else None
    )
    return support, resistance


def _pct_gap(spot: float, level: float | None) -> float | None:
    if level is None:
        return None
    return (level - spot) / spot * 100.0


def _net_gex(
    near: pd.DataFrame, spot: float, dte: int, params: OptionsAnalysisParams,
) -> float | None:
    """Sum of per-strike gamma × OI × multiplier × S², dealers short
    gamma in calls and long in puts (convention: calls positive,
    puts negative).

    If IV is missing at a strike, that strike contributes zero.
    """
    if near.empty:
        return None
    t = max(dte, 1) / 365.0
    r = params.risk_free_rate
    mult = params.contract_multiplier

    def _gamma(strike: float, iv_pct: float) -> float:
        if iv_pct is None or iv_pct <= 0 or np.isnan(iv_pct):
            return 0.0
        sigma = iv_pct / 100.0
        st = sigma * math.sqrt(t)
        if st == 0:
            return 0.0
        d1 = (math.log(spot / strike) + (r + 0.5 * sigma * sigma) * t) / st
        phi = math.exp(-0.5 * d1 * d1) / math.sqrt(2 * math.pi)
        return phi / (spot * st)

    total = 0.0
    for row in near.itertuples(index=False):
        strike = float(row.strike)
        ce_iv = float(row.ce_iv) if not pd.isna(row.ce_iv) else float("nan")
        pe_iv = float(row.pe_iv) if not pd.isna(row.pe_iv) else float("nan")
        g_ce = _gamma(strike, ce_iv) if not np.isnan(ce_iv) else 0.0
        g_pe = _gamma(strike, pe_iv) if not np.isnan(pe_iv) else 0.0
        # Per-strike GEX: dealer perspective → short calls (+), long puts (−).
        gex = (g_ce * float(row.ce_oi) - g_pe * float(row.pe_oi)) * mult * spot * spot * 0.01
        total += gex
    return float(total)


def _hvl(near: pd.DataFrame) -> float | None:
    """High Volume Level: strike with the largest combined OI."""
    if near.empty:
        return None
    combined = near["ce_oi"] + near["pe_oi"]
    if combined.max() <= 0:
        return None
    return float(near.loc[combined.idxmax(), "strike"])


def _pcr_oi(near: pd.DataFrame) -> float | None:
    if near.empty:
        return None
    ce_sum = float(near["ce_oi"].sum())
    pe_sum = float(near["pe_oi"].sum())
    if ce_sum == 0:
        return None
    return pe_sum / ce_sum


def _iv_atm(near: pd.DataFrame, spot: float) -> float | None:
    """Return the closer-of-CE/PE IV at the strike nearest to spot."""
    if near.empty:
        return None
    idx = int((near["strike"] - spot).abs().idxmin())
    row = near.iloc[idx]
    candidates = [
        v for v in (row.get("ce_iv"), row.get("pe_iv"))
        if v is not None and not pd.isna(v) and v > 0
    ]
    if not candidates:
        return None
    return float(sum(candidates) / len(candidates))


def _ivr_proxy(near: pd.DataFrame, iv_atm: float | None) -> float | None:
    """Within-chain IV rank proxy — current ATM IV's percentile vs. the
    chain's P5–P95 of CE IV. Returns 0–100 or None."""
    if iv_atm is None or near.empty:
        return None
    iv_series = pd.to_numeric(near["ce_iv"], errors="coerce").dropna()
    iv_series = iv_series[iv_series > 0]
    if len(iv_series) < 5:
        return None
    lo = float(iv_series.quantile(0.05))
    hi = float(iv_series.quantile(0.95))
    if hi <= lo:
        return None
    rank = (iv_atm - lo) / (hi - lo) * 100.0
    return float(max(0.0, min(100.0, rank)))


def _classify_gex_regime(
    net_gex: float | None,
    pct_to_resistance: float | None,
    params: OptionsAnalysisParams,
) -> GEXRegime | None:
    if net_gex is None:
        return None
    if net_gex < 0:
        return GEXRegime.TREND_FRIENDLY
    # Neutral-ish GEX: TREND_FRIENDLY only if resistance is far away.
    if pct_to_resistance is not None and pct_to_resistance >= params.trend_min_resistance_pct:
        return GEXRegime.TREND_FRIENDLY
    return GEXRegime.PINNING


def _classify_expiry_risk(
    *,
    dte: int,
    spot: float,
    max_pain: float | None,
    params: OptionsAnalysisParams,
) -> ExpiryRisk:
    if dte <= 0:
        return ExpiryRisk.HIGH
    if dte <= params.high_risk_dte:
        return ExpiryRisk.HIGH
    near_pin = (
        max_pain is not None
        and spot > 0
        and abs(spot - max_pain) / spot < params.pin_proximity_pct
    )
    if dte <= params.elevated_risk_dte and near_pin:
        return ExpiryRisk.HIGH
    if dte <= params.elevated_risk_dte or near_pin:
        return ExpiryRisk.ELEVATED
    return ExpiryRisk.LOW
