#!/usr/bin/env python3
"""
scripts/run_etf_vix_backtest.py — ETF Momentum strategy backtested against VIX regimes.

ETF momentum (pullback-in-trend) is the OPPOSITE of equity mean reversion.
Hypothesis: high VIX BREAKS trends (bad for momentum), low VIX = clean trends (good).

Runs the momentum entry/exit logic bar-by-bar on the ETF universe,
records all trades, then analyzes performance by VIX regime.

Usage:
    python3 scripts/run_etf_vix_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("etf_vix_bt")

# ETF universe — liquid ETFs suitable for momentum
ETF_SYMBOLS = [
    "GOLDBEES", "GOLDCASE", "GOLDETF",
    "SILVERBEES", "SILVERIETF",
    "NIFTYBEES", "SETFNIF50", "JUNIORBEES", "NV20IETF",
    "BANKBEES", "SETFNIFBK", "PSUBNKBEES", "FINIETF",
    "ITBEES", "PHARMABEES", "INFRABEES", "CPSEETF",
    "AUTOIETF", "FMCGIETF", "HEALTHIETF",
    "COMMOIETF", "METALIETF", "OILIETF",
    "MOM100", "LOWVOLIETF", "MIDCAPIETF",
]


def fetch_data(symbols, years=5):
    """Download price data for ETF symbols."""
    import yfinance as yf
    data = {}
    for i, sym in enumerate(symbols):
        try:
            df = yf.download(f"{sym}.NS", period=f"{years}y", progress=False, timeout=15)
            if df is not None and not df.empty:
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = df.columns.get_level_values(0)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                if len(df) >= 60:
                    data[sym] = df
        except Exception:
            pass
        if (i + 1) % 10 == 0:
            logger.info("  %d/%d downloaded", i + 1, len(symbols))
    return data


def fetch_vix(start, end):
    import yfinance as yf
    vix = yf.download("^INDIAVIX", start=start, end=end, progress=False)
    if vix is None or vix.empty:
        return None
    if isinstance(vix.columns, pd.MultiIndex):
        vix.columns = vix.columns.get_level_values(0)
    vix.index = pd.to_datetime(vix.index)
    if hasattr(vix.index, "tz") and vix.index.tz is not None:
        vix.index = vix.index.tz_localize(None)
    return vix["Close"]


def run_backtest(price_data):
    """Run momentum entry/exit bar-by-bar, return list of trades."""
    from modules.etf_momentum import (
        compute_etf_momentum, check_exit, MomentumSignal,
        SMA_TREND, WR_DIP_LEVEL, WR_RECOVER, DIP_LOOKBACK,
        TRAIL_ATR_MULT, MAX_HOLD, PROFIT_TARGET,
    )

    all_trades = []

    for sym, df in price_data.items():
        if len(df) < 80:
            continue

        # Pre-compute indicators for each window
        position = None  # None or dict with entry info

        for i in range(60, len(df)):
            window = df.iloc[:i + 1]
            try:
                sig = compute_etf_momentum(window, symbol=sym)
            except Exception:
                continue

            if not sig.data_sufficient:
                continue

            current_date = df.index[i]
            current_price = float(df.iloc[i]["Close"])

            # ── In position: check exit ──
            if position is not None:
                bars_held = position["bars_held"] + 1
                peak = max(position["peak"], current_price)

                exit_reason = check_exit(sig, position["entry_price"], peak, bars_held)

                if exit_reason:
                    pnl = (current_price / position["entry_price"] - 1) * 100
                    all_trades.append({
                        "symbol": sym,
                        "entry_date": position["entry_date"],
                        "exit_date": current_date,
                        "entry_price": position["entry_price"],
                        "exit_price": current_price,
                        "pnl_pct": round(pnl, 3),
                        "bars_held": bars_held,
                        "exit_reason": exit_reason.replace("_", ""),
                        "score": position["score"],
                    })
                    position = None
                else:
                    position["bars_held"] = bars_held
                    position["peak"] = peak

            # ── Not in position: check entry ──
            elif sig.entry_triggered:
                position = {
                    "entry_date": current_date,
                    "entry_price": current_price,
                    "peak": current_price,
                    "bars_held": 0,
                    "score": sig.momentum_score,
                }

    return all_trades


def calc_stats(pnls):
    if len(pnls) < 3:
        return {"n": len(pnls), "avg": 0, "win": 0, "sharpe": 0}
    arr = np.array(pnls)
    avg = float(np.mean(arr)); std = float(np.std(arr))
    return {
        "n": len(arr), "avg": round(avg, 3),
        "win": round((arr > 0).mean() * 100, 1),
        "sharpe": round(avg / std * np.sqrt(252 / 20), 2) if std > 0 else 0,
        "median": round(float(np.median(arr)), 3),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--years", type=int, default=5)
    parser.add_argument("--output", default="etf_vix_backtest_report.txt")
    args = parser.parse_args()

    logger.info("Downloading ETF price data (%d symbols, %dyr)...", len(ETF_SYMBOLS), args.years)
    price_data = fetch_data(ETF_SYMBOLS, years=args.years)
    logger.info("Got data for %d/%d ETFs", len(price_data), len(ETF_SYMBOLS))

    logger.info("Running momentum backtest bar-by-bar...")
    trades = run_backtest(price_data)
    logger.info("Generated %d trades across %d ETFs",
                len(trades), len(set(t["symbol"] for t in trades)))

    if not trades:
        logger.error("No trades generated — check data")
        return

    trades_df = pd.DataFrame(trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])

    # Fetch VIX
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    logger.info("Fetching India VIX...")
    vix_series = fetch_vix(start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"))

    # Match VIX to trades
    if vix_series is not None:
        vix_at_entry = []
        for _, row in trades_df.iterrows():
            dt = row["entry_date"]
            mask = vix_series.index <= dt
            vix_at_entry.append(float(vix_series[mask].iloc[-1]) if mask.any() else np.nan)
        trades_df["vix"] = vix_at_entry
    else:
        trades_df["vix"] = np.nan

    # ── Report ──
    report = []
    report.append("=" * 70)
    report.append("ETF MOMENTUM × VIX REGIME BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(trades_df)} | ETFs: {trades_df['symbol'].nunique()}")
    report.append(f"Dates: {trades_df['entry_date'].min().date()} → {trades_df['entry_date'].max().date()}")
    report.append("=" * 70)

    # Overall stats
    overall = calc_stats(trades_df["pnl_pct"].values)
    report.append(f"\nOVERALL: N={overall['n']} avg={overall['avg']:+.3f}% "
                  f"win={overall['win']:.1f}% Sh={overall['sharpe']:.2f}")

    # Exit reason breakdown
    report.append("\nEXIT REASONS:")
    for reason in trades_df["exit_reason"].unique():
        bucket = trades_df[trades_df["exit_reason"] == reason]
        s = calc_stats(bucket["pnl_pct"].values)
        report.append(f"  {reason:15s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  win={s['win']:.1f}%")

    # ── TEST 1: VIX regime ──
    report.append("\n" + "=" * 70)
    report.append("TEST 1: ETF MOMENTUM BY VIX REGIME")
    report.append("=" * 70)
    report.append("\n  Hypothesis: Momentum NEEDS trends. High VIX breaks trends → worse performance.")

    vix_buckets = [("Low (<13)", 0, 13), ("Normal (13-18)", 13, 18),
                   ("Elevated (18-24)", 18, 24), ("Panic (>24)", 24, 999)]

    valid = trades_df.dropna(subset=["vix"])
    for label, lo, hi in vix_buckets:
        bucket = valid[(valid["vix"] >= lo) & (valid["vix"] < hi)]
        if len(bucket) < 5:
            report.append(f"  {label:20s}: N={len(bucket):4d}  (insufficient)")
            continue
        s = calc_stats(bucket["pnl_pct"].values)
        report.append(f"  {label:20s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}")

    # T-test
    low = valid[valid["vix"] < 15]["pnl_pct"].values
    high = valid[valid["vix"] >= 20]["pnl_pct"].values
    if len(low) >= 10 and len(high) >= 10:
        try:
            from scipy import stats
            t, p = stats.ttest_ind(low, high, equal_var=False)
            report.append(f"\n  Low VIX (<15) vs High VIX (≥20):")
            report.append(f"    t={t:.3f}  p={p:.4f}  "
                          f"{'✓ SIGNIFICANT' if p < 0.05 else '○ not significant'}")
        except ImportError:
            pass

    # ── TEST 2: Does VIX predict trend breaks? ──
    report.append("\n" + "=" * 70)
    report.append("TEST 2: EXIT REASON BY VIX (does high VIX = more trend breaks?)")
    report.append("=" * 70)

    for label, lo, hi in vix_buckets:
        bucket = valid[(valid["vix"] >= lo) & (valid["vix"] < hi)]
        if len(bucket) < 10:
            continue
        n = len(bucket)
        pt = (bucket["exit_reason"] == "PROFITTARGET").mean() * 100
        trail = (bucket["exit_reason"] == "TRAILSTOP").mean() * 100
        sma = (bucket["exit_reason"] == "SMABREAK").mean() * 100
        maxh = (bucket["exit_reason"] == "MAXHOLD").mean() * 100
        report.append(f"  {label:20s}: N={n:4d}  PT={pt:.0f}%  Trail={trail:.0f}%  "
                      f"SMA_brk={sma:.0f}%  MAX={maxh:.0f}%")

    report.append("\n  If SMA_brk% rises with VIX → high VIX breaks trends")
    report.append("  If PT% falls with VIX → high VIX prevents clean profits")

    # ── TEST 3: Bars held by VIX ──
    report.append("\n" + "=" * 70)
    report.append("TEST 3: BARS HELD BY VIX REGIME")
    report.append("=" * 70)

    for label, lo, hi in vix_buckets:
        bucket = valid[(valid["vix"] >= lo) & (valid["vix"] < hi)]
        if len(bucket) < 10:
            continue
        avg_bars = bucket["bars_held"].mean()
        wins = bucket[bucket["pnl_pct"] > 0]
        loses = bucket[bucket["pnl_pct"] <= 0]
        report.append(f"  {label:20s}: N={len(bucket):4d}  avg_bars={avg_bars:.1f}  "
                      f"win_bars={wins['bars_held'].mean():.1f}  "
                      f"lose_bars={loses['bars_held'].mean():.1f}")

    # ── Decision framework ──
    report.append("\n" + "=" * 70)
    report.append("DECISION FRAMEWORK")
    report.append("=" * 70)
    report.append("""
  ETF momentum is trend-following. Expected VIX impact:
    Low VIX:     Clean trends, momentum works well
    Normal VIX:  Standard conditions
    High VIX:    Trends break, SMA stops trigger, momentum fails

  This is the INVERSE of equity mean reversion (which loves panic).

  IF Low VIX outperforms:
    → Add VIX bonus to ETF scores when VIX < 13
    → Reduce ETF sizing when VIX > 20

  IF no VIX effect:
    → Keep ETF scoring independent of VIX

  IF results mirror equity MR (high VIX = better):
    → Surprising — ETFs may be mean-reverting too
    → Investigate whether commodity ETFs drive this
""")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)

    # Also save trades for future analysis
    trades_df.to_csv("etf_oos_trades.csv", index=False)
    logger.info("Trades saved: etf_oos_trades.csv")


if __name__ == "__main__":
    main()
