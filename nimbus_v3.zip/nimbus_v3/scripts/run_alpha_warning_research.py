"""scripts/run_alpha_warning_research.py — warning-feature ablation on ALPHA.

The +2.00pp fwd-20d edge on ALPHA (is_alpha_leader=True) was measured
as an AVERAGE across all ALPHA fires. This research asks a refinement:
among the ALPHA cohort, can we detect a subset that underperforms due
to blow-off-top exhaustion or momentum fading?

Design
------
ALPHA cohort = stocks where ``alpha_vs_industry`` is in the top 10%
of the panel at the bar. We split the cohort by each candidate
warning feature and measure forward-return delta of warned vs
unwarned ALPHA fires.

Candidate warnings
------------------
Group A — blow-off / exhaustion (stock has already rallied hard):
  blowoff_roc20_15   : roc_20 > 15%
  blowoff_bb_95      : bb_pct > 0.95  (near upper BB)
  blowoff_bb_100     : bb_pct > 1.00  (parabolic — outside upper BB)
  blowoff_stretched  : close > 1.20 * sma_50
  blowoff_accel      : roc_5 > roc_20 * 0.6  (most move in last week)

Group B — momentum fading (recent action contradicts cumulative alpha):
  fading_roc5_neg    : roc_5 < 0
  fading_decel       : roc_5 < roc_20 * 0.25  (recent pace < 25% of 20d)
  fading_vol_col     : vol_chg_20 < -30  (volume collapsing)
  fading_below_sma20 : close < sma_20

Decision criteria (stricter than general tag research)
------------------------------------------------------
A feature is promoted to production only when:
  - n_warned >= 500  (statistical power)
  - |delta_pp| >= 0.5  (meaningful magnitude within ALPHA)
  - |t_stat| >= 3.0    (stricter than 2.0 elsewhere — false
                        warnings on leaders are costly)

Sanity check: for each working warning, we compute the same feature's
delta on the non-ALPHA cohort. If non-α Δ ≈ α Δ, the feature isn't
ALPHA-specific — it's a broadly harmful signal. Those get flagged.

Run::

    python scripts/run_alpha_warning_research.py

Writes:
  - data/alpha_warning_research.csv
  - stdout report
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nimbus_v3.data.industry_db import load_industry_db              # noqa: E402
from nimbus_v3.research.equity_universe import load_equity_panel     # noqa: E402
# Reuse the proven alpha/beta compute pipeline — same methodology
# as run_alpha_walk_forward.py and run_beta_feature_research.py.
from scripts.run_beta_feature_research import (                      # noqa: E402
    build_industry_returns_and_phase,
    compute_beta_features,
)

logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("alpha_warning_research")


# ══════════════════════════════════════════════════════════════════════
# Stats helpers
# ══════════════════════════════════════════════════════════════════════

def welch_t(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(va / na + vb / nb)
    if denom == 0 or not np.isfinite(denom):
        return float("nan")
    return float((a.mean() - b.mean()) / denom)


def ablate(
    feats: pd.DataFrame, alpha_mask: np.ndarray,
    warning_mask: np.ndarray, fwd_col: str, name: str,
) -> dict:
    """Within the ALPHA cohort, split by the warning mask and
    compare forward returns of warned vs unwarned subsets."""
    fwd = feats[fwd_col].to_numpy()
    valid = np.isfinite(fwd)

    warned = valid & alpha_mask & warning_mask
    unwarned = valid & alpha_mask & ~warning_mask

    w_ret = fwd[warned]
    u_ret = fwd[unwarned]

    return {
        "warning": name,
        "horizon": fwd_col,
        "n_warned": int(warned.sum()),
        "n_unwarned": int(unwarned.sum()),
        "warned_pct": float(w_ret.mean() * 100) if len(w_ret) else float("nan"),
        "unwarned_pct": float(u_ret.mean() * 100) if len(u_ret) else float("nan"),
        "delta_pp": (
            float((w_ret.mean() - u_ret.mean()) * 100)
            if len(w_ret) and len(u_ret) else float("nan")
        ),
        "t_stat": welch_t(w_ret, u_ret),
    }


def ablate_non_alpha(
    feats: pd.DataFrame, alpha_mask: np.ndarray,
    warning_mask: np.ndarray, fwd_col: str,
) -> float:
    """Same warning applied to the NON-ALPHA cohort. Used to
    distinguish ALPHA-specific warnings from broadly harmful
    features. Returns delta_pp only."""
    fwd = feats[fwd_col].to_numpy()
    valid = np.isfinite(fwd)
    non_alpha = valid & ~alpha_mask
    warned = non_alpha & warning_mask
    unwarned = non_alpha & ~warning_mask
    w = fwd[warned]
    u = fwd[unwarned]
    if len(w) < 100 or len(u) < 100:
        return float("nan")
    return float((w.mean() - u.mean()) * 100)


def decile_within_alpha(
    feats: pd.DataFrame, alpha_mask: np.ndarray,
    feature: str, fwd_col: str,
) -> pd.DataFrame:
    """Bucket the ALPHA cohort into deciles of the feature and
    report mean forward return per decile. A monotonic progression
    from decile 0 to decile 9 is the cleanest evidence the
    feature segments the cohort."""
    sub = feats[alpha_mask].copy()
    sub = sub[np.isfinite(sub[feature]) & np.isfinite(sub[fwd_col])]
    if len(sub) < 1000:
        return pd.DataFrame()
    deciles = pd.qcut(sub[feature], 10, labels=False, duplicates="drop")
    grouped = (
        sub.assign(decile=deciles)
           .groupby("decile", observed=True)
           .agg(
               n=(fwd_col, "size"),
               mean_fwd=(fwd_col, "mean"),
               feature_min=(feature, "min"),
               feature_max=(feature, "max"),
           )
    )
    grouped["mean_fwd_pct"] = grouped["mean_fwd"] * 100
    return grouped


# ══════════════════════════════════════════════════════════════════════
# Verdict rules
# ══════════════════════════════════════════════════════════════════════

def verdict(row: dict) -> str:
    n = row["n_warned"]
    d = row["delta_pp"]
    t = row["t_stat"]
    if n < 500:
        return "too few warned fires"
    if np.isnan(d) or np.isnan(t):
        return "n/a"
    if d <= -0.5 and t <= -3.0:
        return "STRONG working"
    if d <= -0.3 and t <= -2.0:
        return "weak working"
    if d >= +0.5 and t >= +3.0:
        return "STRONG HARMFUL (warned ALPHA outperforms!)"
    if d >= +0.3 and t >= +2.0:
        return "weak harmful"
    if abs(d) < 0.3 or abs(t) < 1.5:
        return "noise"
    return "inconclusive"


# ══════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════

def print_warning_table(rows: list[dict], non_alpha_deltas: dict) -> None:
    hdr = (
        f"  {'warning':22s}  {'horizon':8s}  {'n_warn':>7s}  {'n_kept':>7s}  "
        f"{'warn%':>7s}  {'kept%':>7s}  {'Δ pp':>7s}  {'t':>7s}  "
        f"{'non-α Δ':>8s}  verdict"
    )
    sep = "─" * len(hdr)
    print(sep)
    print(hdr)
    print(sep)
    for r in rows:
        v = verdict(r)
        non_alpha_d = non_alpha_deltas.get(
            (r["warning"], r["horizon"]), float("nan"),
        )
        non_alpha_str = (
            f"{non_alpha_d:>+7.3f}" if np.isfinite(non_alpha_d) else "    n/a"
        )
        print(
            f"  {r['warning']:22s}  {r['horizon']:8s}  "
            f"{r['n_warned']:>7,d}  {r['n_unwarned']:>7,d}  "
            f"{r['warned_pct']:>+6.3f}  {r['unwarned_pct']:>+6.3f}  "
            f"{r['delta_pp']:>+6.3f}  {r['t_stat']:>+6.2f}  "
            f"{non_alpha_str}  {v}"
        )
    print(sep)


def print_decile_table(
    grouped: pd.DataFrame, feature: str, horizon: str,
) -> None:
    print(f"\nDecile within ALPHA: {feature} vs {horizon}")
    print("─" * 62)
    print(f"  {'decile':>6s}  {'n':>6s}  {'feature range':>22s}  {'fwd%':>8s}")
    for decile, row in grouped.iterrows():
        rng = f"{row['feature_min']:+7.2f} to {row['feature_max']:+7.2f}"
        print(
            f"  {decile:>6}  {int(row['n']):>6,d}  {rng:>22s}  "
            f"{row['mean_fwd_pct']:>+7.3f}"
        )
    spread = grouped.iloc[-1]["mean_fwd_pct"] - grouped.iloc[0]["mean_fwd_pct"]
    print(f"  Spread (top decile − bottom decile): {spread:+.3f}pp")
    print("─" * 62)


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Loading equity panel …")
    panel = load_equity_panel(verbose=False)
    log.info("Panel: %d symbols", len(panel))

    log.info("Loading industry DB …")
    ind_db = load_industry_db()
    industry_map = {sym: rec.industry for sym, rec in ind_db.items()}

    log.info("Building industry return + phase series …")
    industry_rets, industry_phases, industry_members = (
        build_industry_returns_and_phase(panel, industry_map)
    )

    log.info("Computing per-stock beta / alpha feature table …")
    feats = compute_beta_features(
        panel, industry_map, industry_rets, industry_phases,
        industry_members,
    )
    # Drop rows with no alpha (early history)
    feats = feats[feats["alpha_vs_industry"].notna()].copy()
    log.info("Valid rows for ablation: %d", len(feats))

    # ── Build the ALPHA cohort mask ─────────────────────────────────
    # ALPHA = alpha_vs_industry panel percentile >= 90 at that bar.
    # Matches the production definition of ``is_alpha_leader`` which
    # uses an absolute threshold calibrated to the historical 90th
    # percentile — see _ALPHA_LEADER_THRESHOLD_PCT_DAY in
    # nimbus_v3/compute/industry_analytics.py.
    log.info("Computing panel-wide alpha percentile per bar …")
    feats["alpha_pct"] = (
        feats.groupby("bar_date", observed=True)["alpha_vs_industry"]
             .rank(pct=True) * 100
    )
    alpha_mask = (feats["alpha_pct"] >= 90.0).to_numpy()
    n_alpha = int(alpha_mask.sum())
    log.info("ALPHA cohort: %d fires (%.1f%% of panel)",
             n_alpha, 100 * n_alpha / len(feats))

    # ── Build warning feature masks ─────────────────────────────────
    roc_5 = feats["roc_5"].to_numpy()
    roc_20 = feats["roc_20"].to_numpy()
    close = feats["close"].to_numpy()
    sma_20 = feats["sma_20"].to_numpy()
    sma_50 = feats["sma_50"].to_numpy()
    bb_pct = feats["bb_pct"].to_numpy()
    vol_chg_20 = feats["vol_chg_20"].to_numpy()

    warnings_map = {
        # Group A — blow-off / exhaustion
        "blowoff_roc20_15":   roc_20 > 15.0,
        "blowoff_bb_95":      bb_pct > 0.95,
        "blowoff_bb_100":     bb_pct > 1.00,
        "blowoff_stretched":  close > 1.20 * sma_50,
        "blowoff_accel":      roc_5 > roc_20 * 0.6,
        # Group B — momentum fading
        "fading_roc5_neg":    roc_5 < 0,
        "fading_decel":       roc_5 < roc_20 * 0.25,
        "fading_vol_col":     vol_chg_20 < -30.0,
        "fading_below_sma20": close < sma_20,
    }

    # ── Run ablations ───────────────────────────────────────────────
    print("\n" + "═" * 110)
    print("ALPHA WARNING RESEARCH — can we predict ALPHA subset underperformance?")
    print("═" * 110)
    print("ALPHA cohort = alpha_vs_industry panel percentile >= 90 at the bar")
    print(f"Total ALPHA fires: {n_alpha:,} (~10% of panel by construction)")
    print()
    print("A working warning has:")
    print("  n_warned  >= 500")
    print("  delta_pp  <= -0.5   (warned ALPHA underperforms unwarned ALPHA)")
    print("  |t_stat|  >= 3.0    (stricter: false warnings on leaders cost)")
    print()
    print("non-α Δ: same warning applied to NON-ALPHA stocks. If |non-α Δ| is")
    print("close to |α Δ|, the warning isn't ALPHA-specific — it's a broadly")
    print("harmful signal. Only ALPHA-specific warnings are worth shipping.")
    print()

    rows: list[dict] = []
    non_alpha_deltas: dict = {}
    for name, wmask in warnings_map.items():
        wmask = np.asarray(wmask, dtype=bool)
        for horizon in ("fwd_10d", "fwd_20d"):
            rows.append(ablate(feats, alpha_mask, wmask, horizon, name))
            non_alpha_deltas[(name, horizon)] = ablate_non_alpha(
                feats, alpha_mask, wmask, horizon,
            )

    print_warning_table(rows, non_alpha_deltas)

    # ── Decile reports for working warnings ─────────────────────────
    working_names = {
        r["warning"] for r in rows
        if verdict(r).endswith("working")
    }
    if working_names:
        print("\n" + "═" * 110)
        print("DECILE REPORTS FOR WORKING WARNINGS (ALPHA cohort only, fwd_20d)")
        print("═" * 110)
        feats["_ratio_close_sma50"] = close / sma_50
        feats["_ratio_roc5_roc20"] = np.where(
            np.abs(roc_20) > 0.01, roc_5 / roc_20, 0.0
        )
        feats["_diff_close_sma20_pct"] = (close - sma_20) / sma_20 * 100
        decile_features = {
            "blowoff_roc20_15":   "roc_20",
            "blowoff_bb_95":      "bb_pct",
            "blowoff_bb_100":     "bb_pct",
            "blowoff_stretched":  "_ratio_close_sma50",
            "blowoff_accel":      "_ratio_roc5_roc20",
            "fading_roc5_neg":    "roc_5",
            "fading_decel":       "_ratio_roc5_roc20",
            "fading_vol_col":     "vol_chg_20",
            "fading_below_sma20": "_diff_close_sma20_pct",
        }
        for name in sorted(working_names):
            feat = decile_features.get(name)
            if feat is None or feat not in feats.columns:
                continue
            grouped = decile_within_alpha(
                feats, alpha_mask, feat, "fwd_20d",
            )
            if len(grouped):
                print_decile_table(grouped, feat, "fwd_20d")

    # ── Persist full results ───────────────────────────────────────
    for r in rows:
        r["non_alpha_delta_pp"] = non_alpha_deltas.get(
            (r["warning"], r["horizon"]), float("nan"),
        )
    out_df = pd.DataFrame(rows)
    out_path = Path("data/alpha_warning_research.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    log.info("\nFull results written to %s", out_path)

    # ── Summary ─────────────────────────────────────────────────────
    print("\n" + "═" * 110)
    print("SUMMARY")
    print("═" * 110)
    working = [r for r in rows if verdict(r).endswith("working")]
    if not working:
        print("No warning feature earned production-quality edge on the ALPHA")
        print("cohort. Either the ALPHA signal is robust across its cohort or")
        print("the candidate warning features don't segment it meaningfully.")
        print()
        print("Next candidates worth trying: combinations (e.g. bb_pct>0.95")
        print("AND vol_chg_20<0 together), or industry-phase stratification")
        print("(ALPHA in EUPHORIA industries might degrade differently than")
        print("ALPHA in MID industries).")
    else:
        print(f"{len(working)} warning × horizon pair(s) earned edge:")
        for r in working:
            non_alpha_d = non_alpha_deltas.get(
                (r["warning"], r["horizon"]), float("nan"),
            )
            alpha_specific = (
                "ALPHA-specific" if (
                    np.isfinite(non_alpha_d)
                    and r["delta_pp"] < non_alpha_d - 0.3
                ) else "not ALPHA-specific"
            )
            print(
                f"  • {r['warning']} @ {r['horizon']}: "
                f"Δ {r['delta_pp']:+.2f}pp  t={r['t_stat']:+.2f}  "
                f"({verdict(r)}, {alpha_specific})"
            )
        print()
        print("Shipping rule: implement ALPHA-SPECIFIC warnings only. A")
        print("warning that hits non-ALPHA stocks just as hard isn't telling")
        print("us about ALPHA degradation — it's a general bearish signal and")
        print("belongs elsewhere (or nowhere).")


if __name__ == "__main__":
    main()
