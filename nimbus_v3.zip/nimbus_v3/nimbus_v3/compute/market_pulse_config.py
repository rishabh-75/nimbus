"""Single source of truth for the Market Pulse / Confluence horizons.

The whole Market Pulse tab — the ROC (strength) view, the RRG (direction)
view, and the Confluence read that gates one against the other — must agree
on *what horizon* each factor is measured over. If the ROC sub-tab showed a
60-day trend while Confluence ranked on a 20-day one, clicking from the
ranked list into the breakdown would show inconsistent numbers, and the
"strength" being gated wouldn't be the "strength" on screen.

So every consumer imports these constants rather than hard-coding its own
default. Strength and direction are decoupled on purpose — they measure
different things and want different horizons:

* **STRENGTH** (the ROC ranking window) is the rotation-speed dial. A short
  window (20d ≈ a month) catches emerging leaders quickly, at the cost of
  more whipsaw than a full-quarter trend. This is the knob to turn when you
  want faster or slower rotation.

* **DIRECTION** (the RRG RS-series window) is held longer (50d) so the RS
  series has enough runway for a stable momentum + tail-slope fit. Note the
  direction *signal* itself is governed by the RRG momentum / slope
  constants in :mod:`nimbus_v3.compute.rrg` (``MOM_LOOKBACK``, tail length),
  not this window — this only decides how much RS history feeds them, so
  direction stays responsive regardless of how the strength dial is set.

Changing rotation speed is therefore a one-line edit here that the entire
Market Pulse tab and the Confluence engine pick up together.
"""
from __future__ import annotations

#: ROC window (trading days) for the STRENGTH factor — the rotation-speed
#: dial. Shorter = faster/twitchier, longer = established-trend.
STRENGTH_LOOKBACK: int = 20

#: RS-series window (trading days) for the DIRECTION (RRG) factor. Held
#: long enough for a stable slope fit; the direction signal's actual
#: horizon is set by the RRG momentum/slope constants, not this.
RRG_LOOKBACK: int = 50

# ── Momentum-implied edge model ─────────────────────────────────────────
# The edge engine turns confluence into a per-symbol EXPECTED EXCESS EDGE
# (in horizon-period %) and a reward-to-risk rank. See
# nimbus_v3.compute.equity_edge for the full derivation. These are the
# tunables.

#: Persistence haircut κ ∈ (0,1]. Trailing relative strength massively
#: OVERSTATES expected forward return — momentum mean-reverts. κ shrinks
#: the measured RS toward zero so "expected" is a defensible label rather
#: than an extrapolation of the past. Empirical momentum persistence is
#: low, so κ is small: only ~30% of the trailing relative move is assumed
#: to carry forward. RAISE toward 1 to trust momentum more; LOWER to assume
#: more reversion. This is the single biggest dial on the edge magnitude.
EDGE_PERSISTENCE_KAPPA: float = 0.30

#: How strongly a member's own relative strength (vs its industry
#: composite) tilts its share of the industry edge. 0 = every member gets
#: the plain industry edge; 1 = full tilt (a leader gets much more, a
#: laggard much less). Kept modest — within-industry RS is noisier than the
#: industry signal, so we don't want member noise to dominate.
EDGE_MEMBER_TILT: float = 0.5

#: Floor on ATR% used as the reward-to-risk denominator, so a freakishly
#: low-vol symbol can't produce a divide-by-near-zero blow-up in the ratio.
EDGE_MIN_ATR_PCT: float = 0.5

#: Liquidity gate — an EXECUTABILITY haircut on the edge. An edge you can't
#: trade at size is a phantom: a thin name may show a huge reward-to-risk
#: that's fiction because you'd move the price entering, or couldn't exit.
#: So a thin name's edge is shrunk toward zero — the same "we don't trust
#: you can realise this" logic as the confluence trust gate, kept SEPARATE
#: from the ATR% risk denominator (ATR% is price risk; liquidity is
#: executability — conflating them would double-count).
#:
#: Unlike breadth, this reference is ABSOLUTE, not market-relative:
#: tradeability is a hard fact about rupees/day, not a ranking. A name
#: trading ₹2cr/day is thin whether or not the rest of the universe is
#: thinner. The floor/ceiling are set to discriminate ACROSS the tradeable
#: NSE mid-cap range: at ₹15cr the gate begins to bite and it reaches full
#: credit at ₹200cr. (An earlier ₹100cr floor floored most of the mid-cap
#: universe at one value, letting liquidity substitute for edge in the
#: ranking — these lower bounds keep the gate discriminating instead of
#: acting as a blanket mid-cap penalty.)
#:
#:     x    = clamp((log ADTV − log FLOOR) / (log CEIL − log FLOOR), 0, 1)
#:     gate = LIQ_FLOOR + (1 − LIQ_FLOOR) · x
#:
#: at/above the ADTV ceiling → gate 1.0 (fully tradeable, no discount);
#: at/below the floor → gate = LIQ_FLOOR (edge crushed); log-scaled between.
#: LIQ_FLOOR is harder than the breadth floor (a narrow move might broaden,
#: but an untradeable name is untradeable *now*): a fully-thin name loses
#: ~65% of its edge.
EDGE_ADTV_FLOOR: float = 1.5e8   # ₹15cr — below this, fully "thin"
EDGE_ADTV_CEILING: float = 2e9   # ₹200cr — at/above this, no discount
EDGE_LIQUIDITY_FLOOR: float = 0.35

