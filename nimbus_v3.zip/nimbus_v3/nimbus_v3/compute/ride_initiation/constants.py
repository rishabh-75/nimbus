"""Tunable constants for the ride classification engine.

All parameters live here as module-level ``Final`` values so they can
be imported anywhere without instantiating the engine, and so
``schema_hash`` can include every tuning knob in its payload for
cache invalidation.

Three logical groups:

1. **Shared filters** — used by all phases (detachment, body strength,
   slope, BBW floor, volume floors).
2. **INITIATION-specific** — freshness window, hold semantics,
   open-zone bounds.
3. **CONTINUATION-specific** — established-ride thresholds, mean-
   reversion guards, volume decay floor.
4. **RETEST-specific** — pullback window, ride-base lookback.

Aggregate group for industry/universe-level consensus is at the bottom.

Calibration TODO (deferred until phase classifier runs against full
parquet history):
  - CONT_VOL_DECAY_FLOOR (initial 0.7)
  - CONT_RIDE_BARS_MIN (initial 5)
  - CONT_RIDE_LOOKBACK (initial 10)
  - CONT_DETACHED_PCTB_MAX (initial 1.5)
  - CONT_TREND_BUFFER (initial 1.02)
  - RETEST_PULLBACK_PCTB_MIN/MAX (initial 0.7/1.05)
  - RETEST_RIDE_BARS_MIN (initial 3)
"""

from __future__ import annotations

from typing import Final


# ══════════════════════════════════════════════════════════════════════
# Required input columns
# ══════════════════════════════════════════════════════════════════════

REQUIRED_COLS: Final[tuple[str, ...]] = (
    "Open",
    "High",
    "Low",
    "Close",
    "Volume",
    "sma_20",
    "bb_20_1s_upper",
    "bb_20_1s_lower",
    "bbw_20_1s",
)


# ══════════════════════════════════════════════════════════════════════
# Shared filter constants — used across phases
# ══════════════════════════════════════════════════════════════════════

#: Detachment ceiling for %B(close). When BBW is below its 60-bar
#: median (bands compressed), ceiling relaxes to
#: DETACHED_PCTB_MAX_COMPRESSED — compressed bands legitimately produce
#: high %B on genuine breakouts (BHEL pattern).
DETACHED_PCTB_MAX: Final[float] = 1.9
DETACHED_PCTB_MAX_COMPRESSED: Final[float] = 2.0

#: SMA20 slope window (5 bars ≈ 1 week).
SMA_SLOPE_WINDOW: Final[int] = 5

#: BBW expansion lookback. Shortened from 5 → 2: on the actual
#: breakout bar, bands are just beginning to expand from a squeeze.
BBW_LOOKBACK: Final[int] = 2

#: BBW percentile floor — used by INITIATION's bbw_ok criterion.
BBW_FLOOR_WINDOW: Final[int] = 40
BBW_FLOOR_PERCENTILE: Final[float] = 0.35

#: Volume surge filter — used by INITIATION.
VOL_SURGE_WINDOW: Final[int] = 20
VOL_SURGE_RATIO: Final[float] = 1.0
VOL_PERCENTILE_WINDOW: Final[int] = 40
VOL_PERCENTILE_FLOOR: Final[float] = 0.55

#: Candle body strength. Body (|close-open|) ≥ this fraction of
#: High-Low range. Filters doji/spinning-top bars.
#: Body strength minimum for INIT/RETEST/CONT fires. Defined as
#: ``|close - open| / (high - low)``. Filters dojis and weak bars
#: where the close is closer to the wick midpoint than to either
#: extreme. Set at 0.25 — body is at least a quarter of the day's
#: range. Calibration history:
#:   - Initial 0.45: too aggressive, killed valid setups with small
#:     bodies during low-volatility regimes.
#:   - 0.35: still rejected legitimate pullback-resume bars whose
#:     body was 27-32% of range (real moves but moderate-doji-ish).
#:   - 0.25: keeps true dojis out (body < quarter of range = clear
#:     indecision) without gating moderate-body resumption bars.
BODY_STRENGTH_MIN: Final[float] = 0.25


# ══════════════════════════════════════════════════════════════════════
# INITIATION-specific
# ══════════════════════════════════════════════════════════════════════

#: Lookback for the "fresh body-above" check.
CROSS_LOOKBACK: Final[int] = 5

#: Hold duration: body-above on cross bar AND bar after.
HOLD_BARS: Final[int] = 2

#: Open's %B must be in this range — filters gap-up detached opens.
OPEN_PCTB_MIN: Final[float] = 1.0
OPEN_PCTB_MAX: Final[float] = 1.6

#: How many bars after fire the signal stays "active".
ACTIVE_WINDOW: Final[int] = 2


# ══════════════════════════════════════════════════════════════════════
# CONTINUATION-specific
# ══════════════════════════════════════════════════════════════════════

#: Established-ride threshold — at least ``CONT_RIDE_BARS_MIN`` of
#: the last ``CONT_RIDE_LOOKBACK`` bars must have had %B(close) ≥ 1.0.
#:
#: Tight 3-bar window with all 3 required body-above. CONT here means
#: "today + the two prior bars all riding the band" — a freshly-
#: established ride, not a multi-week trailing average. The previous
#: 5-of-10 formulation was too lenient: it would still fire on a
#: spotty pattern where 5 of 10 bars were body-above and 5 weren't,
#: which doesn't read as a continuation to the operator's eye.
CONT_RIDE_LOOKBACK: Final[int] = 3
CONT_RIDE_BARS_MIN: Final[int] = 3

#: Mean reversion guard — ceiling tighter than INIT because mid-rally
#: extension carries asymmetric downside.
#: CONT-specific %B(close) ceiling — band-walk symbols routinely
#: trade between 1.0 and 1.7 during clean uptrends. The 1.5 cap
#: paired with the previous 5-of-10 lookback was reasonable
#: ("don't enter late on an extended ride") but with the new
#: 3-bar all-body-above lookback CONT only fires on freshly-
#: confirmed continuations, so the late-entry concern is already
#: baked in. 1.7 lets clean band-walks through; the general
#: ``DETACHED_PCTB_MAX`` (1.9) still backstops via
#: ``crit_not_detached_today``, so genuinely extended bars (%B≥1.9)
#: are still gated regardless of phase.
CONT_DETACHED_PCTB_MAX: Final[float] = 1.7

#: Trend buffer — close must be at least this multiple of SMA20.
#: Filters cases where %B>1 only because bands collapsed inward.
CONT_TREND_BUFFER: Final[float] = 1.02

#: Volume not collapsing — recent 20-bar avg must be ≥ this fraction
#: of older 20-bar avg (10 bars earlier). Continuations naturally
#: see fading volume; only collapse-rate is a problem.
CONT_VOL_DECAY_FLOOR: Final[float] = 0.7

#: Active window for CONTINUATION fires — single bar only. Lower
#: conviction than INIT, so don't propagate forward.
CONT_ACTIVE_WINDOW: Final[int] = 1


# ══════════════════════════════════════════════════════════════════════
# RETEST-specific
# ══════════════════════════════════════════════════════════════════════

#: Window over which a "qualified prior ride" must have existed.
RETEST_RIDE_LOOKBACK: Final[int] = 15

#: Minimum body-above bars within RETEST_RIDE_LOOKBACK to count as
#: a real prior ride (not noise).
RETEST_RIDE_BARS_MIN: Final[int] = 3

#: Maximum bars in pullback window before T-1.
RETEST_PULLBACK_MAX_BARS: Final[int] = 5

#: %B(close) range during the pullback. Must be inside the upper
#: half of the band but not crashed through SMA20.
RETEST_PULLBACK_PCTB_MIN: Final[float] = 0.7
RETEST_PULLBACK_PCTB_MAX: Final[float] = 1.05

#: Active window for RETEST — same as INIT.
RETEST_ACTIVE_WINDOW: Final[int] = 2


# ══════════════════════════════════════════════════════════════════════
# Composite score weights — must sum to 1.0
# ══════════════════════════════════════════════════════════════════════

SCORE_WEIGHT_FRESHNESS: Final[float] = 0.30
SCORE_WEIGHT_VOLUME: Final[float] = 0.25
SCORE_WEIGHT_BBW: Final[float] = 0.20
SCORE_WEIGHT_MOMENTUM: Final[float] = 0.15
SCORE_WEIGHT_BODY: Final[float] = 0.10


# ══════════════════════════════════════════════════════════════════════
# Composite score discount factors — applied multiplicatively after
# the weighted-conviction sum. They model **tradeability** (can the
# operator act on this) rather than **conviction** (how strong is
# the signal). The 5 weighted components above measure conviction;
# extension and liquidity are discount factors that push extended
# / illiquid setups below cleaner peers in ranking, without zeroing
# them out entirely.
# ══════════════════════════════════════════════════════════════════════

#: %B above which the extension penalty kicks in. Below this, the
#: signal is "comfortably inside the ride zone"; above, the
#: discount ramps up to the floor over the band-walk envelope.
#:
#: 1.4 was chosen as the inflection because:
#:   - %B 1.0–1.4 covers ~80% of clean band-walk bars in the
#:     SUNPHARMA / CIPLA reference set.
#:   - %B 1.4–1.7 is "extended but tradeable" territory — penalty
#:     should be felt, not crushing.
#:   - The CONT entry ceiling (``CONT_DETACHED_PCTB_MAX``) is 1.7;
#:     the penalty hits its floor exactly at that threshold, so a
#:     bar that *just* fired CONT at the limit is at the bottom of
#:     its tradeability score even though phase still says CONT.
SCORE_EXTENSION_PCTB_MIN: Final[float] = 1.4

#: %B at which the extension penalty hits its floor. Set equal to
#: ``CONT_DETACHED_PCTB_MAX`` (1.7) so the penalty curve and the
#: phase-firing ceiling agree on what counts as fully extended.
SCORE_EXTENSION_PCTB_MAX: Final[float] = 1.7

#: Minimum extension penalty factor. A bar at %B 1.7 retains 55%
#: of its raw score, not zero — the strategy didn't gate it out
#: (we're inside CONT_DETACHED_PCTB_MAX), so neither should the
#: score. The penalty floor preserves the signal as a low-rank
#: visible setup rather than hiding it.
SCORE_EXTENSION_PENALTY_FLOOR: Final[float] = 0.55

#: ADTV (₹) at and above which the liquidity penalty is fully
#: relaxed (penalty = 1.0). NSE large/mega-caps. Operators can
#: enter / exit these in size without slippage worth modelling.
SCORE_LIQUIDITY_ADTV_FULL: Final[float] = 1_000_000_000.0    # ₹1B

#: ADTV (₹) above which the liquidity penalty starts decreasing
#: from full (penalty = 0.85). Mid-cap territory — typical NSE
#: name with ₹250M turnover trades cleanly at retail size but
#: institutional flow shows up. Penalty between this and
#: ``SCORE_LIQUIDITY_ADTV_FULL`` ramps linearly 0.85 → 1.0.
SCORE_LIQUIDITY_ADTV_MID: Final[float] = 250_000_000.0    # ₹250M

#: ADTV (₹) above which the small-cap penalty applies (between
#: ``SCORE_LIQUIDITY_ADTV_SMALL`` and ``SCORE_LIQUIDITY_ADTV_MID``
#: the penalty ramps linearly 0.6 → 0.85).
SCORE_LIQUIDITY_ADTV_SMALL: Final[float] = 50_000_000.0    # ₹50M

#: Liquidity penalty floor for ADTV at or below
#: ``SCORE_LIQUIDITY_ADTV_SMALL``. Micro-caps retain 60% of their
#: raw conviction — the signal might be real but tradeability is
#: poor enough to dock it heavily.
SCORE_LIQUIDITY_PENALTY_FLOOR: Final[float] = 0.6


# ══════════════════════════════════════════════════════════════════════
# Aggregate / synthetic-index minimum members
# ══════════════════════════════════════════════════════════════════════

#: Industry classification falls back to ``RideResult.empty`` when
#: fewer than this many members can contribute valid ADTV weights.
#: 3 is the minimum where a weighted aggregate is statistically
#: meaningful — below that the synthetic is dominated by one symbol.
INDUSTRY_MIN_MEMBERS: Final[int] = 3


def schema_hash() -> str:
    """8-char hash of all tunable constants. Downstream caches use this
    to invalidate when any parameter changes.
    """
    import hashlib

    payload = (
        f"cross_lookback={CROSS_LOOKBACK}|"
        f"hold_bars={HOLD_BARS}|"
        f"detached_pctb_max={DETACHED_PCTB_MAX}|"
        f"detached_pctb_max_compressed={DETACHED_PCTB_MAX_COMPRESSED}|"
        f"open_pctb_min={OPEN_PCTB_MIN}|"
        f"open_pctb_max={OPEN_PCTB_MAX}|"
        f"sma_slope_window={SMA_SLOPE_WINDOW}|"
        f"bbw_lookback={BBW_LOOKBACK}|"
        f"bbw_floor_window={BBW_FLOOR_WINDOW}|"
        f"bbw_floor_percentile={BBW_FLOOR_PERCENTILE}|"
        f"vol_surge_window={VOL_SURGE_WINDOW}|"
        f"vol_surge_ratio={VOL_SURGE_RATIO}|"
        f"vol_percentile_window={VOL_PERCENTILE_WINDOW}|"
        f"vol_percentile_floor={VOL_PERCENTILE_FLOOR}|"
        f"body_strength_min={BODY_STRENGTH_MIN}|"
        f"active_window={ACTIVE_WINDOW}|"
        f"cont_ride_lookback={CONT_RIDE_LOOKBACK}|"
        f"cont_ride_bars_min={CONT_RIDE_BARS_MIN}|"
        f"cont_detached_pctb_max={CONT_DETACHED_PCTB_MAX}|"
        f"cont_trend_buffer={CONT_TREND_BUFFER}|"
        f"cont_vol_decay_floor={CONT_VOL_DECAY_FLOOR}|"
        f"cont_active_window={CONT_ACTIVE_WINDOW}|"
        f"retest_ride_lookback={RETEST_RIDE_LOOKBACK}|"
        f"retest_ride_bars_min={RETEST_RIDE_BARS_MIN}|"
        f"retest_pullback_max_bars={RETEST_PULLBACK_MAX_BARS}|"
        f"retest_pullback_pctb_min={RETEST_PULLBACK_PCTB_MIN}|"
        f"retest_pullback_pctb_max={RETEST_PULLBACK_PCTB_MAX}|"
        f"retest_active_window={RETEST_ACTIVE_WINDOW}|"
        f"score_w_fresh={SCORE_WEIGHT_FRESHNESS}|"
        f"score_w_vol={SCORE_WEIGHT_VOLUME}|"
        f"score_w_bbw={SCORE_WEIGHT_BBW}|"
        f"score_w_mom={SCORE_WEIGHT_MOMENTUM}|"
        f"score_w_body={SCORE_WEIGHT_BODY}|"
        f"score_ext_pctb_min={SCORE_EXTENSION_PCTB_MIN}|"
        f"score_ext_pctb_max={SCORE_EXTENSION_PCTB_MAX}|"
        f"score_ext_floor={SCORE_EXTENSION_PENALTY_FLOOR}|"
        f"score_liq_full={SCORE_LIQUIDITY_ADTV_FULL}|"
        f"score_liq_mid={SCORE_LIQUIDITY_ADTV_MID}|"
        f"score_liq_small={SCORE_LIQUIDITY_ADTV_SMALL}|"
        f"score_liq_floor={SCORE_LIQUIDITY_PENALTY_FLOOR}|"
        f"industry_min_members={INDUSTRY_MIN_MEMBERS}"
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:8]
