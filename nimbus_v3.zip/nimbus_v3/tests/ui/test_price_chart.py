"""Tests for PriceChart widget — price + volume + options levels."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.core.context import OptionsContext
from nimbus_v3.core.types import ExpiryRisk
from nimbus_v3.ui.widgets.price_chart import PriceChart


_ASOF = pd.Timestamp("2024-05-15")


def _synthetic_ohlcv(n: int = 60, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2024-01-01", periods=n)
    closes = 100.0 + rng.normal(0, 1.5, n).cumsum()
    df = pd.DataFrame({
        "Open": closes + rng.normal(0, 0.3, n),
        "High": closes + np.abs(rng.normal(0.5, 0.2, n)),
        "Low": closes - np.abs(rng.normal(0.5, 0.2, n)),
        "Close": closes,
        "Volume": rng.integers(1e5, 1e6, n).astype(float),
    }, index=idx)
    return df


def _options_with_levels(
    spot: float = 100.0,
    support: float | None = 95.0,
    resistance: float | None = 105.0,
    max_pain: float | None = 100.0,
    hvl: float | None = 102.0,
) -> OptionsContext:
    return OptionsContext(
        asof_date=_ASOF, symbol="TEST",
        spot=spot, dte=7,
        max_pain=max_pain, support_wall=support, resistance_wall=resistance,
        pct_to_support=None, pct_to_resistance=None,
        net_gex=None, hvl=hvl, gex_regime=None,
        pcr_oi=None, iv_atm=None, ivr=None,
        expiry_risk=ExpiryRisk.LOW,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Construction
# ══════════════════════════════════════════════════════════════════════════════

def test_chart_constructs_empty(qapp) -> None:   # noqa: ARG001
    chart = PriceChart()
    # Placeholder is present initially.
    assert chart._current_df is None


def test_chart_accepts_ohlcv_dataframe(qapp) -> None:    # noqa: ARG001
    chart = PriceChart()
    df = _synthetic_ohlcv()
    chart.set_data(df)
    assert chart._current_df is not None
    assert len(chart._current_df) == 60


def test_chart_clears_on_none(qapp) -> None:    # noqa: ARG001
    chart = PriceChart()
    chart.set_data(_synthetic_ohlcv())
    chart.set_data(None)
    assert chart._current_df is None


def test_chart_respects_trailing_bars_limit(qapp) -> None:    # noqa: ARG001
    chart = PriceChart()
    df = _synthetic_ohlcv(n=500)   # longer than DEFAULT_BARS=120
    chart.set_data(df)
    assert len(chart._current_df) == PriceChart.DEFAULT_BARS


def test_chart_respects_custom_bars_argument(qapp) -> None:   # noqa: ARG001
    chart = PriceChart()
    df = _synthetic_ohlcv(n=500)
    chart.set_data(df, bars=30)
    assert len(chart._current_df) == 30


# ══════════════════════════════════════════════════════════════════════════════
# Empty / malformed input
# ══════════════════════════════════════════════════════════════════════════════

def test_chart_handles_empty_dataframe(qapp) -> None:    # noqa: ARG001
    chart = PriceChart()
    chart.set_data(pd.DataFrame())
    assert chart._current_df is None


def test_chart_silently_ignores_missing_columns(qapp) -> None:    # noqa: ARG001
    chart = PriceChart()
    # DataFrame with only Close — no candles can be drawn.
    bad = pd.DataFrame(
        {"Close": np.arange(10)},
        index=pd.bdate_range("2024-01-01", periods=10),
    )
    chart.set_data(bad)
    assert chart._current_df is None    # didn't bind malformed data


# ══════════════════════════════════════════════════════════════════════════════
# Options levels
# ══════════════════════════════════════════════════════════════════════════════

def test_options_levels_drawn_when_supplied(qapp) -> None:     # noqa: ARG001
    chart = PriceChart()
    df = _synthetic_ohlcv()
    opts = _options_with_levels()
    chart.set_data(df, options=opts)
    # 4 level fields supplied → 4 InfiniteLine items added.
    assert len(chart._level_lines) == 4


def test_partial_options_levels_ok(qapp) -> None:     # noqa: ARG001
    chart = PriceChart()
    df = _synthetic_ohlcv()
    # Only support + resistance present; max_pain and hvl missing.
    opts = _options_with_levels(max_pain=None, hvl=None)
    chart.set_data(df, options=opts)
    assert len(chart._level_lines) == 2


def test_no_options_no_levels(qapp) -> None:      # noqa: ARG001
    chart = PriceChart()
    chart.set_data(_synthetic_ohlcv(), options=None)
    assert chart._level_lines == []


# ══════════════════════════════════════════════════════════════════════════════
# Rebinding
# ══════════════════════════════════════════════════════════════════════════════

def test_rebinding_clears_previous_levels(qapp) -> None:     # noqa: ARG001
    chart = PriceChart()
    opts_a = _options_with_levels()
    chart.set_data(_synthetic_ohlcv(), options=opts_a)
    assert len(chart._level_lines) == 4
    # Second call with no options — levels from first binding must go.
    chart.set_data(_synthetic_ohlcv(seed=1), options=None)
    assert chart._level_lines == []


def test_clear_method_resets_state(qapp) -> None:     # noqa: ARG001
    chart = PriceChart()
    chart.set_data(_synthetic_ohlcv(), options=_options_with_levels())
    chart.clear()
    assert chart._current_df is None
    assert chart._level_lines == []
