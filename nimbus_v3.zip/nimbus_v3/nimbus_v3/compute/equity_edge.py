"""Momentum-implied expected excess edge, derived from confluence.

This turns the Confluence read into two per-symbol numbers:

* **expected excess edge** (μ̂, in horizon-period %): an estimate of a
  symbol's return *in excess of the benchmark* over the strength horizon,
  implied by momentum confluence.
* **reward-to-risk** (μ̂ / risk): a Sharpe-like rotation rank — expected
  edge per unit of realised volatility.

**What this is NOT.** This is *not* an equity risk premium in the
valuation sense. A true ERP is a forward, cash-flow / discount-rate
quantity (dividend yield + growth − risk-free, or an implied premium from
prices and earnings). Confluence contains no valuation data — only
momentum, direction, seasonality and breadth. So the honest object here is
a *momentum-implied* expected edge, not a risk premium. The label is chosen
to match the math.

── Derivation ──────────────────────────────────────────────────────────
Confluence scores INDUSTRIES, so a symbol's edge is its industry's edge,
adjusted for where the symbol sits within its industry:

    industry_edge   = κ · RS_excess · trust
    member_shift    = κ · tilt · (member_RS − industry_RS) · trust
    μ̂(symbol)       = (industry_edge + member_shift) · liquidity_gate
    reward_to_risk  = μ̂(symbol) / max(ATR%, floor)

where

* ``RS_excess`` — the industry composite's return over the horizon MINUS
  the benchmark's return over the same horizon (a real excess-return
  number, the magnitude anchor).
* ``trust`` — the confluence GATE PRODUCT (direction × seasonal × breadth
  gates), i.e. ``ConfluenceRow.confidence``. A strong-but-narrow-and-fading
  industry has high RS_excess but low trust, so its edge is shrunk toward
  zero: "the trailing outperformance is real, but we don't expect it to
  persist."
* ``κ`` (kappa) — the persistence haircut. Trailing momentum mean-reverts
  hard, so raw RS massively overstates forward return; κ (well under 1)
  shrinks it so calling the output "expected" is defensible rather than a
  naive extrapolation. This is the single biggest dial and it is what makes
  the "expected" label honest.
* ``member_shift`` — an ADDITIVE adjustment by the symbol's own strength
  relative to its industry composite, so a leader within the group is
  shifted up and a laggard down. Additive (not a multiplier on the
  industry edge) so a strong member in a WEAK industry is made *less bad*,
  not amplified downward — the member's own strength is independent
  information that should move its edge the same direction regardless of
  the industry's sign. Scaled by the same κ and trust; the tilt strength
  is kept modest because within-industry RS is noisier than the industry
  signal.
* risk denominator — the symbol's ATR% (realised short-term vol), floored
  so a freakishly-low-vol name can't blow up the ratio.
* ``liquidity_gate`` — an executability haircut ∈ [floor, 1]. An edge you
  can't trade at size is a phantom, so a thin name (low ADTV) has its edge
  shrunk toward the floor. ABSOLUTE (log-ADTV clamped between the
  Dashboard's floor/ceiling), because tradeability is a hard fact about
  rupees/day, not a ranking. Kept separate from the ATR% denominator: ATR%
  is price risk, liquidity is executability — conflating them double-counts.

All tunables live in :mod:`nimbus_v3.compute.market_pulse_config`.

The engine is stateless and returns a frozen result; it consumes the
already-computed confluence / rotation / rrg outputs plus the panel — it
recomputes none of them.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import log

import pandas as pd

from nimbus_v3.compute.confluence import ConfluenceResult
from nimbus_v3.compute.constituent_features import (
    extract_constituent_features,
)
from nimbus_v3.compute.indicators import adtv_latest
from nimbus_v3.compute.industry_rotation import RotationResult
from nimbus_v3.compute.market_pulse_common import (
    industry_rs_excess,
    window_return_pct,
)
from nimbus_v3.compute.market_pulse_config import (
    EDGE_ADTV_CEILING,
    EDGE_ADTV_FLOOR,
    EDGE_LIQUIDITY_FLOOR,
    EDGE_MEMBER_TILT,
    EDGE_MIN_ATR_PCT,
    EDGE_PERSISTENCE_KAPPA,
    STRENGTH_LOOKBACK,
)


@dataclass(frozen=True)
class SymbolEdge:
    """One symbol's momentum-implied edge read — fully auditable."""
    symbol: str
    industry: str
    #: Expected excess edge over the benchmark, in horizon-period % (the
    #: strength lookback window). Persistence- and trust-shrunk.
    expected_edge: float
    #: Reward-to-risk: expected_edge / ATR%. Sharpe-like rotation rank.
    reward_to_risk: float
    #: The pieces, surfaced for inspection.
    industry_rs_excess: float   # industry composite return − benchmark, %
    trust: float                # confluence gate product 0..1
    member_shift: float         # additive within-industry adjustment, %
    atr_pct: float              # risk denominator used
    adtv: float                 # avg daily traded value (₹), raw
    liquidity_gate: float       # executability haircut applied, 0..1
    chg_1d: float = float("nan")    # latest 1-bar % change
    chg_5d: float = float("nan")    # 5-bar % change
    chg_10d: float = float("nan")   # 10-bar % change
    vol_ratio: float = float("nan")  # latest volume / 20-bar mean volume
    above: bool = False              # body-above-band flag
    streak: int = 0                  # trailing body-above run length


@dataclass(frozen=True)
class EdgeResult:
    """All symbols' edges, ranked by reward-to-risk descending."""
    rows: tuple[SymbolEdge, ...]
    horizon_days: int
    kappa: float

    @property
    def has_data(self) -> bool:
        return len(self.rows) > 0


def _liquidity_gate(
    adtv: float,
    floor_adtv: float,
    ceil_adtv: float,
    gate_floor: float,
) -> float:
    """Executability haircut ∈ [gate_floor, 1] from a symbol's ADTV.

    Log-scaled between an absolute floor and ceiling (tradeability is an
    absolute fact, not a ranking): at/above the ADTV ceiling → 1.0 (no
    discount); at/below the floor → gate_floor (edge crushed). NaN ADTV is
    treated as fully thin (gate_floor) — we can't confirm it's tradeable,
    so we don't give it the benefit of the doubt.
    """
    if adtv != adtv or adtv <= 0:
        return gate_floor
    lo, hi = log(floor_adtv), log(ceil_adtv)
    x = (log(adtv) - lo) / (hi - lo) if hi > lo else 1.0
    x = max(0.0, min(1.0, x))
    return gate_floor + (1.0 - gate_floor) * x


def compute_equity_edge(
    confluence: ConfluenceResult,
    rotation: RotationResult,
    members_by_industry: dict[str, list],
    panel: dict[str, pd.DataFrame],
    benchmark_close: pd.Series | None = None,
    *,
    lookback: int = STRENGTH_LOOKBACK,
    kappa: float = EDGE_PERSISTENCE_KAPPA,
    member_tilt: float = EDGE_MEMBER_TILT,
    min_atr_pct: float = EDGE_MIN_ATR_PCT,
    adtv_floor: float = EDGE_ADTV_FLOOR,
    adtv_ceiling: float = EDGE_ADTV_CEILING,
    liquidity_floor: float = EDGE_LIQUIDITY_FLOOR,
) -> EdgeResult:
    """Derive per-symbol momentum-implied expected edge + reward-to-risk.

    Args:
        confluence: the confluence result (its ``confidence`` field is the
            gate product used as ``trust``).
        rotation: the rotation result (industry composite ``roc`` is the
            RS magnitude anchor, over the same ``lookback``).
        members_by_industry: industry → member symbols.
        panel: enriched OHLCV+indicator frames (needs ``Close`` and
            ``atr_14_pct``).
        benchmark_close: benchmark close series; its window return is
            subtracted to make RS an EXCESS return. If None, the excess is
            taken vs 0 (absolute return) — less correct, so pass it.
        lookback: horizon (days) the edge is expressed over; matches the
            strength window so RS_excess and the edge share a horizon.
        kappa: persistence haircut (see module docstring).
        member_tilt: within-industry RS tilt strength.
        min_atr_pct: floor on the risk denominator.

    Returns:
        An :class:`EdgeResult`, symbols ranked by reward-to-risk desc.
    """
    # Trust (gate product) and industry composite return, keyed by industry.
    trust_by_ind = {r.industry: r.confidence for r in confluence.rows}
    roc_by_ind = {r.industry: r.roc for r in rotation.industries}

    # Benchmark-relative RS per industry — the SAME shared definition the
    # Confluence strength factor uses, so the two tabs agree.
    bench_ret = (window_return_pct(benchmark_close, lookback)
                 if benchmark_close is not None else 0.0)
    rs_excess_by_ind = industry_rs_excess(roc_by_ind, bench_ret)

    rows: list[SymbolEdge] = []
    for industry, members in members_by_industry.items():
        trust = trust_by_ind.get(industry, float("nan"))
        ind_roc = roc_by_ind.get(industry, float("nan"))
        # An industry must have BOTH a confluence trust and a composite
        # return to carry an edge — otherwise it isn't a ranked candidate.
        if trust != trust or ind_roc != ind_roc:
            continue

        rs_excess = rs_excess_by_ind.get(industry, float("nan"))
        industry_edge = kappa * rs_excess * trust

        for sym in members:
            df = panel.get(sym)
            if df is None or df.empty or "Close" not in df.columns:
                continue
            sym_ret = window_return_pct(df["Close"], lookback)
            if sym_ret != sym_ret:
                continue

            # Member shift: the symbol's own strength relative to its
            # industry composite, as an ADDITIVE adjustment. A member
            # outperforming its group is a better prospect than one
            # lagging it — regardless of whether the industry itself is hot
            # or cold — so this must shift the edge in a consistent
            # direction (up for leaders, down for laggards), not multiply
            # the industry edge (which would wrongly amplify a strong
            # member DOWNWARD inside a weak industry). Scaled by the same
            # κ and trust as the industry edge, since within-group
            # dispersion deserves no more trust than the industry signal.
            member_excess = sym_ret - ind_roc
            member_shift = kappa * member_tilt * member_excess * trust

            raw_edge = industry_edge + member_shift

            # Per-symbol display features (adtv, chg 1/5/10d, vol ratio,
            # body-above flag, streak) come from the SHARED constituent-
            # feature extractor — the same one the Dashboard tables use — so
            # the Edge tab and Dashboard never disagree on a symbol's numbers
            # and nothing is recomputed in two places. ADTV from here also
            # feeds the liquidity gate.
            feats = extract_constituent_features(sym, df)
            adtv = feats.adtv if feats is not None else adtv_latest(df)

            # Liquidity gate: an edge you can't trade at size is a phantom.
            # Shrink the edge toward zero for thin names (executability
            # haircut) — kept separate from the ATR% denominator, which is
            # price risk, not tradeability.
            liq_gate = _liquidity_gate(
                adtv, adtv_floor, adtv_ceiling, liquidity_floor)
            edge = raw_edge * liq_gate

            atr = float("nan")
            if "atr_14_pct" in df.columns:
                a = df["atr_14_pct"].dropna()
                if a.shape[0]:
                    atr = float(a.iloc[-1])
            atr_used = max(min_atr_pct, atr) if atr == atr else min_atr_pct
            rr = edge / atr_used if atr_used > 0 else float("nan")

            rows.append(SymbolEdge(
                symbol=sym,
                industry=industry,
                expected_edge=edge,
                reward_to_risk=rr,
                industry_rs_excess=rs_excess,
                trust=trust,
                member_shift=member_shift,
                atr_pct=atr_used,
                adtv=adtv,
                liquidity_gate=liq_gate,
                chg_1d=feats.chg_1d if feats else float("nan"),
                chg_5d=feats.chg_5d if feats else float("nan"),
                chg_10d=feats.chg_10d if feats else float("nan"),
                vol_ratio=feats.vol_ratio if feats else float("nan"),
                above=feats.above if feats else False,
                streak=feats.streak if feats else 0,
            ))

    # Rank by reward-to-risk desc; NaN sinks. Ties break by symbol for
    # deterministic ordering.
    rows.sort(key=lambda r: (
        r.reward_to_risk != r.reward_to_risk,
        -(r.reward_to_risk if r.reward_to_risk == r.reward_to_risk else 0.0),
        r.symbol))

    return EdgeResult(
        rows=tuple(rows),
        horizon_days=lookback,
        kappa=kappa,
    )
