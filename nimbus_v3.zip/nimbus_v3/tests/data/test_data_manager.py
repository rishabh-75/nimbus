"""Tests for ``nimbus_v3.data.data_manager`` — wiring contract.

The single behaviour pinned here:

  - When :meth:`DataManager.request_price` is called with
    ``force_refresh=True``, the spawned :class:`PriceWorker`
    calls ``PriceLoader.load(symbol, force_refresh=True)``.

  - When called without the flag (or with ``False``), the worker
    calls ``PriceLoader.load(symbol, force_refresh=False)``.

This pins the wiring that the sidebar REFRESH button relies on.
The bug we're guarding against: dropping the kwarg somewhere
along ``MainWindow._on_sidebar_refresh`` → ``_load_symbol`` →
``DataManager.request_price`` → ``PriceWorker.__init__`` →
``PriceWorker._fetch_equity`` → ``PriceLoader.load``. A break
anywhere along that chain silently turns REFRESH into a no-op,
which is exactly what happened previously.
"""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pandas as pd
import pytest
from PyQt6.QtCore import QCoreApplication

from nimbus_v3.data.data_manager import DataManager, PriceWorker


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════


@pytest.fixture(scope="module")
def qapp():
    """Qt needs a QCoreApplication for QThread signalling to work,
    even in offscreen test mode. Reuse one across tests."""
    app = QCoreApplication.instance() or QCoreApplication([])
    yield app


def _fake_df() -> pd.DataFrame:
    """Minimal valid OHLCV frame so PriceWorker.finished fires
    rather than failed."""
    idx = pd.bdate_range("2024-01-01", periods=5)
    return pd.DataFrame({
        "Open":   [100.0] * 5,
        "High":   [101.0] * 5,
        "Low":    [99.0] * 5,
        "Close":  [100.5] * 5,
        "Volume": [1_000_000.0] * 5,
    }, index=idx)


# ══════════════════════════════════════════════════════════════════════════════
# PriceWorker — the unit at the bottom of the chain
# ══════════════════════════════════════════════════════════════════════════════


class TestPriceWorkerForceRefresh:
    """Verify PriceWorker passes ``force_refresh`` to PriceLoader.

    We call ``run`` synchronously rather than via the QThread's
    ``start`` — easier to inspect, and the threading concern is
    orthogonal to the wiring concern.
    """

    def test_force_refresh_true_propagates_to_loader(self, qapp):    # noqa: ARG002
        loader = MagicMock()
        loader.load.return_value = _fake_df()
        w = PriceWorker("RELIANCE", loader, force_refresh=True)
        # Capture the signal emission rather than waiting on the thread.
        captured: list = []
        w.finished.connect(captured.append)
        w.run()    # synchronous run on the test thread

        loader.load.assert_called_once_with(
            "RELIANCE", force_refresh=True,
        )
        assert len(captured) == 1, "finished should have emitted exactly once"

    def test_force_refresh_default_is_false(self, qapp):    # noqa: ARG002
        """Default ``force_refresh=False`` — the standard symbol
        change path through the sidebar combo (not the REFRESH
        button) should NOT bypass cache."""
        loader = MagicMock()
        loader.load.return_value = _fake_df()
        w = PriceWorker("RELIANCE", loader)
        captured: list = []
        w.finished.connect(captured.append)
        w.run()

        loader.load.assert_called_once_with(
            "RELIANCE", force_refresh=False,
        )

    def test_force_refresh_false_explicit(self, qapp):    # noqa: ARG002
        loader = MagicMock()
        loader.load.return_value = _fake_df()
        w = PriceWorker("RELIANCE", loader, force_refresh=False)
        w.run()
        loader.load.assert_called_once_with(
            "RELIANCE", force_refresh=False,
        )


# ══════════════════════════════════════════════════════════════════════════════
# DataManager.request_price — the wiring above PriceWorker
# ══════════════════════════════════════════════════════════════════════════════


class TestDataManagerRequestPrice:
    """Spy on PriceWorker construction to verify
    ``DataManager.request_price`` forwards ``force_refresh``.

    We patch ``PriceWorker`` at the module level so the spawned
    worker doesn't actually start a thread.
    """

    def test_force_refresh_true_passed_to_worker(
        self, qapp, monkeypatch,    # noqa: ARG002
    ):
        constructed: list[dict] = []

        class FakeWorker:
            """Records constructor kwargs; emits nothing."""
            finished = MagicMock()
            failed = MagicMock()

            def __init__(self, symbol, loader, **kwargs):
                constructed.append({"symbol": symbol, **kwargs})

            def start(self):
                pass

        monkeypatch.setattr(
            "nimbus_v3.data.data_manager.PriceWorker", FakeWorker,
        )

        dm = DataManager(
            price_loader=MagicMock(),
            options_loader=MagicMock(),
        )
        dm.request_price("RELIANCE", force_refresh=True)

        assert len(constructed) == 1
        assert constructed[0]["symbol"] == "RELIANCE"
        assert constructed[0]["force_refresh"] is True

    def test_force_refresh_default_false(
        self, qapp, monkeypatch,    # noqa: ARG002
    ):
        constructed: list[dict] = []

        class FakeWorker:
            finished = MagicMock()
            failed = MagicMock()

            def __init__(self, symbol, loader, **kwargs):
                constructed.append({"symbol": symbol, **kwargs})

            def start(self):
                pass

        monkeypatch.setattr(
            "nimbus_v3.data.data_manager.PriceWorker", FakeWorker,
        )

        dm = DataManager(
            price_loader=MagicMock(),
            options_loader=MagicMock(),
        )
        dm.request_price("RELIANCE")    # no force_refresh

        assert constructed[0]["force_refresh"] is False
