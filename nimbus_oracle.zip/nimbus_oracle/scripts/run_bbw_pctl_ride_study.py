#!/usr/bin/env python3
"""
scripts/run_bbw_pctl_ride_study.py — BBW percentile predictive power for BB Ride.

HYPOTHESIS:
  The MR study showed compression HURTS mean reversion (compressed bottom decile
  underperformed mid by 8.6pp on win rate). Ride is the OPPOSITE trade — it bets
  on volatility persistence rather than reversion. So expansion should HELP ride.

  If a stock enters a ride setup (price tagging upper band) when BBW is already
  in the top decile of its own history, that's a regime where vol is genuinely
  expanding — the ride has fuel. Compressed BBW = false breakout, fizzles.

DESIGN:
  For each ride trade in bb_ride_trades.csv:
    1. Load same per-symbol price cache from MR study (data/bbw_pctl_cache/)
    2. Compute BBW percentile at entry across windows 40/60/80/100d
    3. Bucket trade outcome by (BBW pctl, VIX regime, window length)
  Same analysis matrix as MR study — but expecting OPPOSITE directional pattern.

DECISION CRITERIA:
  Add as ride grade factor IF:
    - Top decile (expanded) shows >= 5pp win rate edge over middle
    - OR bottom decile (compressed) shows >= 5pp NEGATIVE edge (hard filter)
    - Cohen's d >= 0.25 in at least one window
    - Effect persists across VIX regimes

Usage:
    python3 scripts/run_bbw_pctl_ride_study.py
    python3 scripts/run_bbw_pctl_ride_study.py --windows 40,60,80
"""
import argparse
import datetime
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

# Reuse the MR study's helpers — they're identical
from scripts.run_bbw_pctl_study import (
    fetch_price_history_range,
    compute_bbw,
    compute_bbw_pctl,
    cohens_d,
)

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("bbw_pctl_ride_study")


# ══════════════════════════════════════════════════════════════════════════════
# DATA LOADING
# ══════════════════════════════════════════════════════════════════════════════

def load_ride_trades(path: str = "data/backtest_results/bb_ride_trades.csv") -> pd.DataFrame:
    """Load BB Ride OOS trade data."""
    if not os.path.exists(path):
        logger.error(f"Ride trades CSV not found at {path}")
        logger.error("Run: python3 scripts/run_bb_ride_backtest.py --export")
        sys.exit(1)

    df = pd.read_csv(path)
    df["entry_date"] = pd.to_datetime(df["entry_date"])

    # win and vix_regime are already in the ride backtest output
    if "win" not in df.columns:
        df["win"] = df["pnl_pct"] > 0

    logger.info(f"Loaded {len(df)} ride trades from {path}")
    logger.info(f"  Date range: {df['entry_date'].min().date()} to {df['entry_date'].max().date()}")
    logger.info(f"  Unique symbols: {df['symbol'].nunique()}")
    logger.info(f"  Overall win rate: {df['win'].mean()*100:.1f}%")
    logger.info(f"  Overall avg PnL: {df['pnl_pct'].mean():+.2f}%")
    return df


# ══════════════════════════════════════════════════════════════════════════════
# ENRICHMENT
# ══════════════════════════════════════════════════════════════════════════════

def enrich_ride_trades(
    trades: pd.DataFrame,
    windows: list[int],
    cache_dir: str = "data/bbw_pctl_cache",
) -> pd.DataFrame:
    """
    For each ride trade, compute BBW percentile at entry across multiple windows.
    Reuses the MR study's per-symbol parquet cache (same source data).
    """
    os.makedirs(cache_dir, exist_ok=True)
    cache: dict[str, dict] = {}
    skipped = 0
    enriched_rows = []
    t0 = time.time()

    symbols = sorted(trades["symbol"].unique())
    logger.info(f"Enriching {len(trades)} trades across {len(symbols)} symbols")
    logger.info(f"Windows: {windows}")

    earliest = trades["entry_date"].min() - pd.Timedelta(days=max(windows) + 30)
    latest = trades["entry_date"].max() + pd.Timedelta(days=5)
    logger.info(f"  Fetch range: {earliest.date()} → {latest.date()}")

    for i, sym in enumerate(symbols):
        if i % 25 == 0:
            elapsed = time.time() - t0
            rate = i / elapsed if elapsed > 0 else 0
            eta = (len(symbols) - i) / rate if rate > 0 else 0
            logger.info(f"  [{i}/{len(symbols)}] {sym} (eta {eta:.0f}s)")

        cache_path = os.path.join(cache_dir, f"{sym}.parquet")
        df = pd.DataFrame()

        if os.path.exists(cache_path):
            try:
                df = pd.read_parquet(cache_path)
                # Validate cache covers the full range we need
                if df.empty or df.index.min() > earliest or df.index.max() < latest - pd.Timedelta(days=5):
                    df = pd.DataFrame()
            except Exception:
                df = pd.DataFrame()

        if df.empty:
            df = fetch_price_history_range(sym, earliest, latest)
            if not df.empty:
                try:
                    df.to_parquet(cache_path)
                except Exception:
                    pass

        if df.empty or len(df) < 100:
            skipped += len(trades[trades["symbol"] == sym])
            continue

        bbw = compute_bbw(df, period=20, std_dev=2.0)
        pctl_series = {w: compute_bbw_pctl(bbw, w) for w in windows}
        cache[sym] = {"bbw": bbw, "pctl": pctl_series}

    logger.info(f"Pre-fetch done: {len(cache)} symbols cached, {skipped} trades skipped")

    for _, trade in trades.iterrows():
        sym = trade["symbol"]
        if sym not in cache:
            continue
        entry_date = trade["entry_date"]
        sym_data = cache[sym]
        bbw_series = sym_data["bbw"]

        try:
            idx = bbw_series.index.get_indexer([entry_date], method="ffill")[0]
            if idx < 0:
                continue
        except Exception:
            continue

        bbw_at_entry = bbw_series.iloc[idx]
        if pd.isna(bbw_at_entry):
            continue

        row = trade.to_dict()
        row["bbw_recomputed"] = float(bbw_at_entry)
        for w in windows:
            pctl = sym_data["pctl"][w].iloc[idx] if idx < len(sym_data["pctl"][w]) else np.nan
            row[f"bbw_pctl_{w}"] = float(pctl) if not pd.isna(pctl) else np.nan

        enriched_rows.append(row)

    enriched = pd.DataFrame(enriched_rows)
    logger.info(f"Enriched: {len(enriched)}/{len(trades)} trades have BBW data")
    return enriched


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def analyze_window(df: pd.DataFrame, window: int) -> dict:
    """Analyze BBW percentile predictive power for a single window length."""
    col = f"bbw_pctl_{window}"
    if col not in df.columns:
        return {}
    d = df.dropna(subset=[col, "pnl_pct", "win"])
    if len(d) < 100:
        return {"window": window, "n": len(d), "error": "insufficient data"}

    buckets = [
        (0, 10, "P0-10 (compressed)"),
        (10, 25, "P10-25"),
        (25, 50, "P25-50"),
        (50, 75, "P50-75"),
        (75, 90, "P75-90"),
        (90, 100, "P90-100 (expanded)"),
    ]

    overall_results = []
    for lo, hi, label in buckets:
        s = d[(d[col] >= lo) & (d[col] < hi)]
        if len(s) < 20:
            continue
        overall_results.append({
            "bucket": label,
            "n": len(s),
            "win_pct": s["win"].mean() * 100,
            "avg_pnl": s["pnl_pct"].mean(),
            "med_pnl": s["pnl_pct"].median(),
        })

    # NORMAL VIX slice
    normal = d[d["vix_regime"] == "NORMAL"] if "vix_regime" in d.columns else pd.DataFrame()
    normal_results = []
    for lo, hi, label in buckets:
        s = normal[(normal[col] >= lo) & (normal[col] < hi)] if not normal.empty else pd.DataFrame()
        if len(s) < 15:
            continue
        normal_results.append({
            "bucket": label,
            "n": len(s),
            "win_pct": s["win"].mean() * 100,
            "avg_pnl": s["pnl_pct"].mean(),
            "med_pnl": s["pnl_pct"].median(),
        })

    corr = d[col].corr(d["pnl_pct"])
    bottom = d[d[col] < 10]["pnl_pct"]
    middle = d[(d[col] >= 25) & (d[col] < 75)]["pnl_pct"]
    top = d[d[col] >= 90]["pnl_pct"]

    d_bot = cohens_d(bottom, middle) if len(bottom) >= 5 else 0
    d_top = cohens_d(top, middle) if len(top) >= 5 else 0

    return {
        "window": window,
        "n": len(d),
        "corr": corr,
        "d_bottom_vs_mid": d_bot,
        "d_top_vs_mid": d_top,
        "overall": overall_results,
        "normal_vix": normal_results,
    }


def print_results(results: list[dict]):
    """Format and print analysis results."""
    print("\n" + "=" * 78)
    print("  BBW PERCENTILE PREDICTIVE POWER — BB RIDE")
    print("  Hypothesis: expansion HELPS ride (opposite of MR finding)")
    print("=" * 78)

    for r in results:
        if "error" in r:
            print(f"\n  Window {r['window']}d: SKIPPED ({r['error']})")
            continue
        print(f"\n  ── WINDOW = {r['window']} days ──")
        print(f"  N={r['n']}  corr={r['corr']:+.3f}")
        print(f"  Effect size: bottom vs mid d={r['d_bottom_vs_mid']:+.3f}  |  top vs mid d={r['d_top_vs_mid']:+.3f}")

        print(f"\n  ALL TRADES:")
        print(f"  {'Bucket':>22s}  {'N':>5s}  {'Win%':>6s}  {'Avg PnL':>8s}  {'Med PnL':>8s}")
        for b in r["overall"]:
            print(f"  {b['bucket']:>22s}  {b['n']:5d}  {b['win_pct']:5.1f}%  {b['avg_pnl']:+7.2f}%  {b['med_pnl']:+7.2f}%")

        if r["normal_vix"]:
            print(f"\n  NORMAL VIX ONLY:")
            print(f"  {'Bucket':>22s}  {'N':>5s}  {'Win%':>6s}  {'Avg PnL':>8s}  {'Med PnL':>8s}")
            for b in r["normal_vix"]:
                print(f"  {b['bucket']:>22s}  {b['n']:5d}  {b['win_pct']:5.1f}%  {b['avg_pnl']:+7.2f}%  {b['med_pnl']:+7.2f}%")

    print("\n" + "=" * 78)
    print("  CROSS-WINDOW SUMMARY")
    print("=" * 78)
    print(f"\n  {'Window':>8s}  {'Corr':>8s}  {'d(bot)':>8s}  {'d(top)':>8s}  {'Verdict':>30s}")
    for r in results:
        if "error" in r:
            continue
        # For ride: positive d(top) = expansion helps = good
        # For ride: negative d(bot) = compression hurts = good (filter)
        max_abs = max(abs(r["d_bottom_vs_mid"]), abs(r["d_top_vs_mid"]))
        verdict = "no signal"
        if max_abs >= 0.15:
            verdict = "WEAK signal"
        if max_abs >= 0.25:
            verdict = "MEANINGFUL signal"
        if max_abs >= 0.4:
            verdict = "STRONG signal"
        print(f"  {r['window']:>6d}d  {r['corr']:+7.3f}  {r['d_bottom_vs_mid']:+7.3f}  {r['d_top_vs_mid']:+7.3f}  {verdict:>30s}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="40,60,80,100",
                    help="Comma-separated rolling window sizes")
    ap.add_argument("--ride-csv", default="data/backtest_results/bb_ride_trades.csv",
                    help="Path to BB Ride trades CSV")
    args = ap.parse_args()

    windows = [int(w) for w in args.windows.split(",")]

    trades = load_ride_trades(args.ride_csv)
    enriched = enrich_ride_trades(trades, windows)

    if enriched.empty:
        logger.error("No trades enriched.")
        sys.exit(1)

    out_path = f"data/bbw_pctl_ride_trades_{datetime.datetime.now():%Y%m%d_%H%M}.csv"
    enriched.to_csv(out_path, index=False)
    logger.info(f"Saved enriched trades to {out_path}")

    results = [analyze_window(enriched, w) for w in windows]
    print_results(results)

    print("\n" + "=" * 78)
    print("  DECISION GUIDANCE")
    print("=" * 78)
    print("""
  MR study found: compression (P0-10) HURTS mean reversion by 8.6pp win rate.
  Ride hypothesis: expansion (P90-100) should HELP ride (opposite trade).

  ADD AS RIDE GRADE FACTOR if:
    - Top decile (expanded) shows >= 5pp win rate edge vs middle
    - Cohen's d(top vs mid) >= 0.25 in at least one window
    - Effect persists in NORMAL/LOW VIX where rides are most common

  ADD AS RIDE FILTER if:
    - Bottom decile (compressed) shows >= 5pp NEGATIVE edge vs middle
    - This means: skip ride entries during compression (false breakouts)

  REJECT if:
    - All windows show |d| < 0.15 (the volatility-momentum link doesn't show)
    - Effect is in opposite direction of expected (compressed actually wins)
""")


if __name__ == "__main__":
    main()
