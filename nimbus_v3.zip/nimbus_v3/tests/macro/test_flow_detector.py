"""Tests for nimbus_v3.macro.flow_detector."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.macro.flow_detector import (
    MIN_BARS_REQUIRED, MacroFlowResult, detect_flows, _window_z,
)
from nimbus_v3.macro.universe import COMMODITY_UNIVERSE, by_ticker


def _ohlcv(closes: np.ndarray, start="2023-01-01") -> pd.DataFrame:
    idx = pd.bdate_range(start, periods=len(closes))
    return pd.DataFrame({
        "Open": closes, "High": closes * 1.005, "Low": closes * 0.995,
        "Close": closes, "Volume": 1e6,
    }, index=idx)


def _calm_panel(tickers: list[str], n: int = 600, seed: int = 0) -> dict:
    """Calm random-walk panel — z-scores should hover near 0."""
    rng = np.random.default_rng(seed)
    panel = {}
    for t in tickers:
        rets = rng.normal(0.0003, 0.012, n)
        closes = 100.0 * np.exp(np.cumsum(rets))
        panel[t] = _ohlcv(closes)
    return panel


# ══════════════════════════════════════════════════════════════════════════════
# detect_flows — basic shape
# ══════════════════════════════════════════════════════════════════════════════

def test_detect_flows_empty_panel_returns_empty() -> None:
    assert detect_flows({}) == []


def test_detect_flows_skips_missing_tickers() -> None:
    panel = _calm_panel(["GC=F"])     # only one ticker present
    results = detect_flows(panel)
    assert len(results) == 1
    assert results[0].instrument.ticker == "GC=F"


def test_detect_flows_skips_empty_dataframes() -> None:
    panel = {"GC=F": pd.DataFrame()}
    results = detect_flows(panel)
    assert results == []


def test_detect_flows_returns_one_per_instrument() -> None:
    tickers = ["GC=F", "SI=F", "CL=F"]
    panel = _calm_panel(tickers)
    results = detect_flows(panel)
    assert len(results) == 3
    assert {r.instrument.ticker for r in results} == set(tickers)


def test_detect_flows_sorted_by_max_abs_z_descending() -> None:
    tickers = ["GC=F", "SI=F", "CL=F"]
    panel = _calm_panel(tickers, seed=1)
    # Spike CL=F's last 5 bars to push its z above the others.
    cl = panel["CL=F"]
    spike_closes = cl["Close"].copy()
    spike_closes.iloc[-5:] = spike_closes.iloc[-6] * np.array(
        [1.05, 1.10, 1.16, 1.22, 1.28]
    )
    cl["Close"] = spike_closes
    cl["Open"] = cl["Close"]
    cl["High"] = cl["Close"] * 1.005
    cl["Low"] = cl["Close"] * 0.995

    results = detect_flows(panel)
    assert results[0].instrument.ticker == "CL=F"


def test_detect_flows_silently_continues_on_per_symbol_error(caplog) -> None:
    """A broken DataFrame for one ticker shouldn't kill the whole run."""
    panel = _calm_panel(["GC=F"])
    panel["SI=F"] = pd.DataFrame({"NotClose": [1, 2, 3]})  # malformed
    results = detect_flows(panel)
    # GC=F still appears; SI=F skipped (no Close column).
    assert any(r.instrument.ticker == "GC=F" for r in results)


# ══════════════════════════════════════════════════════════════════════════════
# Z-score correctness
# ══════════════════════════════════════════════════════════════════════════════

def test_calm_market_produces_small_z_scores() -> None:
    panel = _calm_panel(["GC=F"], n=600, seed=42)
    results = detect_flows(panel)
    r = results[0]
    # Random walk → cumulative z-scores typically < 2σ.
    assert abs(r.price_z_60d) < 3.0
    assert abs(r.price_z_30d) < 3.0


def test_extreme_spike_registers_high_z() -> None:
    """Engineered +5%/day for last 5 days should fire all three windows."""
    panel = _calm_panel(["GC=F"], seed=0)
    df = panel["GC=F"]
    closes = df["Close"].copy()
    last_normal = float(closes.iloc[-6])
    closes.iloc[-5:] = last_normal * np.array([1.05, 1.10, 1.16, 1.22, 1.28])
    df["Close"] = closes

    results = detect_flows(panel)
    r = results[0]
    # 10d window: 5 days of +5% pushes cumulative way beyond historical normal.
    assert r.price_z_10d > 3.0


def test_insufficient_history_returns_nan_z() -> None:
    """Less than the minimum window history → NaN z-scores, not crash."""
    short = _ohlcv(np.linspace(100.0, 110.0, 20))
    results = detect_flows({"GC=F": short})
    r = results[0]
    assert np.isnan(r.price_z_60d)
    assert np.isnan(r.price_z_30d)
    assert np.isnan(r.price_z_10d)


def test_pct_change_calculations() -> None:
    closes = np.array([100.0] * 100 + [105.0])    # 5% jump on last bar
    panel = {"GC=F": _ohlcv(closes)}
    results = detect_flows(panel)
    r = results[0]
    assert r.pct_change_1d == pytest.approx(5.0, abs=0.1)


# ══════════════════════════════════════════════════════════════════════════════
# Stage labels
# ══════════════════════════════════════════════════════════════════════════════

def test_stage_label_extended_when_all_windows_high() -> None:
    instr = by_ticker("GC=F")
    r = MacroFlowResult(
        instrument=instr, asof_date=pd.Timestamp("2024-05-15"),
        close_price=100.0, pct_change_1d=0.0, pct_change_5d=0.0,
        price_z_10d=2.5, price_z_30d=2.2, price_z_60d=2.1,
    )
    assert r.stage_label == "extended"


def test_stage_label_early_when_only_short_window_hot() -> None:
    instr = by_ticker("GC=F")
    r = MacroFlowResult(
        instrument=instr, asof_date=pd.Timestamp("2024-05-15"),
        close_price=100.0, pct_change_1d=0.0, pct_change_5d=0.0,
        price_z_10d=2.5, price_z_30d=0.5, price_z_60d=0.3,
    )
    assert r.stage_label == "early"


def test_stage_label_mature_when_long_window_dominant() -> None:
    instr = by_ticker("GC=F")
    r = MacroFlowResult(
        instrument=instr, asof_date=pd.Timestamp("2024-05-15"),
        close_price=100.0, pct_change_1d=0.0, pct_change_5d=0.0,
        price_z_10d=0.8, price_z_30d=1.5, price_z_60d=2.4,
    )
    assert r.stage_label == "mature"


def test_stage_label_dash_when_quiet() -> None:
    instr = by_ticker("GC=F")
    r = MacroFlowResult(
        instrument=instr, asof_date=pd.Timestamp("2024-05-15"),
        close_price=100.0, pct_change_1d=0.0, pct_change_5d=0.0,
        price_z_10d=0.3, price_z_30d=0.5, price_z_60d=0.4,
    )
    assert r.stage_label == "—"


# ══════════════════════════════════════════════════════════════════════════════
# max_abs_z accessor
# ══════════════════════════════════════════════════════════════════════════════

def test_max_abs_z_picks_largest_absolute_value() -> None:
    instr = by_ticker("GC=F")
    r = MacroFlowResult(
        instrument=instr, asof_date=pd.Timestamp("2024-05-15"),
        close_price=100.0, pct_change_1d=0.0, pct_change_5d=0.0,
        price_z_10d=-2.7, price_z_30d=1.1, price_z_60d=0.5,
    )
    assert r.max_abs_z == pytest.approx(2.7)


# ══════════════════════════════════════════════════════════════════════════════
# _window_z internals
# ══════════════════════════════════════════════════════════════════════════════

def test_window_z_returns_nan_with_insufficient_data() -> None:
    rets = pd.Series(np.zeros(10))   # way below window+30
    assert np.isnan(_window_z(rets, window=10))


def test_window_z_returns_nan_when_std_zero() -> None:
    """Constant returns → zero std → NaN, not divide-by-zero crash."""
    rets = pd.Series(np.zeros(400))
    assert np.isnan(_window_z(rets, window=10))


def test_window_z_uses_only_history_excluding_current() -> None:
    """The current cumulative-N return must NOT be included in its own
    historical baseline — that would shrink the z-score."""
    rng = np.random.default_rng(0)
    rets = pd.Series(rng.normal(0.0, 0.01, 400))
    # Spike the last value massively.
    rets.iloc[-1] = 0.5
    z = _window_z(rets, window=10)
    # If current point were included in baseline, z would be artificially small.
    # Excluding it, the spike should dominate the window's cumulative sum.
    assert z > 5.0
