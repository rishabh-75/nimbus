#!/usr/bin/env python3
"""self_valuation_separation_probe.py — separate the REAL name-level value
signal from the market-timing artifact and the %B redundancy that
contaminated self_valuation_probe.

WHAT WE'RE UNTANGLING
─────────────────────
self_valuation_probe found all three self-referential ratios fire
cheap-for-itself (price_over_median t+6.8, price_over_rs t+12.2,
price_over_seasonal t+8.9) with the random-key control dead — so the labels
carry information. BUT the shuffle-dates canary was HOT on all three
(+3.1/+6.4/+3.4), which is the tell that the effect is contaminated by
TIME STRUCTURE the clustering did not absorb. Diagnosis:

  • MARKET-TIMING LEAK. "Below its own median" clusters in time — at market
    lows, nearly every name is cheap-for-itself AT ONCE, and the subsequent
    market bounce pays. That is "buy the dip on the index" wearing a value
    costume, not a per-name effect.
  • %B REDUNDANCY. The %B gate reproduced the same cheap-D1/rich-D10 shape
    (t+6.1) — part of price_over_median is just the band signal inverted.
  • CLUSTERING. symbol-month is not the independent unit when cheapness
    co-moves across names on the same dates; the honest unit is the DATE.

THREE FIXES, EACH ISOLATING ONE CONTAMINANT
───────────────────────────────────────────
  1. PER-DATE CROSS-SECTIONAL DEMEAN. On each date, replace a name's raw
     own-history z with its z MINUS that date's cross-sectional mean z. This
     asks "cheap for itself vs how cheap everything is for itself RIGHT NOW",
     removing "the whole market is down". Survives → genuine name-level value.
     Collapses → it was buy-the-dip.

  2. DATE CLUSTERING. All inference clusters on the ENTRY DATE (the unit that
     co-moves), not symbol-month. t shrinks but becomes honest. The
     shuffle-dates canary must finally go ~0 under this.

  3. %B ORTHOGONALISATION. Regress the (demeaned) signal on %B and keep only
     the RESIDUAL, so we measure the value effect NOT already in the band.

The probe runs each ratio through: RAW → +demean → +demean+orthogonalised,
so you SEE how much each contaminant was worth. The final column
(demeaned + date-clustered + %B-orthogonalised) is the honest name-level
value signal. Anything that still clears |t|>2 THERE is real and new.

CONTROLS: random-key (must die) and shuffle-dates (must now be ~0 under date
clustering — that is the proof the leak is gone).

Run from the dir with ./data:
    cd /Users/srishabh/Monarch/nimbus
    python nimbus_v3/self_valuation_separation_probe.py
    python nimbus_v3/self_valuation_separation_probe.py --selftest
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

FWD = 20
SAMPLE_EVERY = 5
ZWIN = 504
MEDIAN_WIN = 252
RS_WIN = 120
MIN_SEASON_YEARS = 3
PCTB = "bb_20_1s_pct"


# ── ratios (same as the parent probe) ───────────────────────────────────────
def ratio_price_over_median(df, *, win=MEDIAN_WIN):
    import numpy as np
    c = df["Close"].astype(float)
    return c / c.rolling(win, min_periods=win // 2).median().replace(0.0, np.nan)


def ratio_price_over_rs(df, market_close, *, win=RS_WIN):
    import numpy as np
    c = df["Close"].astype(float)
    m = market_close.reindex(c.index).ffill()
    rs = c / m.replace(0.0, np.nan)
    return rs / rs.rolling(win, min_periods=win // 2).mean()


def _monthly_pattern(close, asof):
    import numpy as np
    from nimbus_v3.compute.seasonality import _monthly_returns
    hist = close.loc[close.index < asof]
    if hist.empty:
        return {}
    m = _monthly_returns(hist)
    if m.empty:
        return {}
    out = {}
    for mo in range(1, 13):
        v = m[m.index.month == mo].to_numpy(dtype=float)
        v = v[np.isfinite(v)]
        if len(v) >= MIN_SEASON_YEARS:
            out[mo] = float(np.mean(v))
    return out


def seasonal_ratio_at(df, seasonal_close, i):
    import numpy as np
    asof = df.index[i]
    pat = _monthly_pattern(seasonal_close, asof)
    if not pat:
        return float("nan")
    exp = pat.get(asof.month)
    if exp is None:
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    if i < 21 or c[i - 21] <= 0:
        return float("nan")
    expp = c[i - 21] * (1.0 + exp)
    return c[i] / expp if expp > 0 else float("nan")


def zscore_at(vals, i, *, win=ZWIN):
    import numpy as np
    lo = max(0, i - win)
    h = vals[lo:i]
    h = h[np.isfinite(h)]
    if len(h) < win // 3:
        return float("nan")
    mu, sd = h.mean(), h.std(ddof=1)
    return (vals[i] - mu) / sd if sd > 0 else float("nan")


def forward_excess(df, i, market_cum, *, fwd=FWD):
    import numpy as np
    if i + fwd >= len(df):
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    r = c[i + fwd] / c[i] - 1.0
    d0, d1 = df.index[i], df.index[i + fwd]
    m0, m1 = market_cum.get(d0), market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan")
    rm = m1 / m0 - 1.0
    return (r - rm) if (np.isfinite(r) and np.isfinite(rm)) else float("nan")


# ── inference: DATE-clustered ───────────────────────────────────────────────
def clustered_mean(pairs):
    import numpy as np
    by = defaultdict(list)
    for k, x in pairs:
        if x == x:
            by[k].append(x)
    dm = [np.mean(v) for v in by.values()]
    return (float(np.mean(dm)), len(dm)) if len(dm) >= 3 else (float("nan"), len(dm))


def welch(a, b):
    import numpy as np
    def dm(p):
        d = defaultdict(list)
        for k, x in p:
            if x == x:
                d[k].append(x)
        return np.array([np.mean(v) for v in d.values()])
    x, y = dm(a), dm(b)
    if len(x) < 3 or len(y) < 3:
        return float("nan")
    se = np.sqrt(x.var(ddof=1)/len(x) + y.var(ddof=1)/len(y))
    return (x.mean()-y.mean())/se if se > 0 else float("nan")


def _spread(rows, key_i, *, clip_deciles=True):
    """D1(cheap)−D10(rich) with DATE clustering. rows carry the entry date as
    the cluster key at column 0."""
    import numpy as np
    vals = np.array([r[key_i] for r in rows if r[key_i] == r[key_i]])
    if len(vals) < 20:
        return float("nan"), float("nan")
    e1, e9 = np.quantile(vals, 0.1), np.quantile(vals, 0.9)
    cheap = [(r[0], r[1]) for r in rows if r[key_i] == r[key_i] and r[key_i] <= e1]
    rich = [(r[0], r[1]) for r in rows if r[key_i] == r[key_i] and r[key_i] >= e9]
    cm, _ = clustered_mean(cheap)
    rm, _ = clustered_mean(rich)
    return ((cm - rm) if (cm == cm and rm == rm) else float("nan")), welch(cheap, rich)


# ── transforms ──────────────────────────────────────────────────────────────
def per_date_demean(rows, key_i, out_i):
    """out_i = key_i minus that entry-date's cross-sectional mean of key_i."""
    import numpy as np
    by_date = defaultdict(list)
    for r in rows:
        if r[key_i] == r[key_i]:
            by_date[r[7]].append(r[key_i])   # r[7] = raw entry date
    means = {d: float(np.mean(v)) for d, v in by_date.items() if v}
    for r in rows:
        if r[key_i] == r[key_i] and r[7] in means:
            r[out_i] = r[key_i] - means[r[7]]
        else:
            r[out_i] = float("nan")


def orthogonalize_vs_pctb(rows, key_i, pctb_i, out_i):
    """out_i = residual of key_i after regressing on %B (single-var OLS).
    Removes the component of the signal already contained in the band."""
    import numpy as np
    xs = np.array([r[pctb_i] for r in rows])
    ys = np.array([r[key_i] for r in rows])
    ok = np.isfinite(xs) & np.isfinite(ys)
    if ok.sum() < 50:
        for r in rows:
            r[out_i] = float("nan")
        return
    x, y = xs[ok], ys[ok]
    b = np.cov(x, y, ddof=1)[0, 1] / (x.var(ddof=1) or 1.0)
    a = y.mean() - b * x.mean()
    for r in rows:
        if np.isfinite(r[pctb_i]) and np.isfinite(r[key_i]):
            r[out_i] = r[key_i] - (a + b * r[pctb_i])
        else:
            r[out_i] = float("nan")


# ── row layout ──────────────────────────────────────────────────────────────
# 0 date(clusterkey) 1 fwd 2 z_med 3 z_rs 4 z_seas 5 pctb 6 <scratch>
# 7 raw_date 8..: transform scratch columns per ratio
def build_rows(panel, sym_to_industry, comps, market_close, market_cum):
    import numpy as np
    rows = []
    for sym, df in panel.items():
        ind = sym_to_industry.get(sym)
        if "Close" not in df.columns or len(df) < ZWIN + FWD + 30:
            continue
        seas_close = comps.get(ind)
        rmed = ratio_price_over_median(df).to_numpy(dtype=float)
        rrs = ratio_price_over_rs(df, market_close).to_numpy(dtype=float)
        pctb = (df[PCTB].to_numpy(dtype=float) if PCTB in df.columns
                else np.full(len(df), np.nan))
        for i in range(ZWIN, len(df) - FWD - 1, SAMPLE_EVERY):
            fx = forward_excess(df, i, market_cum)
            if fx != fx:
                continue
            zm = zscore_at(rmed, i)
            zr = zscore_at(rrs, i)
            zs = float("nan")
            if seas_close is not None:
                sr = seasonal_ratio_at(df, seas_close, i)
                if sr == sr:
                    zs = sr - 1.0
            d = df.index[i]
            rows.append([d, fx, zm, zr, zs, pctb[i], None, d,
                         float("nan"), float("nan"),      # med: demean, ortho
                         float("nan"), float("nan"),      # rs
                         float("nan"), float("nan")])     # seas
    return rows


def run_ratio(rows, name, z_i, dm_i, dmo_i, rng):
    """RAW → per-date-demeaned → demeaned+%B-orthogonalised, all DATE-clustered."""
    per_date_demean(rows, z_i, dm_i)
    orthogonalize_vs_pctb(rows, dm_i, 5, dmo_i)

    raw_s, raw_t = _spread(rows, z_i)
    dm_s, dm_t = _spread(rows, dm_i)
    dmo_s, dmo_t = _spread(rows, dmo_i)

    # controls on the FINAL (demeaned+ortho) signal
    rk = [r[:] for r in rows]
    ks = [r[dmo_i] for r in rk]
    rng.shuffle(ks)
    for r, k in zip(rk, ks):
        r[dmo_i] = k
    _, rk_t = _spread(rk, dmo_i)

    sd = [r[:] for r in rows]
    ds = [r[0] for r in sd]
    rng.shuffle(ds)
    for r, d in zip(sd, ds):
        r[0] = d
    _, sd_t = _spread(sd, dmo_i)

    print(f"\n─── {name} " + "─" * max(2, 46 - len(name)))
    print(f"  RAW (date-clustered)          D1−D10 {raw_s*100:+6.2f}%  t {raw_t:+6.2f}")
    print(f"  + per-date demean             D1−D10 {dm_s*100:+6.2f}%  t {dm_t:+6.2f}")
    print(f"  + demean + %B-orthogonalised  D1−D10 {dmo_s*100:+6.2f}%  t {dmo_t:+6.2f}"
          f"   << honest name-level value")
    print(f"     control random-key t {rk_t:+.2f} (must be ~0)   "
          f"shuffle-dates t {sd_t:+.2f} (context only — a real name-level "
          f"signal stays hot here)")
    return {"raw_t": raw_t, "demean_t": dm_t, "final_t": dmo_t,
            "final_s": dmo_s, "rk_t": rk_t, "sd_t": sd_t}


def build_market(panel, *, min_count=20):
    import numpy as np
    import pandas as pd
    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                sums[idx[i]] += c[i]/c[i-1] - 1.0
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    cum, acc, lvl = {}, 1.0, {}
    for d in sorted(daily):
        acc *= 1.0 + daily[d]
        cum[d] = acc
        lvl[d] = acc
    return cum, pd.Series(lvl).sort_index()


def build_composites(panel, sym_to_industry):
    from nimbus_v3.compute.industry_composite import build_industry_composite
    members = defaultdict(list)
    for sym, ind in sym_to_industry.items():
        if sym in panel:
            members[ind].append(sym)
    out = {}
    for ind, syms in members.items():
        comp, _ = build_industry_composite(
            syms, panel, min_members=3, min_bars=250, lookback=None)
        if comp is not None:
            out[ind] = comp
    return out


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db
    from strategy_probe import load_panel

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — run from dir with ./data", file=sys.stderr)
        return 1
    print("composites + market...", file=sys.stderr)
    comps = build_composites(panel, sym_to_industry)
    market_cum, market_close = build_market(panel)
    print("building rows...", file=sys.stderr)
    rows = build_rows(panel, sym_to_industry, comps, market_close, market_cum)
    print(f"rows: {len(rows)}", file=sys.stderr)

    rng = np.random.default_rng(args.seed)
    res = {}
    res["price_over_median"] = run_ratio(rows, "price_over_median", 2, 8, 9, rng)
    res["price_over_rs"] = run_ratio(rows, "price_over_rs", 3, 10, 11, rng)
    res["price_over_seasonal"] = run_ratio(rows, "price_over_seasonal", 4, 12, 13, rng)

    print("\n" + "=" * 68)
    print("VERDICT (the honest column is 'demean + %B-orthogonalised')")
    print("  note: the per-date demean is the market-timing control (it strips")
    print("  the 'whole market is cheap' tide); random-key must die; a real")
    print("  NAME-LEVEL signal legitimately keeps shuffle-dates hot (it is")
    print("  cross-sectional, not time-structure), so shuffle-dates is NOT a")
    print("  kill gate here — it is reported for context only.")
    survivors = []
    for name, r in res.items():
        real = (abs(r["final_t"]) > 2 and abs(r["rk_t"]) < 2
                and r["final_s"] > 0)
        note = []
        if not (abs(r["final_t"]) > 2):
            if abs(r["demean_t"]) < 2:
                note.append("died at per-date demean → was market-timing")
            else:
                note.append("died at %B-ortho → was band redundancy")
        if abs(r["rk_t"]) >= 2:
            note.append("random-key hot → suspect")
        tag = "REAL name-level value" if real else "not clean"
        print(f"  {name:20} raw t {r['raw_t']:+5.2f} → demean {r['demean_t']:+5.2f}"
              f" → final {r['final_t']:+5.2f}   [{tag}]"
              + (f"  ({'; '.join(note)})" if note else ""))
        if real:
            survivors.append(name)
    print()
    if survivors:
        print(f"  SURVIVES cleaning: {', '.join(survivors)}.")
        print("  This is a genuine name-level, non-market-timing, non-%B value")
        print("  signal — the first non-momentum edge in the system. Worth")
        print("  building as a bounded oscillator. Confirm sign stability on a")
        print("  re-run and check the effect size is worth the trading cost.")
    else:
        print("  NOTHING survives all three cleanings. The t+12 was market-")
        print("  timing (buy-the-dip) plus %B redundancy, not name-level value.")
        print("  Honest end of the valuation thread: build nothing; the")
        print("  volume blow-off remains the one validated edge.")
    return 0


def _selftest(args):
    """Three worlds on synthetic rows (date + cross-section structure):
      A) NAME-LEVEL VALUE — fwd ∝ −(demeaned z). Survives all cleanings.
      B) MARKET-TIMING     — fwd ∝ −(date mean z) only. Dies after per-date
                             demean (nothing left name-level).
      C) %B-REDUNDANT      — fwd ∝ −pctb; z correlated with pctb. Dies after
                             orthogonalisation.
    """
    import numpy as np
    import pandas as pd
    dates = pd.bdate_range("2016-01-01", periods=1000)

    def synth(mode):
        rng = np.random.default_rng(args.seed)
        # DENSE panel: every symbol sampled on every entry date, so per-date
        # cross-sectional demean has a real cross-section to estimate the
        # market 'tide' from (matches the real panel: ~485 names per date).
        entry_dates = dates[::4]
        tide = {d: rng.normal(0, 1) for d in entry_dates}
        syms = [f"S{s:02d}" for s in range(80)]
        rows = []
        for d in entry_dates:
            for sym in syms:
                name_z = rng.normal(0, 1)
                z = tide[d] + name_z          # raw z = market tide + name part
                if mode == "value":
                    # %B is INDEPENDENT of the name value signal here, so
                    # orthogonalising must NOT remove the value effect.
                    pctb = 0.5 + rng.normal(0, 0.15)
                    fwd = -0.012 * name_z + rng.normal(0, 0.04)
                elif mode == "timing":
                    pctb = 0.5 + rng.normal(0, 0.15)
                    fwd = -0.012 * tide[d] + rng.normal(0, 0.04)
                else:  # pctb-redundant: %B carries the signal, z tracks %B
                    pctb = 0.5 + 0.15 * name_z + rng.normal(0, 0.05)
                    fwd = -0.03 * (pctb - 0.5) + rng.normal(0, 0.04)
                rows.append([d, fwd, z, rng.normal(), rng.normal(), pctb, None,
                             d, float("nan"), float("nan"), float("nan"),
                             float("nan"), float("nan"), float("nan")])
        return rows

    rng = np.random.default_rng(args.seed)
    print("\n### A: name-level value (should SURVIVE) ###")
    A = run_ratio(synth("value"), "A value", 2, 8, 9, rng)
    print("\n### B: market-timing (should DIE at demean) ###")
    B = run_ratio(synth("timing"), "B timing", 2, 8, 9, rng)
    print("\n### C: %B-redundant (should DIE at ortho) ###")
    C = run_ratio(synth("pctb"), "C pctb", 2, 8, 9, rng)

    A_ok = abs(A["final_t"]) > 2 and abs(A["rk_t"]) < 2   # survives; label-info real
    B_ok = abs(B["demean_t"]) < 2                 # timing gone after demean
    C_ok = abs(C["raw_t"]) > 2 and abs(C["final_t"]) < 2  # gone after ortho
    print("\n" + "=" * 68)
    print(f"A value survives cleaning (final t>2, random-key dead):  {A_ok}")
    print(f"B timing dies at per-date demean:                        {B_ok}")
    print(f"C %B-redundant dies at ortho:                            {C_ok}")
    ok = A_ok and B_ok and C_ok
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
