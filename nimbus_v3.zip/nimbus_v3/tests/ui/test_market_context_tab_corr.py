"""tests.ui.test_market_context_tab_corr — CORR regime badge.

Tests the set_correlation_state() → badge text/color update path.
"""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.compute.correlation_regime import (
    CorrelationRegimeState,
    REGIME_HIGH, REGIME_LOW, REGIME_NORMAL, REGIME_UNKNOWN,
)
from nimbus_v3.ui.theme import GREEN, MUTED, RED
from nimbus_v3.ui.widgets.market_context_tab import MarketContextTab


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _state(regime: str, corr: float = 0.5, pctile: float = 0.5,
           n_inds: int = 40):
    return CorrelationRegimeState(
        regime=regime, mean_correlation=corr,
        pctile=pctile, n_industries=n_inds,
    )


# ══════════════════════════════════════════════════════════════════════
# Initial state
# ══════════════════════════════════════════════════════════════════════

class TestInitialBadgeState:

    def test_placeholder_before_set_state(self, qapp):
        tab = MarketContextTab()
        assert tab._corr_regime_label.text() == "CORR: —"
        assert MUTED in tab._corr_regime_label.styleSheet()
        assert tab._corr_state is None


# ══════════════════════════════════════════════════════════════════════
# Badge updates
# ══════════════════════════════════════════════════════════════════════

class TestSetCorrelationState:

    def test_high_regime_badge_green(self, qapp):
        tab = MarketContextTab()
        tab.set_correlation_state(_state(REGIME_HIGH, corr=0.65, pctile=0.85))
        assert tab._corr_regime_label.text() == "CORR: HIGH"
        assert GREEN in tab._corr_regime_label.styleSheet()

    def test_normal_regime_badge_red(self, qapp):
        """NORMAL is RED because it has the worst forward returns
        (-1.1pp) — counterintuitive but accurate per the research."""
        tab = MarketContextTab()
        tab.set_correlation_state(_state(REGIME_NORMAL, corr=0.50, pctile=0.50))
        assert tab._corr_regime_label.text() == "CORR: NORMAL"
        assert RED in tab._corr_regime_label.styleSheet()

    def test_low_regime_badge_muted(self, qapp):
        """LOW has neutral fwd lift, so MUTED — no directional cue
        but the regime IS real (orderly bull-market rally)."""
        tab = MarketContextTab()
        tab.set_correlation_state(_state(REGIME_LOW, corr=0.30, pctile=0.10))
        assert tab._corr_regime_label.text() == "CORR: LOW"
        assert MUTED in tab._corr_regime_label.styleSheet()

    def test_unknown_regime_renders_placeholder(self, qapp):
        """UNKNOWN during warmup → placeholder, not 'CORR: UNKNOWN'."""
        tab = MarketContextTab()
        tab.set_correlation_state(_state(REGIME_UNKNOWN))
        assert tab._corr_regime_label.text() == "CORR: —"
        assert MUTED in tab._corr_regime_label.styleSheet()

    def test_none_resets_badge(self, qapp):
        tab = MarketContextTab()
        tab.set_correlation_state(_state(REGIME_HIGH))
        assert tab._corr_regime_label.text() == "CORR: HIGH"
        tab.set_correlation_state(None)
        assert tab._corr_regime_label.text() == "CORR: —"
        assert MUTED in tab._corr_regime_label.styleSheet()

    def test_repeated_calls_safe(self, qapp):
        tab = MarketContextTab()
        for r in (REGIME_HIGH, REGIME_NORMAL, REGIME_LOW,
                  REGIME_HIGH, REGIME_UNKNOWN):
            tab.set_correlation_state(_state(r))


# ══════════════════════════════════════════════════════════════════════
# Independence from VIX badge
# ══════════════════════════════════════════════════════════════════════

class TestCorrAndVixCoexist:

    def test_setting_corr_does_not_affect_vix_badge(self, qapp):
        """The two badges share a header but are independent — setting
        correlation state must not mutate the VIX badge."""
        tab = MarketContextTab()
        # VIX starts at placeholder
        assert tab._vix_regime_label.text() == "VIX: —"
        tab.set_correlation_state(_state(REGIME_HIGH))
        # VIX should be unchanged
        assert tab._vix_regime_label.text() == "VIX: —"
