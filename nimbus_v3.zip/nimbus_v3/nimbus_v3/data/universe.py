"""nimbus_v3.data.universe — NSE-index-driven universe builder.

Per ``docs/ARCHITECTURE.md §18.1``: one coordinated fetch against NSE's
sectoral + broad-market index endpoints produces both the tradable
universe and the symbol→sector mapping. No hard-coded sector dictionary.

How the builder composes a ``Universe``
───────────────────────────────────────

1. For each broad-market index (NIFTY 50, 100, 200, 500) — fetch the
   constituent list. Tag every symbol with the index name.

2. For each sectoral index (NIFTY BANK, NIFTY IT, NIFTY AUTO, …) — fetch.
   Tag every symbol with the sectoral index name AND mark the symbol's
   ``sector`` field using a map from index name to a canonical sector
   string.

3. For the F&O universe endpoint (market lot list) — fetch. Set
   ``is_fno=True`` on each listed symbol.

4. For the ETF list endpoint — fetch. Create a separate slice of
   ``SymbolMeta`` with ``is_etf=True`` and attached ``ETFMeta``.

5. Emit a single ``Universe`` keyed by canonical NSE symbol. When a
   symbol appears in multiple indices, its ``indices`` set accumulates
   all of them; its ``sector`` is the first sectoral-index assignment
   encountered (sectoral indices are fetched in a deterministic order
   so this is stable across runs).

Failure semantics
─────────────────
- A partial failure (some endpoints succeed, others fail) results in a
  partial universe. The builder logs the failure and proceeds with what
  it has. The universe's ``built_at`` still reflects wall-clock.
- A total failure (all endpoints fail) raises ``UniverseBuildError``.
  Callers MAY fall back to a cached universe; the builder does not do
  this automatically because policy (stale fallback vs. hard fail) is a
  caller concern.

All endpoint URLs and the index→sector mapping are configurable via the
``UniverseConfig`` dataclass so tests can parametrise without monkey-
patching.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Final

import pandas as pd

from nimbus_v3.core.universe import ETFMeta, SymbolMeta, Universe
from nimbus_v3.data.nse_client import NSEClient


logger = logging.getLogger(__name__)


class UniverseBuildError(RuntimeError):
    """Raised when the builder cannot produce any usable universe at all."""


# ══════════════════════════════════════════════════════════════════════════════
# Default NSE endpoint config
# ══════════════════════════════════════════════════════════════════════════════

#: Base URLs. Exposed via config so tests can override.
_NSE_BASE = "https://www.nseindia.com"
_INDEX_ENDPOINT = f"{_NSE_BASE}/api/equity-stockIndices"
_ETF_ENDPOINT = f"{_NSE_BASE}/api/etf"
_FNO_ENDPOINT = f"{_NSE_BASE}/api/liveEquity-derivatives?index=fo_secban"

#: Common referer used when hitting index data. NSE serves the same
#: endpoint from multiple public pages; this one works in live probes.
_INDEX_REFERER = f"{_NSE_BASE}/market-data/live-equity-market"
_ETF_REFERER = f"{_NSE_BASE}/market-data/exchange-traded-funds-etf"
_FNO_REFERER = f"{_NSE_BASE}/market-data/live-market-indices"

#: Broad-market indices — these do not carry sector attribution.
_DEFAULT_BROAD_INDICES: Final[tuple[str, ...]] = (
    "NIFTY 50",
    "NIFTY 100",
    "NIFTY 200",
    "NIFTY 500",
)

#: Sectoral indices and the canonical sector names they map to.
#: The order matters: the first sectoral index a symbol appears in wins
#: the ``sector`` assignment. We list narrower sectors (e.g. PSU BANK)
#: before broader ones (BANK) so the more specific wins.
_DEFAULT_SECTORAL_INDICES: Final[tuple[tuple[str, str], ...]] = (
    ("NIFTY PSU BANK", "PSU Banking"),
    ("NIFTY PVT BANK", "Private Banking"),
    ("NIFTY BANK", "Banking"),
    ("NIFTY FINANCIAL SERVICES", "Financial Services"),
    ("NIFTY IT", "Information Technology"),
    ("NIFTY AUTO", "Auto"),
    ("NIFTY PHARMA", "Pharmaceuticals"),
    ("NIFTY FMCG", "FMCG"),
    ("NIFTY METAL", "Metals"),
    ("NIFTY ENERGY", "Energy"),
    ("NIFTY REALTY", "Realty"),
    ("NIFTY MEDIA", "Media"),
    ("NIFTY CONSUMER DURABLES", "Consumer Durables"),
    ("NIFTY OIL & GAS", "Oil & Gas"),
    ("NIFTY HEALTHCARE INDEX", "Healthcare"),
    ("NIFTY INFRASTRUCTURE", "Infrastructure"),
)


@dataclass(frozen=True)
class UniverseConfig:
    """Tunables for the universe build. Override in tests or deployment
    to hit a different set of indices / URLs.
    """
    broad_indices: tuple[str, ...] = _DEFAULT_BROAD_INDICES
    sectoral_indices: tuple[tuple[str, str], ...] = _DEFAULT_SECTORAL_INDICES
    include_fno: bool = True
    include_etfs: bool = True
    index_endpoint: str = _INDEX_ENDPOINT
    index_referer: str = _INDEX_REFERER
    fno_endpoint: str = _FNO_ENDPOINT
    fno_referer: str = _FNO_REFERER
    etf_endpoint: str = _ETF_ENDPOINT
    etf_referer: str = _ETF_REFERER


# ══════════════════════════════════════════════════════════════════════════════
# Mutable intermediate used only during a build
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class _SymbolAccumulator:
    """Mutable builder-scoped scratchpad for one symbol.

    Converted to the frozen ``SymbolMeta`` at the end of a build. Keeping
    this mutable keeps the accumulation logic readable; the external
    contract is still immutable.
    """
    symbol: str
    sector: str = "Unknown"
    industry: str = "Unknown"
    indices: set[str] = field(default_factory=set)
    is_fno: bool = False
    is_etf: bool = False
    etf_meta: ETFMeta | None = None

    def to_meta(self) -> SymbolMeta:
        return SymbolMeta(
            symbol=self.symbol,
            sector=self.sector,
            industry=self.industry,
            indices=frozenset(self.indices),
            is_fno=self.is_fno,
            is_etf=self.is_etf,
            etf_meta=self.etf_meta,
        )


# ══════════════════════════════════════════════════════════════════════════════
# The builder
# ══════════════════════════════════════════════════════════════════════════════

class UniverseBuilder:
    """Build a ``Universe`` by calling the configured NSE endpoints in one
    coordinated pass.

    Construction is cheap; ``build()`` does the network I/O. Idempotent —
    calling ``build()`` twice produces two independent ``Universe``
    objects, both valid.
    """

    def __init__(
        self,
        nse_client: NSEClient,
        config: UniverseConfig | None = None,
    ) -> None:
        self._nse = nse_client
        self._config = config if config is not None else UniverseConfig()

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def build(self) -> Universe:
        """Fetch every configured endpoint, accumulate, emit a ``Universe``.

        Raises:
            UniverseBuildError: Every endpoint failed and no data was
                collected.
        """
        acc: dict[str, _SymbolAccumulator] = {}
        successes = 0

        # ── Broad market indices ─────────────────────────────────────────
        for index_name in self._config.broad_indices:
            added = self._fetch_index(index_name, sector=None, accumulator=acc)
            if added > 0:
                successes += 1

        # ── Sectoral indices (narrower first so narrower wins) ──────────
        for index_name, sector in self._config.sectoral_indices:
            added = self._fetch_index(index_name, sector=sector, accumulator=acc)
            if added > 0:
                successes += 1

        # ── F&O universe ────────────────────────────────────────────────
        if self._config.include_fno:
            if self._fetch_fno(acc):
                successes += 1

        # ── ETF universe ────────────────────────────────────────────────
        if self._config.include_etfs:
            if self._fetch_etfs(acc):
                successes += 1

        if successes == 0 or not acc:
            raise UniverseBuildError(
                "UniverseBuilder.build: every NSE endpoint failed or returned empty; "
                "no universe could be built"
            )

        symbols = {sym: a.to_meta() for sym, a in acc.items()}
        return Universe(symbols=symbols, built_at=pd.Timestamp.now("UTC"))

    # ══════════════════════════════════════════════════════════════════════
    # Private fetch helpers
    # ══════════════════════════════════════════════════════════════════════

    def _fetch_index(
        self,
        index_name: str,
        *,
        sector: str | None,
        accumulator: dict[str, _SymbolAccumulator],
    ) -> int:
        """Fetch one index's constituents and fold into ``accumulator``.

        Returns the number of symbols added or updated. Zero indicates the
        fetch failed or the payload was empty.
        """
        payload = self._nse.fetch(
            self._config.index_endpoint,
            referer=self._config.index_referer,
            params={"index": index_name},
        )
        if not payload:
            logger.warning("universe: index %r fetch returned no payload", index_name)
            return 0

        constituents = _extract_index_constituents(payload)
        if not constituents:
            logger.warning("universe: index %r returned zero constituents", index_name)
            return 0

        for symbol, industry in constituents:
            a = accumulator.setdefault(symbol, _SymbolAccumulator(symbol=symbol))
            a.indices.add(index_name)
            # Industry comes from the constituent row even on broad indices.
            if industry and a.industry == "Unknown":
                a.industry = industry
            # Sector comes from sectoral indices only — broad indices pass None.
            if sector and a.sector == "Unknown":
                a.sector = sector
        return len(constituents)

    def _fetch_fno(self, accumulator: dict[str, _SymbolAccumulator]) -> bool:
        """Mark all symbols in the F&O endpoint as ``is_fno=True``.

        Returns True iff the fetch yielded a usable list.
        """
        payload = self._nse.fetch(
            self._config.fno_endpoint,
            referer=self._config.fno_referer,
        )
        if not payload:
            logger.warning("universe: F&O fetch returned no payload")
            return False

        fno_symbols = _extract_fno_symbols(payload)
        if not fno_symbols:
            logger.warning("universe: F&O fetch returned zero symbols")
            return False

        for symbol in fno_symbols:
            a = accumulator.setdefault(symbol, _SymbolAccumulator(symbol=symbol))
            a.is_fno = True
        return True

    def _fetch_etfs(self, accumulator: dict[str, _SymbolAccumulator]) -> bool:
        """Add all ETF listings with ``is_etf=True`` and populated ``ETFMeta``.

        Returns True iff the fetch yielded a usable list.
        """
        payload = self._nse.fetch(
            self._config.etf_endpoint,
            referer=self._config.etf_referer,
        )
        if not payload:
            logger.warning("universe: ETF fetch returned no payload")
            return False

        etfs = _extract_etfs(payload)
        if not etfs:
            logger.warning("universe: ETF fetch returned zero rows")
            return False

        for symbol, meta in etfs:
            a = accumulator.setdefault(symbol, _SymbolAccumulator(symbol=symbol))
            a.is_etf = True
            # ETFs and F&O are mutually exclusive in the SymbolMeta contract;
            # if a symbol somehow appears in both, the ETF classification
            # wins because ETFs never have vanilla F&O.
            a.is_fno = False
            a.etf_meta = meta
        return True


# ══════════════════════════════════════════════════════════════════════════════
# Payload parsers — isolated so tests can parametrise them independently
# ══════════════════════════════════════════════════════════════════════════════

def _extract_index_constituents(payload: dict | list) -> list[tuple[str, str]]:
    """Return ``[(symbol, industry), ...]`` from an equity-stockIndices payload.

    NSE's actual response shape (validated by nimbus_v2)::

        {
          "data": [
            {
              "symbol": "NIFTY 200",
              "meta": {}
            },
            {
              "symbol": "RELIANCE",
              "meta": {
                "symbol": "RELIANCE",
                "companyName": "Reliance Industries Limited",
                "industry": "Refineries",
                "isin": "INE002A01018"
              }
            },
            ...
          ]
        }

    Industry lives under ``row["meta"]["industry"]``. The first row is
    the index itself (empty or missing ``meta``) — skipped.
    """
    if not isinstance(payload, dict):
        return []
    data = payload.get("data")
    if not isinstance(data, list):
        return []
    out: list[tuple[str, str]] = []
    for row in data:
        if not isinstance(row, dict):
            continue
        meta = row.get("meta") or {}
        # Symbol: prefer meta.symbol, fall back to top-level symbol.
        symbol = meta.get("symbol") or row.get("symbol") or ""
        industry = meta.get("industry") or ""
        if not isinstance(symbol, str) or not symbol:
            continue
        # Skip the synthetic index row (first row, no meta / no industry).
        if not industry and symbol.upper().startswith("NIFTY"):
            continue
        out.append((symbol.upper().strip(), industry.strip()))
    return out


def _extract_fno_symbols(payload: dict | list) -> list[str]:
    """Extract symbol strings from the F&O securities payload.

    NSE's shape varies across endpoints; this parser handles the two
    commonly-seen shapes:

    - ``{"data": [{"symbol": "RELIANCE", ...}, ...]}``
    - ``[{"symbol": "RELIANCE", ...}, ...]``
    """
    rows: list = []
    if isinstance(payload, dict):
        data = payload.get("data")
        if isinstance(data, list):
            rows = data
    elif isinstance(payload, list):
        rows = payload
    out: list[str] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        symbol = row.get("symbol")
        if isinstance(symbol, str) and symbol:
            out.append(symbol.upper())
    return out


def _extract_etfs(payload: dict | list) -> list[tuple[str, ETFMeta]]:
    """Extract ETF entries and their metadata from the NSE ETF endpoint.

    Shape observed::

        {
          "data": [
            {
              "symbol": "NIFTYBEES",
              "underlying": "Nifty 50",
              "assetsUnderManagement": "12345.67",
              ...
            },
            ...
          ]
        }

    Missing fields become ``None`` on the returned ``ETFMeta``. Non-dict
    rows and rows without a usable symbol are skipped silently.
    """
    if not isinstance(payload, dict):
        return []
    data = payload.get("data")
    if not isinstance(data, list):
        return []
    out: list[tuple[str, ETFMeta]] = []
    for row in data:
        if not isinstance(row, dict):
            continue
        symbol = row.get("symbol")
        if not isinstance(symbol, str) or not symbol:
            continue

        meta = ETFMeta(
            underlying_asset=_safe_str(row.get("underlying")),
            tracking_index=_safe_str(row.get("indexName") or row.get("underlying")),
            aum_crore=_safe_float(
                row.get("assetsUnderManagement") or row.get("aum"),
            ),
            expense_ratio=_safe_float(row.get("expenseRatio")),
        )
        out.append((symbol.upper(), meta))
    return out


def _safe_str(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    trimmed = value.strip()
    return trimmed or None


def _safe_float(value: object) -> float | None:
    if value is None:
        return None
    try:
        # NSE often emits strings like "1,234.56".
        if isinstance(value, str):
            value = value.replace(",", "").strip()
            if not value or value == "-":
                return None
        return float(value)
    except (TypeError, ValueError):
        return None
