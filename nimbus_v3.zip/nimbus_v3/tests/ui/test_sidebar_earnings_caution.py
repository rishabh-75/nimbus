"""Tests for the earnings-caution row in :class:`nimbus_v3.ui.sidebar.Sidebar`.

Standalone test file — does NOT import from the same modules as
``test_sidebar.py``, which currently fails collection due to
architectural drift unrelated to this feature.
"""
from __future__ import annotations

from datetime import date

import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.data.earnings_calendar import EarningsCaution
from nimbus_v3.ui.sidebar import Sidebar
from nimbus_v3.ui.theme import GOLD


@pytest.fixture(scope="module")
def qapp():
    """One QApplication per test module — Qt requires it for any
    widget construction even under offscreen rendering."""
    app = QApplication.instance() or QApplication([])
    yield app


# ══════════════════════════════════════════════════════════════════════════════
# set_earnings_caution — single-row state machine
# ══════════════════════════════════════════════════════════════════════════════


class TestSetEarningsCaution:
    """The sidebar exposes one public method for this feature.
    Three input states (None / 0 sessions / N sessions) drive three
    output states on the label."""

    def test_none_clears_row(self, qapp):    # noqa: ARG002
        s = Sidebar()
        # Seed a non-empty state first.
        s.set_earnings_caution(EarningsCaution(
            symbol="X", next_event_date=date(2026, 5, 28),
            sessions_away=1, purpose="Financial Results",
        ))
        assert s._earnings_caution_lbl.text() != ""

        s.set_earnings_caution(None)
        assert s._earnings_caution_lbl.text() == ""

    def test_zero_sessions_says_today(self, qapp):    # noqa: ARG002
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="RELIANCE", next_event_date=date(2026, 5, 28),
            sessions_away=0, purpose="Financial Results",
        ))
        text = s._earnings_caution_lbl.text()
        assert "EARNINGS TODAY" in text
        assert "28 May" in text

    def test_one_session_singular(self, qapp):    # noqa: ARG002
        """Singular grammar at 1 — 'session', not 'sessions'."""
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="INFY", next_event_date=date(2026, 5, 29),
            sessions_away=1, purpose="Financial Results",
        ))
        text = s._earnings_caution_lbl.text()
        assert "in 1 session" in text
        assert "sessions" not in text    # avoid the plural form
        assert "29 May" in text

    def test_multiple_sessions_plural(self, qapp):    # noqa: ARG002
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="TCS", next_event_date=date(2026, 6, 2),
            sessions_away=3, purpose="Financial Results",
        ))
        text = s._earnings_caution_lbl.text()
        assert "in 3 sessions" in text
        assert "02 Jun" in text

    def test_caution_uses_gold_colour(self, qapp):    # noqa: ARG002
        """Theme integration: caution sits in the same colour tier
        as HALF size / STALE indicators."""
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="X", next_event_date=date(2026, 5, 28),
            sessions_away=1, purpose="Financial Results",
        ))
        css = s._earnings_caution_lbl.styleSheet()
        # GOLD constant pasted into the stylesheet verbatim.
        assert GOLD in css

    def test_warning_glyph_present(self, qapp):    # noqa: ARG002
        """The leading ⚠ glyph anchors the operator's eye. Keep it
        visible by contract."""
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="X", next_event_date=date(2026, 5, 28),
            sessions_away=1, purpose="Financial Results",
        ))
        assert "⚠" in s._earnings_caution_lbl.text()

    def test_clear_signals_resets_earnings_row(self, qapp):    # noqa: ARG002
        """Wiping the sidebar (symbol change to empty / app reset)
        must also clear the caution — otherwise the operator could
        see a stale caution attributed to the wrong symbol."""
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="X", next_event_date=date(2026, 5, 28),
            sessions_away=1, purpose="Financial Results",
        ))
        assert s._earnings_caution_lbl.text() != ""

        s.clear_signals()
        assert s._earnings_caution_lbl.text() == ""

    def test_negative_sessions_treated_as_today(self, qapp):    # noqa: ARG002
        """Edge case: if check_symbol ever returned a stale-past
        caution (sessions_away < 0), the rendering must not crash
        or produce 'in -1 sessions'. Coerce to 'TODAY' as the
        least-misleading display."""
        s = Sidebar()
        s.set_earnings_caution(EarningsCaution(
            symbol="X", next_event_date=date(2026, 5, 27),
            sessions_away=-1, purpose="Financial Results",
        ))
        text = s._earnings_caution_lbl.text()
        assert "EARNINGS TODAY" in text
        assert "-1" not in text
