"""Research utilities — analyses that produce offline artefacts
rather than live-app behaviour. Not imported by the cockpit;
not on the deploy critical path.
"""
