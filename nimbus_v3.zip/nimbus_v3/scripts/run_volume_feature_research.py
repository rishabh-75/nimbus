"""scripts/run_volume_feature_research.py — candidate volume-feature ablation.

Research harness for deciding whether longer-horizon volume features
add forward-return edge beyond the existing ``vol_chg_20``.

Features tested
---------------
  vol_chg_20   (baseline, currently used)
  vol_chg_30   N-day-vs-prior-N-day at 30 days
  vol_chg_45   N-day-vs-prior-N-day at 45 days
  vol_chg_60   N-day-vs-prior-N-day at 60 days
  vol_ratio_60 last-5d-mean / last-60d-mean (cross-window)

What's measured
---------------
For each feature, two signatures:

  **distribution**: feature < threshold AND ROC_5 < 0
      A weak week combined with volume collapse. Currently only
      kept on EUPHORIA per ablation; we test whether longer
      windows make this signal work on MID/LATE too.

  **accumulation**: feature > threshold AND price showing
      basing-then-breakout (close > SMA_20 AND ROC_5 > 0 AND
      close within 15% of 60d high not 60d low)
      The AWL-style pattern the user flagged: volume starts
      ramping off a capitulation base. If this earns edge, it's
      candidate material for a new EARLY/MID accumulation tag.

Also computed: decile forward returns by feature value (a feature
that monotonically separates forward returns across deciles is a
good candidate regardless of which threshold is picked).

How to interpret
----------------
A working accumulation signal will show:
  - fired cohort (high volume relative to baseline + price rising)
    has higher fwd10/fwd20 than unfired
  - delta_pp positive and large, t-stat positive and |t| > 2

A working distribution signal: opposite direction.

A noise feature will show all deltas near zero — the volume
signature doesn't predict forward returns regardless of window.

Run::

    python scripts/run_volume_feature_research.py

Writes:
  - data/volume_feature_research.csv
  - stdout report
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nimbus_v3.research.equity_universe import load_equity_panel   # noqa: E402
from scripts.run_phase_calibration import compute_features         # noqa: E402

logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("vol_research")


# ══════════════════════════════════════════════════════════════════════
# Signatures
# ══════════════════════════════════════════════════════════════════════

FEATURES = ["vol_chg_20", "vol_chg_30", "vol_chg_45", "vol_chg_60", "vol_ratio_60"]


def welch_t(a: np.ndarray, b: np.ndarray) -> float:
    """Welch's t-stat; returns nan if either sample too small."""
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(va / na + vb / nb)
    if denom == 0 or not np.isfinite(denom):
        return float("nan")
    return float((a.mean() - b.mean()) / denom)


def distribution_signature(
    feats: pd.DataFrame, feature: str, threshold: float,
) -> np.ndarray:
    """Distribution-style: feature < threshold AND ROC_5 < 0.

    Both conditions together capture "volume collapsing on price
    weakness" — the existing distribution topology, generalised to
    test whether longer windows add power.
    """
    return (
        feats[feature].to_numpy() < threshold
    ) & (feats["roc_5"].to_numpy() < 0)


def accumulation_signature(
    feats: pd.DataFrame, feature: str, threshold: float,
) -> np.ndarray:
    """Accumulation-style: feature > threshold AND basing-then-breakout.

    Approximates the AWL topology — price recovering off a capitulation
    low with volume ramping. Conditions:
      - feature > threshold (volume above baseline)
      - roc_5 > 0 (last week up)
      - close > sma_20 (above short-term mean)
      - close < 1.15 * close_60d_low (within 15% of 60d low,
        i.e. still a basing setup, not a late-trend stock)

    The last condition distinguishes fresh accumulation from stretched
    stocks with strong current volume — those would be caught by
    EUPHORIA/LATE gates separately.
    """
    close = feats["close"].to_numpy()
    roc_5 = feats["roc_5"].to_numpy()
    sma_20 = feats["sma_20"].to_numpy()
    # Approximate the 60d low from the sma_50 and a 3σ buffer; without
    # a running min we can't compute this exactly in a single column.
    # Use sma_50 * 0.85 as a proxy for the 60d low region — a stock
    # within 15% of its 60d low is near ~0.85-1.15× its 60d mean, which
    # is roughly sma_50 for slow-moving bases.
    sma_50 = feats["sma_50"].to_numpy()
    near_base = close < 1.15 * sma_50      # within 15% of base
    vol_ok = feats[feature].to_numpy() > threshold
    return vol_ok & (roc_5 > 0) & (close > sma_20) & near_base


def ablate_signature(
    feats: pd.DataFrame,
    signature_name: str,
    mask: np.ndarray,
    fwd_col: str,
) -> dict:
    """Split rows by signature mask, measure forward-return delta."""
    fwd = feats[fwd_col].to_numpy()
    valid = np.isfinite(fwd)
    fired = valid & mask
    unfired = valid & ~mask
    f_ret = fwd[fired]
    u_ret = fwd[unfired]
    return {
        "signature": signature_name,
        "horizon": fwd_col,
        "n_fired": int(fired.sum()),
        "n_unfired": int(unfired.sum()),
        "fired_pct": float(f_ret.mean() * 100) if len(f_ret) else float("nan"),
        "unfired_pct": float(u_ret.mean() * 100) if len(u_ret) else float("nan"),
        "delta_pp": (
            float((f_ret.mean() - u_ret.mean()) * 100)
            if len(f_ret) and len(u_ret) else float("nan")
        ),
        "t_stat": welch_t(f_ret, u_ret),
    }


def decile_report(feats: pd.DataFrame, feature: str, horizon: str) -> pd.DataFrame:
    """Bucket feats by decile of ``feature`` and report mean forward return."""
    valid = feats[np.isfinite(feats[feature]) & np.isfinite(feats[horizon])]
    if len(valid) < 1000:
        return pd.DataFrame()
    deciles = pd.qcut(valid[feature], 10, labels=False, duplicates="drop")
    grouped = (
        valid.assign(decile=deciles)
             .groupby("decile", observed=True)
             .agg(n=(horizon, "size"), mean_fwd=(horizon, "mean"),
                  feature_min=(feature, "min"),
                  feature_max=(feature, "max"))
    )
    grouped["mean_fwd_pct"] = grouped["mean_fwd"] * 100
    return grouped


# ══════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════

def verdict(row: dict) -> str:
    if row["n_fired"] < 200:
        return "too few fires"
    d, t = row["delta_pp"], row["t_stat"]
    if np.isnan(d) or np.isnan(t):
        return "n/a"
    # For accumulation: positive delta is desired
    # For distribution: negative delta is desired
    sig = "acc" if "accumulation" in row["signature"] else "dist"
    if sig == "acc":
        if d >= 0.5 and t >= 2:
            return "STRONG working"
        if d >= 0.2 and t >= 1.5:
            return "weak working"
        if d <= -0.5 and t <= -2:
            return "STRONG HARMFUL"
        if d <= -0.2 and t <= -1.5:
            return "weak harmful"
    else:  # distribution
        if d <= -0.5 and t <= -2:
            return "STRONG working"
        if d <= -0.2 and t <= -1.5:
            return "weak working"
        if d >= 0.5 and t >= 2:
            return "STRONG HARMFUL"
        if d >= 0.2 and t >= 1.5:
            return "weak harmful"
    if abs(d) < 0.2 or abs(t) < 1:
        return "noise"
    return "inconclusive"


def print_signature_table(rows: list[dict]) -> None:
    hdr = (
        f"  {'signature':28s}  {'horizon':8s}  {'n_fire':>7s}  {'n_keep':>7s}  "
        f"{'fired%':>8s}  {'kept%':>8s}  {'Δ pp':>8s}  {'t':>7s}  verdict"
    )
    sep = "─" * len(hdr)
    print(sep)
    print(hdr)
    print(sep)
    for r in rows:
        v = verdict(r)
        print(
            f"  {r['signature']:28s}  {r['horizon']:8s}  "
            f"{r['n_fired']:>7,d}  {r['n_unfired']:>7,d}  "
            f"{r['fired_pct']:>+7.3f}  {r['unfired_pct']:>+7.3f}  "
            f"{r['delta_pp']:>+7.3f}  {r['t_stat']:>+6.2f}  {v}"
        )
    print(sep)


def print_decile_table(grouped: pd.DataFrame, feature: str, horizon: str) -> None:
    print(f"\nDecile report: {feature} vs {horizon}")
    print("─" * 60)
    print(f"  {'decile':>6s}  {'n':>7s}  {'feature range':>22s}  {'fwd%':>8s}")
    for decile, row in grouped.iterrows():
        rng = f"{row['feature_min']:+7.1f} to {row['feature_max']:+7.1f}"
        print(
            f"  {decile:>6}  {int(row['n']):>7,d}  {rng:>22s}  "
            f"{row['mean_fwd_pct']:>+7.3f}"
        )
    # Spread between bottom and top decile
    spread = grouped.iloc[-1]["mean_fwd_pct"] - grouped.iloc[0]["mean_fwd_pct"]
    print(f"  Spread (top decile − bottom decile): {spread:+.3f}pp")
    print("─" * 60)


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Loading equity panel …")
    panel = load_equity_panel(verbose=False)
    log.info("Panel: %d symbols", len(panel))

    all_rows: list[pd.DataFrame] = []
    for sym, df in panel.items():
        feats = compute_features(df)
        if len(feats) < 100:
            continue
        feats["symbol"] = sym
        all_rows.append(feats)

    feats = pd.concat(all_rows, ignore_index=True)
    log.info("Feature table: %d rows × %d cols", len(feats), len(feats.columns))

    # Verify all candidate features present
    missing = [f for f in FEATURES if f not in feats.columns]
    if missing:
        log.error("Missing volume features: %s", missing)
        sys.exit(1)

    # ── Decile reports — does the feature monotonically separate
    # forward returns? This is a threshold-free sanity check.
    print("\n" + "═" * 72)
    print("DECILE REPORTS — is there a monotonic relationship?")
    print("═" * 72)
    print("A feature with real information will show a clear progression")
    print("from bottom-decile fwd return to top-decile fwd return.")
    for feature in FEATURES:
        for horizon in ("fwd_10d", "fwd_20d"):
            grouped = decile_report(feats, feature, horizon)
            if len(grouped):
                print_decile_table(grouped, feature, horizon)

    # ── Signature ablation — each feature tested as distribution
    # and as accumulation at a reasonable threshold. The thresholds
    # below are starting points; the decile report shows where
    # natural breakpoints live so future runs can refine.
    print("\n" + "═" * 72)
    print("DISTRIBUTION SIGNATURES — feature < threshold AND ROC_5 < 0")
    print("═" * 72)
    print("A working distribution signal has delta_pp NEGATIVE and |t| ≥ 2.")
    # For N-vs-prior-N features, -40% is the current threshold; test -30
    # and -50 as well. For vol_ratio_60, use different thresholds.
    dist_tests = [
        ("vol_chg_20", -40.0),
        ("vol_chg_30", -40.0),
        ("vol_chg_45", -40.0),
        ("vol_chg_60", -40.0),
        ("vol_ratio_60", -30.0),
    ]
    dist_rows: list[dict] = []
    for feature, threshold in dist_tests:
        sig_name = f"{feature} < {threshold:.0f} + ROC_5<0"
        mask = distribution_signature(feats, feature, threshold)
        for horizon in ("fwd_10d", "fwd_20d"):
            row = ablate_signature(feats, sig_name, mask, horizon)
            dist_rows.append(row)
    print_signature_table(dist_rows)

    print("\n" + "═" * 72)
    print("ACCUMULATION SIGNATURES — vol ramping + price basing-then-breakout")
    print("═" * 72)
    print("A working accumulation signal has delta_pp POSITIVE and t ≥ 2.")
    acc_tests = [
        ("vol_chg_20",   +30.0),
        ("vol_chg_30",   +30.0),
        ("vol_chg_45",   +30.0),
        ("vol_chg_60",   +30.0),
        ("vol_ratio_60", +30.0),
        # Also test a more aggressive threshold on ratio_60
        ("vol_ratio_60", +50.0),
        ("vol_ratio_60", +100.0),
    ]
    acc_rows: list[dict] = []
    for feature, threshold in acc_tests:
        sig_name = f"accumulation {feature} > {threshold:.0f}"
        mask = accumulation_signature(feats, feature, threshold)
        for horizon in ("fwd_10d", "fwd_20d"):
            row = ablate_signature(feats, sig_name, mask, horizon)
            acc_rows.append(row)
    print_signature_table(acc_rows)

    # Persist full results
    all_result_rows = dist_rows + acc_rows
    out_df = pd.DataFrame(all_result_rows)
    out_path = Path("data/volume_feature_research.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    log.info("\nFull results written to %s", out_path)

    # Summary
    print("\n" + "═" * 72)
    print("SUMMARY")
    print("═" * 72)
    working = [r for r in all_result_rows if verdict(r).endswith("working")]
    if working:
        print(f"{len(working)} signature × horizon pair(s) earned edge:")
        for r in working:
            print(f"  • {r['signature']} @ {r['horizon']}: "
                  f"Δ {r['delta_pp']:+.2f}pp  t={r['t_stat']:+.2f}  ({verdict(r)})")
    else:
        print("No signatures earned empirical edge. Volume windows may not")
        print("be the right axis for this market — consider price-structure")
        print("features (52w high proximity, basing duration) instead.")


if __name__ == "__main__":
    main()
