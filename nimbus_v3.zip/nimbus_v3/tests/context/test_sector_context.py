"""Tests for SectorContextProvider."""
from __future__ import annotations

from unittest.mock import MagicMock

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.context.sector_context import (
    SectorContextProvider,
    _annualised_vol,
    _classify_rs,
    _rs_20d,
    _vol_zscore,
)
from nimbus_v3.core.types import RSRegime
from nimbus_v3.core.universe import SymbolMeta, Universe


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _series_with_returns(returns: list[float], start: float = 100.0) -> pd.DataFrame:
    closes = [start]
    for r in returns:
        closes.append(closes[-1] * (1 + r))
    idx = pd.bdate_range("2023-01-01", periods=len(closes))
    return pd.DataFrame({"Close": closes}, index=idx)


def _constant_noise_series(n: int = 400, vol: float = 0.012, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    log_rets = rng.normal(0, vol, size=n)
    closes = 100.0 * np.exp(np.cumsum(log_rets))
    idx = pd.bdate_range("2022-01-01", periods=n)
    return pd.DataFrame({"Close": closes}, index=idx)


def _minimal_universe(symbol: str, sector: str) -> Universe:
    return Universe(
        symbols={symbol: SymbolMeta(symbol=symbol, sector=sector)},
        built_at=pd.Timestamp("2024-05-01"),
    )


# ══════════════════════════════════════════════════════════════════════════════
# _classify_rs
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize(("rs", "expected"), [
    (None, RSRegime.NEUTRAL),
    (0.0, RSRegime.NEUTRAL),
    (2.9, RSRegime.NEUTRAL),
    (3.0, RSRegime.LEADING),
    (-2.9, RSRegime.NEUTRAL),
    (-3.0, RSRegime.LAGGING),
])
def test_classify_rs(rs, expected) -> None:
    assert _classify_rs(rs, leading=3.0, lagging=-3.0) == expected


# ══════════════════════════════════════════════════════════════════════════════
# _rs_20d
# ══════════════════════════════════════════════════════════════════════════════

def test_rs_20d_positive_when_sector_outperforms() -> None:
    # 21 bars → 20-bar ROC over the last window.
    # Sector: +1% per bar; broad: 0% per bar.
    sector = _series_with_returns([0.01] * 30)
    broad = _series_with_returns([0.0] * 30)
    rs = _rs_20d(sector, broad, sector.index[-1])
    assert rs is not None and rs > 0


def test_rs_20d_none_when_insufficient_history() -> None:
    short = _series_with_returns([0.01] * 5)
    assert _rs_20d(short, short, short.index[-1]) is None


# ══════════════════════════════════════════════════════════════════════════════
# _annualised_vol
# ══════════════════════════════════════════════════════════════════════════════

def test_annualised_vol_scales_with_underlying() -> None:
    low = _constant_noise_series(n=100, vol=0.005, seed=1)
    high = _constant_noise_series(n=100, vol=0.02, seed=2)
    v_low = _annualised_vol(low, low.index[-1], window=20)
    v_high = _annualised_vol(high, high.index[-1], window=20)
    assert v_low is not None and v_high is not None
    assert v_high > v_low


def test_annualised_vol_none_on_short_history() -> None:
    short = _constant_noise_series(n=5)
    assert _annualised_vol(short, short.index[-1], window=20) is None


# ══════════════════════════════════════════════════════════════════════════════
# _vol_zscore
# ══════════════════════════════════════════════════════════════════════════════

def test_vol_zscore_none_on_insufficient_history() -> None:
    short = _constant_noise_series(n=50)
    assert _vol_zscore(short, short.index[-1], short_window=20, baseline_window=252) is None


def test_vol_zscore_positive_when_current_higher_than_baseline() -> None:
    baseline = _constant_noise_series(n=260, vol=0.005, seed=1)
    # Append a high-vol tail.
    tail = _constant_noise_series(n=30, vol=0.03, seed=2)
    tail.index = pd.bdate_range(
        start=baseline.index[-1] + pd.Timedelta(days=1),
        periods=len(tail),
    )
    combined = pd.concat([baseline, tail])
    z = _vol_zscore(combined, combined.index[-1], short_window=20, baseline_window=252)
    assert z is not None and z > 0


# ══════════════════════════════════════════════════════════════════════════════
# Provider
# ══════════════════════════════════════════════════════════════════════════════

def _loader_returning(mapping: dict[str, pd.DataFrame]) -> MagicMock:
    loader = MagicMock()
    loader.load.side_effect = lambda ticker: mapping.get(ticker, pd.DataFrame())
    return loader


def test_provider_returns_none_for_unknown_symbol() -> None:
    universe = _minimal_universe("RELIANCE", "Energy")
    loader = _loader_returning({})
    provider = SectorContextProvider(loader, universe)
    ctx = provider.build(symbol="UNKNOWN", asof_date=pd.Timestamp("2024-05-01"))
    assert ctx is None


def test_provider_emits_sector_from_universe_meta() -> None:
    universe = _minimal_universe("HDFCBANK", "Banking")
    sector_hist = _series_with_returns([0.01] * 30)
    broad_hist = _series_with_returns([0.0] * 30)
    loader = _loader_returning({"^NSEBANK": sector_hist, "^CRSLDX": broad_hist})
    provider = SectorContextProvider(loader, universe)
    ctx = provider.build(symbol="HDFCBANK", asof_date=sector_hist.index[-1])
    assert ctx is not None
    assert ctx.sector_name == "Banking"
    assert ctx.rs_regime == RSRegime.LEADING
    assert ctx.sector_type is None   # Phase 7 research territory


def test_provider_falls_back_when_sector_has_no_ticker() -> None:
    universe = _minimal_universe("X", "UnknownSector")
    broad_hist = _series_with_returns([0.0] * 30)
    loader = _loader_returning({"^CRSLDX": broad_hist})
    provider = SectorContextProvider(loader, universe)
    ctx = provider.build(symbol="X", asof_date=broad_hist.index[-1])
    assert ctx is not None
    assert ctx.sector_name == "UnknownSector"
    assert ctx.rs_regime == RSRegime.NEUTRAL
    assert ctx.rs_20d == 0.0
    assert ctx.realized_vol_20d == 0.0
