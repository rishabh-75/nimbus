"""Tests for nimbus_v3.compute.breadth_regime."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.breadth_regime import (
    NEUTRAL,
    RISK_OFF,
    RISK_ON,
    SLOPE_LOOKBACK,
    classify_regime,
)


def _breadth(pct50, ad, nhnl, n=40):
    idx = pd.bdate_range("2024-01-01", periods=n)
    return pd.DataFrame({
        "pct_above_sma50": pd.Series(pct50, index=idx, dtype=float),
        "ad_line": pd.Series(ad, index=idx, dtype=float),
        "nh_nl_diff": pd.Series(nhnl, index=idx, dtype=int),
    })


def test_insufficient_history_returns_dash():
    b = _breadth([60] * 5, [10] * 5, [5] * 5, n=5)
    assert classify_regime(b).label == "—"


def test_all_signals_on_is_risk_on():
    n = 40
    # rising pct50 (60 now, was 40), rising ad, positive nh-nl, level>50
    pct = list(np.linspace(40, 70, n))
    ad = list(np.linspace(0, 500, n))
    nhnl = [5] * n
    r = classify_regime(_breadth(pct, ad, nhnl, n))
    assert r.label == RISK_ON
    assert r.signals_on == 4
    assert r.level and r.expand and r.ad and r.nhnl


def test_all_signals_off_is_risk_off():
    n = 40
    pct = list(np.linspace(60, 30, n))   # falling, ends < 50
    ad = list(np.linspace(500, 0, n))    # falling
    nhnl = [-5] * n                       # negative
    r = classify_regime(_breadth(pct, ad, nhnl, n))
    assert r.label == RISK_OFF
    assert r.signals_on <= 1


def test_mixed_signals_is_neutral():
    n = 40
    # level>50 and rising, but ad falling and nh-nl negative → 2 on
    pct = list(np.linspace(40, 70, n))
    ad = list(np.linspace(500, 0, n))
    nhnl = [-3] * n
    r = classify_regime(_breadth(pct, ad, nhnl, n))
    assert r.label == NEUTRAL
    assert r.signals_on == 2


def test_index_adds_fifth_signal():
    n = 60
    pct = list(np.linspace(40, 70, n))
    ad = list(np.linspace(0, 500, n))
    nhnl = [5] * n
    b = _breadth(pct, ad, nhnl, n)
    idx = pd.Series(np.linspace(100, 200, n), index=b.index)   # rising index
    r = classify_regime(b, idx)
    assert r.n_signals == 5
