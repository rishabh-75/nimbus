"""nimbus_v3.compute.confluence — cross-view industry confluence.

Combines the outputs of the four Market-Pulse views into a single ranked
read of *where the signals agree* for rotating capital across industries:

  * Relative strength  — ROC + RRG RS-Ratio (cross-sectional momentum,
    the empirically robust rotation factor).
  * Rotation direction — RRG quadrant + maturity (is the move improving
    and fresh, or fading and late).
  * Seasonal edge      — the current calendar month's average return,
    DISCOUNTED by that cell's reliability (thin/outlier-driven seasonal
    signals demote themselves rather than being trusted at face value).

Design principles (these are deliberate, money-on-the-line choices):

1. **Confluence, not forecast.** The score states that several lenses
   agree *right now*; it never claims an industry will rise. Agreement is
   a statable fact; a prediction is not.

2. **Reliability-weighted, not naive-averaged.** Each factor enters at
   equal nominal weight but is multiplied by its own confidence before
   combining, so a 2/100-reliable seasonal cell contributes ~nothing
   while a 90/100 one earns full weight. The demotion is data-driven and
   visible, not a hard-coded opinion about which factor matters.

3. **Relative by construction.** Factors are percentile-ranked within the
   current cross-section of industries — the score answers "where does
   this industry stand versus the others I could rotate into now," which
   is exactly the rotation question. It is NOT comparable across days in
   absolute terms; it is a standing within today's universe.

4. **Regime is context, not a gate.** Market breadth rides alongside as a
   banner (see :class:`ConfluenceResult.regime_*`) but does NOT scale the
   scores: a dull tape can still have bright spots worth rotating toward,
   and dampening every score would hide exactly the leadership a rotation
   tool exists to surface.

5. **Auditable.** Every component — raw value, percentile, and confidence
   — is carried on the row so the composite is never a black box.

This is a pure CONSUMER of the existing engines: it recomputes nothing
and touches no engine internals. It is the fifth reader of the shared
industry composites, aligning the four results by industry name.
"""
from __future__ import annotations

from dataclasses import dataclass

from nimbus_v3.compute.breadth_regime import RegimeState
from nimbus_v3.compute.industry_rotation import RotationResult
from nimbus_v3.compute.market_pulse_common import industry_rs_excess
from nimbus_v3.compute.rrg import Maturity, Quadrant, RRGResult
from nimbus_v3.compute.industry_seasonality import SeasonalityGrid


#: The three factors do NOT enter as a weighted average. The score is
#: multiplicative: STRENGTH percentile is the base magnitude being ranked,
#: and direction and seasonality are quality GATES on it (see the score
#: model below). Strength is therefore the primary factor by construction —
#: the gates can only discount it toward their floors, never add an
#: independent leg that outvotes it. Seasonality in particular is a TILT
#: (floor 0.55): it reorders names of comparable strength but cannot lift a
#: weaker name over a clearly stronger one.
#: Quadrant → a 0..1 directional desirability for rotation. Leading and
#: Improving are where you want to rotate toward (strong, or strengthening
#: from weakness); Weakening and Lagging are exits / avoids. Used for the
#: DIRECTION raw value shown in the table (the ranking uses the gate below).
_QUADRANT_SCORE: dict[Quadrant, float] = {
    Quadrant.LEADING: 1.00,
    Quadrant.IMPROVING: 0.75,
    Quadrant.WEAKENING: 0.35,
    Quadrant.LAGGING: 0.00,
}

#: Maturity → a multiplier on the direction raw value. FRESH/TURNING mean
#: the move is building (early — good); MATURING means it's fading (late);
#: STABLE is neutral; EXTENDED is strong-and-still-rising but stretched.
_MATURITY_MULT: dict[Maturity, float] = {
    Maturity.FRESH: 1.00,
    Maturity.TURNING: 0.90,
    Maturity.EXTENDED: 0.65,
    Maturity.STABLE: 0.70,
    Maturity.MATURING: 0.45,
}

# === The score model: strength magnitude, gated by direction & season ===
# score = strength_pct × direction_gate × seasonal_gate  (+ small lift)
# Direction and seasonality are multiplicative GATES on strength, not
# factors averaged with it — a high score requires all three to agree.

#: Direction gate = quadrant desirability × maturity multiplier. A
#: late/fading name cannot top the board however strong — you don't rotate
#: INTO an industry whose move is exhausting.
#:
#: IMPROVING was 1.00 — exactly equal to LEADING — which said a weak name
#: turning up is as good a rotation target as a confirmed leader. That was
#: a default, not a finding, and the measurements disagree with it:
#: rrg_lookback_probe (36 as-of dates, 8 RRG windows x 2 horizons on the
#: live panel) found LEADING the only consistently positive cohort, beating
#: IMPROVING in 15 of 16 cells, with IMPROVING often the WORST cohort on
#: the board at 20 days. It is now discounted to 0.90.
#:
#: Why 0.90 and not lower: nothing in that probe cleared |t|>2 and the
#: cells are not independent, so this is deliberately a TIE-BREAK — enough
#: to stop a turning name outranking a confirmed leader on equal strength,
#: not enough to demote a whole quadrant on thin evidence. Pushing it
#: toward WEAKENING (0.55) would be fitting noise. Raise it back to 1.00
#: to restore the old "Improving is as good as Leading" behaviour.
_DIRECTION_GATE: dict[Quadrant, float] = {
    Quadrant.LEADING: 1.00,
    Quadrant.IMPROVING: 0.90,
    Quadrant.WEAKENING: 0.55,
    Quadrant.LAGGING: 0.35,
}
#: Maturity component of the direction GATE (a multiplier on the quadrant
#: gate above). This is deliberately ORDERED the same way the maturity
#: multiplier used for the *displayed* Direction Score is — a fading move is
#: a worse rotation target than a stretched-but-still-rising one — so the
#: score and the column the operator reads never disagree on which
#: direction is better:
#:   FRESH / TURNING — the move is building (fresh leader, or turning up from
#:     weakness): no gate, this is exactly what a rotation tool wants.
#:   STABLE — steady, mild caution.
#:   EXTENDED — top-decile and STILL RISING but stretched: the froth
#:     caution, kept at its original 0.75 (still-rising strength is only
#:     mildly cautioned, not demoted below a fading name).
#:   MATURING — the move is FADING / late: the HARDEST caution among the
#:     favourable maturities. Previously this got the FULL gate (1.0) — so a
#:     fading leader outranked a still-rising (Extended) one purely because
#:     "Extended" was the only maturity that bit. That inverted the intended
#:     ordering and let a fading leader overpower the strongest, still-rising
#:     names. Now gated to 0.70, just below Extended.
#: Raise MATURING toward 1.0 to let fading leaders back up the board; the
#: ordering (fading < stretched < steady < building) mirrors the maturity
#: multiplier used for the displayed Direction Score, so score and column
#: never disagree on which direction is better.
_MATURITY_GATE: dict[Maturity, float] = {
    Maturity.FRESH: 1.00,
    Maturity.TURNING: 1.00,
    Maturity.STABLE: 0.90,
    Maturity.EXTENDED: 0.75,
    Maturity.MATURING: 0.70,
}

_FAVOURABLE_QUADRANTS = (Quadrant.LEADING, Quadrant.IMPROVING)

#: Seasonal gate floor. The seasonal gate is
#:   SEA_FLOOR + (1 - SEA_FLOOR) × (z · q)
#: where z = seasonal magnitude (percentile 0..1) and q = seasonal quality
#: (member-lumpiness-aware reliability 0..1). A perfect seasonal → gate 1.0
#: (no discount); a dead/lumpy/absent seasonal → gate = SEA_FLOOR. The
#: floor sets how hard a weak/lumpy seasonal bites: a dead seasonal keeps
#: (1 − FLOOR) of the strength away from the score, an elite one keeps all
#: of it. At 0.55 the seasonal is a TILT, not a gate — it can still reorder
#: names of comparable strength (a strong reliable calendar tailwind wins a
#: close call, a dead one loses it), but it can no longer near-veto a name
#: that is clearly the strongest, so STRENGTH is the dominant factor and
#: seasonality corroborates rather than overrides it. Lower this back toward
#: 0.20 to restore the aggressive "all three must corroborate" hard gate;
#: raise it further (→1.0) to fade seasonality out toward inert.
_SEASONAL_GATE_FLOOR: float = 0.55

#: Small squared lift (points added, capped by min(100, …)) for a
#: GENUINELY ELITE seasonal (z·q near 1) on a favourable-direction name.
#: Squared so only exceptional seasonals matter — a mediocre one adds ~0.
#: Lets a strong reliable seasonal nudge a moderate-strength name up a few
#: points without overturning strength as the primary factor. Halved (8→4)
#: alongside the raised floor so the calendar tailwind is a light tilt, not
#: a lever that lifts a moderate name over a clearly stronger one.
_SEASONAL_LIFT_MAX: float = 4.0

#: Breadth gate — a bottom-up PARTICIPATION check on strength. Strength is
#: the ADTV-weighted composite's momentum, which a couple of heavy members
#: can carry while most members don't participate (a narrow, top-heavy
#: move — fragile for rotation). The breadth gate discounts such moves.
#:
#: It is MARKET-RELATIVE, not absolute: an industry's breadth (fraction of
#: members above their own SMA50) is judged against the market's own
#: breadth, so "narrow" means narrow *versus the tape* — in a strong market
#: 60% participation is merely average, in a weak one it may be leadership.
#:
#:     rel  = breadth_industry − breadth_market
#:     gate = clamp(FLOOR + (1-FLOOR)·(1 + rel/SPREAD), FLOOR, 1.0)
#:
#: so an industry at/above market breadth → gate 1.0 (broad = neutral, per
#: the design), falling linearly to FLOOR once it is SPREAD below the tape.
#: FLOOR is gentle (breadth is corroboration, not a required leg of
#: confluence like direction/seasonality): a fully-narrow move loses
#: ~40%, enough to drop below a broad peer of equal strength but not to
#: veto a genuinely strong early move.
_BREADTH_GATE_FLOOR: float = 0.60
#: Participation gap (in fraction, i.e. 0.30 = 30 percentage points) below
#: market breadth at which the gate reaches its floor.
_BREADTH_GATE_SPREAD: float = 0.30


@dataclass(frozen=True)
class FactorRead:
    """One factor's contribution for one industry — fully auditable.

    ``value`` is the raw factor (the actual number, for judgment),
    ``percentile`` is its 0..100 standing within today's cross-section
    (what feeds the blend), and ``confidence`` is the 0..1 reliability
    the percentile is discounted by. ``detail`` is a short human label
    (e.g. the quadrant+maturity, or "40/100 reliable").
    """
    value: float
    percentile: float
    confidence: float
    detail: str = ""


@dataclass(frozen=True)
class ConfluenceRow:
    """One industry's confluence read across the three factors."""
    industry: str
    #: 0..100 reliability-weighted composite of the factor percentiles —
    #: the headline ranking number. Higher = more lenses agree this is a
    #: strong rotation candidate *relative to the other industries now*.
    score: float
    #: Overall 0..1 confidence = how much trustworthy signal backed the
    #: score (the sum of factor confidences that actually contributed).
    confidence: float
    strength: FactorRead       # relative strength (ROC + RRG RS-Ratio)
    direction: FactorRead      # RRG quadrant + maturity
    seasonal: FactorRead       # current-month seasonal edge (reliability-disc.)
    n_members: int
    #: Bottom-up participation: fraction (0..1) of members above their own
    #: SMA50. NaN when breadth wasn't supplied. Shown as the Breadth column.
    breadth: float = float("nan")
    #: The breadth gate actually applied to the score (0.6..1.0). 1.0 means
    #: broad participation (no discount); lower means a narrow move was
    #: discounted. Surfaced so the gate is auditable next to the raw breadth.
    breadth_gate: float = 1.0


@dataclass(frozen=True)
class ConfluenceResult:
    """All industries' confluence, ranked best-first, plus regime context."""
    rows: tuple[ConfluenceRow, ...]
    month: int                 # 1..12 — the calendar month the seasonal
    #                            factor was read for (context only).
    #: Market regime context (banner). Does NOT scale the scores.
    regime_label: str          # RISK_ON / NEUTRAL / RISK_OFF / "—"
    regime_signals_on: int
    regime_n_signals: int

    @property
    def has_data(self) -> bool:
        return len(self.rows) > 0

    def top(self, n: int) -> tuple[ConfluenceRow, ...]:
        return self.rows[:n]


def _percentiles(values: dict[str, float]) -> dict[str, float]:
    """Map ``{industry: raw_value}`` to ``{industry: percentile 0..100}``
    within the cross-section. NaN values get NaN percentile (they don't
    participate). Percentile = fraction of industries this one is ≥, so
    the best scores ~100 and the worst ~0. Robust to outliers (rank-based,
    not magnitude-based), which a z-score would not be.
    """
    finite = {k: v for k, v in values.items() if v == v}
    out: dict[str, float] = {k: float("nan") for k in values}
    n = len(finite)
    if n == 0:
        return out
    if n == 1:
        # A lone finite value has no cross-section to rank against; treat
        # it as median standing rather than a spurious 0 or 100.
        only = next(iter(finite))
        out[only] = 50.0
        return out
    # Sort by (value, key) so the order is fully deterministic, then give
    # TIED values the same percentile (the average of the ranks they span)
    # — otherwise two identical factor values would receive different
    # standings purely from iteration order, making the ranking unstable.
    ordered = sorted(finite.items(), key=lambda kv: (kv[1], kv[0]))
    i = 0
    while i < n:
        j = i
        while j + 1 < n and ordered[j + 1][1] == ordered[i][1]:
            j += 1
        # ranks i..j share value; assign them the mean percentile.
        pct = 100.0 * ((i + j) / 2.0) / (n - 1)
        for r in range(i, j + 1):
            out[ordered[r][0]] = pct
        i = j + 1
    return out


def compute_confluence(
    rotation: RotationResult,
    rrg: RRGResult,
    seasonality: SeasonalityGrid,
    regime: RegimeState | None,
    month: int,
    breadth_by_industry: dict[str, float] | None = None,
    market_breadth: float | None = None,
    benchmark_return: float = 0.0,
) -> ConfluenceResult:
    """Rank industries by cross-view confluence for the given ``month``.

    Args:
        rotation: ROC view result (relative strength).
        rrg: RRG view result (rs-ratio + quadrant + maturity).
        seasonality: industry seasonality grid (current-month edge).
        regime: market breadth regime (context banner; may be None).
        month: calendar month 1..12 the seasonal factor is read for
            (normally the current month — "actionable now").
        breadth_by_industry: optional ``{industry: fraction 0..1}`` of
            members above their own SMA50 — a bottom-up PARTICIPATION
            measure. When provided (with ``market_breadth``), a narrow
            move (industry breadth well below the market's) discounts the
            score via the breadth gate; a broad move is neutral. Absent →
            the breadth gate is inert (1.0 for all).
        market_breadth: optional universe-wide fraction (0..1) above SMA50,
            the reference the per-industry breadth is judged against, so
            "narrow" is market-relative, not an absolute threshold.

    Returns:
        A :class:`ConfluenceResult`, rows ranked by score descending.
    """
    mi = month - 1

    # ---- Raw factors per industry -------------------------------------
    # Strength is benchmark-relative RS: the industry composite's ROC minus
    # the benchmark's return over the same window. This is the SINGLE shared
    # definition (see market_pulse_common.industry_rs_excess), so the
    # Confluence strength factor and the Edge RS-excess anchor are the same
    # number and can never disagree in sign.
    strength_raw = industry_rs_excess(
        {r.industry: r.roc for r in rotation.industries}, benchmark_return)

    rrg_by_ind = {p.industry: p for p in rrg.points}
    direction_raw: dict[str, float] = {}
    direction_conf: dict[str, float] = {}
    direction_detail: dict[str, str] = {}
    direction_quadrant: dict[str, Quadrant] = {}
    direction_maturity: dict[str, Maturity] = {}
    for ind, p in rrg_by_ind.items():
        base = _QUADRANT_SCORE.get(p.quadrant, 0.0)
        mult = _MATURITY_MULT.get(p.maturity, 0.7)
        direction_raw[ind] = base * mult
        # Shown as the direction "confidence" in the table: the gate value
        # itself — how much this direction is trusted / how much of the
        # strength it lets survive. Quadrant desirability × maturity gate.
        dgate = (_DIRECTION_GATE.get(p.quadrant, 0.55)
                 * _MATURITY_GATE.get(p.maturity, 0.90))
        direction_conf[ind] = dgate
        direction_detail[ind] = f"{p.quadrant.value} · {p.maturity.value}"
        direction_quadrant[ind] = p.quadrant
        direction_maturity[ind] = p.maturity

    seasonal_raw: dict[str, float] = {}
    seasonal_conf: dict[str, float] = {}
    seasonal_detail: dict[str, str] = {}
    members: dict[str, int] = {}
    for row in seasonality.rows:
        if not row.has_data:
            continue
        avg = row.avg_returns[mi]
        members[row.industry] = row.n_members
        if avg != avg:
            # Blank/too-few cell this month — no seasonal signal. It still
            # ranks on the other two factors; seasonal just contributes 0
            # at 0 confidence.
            seasonal_raw[row.industry] = float("nan")
            seasonal_conf[row.industry] = 0.0
            seasonal_detail[row.industry] = "no cell"
            continue
        # Confidence is the member-aware seasonal QUALITY, not the raw
        # composite reliability: it blends the composite's |mean|/std with a
        # weight-aware member read, so an industry whose headline number
        # looks dependable but whose heavy members are individually lumpy
        # (or whose steady members are underweight) is correctly discounted.
        # This is what makes the confluence seasonal factor see the
        # lumpiness the composite reliability alone would hide.
        quality = (row.seasonal_quality[mi]
                   if mi < len(row.seasonal_quality) else float("nan"))
        seasonal_raw[row.industry] = avg
        seasonal_conf[row.industry] = 0.0 if quality != quality else quality
        seasonal_detail[row.industry] = (
            "—" if quality != quality
            else f"{quality*100:.0f}/100 quality")

    # Universe = industries with BOTH a strength and a direction reading.
    # Rotation is fundamentally a momentum decision; seasonality is a tilt
    # on top of it, never a substitute. An industry lacking a real
    # momentum read (e.g. a sub-floor override name with no RRG/ROC data)
    # must not rank on its seasonal factor alone — it is excluded from the
    # board entirely rather than floated to the top on one factor.
    def _has(d: dict, k: str) -> bool:
        return k in d and d[k] == d[k]
    universe = {
        ind for ind in (set(strength_raw) & set(direction_raw))
        if _has(strength_raw, ind) and _has(direction_raw, ind)
    }
    if not universe:
        return ConfluenceResult(
            rows=(), month=month,
            regime_label=(regime.label if regime else "—"),
            regime_signals_on=(regime.signals_on if regime else 0),
            regime_n_signals=(regime.n_signals if regime else 0))

    # ---- Cross-sectional percentiles ----------------------------------
    strength_pct = _percentiles(strength_raw)
    # Direction is NOT percentile-ranked: unlike strength (inherently
    # relative — leader vs laggard) and seasonal edge, the direction score
    # has an ABSOLUTE meaning (0..1 from quadrant × maturity, with known-
    # good and known-bad quadrants). Percentile-ranking it would let a
    # fading "Weakening" leader look strong merely because the rest of the
    # field is even worse — the classic relative-ranking trap. Mapping the
    # absolute 0..1 desirability onto 0..100 keeps "Weakening is bad" true
    # regardless of how weak the cross-section is.
    direction_pct = {k: (v * 100.0 if v == v else float("nan"))
                     for k, v in direction_raw.items()}
    seasonal_pct = _percentiles(
        {k: v for k, v in seasonal_raw.items() if v == v})

    # ---- Score: strength magnitude, gated by direction and seasonality --
    # The model is deliberately simple and interpretable:
    #
    #     seasonal_gate = SEA_FLOOR + (1 - SEA_FLOOR) * (z * q)
    #     base          = strength_pct * direction_gate * seasonal_gate
    #     lift          = LIFT_MAX * (z*q)^2     (favourable direction only)
    #     score         = min(100, base + lift)
    #
    # Rationale (money-on-the-line design, settled with the operator):
    #   • STRENGTH is the magnitude being ranked — rotation buys relative
    #     strength, so it is the base, on a 0..100 percentile scale.
    #   • DIRECTION and SEASONALITY are *quality gates* on that strength,
    #     not independent factors to average in. Each is a multiplier in
    #     [gate_floor, 1] that can only DISCOUNT the strength — a fading or
    #     seasonally-unsupported name is worth less, never more. This is
    #     what makes the score a true CONFLUENCE: a high score needs all
    #     three to agree, and a multiplicative gate (unlike an additive
    #     penalty) genuinely bites even against elite strength.
    #   • The seasonal gate combines the seasonal MAGNITUDE (z, percentile)
    #     with its QUALITY (q, the member-lumpiness-aware reliability): a
    #     strong-but-lumpy seasonal and a weak-but-clean one are both
    #     untrustworthy tailwinds, so the gate is high only when z*q is
    #     high. SEA_FLOOR is set low (hard bite) so a lumpy/weak seasonal
    #     blocks the top spot — the operator's "true confluence" choice.
    #   • A small squared LIFT lets a GENUINELY ELITE seasonal (z*q near 1)
    #     nudge a moderate-strength name up a few points, without letting a
    #     mediocre one matter — strength stays primary. Favourable
    #     direction only: a tailwind can't lift a fading name.
    #
    # Deterministic sorted iteration so tied values rank stably run-to-run.
    rows: list[ConfluenceRow] = []
    for ind in sorted(universe):
        s_pct = strength_pct.get(ind, float("nan"))
        d_pct = direction_pct.get(ind, float("nan"))
        z_pct = seasonal_pct.get(ind, float("nan"))

        quad = direction_quadrant.get(ind)
        mat = direction_maturity.get(ind)

        # Direction gate ∈ [0,1] — quadrant desirability × maturity gate, so
        # a fading (Maturing) leader is gated harder than a stretched-but-
        # rising (Extended) one, consistent with the displayed Direction Score.
        d_gate = (_DIRECTION_GATE.get(quad, 0.55) * _MATURITY_GATE.get(mat, 0.90)
                  if quad is not None else 0.0)

        # Seasonal favourability z*q: magnitude (percentile 0..1) × quality
        # (member-aware reliability 0..1). No cell → 0 (fully unsupported).
        z = (z_pct / 100.0) if z_pct == z_pct else 0.0
        q = seasonal_conf.get(ind, 0.0)
        if q != q:
            q = 0.0
        zq = max(0.0, min(1.0, z * q))
        # The seasonal gate can only LIFT the score for a favourable-
        # direction name — a good seasonal must never partly compensate for
        # bad direction (the "seasonal rescues a fading name" trap). For
        # Weakening/Lagging names the gate is pinned at the floor: their
        # seasonal can't help them, it can only fail to. For favourable
        # names it scales up with z*q as usual.
        if quad in _FAVOURABLE_QUADRANTS:
            seasonal_gate = _SEASONAL_GATE_FLOOR + \
                (1.0 - _SEASONAL_GATE_FLOOR) * zq
        else:
            seasonal_gate = _SEASONAL_GATE_FLOOR

        # Breadth gate ∈ [FLOOR, 1]: a market-relative participation check.
        # A narrow move (industry breadth well below the market's) discounts
        # the score; at/above market breadth it is neutral (1.0). Inert when
        # no breadth data was supplied.
        b_ind = (breadth_by_industry or {}).get(ind, float("nan"))
        if b_ind == b_ind and market_breadth is not None:
            rel = b_ind - market_breadth
            breadth_gate = _BREADTH_GATE_FLOOR + (1.0 - _BREADTH_GATE_FLOOR) \
                * (1.0 + rel / _BREADTH_GATE_SPREAD)
            breadth_gate = max(_BREADTH_GATE_FLOOR, min(1.0, breadth_gate))
        else:
            breadth_gate = 1.0

        # Base score: strength magnitude, gated by direction, seasonality
        # and breadth.
        if s_pct != s_pct:
            score = float("nan")
        else:
            score = s_pct * d_gate * seasonal_gate * breadth_gate
            # Small squared lift for an elite seasonal on a favourable-
            # direction name — strength stays primary, but an exceptional
            # calendar tailwind can nudge a moderate name up a few points.
            if quad in _FAVOURABLE_QUADRANTS:
                score = min(100.0, score + _SEASONAL_LIFT_MAX * (zq ** 2))

        # Overall confidence: how much all gates corroborate. High only when
        # strength is present AND direction is favourable AND the seasonal is
        # trustworthy AND participation is broad. Descriptive (not scored).
        s_conf = 1.0 if s_pct == s_pct else 0.0
        overall_conf = s_conf * d_gate * seasonal_gate * breadth_gate

        rows.append(ConfluenceRow(
            industry=ind,
            score=score,
            confidence=overall_conf,
            strength=FactorRead(
                value=strength_raw.get(ind, float("nan")),
                percentile=s_pct, confidence=s_conf,
                detail="ROC + RS-Ratio"),
            direction=FactorRead(
                value=direction_raw.get(ind, float("nan")),
                percentile=d_pct,
                confidence=direction_conf.get(ind, 0.0),
                detail=direction_detail.get(ind, "—")),
            seasonal=FactorRead(
                value=seasonal_raw.get(ind, float("nan")),
                percentile=z_pct,
                confidence=seasonal_conf.get(ind, 0.0),
                detail=seasonal_detail.get(ind, "—")),
            n_members=members.get(ind, 0),
            breadth=b_ind,
            breadth_gate=breadth_gate,
        ))

    # Rank best-first; NaN scores sink to the bottom. Ties break
    # alphabetically by industry so the order is fully deterministic.
    rows.sort(key=lambda r: (
        r.score != r.score,
        -(r.score if r.score == r.score else 0.0),
        r.industry))

    return ConfluenceResult(
        rows=tuple(rows),
        month=month,
        regime_label=(regime.label if regime else "—"),
        regime_signals_on=(regime.signals_on if regime else 0),
        regime_n_signals=(regime.n_signals if regime else 0),
    )
