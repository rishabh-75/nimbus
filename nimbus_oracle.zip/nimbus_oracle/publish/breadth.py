#!/usr/bin/env python3
"""
publish/breadth.py — NIFTY 50/100 Market Breadth Snapshot.

Public-facing chart — no indicator jargon. Uses universally understood metrics:
  - % of stocks above key moving averages (SMA 20/50/200)
  - Drawdown from 52-week high distribution
  - Sector average drawdown
  - Key aggregate stats

Usage:
    python3 publish/breadth.py                    # NIFTY 50
    python3 publish/breadth.py --index nifty100   # NIFTY 100
    python3 publish/breadth.py --no-export        # preview only
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from publish.common import (
    nimbus_style, export_figure, add_title, add_timestamp,
    COLORS, SECTOR_COLORS,
)
from modules.index_constituents import get_nifty50, get_nifty100, get_sector

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("publish_breadth")


def scan_universe(symbols):
    """Scan all symbols, return list of result dicts with public-facing metrics."""
    from modules.data import get_price_daily

    results = []
    for i, sym in enumerate(symbols):
        try:
            df, msg = get_price_daily(sym, days=365)
            if df is None or df.empty or len(df) < 40:
                continue

            c = df["Close"]
            h = df["High"]

            # Moving averages
            sma20 = c.rolling(20).mean().iloc[-1]
            sma50 = c.rolling(50).mean().iloc[-1] if len(c) >= 50 else np.nan
            sma200 = c.rolling(200).mean().iloc[-1] if len(c) >= 200 else np.nan
            last_close = float(c.iloc[-1])

            # Drawdown from 52w high
            high_52w = float(h.max())  # full year of data
            dd_52w = (last_close / high_52w - 1) * 100 if high_52w > 0 else 0

            # Drawdown from 50d high
            high_50d = float(h.tail(50).max()) if len(h) >= 50 else float(h.max())
            dd_50d = (last_close / high_50d - 1) * 100 if high_50d > 0 else 0

            # Weekly change
            if len(c) >= 6:
                wk_chg = (last_close / float(c.iloc[-6]) - 1) * 100
            else:
                wk_chg = 0.0

            # Consecutive red days
            red = (c < c.shift(1)).astype(int)
            streak = int(red.groupby((red != red.shift()).cumsum()).cumsum().iloc[-1])

            results.append({
                "symbol": sym,
                "sector": get_sector(sym),
                "close": last_close,
                "above_sma20": last_close > sma20 if not np.isnan(sma20) else False,
                "above_sma50": last_close > sma50 if not np.isnan(sma50) else False,
                "above_sma200": last_close > sma200 if not np.isnan(sma200) else False,
                "dd_52w": dd_52w,
                "dd_50d": dd_50d,
                "wk_chg": wk_chg,
                "streak": streak,
            })
        except Exception as e:
            logger.debug("Skipped %s: %s", sym, e)

        if (i + 1) % 10 == 0:
            logger.info("  Scanned %d/%d", i + 1, len(symbols))

    logger.info("Scan complete: %d/%d stocks with data", len(results), len(symbols))
    return results


def render_breadth(results, index_name="NIFTY 50"):
    """Render the market breadth snapshot — public-facing metrics only."""
    n = len(results)
    dds_52w = np.array([r["dd_52w"] for r in results])
    dds_50d = np.array([r["dd_50d"] for r in results])
    streaks = np.array([r["streak"] for r in results])

    # SMA stats
    pct_above_20 = np.mean([r["above_sma20"] for r in results]) * 100
    pct_above_50 = np.mean([r["above_sma50"] for r in results]) * 100
    pct_above_200 = np.mean([r["above_sma200"] for r in results]) * 100

    with nimbus_style():
        fig = plt.figure(figsize=(14, 8))
        gs = fig.add_gridspec(3, 3, hspace=0.45, wspace=0.35,
                              top=0.88, bottom=0.08, left=0.08, right=0.97)

        now_str = datetime.datetime.now().strftime("%d %b %Y")
        add_title(fig, f"{index_name} MARKET BREADTH",
                  f"{n} stocks · {now_str} · Aggregate market structure snapshot")
        add_timestamp(fig)

        # ── Panel 1: % Above SMA (top-left) ─────────────────────────────
        ax1 = fig.add_subplot(gs[0, 0])
        sma_labels = ["SMA(200)", "SMA(50)", "SMA(20)"]
        sma_pcts = [pct_above_200, pct_above_50, pct_above_20]
        sma_colors = [
            COLORS["emerald"] if p > 50 else (COLORS["gold"] if p > 25 else COLORS["red"])
            for p in sma_pcts
        ]
        bars1 = ax1.barh(sma_labels, sma_pcts, color=sma_colors,
                         edgecolor="none", height=0.5, alpha=0.85)
        ax1.set_xlim(0, 105)
        ax1.set_title("% of stocks above moving average", fontsize=10, pad=8)
        ax1.axvline(x=50, color=COLORS["muted"], linewidth=0.6, linestyle=":", alpha=0.5)
        for bar, pct in zip(bars1, sma_pcts):
            ax1.text(bar.get_width() + 1.5, bar.get_y() + bar.get_height()/2,
                    f"{pct:.0f}%", va="center", fontsize=9, fontweight=600,
                    color=COLORS["white"])

        # ── Panel 2: Drawdown from 52w high (top-center) ────────────────
        ax2 = fig.add_subplot(gs[0, 1])
        dd_abs = np.abs(dds_52w)
        dd_bins = [0, 5, 10, 15, 20, 30, 50, 100]
        dd_labels = ["0-5%", "5-10%", "10-15%", "15-20%", "20-30%", "30-50%", "50%+"]
        dd_counts = []
        for i in range(len(dd_bins) - 1):
            dd_counts.append(int(np.sum((dd_abs >= dd_bins[i]) & (dd_abs < dd_bins[i+1]))))
        dd_colors = [COLORS["emerald"], COLORS["muted"], COLORS["muted"],
                     COLORS["gold"], COLORS["gold"], COLORS["red"], COLORS["red"]]
        bars2 = ax2.bar(dd_labels, dd_counts, color=dd_colors, edgecolor="none", width=0.7)
        ax2.set_title("Drawdown from 52-week high", fontsize=10, pad=8)
        ax2.set_ylabel("stocks")
        ax2.tick_params(axis="x", rotation=40)
        for bar, count in zip(bars2, dd_counts):
            if count > 0:
                ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                        str(count), ha="center", fontsize=7, color=COLORS["white"])

        # ── Panel 3: Key Stats (top-right) ──────────────────────────────
        ax3 = fig.add_subplot(gs[0, 2])
        ax3.axis("off")

        avg_dd_52w = np.mean(dds_52w)
        avg_dd_50d = np.mean(dds_50d)
        pct_deep = np.sum(dd_abs > 20) / n * 100
        avg_streak = np.mean(streaks)

        stats = [
            ("Above SMA(50)", f"{pct_above_50:.0f}%",
             COLORS["emerald"] if pct_above_50 > 50 else COLORS["red"]),
            ("Avg DD (52w high)", f"{avg_dd_52w:.1f}%",
             COLORS["red"] if avg_dd_52w < -15 else COLORS["gold"]),
            ("Avg DD (50d high)", f"{avg_dd_50d:.1f}%",
             COLORS["red"] if avg_dd_50d < -8 else COLORS["muted"]),
            ("DD > 20% from 52w", f"{pct_deep:.0f}%",
             COLORS["red"] if pct_deep > 30 else COLORS["muted"]),
            ("Avg red streak", f"{avg_streak:.1f}d",
             COLORS["red"] if avg_streak > 2 else COLORS["muted"]),
        ]

        for i, (label, value, color) in enumerate(stats):
            y = 0.88 - i * 0.17
            ax3.text(0.05, y, label, fontsize=8, color=COLORS["muted"],
                    transform=ax3.transAxes, va="center")
            ax3.text(0.95, y, value, fontsize=11, fontweight=600, color=color,
                    transform=ax3.transAxes, va="center", ha="right",
                    fontfamily="monospace")

        # ── Panel 4: Sector Avg Drawdown (bottom-left, spanning 2 cols) ─
        ax4 = fig.add_subplot(gs[1:, :2])

        sector_data = {}
        for r in results:
            s = r["sector"]
            if s not in sector_data:
                sector_data[s] = []
            sector_data[s].append(r["dd_52w"])

        # Sort by avg drawdown (most beaten down first)
        sorted_sectors = sorted(sector_data.items(), key=lambda x: np.mean(x[1]))
        sector_names = [s[0] for s in sorted_sectors]
        sector_avg_dd = [np.mean(s[1]) for s in sorted_sectors]
        bar_colors = [SECTOR_COLORS.get(s, COLORS["muted"]) for s in sector_names]

        y_pos = np.arange(len(sector_names))
        bars4 = ax4.barh(y_pos, sector_avg_dd, color=bar_colors,
                         edgecolor="none", height=0.6, alpha=0.85)
        ax4.set_yticks(y_pos)
        ax4.set_yticklabels(
            [f"{s} ({len(sector_data[s])})" for s in sector_names], fontsize=8
        )
        ax4.set_title("Sector avg drawdown from 52-week high", fontsize=10, pad=8)
        ax4.set_xlabel("Avg drawdown %")
        ax4.axvline(x=-10, color=COLORS["gold"], linewidth=0.6, linestyle=":", alpha=0.4)
        ax4.axvline(x=-20, color=COLORS["red"], linewidth=0.6, linestyle=":", alpha=0.4)
        ax4.invert_yaxis()

        for i, dd in enumerate(sector_avg_dd):
            ax4.text(dd + 0.5, i, f"{dd:.1f}%",
                    va="center", ha="left", fontsize=7, color=COLORS["white"],
                    fontweight=500)

        # ── Panel 5: Drawdown from 50d high (bottom-right) ──────────────
        ax5 = fig.add_subplot(gs[1, 2])
        dd50_abs = np.abs(dds_50d)
        dd50_bins = [0, 3, 5, 8, 10, 15, 25, 100]
        dd50_labels = ["0-3%", "3-5%", "5-8%", "8-10%", "10-15%", "15-25%", "25%+"]
        dd50_counts = []
        for i in range(len(dd50_bins) - 1):
            dd50_counts.append(int(np.sum((dd50_abs >= dd50_bins[i]) & (dd50_abs < dd50_bins[i+1]))))
        dd50_colors = [COLORS["muted"], COLORS["muted"], COLORS["gold"],
                       COLORS["gold"], COLORS["red"], COLORS["red"], COLORS["red"]]
        bars5 = ax5.bar(dd50_labels, dd50_counts, color=dd50_colors, edgecolor="none", width=0.7)
        ax5.set_title("Drawdown from 50d high", fontsize=10, pad=8)
        ax5.set_ylabel("stocks")
        ax5.tick_params(axis="x", rotation=45)
        for bar, count in zip(bars5, dd50_counts):
            if count > 0:
                ax5.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                        str(count), ha="center", fontsize=7, color=COLORS["white"])

        # ── Panel 6: Red Streak (bottom-right-bottom) ───────────────────
        ax6 = fig.add_subplot(gs[2, 2])
        streak_labels = ["0d", "1d", "2d", "3d", "4d", "5d+"]
        streak_counts = [
            np.sum(streaks == 0), np.sum(streaks == 1), np.sum(streaks == 2),
            np.sum(streaks == 3), np.sum(streaks == 4), np.sum(streaks >= 5),
        ]
        streak_colors = [COLORS["muted"], COLORS["muted"], COLORS["gold"],
                         COLORS["gold"], COLORS["red"], COLORS["red"]]
        bars6 = ax6.bar(streak_labels, streak_counts, color=streak_colors,
                        edgecolor="none", width=0.6)
        ax6.set_title("Consecutive red days", fontsize=10, pad=8)
        ax6.set_ylabel("stocks")
        for bar, count in zip(bars6, streak_counts):
            if count > 0:
                ax6.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                        str(count), ha="center", fontsize=7, color=COLORS["white"])

    return fig


def main():
    parser = argparse.ArgumentParser(description="NIMBUS Market Breadth Snapshot")
    parser.add_argument("--index", default="nifty50", choices=["nifty50", "nifty100"])
    parser.add_argument("--no-export", action="store_true", help="Skip file export")
    args = parser.parse_args()

    if args.index == "nifty100":
        symbols = get_nifty100()
        index_name = "NIFTY 100"
    else:
        symbols = get_nifty50()
        index_name = "NIFTY 50"

    logger.info("Publishing %s Market Breadth (%d stocks)...", index_name, len(symbols))
    results = scan_universe(symbols)

    if len(results) < 10:
        logger.error("Too few results (%d) — check data availability", len(results))
        return

    fig = render_breadth(results, index_name)

    if not args.no_export:
        slug = f"{args.index}_breadth"
        export_figure(fig, slug)
    else:
        logger.info("Preview mode — not exported")

    plt.close(fig)
    logger.info("Done.")


if __name__ == "__main__":
    main()
