"""nimbus_v3.strategies.base — Strategy protocol and StrategySignal.

A ``Strategy`` evaluates a ``(symbol, state, contexts)`` triple and
emits a ``StrategySignal`` if its entry conditions are met, or ``None``
otherwise. Strategies never compute indicators (those come from
``compute/``) and never grade themselves (grading is the
``ConvictionEngine``'s single responsibility).

One symbol may fire multiple strategies on the same bar — the scan
engine collects every non-``None`` signal and hands each one to the
conviction engine separately. A symbol can therefore appear in the
results list multiple times, once per firing strategy.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta


# ══════════════════════════════════════════════════════════════════════════════
# Signal shape
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class StrategySignal:
    """One strategy firing on one ``(symbol, bar)`` pair.

    Carries the minimum information the conviction engine needs to grade
    the setup. The ``metadata`` dict is a debug / display-only payload;
    the conviction engine reads from ``state`` and ``contexts`` directly.
    """
    strategy_name: str
    symbol: str
    setup_type: SetupType
    asof_date: pd.Timestamp
    priority: int
    direction: str = "LONG"         # 'LONG' | 'SHORT' — v3.0 ships LONG only
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.asof_date, pd.Timestamp):
            object.__setattr__(self, "asof_date", pd.Timestamp(self.asof_date))
        if self.direction not in ("LONG", "SHORT"):
            raise ValueError(f"direction must be LONG or SHORT, got {self.direction!r}")


# ══════════════════════════════════════════════════════════════════════════════
# Strategy protocol
# ══════════════════════════════════════════════════════════════════════════════

class Strategy(Protocol):
    """A stateless entry-setup detector.

    Concrete strategies are plain classes that implement ``evaluate``.
    They may take configuration at construction (thresholds, universe
    references, etc.), but a single instance is expected to be shared
    across many evaluations — no per-symbol state.
    """

    @property
    def name(self) -> str:
        """Display name — used for identification and logging."""
        ...

    @property
    def setup_type(self) -> SetupType:
        """Category this strategy belongs to."""
        ...

    @property
    def priority(self) -> int:
        """Higher priority strategies resolve first when multiple fire.

        The registry uses this to sort results. TRAP (override) is
        typically highest, technical setups are mid-range, and
        experimental strategies are lowest.
        """
        ...

    @property
    def production_weight(self) -> float:
        """Multiplier applied to this strategy's conviction score.

        A weight of ``1.0`` gives the strategy full grade influence.
        A weight of ``0.0`` means the strategy is research-only: it
        still emits signals (feeding ``SignalTracker`` for forward-
        return attribution) but contributes nothing to live grades.

        Validation-derived defaults (fresh-data OOS, April 2026):
        - MeanReversion → 1.0 (only OOS-confirmed production signal)
        - all others   → 0.0 (research-tier, emit-only)

        These weights are settable per class — see individual
        ``Strategy`` implementations.
        """
        ...

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        """Return True if this strategy is eligible for the symbol.

        Default expectation: equity strategies reject ETFs and vice
        versa. Scanner filters against this before calling ``evaluate``.
        """
        ...

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        """Return a ``StrategySignal`` if the entry conditions are met,
        otherwise ``None``. Must not raise for unfit setups."""
        ...
