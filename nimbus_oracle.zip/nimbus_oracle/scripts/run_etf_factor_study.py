#!/usr/bin/env python3
"""
scripts/run_etf_factor_study.py — Factor study for ETF momentum grade.

Runs walk-forward on 35+ NSE ETFs, then tests which factors predict
trade outcome (PnL). Uses leave-one-out factor analysis same as the
MR equity study that validated MFI, RSI, vol_ratio, VIX.

Factors tested:
  Current grade factors:
    - score_band (momentum_score bins)
    - trend_strength (pct_from_sma50)
    - dip_depth (wr_min_10)
    - mfi (money flow)
    - adx (trend directional)
    - roc_10 (momentum)

  Candidate additions:
    - vol_ratio (volume vs 20d avg — in MR grade, not in ETF grade)
    - bbw_slope (BB squeeze/expansion)
    - rsi (relative strength index)
    - vix (market-level fear)
    - nav_premium (ETF-specific: premium/discount to NAV)

Usage:
    python3 scripts/run_etf_factor_study.py
    python3 scripts/run_etf_factor_study.py --years 5 --stocks 40
"""
import argparse, logging, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()
import numpy as np, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("etf_factor")

# ── ETF Universe ──────────────────────────────────────────────────────────────
ETF_SYMBOLS = [
    # Gold
    "GOLDBEES", "GOLDCASE", "GOLDETF", "IVZINGOLD",
    # Silver
    "SILVERBEES", "SILVERIETF",
    # Broad index
    "NIFTYBEES", "SETFNIF50", "JUNIORBEES", "NV20IETF",
    # Banking
    "BANKBEES", "SETFNIFBK", "PSUBNKBEES", "FINIETF",
    # Sectoral
    "ITBEES", "PHARMABEES", "INFRABEES", "CPSEETF",
    "AUTOIETF", "FMCGIETF", "HEALTHIETF",
    # Commodity / Thematic
    "COMMOIETF", "METALIETF", "OILIETF",
    # Strategy
    "MOM100", "LOWVOLIETF", "MIDCAPIETF",
    # International
    "N100", "MON100", "MAFANG", "HNGSNGBEES",
]


def fetch_daily(symbol, years=5):
    """Fetch daily OHLCV from yfinance."""
    import yfinance as yf
    try:
        ticker = f"{symbol}.NS" if not symbol.startswith("^") else symbol
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", symbol, exc)
        return pd.DataFrame()


def compute_factors(df, symbol):
    """Compute all candidate factors for each bar."""
    from modules.etf_momentum import compute_etf_momentum, MomentumSignal
    
    if df is None or len(df) < 80:
        return pd.DataFrame()
    
    c = df["Close"]; h = df["High"]; l = df["Low"]
    v = df["Volume"] if "Volume" in df.columns else pd.Series(0, index=df.index)
    
    # SMA
    sma20 = c.rolling(20).mean()
    sma50 = c.rolling(50, min_periods=30).mean()
    
    # WR(20)
    hh = h.rolling(20).max(); ll = l.rolling(20).min()
    wr = ((hh - c) / (hh - ll).replace(0, np.nan)) * -100
    wr_min10 = wr.rolling(10, min_periods=5).min()
    
    # ADX(14)
    tr = pd.concat([h-l, (h-c.shift(1)).abs(), (l-c.shift(1)).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    up = h.diff(); dn = -l.diff()
    pdm = pd.Series(np.where((up>dn)&(up>0), up, 0), index=df.index)
    mdm = pd.Series(np.where((dn>up)&(dn>0), dn, 0), index=df.index)
    pdi = 100 * pdm.rolling(14).mean() / atr.replace(0, np.nan)
    mdi = 100 * mdm.rolling(14).mean() / atr.replace(0, np.nan)
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    adx = dx.rolling(14).mean()
    
    # MFI(14)
    tp = (h + l + c) / 3; mf = tp * v
    pmf = pd.Series(np.where(tp > tp.shift(1), mf, 0), index=df.index)
    nmf = pd.Series(np.where(tp < tp.shift(1), mf, 0), index=df.index)
    mr = pmf.rolling(14).sum() / nmf.rolling(14).sum().replace(0, np.nan)
    mfi = 100 - (100 / (1 + mr))
    
    # RSI(14)
    delta = c.diff(); gain = delta.clip(lower=0); loss = -delta.clip(upper=0)
    ag = gain.rolling(14).mean(); al = loss.rolling(14).mean()
    rsi = 100 - (100 / (1 + ag / al.replace(0, np.nan)))
    
    # Volume ratio
    vol_ratio = v / v.rolling(20).mean().replace(0, np.nan)
    
    # BB
    bb_ma = c.rolling(20).mean(); bb_sd = c.rolling(20).std()
    bbw = ((bb_ma + 2*bb_sd) - (bb_ma - 2*bb_sd)) / bb_ma.replace(0, np.nan) * 100
    bbw_slope = bbw.diff(5)
    
    # ROC
    roc_10 = (c / c.shift(10) - 1) * 100
    roc_20 = (c / c.shift(20) - 1) * 100
    
    # Forward returns
    fwd_5d = (c.shift(-5) / c - 1) * 100
    fwd_10d = (c.shift(-10) / c - 1) * 100
    fwd_21d = (c.shift(-21) / c - 1) * 100
    
    # Entry detection: pullback_in_trend
    above_sma50 = c > sma50
    dip_detected = wr_min10 < -60  # dipped below -60 in last 10 bars
    recovered = wr > -30
    entry = above_sma50 & dip_detected & recovered
    
    result = pd.DataFrame({
        "symbol": symbol,
        "close": c,
        "sma20": sma20, "sma50": sma50,
        "pct_sma50": ((c / sma50) - 1) * 100,
        "pct_sma20": ((c / sma20) - 1) * 100,
        "wr": wr, "wr_min10": wr_min10,
        "adx": adx, "mfi": mfi, "rsi": rsi,
        "vol_ratio": vol_ratio,
        "bbw": bbw, "bbw_slope": bbw_slope,
        "roc_10": roc_10, "roc_20": roc_20,
        "atr": atr, "atr_pct": (atr / c) * 100,
        "entry": entry,
        "fwd_5d": fwd_5d, "fwd_10d": fwd_10d, "fwd_21d": fwd_21d,
        "win_5d": fwd_5d > 0, "win_10d": fwd_10d > 0, "win_21d": fwd_21d > 0,
    }, index=df.index)
    
    return result.dropna(subset=["mfi", "rsi", "adx", "fwd_10d"])


def factor_analysis(trades: pd.DataFrame, horizon="fwd_10d"):
    """Compute factor correlations with forward returns."""
    logger.info("\n" + "=" * 70)
    logger.info("FACTOR CORRELATION WITH %s", horizon)
    logger.info("=" * 70)
    
    factors = ["mfi", "rsi", "adx", "vol_ratio", "roc_10", "roc_20",
               "pct_sma50", "pct_sma20", "wr", "wr_min10",
               "bbw", "bbw_slope", "atr_pct"]
    
    results = []
    for f in factors:
        if f not in trades.columns:
            continue
        valid = trades[[f, horizon]].dropna()
        if len(valid) < 30:
            continue
        r = valid[f].corr(valid[horizon])
        results.append({"factor": f, "corr": r, "n": len(valid)})
    
    results.sort(key=lambda x: -abs(x["corr"]))
    
    print(f"\n  {'Factor':15s} {'r(PnL)':>8s} {'N':>6s}  {'Direction':15s} {'Use?'}")
    print(f"  {'-'*15} {'-'*8} {'-'*6}  {'-'*15} {'-'*5}")
    for r in results:
        direction = "higher = better" if r["corr"] > 0 else "higher = worse"
        use = "✓ KEEP" if abs(r["corr"]) > 0.03 else "✗ DROP"
        print(f"  {r['factor']:15s} {r['corr']:+8.4f} {r['n']:6d}  {direction:15s} {use}")
    
    return results


def leave_one_out(trades: pd.DataFrame, horizon="fwd_10d"):
    """Leave-one-out: does removing a factor IMPROVE or HURT prediction?"""
    logger.info("\n" + "=" * 70)
    logger.info("LEAVE-ONE-OUT FACTOR ANALYSIS")
    logger.info("=" * 70)
    
    factors = ["mfi", "rsi", "adx", "vol_ratio", "roc_10",
               "pct_sma50", "wr_min10", "bbw_slope", "atr_pct"]
    
    # Base: simple composite of all factors (z-scored)
    valid = trades[factors + [horizon]].dropna()
    if len(valid) < 50:
        print("  Insufficient data for LOO analysis")
        return
    
    # Z-score normalize
    zscored = valid[factors].apply(lambda x: (x - x.mean()) / x.std())
    base_composite = zscored.mean(axis=1)
    base_r = base_composite.corr(valid[horizon])
    
    print(f"\n  Base composite (all factors): r = {base_r:+.4f}  N = {len(valid)}")
    print(f"\n  {'Removed':15s} {'r(PnL)':>8s} {'Δ vs base':>10s} {'Verdict'}")
    print(f"  {'-'*15} {'-'*8} {'-'*10} {'-'*20}")
    
    for f in factors:
        remaining = [x for x in factors if x != f]
        comp = zscored[remaining].mean(axis=1)
        r = comp.corr(valid[horizon])
        delta = r - base_r
        verdict = f"REMOVE (+{delta:.4f})" if delta > 0.002 else "KEEP"
        print(f"  {f:15s} {r:+8.4f} {delta:+10.4f} {verdict}")


def grade_backtest(trades: pd.DataFrame, horizon="fwd_10d"):
    """Backtest the current ETF grade formula vs potential improvements."""
    logger.info("\n" + "=" * 70)
    logger.info("CURRENT ETF GRADE BACKTEST")
    logger.info("=" * 70)
    
    # Compute current grade using the actual function
    from modules.etf_momentum import momentum_grade, MomentumSignal
    
    entries = trades[trades["entry"]].copy()
    if len(entries) < 30:
        print(f"  Only {len(entries)} entry signals — too few for grade backtest")
        return
    
    # Build momentum signals and grade them
    grades = []
    for _, r in entries.iterrows():
        sig = MomentumSignal()
        sig.entry_triggered = True
        sig.momentum_score = 50  # placeholder — we'll test score bands separately
        sig.pct_from_sma50 = r["pct_sma50"]
        sig.wr_min_10 = r["wr_min10"]
        sig.mfi = r["mfi"]
        sig.adx = r["adx"]
        sig.roc_10 = r["roc_10"]
        
        # Score band — simulate from factors
        sc = 30
        if r["pct_sma50"] > 0: sc += 15
        if r["wr_min10"] < -60: sc += 10
        if r["wr"] > -30: sc += 10
        if r["mfi"] >= 50: sc += 10
        if r["adx"] >= 20: sc += 10
        if r["roc_10"] > 0: sc += 5
        sig.momentum_score = min(100, sc)
        
        g = momentum_grade(sig)
        grades.append(g)
    
    entries["grade"] = grades
    
    GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6}
    
    print(f"\n  Total entries: {len(entries)}")
    print(f"\n  {'Grade':>5s} {'N':>6s} {'Win%':>6s} {'Avg':>8s} {'Med':>8s} {'Sharpe':>7s}")
    print(f"  {'-'*5} {'-'*6} {'-'*6} {'-'*8} {'-'*8} {'-'*7}")
    
    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        sub = entries[entries["grade"] == g]
        if len(sub) < 5:
            continue
        pnl = sub[horizon]
        win = (pnl > 0).mean() * 100
        avg = pnl.mean()
        med = pnl.median()
        std = pnl.std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        print(f"  {g:>5s} {len(sub):6d} {win:5.1f}% {avg:+7.2f}% {med:+7.2f}% {sh:+6.2f}")
    
    # Does grade predict PnL?
    entries["grade_ord"] = entries["grade"].map(GRADE_ORD)
    r = entries["grade_ord"].corr(entries[horizon])
    print(f"\n  Grade ↔ {horizon} correlation: r = {r:+.4f}")
    print(f"  {'→ Grade PREDICTS outcome' if r < -0.03 else '→ Grade does NOT predict (same issue as MR score)'}")
    
    return entries


def vol_deep_dive(trades: pd.DataFrame, horizon="fwd_10d"):
    """Deep dive on volume ratio — the factor you asked about."""
    logger.info("\n" + "=" * 70)
    logger.info("VOLUME RATIO DEEP DIVE")
    logger.info("=" * 70)
    
    entries = trades[trades["entry"]].copy()
    if len(entries) < 30:
        print(f"  Only {len(entries)} entries — too few")
        return
    
    print(f"\n  Vol ratio distribution (entries only):")
    print(f"    min={entries['vol_ratio'].min():.2f}  p25={entries['vol_ratio'].quantile(0.25):.2f}  "
          f"med={entries['vol_ratio'].median():.2f}  p75={entries['vol_ratio'].quantile(0.75):.2f}  "
          f"max={entries['vol_ratio'].max():.2f}")
    
    print(f"\n  {'Vol bucket':>15s} {'N':>6s} {'Win%':>6s} {'Avg':>8s} {'Med':>8s}")
    print(f"  {'-'*15} {'-'*6} {'-'*6} {'-'*8} {'-'*8}")
    
    for label, lo, hi in [("<0.5x", 0, 0.5), ("0.5-1.0x", 0.5, 1.0),
                           ("1.0-1.5x", 1.0, 1.5), ("1.5-2.0x", 1.5, 2.0),
                           (">2.0x", 2.0, 99)]:
        sub = entries[(entries["vol_ratio"] >= lo) & (entries["vol_ratio"] < hi)]
        if len(sub) < 5:
            continue
        pnl = sub[horizon]
        win = (pnl > 0).mean() * 100
        avg = pnl.mean()
        med = pnl.median()
        print(f"  {label:>15s} {len(sub):6d} {win:5.1f}% {avg:+7.2f}% {med:+7.2f}%")
    
    r = entries["vol_ratio"].corr(entries[horizon])
    print(f"\n  vol_ratio ↔ {horizon}: r = {r:+.4f}")
    print(f"  {'→ ADD to grade (+1 pt for vol≥1.5x)' if r > 0.03 else '→ NOT predictive — do NOT add'}")


def main():
    parser = argparse.ArgumentParser(description="ETF Momentum Factor Study")
    parser.add_argument("--years", type=int, default=5, help="Years of data")
    parser.add_argument("--stocks", type=int, default=35, help="Max ETFs")
    args = parser.parse_args()
    
    symbols = ETF_SYMBOLS[:args.stocks]
    logger.info("ETF Factor Study: %d ETFs, %d years", len(symbols), args.years)
    
    # Fetch VIX
    logger.info("Fetching VIX...")
    vix_df = fetch_daily("^INDIAVIX", args.years)
    vix = vix_df["Close"].dropna() if not vix_df.empty else pd.Series(dtype=float)
    logger.info("VIX: %d bars", len(vix))
    
    # Fetch all ETFs and compute factors
    all_factors = []
    failed = 0
    for i, sym in enumerate(symbols):
        logger.info("  [%d/%d] %s", i+1, len(symbols), sym)
        df = fetch_daily(sym, args.years)
        if df is None or len(df) < 80:
            logger.warning("    %s: insufficient data (%d bars)", sym, len(df) if df is not None else 0)
            failed += 1
            continue
        
        factors = compute_factors(df, sym)
        if len(factors) == 0:
            failed += 1
            continue
        
        # Add VIX
        if not vix.empty:
            factors["vix"] = vix.reindex(factors.index, method="ffill")
        
        all_factors.append(factors)
        time.sleep(0.5)  # rate limit
    
    if not all_factors:
        logger.error("No data — check yfinance connection")
        return
    
    trades = pd.concat(all_factors, ignore_index=True)
    entries = trades[trades["entry"]]
    logger.info("\nTotal bars: %d, Entry signals: %d from %d ETFs (%d failed)",
                len(trades), len(entries), len(symbols) - failed, failed)
    
    # Run analyses
    factor_analysis(entries, "fwd_10d")
    factor_analysis(entries, "fwd_21d")
    leave_one_out(entries, "fwd_10d")
    grade_backtest(trades, "fwd_10d")
    vol_deep_dive(trades, "fwd_10d")
    
    # Export
    out = os.path.join("data", "backtest_results")
    os.makedirs(out, exist_ok=True)
    entries.to_csv(os.path.join(out, "etf_factor_entries.csv"), index=False)
    logger.info("\nExported %d entries to %s/etf_factor_entries.csv", len(entries), out)
    logger.info("Done.")


if __name__ == "__main__":
    main()
