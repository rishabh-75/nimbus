#!/usr/bin/env python3
"""volume_probe.py — does PEER-RELATIVE volume surge predict returns?

THE IDEA
--------
The app already shows ``vol_ratio = latest volume / its own 20-bar mean``.
That is SELF-relative, and it cannot tell these two situations apart:

    (a) Pharma is having a huge day — EVERY pharma name shows 2x volume.
        Nothing is happening to any individual stock; the sector is active.
    (b) Pharma is quiet, but GRANULES alone is at 2x.
        That is someone accumulating THAT NAME.

Today both read "2.00x". A PEER-RELATIVE measure separates them:

    vol_shift = stock's vol_ratio / industry's MEDIAN vol_ratio

This is the volume analogue of the Edge model's ``member_shift`` (which is
price-relative-to-industry). It asks: is the money going into THIS name
specifically, or is the whole sector just busy?

WHY THIS IS WORTH TESTING WHEN EVERYTHING ELSE FAILED
-----------------------------------------------------
Every input currently in the Edge model is a PRICE transform — RS_excess,
member_shift, streak, thrust. All of them scored at or BELOW a random
control against forward returns. Volume is the one input carrying a
DIFFERENT kind of information, so it is the only candidate with a real
chance of escaping that.

And there is a thin thread of evidence: in the confirmation-gate experiment
``ctl:vol_ratio`` was the ONLY control that scored above random (+0.045 vs
+0.000). It was unstarred, and I dismissed it as multiple-comparisons noise
— correctly, on that evidence. But it is suggestive that the one non-price
input was also the one flicker of life. This probe is the proper test of it.

HORIZONS: 5 and 10 days. Volume surge is an EVENT signal — accumulation
shows up over days, not a month. A 20d window would let the effect decay
into noise before we measured it.

WHAT IS TESTED
--------------
Several volume constructions, because "peer-relative surge" has more than
one reasonable definition and they say different things:

    vol_ratio        the SHIPPED self-relative measure (the baseline to beat)
    vol_shift        vol_ratio / industry median vol_ratio      <- the idea
    vol_shift_log    log of the above (tames the fat right tail)
    vol_z            z-score of the stock's vol_ratio within its industry
    vol_x_thrust     vol_shift * sign(5d return)   <- surge WITH direction
    dollar_shift     same, but on TRADED VALUE not share count

Plus a RANDOM CONTROL on the same table. If nothing beats it, there is
nothing here — that is the whole point of putting it on the same page.

USAGE
    python volume_probe.py
    python volume_probe.py --horizons 5,10 --dates 20 --csv vol.csv
"""
from __future__ import annotations

import argparse
import statistics
import sys


def spearman(a, b):
    def ranks(xs):
        order = sorted(range(len(xs)), key=lambda i: xs[i], reverse=True)
        r = [0] * len(xs)
        for pos, i in enumerate(order):
            r[i] = pos
        return r
    n = len(a)
    if n < 3:
        return float("nan")
    ra, rb = ranks(a), ranks(b)
    d2 = sum((ra[i] - rb[i]) ** 2 for i in range(n))
    return 1.0 - 6.0 * d2 / (n * (n * n - 1))


def load_panel(engine, ind_db):
    from nimbus_v3.data.cache import ParquetCache
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.paths import cache_dir

    raw = ParquetCache(base_dir=cache_dir("equity_price"))
    ec = EnrichedPanelCache(raw_cache=raw,
                            schema_hash=engine.enrichment_schema_hash())
    panel, members = {}, {}
    for sym in sorted(ind_db):
        df = ec.get_if_fresh(sym)
        if df is None:
            df = ec.get_stale(sym)
        if df is None:
            try:
                r = raw.get(sym)
            except Exception:            # noqa: BLE001
                r = None
            if r is not None and not r.empty:
                try:
                    df = engine.enrich(r, sym)
                except Exception:        # noqa: BLE001
                    df = None
        if df is None or df.empty:
            continue
        panel[sym] = df
        rec = ind_db.get(sym)
        if rec is not None and rec.industry:
            members.setdefault(rec.industry, []).append(sym)
    return panel, members


VOL_WINDOW = 20


def features_at(panel, members, asof, rng):
    """Build every candidate volume feature as of the DATE ``asof``.

    Slicing by DATE, not position. Symbols have different histories (recent
    listings are short), so `df.iloc[:cut]` would mean a DIFFERENT DATE for
    every stock — comparing a peer group across mismatched dates, which is
    nonsense. `df.loc[:asof]` aligns them.

    Everything is computed from data at or before ``asof``, so there is no
    lookahead. The forward return is measured after it.
    """
    import numpy as np

    per_sym = {}
    for sym, df in panel.items():
        h = df.loc[:asof]
        if len(h) < VOL_WINDOW + 15:
            continue
        vol = h["Volume"].to_numpy(dtype=float)
        close = h["Close"].to_numpy(dtype=float)
        mean_v = float(np.nanmean(vol[-VOL_WINDOW:]))
        if not np.isfinite(mean_v) or mean_v <= 0:
            continue
        vr = float(vol[-1]) / mean_v                 # the SHIPPED measure

        # Traded VALUE, not share count: a 2x volume day in a Rs 50 stock
        # and in a Rs 5,000 stock are not the same event.
        val = vol * close
        mean_val = float(np.nanmean(val[-VOL_WINDOW:]))
        dr = (float(val[-1]) / mean_val) if mean_val > 0 else float("nan")

        c5 = ((close[-1] / close[-6] - 1.0) * 100.0
              if len(close) > 6 and close[-6] > 0 else 0.0)

        per_sym[sym] = {"vr": vr, "dr": dr, "c5": c5}

    # ---- peer-relative: the whole point ------------------------------
    feats = {}
    for ind, syms in members.items():
        pool = [s for s in syms if s in per_sym]
        if len(pool) < 5:                 # too few peers to be "relative" TO
            continue
        vrs = np.array([per_sym[s]["vr"] for s in pool], dtype=float)
        drs = np.array([per_sym[s]["dr"] for s in pool], dtype=float)
        med = float(np.nanmedian(vrs))
        med_d = float(np.nanmedian(drs))
        mu, sd = float(np.nanmean(vrs)), float(np.nanstd(vrs))

        for s in pool:
            d = per_sym[s]
            shift = d["vr"] / med if med > 0 else float("nan")
            z = (d["vr"] - mu) / sd if sd > 0 else 0.0
            feats[s] = {
                "vol_ratio": d["vr"],                       # baseline
                "vol_shift": shift,                        # THE IDEA
                "vol_shift_log": (np.log(shift)
                                  if shift == shift and shift > 0
                                  else float("nan")),
                "vol_z": z,
                # Surge WITH direction: buying pressure, not just activity.
                # A volume spike on a down day is distribution, not
                # accumulation — treating them alike throws away the sign.
                "vol_x_thrust": (shift * np.sign(d["c5"])
                                 if shift == shift else float("nan")),
                "dollar_shift": (d["dr"] / med_d
                                 if med_d > 0 else float("nan")),
                "~random~": rng.random(),
            }
    return feats


def forward_excess(panel, feats, asof, horizon):
    """Forward EXCESS return from ``asof``, over the equal-weight market.

    Excess, deliberately: raw returns would mostly measure "did the market go
    up over these ten days", which says nothing about whether the SIGNAL
    picked the right names.
    """
    import numpy as np

    fwd = {}
    for sym in feats:
        df = panel[sym]
        idx = df.index
        pos = idx.searchsorted(asof, side="right") - 1
        if pos < 0 or pos + horizon >= len(idx):
            continue
        c = df["Close"].to_numpy(dtype=float)
        c0, c1 = c[pos], c[pos + horizon]
        if c0 > 0:
            fwd[sym] = (c1 / c0 - 1.0) * 100.0
    if len(fwd) < 40:
        return None, None
    return fwd, float(np.mean(list(fwd.values())))


def run_date(panel, members, asof, horizon, rng):
    """One as-of DATE. Returns {feature: [(value, fwd_excess_ret)]}."""
    feats = features_at(panel, members, asof, rng)
    if len(feats) < 40:
        return None

    fwd, mkt = forward_excess(panel, feats, asof, horizon)
    if fwd is None:
        return None

    out = {}
    keys = next(iter(feats.values())).keys()
    for k in keys:
        rows = [(feats[s][k], fwd[s] - mkt)
                for s in fwd
                if feats[s][k] == feats[s][k]]
        if len(rows) >= 40:
            out[k] = rows
    return out


def event_study(panel, members, all_dates, horizons, thresholds, rng,
                dates, step, var="vol_shift"):
    """The frame an EVENT signal actually deserves.

    Ranking is the wrong question here. A volume surge is a property of
    INDIVIDUAL NAMES on INDIVIDUAL DAYS, not a cross-section to sort: on a
    quiet day the "top 15 by volume shift" are just that day's random
    high-volume names, and scoring them dilutes the real cases into noise.

    So instead: pool every (symbol, day) where vol_shift crossed a
    threshold, and ask what those names did NEXT — against the base rate of
    every other name on the same days. That is the question a trader
    actually has: "GRANULES just printed 3x its peers' volume. Now what?"
    """
    out = {}
    for H in horizons:
        # Base rate: forward excess return of ALL names on ALL sampled days.
        surged = {t: [] for t in thresholds}
        base = []
        for i in range(dates):
            di = len(all_dates) - H - 1 - i * step
            if di < VOL_WINDOW + 40:
                break
            asof = all_dates[di]
            feats = features_at(panel, members, asof, rng)
            if len(feats) < 40:
                continue
            fwd, mkt = forward_excess(panel, feats, asof, H)
            if fwd is None:
                continue
            for sym, fr in fwd.items():
                ex = fr - mkt
                base.append(ex)
                vs = feats[sym].get(var, float("nan"))
                if vs != vs:
                    continue
                for t in thresholds:
                    if vs >= t:
                        surged[t].append(ex)
        out[H] = (base, surged)
    return out


def score(rows, topk):
    rows = sorted(rows, key=lambda t: -t[0])
    n = len(rows)
    if n < topk * 2:
        return None
    rho = spearman([t[0] for t in rows], [t[1] for t in rows])
    top = statistics.mean(t[1] for t in rows[:topk])
    bot = statistics.mean(t[1] for t in rows[-topk:])
    return rho, top, top - bot


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--horizons", default="5,10",
                    help="forward horizons in bars (volume surge is an "
                         "EVENT signal — days, not a month)")
    ap.add_argument("--dates", type=int, default=60,
                    help="as-of dates. Needs to be LARGE: on most days "
                         "nothing is surging, so a handful of dates mostly "
                         "samples quiet tape and dilutes any real effect "
                         "into noise.")
    ap.add_argument("--step", type=int, default=5)
    ap.add_argument("--min-surge", type=float, default=0.0,
                    help="only score dates where the TOP-ranked name has at "
                         "least this vol_shift (e.g. 2.0). This is the "
                         "EVENT filter: it asks 'when something IS surging, "
                         "does it predict?' rather than diluting the answer "
                         "across quiet days.")
    ap.add_argument("--topk", type=int, default=15)
    ap.add_argument("--csv", default=None)
    args = ap.parse_args()

    import numpy as np
    import pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    print("loading panel...", file=sys.stderr)
    panel, members = load_panel(eng, db)
    if not panel:
        print("panel empty — run the app once first.", file=sys.stderr)
        return 1
    # A DATE grid, not a positional one.
    #
    # This used to be `min(len(df) for df in panel.values())` — the shortest
    # symbol's bar count. One recent listing with 204 bars therefore
    # truncated the ENTIRE study to 204 bars, silently discarding ~4 years
    # of history on the other 480 names. Every earlier run of this probe was
    # measuring 10 months of data while claiming to measure 5 years.
    #
    # Indexing by DATE instead lets each symbol contribute whatever history
    # it actually has: a stock that listed last year simply is not in the
    # cross-section for dates before it existed.
    lens = sorted(len(df) for df in panel.values())
    all_dates = sorted({d for df in panel.values() for d in df.index})
    print(f"  {len(panel)} symbols, {len(members)} industries",
          file=sys.stderr)
    print(f"  bars per symbol: min={lens[0]}  median={lens[len(lens) // 2]}"
          f"  max={lens[-1]}", file=sys.stderr)
    print(f"  date span: {all_dates[0].date()} -> {all_dates[-1].date()}  "
          f"({len(all_dates)} trading days)", file=sys.stderr)
    if lens[0] < lens[-1] // 4:
        print(f"  (the shortest symbol has only {lens[0]} bars — it is NOT "
              f"allowed to cap the study)", file=sys.stderr)

    rng = np.random.default_rng(11)
    horizons = [int(h) for h in args.horizons.split(",")]
    rows_out = []

    for H in horizons:
        acc = {}
        used = 0
        surge_at_top = []
        for i in range(args.dates):
            di = len(all_dates) - H - 1 - i * args.step
            if di < VOL_WINDOW + 40:
                break
            asof = all_dates[di]
            res = run_date(panel, members, asof, H, rng)
            if not res:
                continue

            # EVENT FILTER. On a quiet day the "top 15 by volume shift" are
            # just the day's random high-volume names — ranking them tells
            # us nothing. Skip dates where nothing is actually surging.
            if args.min_surge > 0 and "vol_shift" in res:
                top_shift = max(v for v, _ in res["vol_shift"])
                if top_shift < args.min_surge:
                    continue

            if "vol_shift" in res:
                vals = sorted((v for v, _ in res["vol_shift"]), reverse=True)
                surge_at_top.append(statistics.mean(vals[:args.topk]))

            used += 1
            for k, rows in res.items():
                sc = score(rows, args.topk)
                if sc:
                    acc.setdefault(k, []).append(sc)
        if not acc:
            continue

        print()
        print("=" * 86)
        print(f"  PEER-RELATIVE VOLUME — {H}-day forward EXCESS return, "
              f"{used} as-of dates")
        if surge_at_top:
            m = statistics.mean(surge_at_top)
            print(f"  Mean vol_shift of the top-{args.topk} on a scored "
                  f"date: {m:.2f}x peer median")
            if m < 1.6:
                print("  ^^ LOW. The ranking is mostly picking quiet names, "
                      "not surges.")
                print("     Re-run with --min-surge 2.0 to ask the sharper "
                      "question:")
                print("     'when something IS surging, does it predict?'")
        print("=" * 86)
        print(f"  {'feature':<18}{'rho':>16}{'top-k excess':>17}"
              f"{'top-bot spread':>18}{'sig':>6}")
        print(f"  {'':<18}{'mean (sd)':>16}{'mean (sd)':>17}{'mean (sd)':>18}")
        print("  " + "-" * 82)

        order = ["vol_ratio", "vol_shift", "vol_shift_log", "vol_z",
                 "vol_x_thrust", "dollar_shift", "~random~"]
        for k in order:
            if k not in acc:
                continue
            vals = acc[k]
            rhos = [v[0] for v in vals if v[0] == v[0]]
            tops = [v[1] for v in vals]
            sprs = [v[2] for v in vals]

            def ms(xs, pct=False):
                m = statistics.mean(xs)
                sd = statistics.stdev(xs) if len(xs) > 1 else 0.0
                return (f"{m:+.2f}% ({sd:.1f})" if pct
                        else f"{m:+.3f} ({sd:.2f})")

            # |mean| > 2 standard errors from zero. Anything unstarred is
            # indistinguishable from noise and must NOT be acted on.
            sig = ""
            if len(tops) > 1:
                se = statistics.stdev(tops) / (len(tops) ** 0.5)
                if se > 0 and abs(statistics.mean(tops)) > 2 * se:
                    sig = " *"
            tag = "  <<< CONTROL" if k == "~random~" else (
                "  <<< SHIPPED" if k == "vol_ratio" else "")
            print(f"  {k:<18}{ms(rhos):>16}{ms(tops, True):>17}"
                  f"{ms(sprs, True):>18}{sig:>6}{tag}")

            rows_out.append({
                "horizon": H, "feature": k,
                "rho_mean": statistics.mean(rhos) if rhos else float("nan"),
                "rho_sd": (statistics.stdev(rhos) if len(rhos) > 1 else 0.0),
                "topk_mean": statistics.mean(tops),
                "topk_sd": statistics.stdev(tops) if len(tops) > 1 else 0.0,
                "spread_mean": statistics.mean(sprs),
                "n_dates": len(vals), "significant": bool(sig.strip()),
            })

    # ---- BUCKET SWEEP: where does volume turn from good to bad? -------
    # The cumulative thresholds below (">= 1.5x") lump a 1.6x name in with a
    # 5x blowoff, so they cannot show WHERE the sign flips. Disjoint buckets
    # can. This is the question: "there must be a threshold above which it
    # becomes a problem" — so find it rather than assume it.
    edges = [0.0, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 5.0, 1e9]

    # TWO DIFFERENT QUESTIONS, and they must not be conflated:
    #
    #   vol_ratio  = volume / its OWN 20-bar mean
    #                "is this stock busier than IT usually is?"
    #                <-- this is what the SHIPPED confirmation gate uses
    #
    #   vol_shift  = vol_ratio / the industry's MEDIAN vol_ratio
    #                "is this stock busier than ITS PEERS are right now?"
    #                <-- this is the proposal; it is the volume analogue of
    #                    member_shift, and structurally belongs in the EDGE,
    #                    not the gate.
    #
    # The first run of this probe only event-tested vol_shift. Acting on
    # that to "fix" the gate would have meant changing a term (vol_ratio)
    # using evidence about a DIFFERENT quantity. Both are tested now.
    for bucket_var in ("vol_ratio", "vol_shift"):
      print()
      print("=" * 86)
      print(f"  BUCKET SWEEP — forward excess return by {bucket_var} BAND")
      if bucket_var == "vol_ratio":
          print("  (SELF-relative: 'busier than it usually is'"
                " — what the GATE uses today)")
      else:
          print("  (PEER-relative: 'busier than its peers'"
                " — the proposed member-shift analogue)")
      print("=" * 86)
      for H in horizons:
        buckets = {i: [] for i in range(len(edges) - 1)}
        rng2 = np.random.default_rng(31)
        for i in range(args.dates):
            di = len(all_dates) - H - 1 - i * args.step
            if di < VOL_WINDOW + 40:
                break
            asof = all_dates[di]
            feats = features_at(panel, members, asof, rng2)
            if len(feats) < 40:
                continue
            fwd, mkt = forward_excess(panel, feats, asof, H)
            if fwd is None:
                continue
            for sym, fr in fwd.items():
                vs = feats[sym].get(bucket_var, float("nan"))
                if vs != vs:
                    continue
                for bi in range(len(edges) - 1):
                    if edges[bi] <= vs < edges[bi + 1]:
                        buckets[bi].append(fr - mkt)
                        break
        print(f"  {H}-day forward excess return")
        print(f"    {bucket_var + ' band':<20}{'n':>8}{'mean':>10}{'t':>8}")
        print("    " + "-" * 46)
        for bi in range(len(edges) - 1):
            g = buckets[bi]
            if len(g) < 30:
                continue
            lo, hi = edges[bi], edges[bi + 1]
            lbl = (f"{lo:.2f} - {hi:.2f}x" if hi < 1e8
                   else f">= {lo:.2f}x")
            m = statistics.mean(g)
            sd = statistics.stdev(g) if len(g) > 1 else 0.0
            se = sd / (len(g) ** 0.5) if g else float("inf")
            t = m / se if se > 0 else 0.0
            star = " *" if abs(t) > 2 else ""
            print(f"    {lbl:<20}{len(g):>8}{m:>+9.2f}%{t:>8.1f}{star}")
        print()
    print("  Read the SIGN down the column. If the early bands are positive")
    print("  and the late ones negative, there is a genuine crossover and a")
    print("  threshold is the right shape for the fix. If every band is")
    print("  negative, volume is simply bad news at every level and a")
    print("  threshold would be arbitrary.")
    print()

    # ---- EVENT STUDY -------------------------------------------------
    thresholds = [1.5, 2.0, 3.0]
    for ev_var in ("vol_ratio", "vol_shift"):
        es = event_study(panel, members, all_dates, horizons, thresholds,
                         np.random.default_rng(23), args.dates, args.step,
                         var=ev_var)
        print()
        print("=" * 86)
        print(f"  EVENT STUDY [{ev_var}] — 'this name just printed Nx. "
              f"Now what?'")
        if ev_var == "vol_ratio":
            print("  SELF-relative ('busier than IT usually is')."
                  "  <-- what the GATE uses")
        else:
            print("  PEER-relative ('busier than ITS PEERS')."
                  "  <-- the member-shift analogue")
        print("=" * 86)
        for H in horizons:
            base, surged = es.get(H, ([], {}))
            if not base:
                continue
            b_mean = statistics.mean(base)
            print(f"  {H}-day forward excess return")
            print(f"    {'cohort':<26}{'n':>7}{'mean':>10}{'vs base':>10}"
                  f"{'t':>7}")
            print("    " + "-" * 60)
            print(f"    {'ALL names (base rate)':<26}{len(base):>7}"
                  f"{b_mean:>+9.2f}%{'-':>10}{'-':>7}")
            for t in thresholds:
                g = surged.get(t, [])
                if len(g) < 20:
                    print(f"    {'>= ' + str(t) + 'x':<26}{len(g):>7}"
                          f"{'-':>10}{'(too few)':>10}{'':>7}")
                    continue
                m = statistics.mean(g)
                sd = statistics.stdev(g) if len(g) > 1 else 0.0
                se = sd / (len(g) ** 0.5) if g else float("inf")
                diff = m - b_mean
                tstat = diff / se if se > 0 else 0.0
                star = " *" if abs(tstat) > 2 else ""
                print(f"    {'>= ' + str(t) + 'x':<26}{len(g):>7}"
                      f"{m:>+9.2f}%{diff:>+9.2f}%{tstat:>7.1f}{star}")
            print()

    print("  THE COMPARISON THAT MATTERS")
    print("  vol_ratio is what the confirmation gate uses TODAY. vol_shift")
    print("  is the proposal. They answer DIFFERENT questions, so a finding")
    print("  about one says nothing about the other — and the gate must not")
    print("  be 'fixed' with evidence about a quantity it does not use.")
    print()
    print("  * If vol_ratio's cohorts are NEGATIVE, the gate is currently")
    print("    REWARDING a bad signal (it treats a surge as confirmation).")
    print("  * If vol_shift is negative but vol_ratio is not, the peer")
    print("    version carries information the self version does not — and")
    print("    it belongs in the EDGE (beside member_shift), not the gate.")
    print()
    print()
    print("  HOW TO READ THIS")
    print("  * vol_ratio is what SHIPS today (self-relative). vol_shift is")
    print("    the proposal (peer-relative). If vol_shift does not beat")
    print("    vol_ratio, the peer normalisation adds nothing and the idea")
    print("    is dead however sensible the story sounds.")
    print("  * ~random~ is the noise floor. If nothing beats it, there is")
    print("    nothing here. Every price-derived signal we have tested so")
    print("    far has failed exactly this test.")
    print("  * A '*' means |mean| clears 2 standard errors. NO STAR = noise,")
    print("    however good the mean looks. The sd column is why: a +2%")
    print("    mean on a 7% sd across dates is not a finding.")
    print("  * Watch the SPREAD too. rho can look fine while top-minus-")
    print("    bottom is ~0, which means the ranking is not separating")
    print("    winners from losers at all.")
    print()

    if args.csv:
        pd.DataFrame(rows_out).to_csv(args.csv, index=False)
        print(f"wrote {args.csv}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
