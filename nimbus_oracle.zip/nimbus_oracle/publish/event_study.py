#!/usr/bin/env python3
"""
publish/event_study.py — Forward-return event study charts.

Finds historical dates where a condition fired, measures what happened after,
and renders a SubuTrade-style chart: price + indicator + forward return table.

Presets:
    python3 publish/event_study.py --preset vix_25
    python3 publish/event_study.py --preset red_5d
    python3 publish/event_study.py --preset dd_10

Custom:
    python3 publish/event_study.py --event vix_spike --threshold 30 --years 10
    python3 publish/event_study.py --event red_streak --threshold 7 --years 5
    python3 publish/event_study.py --event drawdown --threshold 15 --years 10
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from publish.common import (
    nimbus_style, export_figure, add_timestamp, COLORS,
)
from modules.event_study import (
    compute_forward_returns, detect_vix_spike, detect_consecutive_red_days,
    detect_drawdown_breach, PRESETS, DEFAULT_HORIZONS,
    EventStudyResult, _ensure_series,
)

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("publish_event_study")


# ══════════════════════════════════════════════════════════════════════════════
# DATA FETCH
# ══════════════════════════════════════════════════════════════════════════════

def _fetch_nifty(years: int = 10) -> pd.DataFrame:
    """Fetch NIFTY 50 daily data via yfinance. Tries multiple tickers."""
    import yfinance as yf
    start = (datetime.date.today() - datetime.timedelta(days=years * 365)).strftime("%Y-%m-%d")
    for ticker in ["^NSEI", "NIFTY_50.NS", "^CNXNIFTY"]:
        try:
            df = yf.download(ticker, start=start, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if not df.empty and len(df) > 100:
                return df
        except Exception:
            continue
    return pd.DataFrame()


def _fetch_vix(years: int = 10) -> pd.Series:
    """Fetch India VIX daily data. Tries multiple tickers."""
    import yfinance as yf
    start = (datetime.date.today() - datetime.timedelta(days=years * 365)).strftime("%Y-%m-%d")
    for ticker in ["^INDIAVIX", "INDIAVIX.NS"]:
        try:
            df = yf.download(ticker, start=start, progress=False, auto_adjust=True)
            if df.empty:
                continue
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            s = df["Close"].dropna()
            if isinstance(s, pd.DataFrame):
                s = s.iloc[:, 0]
            if len(s) > 50:
                return s
        except Exception:
            continue
    return pd.Series(dtype=float)


# ══════════════════════════════════════════════════════════════════════════════
# CHART RENDERER
# ══════════════════════════════════════════════════════════════════════════════

def render_event_study(result: EventStudyResult) -> plt.Figure:
    """
    Render SubuTrade-style event study chart:
      - Top: price line with vertical event markers
      - Middle: indicator series with threshold line
      - Bottom: forward return table (color-coded)
    """
    if result.returns_df is None or result.returns_df.empty:
        logger.error("No events to chart")
        return None

    df = result.returns_df
    horizons = [c for c in df.columns if c in DEFAULT_HORIZONS]

    # Adaptive sizing
    n_events = len(df)
    row_px = 16 if n_events <= 15 else (14 if n_events <= 25 else 12)
    table_height = max(2.8, (n_events + 4) * row_px / 72)  # 72 dpi
    chart_height = 5.0
    fig_height = chart_height + table_height + 1.0

    with nimbus_style():
        fig = plt.figure(figsize=(14, fig_height))

        gs = GridSpec(2, 1, figure=fig, height_ratios=[chart_height, table_height],
                      hspace=0.12, top=0.91, bottom=0.03, left=0.07, right=0.96)

        # ── Chart zone: price + indicator (no gap, shared x-axis) ────
        gs_charts = gs[0].subgridspec(2, 1, hspace=0.0, height_ratios=[1.5, 1])

        # Price chart — no x labels, seamless join with indicator
        ax_price = fig.add_subplot(gs_charts[0])
        prices = result.price_series
        if prices is not None and not prices.empty:
            ax_price.plot(prices.index, prices.values, color=COLORS["blue"],
                         linewidth=1.0, zorder=3)
            for evt in result.event_dates:
                evt_ts = pd.Timestamp(evt)
                if prices.index[0] <= evt_ts <= prices.index[-1]:
                    ax_price.axvline(x=evt_ts, color=COLORS["emerald"],
                                    linewidth=0.7, linestyle=":", alpha=0.6, zorder=2)

        ax_price.set_ylabel("Price", fontsize=8, color=COLORS["muted"])
        ax_price.tick_params(labelbottom=False, bottom=False)
        ax_price.spines["bottom"].set_visible(False)

        # Title + subtitle (stacked, no overlap)
        fig.text(0.07, 0.96, result.title,
                fontsize=13, fontweight=700, color=COLORS["white"])
        fig.text(0.07, 0.93, result.subtitle,
                fontsize=8, color=COLORS["muted"], style="italic")
        add_timestamp(fig)

        # Indicator chart
        ax_ind = fig.add_subplot(gs_charts[1], sharex=ax_price)
        if result.indicator_series is not None and not result.indicator_series.empty:
            ind = result.indicator_series
            ax_ind.bar(ind.index, ind.values, color=COLORS["white"],
                      width=1.5, alpha=0.6, zorder=2)
            if result.threshold is not None:
                ax_ind.axhline(y=result.threshold, color=COLORS["emerald"],
                              linewidth=1.2, linestyle="--", zorder=3)
                current_val = float(ind.iloc[-1])
                ax_ind.text(ind.index[-1], result.threshold,
                           f"  {result.threshold:.0f}",
                           fontsize=8, color=COLORS["emerald"], va="bottom")
                ax_ind.text(ind.index[-1], current_val,
                           f"  {current_val:.1f}",
                           fontsize=9, fontweight=600, color=COLORS["red"],
                           va="bottom")

            for evt in result.event_dates:
                evt_ts = pd.Timestamp(evt)
                if ind.index[0] <= evt_ts <= ind.index[-1]:
                    ax_ind.axvline(x=evt_ts, color=COLORS["emerald"],
                                  linewidth=0.7, linestyle=":", alpha=0.6, zorder=2)

        ax_ind.set_ylabel(result.indicator_label, fontsize=8, color=COLORS["muted"])
        ax_ind.tick_params(labelsize=7)

        # ── Table zone ───────────────────────────────────────────────────
        ax_table = fig.add_subplot(gs[1])
        ax_table.axis("off")

        _render_table(ax_table, df, horizons, result)

    return fig


def _render_table(ax, df, horizons, result):
    """Render the forward return table with color coding."""

    n_events = len(df)
    # Adaptive font sizing
    if n_events <= 12:
        fs_date, fs_val, fs_hdr, fs_sum = 7, 7, 7.5, 7.5
        date_fmt = "%B %-d, %Y"
    elif n_events <= 20:
        fs_date, fs_val, fs_hdr, fs_sum = 6.5, 6.5, 7, 7
        date_fmt = "%b %-d, %Y"
    else:
        fs_date, fs_val, fs_hdr, fs_sum = 5.5, 5.5, 6.5, 6.5
        date_fmt = "%b %-d, %Y"

    # Prepare data rows
    rows = []
    for date_idx, row in df.iterrows():
        date_str = pd.Timestamp(date_idx).strftime(date_fmt)
        vals = [row.get(h, np.nan) for h in horizons]
        rows.append((date_str, vals))

    avg_vals = [result.avg_returns.get(h, 0) for h in horizons]
    pct_vals = [result.pct_positive.get(h, 0) for h in horizons]

    # Column layout: wider date column, equal data columns
    n_data_cols = len(horizons)
    date_col_w = 0.14
    data_col_w = (0.88 - date_col_w) / n_data_cols
    total_n = len(rows) + 4  # title + header + data + avg + pct
    row_h = min(0.042, 0.92 / total_n)
    x0 = 0.06
    y = 0.96

    # ── Table title ───────────────────────────────────────────────────
    title_text = result.title.split("after")[-1].strip() if "after" in result.title else result.title
    ax.text(x0, y, f"{title_text} — past {len(rows)} cases",
           fontsize=fs_sum + 1, fontweight=600, color=COLORS["white"],
           transform=ax.transAxes, va="top")
    y -= row_h * 1.5

    # ── Column headers ────────────────────────────────────────────────
    # Date header (left-aligned in wider column)
    ax.text(x0 + date_col_w * 0.5, y, "",
           fontsize=fs_hdr, transform=ax.transAxes, ha="center", va="center")
    for j, h in enumerate(horizons):
        x = x0 + date_col_w + j * data_col_w
        ax.text(x + data_col_w / 2, y, h,
               fontsize=fs_hdr, fontweight=600, color=COLORS["muted"],
               transform=ax.transAxes, ha="center", va="center")
    y -= row_h * 0.7

    # Divider
    ax.plot([x0, x0 + date_col_w + n_data_cols * data_col_w], [y, y],
           color=COLORS["border"], linewidth=0.5, transform=ax.transAxes)
    y -= row_h * 0.5

    # ── Data rows ─────────────────────────────────────────────────────
    for date_str, vals in rows:
        # Date (left-aligned)
        ax.text(x0 + 0.005, y, date_str,
               fontsize=fs_date, color=COLORS["white"], fontweight=500,
               transform=ax.transAxes, ha="left", va="center")
        # Values
        for j, v in enumerate(vals):
            x = x0 + date_col_w + j * data_col_w
            if np.isnan(v):
                txt, color = "—", COLORS["dim"]
            else:
                txt = f"{v:+.2f}%"
                color = COLORS["emerald"] if v >= 0 else COLORS["red"]
                # Background highlight for strong moves
                if v < -5:
                    rect = plt.Rectangle(
                        (x + 0.002, y - row_h * 0.35), data_col_w - 0.004, row_h * 0.7,
                        transform=ax.transAxes, facecolor=COLORS["red"], alpha=0.15,
                        edgecolor="none", clip_on=False)
                    ax.add_patch(rect)
                elif v > 8:
                    rect = plt.Rectangle(
                        (x + 0.002, y - row_h * 0.35), data_col_w - 0.004, row_h * 0.7,
                        transform=ax.transAxes, facecolor=COLORS["emerald"], alpha=0.10,
                        edgecolor="none", clip_on=False)
                    ax.add_patch(rect)

            ax.text(x + data_col_w / 2, y, txt,
                   fontsize=fs_val, color=color,
                   transform=ax.transAxes, ha="center", va="center",
                   fontfamily="monospace")
        y -= row_h

    # ── Divider ───────────────────────────────────────────────────────
    y -= row_h * 0.2
    ax.plot([x0, x0 + date_col_w + n_data_cols * data_col_w], [y, y],
           color=COLORS["border"], linewidth=0.5, transform=ax.transAxes)
    y -= row_h * 0.6

    # ── Average row ───────────────────────────────────────────────────
    ax.text(x0 + 0.005, y, "Average:",
           fontsize=fs_sum, color=COLORS["gold"], fontweight=700,
           transform=ax.transAxes, ha="left", va="center")
    for j, v in enumerate(avg_vals):
        x = x0 + date_col_w + j * data_col_w
        color = COLORS["emerald"] if v >= 0 else COLORS["red"]
        ax.text(x + data_col_w / 2, y, f"{v:+.2f}%",
               fontsize=fs_sum, color=color, fontweight=600,
               transform=ax.transAxes, ha="center", va="center",
               fontfamily="monospace")
    y -= row_h * 1.1

    # ── % Positive row ───────────────────────────────────────────────
    ax.text(x0 + 0.005, y, "% Positive:",
           fontsize=fs_sum, color=COLORS["gold"], fontweight=700,
           transform=ax.transAxes, ha="left", va="center")
    for j, v in enumerate(pct_vals):
        x = x0 + date_col_w + j * data_col_w
        color = COLORS["emerald"] if v >= 70 else (COLORS["gold"] if v >= 50 else COLORS["red"])
        ax.text(x + data_col_w / 2, y, f"{v:.0f}%",
               fontsize=fs_sum, color=color, fontweight=600,
               transform=ax.transAxes, ha="center", va="center",
               fontfamily="monospace")


# ══════════════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════════════

def run_preset(preset_name: str, years: int = 10):
    """Run a predefined event study."""
    preset = PRESETS.get(preset_name)
    if not preset:
        logger.error("Unknown preset: %s. Available: %s", preset_name, list(PRESETS.keys()))
        return None

    logger.info("Running preset: %s (%d years)", preset_name, years)
    nifty_df = _fetch_nifty(years)
    if nifty_df.empty:
        logger.error("Could not fetch NIFTY data")
        return None

    prices = _ensure_series(nifty_df, "Close")

    # Detect events based on preset type
    if preset_name.startswith("vix"):
        threshold = float(preset_name.split("_")[1])
        vix = _fetch_vix(years)
        if vix.empty:
            logger.error("Could not fetch VIX data")
            return None
        events = detect_vix_spike(vix, threshold=threshold)
        indicator = vix
    elif preset_name.startswith("red"):
        n_days = int(preset_name.split("_")[1].replace("d", ""))
        events = detect_consecutive_red_days(nifty_df, n_days=n_days)
        c = _ensure_series(nifty_df, "Close")
        red = (c < c.shift(1)).astype(int)
        indicator = red.groupby((red != red.shift()).cumsum()).cumsum()
        threshold = n_days
    elif preset_name.startswith("dd"):
        pct = -float(preset_name.split("_")[1])
        events = detect_drawdown_breach(nifty_df, threshold_pct=pct)
        c = _ensure_series(nifty_df, "Close")
        h = _ensure_series(nifty_df, "High").rolling(50, min_periods=20).max()
        indicator = (c / h - 1) * 100
        threshold = pct
    else:
        logger.error("Unknown preset pattern: %s", preset_name)
        return None

    logger.info("Found %d events", len(events))
    if not events:
        logger.warning("No events found — try a lower threshold or more years")
        return None

    result = compute_forward_returns(prices, events)
    result.title = preset["title"]
    result.subtitle = f"{preset['subtitle']} · Past {years} years · {len(events)} occurrences"
    result.indicator_label = preset["indicator_label"]
    result.indicator_series = indicator
    result.threshold = threshold

    return result


def run_custom(event_type: str, threshold: float, years: int = 10):
    """Run a custom event study."""
    nifty_df = _fetch_nifty(years)
    if nifty_df.empty:
        logger.error("Could not fetch NIFTY data")
        return None

    prices = _ensure_series(nifty_df, "Close")

    if event_type == "vix_spike":
        vix = _fetch_vix(years)
        events = detect_vix_spike(vix, threshold=threshold)
        indicator = vix
        title = f"NIFTY after India VIX crosses above {threshold:.0f}"
        ind_label = "India VIX"
    elif event_type == "red_streak":
        n = int(threshold)
        events = detect_consecutive_red_days(nifty_df, n_days=n)
        c = _ensure_series(nifty_df, "Close")
        red = (c < c.shift(1)).astype(int)
        indicator = red.groupby((red != red.shift()).cumsum()).cumsum()
        title = f"NIFTY after {n} consecutive red days"
        ind_label = "Consecutive red days"
    elif event_type == "drawdown":
        pct = -abs(threshold)
        events = detect_drawdown_breach(nifty_df, threshold_pct=pct)
        c = _ensure_series(nifty_df, "Close")
        h = _ensure_series(nifty_df, "High").rolling(50, min_periods=20).max()
        indicator = (c / h - 1) * 100
        threshold = pct
        title = f"NIFTY after {abs(pct):.0f}% drawdown from 50-day high"
        ind_label = "Drawdown from 50d high (%)"
    elif event_type == "pcr":
        logger.error("PCR requires external data source — use preset or supply series")
        return None
    else:
        logger.error("Unknown event type: %s", event_type)
        return None

    if not events:
        logger.warning("No events found")
        return None

    result = compute_forward_returns(prices, events)
    result.title = title
    result.subtitle = f"Past {years} years · {len(events)} occurrences"
    result.indicator_label = ind_label
    result.indicator_series = indicator
    result.threshold = threshold

    return result


def main():
    parser = argparse.ArgumentParser(description="NIMBUS Event Study")
    parser.add_argument("--preset", choices=list(PRESETS.keys()),
                       help="Run a predefined event study")
    parser.add_argument("--event", choices=["vix_spike", "red_streak", "drawdown", "pcr"],
                       help="Custom event type")
    parser.add_argument("--threshold", type=float, help="Threshold for custom event")
    parser.add_argument("--years", type=int, default=10, help="Years of history (default: 10)")
    parser.add_argument("--no-export", action="store_true")
    args = parser.parse_args()

    if args.preset:
        results = [(args.preset, run_preset(args.preset, years=args.years))]
    elif args.event and args.threshold:
        slug = f"{args.event}_{args.threshold:.0f}"
        results = [(slug, run_custom(args.event, args.threshold, years=args.years))]
    else:
        # No args → run all presets
        logger.info("No preset specified — running all %d presets", len(PRESETS))
        results = []
        for name in PRESETS:
            r = run_preset(name, years=args.years)
            if r is not None:
                results.append((name, r))

    for slug, result in results:
        if result is None:
            continue
        fig = render_event_study(result)
        if fig is None:
            continue
        if not args.no_export:
            export_figure(fig, f"event_{slug}")
        plt.close(fig)
        logger.info("Done: %s (%d events)", slug, result.n_events)


if __name__ == "__main__":
    main()
