"""nimbus_v3.data.paths — central resolver for runtime data files.

All persistent data NIMBUS reads or writes lives under one root:

  - ``data/nifty500_industry_db.json`` — industry classification DB
  - ``data/cache/equity_price/`` — raw OHLCV parquet cache
  - ``data/cache/equity_enriched/{schema_hash}/`` — enriched cache
  - ``data/cache/options/`` — options chain cache
  - ``data/cache/vix/`` — VIX history cache
  - ``data/cache/universe/`` — symbol → sector map cache
  - ``data/cache/industry_states/`` — pre-batched industry analytics
  - ``data/cache/price/`` — generic price cache (oracle compat)

The root is resolved by :func:`data_root`:

  1. ``NIMBUS_DATA_DIR`` environment variable, if set
  2. ``./data`` relative to the current working directory (legacy default)

Setting ``NIMBUS_DATA_DIR`` to a path **outside** the project tree is
the recommended pattern — it lets you drop in a fresh clone of the
codebase without re-fetching multi-GB caches or re-running the
industry DB build.

Usage in code::

    from nimbus_v3.data.paths import data_root, cache_dir

    db_path = data_root() / "nifty500_industry_db.json"
    price_cache = ParquetCache(cache_dir("equity_price"))

The functions are pure — same env at call-time → same Path. No
caching beyond what os.environ provides; if you change the env var
mid-session the next call sees the new value (useful for tests).
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Final

logger = logging.getLogger(__name__)

#: Environment variable consulted first by :func:`data_root`.
ENV_VAR: Final[str] = "NIMBUS_DATA_DIR"

#: Fallback base directory when the env var is unset. Keeps every
#: existing caller working with no config change — they just resolve
#: to the same ``./data`` they always did.
_DEFAULT_DATA_DIR: Final[Path] = Path("./data")


def data_root() -> Path:
    """Return the base directory for all NIMBUS runtime data.

    Resolution order:
      1. ``$NIMBUS_DATA_DIR`` if set (and non-empty).
      2. ``./data`` (legacy default).

    The returned path is **not** guaranteed to exist — that's the
    caller's responsibility (either via ``mkdir(parents=True,
    exist_ok=True)`` for write paths, or graceful absence handling
    for reads like :mod:`industry_db`).
    """
    override = os.environ.get(ENV_VAR)
    if override:
        return Path(override).expanduser()
    return _DEFAULT_DATA_DIR


def cache_dir(*subdirs: str) -> Path:
    """Return ``data_root() / "cache" / subdirs...`` joined.

    Convenience wrapper for cache locations. Equivalent to
    ``data_root() / "cache" / *subdirs`` but reads cleaner at the
    call site::

        cache_dir("equity_price")           # → <root>/cache/equity_price
        cache_dir("equity_enriched", h)     # → <root>/cache/equity_enriched/<h>
    """
    return data_root().joinpath("cache", *subdirs)


def state_dir(*subdirs: str) -> Path:
    """Return ``data_root() / "state" / subdirs...`` joined.

    For durable app state that is NOT a cache (so it never gets swept
    by cache-clearing): the watchlist, UI preferences, etc.::

        state_dir()                  # → <root>/state
        state_dir("watchlist.json")  # → <root>/state/watchlist.json
    """
    return data_root().joinpath("state", *subdirs)
