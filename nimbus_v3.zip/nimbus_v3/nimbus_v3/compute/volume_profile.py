"""nimbus_v3.compute.volume_profile — reconstructed volume profile.

WHAT THIS IS — AND IS NOT
─────────────────────────
A true volume profile needs intraday/tick data: the actual volume traded at
each price. We have DAILY OHLCV — one volume number per bar, plus four
prices describing that bar's range. The volume-at-each-price information was
never captured, and no amount of arithmetic recovers it.

So this is a *reconstructed* profile: each day's volume is DISTRIBUTED across
that day's High–Low range according to an assumption. The output is an
ESTIMATE of where volume traded, not a measurement of it.

That assumption is the model. Here it is a **triangular kernel peaked at the
typical price (H+L+C)/3** — the standard choice. The reasoning: within a
session, trading clusters around the day's centre of gravity, and thins
toward the extremes (the high and low are, by definition, prices that were
touched and rejected). Weight falls linearly from the peak to zero at each
end of the range.

WHY THE ESTIMATE IS NONETHELESS USEFUL. The signal people want from a volume
profile is coarse — *which price regions did the market accept, and which did
it reject?* Aggregated over 60–120 sessions, that structure survives the
distribution assumption, because it is driven by which price REGIONS the bars
overlapped repeatedly, not by intraday microstructure. What is genuinely lost
is intraday shape: this cannot distinguish "gapped up, sold off heavily" from
"traded quietly all day at the midpoint."

WHERE IT IS WEAKEST. Wide-range, high-volume days — precisely the ones that
dominate the profile — are where the distribution assumption bites hardest.
On a day that opened at the low and closed at the high on huge volume, a
triangular kernel centred on HLC/3 is demonstrably wrong; the volume was not
symmetric about the centre. Treat single-node precision with suspicion; treat
broad structure as informative.

OUTPUTS
───────
* **POC** (Point of Control) — the price bin with the most estimated volume.
  The market's centre of gravity: prices tend to be drawn back to it.
* **Value Area** (VAH/VAL) — the contiguous band around the POC containing
  ``value_area_pct`` (conventionally 70%) of the estimated volume. Inside it,
  price is "accepted"; outside, it is comparatively unexplored.

Stateless; returns a frozen dataclass; no UI imports.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

#: Number of price bins the range is divided into. Higher = finer resolution,
#: but the underlying data does not support much precision — 50 is a
#: deliberate compromise that avoids implying more than daily bars can say.
DEFAULT_BINS: int = 50

#: Trailing sessions the profile is built from. ~60 trading days ≈ 3 months:
#: long enough for structure to form, recent enough to describe the CURRENT
#: regime rather than a stale one.
DEFAULT_LOOKBACK: int = 60

#: Share of estimated volume defining the value area. 70% is the convention
#: (roughly one standard deviation, if the profile were Gaussian — which it
#: is not, hence "roughly").
DEFAULT_VALUE_AREA_PCT: float = 0.70


@dataclass(frozen=True)
class VolumeProfile:
    """A reconstructed volume profile over a trailing window."""

    #: Bin centres (price), ascending.
    prices: tuple[float, ...]
    #: Estimated volume in each bin, aligned with ``prices``.
    volumes: tuple[float, ...]
    #: Point of Control — bin centre with the most estimated volume.
    poc: float
    #: Value-area high / low — the band around the POC holding
    #: ``value_area_pct`` of estimated volume.
    vah: float
    val: float
    #: Provenance, so the caller can label the estimate honestly.
    lookback: int
    n_bars: int
    value_area_pct: float

    @property
    def has_data(self) -> bool:
        return len(self.prices) > 0


def _triangular_weights(
    edges: np.ndarray,
    low: float,
    high: float,
    peak: float,
) -> np.ndarray:
    """Fraction of one bar's volume falling in each price bin.

    A triangular kernel over [low, high], peaked at ``peak`` (the typical
    price) and falling linearly to zero at both ends. Integrated over each
    bin, then normalised to sum to 1 so every bar contributes exactly its
    own volume — no more, no less.

    Degenerate bars (zero range: high == low, e.g. a limit-locked session)
    put all their volume in the single bin containing that price.
    """
    n_bins = len(edges) - 1
    w = np.zeros(n_bins, dtype=float)

    if not np.isfinite([low, high, peak]).all() or high <= low:
        # Zero-range bar: dump the whole volume in the bin holding `low`.
        idx = int(np.clip(np.searchsorted(edges, low, side="right") - 1,
                          0, n_bins - 1))
        w[idx] = 1.0
        return w

    peak = float(np.clip(peak, low, high))

    # Evaluate the triangle at each bin's midpoint, then zero out bins that
    # lie wholly outside the bar's range. Midpoint evaluation is a coarse
    # integration, but the bins are already coarser than the data's real
    # information content, so a finer quadrature would be false precision.
    mids = 0.5 * (edges[:-1] + edges[1:])

    with np.errstate(divide="ignore", invalid="ignore"):
        left = (mids - low) / (peak - low) if peak > low else np.ones_like(mids)
        right = (high - mids) / (high - peak) if high > peak \
            else np.ones_like(mids)
    tri = np.minimum(left, right)
    tri = np.nan_to_num(tri, nan=0.0, posinf=0.0, neginf=0.0)
    tri = np.clip(tri, 0.0, None)

    # Only bins overlapping [low, high] may receive volume.
    overlap = (edges[1:] > low) & (edges[:-1] < high)
    tri = np.where(overlap, tri, 0.0)

    total = tri.sum()
    if total <= 0:
        # The bar's range fell entirely inside one bin (or numeric edge
        # case): assign it all to the bin holding the typical price.
        idx = int(np.clip(np.searchsorted(edges, peak, side="right") - 1,
                          0, n_bins - 1))
        w[idx] = 1.0
        return w

    return tri / total


def _value_area(
    prices: np.ndarray,
    volumes: np.ndarray,
    poc_idx: int,
    target_pct: float,
) -> tuple[float, float]:
    """Grow a contiguous band outward from the POC until it holds
    ``target_pct`` of total volume.

    The standard construction: at each step, extend to whichever ADJACENT
    side (up or down) holds more volume, so the band always accretes the
    densest available price next. Contiguity is the point — a value area is
    a *region* of acceptance, not a scattered set of busy bins.
    """
    total = volumes.sum()
    if total <= 0:
        p = float(prices[poc_idx])
        return p, p

    target = total * target_pct
    lo = hi = poc_idx
    acc = float(volumes[poc_idx])

    while acc < target and (lo > 0 or hi < len(volumes) - 1):
        vol_below = float(volumes[lo - 1]) if lo > 0 else -1.0
        vol_above = float(volumes[hi + 1]) if hi < len(volumes) - 1 else -1.0
        if vol_above >= vol_below:
            hi += 1
            acc += max(vol_above, 0.0)
        else:
            lo -= 1
            acc += max(vol_below, 0.0)

    return float(prices[lo]), float(prices[hi])


def compute_volume_profile(
    df: pd.DataFrame | None,
    *,
    lookback: int = DEFAULT_LOOKBACK,
    bins: int = DEFAULT_BINS,
    value_area_pct: float = DEFAULT_VALUE_AREA_PCT,
) -> VolumeProfile | None:
    """Reconstruct a volume profile from daily OHLCV.

    Each bar's volume is spread across its High–Low range with a triangular
    kernel peaked at the typical price (H+L+C)/3, and the results summed.

    Args:
        df: daily OHLCV. Needs High, Low, Close, Volume.
        lookback: trailing sessions to profile.
        bins: price bins across the window's full range.
        value_area_pct: share of volume defining the value area (0..1).

    Returns:
        A :class:`VolumeProfile`, or ``None`` when there is too little data
        or no volume to distribute (a profile of nothing is not a profile —
        the caller should draw nothing rather than a misleading flat line).
    """
    if df is None or df.empty:
        return None
    need = {"High", "Low", "Close", "Volume"}
    if not need.issubset(df.columns):
        return None

    win = df.tail(max(2, int(lookback)))
    win = win.dropna(subset=["High", "Low", "Close", "Volume"])
    if win.shape[0] < 2:
        return None

    highs = win["High"].to_numpy(dtype=float)
    lows = win["Low"].to_numpy(dtype=float)
    closes = win["Close"].to_numpy(dtype=float)
    vols = win["Volume"].to_numpy(dtype=float)

    vols = np.where(np.isfinite(vols) & (vols > 0), vols, 0.0)
    if vols.sum() <= 0:
        return None

    lo_all = float(np.nanmin(lows))
    hi_all = float(np.nanmax(highs))
    if not np.isfinite([lo_all, hi_all]).all() or hi_all <= lo_all:
        return None

    n_bins = max(5, int(bins))
    edges = np.linspace(lo_all, hi_all, n_bins + 1)
    centres = 0.5 * (edges[:-1] + edges[1:])

    acc = np.zeros(n_bins, dtype=float)
    for h, lo, c, v in zip(highs, lows, closes, vols):
        if v <= 0 or not np.isfinite([h, lo, c]).all():
            continue
        typical = (h + lo + c) / 3.0          # the triangle's peak
        acc += v * _triangular_weights(edges, lo, h, typical)

    if acc.sum() <= 0:
        return None

    poc_idx = int(np.argmax(acc))
    val, vah = _value_area(centres, acc, poc_idx,
                           float(np.clip(value_area_pct, 0.05, 1.0)))

    return VolumeProfile(
        prices=tuple(float(x) for x in centres),
        volumes=tuple(float(x) for x in acc),
        poc=float(centres[poc_idx]),
        vah=float(vah),
        val=float(val),
        lookback=int(lookback),
        n_bars=int(win.shape[0]),
        value_area_pct=float(value_area_pct),
    )
