"""scripts/run_ui.py — DEPRECATED launcher, delegates to project-root main.py.

Kept for backwards compatibility with existing operator habits and any
documentation that still references this path. New invocations should
prefer ``python main.py`` from the project root, which is the canonical
entry point with the splash + staged-loading sequence.
"""
from __future__ import annotations

import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

if __name__ == "__main__":
    from main import main
    sys.exit(main())
