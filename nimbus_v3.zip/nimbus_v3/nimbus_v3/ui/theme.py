"""nimbus_v3.ui.theme — NIMBUS Emerald Slate v5 design system.

Ported from nimbus_oracle/ui/theme.py. Single source of truth for all
v3 UI: color tokens, badge style pairings (bg/text/border per state),
font choice, and a master QSS stylesheet applied at the MainWindow
level so every child widget inherits.

Every value is locked. Do not substitute, simplify, or "modernise"
without explicit roadmap approval — this is the brand.

Why centralised
───────────────
v3 originally had per-widget setStyleSheet calls, which led to the
"each tab looks like a different application" problem we hit in
Phase 9a. Apply ``QSS`` at MainWindow exactly once; per-widget
styling exists only as exceptional overrides for color-coded data
cells (z-scores, grade badges, etc.) using the helper functions
below.
"""
from __future__ import annotations


# ══════════════════════════════════════════════════════════════════════════════
# COLOUR TOKENS
# ══════════════════════════════════════════════════════════════════════════════

BG = "#080C10"           # main window background
SURFACE = "#0D1117"      # card / panel background
S2 = "#111827"           # raised surface (tile bg, inputs)
S3 = "#162032"           # hover / selected row
BORDER = "#1E2937"       # all dividers and borders

EM = "#10B981"           # emerald — primary accent, BULLISH, LIVE
EM_DK = "#059669"        # darker emerald for pressed states
RED = "#EF4444"          # bearish, AVOID, EXIT, error
GOLD = "#F59E0B"         # warning, HALF size, STALE
VIOLET = "#8B5CF6"       # max pain levels, secondary accent
WHITE = "#E2E8F0"        # primary text
MUTED = "#64748B"        # secondary text, labels, metadata
GREEN = "#22C55E"        # FULL size, positive delta
BLUE = "#60A5FA"         # WATCH/QUARTER tier, informational

UP = "#26A69A"           # bullish candles
DOWN = "#EF5350"         # bearish candles


# ══════════════════════════════════════════════════════════════════════════════
# BADGE STYLE PAIRINGS — (bg, text, border) per state name
# Used by ConvictionPanel grade/verdict/sizing tiles + macro stage badges.
# ══════════════════════════════════════════════════════════════════════════════

GRADE_STYLES = {
    "A+": {"bg": "#0A2018", "text": EM,    "border": EM},
    "A":  {"bg": "#0A1F15", "text": GREEN, "border": GREEN},
    "B+": {"bg": "#1F1A0A", "text": GOLD,  "border": GOLD},
    "B":  {"bg": "#1A180D", "text": GOLD,  "border": "#8B7A2E"},
    "C+": {"bg": "#1A1A1A", "text": MUTED, "border": MUTED},
    "C":  {"bg": "#1A1A1A", "text": MUTED, "border": BORDER},
    "D":  {"bg": "#1F0A0A", "text": RED,   "border": RED},
    "—":  {"bg": S2,        "text": MUTED, "border": BORDER},
}

SIZING_STYLES = {
    "FULL":  {"bg": "#0A1F15", "text": GREEN, "border": GREEN},
    "HALF":  {"bg": "#1F1A0A", "text": GOLD,  "border": GOLD},
    "QTR":   {"bg": "#0D1A2B", "text": BLUE,  "border": BLUE},
    "WATCH": {"bg": "#0D1A2B", "text": BLUE,  "border": BLUE},
    "SKIP":  {"bg": "#1F0A0A", "text": RED,   "border": RED},
    "AVOID": {"bg": "#1F0A0A", "text": RED,   "border": RED},
    "ZERO":  {"bg": "#1F0A0A", "text": RED,   "border": RED},
}

VERDICT_STYLES = {
    "TAKE":   {"bg": "#0A1F15", "text": GREEN, "border": GREEN},
    "WATCH":  {"bg": "#0D1A2B", "text": BLUE,  "border": BLUE},
    "WAIT":   {"bg": "#0D1A2B", "text": BLUE,  "border": BLUE},
    "RIDE":   {"bg": "#0A2018", "text": EM,    "border": EM},
    "HOLD":   {"bg": "#0A2018", "text": EM,    "border": EM},
    "SKIP":   {"bg": "#1F0A0A", "text": RED,   "border": RED},
    "AVOID":  {"bg": "#1F0A0A", "text": RED,   "border": RED},
}

# Macro flow panel stage badges
#: Stage badges in the Commodity (macro-flow) panel. Colours match
#: the Market Pulse phase palette so the same lifecycle concept
#: reads the same way across tabs:
#:   EARLY    (BLUE)  — fresh move, longer windows cool
#:   MID      (GREEN) — core of the move, sweet spot
#:   MATURE   (EM)    — 60d still warm, leading window cooling
#:   EXTENDED (GOLD)  — all windows hot; handle-with-care
#:   —        (MUTED) — no clear pattern
STAGE_STYLES = {
    "EARLY":    {"bg": "#0A1A2E", "text": BLUE,  "border": BLUE},
    "MID":      {"bg": "#0A1F14", "text": GREEN, "border": GREEN},
    "MATURE":   {"bg": "#0A2018", "text": EM,    "border": EM},
    "EXTENDED": {"bg": "#1F1A0A", "text": GOLD,  "border": GOLD},
    "—":        {"bg": S2,        "text": MUTED, "border": BORDER},
}

# Research-only strategy badges. Used when a strategy has
# ``production_weight = 0`` (OOS edge unconfirmed) — the signal fired
# but the conviction engine isn't pushing us to size on it. Visually
# distinct from WATCH (blue, "close but not sufficient") and HALF
# (gold-solid, "sized down"): violet/gold hybrid with a dashed-looking
# border accent to encode "emitted for tracking, not for action".
RESEARCH_STYLES = {
    "RESEARCH": {"bg": "#1A1530", "text": VIOLET, "border": VIOLET},
    "OOS":      {"bg": "#1A1530", "text": VIOLET, "border": VIOLET},
    "TRACK":    {"bg": "#1A1530", "text": VIOLET, "border": VIOLET},
}


# ══════════════════════════════════════════════════════════════════════════════
# DATA-CELL COLOUR HELPERS — single source of truth for all table models
# ══════════════════════════════════════════════════════════════════════════════

def grade_fg(grade: str) -> str:
    """Foreground colour for a grade column cell."""
    g = str(grade or "")
    if g == "S":           return EM
    if g.startswith("A"):  return GREEN
    if g.startswith("B"):  return GOLD
    if g == "D":           return RED
    return MUTED


def sizing_fg(sizing: str) -> str:
    """Foreground colour for a sizing column cell."""
    return {
        "FULL": GREEN, "HALF": GOLD, "QTR": BLUE,
        "WATCH": BLUE, "SKIP": MUTED, "AVOID": RED, "ZERO": RED,
    }.get(str(sizing or ""), MUTED)


def verdict_fg(verdict: str) -> str:
    """Foreground colour for a verdict column cell."""
    v = str(verdict or "").upper()
    if v == "TAKE":  return GREEN
    if v == "RIDE":  return EM
    if v == "HOLD":  return EM
    if v in {"WATCH", "WAIT"}: return BLUE
    if v in {"SKIP", "AVOID"}: return RED
    return MUTED


def z_score_fg(z: float) -> str:
    """Foreground colour for a z-score cell — used by the macro panel.

    Strong moves get bright EM/RED; mild moves use GREEN/GOLD; quiet
    cells are MUTED. NaN gets MUTED.
    """
    if z != z:    # NaN
        return MUTED
    az = abs(z)
    if az < 1.0:
        return MUTED
    if az < 2.0:
        return GREEN if z > 0 else GOLD
    return EM if z > 0 else RED


def pct_change_fg(p: float) -> str:
    """Foreground colour for a percent-change cell."""
    if p != p:
        return MUTED
    if abs(p) < 0.5:
        return MUTED
    return GREEN if p > 0 else RED


# ══════════════════════════════════════════════════════════════════════════════
# FONTS
# ══════════════════════════════════════════════════════════════════════════════

#: JetBrains Mono used everywhere — UI, display headers, mono-data cells.
#: Bundled with nimbus_oracle assets historically. If not installed system-
#: wide, Qt falls back to the platform default monospace, which is fine.
FONT_UI = "JetBrains Mono"
FONT_MONO = "JetBrains Mono"


# ══════════════════════════════════════════════════════════════════════════════
# QSS MASTER STYLESHEET — apply once at MainWindow.setStyleSheet(QSS)
# ══════════════════════════════════════════════════════════════════════════════

QSS = f"""
/* ── Base ──────────────────────────────────────────────────────────────── */
QWidget {{
    background-color: {BG};
    color: {WHITE};
    font-family: "{FONT_UI}";
    font-size: 13px;
}}
QMainWindow {{
    background-color: {BG};
}}

/* ── Tabs ──────────────────────────────────────────────────────────────── */
QTabWidget::pane {{
    border: 1px solid {BORDER};
    background: {SURFACE};
}}
QTabBar::tab {{
    background: {S2};
    color: {MUTED};
    padding: 10px 28px;
    border-bottom: 2px solid transparent;
    font-size: 11pt;
    min-width: 100px;
}}
QTabBar::tab:selected {{
    color: {WHITE};
    border-bottom: 2px solid {EM};
    background: {BG};
}}
QTabBar::tab:hover {{
    color: {WHITE};
    background: {S3};
}}

/* ── Buttons ───────────────────────────────────────────────────────────── */
QPushButton {{
    background: {S2};
    color: {WHITE};
    border: 1px solid {BORDER};
    border-radius: 5px;
    padding: 6px 14px;
    font-size: 11pt;
}}
QPushButton:hover {{
    background: {S3};
    border-color: {EM};
}}
QPushButton:pressed {{
    background: #0D2B20;
}}
QPushButton:checked {{
    background: #0D2B20;
    color: {EM};
    border-color: {EM};
}}
QPushButton:disabled {{
    color: {MUTED};
    border-color: {BORDER};
    background: {SURFACE};
}}
QPushButton#primary {{
    background: {EM};
    color: {BG};
    border: none;
    font-weight: bold;
}}
QPushButton#primary:hover {{
    background: {EM_DK};
}}

/* ── Inputs ────────────────────────────────────────────────────────────── */
QLineEdit, QComboBox, QDateEdit {{
    background: {S2};
    color: {WHITE};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 5px 8px;
    font-size: 11pt;
}}
QLineEdit:focus, QDateEdit:focus {{
    border-color: {EM};
}}

/* ── Scrollbar ─────────────────────────────────────────────────────────── */
QScrollBar:vertical {{
    background: {SURFACE};
    width: 8px;
    border: none;
}}
QScrollBar::handle:vertical {{
    background: {BORDER};
    border-radius: 4px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {EM};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    background: none;
}}
QScrollBar:horizontal {{
    background: {SURFACE};
    height: 8px;
    border: none;
}}
QScrollBar::handle:horizontal {{
    background: {BORDER};
    border-radius: 4px;
    min-width: 30px;
}}
QScrollBar::handle:horizontal:hover {{
    background: {EM};
}}

/* ── Tables ────────────────────────────────────────────────────────────── */
QTableView, QTableWidget {{
    background: {SURFACE};
    color: {WHITE};
    gridline-color: {BORDER};
    selection-background-color: {S3};
    selection-color: {WHITE};
    font-family: "{FONT_MONO}";
    font-size: 12px;
    border: none;
    alternate-background-color: {S2};
}}
QTableView::item, QTableWidget::item {{
    padding: 6px 8px;
    border-bottom: 1px solid {BORDER};
}}
QHeaderView::section {{
    background: #0A1520;
    color: {EM};
    font-size: 10pt;
    border: 1px solid {BORDER};
    padding: 6px 10px;
}}

/* ── Status bar ────────────────────────────────────────────────────────── */
QStatusBar {{
    background: #0A1520;
    color: {MUTED};
    border-top: 1px solid {BORDER};
    font-family: "{FONT_MONO}";
    font-size: 11px;
}}

/* ── Labels ────────────────────────────────────────────────────────────── */
QLabel {{
    background: transparent;
    color: {WHITE};
}}
QLabel#muted {{
    color: {MUTED};
}}
QLabel#section-header {{
    color: {MUTED};
    font-size: 9px;
    letter-spacing: 1.4px;
    text-transform: uppercase;
}}
QLabel#nimbus-logo {{
    font-family: "{FONT_MONO}";
    font-size: 18px;
    font-weight: 800;
    color: {EM};
    letter-spacing: 3px;
}}

/* ── Frames ────────────────────────────────────────────────────────────── */
QFrame#card {{
    background: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 8px;
}}
QFrame#kpi-tile {{
    background: {S2};
    border: 1px solid {BORDER};
    border-radius: 6px;
}}

/* ── Splitter ──────────────────────────────────────────────────────────── */
QSplitter::handle {{
    background: {BORDER};
}}
QSplitter::handle:horizontal {{
    width: 1px;
}}
QSplitter::handle:vertical {{
    height: 1px;
}}

/* ── Menus ─────────────────────────────────────────────────────────────── */
QMenuBar {{
    background: {BG};
    color: {WHITE};
    border-bottom: 1px solid {BORDER};
}}
QMenuBar::item:selected {{
    background: {S3};
    color: {EM};
}}
QMenu {{
    background: {SURFACE};
    color: {WHITE};
    border: 1px solid {BORDER};
}}
QMenu::item:selected {{
    background: {S3};
    color: {EM};
}}

/* ── Tooltips ──────────────────────────────────────────────────────────── */
QToolTip {{
    background: {S2};
    color: {WHITE};
    border: 1px solid {BORDER};
    padding: 4px 8px;
    font-size: 11px;
}}

/* ── Checkbox ──────────────────────────────────────────────────────────── */
QCheckBox {{
    color: {WHITE};
    spacing: 6px;
    font-size: 11pt;
}}
QCheckBox::indicator {{
    width: 14px;
    height: 14px;
    border: 1px solid {BORDER};
    border-radius: 3px;
    background: {S2};
}}
QCheckBox::indicator:checked {{
    background: {EM};
    border-color: {EM};
}}
"""


def badge_qss(style: dict[str, str], *, bold: bool = True) -> str:
    """Return inline QSS for a badge-style label.

    Used for grade/sizing/verdict/stage labels that need a fixed
    bg/text/border triple. ``style`` is a dict from one of the
    ``*_STYLES`` mappings above.
    """
    weight = "bold" if bold else "normal"
    return (
        f"background: {style['bg']}; "
        f"color: {style['text']}; "
        f"border: 1px solid {style['border']}; "
        f"border-radius: 3px; "
        f"padding: 3px 10px; "
        f"font-weight: {weight}; "
        f"font-family: '{FONT_MONO}'; "
    )
