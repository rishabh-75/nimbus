"""Tests for ``research.phase_p_win.cont_model``.

Covers:
  - Feature labelling (positive iff hold_bars ≥ symbol's horizon)
  - Walk-forward split semantics (per-symbol 70/30, chronological)
  - Logistic fit converges (sanity check on the optimizer)
  - Save/load metadata roundtrip
  - predict_with_metadata reproduces the train-time predictions
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.research.phase_p_win.cont_model import (
    CONT_MODEL_FEATURES,
    L2_LAMBDA,
    TRAIN_FRAC,
    build_cont_training_set,
    fit_logistic,
    load_model_metadata,
    predict_proba,
    predict_with_metadata,
    save_model_metadata,
    walk_forward_split,
    _auroc,
)
from nimbus_v3.research.phase_p_win.schema import ContModelMetadata, FireEvent


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════════════


def _cont_event(
    symbol: str, idx: int, hold: int | None,
    *,
    pct_b: float = 1.2, sma20: float = 0.3, sma50: float = 0.2,
    bbw_pctile: float = 0.5, vol: float = 1.0, atr: float = 1.0,
    bars_above: int = 30, body_count: int = 2,
    resolved: bool = True,
) -> FireEvent:
    """CONT FireEvent constructor with feature defaults — tests
    only need to override what they care about."""
    return FireEvent(
        symbol=symbol, phase="CONT",
        trigger_idx=idx, trigger_date="2024-01-01",
        hold_bars=hold, exit_idx=(idx + hold) if hold else None,
        return_pct=1.0 if hold else None,
        is_resolved=resolved,
        pct_b_at_trigger=pct_b,
        sma20_slope_pct=sma20, sma50_slope_pct=sma50,
        bb_width_pctile=bbw_pctile, vol_ratio_20=vol, atr_14_pct=atr,
        bars_since_sma20_above_sma50=bars_above,
        body_above_count_prior_5=body_count,
    )


# ══════════════════════════════════════════════════════════════════════════════
# build_cont_training_set
# ══════════════════════════════════════════════════════════════════════════════


class TestBuildTrainingSet:
    def test_label_is_one_when_hold_meets_horizon(self):
        """hold_bars ≥ horizon → y = 1."""
        events = [_cont_event("X", 0, 10)]
        df = build_cont_training_set(events, {"X": 5})
        assert len(df) == 1
        assert df["y"].iloc[0] == 1

    def test_label_is_zero_when_hold_below_horizon(self):
        events = [_cont_event("X", 0, 3)]
        df = build_cont_training_set(events, {"X": 5})
        assert df["y"].iloc[0] == 0

    def test_label_is_one_at_exact_threshold(self):
        """hold_bars == horizon counts as positive (≥ comparison)."""
        events = [_cont_event("X", 0, 5)]
        df = build_cont_training_set(events, {"X": 5})
        assert df["y"].iloc[0] == 1

    def test_unresolved_excluded(self):
        events = [_cont_event("X", 0, None, resolved=False)]
        df = build_cont_training_set(events, {"X": 5})
        assert len(df) == 0

    def test_symbol_without_horizon_excluded(self):
        """Symbols missing from the horizons dict are excluded —
        we have no N for them."""
        events = [_cont_event("Y", 0, 5)]
        df = build_cont_training_set(events, {"X": 5})    # no Y
        assert len(df) == 0

    def test_zero_horizon_excluded(self):
        """Horizon must be positive — zero or negative is meaningless."""
        events = [_cont_event("X", 0, 5)]
        df = build_cont_training_set(events, {"X": 0})
        assert len(df) == 0

    def test_non_cont_phases_excluded(self):
        """Defensive: even if INIT/RETEST events sneak in,
        they're filtered. Function takes 'cont_events' but we
        verify the phase filter for safety."""
        ev = _cont_event("X", 0, 10)
        # Force phase to INIT via construct (frozen dataclass; use replace)
        from dataclasses import replace
        init_ev = replace(ev, phase="INIT")
        df = build_cont_training_set([init_ev], {"X": 5})
        assert len(df) == 0

    def test_all_features_carried_through(self):
        events = [_cont_event("X", 0, 10, pct_b=1.5, vol=2.5)]
        df = build_cont_training_set(events, {"X": 5})
        for f in CONT_MODEL_FEATURES:
            assert f in df.columns
        assert df["pct_b_at_trigger"].iloc[0] == pytest.approx(1.5)
        assert df["vol_ratio_20"].iloc[0] == pytest.approx(2.5)


# ══════════════════════════════════════════════════════════════════════════════
# walk_forward_split
# ══════════════════════════════════════════════════════════════════════════════


class TestWalkForwardSplit:
    def test_per_symbol_chronological_70_30(self):
        """For 10 events, 7 to train, 3 to test, sorted by trigger_idx."""
        df = pd.DataFrame({
            "symbol": ["X"] * 10,
            "trigger_idx": list(range(10)),
            "y": [0] * 10,
            **{f: [0.0] * 10 for f in CONT_MODEL_FEATURES},
        })
        train, test = walk_forward_split(df, train_frac=0.7)
        assert len(train) == 7
        assert len(test) == 3
        # Train trigger_idx values are smaller than test (chronological)
        assert train["trigger_idx"].max() < test["trigger_idx"].min()

    def test_multiple_symbols_split_independently(self):
        """Each symbol gets its own 70/30 split."""
        df = pd.DataFrame({
            "symbol": ["A"] * 10 + ["B"] * 10,
            "trigger_idx": list(range(10)) + list(range(10)),
            "y": [0] * 20,
            **{f: [0.0] * 20 for f in CONT_MODEL_FEATURES},
        })
        train, test = walk_forward_split(df, train_frac=0.7)
        # Each symbol contributes 7 train + 3 test.
        assert (train["symbol"] == "A").sum() == 7
        assert (train["symbol"] == "B").sum() == 7
        assert (test["symbol"] == "A").sum() == 3
        assert (test["symbol"] == "B").sum() == 3

    def test_single_event_symbol_goes_to_train(self):
        """A symbol with 1 event has nothing to split — push to train."""
        df = pd.DataFrame({
            "symbol": ["A"],
            "trigger_idx": [0],
            "y": [0],
            **{f: [0.0] for f in CONT_MODEL_FEATURES},
        })
        train, test = walk_forward_split(df)
        assert len(train) == 1
        assert len(test) == 0

    def test_train_frac_constant_locked(self):
        assert TRAIN_FRAC == 0.70

    def test_input_unsorted_still_chronological_split(self):
        """Function sorts by trigger_idx internally so input order
        doesn't matter."""
        # Trigger 0..9 but in random order.
        triggers = [5, 0, 9, 3, 7, 2, 1, 8, 4, 6]
        df = pd.DataFrame({
            "symbol": ["X"] * 10,
            "trigger_idx": triggers,
            "y": [0] * 10,
            **{f: [0.0] * 10 for f in CONT_MODEL_FEATURES},
        })
        train, test = walk_forward_split(df, train_frac=0.7)
        # Train should still be the chronologically first 7 (idx 0..6)
        assert sorted(train["trigger_idx"].tolist()) == [0, 1, 2, 3, 4, 5, 6]
        assert sorted(test["trigger_idx"].tolist()) == [7, 8, 9]


# ══════════════════════════════════════════════════════════════════════════════
# fit_logistic
# ══════════════════════════════════════════════════════════════════════════════


class TestFitLogistic:
    def test_fits_separable_data(self):
        """Linearly separable: feature 0 perfectly predicts label.
        Optimizer should drive coefficient large enough to classify
        every point correctly."""
        rng = np.random.default_rng(0)
        n = 200
        x_pos = rng.normal(2.0, 0.3, n // 2)
        x_neg = rng.normal(-2.0, 0.3, n // 2)
        X = np.concatenate([x_pos, x_neg]).reshape(-1, 1)
        y = np.array([1] * (n // 2) + [0] * (n // 2))

        coef, intercept = fit_logistic(X, y, l2=0.001)
        p = predict_proba(X, coef, intercept)
        acc = ((p >= 0.5) == y.astype(bool)).mean()
        assert acc > 0.95

    def test_l2_keeps_coefficients_finite(self):
        """With strong L2, coefficients can't blow up even on
        perfectly separable data."""
        rng = np.random.default_rng(0)
        x_pos = rng.normal(5.0, 0.1, 50)
        x_neg = rng.normal(-5.0, 0.1, 50)
        X = np.concatenate([x_pos, x_neg]).reshape(-1, 1)
        y = np.array([1] * 50 + [0] * 50)
        coef, _ = fit_logistic(X, y, l2=10.0)
        assert np.all(np.isfinite(coef))
        # And bounded — L2=10 is strong, coef stays modest.
        assert np.abs(coef[0]) < 5.0

    def test_l2_constant_locked(self):
        assert L2_LAMBDA == 0.01


# ══════════════════════════════════════════════════════════════════════════════
# AUROC
# ══════════════════════════════════════════════════════════════════════════════


class TestAUROC:
    def test_perfect_separation_yields_one(self):
        y = np.array([0, 0, 0, 1, 1, 1])
        scores = np.array([0.1, 0.2, 0.3, 0.7, 0.8, 0.9])
        assert _auroc(y, scores) == pytest.approx(1.0)

    def test_perfect_inversion_yields_zero(self):
        y = np.array([0, 0, 0, 1, 1, 1])
        scores = np.array([0.9, 0.8, 0.7, 0.3, 0.2, 0.1])
        assert _auroc(y, scores) == pytest.approx(0.0)

    def test_random_scores_near_half(self):
        rng = np.random.default_rng(42)
        n = 1000
        y = rng.integers(0, 2, n)
        scores = rng.random(n)
        # With 1000 samples random scores should be near 0.5,
        # tolerance for sampling noise.
        assert 0.45 < _auroc(y, scores) < 0.55

    def test_single_class_yields_nan(self):
        """All-positive or all-negative → AUC undefined."""
        assert np.isnan(_auroc(np.array([1, 1, 1]), np.array([0.1, 0.5, 0.9])))
        assert np.isnan(_auroc(np.array([0, 0, 0]), np.array([0.1, 0.5, 0.9])))

    def test_ties_counted_half(self):
        """Tied scores between a positive and a negative count 0.5."""
        y = np.array([0, 1])
        scores = np.array([0.5, 0.5])
        assert _auroc(y, scores) == pytest.approx(0.5)


# ══════════════════════════════════════════════════════════════════════════════
# Metadata save/load roundtrip
# ══════════════════════════════════════════════════════════════════════════════


class TestMetadataRoundtrip:
    def test_save_load_preserves_all_fields(self, tmp_path: Path):
        meta = ContModelMetadata(
            label_kind="median_hold",
            horizon_value=0,
            feature_names=("a", "b", "c"),
            coefficients=(0.1, -0.2, 0.3),
            intercept=0.05,
            n_train=100, n_test=30,
            train_accuracy=0.75, test_accuracy=0.70,
            train_auroc=0.82, test_auroc=0.78,
            test_brier=0.18,
            train_pos_rate=0.55, test_pos_rate=0.52,
            feature_means=(1.0, 2.0, 3.0),
            feature_stds=(0.5, 1.0, 1.5),
            universe_p_win_init=0.5, universe_p_win_retest=0.55,
            universe_p_win_cont=0.42,
        )
        path = tmp_path / "model.json"
        save_model_metadata(meta, path)
        assert path.is_file()
        data = json.loads(path.read_text())
        assert data["intercept"] == 0.05
        assert data["label_kind"] == "median_hold"

        meta2 = load_model_metadata(path)
        assert meta2 == meta

    def test_save_load_preserves_fixed_horizon_kind(self, tmp_path: Path):
        """The label_kind round-trips correctly for fixed_horizon."""
        meta = ContModelMetadata(
            label_kind="fixed_horizon",
            horizon_value=5,
            feature_names=("a",), coefficients=(0.1,), intercept=0.0,
            n_train=10, n_test=5,
            train_accuracy=0.5, test_accuracy=0.5,
            train_auroc=0.5, test_auroc=0.5, test_brier=0.25,
            train_pos_rate=0.5, test_pos_rate=0.5,
            feature_means=(0.0,), feature_stds=(1.0,),
            universe_p_win_init=0.5, universe_p_win_retest=0.5,
            universe_p_win_cont=0.5,
        )
        path = tmp_path / "model.json"
        save_model_metadata(meta, path)
        meta2 = load_model_metadata(path)
        assert meta2.label_kind == "fixed_horizon"
        assert meta2.horizon_value == 5

    def test_predict_reproduces_train_time(self, tmp_path: Path):
        rng = np.random.default_rng(0)
        n = 200
        X = rng.normal(0, 1, (n, 3))
        logits_true = X[:, 0] * 1.5 - X[:, 1] * 0.8 + 0.3
        y = (logits_true + rng.normal(0, 0.5, n) > 0).astype(int)
        means = X.mean(axis=0)
        stds = X.std(axis=0)
        Xs = (X - means) / stds
        coef, intercept = fit_logistic(Xs, y)

        meta = ContModelMetadata(
            label_kind="median_hold",
            horizon_value=0,
            feature_names=("f1", "f2", "f3"),
            coefficients=tuple(float(c) for c in coef),
            intercept=intercept,
            n_train=n, n_test=0,
            train_accuracy=0.0, test_accuracy=float("nan"),
            train_auroc=0.0, test_auroc=float("nan"),
            test_brier=float("nan"),
            train_pos_rate=float(y.mean()), test_pos_rate=float("nan"),
            feature_means=tuple(float(m) for m in means),
            feature_stds=tuple(float(s) for s in stds),
            universe_p_win_init=0.5, universe_p_win_retest=0.5,
            universe_p_win_cont=0.5,
        )

        i = 42
        feature_row = {"f1": X[i, 0], "f2": X[i, 1], "f3": X[i, 2]}
        via_metadata = predict_with_metadata(feature_row, meta)
        x_std = (X[i] - means) / stds
        via_proba = float(predict_proba(x_std.reshape(1, -1), coef, intercept)[0])
        assert via_metadata == pytest.approx(via_proba, abs=1e-9)


# ══════════════════════════════════════════════════════════════════════════════
# Feature contract
# ══════════════════════════════════════════════════════════════════════════════


class TestFeatureContract:
    def test_features_match_extract_emit(self):
        """The model's feature names must be a subset of what
        FireEvent emits — otherwise we can't predict on real
        events. (Currently they're identical; future model
        revisions might use a subset.)"""
        from nimbus_v3.research.phase_p_win.schema import FireEvent
        feat_names = {f for f in CONT_MODEL_FEATURES}
        # Inspect FireEvent fields via dataclasses.fields.
        from dataclasses import fields
        event_fields = {f.name for f in fields(FireEvent)}
        missing = feat_names - event_fields
        assert not missing, f"model features missing from FireEvent: {missing}"

    def test_feature_names_locked(self):
        """The exact set is contractual — coefficients in saved
        models align by position. Adding/removing/reordering
        features is a breaking change."""
        assert CONT_MODEL_FEATURES == (
            "pct_b_at_trigger",
            "sma20_slope_pct",
            "sma50_slope_pct",
            "bb_width_pctile",
            "vol_ratio_20",
            "atr_14_pct",
            "bars_since_sma20_above_sma50",
            "body_above_count_prior_5",
        )
