"""Composite conviction score for an active ride bar.

Components, all normalised to 0-100:

  - **FRESHNESS** (30%) — distance from the base. 100 when T-1 is
    the only body-above bar in last 5; decays with prior count.
  - **VOLUME** (25%) — vol/vol_sma_20 ratio, capped at 3.0×.
  - **BBW_QUALITY** (20%) — was base tight AND is BBW expanding now.
  - **MOMENTUM** (15%) — SMA20 slope as % per bar.
  - **BODY_CLEANNESS** (10%) — body/range ratio above the 0.35 floor.

The weighted sum is then **multiplicatively docked** by two
tradeability discount factors:

  - **EXTENSION** — penalises bars where %B is approaching the
    band-walk envelope. Linear decay from 1.0 at %B 1.4 down to
    a 0.55 floor at %B 1.7+. Below %B 1.4 the factor is 1.0.
  - **LIQUIDITY** — penalises low-ADTV symbols (small/micro caps
    where slippage / fill risk is non-trivial). Tiered curve from
    1.0 at ADTV ≥ ₹1B down to a 0.6 floor at ADTV ≤ ₹50M.

Why discounts rather than additional weighted components?
─────────────────────────────────────────────────────────
The five weighted components measure **conviction** (how strong
is this signal). Extension and liquidity measure **tradeability**
(can the operator act on it). Multiplying makes the meaning
explicit: a high-conviction setup that is also extended +
illiquid is *still a real signal*, but its expected actionability
is much lower; the score should reflect both. Adding them as
additional weighted negatives would conflate "weak signal" with
"strong signal you can't trade", which the operator needs to be
able to tell apart.

Both penalties have a floor (not zero) so genuinely interesting
setups remain visible at low rank rather than being filtered out.

This is a **conviction-and-tradeability score for a fired bar**,
not a forward-return prediction. NaN where fire is False —
composites for non-signals don't make sense.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .constants import (
    BBW_FLOOR_PERCENTILE,
    BBW_FLOOR_WINDOW,
    BBW_LOOKBACK,
    BODY_STRENGTH_MIN,
    CROSS_LOOKBACK,
    SCORE_EXTENSION_PCTB_MAX,
    SCORE_EXTENSION_PCTB_MIN,
    SCORE_EXTENSION_PENALTY_FLOOR,
    SCORE_LIQUIDITY_ADTV_FULL,
    SCORE_LIQUIDITY_ADTV_MID,
    SCORE_LIQUIDITY_ADTV_SMALL,
    SCORE_LIQUIDITY_PENALTY_FLOOR,
    SCORE_WEIGHT_BBW,
    SCORE_WEIGHT_BODY,
    SCORE_WEIGHT_FRESHNESS,
    SCORE_WEIGHT_MOMENTUM,
    SCORE_WEIGHT_VOLUME,
    VOL_SURGE_WINDOW,
)
from .criteria import body_above_band, pct_b_close, sma_slope


def _freshness_score(df: pd.DataFrame) -> pd.Series:
    """100 - 25 × prior_above_count (clipped 0-100).

    100 when T-1 was the FIRST body-above (ideal init).
    75 when 1 prior, 50 with 2, etc.
    """
    body = body_above_band(df)
    prior = body.shift(2).rolling(CROSS_LOOKBACK, min_periods=1).sum()
    raw = 100.0 - 25.0 * prior
    return raw.clip(lower=0.0, upper=100.0).fillna(0.0)


def _volume_score(df: pd.DataFrame) -> pd.Series:
    """vol/vol_sma scaled to 0-100, capped at 3.0× (=100)."""
    vol_sma = df["Volume"].rolling(VOL_SURGE_WINDOW, min_periods=10).mean()
    ratio = df["Volume"] / vol_sma.replace(0.0, np.nan)
    # 1.0× → 33, 2.0× → 67, 3.0× → 100
    score = ratio * (100.0 / 3.0)
    return score.clip(lower=0.0, upper=100.0).fillna(0.0)


def _bbw_quality_score(df: pd.DataFrame) -> pd.Series:
    """Two halves:

    Half A (50): how tight was the base — bbw_floor / bbw[T-2].
    Higher when base was at/below the floor.

    Half B (50): expansion magnitude — (bbw[T] - bbw[T-2]) / bbw[T].
    Capped at 10% (≥10% expansion → full 50 points).
    """
    bbw = df["bbw_20_1s"]
    bbw_then = bbw.shift(BBW_LOOKBACK)
    floor = bbw.rolling(BBW_FLOOR_WINDOW, min_periods=BBW_FLOOR_WINDOW // 2).quantile(
        BBW_FLOOR_PERCENTILE
    )

    # Half A: base tightness — floor/bbw_then, capped at 1.0
    tight_score = (floor / bbw_then.replace(0.0, np.nan)).clip(lower=0.0, upper=1.0) * 50.0

    # Half B: expansion rate — (bbw_now - bbw_then) / bbw_now
    expansion = ((bbw - bbw_then) / bbw.replace(0.0, np.nan))
    expand_score = (expansion / 0.10).clip(lower=0.0, upper=1.0) * 50.0

    return (tight_score + expand_score).fillna(0.0)


def _momentum_score(df: pd.DataFrame) -> pd.Series:
    """SMA slope as % per bar × 1000, capped 0-100.

    0.1% per bar (a week of 0.5%) → 100.
    """
    slope = sma_slope(df) / df["sma_20"].replace(0.0, np.nan)
    score = slope * 100000.0  # slope is fractional → ×100 for %, ×1000 for scaling
    return score.clip(lower=0.0, upper=100.0).fillna(0.0)


def _body_score(df: pd.DataFrame) -> pd.Series:
    """Body strength normalised: (ratio - 0.35) / 0.65 × 100.

    BODY_STRENGTH_MIN=0.35 → 0 points.
    Perfect 1.0 body → 100 points.
    """
    rng = (df["High"] - df["Low"]).replace(0.0, np.nan)
    body = (df["Close"] - df["Open"]).abs()
    ratio = body / rng
    score = (ratio - BODY_STRENGTH_MIN) / (1.0 - BODY_STRENGTH_MIN) * 100.0
    return score.clip(lower=0.0, upper=100.0).fillna(0.0)


def _extension_penalty(df: pd.DataFrame) -> pd.Series:
    """Multiplicative score discount for over-extended %B bars.

    Curve:
        %B ≤ ``SCORE_EXTENSION_PCTB_MIN`` (1.4) → 1.0 (no penalty)
        SCORE_EXTENSION_PCTB_MIN < %B < SCORE_EXTENSION_PCTB_MAX
            → linear decay from 1.0 to ``SCORE_EXTENSION_PENALTY_FLOOR``
        %B ≥ ``SCORE_EXTENSION_PCTB_MAX`` (1.7) → floor (0.55)

    Why: a fired CONT bar at %B 1.65 is technically still inside
    the ``CONT_DETACHED_PCTB_MAX`` ceiling so the strategy fires,
    but the entry is late by any reasonable definition — the move
    is well past its base. Discounting the score lets the
    operator see that even with strong conviction components, the
    *tradeable* score is lower than a fresh bar at %B 1.10. A
    floor (rather than zero) keeps the bar visible at low rank.

    NaN bars (warm-up period) get penalty 1.0 — they'll be masked
    out at the end of ``compute_composite_score`` anyway.
    """
    pbc = pct_b_close(df)
    span = SCORE_EXTENSION_PCTB_MAX - SCORE_EXTENSION_PCTB_MIN
    # Fraction of the [MIN, MAX] window that has been traversed.
    # Clipped 0..1 so values below MIN give 0 (no penalty) and
    # values above MAX give 1 (full penalty).
    frac = ((pbc - SCORE_EXTENSION_PCTB_MIN) / span).clip(lower=0.0, upper=1.0)
    # Penalty 1.0 at frac=0, FLOOR at frac=1.
    penalty = 1.0 - frac * (1.0 - SCORE_EXTENSION_PENALTY_FLOOR)
    return penalty.fillna(1.0)


def _liquidity_penalty(df: pd.DataFrame) -> pd.Series:
    """Multiplicative score discount for low-ADTV symbols.

    Tiered linear curve over ADTV (₹) — 20-bar mean of
    ``Close × Volume``:

        ADTV ≥ SCORE_LIQUIDITY_ADTV_FULL  (₹1B)  → 1.0 (no penalty)
        SCORE_LIQUIDITY_ADTV_MID ≤ ADTV < FULL   → linear 0.85 → 1.0
        SCORE_LIQUIDITY_ADTV_SMALL ≤ ADTV < MID  → linear 0.6  → 0.85
        ADTV < SCORE_LIQUIDITY_ADTV_SMALL (₹50M) → 0.6 (floor)

    Why: a high-conviction setup on a ₹30M-ADTV micro-cap is
    *technically* tradeable but the cost-to-fill (slippage,
    spread, market impact) usually erodes much of the edge. The
    score should rank this below cleaner mid-cap setups even when
    the per-bar conviction signal is strong.

    A floor of 0.6 (not zero) keeps small-caps visible — operators
    can still see the signal, just downranked.
    """
    if "Volume" not in df.columns:
        # Defensive — every panel symbol has Volume, but indices
        # don't and could conceivably be classified one day. No
        # liquidity to score → no penalty.
        return pd.Series(1.0, index=df.index)

    adtv = (df["Close"] * df["Volume"]).rolling(20, min_periods=5).mean()

    # Tiered piecewise-linear curve. Use np.where to compose the
    # three regions cleanly.
    full   = SCORE_LIQUIDITY_ADTV_FULL
    mid    = SCORE_LIQUIDITY_ADTV_MID
    small  = SCORE_LIQUIDITY_ADTV_SMALL
    floor_ = SCORE_LIQUIDITY_PENALTY_FLOOR

    #   ADTV ≥ full  → 1.0
    #   mid ≤ ADTV < full   → 0.85 + 0.15 × (ADTV − mid) / (full − mid)
    #   small ≤ ADTV < mid  → floor + (0.85 − floor) × (ADTV − small) / (mid − small)
    #   ADTV < small → floor
    a = adtv.fillna(0.0)
    upper_band  = 0.85 + 0.15 * (a - mid)   / max(full - mid, 1e-9)
    middle_band = floor_ + (0.85 - floor_) * (a - small) / max(mid - small, 1e-9)

    penalty = np.where(
        a >= full, 1.0,
        np.where(
            a >= mid, upper_band,
            np.where(
                a >= small, middle_band,
                floor_,
            ),
        ),
    )
    return pd.Series(penalty, index=df.index).fillna(1.0)


def compute_composite_score(df: pd.DataFrame, fire: pd.Series) -> pd.Series:
    """Per-bar composite score (0-100). NaN where fire is False.

    Args:
        df: Enriched OHLC dataframe.
        fire: Boolean series — True where any phase is active.

    Returns:
        Float series, NaN where ``fire`` is False.

    The 5 weighted conviction components are summed, then
    multiplicatively discounted by the extension and liquidity
    penalties. See module docstring for the rationale on
    multiplicative-vs-weighted handling of tradeability factors.
    """
    freshness = _freshness_score(df)
    volume = _volume_score(df)
    bbw_q = _bbw_quality_score(df)
    momentum = _momentum_score(df)
    body = _body_score(df)

    conviction = (
        SCORE_WEIGHT_FRESHNESS * freshness
        + SCORE_WEIGHT_VOLUME * volume
        + SCORE_WEIGHT_BBW * bbw_q
        + SCORE_WEIGHT_MOMENTUM * momentum
        + SCORE_WEIGHT_BODY * body
    )

    # Tradeability discounts — multiplicative.
    extension = _extension_penalty(df)
    liquidity = _liquidity_penalty(df)
    composite = conviction * extension * liquidity

    # Mask to fire bars only — composite only meaningful when phase != NONE
    return composite.where(fire, np.nan)
