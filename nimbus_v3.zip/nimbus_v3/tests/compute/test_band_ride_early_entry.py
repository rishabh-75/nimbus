"""Unit tests for compute/band_ride.py and compute/early_entry.py."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.band_ride import (
    body_above_band,
    body_above_streak,
    last_body_above,
)
from nimbus_v3.compute.early_entry import (
    EarlyEntryFeatures,
    extract_features,
    score_cohort,
    PARTICIPATION_SIZE_FLOOR,
)


def _frame(rows: list[tuple[float, float, float]]) -> pd.DataFrame:
    """Build a minimal frame from (open, close, upper_band) rows."""
    idx = pd.date_range("2025-01-01", periods=len(rows), freq="D")
    return pd.DataFrame(
        {
            "Open": [r[0] for r in rows],
            "Close": [r[1] for r in rows],
            "bb_20_1s_upper": [r[2] for r in rows],
            "High": [max(r[0], r[1]) for r in rows],
            "Low": [min(r[0], r[1]) for r in rows],
            "Volume": [1000] * len(rows),
            "bbw_20_1s": [5.0] * len(rows),
        },
        index=idx,
    )


# ── band_ride ────────────────────────────────────────────────────────────────

def test_body_above_band_requires_both_open_and_close():
    df = _frame([(10, 12, 11)])    # open below band, close above
    assert bool(body_above_band(df).iloc[-1]) is False
    df2 = _frame([(11.5, 12, 11)])    # both above
    assert bool(body_above_band(df2).iloc[-1]) is True


def test_last_body_above_empty_and_missing():
    assert last_body_above(pd.DataFrame()) is False
    assert last_body_above(None) is False


def test_body_above_streak_trailing_run():
    # ...below, above, above, above
    df = _frame([(9, 9, 11), (12, 13, 11), (12, 13, 11), (12, 13, 11)])
    assert body_above_streak(df) == 3


def test_body_above_streak_zero_when_last_below():
    df = _frame([(12, 13, 11), (9, 9, 11)])
    assert body_above_streak(df) == 0


# ── early_entry features ─────────────────────────────────────────────────────

def test_extract_features_recent_return():
    rows = [(100, 100, 90)] * 6
    df = _frame(rows)
    df.loc[df.index[-1], "Close"] = 110.0    # +10% vs 6 bars back
    df.loc[df.index[-6], "Close"] = 100.0
    feats = extract_features("X", df, lookback=5)
    assert feats.recent_return == pytest.approx(10.0, abs=0.01)


def test_extract_features_failsoft_on_short_frame():
    df = _frame([(100, 100, 90)])
    feats = extract_features("X", df)
    assert feats.streak >= 0
    assert np.isnan(feats.recent_return)


# ── early_entry scoring ──────────────────────────────────────────────────────

def test_score_cohort_freshness_orders_streak():
    feats = [
        EarlyEntryFeatures("FRESH", 1, 5.0, 1e9, 5.0),
        EarlyEntryFeatures("OLD", 6, 5.0, 1e9, 5.0),
    ]
    sc = score_cohort(feats)
    assert sc["FRESH"] > sc["OLD"]


def test_score_cohort_extension_penalty():
    feats = [
        EarlyEntryFeatures("CALM", 2, 3.0, 1e9, 5.0),
        EarlyEntryFeatures("RUN", 2, 25.0, 1e9, 5.0),
    ]
    sc = score_cohort(feats)
    assert sc["CALM"] > sc["RUN"]


def test_score_cohort_liquidity_floor():
    feats = [
        EarlyEntryFeatures("LIQUID", 2, 5.0, 5e9, 5.0),
        EarlyEntryFeatures("THIN", 2, 5.0, 1e7, 5.0),
    ]
    sc = score_cohort(feats)
    assert sc["LIQUID"] > sc["THIN"]


def test_participation_only_in_all_cohort():
    feats = [
        EarlyEntryFeatures("A", 2, 5.0, 1e9, 5.0, industry="Broad"),
        EarlyEntryFeatures("B", 2, 5.0, 1e9, 5.0, industry="Lone"),
    ]
    # No industry_riding → participation dormant → tie.
    sc_none = score_cohort(feats)
    assert sc_none["A"] == pytest.approx(sc_none["B"], abs=0.01)
    # With riding → broad sector wins.
    sc_all = score_cohort(
        feats, industry_riding={"Broad": (20, 25), "Lone": (1, 10)}
    )
    assert sc_all["A"] > sc_all["B"]


def test_participation_size_floor_damps_micro_industry():
    feats = [
        EarlyEntryFeatures("MICRO", 2, 5.0, 1e9, 5.0, industry="Micro"),
        EarlyEntryFeatures("BIG", 2, 5.0, 1e9, 5.0, industry="Big"),
    ]
    # Micro 2/2 = 100% raw, but below floor → damped below Big 20/25=80%.
    sc = score_cohort(
        feats, industry_riding={"Micro": (2, 2), "Big": (20, 25)}
    )
    assert sc["BIG"] > sc["MICRO"]
    assert PARTICIPATION_SIZE_FLOOR >= 2


def test_score_cohort_empty():
    assert score_cohort([]) == {}


def test_non_riders_are_not_scored():
    """A symbol not above the band (streak 0) has no early-entry and must
    be absent from the result — regression guard for the bug where
    non-riders scored highest via 1/streak clamping."""
    feats = [
        EarlyEntryFeatures("RIDER", 2, 5.0, 1e9, 5.0),
        EarlyEntryFeatures("FLAT", 0, 5.0, 1e9, 5.0),
    ]
    sc = score_cohort(feats)
    assert "RIDER" in sc
    assert "FLAT" not in sc


def test_all_non_riders_empty():
    feats = [
        EarlyEntryFeatures("A", 0, 5.0, 1e9, 5.0),
        EarlyEntryFeatures("B", 0, 3.0, 1e9, 5.0),
    ]
    assert score_cohort(feats) == {}


def test_freshest_rider_outranks_extended():
    """Streak-1 rider should beat a streak-8 rider, all else equal."""
    feats = [
        EarlyEntryFeatures("FRESH", 1, 5.0, 1e9, 5.0),
        EarlyEntryFeatures("EXTENDED", 8, 5.0, 1e9, 5.0),
    ]
    sc = score_cohort(feats)
    assert sc["FRESH"] > sc["EXTENDED"]
