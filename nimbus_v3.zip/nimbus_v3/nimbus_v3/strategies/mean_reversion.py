"""nimbus_v3.strategies.mean_reversion — equity mean reversion setup.

Fires when a recently-fallen name is in a tight consolidation during an
elevated-volatility regime — the classic "oversold bounce" premise.

Entry gates (v2-validated thresholds, refined in Phase 7)
─────────────────────────────────────────────────────────

- ``state.roc_5 < -3.0``              — short-term selloff (≥ 3% in 5 bars)
- ``state.bbw_20_2s_pctl < 30``       — Bollinger width in bottom 30% of 1-year history
- ``contexts.market.vix_high_streak >= 6``  — VIX has been HIGH for 6+ days
- ``state.data_sufficient``            — enough bars to trust the indicators
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class MeanReversionParams:
    roc_5_max: float = -3.0
    #: Loosened from 30.0 → 40.0 per the strategy-validation study
    #: (scripts/run_strategy_validation.py): the looser threshold
    #: produces 1,519 trades vs 999 at +2.01% mean 10d return vs +1.90%.
    #: Strict-Pareto improvement on the full panel.
    bbw_pctl_max: float = 40.0
    vix_streak_min: int = 6


class MeanReversionStrategy:
    """Mean-reversion equity setup. Rejects ETFs via :meth:`accepts`.

    Note: ``data_sufficient`` is *not* a gate here. The scan engine is
    contractually required to only invoke ``evaluate`` on warmed-up
    states. The validation harness confirmed this gate is a no-op on
    real warmed panels.
    """

    name: str = "MeanReversion"
    setup_type: SetupType = SetupType.MEAN_REVERSION
    priority: int = 50
    production_weight: float = 1.0   # only OOS-confirmed signal in v3.0

    def __init__(self, params: MeanReversionParams = MeanReversionParams()) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        if state.roc_5 >= self._p.roc_5_max:
            return None
        if state.bbw_20_2s_pctl >= self._p.bbw_pctl_max:
            return None
        if contexts.market.vix_high_streak < self._p.vix_streak_min:
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "roc_5": state.roc_5,
                "bbw_pctl": state.bbw_20_2s_pctl,
                "vix_streak": contexts.market.vix_high_streak,
            },
        )
