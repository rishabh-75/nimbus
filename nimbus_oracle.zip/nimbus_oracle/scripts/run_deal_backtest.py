"""
scripts/run_deal_backtest.py — Retrospective deal level validation.

Cross-references walk-forward OOS trades with institutional deal levels
to test whether proximity to a deal level improves trade outcomes.

THIS IS NOT A PARAMETER SWEEP. The deal weights are structural constants.
This script tests the HYPOTHESIS that institutional price memory improves
mean-reversion outcomes — it does not optimize parameters.

Requirements:
  - wf_oos_trades.csv (from run_walkforward.py — 1,733 OOS trades)
  - Network access to NSE (fetches deal data per symbol)
  - ~15-30 minutes to run (rate-limited NSE calls)

Usage:
    python3 scripts/run_deal_backtest.py
    python3 scripts/run_deal_backtest.py --trades path/to/wf_oos_trades.csv
    python3 scripts/run_deal_backtest.py --cache deals_cache.json  # resume from cache

Output:
  - Console report with statistical tests
  - deals_backtest_report.txt — full results
  - deals_cache.json — cached deal data (reusable)

Tests implemented:
  1. PROXIMITY EDGE — do entries near deal levels outperform?
  2. AGE DECAY — do recent deals matter more than old ones?
  3. TRAP CONFIRMATION — do SHORT disclosures near entry predict failure?
  4. SCORE DELTA CORRELATION — does the continuous score predict returns?
  5. DIRECTION BIAS — do buy-side levels outperform sell-side?
"""
import argparse
import datetime
import json
import logging
import os
import sys
import time

import numpy as np
import pandas as pd

# Add parent dir to path
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
sys.path.insert(0, _PROJECT_ROOT)
os.chdir(_PROJECT_ROOT)  # ensure relative paths resolve from project root
from scripts.output import enable_export; enable_export()

from modules.deal_levels import (
    analyze_deal_levels, DealLevelResult, PROXIMITY_PCT,
    TRAP_PROXIMITY_PCT, TRAP_MAX_AGE_DAYS, TRAP_MIN_VALUE_CR,
    MAX_SCORE_DELTA, AGE_HALF_LIFE_DAYS,
)
from modules.nse_client import NSEClient

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────

PROXIMITY_BANDS = [0.5, 1.0, 2.0, 3.0, 5.0, 10.0]  # % from spot
AGE_BUCKETS = [(0, 30), (31, 90), (91, 180), (181, 365)]
MIN_N_FOR_SIGNIFICANCE = 30  # minimum trades per bucket for t-test
DELAY_BETWEEN_SYMBOLS = 0.5  # seconds between NSE calls


# ── Deal data fetching with cache ─────────────────────────────────────────────

def load_or_fetch_deals(
    symbols: list[str],
    cache_path: str = "deals_cache.json",
    lookback_days: int = 365,
) -> dict[str, dict]:
    """
    Fetch ALL bulk/block/short deals from NSE via CSV endpoint.

    Uses csv=true parameter which returns ALL rows (no display cap).
    3 calls total for the full year — one per deal type.
    Results cached to disk; subsequent runs skip fetch entirely.
    """
    cache = {}
    if os.path.exists(cache_path):
        try:
            with open(cache_path) as f:
                cache = json.load(f)
        except Exception:
            cache = {}

    # Skip if already fetched (check for _meta.complete flag)
    if cache.get("_meta", {}).get("complete"):
        logger.info("Using cached deal data (%d deals from %s)",
                    len(cache.get("_meta", {}).get("all_deals", [])),
                    cache.get("_meta", {}).get("fetch_date", "?"))
    else:
        logger.info("Fetching deal data from NSE (3 CSV calls for %d days)...", lookback_days)
        client = NSEClient(timeout=20, retry=3)
        today = datetime.date.today()
        from_date = (today - datetime.timedelta(days=lookback_days)).strftime("%d-%m-%Y")
        to_date = today.strftime("%d-%m-%Y")

        all_raw_deals = []
        for deal_type in ("bulk_deals", "block_deals", "short_selling"):
            try:
                rows = client.fetch_deals_csv(deal_type, from_date, to_date)
                for row in rows:
                    parsed = _parse_raw_deal(row, deal_type)
                    if parsed:
                        all_raw_deals.append(parsed)
                logger.info("  %s: %d CSV rows", deal_type, len(rows))
            except Exception as exc:
                logger.warning("  %s failed: %s", deal_type, exc)
            time.sleep(1.0)

        logger.info("Total raw deals fetched: %d", len(all_raw_deals))

        # Group by symbol and build cache
        deals_by_sym = {}
        for d in all_raw_deals:
            sym = d.get("symbol", "").strip().upper()
            if sym:
                deals_by_sym.setdefault(sym, []).append(d)

        symbols_needed = set(s.strip().upper() for s in symbols)
        for sym in symbols_needed:
            cache[sym] = {
                "raw_deal_count": len(deals_by_sym.get(sym, [])),
                "deals": deals_by_sym.get(sym, []),
                "fetch_date": today.isoformat(),
            }

        cache["_meta"] = {
            "complete": True,
            "fetch_date": today.isoformat(),
            "all_deals": all_raw_deals,
            "total_deals": len(all_raw_deals),
            "symbols_with_deals": len(deals_by_sym),
        }

        with open(cache_path, "w") as f:
            json.dump(cache, f)

        symbols_with_data = sum(1 for s in symbols_needed
                                if cache.get(s, {}).get("raw_deal_count", 0) > 0)
        logger.info("Cache saved: %d symbols (%d with deals), %d total deals",
                    len(symbols_needed), symbols_with_data, len(all_raw_deals))

    return cache


def _parse_raw_deal(row: dict, deal_type: str) -> dict:
    """
    Parse a deal row (CSV or JSON) with symbol and deal_date preserved.

    CSV Bulk/Block: Date, Symbol, Client Name, Buy / Sell,
                    Quantity Traded, Trade Price / Wght. Avg. Price
    CSV Short:      Date, Symbol, Name, Quantity (no price, no buy/sell)
    JSON uses BD_/SS_ prefixed keys.
    """
    try:
        is_short = "short" in deal_type

        price = _safe_float(
            row.get("Trade Price / Wght. Avg. Price") or  # CSV
            row.get("BD_TP_WATP") or 0                    # JSON
        )
        if not is_short and (not price or price <= 0):
            return None

        qty = _safe_float(
            row.get("Quantity Traded") or    # CSV bulk/block
            row.get("Quantity") or           # CSV short
            row.get("BD_QTY_TRD") or         # JSON
            row.get("SS_QTY") or 0           # JSON
        )
        value_cr = (price * qty / 1e7) if (price and qty) else 0.0

        if is_short:
            direction = "SHORT"
        else:
            action = str(
                row.get("Buy / Sell") or     # CSV
                row.get("BD_BUY_SELL") or    # JSON
                ""
            ).strip().upper()
            if action in ("BUY", "B"):
                direction = "BUY"
            elif action in ("SELL", "S"):
                direction = "SELL"
            else:
                direction = "BUY"

        if "block" in deal_type:
            dtype = "BLOCK"
        elif is_short:
            dtype = "SHORT"
        else:
            dtype = "BULK"

        entity = str(
            row.get("Client Name") or       # CSV bulk/block
            row.get("Name") or              # CSV short
            row.get("BD_CLIENT_NAME") or    # JSON
            row.get("SS_NAME") or           # JSON
            "Unknown"
        ).strip()

        deal_date = str(
            row.get("Date") or              # CSV
            row.get("BD_DT_DATE") or        # JSON
            row.get("SS_DATE") or           # JSON
            ""
        ).strip()

        symbol = str(
            row.get("Symbol") or            # CSV
            row.get("BD_SYMBOL") or         # JSON
            row.get("SS_SYMBOL") or         # JSON
            ""
        ).strip().upper()

        return {
            "symbol": symbol,
            "price": price or 0.0,
            "value_cr": round(value_cr, 2),
            "deal_type": dtype,
            "direction": direction,
            "entity": entity,
            "deal_date": deal_date,
        }
    except Exception:
        return None


def _safe_float(val) -> float:
    if val is None or val == "" or val == "-":
        return 0.0
    try:
        return float(str(val).replace(",", "").strip())
    except (ValueError, TypeError):
        return 0.0


def compute_age_days(deal_date_str: str, reference_date: str) -> int:
    """Compute days between deal date and a reference date (trade entry)."""
    for fmt in ("%d-%b-%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            d = datetime.datetime.strptime(deal_date_str.strip(), fmt).date()
            ref = datetime.datetime.strptime(reference_date.strip(), "%Y-%m-%d").date()
            diff = (ref - d).days
            return max(0, diff)  # deals before entry have positive age
        except (ValueError, AttributeError):
            continue
    return 999


def get_levels_at_entry(deals: list[dict], entry_price: float, entry_date: str) -> list[dict]:
    """
    Convert raw deals to level-like dicts with age relative to entry_date.
    Only includes deals that happened BEFORE the entry date.
    """
    levels = []
    for d in deals:
        age = compute_age_days(d["deal_date"], entry_date)
        if age <= 0 or age > 365:  # deal after entry or too old
            continue
        dist_pct = (d["price"] - entry_price) / entry_price * 100 if entry_price > 0 else 0
        levels.append({
            "price": d["price"],
            "value_cr": d["value_cr"],
            "deal_type": d["deal_type"],
            "direction": d["direction"],
            "entity": d["entity"],
            "age_days": age,
            "distance_pct": dist_pct,
        })
    return levels


def get_nearest_level(levels: list[dict], entry_price: float, direction: str = None):
    """Find nearest deal level to entry price, optionally filtered by direction."""
    best = None
    best_dist = float("inf")
    for l in levels:
        if direction and l["direction"] != direction:
            continue
        dist_pct = abs(l["price"] - entry_price) / entry_price * 100
        if dist_pct < best_dist:
            best_dist = dist_pct
            best = l
    return best, best_dist


# ── Statistical helpers ───────────────────────────────────────────────────────

def t_test(group_a, group_b):
    """Two-sample t-test. Returns (t_stat, p_value, significant)."""
    from scipy import stats
    if len(group_a) < 5 or len(group_b) < 5:
        return 0.0, 1.0, False
    t_stat, p_val = stats.ttest_ind(group_a, group_b, equal_var=False)
    return float(t_stat), float(p_val), p_val < 0.05


def proportion_test(successes_a, n_a, successes_b, n_b):
    """Two-proportion z-test. Returns (z_stat, p_value, significant)."""
    if n_a < 5 or n_b < 5:
        return 0.0, 1.0, False
    p_a = successes_a / n_a
    p_b = successes_b / n_b
    p_pool = (successes_a + successes_b) / (n_a + n_b)
    se = np.sqrt(p_pool * (1 - p_pool) * (1/n_a + 1/n_b))
    if se == 0:
        return 0.0, 1.0, False
    z = (p_a - p_b) / se
    from scipy import stats
    p_val = 2 * (1 - stats.norm.cdf(abs(z)))
    return float(z), float(p_val), p_val < 0.05


# ── Test implementations ──────────────────────────────────────────────────────

def test_proximity_edge(trades_df, deal_cache, report):
    """
    TEST 1: Do entries near institutional deal levels outperform?

    For each proximity band [0.5%, 1%, 2%, 3%, 5%, 10%]:
      Split trades into IN_ZONE (entry within band) vs OUT_OF_ZONE.
      Compare: mean return, win rate, PT hit rate.
    """
    report.append("\n" + "="*70)
    report.append("TEST 1: PROXIMITY EDGE SIGNIFICANCE")
    report.append("="*70)

    for band in PROXIMITY_BANDS:
        in_zone = []
        out_zone = []

        for _, trade in trades_df.iterrows():
            sym = trade["symbol"]
            if sym not in deal_cache:
                continue
            deals = deal_cache[sym].get("deals", [])
            levels = get_levels_at_entry(deals, trade["entry_price"], trade["entry_date"])
            if not levels:
                out_zone.append(trade["pnl_pct"])
                continue

            _, dist = get_nearest_level(levels, trade["entry_price"])
            if dist <= band:
                in_zone.append(trade["pnl_pct"])
            else:
                out_zone.append(trade["pnl_pct"])

        n_in, n_out = len(in_zone), len(out_zone)
        if n_in < MIN_N_FOR_SIGNIFICANCE:
            report.append(f"\n  Band {band}%: IN_ZONE N={n_in} — insufficient (<{MIN_N_FOR_SIGNIFICANCE})")
            continue

        avg_in = np.mean(in_zone)
        avg_out = np.mean(out_zone)
        wr_in = sum(1 for x in in_zone if x > 0) / n_in * 100
        wr_out = sum(1 for x in out_zone if x > 0) / n_out * 100 if n_out > 0 else 0
        pt_in = sum(1 for x in in_zone if x >= 5.0) / n_in * 100
        pt_out = sum(1 for x in out_zone if x >= 5.0) / n_out * 100 if n_out > 0 else 0

        try:
            t_stat, p_val, sig = t_test(in_zone, out_zone)
        except ImportError:
            t_stat, p_val, sig = 0, 1, False
            report.append("  (scipy not installed — skipping t-test)")

        status = "✓ SIGNIFICANT" if sig else "○ not significant"

        report.append(f"\n  Band ≤{band}%:")
        report.append(f"    IN_ZONE:  N={n_in:4d}  avg={avg_in:+.2f}%  win={wr_in:.1f}%  PT5%={pt_in:.1f}%")
        report.append(f"    OUT_ZONE: N={n_out:4d}  avg={avg_out:+.2f}%  win={wr_out:.1f}%  PT5%={pt_out:.1f}%")
        report.append(f"    Δ avg={avg_in-avg_out:+.2f}pp  Δ win={wr_in-wr_out:+.1f}pp")
        report.append(f"    t={t_stat:.3f}  p={p_val:.4f}  {status}")


def test_age_decay(trades_df, deal_cache, report):
    """
    TEST 2: Do recent deal levels predict better than old ones?

    For each age bucket, measure win rate when entry is within 3% of a level.
    """
    report.append("\n" + "="*70)
    report.append("TEST 2: AGE DECAY — DOES RECENCY MATTER?")
    report.append("="*70)

    for age_lo, age_hi in AGE_BUCKETS:
        wins = 0
        total = 0

        for _, trade in trades_df.iterrows():
            sym = trade["symbol"]
            if sym not in deal_cache:
                continue
            deals = deal_cache[sym].get("deals", [])
            levels = get_levels_at_entry(deals, trade["entry_price"], trade["entry_date"])
            for l in levels:
                dist = abs(l["price"] - trade["entry_price"]) / trade["entry_price"] * 100
                if dist <= 3.0 and age_lo <= l["age_days"] <= age_hi:
                    total += 1
                    if trade["pnl_pct"] > 0:
                        wins += 1
                    break  # one match per trade per bucket

        wr = wins / total * 100 if total > 0 else 0
        status = f"N={total:4d}  win={wr:.1f}%"
        if total < MIN_N_FOR_SIGNIFICANCE:
            status += "  (insufficient N)"
        report.append(f"  {age_lo:3d}-{age_hi:3d}d:  {status}")

    report.append(f"\n  Baseline (all trades): win={trades_df['pnl_pct'].gt(0).mean()*100:.1f}%")


def test_trap_confirmation(trades_df, deal_cache, report):
    """
    TEST 3: Do SHORT disclosures near entry predict failure?

    Split trades into TRAP (SHORT within 3%, <30d, >₹25Cr) vs non-TRAP.
    Compare failure rates. If TRAP failure rate > baseline + 15pp → validated.
    """
    report.append("\n" + "="*70)
    report.append("TEST 3: SHORT DISCLOSURE TRAP CONFIRMATION")
    report.append("="*70)

    trap_returns = []
    non_trap_returns = []

    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in deal_cache:
            non_trap_returns.append(trade["pnl_pct"])
            continue

        deals = deal_cache[sym].get("deals", [])
        levels = get_levels_at_entry(deals, trade["entry_price"], trade["entry_date"])
        is_trap = False
        for l in levels:
            if l["direction"] != "SHORT":
                continue
            dist = abs(l["price"] - trade["entry_price"]) / trade["entry_price"] * 100
            if dist <= TRAP_PROXIMITY_PCT and l["age_days"] <= TRAP_MAX_AGE_DAYS and l["value_cr"] >= TRAP_MIN_VALUE_CR:
                is_trap = True
                break

        if is_trap:
            trap_returns.append(trade["pnl_pct"])
        else:
            non_trap_returns.append(trade["pnl_pct"])

    n_trap = len(trap_returns)
    n_non = len(non_trap_returns)

    report.append(f"\n  TRAP entries:     N={n_trap}")
    report.append(f"  Non-TRAP entries: N={n_non}")

    if n_trap < 5:
        report.append("  ⚠ Too few TRAP entries for meaningful analysis")
        report.append("  This is expected — SHORT disclosures near oversold entries are rare")
        report.append("  Re-run after accumulating more forward-logged signals")
        return

    fail_trap = sum(1 for x in trap_returns if x < 0) / n_trap * 100
    fail_non = sum(1 for x in non_trap_returns if x < 0) / n_non * 100
    avg_trap = np.mean(trap_returns)
    avg_non = np.mean(non_trap_returns)

    report.append(f"\n  TRAP:     fail={fail_trap:.1f}%  avg={avg_trap:+.2f}%")
    report.append(f"  Non-TRAP: fail={fail_non:.1f}%  avg={avg_non:+.2f}%")
    report.append(f"  Δ fail={fail_trap-fail_non:+.1f}pp  Δ avg={avg_trap-avg_non:+.2f}pp")

    if fail_trap - fail_non > 15:
        report.append("  ✓ VALIDATED — TRAP failure rate > baseline + 15pp")
        report.append("  → Hard score cap at ≤30 is justified")
    elif fail_trap - fail_non > 10:
        report.append("  ○ MARGINAL — TRAP shows elevated failure but < 15pp threshold")
        report.append("  → Consider softening to warning instead of hard cap")
    else:
        report.append("  ✗ NOT VALIDATED — TRAP does not significantly increase failure")
        report.append("  → Soften to informational warning, remove score cap")


def test_score_correlation(trades_df, deal_cache, report):
    """
    TEST 4: Does the continuous deal score predict returns?

    Scatter: score_delta vs forward return. Pearson correlation.
    If r > 0.15 → scoring function has predictive value.
    If r ≈ 0 → simplify to binary (level present/absent).
    """
    report.append("\n" + "="*70)
    report.append("TEST 4: SCORE DELTA CORRELATION WITH RETURNS")
    report.append("="*70)

    scores = []
    returns = []

    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in deal_cache:
            continue
        deals = deal_cache[sym].get("deals", [])
        levels = get_levels_at_entry(deals, trade["entry_price"], trade["entry_date"])
        if not levels:
            scores.append(0)
            returns.append(trade["pnl_pct"])
            continue

        from modules.deal_levels import _compute_score_delta, DealLevel
        dl_objs = []
        for l in levels:
            dl_objs.append(DealLevel(
                price=l["price"], value_cr=l["value_cr"],
                deal_type=l["deal_type"], direction=l["direction"],
                entity=l.get("entity", ""), age_days=l["age_days"],
                deal_count=1, distance_pct=l["distance_pct"],
            ))
        delta = _compute_score_delta(dl_objs, trade["entry_price"], has_trap=False)
        scores.append(delta)
        returns.append(trade["pnl_pct"])

    if len(scores) < 30:
        report.append("  Insufficient data for correlation analysis")
        return

    # Check for zero variance (all scores identical → correlation undefined)
    if np.std(scores) == 0:
        report.append(f"\n  N = {len(scores)}")
        report.append(f"  All score deltas are {scores[0]} — no variance to correlate")
        report.append("  ✗ NO correlation — need more deal coverage for meaningful test")
    else:
        r = np.corrcoef(scores, returns)[0, 1]
        report.append(f"\n  N = {len(scores)}")
        report.append(f"  Pearson r = {r:.4f}")

        if abs(r) > 0.15:
            report.append("  ✓ SIGNIFICANT correlation — continuous scoring adds value")
        elif abs(r) > 0.05:
            report.append("  ○ WEAK correlation — consider simplifying to binary")
        else:
            report.append("  ✗ NO correlation — simplify to binary (level present/absent)")

    # Distribution of score deltas
    report.append(f"\n  Score delta distribution:")
    report.append(f"    Mean:  {np.mean(scores):+.2f}")
    report.append(f"    Std:   {np.std(scores):.2f}")
    report.append(f"    Min:   {min(scores):+d}")
    report.append(f"    Max:   {max(scores):+d}")
    report.append(f"    Zero:  {sum(1 for x in scores if x == 0)} / {len(scores)}")


def test_direction_bias(trades_df, deal_cache, report):
    """
    TEST 5: Do buy-side levels below spot outperform sell-side above?

    This validates the directional logic in the scoring function.
    """
    report.append("\n" + "="*70)
    report.append("TEST 5: DIRECTION BIAS — BUY SUPPORT vs SELL RESISTANCE")
    report.append("="*70)

    near_buy = []
    near_sell = []
    no_level = []

    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in deal_cache:
            no_level.append(trade["pnl_pct"])
            continue

        deals = deal_cache[sym].get("deals", [])
        levels = get_levels_at_entry(deals, trade["entry_price"], trade["entry_date"])
        if not levels:
            no_level.append(trade["pnl_pct"])
            continue

        buy_level, buy_dist = get_nearest_level(levels, trade["entry_price"], "BUY")
        sell_level, sell_dist = get_nearest_level(levels, trade["entry_price"], "SELL")
        short_level, short_dist = get_nearest_level(levels, trade["entry_price"], "SHORT")

        # Take nearest sell/short
        sell_combined_dist = min(sell_dist, short_dist)

        if buy_level and buy_dist <= 3.0 and buy_level["price"] < trade["entry_price"]:
            near_buy.append(trade["pnl_pct"])
        elif sell_combined_dist <= 3.0:
            near_sell.append(trade["pnl_pct"])
        else:
            no_level.append(trade["pnl_pct"])

    report.append(f"\n  Near BUY support (within 3%, below entry): N={len(near_buy)}")
    if near_buy:
        report.append(f"    avg={np.mean(near_buy):+.2f}%  win={sum(1 for x in near_buy if x>0)/len(near_buy)*100:.1f}%")
    report.append(f"  Near SELL/SHORT resistance (within 3%):     N={len(near_sell)}")
    if near_sell:
        report.append(f"    avg={np.mean(near_sell):+.2f}%  win={sum(1 for x in near_sell if x>0)/len(near_sell)*100:.1f}%")
    report.append(f"  No significant level nearby:                N={len(no_level)}")
    if no_level:
        report.append(f"    avg={np.mean(no_level):+.2f}%  win={sum(1 for x in no_level if x>0)/len(no_level)*100:.1f}%")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Deal Levels Backtest")
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv",
                        help="Path to walk-forward OOS trades CSV")
    parser.add_argument("--cache", default="deals_cache.json",
                        help="Path to deal data cache file")
    parser.add_argument("--output", default="deals_backtest_report.txt",
                        help="Path to output report")
    parser.add_argument("--skip-fetch", action="store_true",
                        help="Skip NSE fetch, use cache only")
    parser.add_argument("--price-cache", default="price_cache.pkl",
                        help="Path to price data cache (pickle)")
    args = parser.parse_args()

    # Load trades
    if not os.path.exists(args.trades):
        logger.error("Trades file not found: %s", args.trades)
        logger.error("Run walk-forward first: python3 run_walkforward.py")
        sys.exit(1)

    trades_df = pd.read_csv(args.trades)
    logger.info("Loaded %d OOS trades from %s", len(trades_df), args.trades)

    # Validate required columns
    required = {"symbol", "pnl_pct", "entry_date"}
    missing = required - set(trades_df.columns)
    if missing:
        logger.error("Missing columns in trades CSV: %s", missing)
        sys.exit(1)

    # ── Reconstruct entry_price from yfinance ─────────────────────────────
    if "entry_price" not in trades_df.columns:
        logger.info("Reconstructing entry_price from yfinance...")
        trades_df = _reconstruct_entry_prices(trades_df, args.price_cache)
        valid = trades_df["entry_price"].notna()
        logger.info("Entry prices resolved: %d / %d (%.1f%%)",
                    valid.sum(), len(trades_df), valid.mean() * 100)
        trades_df = trades_df[valid].copy()

    # Get unique symbols
    symbols = sorted(trades_df["symbol"].unique())
    logger.info("Unique symbols: %d", len(symbols))

    # Fetch deal data
    if args.skip_fetch:
        if os.path.exists(args.cache):
            with open(args.cache) as f:
                deal_cache = json.load(f)
            logger.info("Using cached deal data: %d symbols", len(deal_cache))
        else:
            logger.error("Cache not found and --skip-fetch specified")
            sys.exit(1)
    else:
        deal_cache = load_or_fetch_deals(symbols, args.cache)

    # Coverage stats
    symbols_with_deals = sum(1 for s in symbols if deal_cache.get(s, {}).get("raw_deal_count", 0) > 0)
    total_deals = sum(len(deal_cache.get(s, {}).get("deals", [])) for s in symbols)
    logger.info("Coverage: %d/%d symbols have deal data (%d total deals)",
                symbols_with_deals, len(symbols), total_deals)

    # ── Find deal data coverage window ────────────────────────────────────
    all_deal_dates = []
    for s in symbols:
        for d in deal_cache.get(s, {}).get("deals", []):
            dd = d.get("deal_date", "")
            for fmt in ("%d-%b-%Y", "%d-%m-%Y", "%Y-%m-%d"):
                try:
                    all_deal_dates.append(datetime.datetime.strptime(dd.strip(), fmt).date())
                    break
                except (ValueError, AttributeError):
                    continue

    if all_deal_dates:
        deal_earliest = min(all_deal_dates)
        deal_latest = max(all_deal_dates)
        logger.info("Deal data window: %s → %s (%d unique dates)",
                    deal_earliest, deal_latest, len(set(all_deal_dates)))
    else:
        logger.error("No parseable deal dates found — check NSE response format")
        deal_earliest = datetime.date.today()
        deal_latest = datetime.date.today()

    # ── Filter trades to deal coverage window ─────────────────────────────
    # A trade at entry_date T needs deals from BEFORE T.
    # Deals cover deal_earliest → deal_latest.
    # So trade must enter AFTER deal_earliest (so there are prior deals to compare).
    # Give 30-day buffer: trade must enter at least 30d after earliest deal.
    coverage_start = deal_earliest + datetime.timedelta(days=30)
    coverage_end = deal_latest

    trades_df["entry_date_dt"] = pd.to_datetime(trades_df["entry_date"])
    total_before = len(trades_df)
    trades_df = trades_df[
        (trades_df["entry_date_dt"] >= pd.Timestamp(coverage_start)) &
        (trades_df["entry_date_dt"] <= pd.Timestamp(coverage_end))
    ].copy()

    logger.info("Trade filter: %d → %d trades within deal coverage (%s → %s)",
                total_before, len(trades_df), coverage_start, coverage_end)

    if len(trades_df) == 0:
        logger.error("NO TRADES within deal data window!")
        logger.error("  Trade dates: %s → %s",
                     pd.to_datetime(pd.read_csv(args.trades)["entry_date"]).min().date(),
                     pd.to_datetime(pd.read_csv(args.trades)["entry_date"]).max().date())
        logger.error("  Deal dates:  %s → %s", deal_earliest, deal_latest)
        logger.error("  OOS trades predate available deal data (NSE caps at 1yr)")
        logger.error("  → Run walk-forward with --years 2 for more recent trades")
        logger.error("  → Or wait for signal_tracker to accumulate live signals")
        sys.exit(0)

    # ── Debug: sample deal/trade overlap ──────────────────────────────────
    logger.info("\n── OVERLAP DIAGNOSTICS ──")
    sample_matches = 0
    for _, trade in trades_df.head(50).iterrows():
        sym = trade["symbol"]
        deals = deal_cache.get(sym, {}).get("deals", [])
        levels = get_levels_at_entry(deals, trade["entry_price"], trade["entry_date"])
        if levels:
            sample_matches += 1
            nearest, dist = get_nearest_level(levels, trade["entry_price"])
            if sample_matches <= 5:
                logger.info("  %s entry=%.1f on %s: %d levels, nearest=%.1f (%.1f%% away, %s %s)",
                           sym, trade["entry_price"], trade["entry_date"],
                           len(levels), nearest["price"], dist,
                           nearest["deal_type"], nearest["direction"])
    logger.info("  Sample: %d/50 trades have ≥1 deal level nearby", sample_matches)

    # Refresh symbols list after filter
    symbols = sorted(trades_df["symbol"].unique())

    # Run tests
    report = []
    report.append("═"*70)
    report.append("DEAL LEVELS BACKTEST REPORT")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(trades_df)} OOS (filtered to deal coverage window)")
    report.append(f"  Original: {total_before} trades → {len(trades_df)} within {coverage_start} → {coverage_end}")
    report.append(f"Symbols: {len(symbols)} ({symbols_with_deals} with deal data)")
    report.append(f"Total deals: {total_deals}")
    report.append(f"Deal window: {deal_earliest} → {deal_latest}")
    report.append("═"*70)

    test_proximity_edge(trades_df, deal_cache, report)
    test_age_decay(trades_df, deal_cache, report)
    test_trap_confirmation(trades_df, deal_cache, report)
    test_score_correlation(trades_df, deal_cache, report)
    test_direction_bias(trades_df, deal_cache, report)

    # Summary
    report.append("\n" + "═"*70)
    report.append("DECISION FRAMEWORK")
    report.append("═"*70)
    report.append("""
  IF Test 1 shows p < 0.05 for any band with N ≥ 50:
    → Lock that band as PROXIMITY_PCT in deal_levels.py
    → Feature is validated as conviction amplifier

  IF Test 2 shows monotonic decay:
    → AGE_HALF_LIFE_DAYS = 180 is correct
    → If decay is faster, reduce to 90d

  IF Test 3 shows TRAP failure > baseline + 15pp:
    → Hard score cap at ≤30 is justified
    → If < 10pp, soften to warning only

  IF Test 4 shows r > 0.15:
    → Continuous scoring adds value, keep as-is
    → If r ≈ 0, simplify to binary (present/absent)

  IF Test 5 shows BUY support > baseline > SELL resistance:
    → Directional logic is correct
    → If no difference, remove direction weighting
""")

    # Write report
    report_text = "\n".join(report)
    print(report_text)

    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nReport saved to %s", args.output)


def _reconstruct_entry_prices(
    trades_df: pd.DataFrame,
    cache_path: str = "price_cache.pkl",
) -> pd.DataFrame:
    """
    Look up entry_price for each trade using yfinance daily close on entry_date.
    Caches price data to avoid re-downloading on subsequent runs.
    """
    import yfinance as yf

    # Load or build price cache: {symbol: DataFrame}
    price_data = {}
    if os.path.exists(cache_path):
        try:
            price_data = pd.read_pickle(cache_path)
            logger.info("Price cache loaded: %d symbols", len(price_data))
        except Exception:
            price_data = {}

    symbols_needed = set(trades_df["symbol"].unique())
    symbols_to_fetch = symbols_needed - set(price_data.keys())

    if symbols_to_fetch:
        logger.info("Fetching price data for %d symbols...", len(symbols_to_fetch))
        for i, sym in enumerate(sorted(symbols_to_fetch)):
            try:
                ticker = sym if sym.startswith("^") else f"{sym}.NS"
                df = yf.download(ticker, period="5y", progress=False, timeout=15)
                if df is not None and len(df) > 0:
                    price_data[sym] = df
                if (i + 1) % 20 == 0:
                    logger.info("  %d/%d price series fetched", i + 1, len(symbols_to_fetch))
            except Exception as exc:
                logger.debug("  %s: price fetch failed — %s", sym, exc)

        # Save cache
        pd.to_pickle(price_data, cache_path)
        logger.info("Price cache saved: %d symbols", len(price_data))

    # Look up entry_price for each trade
    entry_prices = []
    for _, row in trades_df.iterrows():
        sym = row["symbol"]
        date_str = row["entry_date"]
        price = None

        if sym in price_data:
            df = price_data[sym]
            try:
                dt = pd.Timestamp(date_str)
                # Find closest trading day on or after entry_date
                mask = df.index >= dt
                if mask.any():
                    close_col = "Close"
                    if isinstance(df.columns, pd.MultiIndex):
                        close_col = ("Close", f"{sym}.NS")
                        if close_col not in df.columns:
                            close_col = df.columns[df.columns.get_level_values(0) == "Close"][0]
                    price = float(df.loc[mask, close_col].iloc[0])
                else:
                    # Entry date is after all data — use last close
                    close_col = "Close"
                    if isinstance(df.columns, pd.MultiIndex):
                        close_col = df.columns[df.columns.get_level_values(0) == "Close"][0]
                    price = float(df[close_col].iloc[-1])
            except Exception:
                pass

        entry_prices.append(price)

    trades_df = trades_df.copy()
    trades_df["entry_price"] = entry_prices
    return trades_df


if __name__ == "__main__":
    main()
