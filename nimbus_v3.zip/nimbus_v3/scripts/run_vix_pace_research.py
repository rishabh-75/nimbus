"""scripts/run_vix_pace_research.py — VIX pace regime impact study.

Research question: does VIX pace (rate of change, not level) modulate
forward returns across industries, equity tags, and trend phases?

If yes, we learn:
  - Which industries structurally lead/lag as VIX regime shifts
  - Whether our existing tag edges (ALPHA, ACCUM, FADE, HIGHβ, LOWβ)
    are regime-dependent or robust
  - Whether TrendPhase classification should include VIX pace as
    a parameter

VIX pace regime (definition):
  1. slope_20d_t = (VIX_t - VIX_{t-20}) / 20       # avg daily change
  2. z_t = (slope_20d_t - slope_20d.rolling(252).mean()) / rolling_std
  3. regime_t =
       RISING    if z_t >  +1.0
       FALLING   if z_t <  -1.0
       STABLE    otherwise

Self-normalizing against VIX's own baseline behavior — if VIX's
volatility-of-volatility shifts over years, the thresholds
automatically adapt.

Reads:
  - Equity panel via nimbus_v3.research.equity_universe
  - Industry map via nimbus_v3.data.industry_db
  - VIX history via nimbus_v3.data.vix_loader.VIXLoader

Writes: stdout tables + a CSV dump under scripts/output/ for plotting.
"""
from __future__ import annotations

import logging
import sys
from datetime import timedelta
from pathlib import Path

import numpy as np
import pandas as pd

# Path setup so we can run as ``python scripts/run_vix_pace_research.py``
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from nimbus_v3.compute.engine import StrategyComputeEngine          # noqa: E402
from nimbus_v3.compute.industry_analytics import (                   # noqa: E402
    IndustryAnalyticsEngine,
)
from nimbus_v3.data.cache import ParquetCache                        # noqa: E402
from nimbus_v3.data.enriched_cache import EnrichedPanelCache         # noqa: E402
from nimbus_v3.data.industry_db import load_industry_db              # noqa: E402
from nimbus_v3.data.vix_loader import VIXLoader                      # noqa: E402
from nimbus_v3.research.equity_universe import (                     # noqa: E402
    CACHE_DIR as _EQ_CACHE_DIR,
    load_equity_panel,
)
from nimbus_v3.research.harness import add_forward_returns           # noqa: E402

logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("vix_pace_research")
log.setLevel(logging.INFO)


# ══════════════════════════════════════════════════════════════════════
# Pace regime classifier
# ══════════════════════════════════════════════════════════════════════

_SLOPE_WIN = 20       # default rolling window for slope computation
_Z_WIN = 252          # rolling window for z-score baseline (~1 trading yr)
_Z_CUT = 1.0          # threshold beyond which we flag RISING / FALLING


def classify_vix_pace(
    vix_close: pd.Series,
    *,
    slope_win: int = _SLOPE_WIN,
) -> pd.DataFrame:
    """Return a DataFrame with columns ['vix', 'slope', 'z', 'regime'],
    indexed by the input's index. ``regime`` is one of
    {'RISING', 'FALLING', 'STABLE', 'UNKNOWN'}; UNKNOWN covers bars
    before the z-score baseline has enough history (< _Z_WIN).

    Args:
        vix_close: Daily VIX close series.
        slope_win: Rolling window for the slope calculation (in
            trading days). The z-score baseline window is always
            252 trading days regardless of slope_win — this
            self-normalizes but note the caveat that for longer
            slope windows (e.g. 60d) the 252d baseline contains
            only ~4 independent slope observations, so the z-score
            itself gets jumpier.
    """
    slope = vix_close.diff(slope_win) / slope_win
    mu = slope.rolling(_Z_WIN).mean()
    sd = slope.rolling(_Z_WIN).std()
    z = (slope - mu) / sd

    regime = pd.Series("UNKNOWN", index=vix_close.index)
    regime[z > +_Z_CUT] = "RISING"
    regime[z < -_Z_CUT] = "FALLING"
    regime[(z >= -_Z_CUT) & (z <= +_Z_CUT)] = "STABLE"

    return pd.DataFrame({
        "vix": vix_close,
        "slope": slope,
        "z": z,
        "regime": regime,
    })


# ══════════════════════════════════════════════════════════════════════
# Reporting primitives
# ══════════════════════════════════════════════════════════════════════

def _mean_tstat(x: pd.Series) -> tuple[float, int, float]:
    """Mean, N, t-stat vs H0: mean=0. Returns (nan, 0, nan) for empty."""
    x = x.dropna()
    n = len(x)
    if n < 2:
        return (float("nan"), n, float("nan"))
    mean = float(x.mean())
    sd = float(x.std(ddof=1))
    if sd == 0:
        return (mean, n, float("nan"))
    t = mean / (sd / np.sqrt(n))
    return (mean, n, t)


def _print_table(
    title: str,
    df: pd.DataFrame,
    *,
    sig_cols: list[str] | None = None,
    stream=None,
) -> None:
    """Pretty-print a report table. When ``stream`` is None, writes
    to stdout (existing behavior); otherwise writes to the provided
    file-like object, which lets the multi-window orchestrator
    route each window's output to its own file."""
    if stream is None:
        stream = sys.stdout
    print("", file=stream)
    print("─" * 78, file=stream)
    print(title, file=stream)
    print("─" * 78, file=stream)
    with pd.option_context("display.max_rows", None,
                            "display.max_columns", None,
                            "display.width", 180,
                            "display.float_format", lambda x: f"{x:.4f}"):
        print(df.to_string(), file=stream)


# ══════════════════════════════════════════════════════════════════════
# Step 1: regime distribution
# ══════════════════════════════════════════════════════════════════════

def report_regime_distribution(regime_df: pd.DataFrame, *, stream=None) -> None:
    if stream is None:
        stream = sys.stdout
    reg = regime_df["regime"]
    total = (reg != "UNKNOWN").sum()
    if total == 0:
        print("No classifiable regime days — not enough VIX history.", file=stream)
        return

    counts = reg.value_counts()
    pct = counts / total * 100

    # Duration of consecutive same-regime runs
    runs = (reg != reg.shift()).cumsum()
    # Strip names from the grouper + derived series so downstream
    # DataFrame columns named "regime" don't collide with
    # inherited index-level / series names.
    runs.name = None
    run_lens = reg.groupby(runs).size()
    run_lens.index.name = None
    run_regime = reg.groupby(runs).first()
    run_regime.name = None
    run_regime.index.name = None
    dur_summary = pd.DataFrame({"length": run_lens, "regime": run_regime})
    dur_summary = dur_summary[dur_summary["regime"] != "UNKNOWN"]
    dur_stats = dur_summary.groupby("regime")["length"].agg(["mean", "median", "max", "count"])

    dist = pd.DataFrame({"n_days": counts, "pct": pct})
    dist = dist.reindex(["RISING", "STABLE", "FALLING", "UNKNOWN"])
    dist = dist.dropna()

    _print_table("Regime distribution (total classifiable days: %d)" % total, dist, stream=stream)
    _print_table("Regime run-length stats (in trading days)", dur_stats, stream=stream)


# ══════════════════════════════════════════════════════════════════════
# Step 2: industry × regime grid
# ══════════════════════════════════════════════════════════════════════

def report_industry_regime_grid(
    panel_w_fwd: dict[str, pd.DataFrame],
    industry_map: dict[str, str],
    regime_series: pd.Series,
    *,
    stream=None,
) -> pd.DataFrame:
    """For each industry, for each regime: mean fwd_10d across all
    (symbol, bar) pairs, t-stat, N. Returns the full grid as a
    DataFrame.
    """
    rows: list[dict] = []
    regime_aligned = regime_series.rename("regime")

    # Bucket symbols by industry
    by_industry: dict[str, list[str]] = {}
    for sym, ind in industry_map.items():
        if sym in panel_w_fwd:
            by_industry.setdefault(ind, []).append(sym)

    for industry, syms in sorted(by_industry.items()):
        # Stack all (sym, bar)'s fwd_10d, aligned to regime label by date
        parts = []
        for sym in syms:
            df = panel_w_fwd[sym]
            if "fwd_ret_10d" not in df.columns:
                continue
            s = df["fwd_ret_10d"].to_frame("fwd")
            s = s.join(regime_aligned, how="inner")
            parts.append(s)
        if not parts:
            continue
        stacked = pd.concat(parts)
        stacked = stacked.dropna(subset=["fwd"])

        for regime in ("RISING", "STABLE", "FALLING"):
            mask = stacked["regime"] == regime
            mean, n, t = _mean_tstat(stacked.loc[mask, "fwd"])
            rows.append({
                "industry":   industry,
                "regime":     regime,
                "n_obs":      n,
                "mean_fwd10": mean * 100,   # display in %
                "t_stat":     t,
            })

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    # Pivot: industries as rows, regimes as columns (mean%); keep N + t for diag
    pivot_mean = out.pivot(index="industry", columns="regime", values="mean_fwd10")
    pivot_n = out.pivot(index="industry", columns="regime", values="n_obs")
    pivot_t = out.pivot(index="industry", columns="regime", values="t_stat")
    # Reorder columns for readability
    col_order = [c for c in ("RISING", "STABLE", "FALLING") if c in pivot_mean.columns]
    pivot_mean = pivot_mean[col_order]
    pivot_n = pivot_n[col_order]
    pivot_t = pivot_t[col_order]

    # Signed spread RISING minus FALLING — most actionable column
    if "RISING" in pivot_mean.columns and "FALLING" in pivot_mean.columns:
        pivot_mean["Δ(R-F)"] = pivot_mean["RISING"] - pivot_mean["FALLING"]

    # Sort by the spread column (largest positive = outperform when VIX rising)
    if "Δ(R-F)" in pivot_mean.columns:
        pivot_mean = pivot_mean.sort_values("Δ(R-F)", ascending=False)

    _print_table(
        "Industry × VIX-pace regime: mean fwd_10d return (%, log return × 100)",
        pivot_mean, stream=stream,
    )
    _print_table(
        "Industry × VIX-pace regime: N observations",
        pivot_n.astype("Int64"), stream=stream,
    )
    _print_table(
        "Industry × VIX-pace regime: t-statistic (vs H0: mean=0)",
        pivot_t, stream=stream,
    )
    return out


# ══════════════════════════════════════════════════════════════════════
# Step 3: tag × regime grid (symbol-level)
# ══════════════════════════════════════════════════════════════════════

_TAG_COLS = (
    ("is_alpha_leader",      "ALPHA"),
    ("is_accumulating",      "ACCUM"),
    ("is_alpha_fading",      "FADE"),
    ("is_high_beta_rider",   "HIGHβ"),
    ("is_low_beta_quality",  "LOWβ"),
    ("is_industry_declining", "IND↓"),
)


def report_tag_regime_grid(
    tagged_panel: dict[str, pd.DataFrame],
    regime_series: pd.Series,
    *,
    stream=None,
) -> None:
    """For each tag, for each regime: stratified fwd_10d where the
    tag fires. Baseline is the universe mean in that regime (no
    tag filter).
    """
    regime_aligned = regime_series.rename("regime")

    # Stack the full panel (enriched + tagged + fwd)
    stacked_parts = []
    for sym, df in tagged_panel.items():
        if "fwd_ret_10d" not in df.columns:
            continue
        cols_kept = [c for c in df.columns if c.startswith("is_") or c == "fwd_ret_10d"]
        if "fwd_ret_10d" not in cols_kept:
            continue
        sub = df[cols_kept]
        sub = sub.join(regime_aligned, how="inner")
        stacked_parts.append(sub)
    if not stacked_parts:
        print("No panel rows had both tags and forward returns — skipping tag×regime grid", file=stream or sys.stdout)
        return
    stacked = pd.concat(stacked_parts)
    stacked = stacked.dropna(subset=["fwd_ret_10d"])

    # Baseline per regime (no filter)
    baseline_rows = []
    for regime in ("RISING", "STABLE", "FALLING"):
        m = stacked["regime"] == regime
        mean, n, t = _mean_tstat(stacked.loc[m, "fwd_ret_10d"])
        baseline_rows.append({
            "tag": "BASELINE",
            "regime": regime,
            "mean_fwd10_%": mean * 100,
            "n": n,
            "t": t,
            "lift_vs_baseline_pp": 0.0,
            "t_lift": float("nan"),
        })

    tag_rows = list(baseline_rows)
    for tag_col, tag_display in _TAG_COLS:
        if tag_col not in stacked.columns:
            continue
        for regime in ("RISING", "STABLE", "FALLING"):
            regime_mask = stacked["regime"] == regime
            tag_mask = stacked[tag_col].fillna(False).astype(bool)

            in_cell = stacked.loc[regime_mask & tag_mask, "fwd_ret_10d"]
            baseline = stacked.loc[regime_mask, "fwd_ret_10d"]

            mean, n, t = _mean_tstat(in_cell)
            # Paired lift: t-stat of (in_cell - baseline_mean) against 0
            base_mean = baseline.dropna().mean()
            lift = in_cell.dropna() - base_mean
            lift_mean, _, lift_t = _mean_tstat(lift)

            tag_rows.append({
                "tag": tag_display,
                "regime": regime,
                "mean_fwd10_%": mean * 100,
                "n": n,
                "t": t,
                "lift_vs_baseline_pp": (mean - (base_mean if not np.isnan(base_mean) else 0)) * 100,
                "t_lift": lift_t,
            })

    out = pd.DataFrame(tag_rows)
    # Pretty pivot: rows = tag, cols = regime, metric split
    for metric, label in (
        ("mean_fwd10_%",         "mean fwd_10d (%)"),
        ("lift_vs_baseline_pp",  "lift vs in-regime baseline (pp)"),
        ("t_lift",               "t-stat of lift"),
        ("n",                    "N"),
    ):
        piv = out.pivot(index="tag", columns="regime", values=metric)
        cols = [c for c in ("RISING", "STABLE", "FALLING") if c in piv.columns]
        piv = piv[cols]
        # Order tags with baseline first, then by our standard list
        order = ["BASELINE"] + [t for _, t in _TAG_COLS if t in piv.index]
        piv = piv.reindex(order).dropna(how="all")
        if metric == "n":
            piv = piv.astype("Int64")
        _print_table(f"Tag × regime: {label}", piv, stream=stream)


# ══════════════════════════════════════════════════════════════════════
# Step 4: phase × regime grid
# ══════════════════════════════════════════════════════════════════════

def report_phase_regime_grid(
    panel_w_phase_fwd: dict[str, pd.DataFrame],
    regime_series: pd.Series,
    *,
    stream=None,
) -> None:
    """For each phase label, across each regime, the fwd_10d mean.

    Phase here is the per-bar classify_phase output attached to each
    enriched row, not the industry phase. We compute it inline below.
    """
    regime_aligned = regime_series.rename("regime")

    stacked_parts = []
    for sym, df in panel_w_phase_fwd.items():
        if "phase" not in df.columns or "fwd_ret_10d" not in df.columns:
            continue
        sub = df[["phase", "fwd_ret_10d"]].copy()
        sub = sub.join(regime_aligned, how="inner")
        stacked_parts.append(sub)
    if not stacked_parts:
        print("No panel rows had phase + fwd_10d — skipping phase×regime grid", file=stream or sys.stdout)
        return
    stacked = pd.concat(stacked_parts).dropna(subset=["fwd_ret_10d"])

    rows = []
    all_phases = stacked["phase"].dropna().unique().tolist()
    for phase in all_phases:
        for regime in ("RISING", "STABLE", "FALLING"):
            m = (stacked["phase"] == phase) & (stacked["regime"] == regime)
            mean, n, t = _mean_tstat(stacked.loc[m, "fwd_ret_10d"])
            rows.append({
                "phase": phase,
                "regime": regime,
                "mean_fwd10_%": mean * 100,
                "n": n,
                "t": t,
            })
    out = pd.DataFrame(rows)
    for metric, label in (
        ("mean_fwd10_%", "mean fwd_10d (%)"),
        ("n",             "N"),
        ("t",             "t-stat"),
    ):
        piv = out.pivot(index="phase", columns="regime", values=metric)
        cols = [c for c in ("RISING", "STABLE", "FALLING") if c in piv.columns]
        piv = piv[cols]
        if metric == "n":
            piv = piv.astype("Int64")
        _print_table(f"Phase × regime: {label}", piv, stream=stream)


# ══════════════════════════════════════════════════════════════════════
# Pipeline
# ══════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════
# Multi-window orchestration
# ══════════════════════════════════════════════════════════════════════

#: Slope windows to test. Each gets its own detail output file plus a
#: row in the cross-window summary.
_WINDOWS: tuple[int, ...] = (5, 10, 20, 60)

#: Where detail + summary files land. Created if missing.
_OUT_DIR = Path("scripts/output")


def _prepare_data() -> dict:
    """Run the one-time heavyweight setup: VIX history, equity panel
    enrichment, industry tagging, forward returns, phase attribution.

    None of this depends on the slope window, so we compute it once
    and reuse across all windows. Returns a dict with these keys
    that ``_run_window`` consumes:
      - vix_close:        pd.Series of VIX daily closes
      - panel_w_fwd:      {symbol: enriched+fwd DataFrame}
      - tagged_panel:     {symbol: industry-relative tagged DataFrame}
      - panel_w_phase_fwd:{symbol: phase+fwd DataFrame}
      - industry_map:     {symbol: industry}
    """
    # ── Load VIX ──────────────────────────────────────────────────────
    log.info("Loading VIX history...")
    from nimbus_v3.data.nse_client import NSEClient
    loader = VIXLoader(
        nse_client=NSEClient(),
        cache=ParquetCache(Path("data/cache/vix")),
        default_history_years=10,
    )
    vix_df = loader.load_history(cache_ttl=timedelta(days=30))
    if vix_df.empty:
        raise RuntimeError("VIX history unavailable — aborting")
    log.info("VIX history: %d bars (%s → %s)",
             len(vix_df), vix_df.index[0].date(), vix_df.index[-1].date())

    # ── Load equity panel ─────────────────────────────────────────────
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    log.info("Equity panel: %d symbols", len(raw_panel))

    # ── Enrich via cache ──────────────────────────────────────────────
    log.info("Enriching...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    hits = misses = 0
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
            hits += 1
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
                misses += 1
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched panel: %d symbols (cache: %d hits, %d misses)",
             len(enriched_panel), hits, misses)

    # ── Forward returns ───────────────────────────────────────────────
    log.info("Attaching forward returns...")
    panel_w_fwd: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        panel_w_fwd[sym] = add_forward_returns(df)

    # ── Industry map ──────────────────────────────────────────────────
    log.info("Loading industry DB...")
    ind_db = load_industry_db()
    industry_map: dict[str, str] = {
        sym: rec.industry for sym, rec in ind_db.items()
    }
    log.info("Industry map: %d symbols across %d industries",
             len(industry_map), len(set(industry_map.values())))

    # ── Industry-relative tags + phase attribution ────────────────────
    log.info("Computing industry-relative tags (this takes a minute)...")
    ind_engine = IndustryAnalyticsEngine()
    by_industry: dict[str, dict[str, pd.DataFrame]] = {}
    for sym, ind in industry_map.items():
        if sym in enriched_panel:
            by_industry.setdefault(ind, {})[sym] = enriched_panel[sym]

    tagged_panel: dict[str, pd.DataFrame] = {}
    panel_w_phase_fwd: dict[str, pd.DataFrame] = {}
    for industry, members in by_industry.items():
        if len(members) < ind_engine.MIN_INDUSTRY_SIZE:
            continue
        try:
            ind_frame = ind_engine.enrich_industry(members)
        except Exception:    # noqa: BLE001
            continue
        phase_by_date = ind_frame["phase"] if "phase" in ind_frame.columns else None
        for sym, df in members.items():
            # Tagged panel — alpha/accum/fade/etc + fwd returns
            try:
                rel = ind_engine.enrich_symbol_relative(
                    raw_df=df, symbol=sym, industry=industry,
                    industry_frame=ind_frame,
                    alpha_panel_threshold=0.0,
                )
                rel = rel.join(panel_w_fwd[sym][
                    [c for c in ("fwd_ret_5d", "fwd_ret_10d", "fwd_ret_20d")
                     if c in panel_w_fwd[sym].columns]
                ])
                tagged_panel[sym] = rel
            except Exception:    # noqa: BLE001
                pass
            # Phase-attributed panel
            if phase_by_date is not None and sym in panel_w_fwd:
                base = panel_w_fwd[sym][["fwd_ret_10d"]].copy()
                base = base.join(phase_by_date.rename("phase"), how="left")
                panel_w_phase_fwd[sym] = base
    log.info("Tagged panel: %d symbols  |  Phase-tagged panel: %d symbols",
             len(tagged_panel), len(panel_w_phase_fwd))

    return {
        "vix_close":          vix_df["Close"],
        "panel_w_fwd":        panel_w_fwd,
        "tagged_panel":       tagged_panel,
        "panel_w_phase_fwd":  panel_w_phase_fwd,
        "industry_map":       industry_map,
    }


def _run_window(slope_win: int, prepared: dict, stream) -> dict:
    """Run all four reports for one slope window, routing output to
    ``stream``. Returns a small dict of summary stats for the
    cross-window comparison table.
    """
    # Classify regimes at this window
    regime_df = classify_vix_pace(prepared["vix_close"], slope_win=slope_win)
    regime_series = regime_df["regime"]

    print(f"VIX PACE RESEARCH — slope window = {slope_win}d", file=stream)
    print(f"z-baseline = {_Z_WIN}d, z-cut = ±{_Z_CUT:.1f}", file=stream)
    print("=" * 78, file=stream)

    # Step 1: regime distribution
    report_regime_distribution(regime_df, stream=stream)

    # Step 2: industry × regime
    ind_grid = report_industry_regime_grid(
        prepared["panel_w_fwd"],
        prepared["industry_map"],
        regime_series,
        stream=stream,
    )

    # Step 3: tag × regime
    report_tag_regime_grid(
        prepared["tagged_panel"], regime_series, stream=stream,
    )

    # Step 4: phase × regime
    report_phase_regime_grid(
        prepared["panel_w_phase_fwd"], regime_series, stream=stream,
    )

    # ── Summary stats for cross-window comparison ─────────────────────
    # Pull a few numbers out of the industry grid for the summary.
    regime_counts = regime_series.value_counts()
    total_classifiable = int((regime_series != "UNKNOWN").sum())

    # Largest Δ(R-F) magnitudes (absolute) — proxy for "how much regime
    # differentiation does this window produce at the industry level?"
    top_spread = 0.0
    if not ind_grid.empty:
        pivot = ind_grid.pivot(
            index="industry", columns="regime", values="mean_fwd10",
        )
        if "RISING" in pivot.columns and "FALLING" in pivot.columns:
            spreads = (pivot["RISING"] - pivot["FALLING"]).abs().dropna()
            if len(spreads) > 0:
                top_spread = float(spreads.max())

    return {
        "slope_win":          slope_win,
        "n_rising":           int(regime_counts.get("RISING", 0)),
        "n_stable":           int(regime_counts.get("STABLE", 0)),
        "n_falling":          int(regime_counts.get("FALLING", 0)),
        "n_classifiable":     total_classifiable,
        "pct_stable":         float(regime_counts.get("STABLE", 0)) / max(total_classifiable, 1) * 100,
        "top_industry_spread_pp": top_spread,
    }


def _write_summary(summaries: list[dict], stream) -> None:
    """Cross-window comparison table — one row per slope window."""
    df = pd.DataFrame(summaries)
    print("VIX PACE RESEARCH — cross-window summary", file=stream)
    print("=" * 78, file=stream)
    print(
        "\nEach row is a slope window. Compare the regime distribution "
        "balance\n(n_rising / n_stable / n_falling) and "
        "top_industry_spread_pp across\nwindows — the 'right' window "
        "produces balanced regime coverage AND\nmaterial cross-regime "
        "differentiation. Extreme STABLE dominance (>80%) or\ntiny "
        "spreads (<2pp) suggest the window doesn't resolve regime "
        "shifts\nat this horizon.",
        file=stream,
    )
    print("", file=stream)
    _print_table("Window bake-off", df, stream=stream)
    print("""

Reading guide:
  - Small slope_win (5d, 10d): more RISING/FALLING days, shorter runs,
    catches faster inflections but noisier. Expect tag lifts to
    be more muted if the signal averages over noise.
  - Large slope_win (60d): fewer RISING/FALLING days, longer runs,
    captures secular shifts. Expect stronger per-day effects but
    fewer observations in the extreme cells → wider confidence
    intervals.
  - Look for the window whose industry Δ(R-F) t-stats are largest
    while still having n>200 per cell. That's the window worth
    productionizing.
""", file=stream)


def main() -> None:
    """Multi-window VIX pace research.

    Prepares the heavyweight inputs once (VIX history, equity panel,
    industry tags, phase attribution), then runs the four-report
    bundle for each slope window in ``_WINDOWS``, writing each
    window's output to its own file under ``scripts/output/``. A
    cross-window summary is written last.
    """
    _OUT_DIR.mkdir(parents=True, exist_ok=True)

    try:
        prepared = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    summaries: list[dict] = []
    for win in _WINDOWS:
        out_path = _OUT_DIR / f"vix_pace_research_{win}d.txt"
        log.info("Running window=%dd → %s", win, out_path)
        with out_path.open("w") as f:
            stats = _run_window(win, prepared, f)
        summaries.append(stats)

    # Cross-window summary
    summary_path = _OUT_DIR / "vix_pace_research_summary.txt"
    log.info("Writing summary → %s", summary_path)
    with summary_path.open("w") as f:
        _write_summary(summaries, f)

    # Print the summary to stdout as well — convenient for eyeballing
    # immediately after the run finishes.
    print()
    print("=" * 78)
    print("RUN COMPLETE. Detail files:")
    for win in _WINDOWS:
        print(f"  {_OUT_DIR / f'vix_pace_research_{win}d.txt'}")
    print(f"Summary:")
    print(f"  {summary_path}")
    print("=" * 78)
    _write_summary(summaries, sys.stdout)


if __name__ == "__main__":
    main()
