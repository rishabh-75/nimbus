"""nimbus_v3.ui.presenters.builders — pure ViewModel builders.

No Qt dependency, no IO. Every public function is a pure mapping from
domain types (enriched dataframe, NSE
:class:`SymbolMeta`) to a frozen view dataclass that the rendering
widgets consume.

This module is the only place where domain-to-display interpretation
happens. Colours, threshold buckets, and label strings are decided
here so the widgets can stay purely structural.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import pandas as pd

from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.ui.theme import GREEN, MUTED, RED


# ══════════════════════════════════════════════════════════════════════════════
# View dataclasses — frozen, immutable, no behaviour
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class HeaderView:
    """Top-of-dashboard symbol header. Six fields, all pre-formatted."""

    symbol: str = "—"
    spot_text: str = "—"        # e.g. "₹ 2,450.30"
    change_text: str = "—"      # e.g. "+1.8%"
    change_color: str = MUTED   # GREEN if positive, RED if negative
    asof_text: str = ""         # e.g. "close 30 Apr 2026"
    asof_color: str = MUTED


@dataclass(frozen=True)
class IndustryClassificationView:
    """The NSE four-level hierarchy for the active symbol."""

    macro: str = "—"
    sector: str = "—"
    industry: str = "—"
    basic: str = "—"


# ══════════════════════════════════════════════════════════════════════════════
# Empty singletons — used as initial state and as fallback on bad input
# ══════════════════════════════════════════════════════════════════════════════

EMPTY_HEADER_VIEW: Final[HeaderView] = HeaderView()
EMPTY_INDUSTRY_VIEW: Final[IndustryClassificationView] = IndustryClassificationView()



# ══════════════════════════════════════════════════════════════════════════════
# Header builder
# ══════════════════════════════════════════════════════════════════════════════


def build_header_view(
    symbol: str,
    enriched_df: pd.DataFrame | None,
    asof_label: str = "",
) -> HeaderView:
    """Render the dashboard header from the most-recent bar.

    Args:
        symbol: ticker text shown on the left.
        enriched_df: indicator-enriched OHLCV. The last row is used.
            Pass ``None`` (or empty) to get the empty view.
        asof_label: free-form date label (e.g. ``"close 30 Apr 2026"``).
    """
    if enriched_df is None or enriched_df.empty:
        return HeaderView(symbol=symbol or "—", asof_text=asof_label)

    try:
        last = enriched_df.iloc[-1]
        prev = enriched_df.iloc[-2] if len(enriched_df) >= 2 else last
        spot = float(last["Close"])
        prev_close = float(prev["Close"])
    except (KeyError, IndexError, TypeError, ValueError):
        return HeaderView(symbol=symbol or "—", asof_text=asof_label)

    if not (spot == spot):    # NaN check
        return HeaderView(symbol=symbol or "—", asof_text=asof_label)

    spot_text = f"₹ {spot:,.2f}"

    if prev_close and prev_close == prev_close and prev_close != 0:
        pct = (spot / prev_close - 1.0) * 100.0
        change_text = f"{pct:+.2f}%"
        change_color = GREEN if pct >= 0 else RED
    else:
        change_text = "—"
        change_color = MUTED

    return HeaderView(
        symbol=symbol or "—",
        spot_text=spot_text,
        change_text=change_text,
        change_color=change_color,
        asof_text=asof_label,
        asof_color=MUTED,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Industry classification builder
# ══════════════════════════════════════════════════════════════════════════════


def build_industry_view(
    meta: SymbolMeta | None,
) -> IndustryClassificationView:
    """Pull the four-level NSE classification off a :class:`SymbolMeta`."""
    if meta is None:
        return EMPTY_INDUSTRY_VIEW
    return IndustryClassificationView(
        macro=meta.macro_sector or "—",
        sector=meta.sector or "—",
        industry=meta.industry or "—",
        basic=meta.basic_industry or "—",
    )


# ══════════════════════════════════════════════════════════════════════════════
# Coercion helpers
# ══════════════════════════════════════════════════════════════════════════════


def _safe_float(value) -> float:
    """Coerce to native float, returning NaN on any failure."""
    if value is None:
        return float("nan")
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")
