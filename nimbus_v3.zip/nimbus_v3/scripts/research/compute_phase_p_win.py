#!/usr/bin/env python3
"""scripts/research/compute_phase_p_win.py — research pipeline.

Walks the current 473-symbol panel, classifies every symbol,
extracts every fire event, and produces:

  - ``events.parquet``           — raw fire-event records
  - ``init_retest_stats.parquet``— per-symbol Beta-smoothed
                                   p_win for INIT/RETEST under
                                   three definitions:
                                     * relative (vs symbol mean)
                                     * profit (return > 0)
                                     * meaningful (return > 1%)
  - ``cont_model_median.json``   — universe-wide CONT logistic
                                   regression, label = "ride
                                   continues for ≥ symbol's
                                   median hold bars"
  - ``cont_model_fixed.json``    — same model, label = "ride
                                   continues for ≥ 5 bars"
                                   (FIXED_HORIZON_BARS)
  - ``universe_ranked.csv``      — symbols' latest fires,
                                   columns include all three
                                   p_wins, both CONT model
                                   predictions, and live
                                   conviction score for stacking
  - ``report.md``                — methodology + comparison of
                                   the two CONT models +
                                   stacking analysis

Output goes to ``data/research/phase_p_win/<timestamp>/``.

Usage
─────
    # First run — builds everything from scratch.
    python scripts/research/compute_phase_p_win.py

    # Force fresh yfinance fetches (bypass the price cache).
    python scripts/research/compute_phase_p_win.py --rebuild

    # Limit to a subset for fast iteration.
    python scripts/research/compute_phase_p_win.py \\
        --symbols AWL CIPLA SUNPHARMA

NOT for production
──────────────────
This script does not modify the live cockpit, the cache layer,
or the deploy target. It produces offline artefacts only.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Add project root to sys.path so 'nimbus_v3' resolves when run
# directly from scripts/research/.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import RideEngine
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.data.industry_db import load_industry_db
from nimbus_v3.data.paths import cache_dir, data_root
from nimbus_v3.data.price_loader import PriceLoader
from nimbus_v3.research.phase_p_win.aggregate import (
    aggregate_per_symbol,
    stats_to_dataframe,
    universe_win_rates,
)
from nimbus_v3.research.phase_p_win.cont_model import (
    predict_with_metadata,
    save_model_metadata,
    train_cont_model,
)
from nimbus_v3.research.phase_p_win.extract import (
    events_to_dataframe,
    extract_fire_events,
)
from nimbus_v3.research.phase_p_win.schema import (
    FIXED_HORIZON_BARS,
    LatestFireScore,
    MIN_HISTORY_BARS,
)


logger = logging.getLogger("phase_p_win")


# ══════════════════════════════════════════════════════════════════════════════
# Argument parsing
# ══════════════════════════════════════════════════════════════════════════════


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=__doc__.split("\n\n")[0],
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--symbols", nargs="+", default=None,
        help=(
            "Restrict to a subset of symbols. Default: all symbols "
            "in the industry DB."
        ),
    )
    parser.add_argument(
        "--rebuild", action="store_true",
        help=(
            "Force fresh fetches from yfinance (force_refresh=True "
            "on every PriceLoader.load call). Default uses cache."
        ),
    )
    parser.add_argument(
        "--output-root", default=None,
        help=(
            "Base directory for output. Default: "
            "<data_root>/research/phase_p_win."
        ),
    )
    return parser.parse_args()


# ══════════════════════════════════════════════════════════════════════════════
# Pipeline
# ══════════════════════════════════════════════════════════════════════════════


def run() -> int:
    args = _parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    out_root = (
        Path(args.output_root)
        if args.output_root else
        data_root() / "research" / "phase_p_win"
    )
    timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
    out_dir = out_root / timestamp
    out_dir.mkdir(parents=True, exist_ok=True)
    logger.info("output directory: %s", out_dir)

    ind_db = load_industry_db()
    if not ind_db:
        logger.error(
            "industry DB is empty — run scripts/build_industry_db.py first"
        )
        return 1

    symbol_list = sorted(ind_db.keys())
    if args.symbols:
        requested = set(args.symbols)
        symbol_list = [s for s in symbol_list if s in requested]
        if not symbol_list:
            logger.error(
                "none of the requested symbols are in the industry DB: %s",
                args.symbols,
            )
            return 1
    logger.info("processing %d symbols", len(symbol_list))

    compute = StrategyComputeEngine()
    raw_cache = ParquetCache(base_dir=cache_dir("equity_price"))
    enriched_cache = EnrichedPanelCache(
        raw_cache=raw_cache,
        schema_hash=compute.enrichment_schema_hash(),
    )
    price_loader = PriceLoader(raw_cache, default_years=2)
    ride_engine = RideEngine()

    # ── Per-symbol: load → enrich → classify → extract events.
    # Also keep the (enriched, ride_result) pair for the stack
    # analysis at the end (live conviction-score lookup needs
    # both).
    t0 = time.perf_counter()
    all_events = []
    enriched_by_symbol: dict[str, pd.DataFrame] = {}
    ride_result_by_symbol: dict[str, "RideResult"] = {}    # type: ignore[name-defined]
    n_processed = 0
    n_skipped_short = 0
    n_failed = 0

    for sym in symbol_list:
        try:
            if args.rebuild:
                raw = price_loader.load(sym, force_refresh=True)
            else:
                hit = enriched_cache.get_if_fresh(sym)
                if hit is not None:
                    if len(hit) < MIN_HISTORY_BARS:
                        n_skipped_short += 1
                        continue
                    enriched = hit
                    raw = None
                else:
                    raw = price_loader.load(sym)

            if raw is not None:
                if len(raw) < MIN_HISTORY_BARS:
                    n_skipped_short += 1
                    continue
                enriched = compute.enrich(raw, sym)
                enriched_cache.set(sym, enriched)
        except Exception:    # noqa: BLE001
            logger.exception("%s: load/enrich failed; skipping", sym)
            n_failed += 1
            continue

        if len(enriched) < MIN_HISTORY_BARS:
            n_skipped_short += 1
            continue

        try:
            res = ride_engine.classify(enriched)
            events = extract_fire_events(sym, enriched, res)
            all_events.extend(events)
            enriched_by_symbol[sym] = enriched
            ride_result_by_symbol[sym] = res
            n_processed += 1
        except Exception:    # noqa: BLE001
            logger.exception("%s: classify/extract failed; skipping", sym)
            n_failed += 1
            continue

        if n_processed % 50 == 0 and n_processed > 0:
            logger.info(
                "  ...%d/%d processed (%d events so far)",
                n_processed, len(symbol_list), len(all_events),
            )

    logger.info(
        "extraction done in %.1fs: %d processed, %d skipped (short), "
        "%d failed; %d total events",
        time.perf_counter() - t0,
        n_processed, n_skipped_short, n_failed, len(all_events),
    )

    if not all_events:
        logger.error("no fire events extracted — nothing to aggregate")
        return 1

    # ── Aggregate per-symbol p_win under three definitions ───────────
    u_rates = universe_win_rates(all_events)
    logger.info("universe win rates by phase + definition:")
    for phase, defs in u_rates.items():
        logger.info(
            "  %s: relative=%.3f profit=%.3f meaningful=%.3f",
            phase, defs["relative"], defs["profit"], defs["meaningful"],
        )
    stats = aggregate_per_symbol(all_events, universe_rates=u_rates)
    logger.info("computed stats for %d (symbol, phase) pairs", len(stats))

    # ── Train both CONT models ──────────────────────────────────────
    cont_events = [ev for ev in all_events if ev.phase == "CONT"]

    meta_median = None
    meta_fixed = None
    try:
        meta_median, _, _ = train_cont_model(
            cont_events, stats,
            universe_p_win_init=u_rates["INIT"]["relative"],
            universe_p_win_retest=u_rates["RETEST"]["relative"],
            universe_p_win_cont=u_rates["CONT"]["relative"],
            label_kind="median_hold",
        )
        logger.info(
            "CONT model (median_hold): n_train=%d n_test=%d  pos_rate=%.3f  "
            "test_acc=%.3f test_AUROC=%.3f test_Brier=%.3f",
            meta_median.n_train, meta_median.n_test, meta_median.test_pos_rate,
            meta_median.test_accuracy, meta_median.test_auroc,
            meta_median.test_brier,
        )
    except ValueError as exc:
        logger.warning("median_hold model training failed: %s", exc)

    try:
        meta_fixed, _, _ = train_cont_model(
            cont_events, stats,
            universe_p_win_init=u_rates["INIT"]["relative"],
            universe_p_win_retest=u_rates["RETEST"]["relative"],
            universe_p_win_cont=u_rates["CONT"]["relative"],
            label_kind="fixed_horizon",
            fixed_horizon=FIXED_HORIZON_BARS,
        )
        logger.info(
            "CONT model (fixed_horizon=%d): n_train=%d n_test=%d  "
            "pos_rate=%.3f  test_acc=%.3f test_AUROC=%.3f test_Brier=%.3f",
            FIXED_HORIZON_BARS,
            meta_fixed.n_train, meta_fixed.n_test, meta_fixed.test_pos_rate,
            meta_fixed.test_accuracy, meta_fixed.test_auroc,
            meta_fixed.test_brier,
        )
    except ValueError as exc:
        logger.warning("fixed_horizon model training failed: %s", exc)

    # ── Latest-fire scores per symbol ───────────────────────────────
    latest_scores = _build_latest_scores(
        all_events, stats, meta_median, meta_fixed,
        enriched_by_symbol, ride_result_by_symbol,
    )

    # ── Persist outputs ─────────────────────────────────────────────
    events_df = events_to_dataframe(all_events)
    events_df.to_parquet(out_dir / "events.parquet", index=False)
    logger.info("wrote events.parquet (%d rows)", len(events_df))

    stats_df = stats_to_dataframe(stats)
    stats_df.to_parquet(out_dir / "init_retest_stats.parquet", index=False)
    logger.info("wrote init_retest_stats.parquet (%d rows)", len(stats_df))

    if meta_median is not None:
        save_model_metadata(meta_median, out_dir / "cont_model_median.json")
        logger.info("wrote cont_model_median.json")
    if meta_fixed is not None:
        save_model_metadata(meta_fixed, out_dir / "cont_model_fixed.json")
        logger.info("wrote cont_model_fixed.json")

    if latest_scores:
        latest_df = pd.DataFrame([s.__dict__ for s in latest_scores])
        # Sort by p_win_profit descending — most operationally
        # meaningful single column for ranking. Operators can
        # re-sort the CSV by other columns externally.
        latest_df = latest_df.sort_values(
            "p_win_profit", ascending=False, na_position="last",
        )
        latest_df.to_csv(out_dir / "universe_ranked.csv", index=False)
        logger.info("wrote universe_ranked.csv (%d rows)", len(latest_df))

    _write_report(
        out_dir, all_events, stats, meta_median, meta_fixed,
        u_rates, latest_scores,
    )
    logger.info("wrote report.md")

    logger.info("DONE — total elapsed %.1fs", time.perf_counter() - t0)
    return 0


# ══════════════════════════════════════════════════════════════════════════════
# Latest-fire scoring + report
# ══════════════════════════════════════════════════════════════════════════════


def _build_latest_scores(
    events,
    stats,
    meta_median,
    meta_fixed,
    enriched_by_symbol,
    ride_result_by_symbol,
) -> list[LatestFireScore]:
    """For each symbol, find the latest fire and compute every
    flavour of p_win + the live conviction score at that bar.

    The conviction score lookup uses the symbol's
    :class:`RideResult.score` series at ``trigger_idx`` — exactly
    what the cockpit would have shown for that bar. This makes
    the universe_ranked.csv stack-comparable: same ordering of
    rows can be sorted by score, by any p_win, or by the model
    output.
    """
    by_sym: dict[str, list] = {}
    for ev in events:
        by_sym.setdefault(ev.symbol, []).append(ev)

    stats_lookup = {(s.symbol, s.phase): s for s in stats}
    out: list[LatestFireScore] = []

    for sym, evs in by_sym.items():
        latest = max(evs, key=lambda e: e.trigger_idx)
        s = stats_lookup.get((sym, latest.phase))

        # Conviction score lookup — uses the live RideResult.
        conv_score = None
        rr = ride_result_by_symbol.get(sym)
        if rr is not None and latest.trigger_idx < len(rr.score):
            v = rr.score.iloc[latest.trigger_idx]
            if v == v:    # not NaN
                conv_score = float(v)

        # Three INIT/RETEST p_wins from stats — applicable to
        # any phase since aggregate computes them universally.
        if s is not None:
            p_rel = s.p_win_relative_smoothed
            p_prof = s.p_win_profit_smoothed
            p_meaning = s.p_win_meaningful_smoothed
            n_hist = s.n_resolved
            avg_ret = (
                s.avg_return_pct
                if s.avg_return_pct == s.avg_return_pct else None
            )
            median_hold = s.median_hold_bars
        else:
            p_rel = p_prof = p_meaning = None
            n_hist = 0
            avg_ret = None
            median_hold = None

        # CONT model outputs — only for CONT fires; None
        # otherwise. For INIT/RETEST the historical p_wins are
        # the relevant numbers.
        p_cont_med = None
        p_cont_fix = None
        if latest.phase == "CONT":
            features = {
                f: getattr(latest, f) for f in (
                    meta_median.feature_names if meta_median
                    else (meta_fixed.feature_names if meta_fixed else ())
                )
            }
            if features:
                if meta_median is not None:
                    p_cont_med = predict_with_metadata(features, meta_median)
                if meta_fixed is not None:
                    p_cont_fix = predict_with_metadata(features, meta_fixed)

        notes_parts: list[str] = []
        if not latest.is_resolved:
            notes_parts.append("open ride")
        if s and s.n_resolved < 3:
            notes_parts.append("small sample")
        notes = "; ".join(notes_parts)

        out.append(LatestFireScore(
            symbol=sym,
            latest_phase=latest.phase,
            latest_trigger_date=latest.trigger_date,
            n_historical=n_hist,
            avg_historical_return_pct=avg_ret,
            median_hold_bars=median_hold,
            p_win_relative=p_rel,
            p_win_profit=p_prof,
            p_win_meaningful=p_meaning,
            p_win_cont_model_median=p_cont_med,
            p_win_cont_model_fixed=p_cont_fix,
            conviction_score=conv_score,
            notes=notes,
        ))

    return out


def _stack_correlation_summary(latest_scores) -> str:
    """Compute the Spearman-style rank correlation between
    conviction_score and each p_win column. Returns a markdown
    table snippet.

    Reports correlation only on rows with both values present
    (non-NaN). If we have <30 such rows, returns a stub note.
    """
    df = pd.DataFrame([s.__dict__ for s in latest_scores])
    targets = (
        ("p_win_relative",          "Historical p_win (relative, vs symbol mean)"),
        ("p_win_profit",            "Historical p_win (profit, return > 0)"),
        ("p_win_meaningful",        "Historical p_win (meaningful, return > 1%)"),
        ("p_win_cont_model_median", "CONT model (median_hold)"),
        ("p_win_cont_model_fixed",  "CONT model (fixed 5-bar horizon)"),
    )
    rows: list[str] = []
    for col, label in targets:
        sub = df[["conviction_score", col]].dropna()
        if len(sub) < 30:
            rows.append(f"| {label} | {len(sub)} | n/a (n<30) |")
            continue
        # Spearman rank correlation.
        rank_a = sub["conviction_score"].rank()
        rank_b = sub[col].rank()
        corr = rank_a.corr(rank_b)
        rows.append(f"| {label} | {len(sub)} | {corr:+.3f} |")
    return "\n".join(rows)


def _write_report(
    out_dir, events, stats, meta_median, meta_fixed, u_rates, latest_scores,
) -> None:
    """Markdown narrative report — methodology + results."""
    n_events = len(events)
    n_resolved = sum(1 for e in events if e.is_resolved)
    n_init = sum(1 for e in events if e.phase == "INIT")
    n_retest = sum(1 for e in events if e.phase == "RETEST")
    n_cont = sum(1 for e in events if e.phase == "CONT")

    lines = [
        "# Phase win-rate research",
        "",
        f"Generated {datetime.now(tz=timezone.utc).isoformat()}.",
        "",
        "## Summary",
        "",
        f"- Fire events extracted: **{n_events}** "
        f"({n_resolved} resolved, {n_events - n_resolved} open)",
        f"- INIT: {n_init}    RETEST: {n_retest}    CONT: {n_cont}",
        f"- Per-symbol-per-phase stats: **{len(stats)}** records",
        "",
        "## Three win definitions",
        "",
        (
            "Each (symbol, phase) is scored under three parallel "
            "definitions of \"win\":"
        ),
        "",
        (
            "1. **Relative** — fire's return > symbol's own historical "
            "mean. By construction this hovers near 0.50; useful for "
            "asking \"is this fire above-typical for this symbol\". "
            "Limitation: a symbol with a very negative mean has a low "
            "bar to clear, so high p_win_relative does NOT mean "
            "profitable."
        ),
        (
            "2. **Profit** — fire's return > 0. Absolute threshold; "
            "the most operationally meaningful single number. Answers "
            "\"what fraction of historical fires made money\"."
        ),
        (
            "3. **Meaningful** — fire's return > 1%. Filters out the "
            "tiny-positive returns that pad the profit fraction. "
            "Answers \"what fraction of fires delivered a result "
            "worth taking\"."
        ),
        "",
        "### Universe-wide rates",
        "",
        "| Phase | Relative | Profit | Meaningful |",
        "|---|---|---|---|",
    ]
    for phase in ("INIT", "RETEST", "CONT"):
        defs = u_rates.get(phase, {})
        lines.append(
            f"| **{phase}** | {defs.get('relative', 0.5):.3f} | "
            f"{defs.get('profit', 0.5):.3f} | "
            f"{defs.get('meaningful', 0.5):.3f} |"
        )
    lines.extend([
        "",
        (
            "Note the universe-wide *profit* rates — these are the "
            "real \"how often does a fire pay\" numbers. If profit "
            "rate is below 0.5 universe-wide, the strategy as fired "
            "is a coin-flip-or-worse on average; the value comes "
            "from selecting the upper tail (high-conviction-score, "
            "high-p_win-profit symbols)."
        ),
        "",
        "## CONT model — two label flavours",
        "",
        (
            "Both models are logistic regression, same 8 features, "
            "same walk-forward 70/30 per-symbol split, same L2 "
            "regularisation. Only the label differs:"
        ),
        "",
        (
            "- **`cont_model_median.json`** — positive iff ride "
            "continues for ≥ symbol's overall median hold (varies "
            "per symbol, ~3–5 bars). Originally specified by the "
            "operator; tends to give ~50/50 label balance per "
            "symbol so the model has a good signal-to-noise ratio "
            "but the meaning of \"positive\" varies across the "
            f"universe. Pos rate this run: "
            f"{meta_median.test_pos_rate:.3f}."
            if meta_median else
            "- **`cont_model_median.json`** — training failed."
        ),
        (
            f"- **`cont_model_fixed.json`** — positive iff ride "
            f"continues for ≥ {FIXED_HORIZON_BARS} bars (~1 trading "
            f"week). Uniform meaning across the universe. Pos rate "
            f"this run: {meta_fixed.test_pos_rate:.3f}."
            if meta_fixed else
            "- **`cont_model_fixed.json`** — training failed."
        ),
        "",
        "### Test-set diagnostics",
        "",
        "| Model | n_train | n_test | pos_rate | test_acc | test_AUROC | test_Brier |",
        "|---|---|---|---|---|---|---|",
    ])
    for label, m in [
        ("median_hold", meta_median),
        ("fixed_horizon", meta_fixed),
    ]:
        if m is None:
            lines.append(f"| {label} | n/a | n/a | n/a | n/a | n/a | n/a |")
        else:
            lines.append(
                f"| {label} | {m.n_train} | {m.n_test} | "
                f"{m.test_pos_rate:.3f} | {m.test_accuracy:.3f} | "
                f"{m.test_auroc:.3f} | {m.test_brier:.3f} |"
            )

    lines.extend([
        "",
        (
            "**Reading the comparison.** AUROC measures rank-order "
            "calibration — \"if I rank fires by predicted probability, "
            "how often does a randomly-chosen positive outrank a "
            "randomly-chosen negative\". Higher = more usable signal. "
            "If the fixed-horizon AUROC is comparable to or higher "
            "than the median-horizon, prefer fixed: the meaning of "
            "the prediction is consistent across the universe. If "
            "fixed AUROC drops sharply, it means there's no universal "
            "5-bar continuation signature — different symbols ride "
            "for very different durations and the model can only "
            "capture the per-symbol relative-strength signal."
        ),
        "",
    ])

    if meta_median is not None:
        lines.extend([
            "### Median-horizon model coefficients (standardised)",
            "",
            "| Feature | Coefficient |",
            "|---|---|",
        ])
        for name, coef in zip(meta_median.feature_names, meta_median.coefficients):
            lines.append(f"| `{name}` | {coef:+.3f} |")
        lines.append(f"| (intercept) | {meta_median.intercept:+.3f} |")
        lines.append("")

    if meta_fixed is not None:
        lines.extend([
            "### Fixed-horizon model coefficients (standardised)",
            "",
            "| Feature | Coefficient |",
            "|---|---|",
        ])
        for name, coef in zip(meta_fixed.feature_names, meta_fixed.coefficients):
            lines.append(f"| `{name}` | {coef:+.3f} |")
        lines.append(f"| (intercept) | {meta_fixed.intercept:+.3f} |")
        lines.append("")

    # ── Stack analysis ─────────────────────────────────────────────
    lines.extend([
        "## Stack analysis",
        "",
        (
            "Does p_win add information beyond what the live "
            "conviction score already encodes? The Spearman rank "
            "correlation between the live composite score (post "
            "extension/liquidity penalties) and each p_win flavour "
            "tells us. Correlation near 0 → fully independent "
            "signals; correlation near 1 → redundant; correlation "
            "near -1 → contradictory."
        ),
        "",
        "| Comparison | n | Spearman ρ vs conviction_score |",
        "|---|---|---|",
        _stack_correlation_summary(latest_scores),
        "",
        (
            "**Reading the table.** A modest |ρ| (say 0.1–0.3) is "
            "the sweet spot — p_win and conviction agree directionally "
            "but each captures something the other doesn't. Extreme "
            "|ρ| in either direction is a red flag: ρ > 0.7 means "
            "the operator is paying for two signals that say the "
            "same thing; ρ < 0 means they actively disagree and "
            "the operator has to choose which to trust."
        ),
        "",
        "## Limitations",
        "",
        "1. **Survivorship bias.** Universe is the current ~470 "
        "symbols. Delisted / merged-out names are absent — a real "
        "subset of historical 'rides that worked' is missing.",
        "2. **Sample size.** Many (symbol, phase) pairs have <5 "
        "fires. Beta smoothing handles the math, but per-symbol "
        "headline numbers should not be over-interpreted on small N.",
        "3. **Regime change.** The model learns from a 2-year "
        "window; if the next year has a different volatility / "
        "trend regime, predictions degrade.",
        "4. **No cross-validation.** Train/test split is single "
        "walk-forward per symbol. Results are illustrative; a "
        "proper k-fold CV would tighten the calibration estimate.",
        "5. **The model is not the strategy.** P_win is a prior on "
        "outcomes, not a buy/sell signal. It's one input to the "
        "operator's decision, weighted alongside the live "
        "conviction score and discretionary judgement.",
    ])

    (out_dir / "report.md").write_text("\n".join(lines))


if __name__ == "__main__":
    sys.exit(run())
