"""Market Pulse container wiring — the whole tab must read off the shared
lookback config so the ROC view, RRG view and Confluence read agree."""
import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.market_pulse_config import (
    RRG_LOOKBACK,
    STRENGTH_LOOKBACK,
)


@pytest.fixture(scope="module")
def qapp():
    from PyQt6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    return app


def _mk(seed, drift):
    idx = pd.date_range("2020-01-01", "2025-12-31", freq="B")
    c = 100 * np.cumprod(
        1 + np.random.default_rng(seed).normal(drift, 0.012, len(idx)))
    return pd.DataFrame(
        {"Open": c, "High": c * 1.01, "Low": c * 0.99, "Close": c,
         "Volume": np.full(len(idx), 1e6)}, index=idx)


def _panel():
    panel, mbi = {}, {}
    for i, (nm, d) in enumerate(
            [("A", 0.0012), ("B", 0.0008), ("C", 0.0005), ("D", 0.0003)]):
        syms = [f"{nm}{j}" for j in range(6)]
        for j, s in enumerate(syms):
            panel[s] = _mk(i * 10 + j, d)
        mbi[nm] = syms
    return mbi, panel


class _Reg:
    label = "NEUTRAL"
    signals_on = 3
    n_signals = 5


def test_market_pulse_uses_shared_lookbacks(qapp):  # noqa: ARG001
    """Strength → STRENGTH_LOOKBACK, direction → RRG_LOOKBACK, and both the
    ROC and RRG breakdown sub-tabs render the SAME result the container
    computed (no drift between the ranked list and the breakdowns)."""
    from nimbus_v3.ui.widgets.rotation_tab import RotationTab
    mbi, panel = _panel()
    bench = _mk(999, 0.0005)["Close"]
    t = RotationTab()
    t.set_data(mbi, panel, bench, regime=_Reg(), month=7,
               market_breadth=0.55)
    # Container computed on the shared horizons.
    assert t._last_rotation.lookback == STRENGTH_LOOKBACK
    assert t._last_rrg.lookback == RRG_LOOKBACK
    # Breakdown sub-tabs render the very same shared results.
    assert t._roc._last_result.lookback == STRENGTH_LOOKBACK
    assert t._rrg._last_result.lookback == RRG_LOOKBACK
    # Confluence was built (off those same results).
    assert t._confluence._result_stable is not None


def test_lookbacks_overridable_per_call(qapp):  # noqa: ARG001
    """The shared defaults can still be overridden per call for
    experiments, without touching the config module."""
    from nimbus_v3.ui.widgets.rotation_tab import RotationTab
    mbi, panel = _panel()
    bench = _mk(999, 0.0005)["Close"]
    t = RotationTab()
    t.set_data(mbi, panel, bench, regime=_Reg(), month=7,
               strength_lookback=30, rrg_lookback=45)
    assert t._last_rotation.lookback == 30
    assert t._last_rrg.lookback == 45
