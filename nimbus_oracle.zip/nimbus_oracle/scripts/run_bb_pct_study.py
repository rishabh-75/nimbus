#!/usr/bin/env python3
"""
scripts/run_bb_pct_study.py — Stock-level %B (BB position) predictive power.

  ┌──────────────────────────────────────────────────────────────────────────┐
  │ STATUS: CLOSED — REJECTED                                                │
  │                                                                          │
  │ Final findings (April 2026):                                             │
  │   1. Lower-band pierce hypothesis: REJECTED                              │
  │      - %B < 0 trades have LOWER win rate than middle bands (68.3% vs    │
  │        72%). Deep snaps are falling-knife signals, not bounces.          │
  │      - Multivariate regression: %B t-stat = 0.68 (NOT significant) and  │
  │        R² gain of just 0.0001 after adding %B to WR + pct_from_sma.     │
  │      - %B is fully captured by existing WR(30) and pct_from_sma factors.│
  │                                                                          │
  │   2. Upper-mid bucket (%B 0.6-0.8) anomaly: REJECTED                    │
  │      - 244 trades, 80% win rate, +2.65% avg PnL — looked promising.    │
  │      - All 244 trades are in fold 3 of the walk-forward backtest.       │
  │      - Fold comparison showed fold 3 is only marginally better overall  │
  │        (+1.1pp win rate, +0.61% avg PnL vs other folds).                │
  │      - The upper-mid concentration came from fold 3 trading 6.8pp more  │
  │        SECONDARY (Ride) signals than other folds, in a period when      │
  │        Ride was working — not from BB %B itself.                        │
  │                                                                          │
  │ NO GRADE CHANGES. The current grade formula adequately captures mean    │
  │ reversion setups via WR(30) + pct_from_sma. Adding %B would be          │
  │ collinear noise.                                                         │
  │                                                                          │
  │ See also:                                                                │
  │   - scripts/run_bbw_pctl_study.py (BB width — also CLOSED, also null)   │
  │   - scripts/run_fold_comparison.py (fold-level performance breakdown)   │
  │                                                                          │
  │ This script is preserved for reference. Don't run it as part of routine │
  │ research — its findings are settled.                                    │
  └──────────────────────────────────────────────────────────────────────────┘

ORIGINAL HYPOTHESIS:
  When a stock pierces the lower Bollinger Band (especially deep — %B < 0),
  it's a high-probability mean reversion setup. Volatility-normalized stretch
  (%B) catches snaps in low-volatility stocks that the absolute pct_from_sma
  measure under-weights.

DESIGN:
  For each OOS trade (4,511):
    1. Load symbol's price history from existing per-symbol parquet cache
       (data/bbw_pctl_cache/<symbol>.parquet)
    2. Compute BB(20, 2σ) at entry → %B value
    3. Also compute WR(30) and pct_from_sma(20) at entry — needed for the
       INCREMENTAL signal test (does %B add value beyond what we have)
    4. Bucket by %B and compare win rate / avg PnL
    5. Multivariate regression: PnL ~ %B + WR + pct_from_sma
       Tells us if %B has predictive power AFTER controlling for the
       factors already in the grade.

DECISION CRITERIA:
  Add as grade factor IF:
    - Bottom-decile %B (deep pierce, %B < 0) shows >= 5pp win rate edge
    - Cohen's d(below-band vs middle) >= 0.25
    - Multivariate regression shows %B coefficient is statistically
      significant AFTER controlling for WR and pct_from_sma
  REJECT IF:
    - %B effect disappears once WR and pct_from_sma are in the model
      (it's just a redundant proxy)

Usage:
    python3 scripts/run_bb_pct_study.py
    python3 scripts/run_bb_pct_study.py --max-symbols 50  # quick iteration
"""
import argparse
import datetime
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

# Reuse helpers from MR BBW study — same parquet cache, same fetcher
from scripts.run_bbw_pctl_study import (
    load_oos_trades,
    fetch_price_history_range,
    cohens_d,
)

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("bb_pct_study")


# ══════════════════════════════════════════════════════════════════════════════
# TECHNICAL FEATURE COMPUTATION
# ══════════════════════════════════════════════════════════════════════════════

def compute_bb_pct(df: pd.DataFrame, period: int = 20, std_dev: float = 2.0) -> pd.Series:
    """
    Compute %B (Bollinger Band position).
    %B = (close - lower) / (upper - lower)

    Returns:
       0.0  = price at lower band
       0.5  = price at middle band
       1.0  = price at upper band
       < 0  = price BELOW lower band (the "snap" — what we're testing)
       > 1  = price ABOVE upper band
    """
    if df.empty or len(df) < period:
        return pd.Series(dtype=float)
    close = df["Close"]
    mid = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = mid + std_dev * std
    lower = mid - std_dev * std
    band_width = (upper - lower).replace(0, np.nan)
    return (close - lower) / band_width


def compute_williams_r(df: pd.DataFrame, period: int = 30) -> pd.Series:
    """Williams %R. Range: -100 (oversold) to 0 (overbought)."""
    if df.empty or len(df) < period:
        return pd.Series(dtype=float)
    high = df["High"].rolling(period).max()
    low = df["Low"].rolling(period).min()
    return -100 * (high - df["Close"]) / (high - low).replace(0, np.nan)


def compute_pct_from_sma(df: pd.DataFrame, period: int = 20) -> pd.Series:
    """Percent distance from SMA(20). Negative = below."""
    if df.empty or len(df) < period:
        return pd.Series(dtype=float)
    sma = df["Close"].rolling(period).mean()
    return (df["Close"] / sma - 1) * 100


# ══════════════════════════════════════════════════════════════════════════════
# ENRICHMENT
# ══════════════════════════════════════════════════════════════════════════════

def enrich_trades(
    trades: pd.DataFrame,
    cache_dir: str = "data/bbw_pctl_cache",
) -> pd.DataFrame:
    """
    For each trade, compute %B, WR(30), pct_from_sma at entry.
    Reuses the parquet cache from the BBW pctl study.
    """
    os.makedirs(cache_dir, exist_ok=True)
    cache: dict[str, dict] = {}
    enriched_rows = []
    skipped = 0
    t0 = time.time()

    symbols = sorted(trades["symbol"].unique())
    logger.info(f"Enriching {len(trades)} trades across {len(symbols)} symbols")

    earliest = trades["entry_date"].min() - pd.Timedelta(days=60)
    latest = trades["entry_date"].max() + pd.Timedelta(days=5)
    logger.info(f"  Fetch range: {earliest.date()} → {latest.date()}")

    for i, sym in enumerate(symbols):
        if i % 25 == 0:
            elapsed = time.time() - t0
            rate = i / elapsed if elapsed > 0 else 0
            eta = (len(symbols) - i) / rate if rate > 0 else 0
            logger.info(f"  [{i}/{len(symbols)}] {sym} (eta {eta:.0f}s)")

        cache_path = os.path.join(cache_dir, f"{sym}.parquet")
        df = pd.DataFrame()

        if os.path.exists(cache_path):
            try:
                df = pd.read_parquet(cache_path)
                if df.empty or df.index.min() > earliest or df.index.max() < latest - pd.Timedelta(days=5):
                    df = pd.DataFrame()
            except Exception:
                df = pd.DataFrame()

        if df.empty:
            df = fetch_price_history_range(sym, earliest, latest)
            if not df.empty:
                try:
                    df.to_parquet(cache_path)
                except Exception:
                    pass

        if df.empty or len(df) < 60:
            skipped += len(trades[trades["symbol"] == sym])
            continue

        cache[sym] = {
            "bb_pct": compute_bb_pct(df),
            "wr_30": compute_williams_r(df, 30),
            "pct_sma": compute_pct_from_sma(df, 20),
        }

    logger.info(f"Pre-fetch done: {len(cache)} symbols cached, {skipped} trades skipped")

    for _, trade in trades.iterrows():
        sym = trade["symbol"]
        if sym not in cache:
            continue
        entry_date = trade["entry_date"]
        sym_data = cache[sym]
        bb_series = sym_data["bb_pct"]

        try:
            idx = bb_series.index.get_indexer([entry_date], method="ffill")[0]
            if idx < 0:
                continue
        except Exception:
            continue

        bb_val = bb_series.iloc[idx]
        wr_val = sym_data["wr_30"].iloc[idx] if idx < len(sym_data["wr_30"]) else np.nan
        sma_val = sym_data["pct_sma"].iloc[idx] if idx < len(sym_data["pct_sma"]) else np.nan

        if pd.isna(bb_val):
            continue

        row = trade.to_dict()
        row["bb_pct"] = float(bb_val)
        row["wr_30"] = float(wr_val) if not pd.isna(wr_val) else None
        row["pct_from_sma"] = float(sma_val) if not pd.isna(sma_val) else None
        enriched_rows.append(row)

    enriched = pd.DataFrame(enriched_rows)
    logger.info(f"Enriched: {len(enriched)}/{len(trades)} trades have BB data")
    return enriched


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def analyze_bb_pct(df: pd.DataFrame) -> dict:
    """Bucket trades by %B and report metrics."""
    d = df.dropna(subset=["bb_pct", "pnl_pct", "win"])
    if len(d) < 100:
        return {"error": "insufficient data", "n": len(d)}

    # %B buckets — focused on the lower-band pierce hypothesis
    buckets = [
        (-99, 0.0,  "below band  (%B<0)"),     # the snap
        (0.0,  0.2, "lower zone  (0-0.2)"),
        (0.2,  0.4, "lower-mid   (0.2-0.4)"),
        (0.4,  0.6, "mid zone    (0.4-0.6)"),
        (0.6,  0.8, "upper-mid   (0.6-0.8)"),
        (0.8,  99,  "upper zone  (>0.8)"),
    ]

    overall = []
    for lo, hi, label in buckets:
        s = d[(d["bb_pct"] >= lo) & (d["bb_pct"] < hi)]
        if len(s) < 15:
            continue
        overall.append({
            "bucket": label,
            "n": len(s),
            "win_pct": float(s["win"].mean() * 100),
            "avg_pnl": float(s["pnl_pct"].mean()),
            "med_pnl": float(s["pnl_pct"].median()),
        })

    # NORMAL VIX subset
    normal = d[d["vix_regime"] == "NORMAL"] if "vix_regime" in d.columns else pd.DataFrame()
    normal_results = []
    for lo, hi, label in buckets:
        s = normal[(normal["bb_pct"] >= lo) & (normal["bb_pct"] < hi)] if not normal.empty else pd.DataFrame()
        if len(s) < 10:
            continue
        normal_results.append({
            "bucket": label,
            "n": len(s),
            "win_pct": float(s["win"].mean() * 100),
            "avg_pnl": float(s["pnl_pct"].mean()),
        })

    # Cohen's d: below-band vs middle
    below = d[d["bb_pct"] < 0]["pnl_pct"]
    middle = d[(d["bb_pct"] >= 0.4) & (d["bb_pct"] < 0.6)]["pnl_pct"]
    d_below = cohens_d(below, middle) if len(below) >= 5 else 0.0

    return {
        "n": len(d),
        "corr": float(d["bb_pct"].corr(d["pnl_pct"])),
        "d_below_vs_mid": d_below,
        "n_below_band": len(below),
        "overall": overall,
        "normal_vix": normal_results,
    }


def multivariate_test(df: pd.DataFrame) -> dict:
    """
    Test if %B has predictive power AFTER controlling for WR(30) and pct_from_sma.

    Fits two linear regressions:
      Model A: pnl ~ wr + pct_from_sma           (baseline)
      Model B: pnl ~ wr + pct_from_sma + bb_pct  (with %B added)
    Compares R² gain. If %B is just a redundant proxy, the gain is ~0.
    """
    d = df.dropna(subset=["bb_pct", "wr_30", "pct_from_sma", "pnl_pct"])
    if len(d) < 200:
        return {"error": "insufficient data for regression", "n": len(d)}

    y = d["pnl_pct"].values

    # Model A: WR + pct_from_sma only
    Xa = np.column_stack([
        np.ones(len(d)),
        d["wr_30"].values,
        d["pct_from_sma"].values,
    ])
    beta_a, _, _, _ = np.linalg.lstsq(Xa, y, rcond=None)
    pred_a = Xa @ beta_a
    ss_res_a = np.sum((y - pred_a) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2_a = 1 - ss_res_a / ss_tot if ss_tot > 0 else 0

    # Model B: + bb_pct
    Xb = np.column_stack([
        np.ones(len(d)),
        d["wr_30"].values,
        d["pct_from_sma"].values,
        d["bb_pct"].values,
    ])
    beta_b, _, _, _ = np.linalg.lstsq(Xb, y, rcond=None)
    pred_b = Xb @ beta_b
    ss_res_b = np.sum((y - pred_b) ** 2)
    r2_b = 1 - ss_res_b / ss_tot if ss_tot > 0 else 0

    # Standard error of bb_pct coefficient — basic OLS calculation
    n, k = Xb.shape
    sigma2 = ss_res_b / (n - k)
    try:
        cov = sigma2 * np.linalg.inv(Xb.T @ Xb)
        se_bb = float(np.sqrt(cov[3, 3]))
        t_stat = float(beta_b[3] / se_bb) if se_bb > 0 else 0.0
    except np.linalg.LinAlgError:
        se_bb = 0.0
        t_stat = 0.0

    return {
        "n": len(d),
        "r2_baseline": r2_a,
        "r2_with_bb": r2_b,
        "r2_gain": r2_b - r2_a,
        "bb_coef": float(beta_b[3]),
        "bb_se": se_bb,
        "bb_t_stat": t_stat,
        "wr_coef": float(beta_a[1]),
        "sma_coef": float(beta_a[2]),
    }


def print_results(bucket_results: dict, regression: dict):
    """Format and print analysis results."""
    print("\n" + "=" * 78)
    print("  BB %B PREDICTIVE POWER — STOCK-LEVEL")
    print("  Hypothesis: lower-band pierce (%B < 0) is a high-prob MR setup")
    print("=" * 78)

    if "error" in bucket_results:
        print(f"\n  Bucket analysis SKIPPED ({bucket_results['error']})")
    else:
        r = bucket_results
        print(f"\n  N={r['n']}  corr(%B, pnl)={r['corr']:+.3f}")
        print(f"  Below-band trades: {r['n_below_band']}")
        print(f"  Cohen's d (below vs middle): {r['d_below_vs_mid']:+.3f}")

        print(f"\n  ALL TRADES:")
        print(f"  {'Bucket':>22s}  {'N':>5s}  {'Win%':>6s}  {'Avg PnL':>8s}  {'Med PnL':>8s}")
        for b in r["overall"]:
            print(f"  {b['bucket']:>22s}  {b['n']:5d}  {b['win_pct']:5.1f}%  {b['avg_pnl']:+7.2f}%  {b['med_pnl']:+7.2f}%")

        if r["normal_vix"]:
            print(f"\n  NORMAL VIX ONLY (where extra signal is most needed):")
            print(f"  {'Bucket':>22s}  {'N':>5s}  {'Win%':>6s}  {'Avg PnL':>8s}")
            for b in r["normal_vix"]:
                print(f"  {b['bucket']:>22s}  {b['n']:5d}  {b['win_pct']:5.1f}%  {b['avg_pnl']:+7.2f}%")

    print("\n" + "=" * 78)
    print("  INCREMENTAL SIGNAL TEST — DOES %B ADD VALUE BEYOND WR + pct_from_sma?")
    print("=" * 78)

    if "error" in regression:
        print(f"\n  Regression SKIPPED ({regression['error']})")
    else:
        r = regression
        print(f"\n  N = {r['n']}")
        print(f"  Model A (WR + pct_from_sma):           R² = {r['r2_baseline']:+.4f}")
        print(f"  Model B (WR + pct_from_sma + bb_pct):  R² = {r['r2_with_bb']:+.4f}")
        print(f"  R² gain from adding %B:                +{r['r2_gain']:+.4f}")
        print(f"\n  %B coefficient:        {r['bb_coef']:+.4f}")
        print(f"  %B standard error:     {r['bb_se']:.4f}")
        print(f"  %B t-statistic:        {r['bb_t_stat']:+.2f}")

        # Significance interpretation
        if abs(r['bb_t_stat']) >= 2.58:
            sig = "HIGHLY SIGNIFICANT (p < 0.01)"
        elif abs(r['bb_t_stat']) >= 1.96:
            sig = "significant (p < 0.05)"
        elif abs(r['bb_t_stat']) >= 1.65:
            sig = "marginally significant (p < 0.10)"
        else:
            sig = "NOT significant"
        print(f"  Significance:          {sig}")

    print("\n" + "=" * 78)
    print("  DECISION GUIDANCE")
    print("=" * 78)
    print("""
  ADD %B as grade factor IF ALL of:
    - Below-band trades show >= 5pp win-rate edge in bucket analysis
    - Cohen's d (below vs middle) >= 0.25
    - Regression t-stat for %B >= 1.96 (significant after controlling for WR/SMA)
    - R² gain >= 0.005 (meaningful incremental fit improvement)

  REJECT %B IF:
    - Bucket analysis shows flat/inverse pattern (deep snap doesn't help)
    - Regression t-stat < 1.65 (just a proxy for WR/SMA — no new info)
    - R² gain < 0.002 (statistically detectable but practically zero)

  Best outcome we can hope for:
    - Below-band bucket has dramatically better win rate than mid
    - %B remains significant in regression (not redundant)
    - Cohen's d > 0.25 (meaningful effect size)

  Most likely outcome (based on BBW pctl null result):
    - Bucket shows moderate edge for below-band entries
    - But regression shows %B is largely captured by WR + pct_from_sma
    - Verdict: REJECT — already covered by existing factors
""")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-symbols", type=int, default=None,
                    help="Limit to top N symbols by trade count (for fast iteration)")
    args = ap.parse_args()

    trades = load_oos_trades()

    if args.max_symbols:
        top_syms = trades["symbol"].value_counts().head(args.max_symbols).index
        trades = trades[trades["symbol"].isin(top_syms)]
        logger.info(f"Limited to top {args.max_symbols} symbols: {len(trades)} trades")

    enriched = enrich_trades(trades)
    if enriched.empty:
        logger.error("No trades enriched.")
        sys.exit(1)

    out_path = f"data/bb_pct_trades_{datetime.datetime.now():%Y%m%d_%H%M}.csv"
    enriched.to_csv(out_path, index=False)
    logger.info(f"Saved enriched trades to {out_path}")

    bucket_results = analyze_bb_pct(enriched)
    regression = multivariate_test(enriched)
    print_results(bucket_results, regression)


if __name__ == "__main__":
    main()
