# NIMBUS v3 — Architecture Sanity Audit

**Date:** 2026-06-18
**Scope:** structural review against the stated architecture — clean
layering, stateless engines, single source of truth, no dangling code.

## Verdict

The architecture is **largely sound**. Layering is correct at the
package level, the engines are genuinely stateless, and the domain
(`core/`) is pure.

**RESOLUTION (2026-06-18):** All five issues addressed. Issues 2/3/5
fixed by consolidating `adtv_*` and `vwap` into `compute/indicators.py`
and the `format_adtv_m` formatter into `ui/widgets/formatters.py` (calc
removed from UI). Issue 1 retired per `docs/retired/001` (~2,000 lines +
4 test files + the dead `_thin_peer_for` + the empty `analysis/`
package). Issue 4 partially done (inline imports hoisted); the CNX500
`PriceLoader`-in-UI remains as a smaller follow-up. Strategy unchanged
throughout (schema_hash 3eb7942e).

---

## What's healthy (verified, not assumed)

- **Layer boundaries hold.** UI reaches the data layer only through
  `DataManager` (the intended seam). `core/` imports nothing upward —
  the domain layer is pure, as it should be.
- **Engines are stateless.** `StrategyComputeEngine`, `RideEngine`, and
  `IndustryAnalyticsEngine` assign **no** `self.<x>` result state — they
  take inputs and return outputs. The stateless-engine design is real.
- **`body_above_band` is single-source** — defined once in
  `ride_initiation/criteria.py`, reused everywhere. This is the pattern
  the rest of the codebase should follow.
- **Directory taxonomy is coherent:** `core` (domain types), `data`
  (loaders/persistence), `compute` (stateless engines), `context`
  (composed analysis), `ui` (presentation), `research` (offline).

---

## Issue 1 — Orphaned analytics subsystem (~2,000 lines)

**Severity: high (dead weight, not a bug).**

The earlier ride-only refactor cut the app over to the ride engine +
breadth, but left a whole industry-analytics stack wired to nothing.
The running app references `IndustryAnalyticsEngine` in exactly one
place — `MainWindow._thin_peer_for` — and only to read the constant
`MIN_INDUSTRY_SIZE = 5`. None of the engine's *methods* are called from
any reachable path. The cluster, kept alive by that one constant (and
its own tests):

| Module | Lines | Reachable from app? |
|--------|-------|---------------------|
| `compute/industry_analytics.py` | 906 | constant only |
| `analysis/trend_phase.py` | 431 | only via industry_analytics |
| `context/sector_context.py` | 358 | no (only its dataclass, in comments) |
| `core/industry_relative_state.py` | 204 | `ThinPeerContext` only |
| `core/industry_state.py` | 103 | only via industry_analytics |

**Recommendation:** extract `MIN_INDUSTRY_SIZE` to a small shared
constant (e.g. `core/universe.py` or a `core/constants.py`), repoint
`_thin_peer_for` at it, then delete the orphaned modules + their tests.
**Requires explicit deletion approval** — and a decision on whether the
sector/relative-strength analytics are genuinely abandoned or planned
for re-wiring. If they may return, leave them but document the dormancy.

---

## Issue 2 — ADTV computed in 5 places, no shared helper

**Severity: medium (single-source-of-truth violation).**

`(Close * Volume).rolling/tail(20).mean()` is reimplemented in:

- `compute/ride_initiation/score.py:196`
- `compute/ride_initiation/engine.py:344`
- `compute/industry_rollup.py:111`
- `ui/widgets/dashboard_tab.py:319`  ← **in UI**
- `ui/widgets/industry_tables.py:797`  ← **in UI**

Five definitions of "average daily traded value" that must agree but
aren't enforced to. Two of them live in UI widgets (calculation in the
presentation layer — see Issue 4).

**Recommendation:** add `adtv(df, window=20)` to
`compute/indicators.py` and route all five through it. Mirrors how
`body_above_band` is handled.

---

## Issue 3 — VWAP indicator computed inside a UI widget

**Severity: medium (calculation in presentation layer).**

`ui/widgets/price_chart.py::_compute_vwap` (lines 232-249) is a full
session-reset VWAP indicator — typical-price × volume, cumulative,
per-session reset. That's an indicator calculation, and indicators
belong in `compute/indicators.py`, not a chart widget.

**Recommendation:** move `_compute_vwap` to `compute/indicators.py` as
`vwap(df)`; the chart widget calls it and only renders.

---

## Issue 4 — UI layer constructs data-layer objects directly

**Severity: low-medium (layering leak).**

`MainWindow._load_cnx500_close` (main_window.py ~383) builds a
`ParquetCache` + `PriceLoader` itself, inside the method, via inline
imports — bypassing `DataManager`, which is supposed to be the only
path from UI to the data layer. It works, but it's the UI reaching
across a layer boundary and owning data-fetch wiring it shouldn't.

**Recommendation:** move CNX500 loading behind `DataManager` (e.g. a
`request_index(symbol)` or a dedicated index-series accessor), so the
UI asks for the series rather than constructing the loader.

Related minor: a few **function-body imports** (`industry_tables.py:871`,
`main_window.py:359/383/781`) hide cross-layer dependencies. The
`TYPE_CHECKING` ones are fine; the runtime ones should move to module
top once the underlying coupling (Issues 1, 4) is resolved.

---

## Issue 5 — `_format_adtv_m` duplicated

**Severity: low (copy-pasted helper).**

Identical `_format_adtv_m` formatter in both `dashboard_tab.py:80` and
`industry_tables.py:121`. Pure presentation, so it can stay in the UI
layer — but it should be one function in a shared UI util (e.g.
`ui/widgets/_format.py` or `ui/theme.py`).

---

## Suggested order of work

1. **Issue 2 + 3** first (cheap, pure wins): add `adtv()` and `vwap()`
   to `compute/indicators.py`, route the call sites through them. No
   behaviour change, removes duplication, pulls calc out of UI.
2. **Issue 5**: dedupe the formatter (trivial).
3. **Issue 4**: route CNX500 through `DataManager`.
4. **Issue 1** last, and only with explicit sign-off: decide
   abandoned-vs-dormant on the analytics subsystem, then either delete
   (~2,000 lines + tests) or document the dormancy. This is the big
   structural cleanup but also the one needing a product decision.

None of these change the strategy (schema_hash 3eb7942e) or any
validated result (RT-001..004). They are structure-only.
