"""Tests for offline-stall prevention: connectivity probe + get_stale."""
from __future__ import annotations

import socket
from unittest.mock import patch

import pandas as pd
import pytest

from nimbus_v3.core.connectivity import is_online, _PROBE_TARGETS


def test_is_online_true_when_a_probe_connects():
    # Mock create_connection to succeed immediately.
    with patch("socket.create_connection") as m:
        m.return_value.__enter__.return_value = object()
        assert is_online() is True


def test_is_online_false_when_all_probes_fail():
    with patch("socket.create_connection", side_effect=OSError("offline")):
        assert is_online() is False


def test_is_online_tries_targets_in_order_until_success():
    calls = []

    def fake_conn(addr, timeout):
        calls.append(addr)
        if len(calls) < 2:
            raise OSError("fail first")
        # succeed on the second
        from contextlib import nullcontext
        return nullcontext(object())

    with patch("socket.create_connection", side_effect=fake_conn):
        assert is_online() is True
    assert len(calls) == 2    # stopped at first success


def test_probe_targets_nonempty():
    assert len(_PROBE_TARGETS) >= 2


def test_get_stale_returns_none_for_missing(tmp_path):
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.cache import ParquetCache
    raw = ParquetCache(base_dir=tmp_path / "raw")
    cache = EnrichedPanelCache(
        raw_cache=raw, schema_hash="x", root=tmp_path / "enr",
    )
    assert cache.get_stale("NOPE") is None


def test_get_stale_returns_entry_regardless_of_freshness(tmp_path):
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.cache import ParquetCache
    raw = ParquetCache(base_dir=tmp_path / "raw")
    cache = EnrichedPanelCache(
        raw_cache=raw, schema_hash="x", root=tmp_path / "enr",
    )
    df = pd.DataFrame({"Close": [1.0, 2.0]},
                      index=pd.date_range("2025-01-01", periods=2))
    cache.set("AAA", df)
    out = cache.get_stale("AAA")
    assert out is not None
    assert len(out) == 2
