"""nimbus_v3.data.watchlist — durable watchlist persistence.

A tiny JSON-backed store for the operator's watchlist symbols. Order is
preserved (insertion order); duplicates are ignored. Lives under
``state_dir()`` so it survives restarts and is never swept by
cache-clearing.

The store is intentionally dumb: load returns a list, save writes one.
All dedup/ordering policy lives in :class:`Watchlist`, an in-memory
ordered set that wraps load/save so the UI never touches disk directly.
"""
from __future__ import annotations

import json
import logging

from nimbus_v3.data.paths import state_dir

logger = logging.getLogger(__name__)

_WATCHLIST_FILE = "watchlist.json"


def _path():
    return state_dir(_WATCHLIST_FILE)


def load_watchlist() -> list[str]:
    """Return the persisted watchlist symbols (empty list if none)."""
    p = _path()
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text())
        if isinstance(data, list):
            return [str(s).strip().upper() for s in data if str(s).strip()]
        if isinstance(data, dict) and isinstance(data.get("symbols"), list):
            return [str(s).strip().upper()
                    for s in data["symbols"] if str(s).strip()]
    except Exception:    # noqa: BLE001
        logger.exception("could not read watchlist at %s", p)
    return []


def save_watchlist(symbols: list[str]) -> None:
    """Persist the watchlist symbols, creating the state dir if needed."""
    p = _path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"symbols": symbols}, indent=2))
    except Exception:    # noqa: BLE001
        logger.exception("could not write watchlist at %s", p)


class Watchlist:
    """In-memory ordered set of symbols, backed by JSON on disk.

    Add/remove mutate memory and persist immediately. The UI reads
    :meth:`symbols` and listens for changes via the owner re-querying
    after add/remove.
    """

    def __init__(self) -> None:
        self._symbols: list[str] = load_watchlist()

    def symbols(self) -> list[str]:
        return list(self._symbols)

    def __contains__(self, sym: str) -> bool:
        return sym.strip().upper() in self._symbols

    def add(self, sym: str) -> bool:
        """Add a symbol. Returns True if it was newly added."""
        s = sym.strip().upper()
        if not s or s in self._symbols:
            return False
        self._symbols.append(s)
        save_watchlist(self._symbols)
        return True

    def remove(self, sym: str) -> bool:
        """Remove a symbol. Returns True if it was present."""
        s = sym.strip().upper()
        if s not in self._symbols:
            return False
        self._symbols.remove(s)
        save_watchlist(self._symbols)
        return True
