"""Regression: a cache left one session behind must refetch, not be served.

The stuck-cache bug: a cache written intraday has today's forming bar
dropped by the session guard, so once that session closes the cache sits
one bar behind. Age-based freshness alone would keep serving it — during
closed hours indefinitely, and during the next open until the TTL expires —
so yesterday's completed session silently never appeared. The content-
freshness check (does the cache cover the last completed session?) forces a
refetch exactly when the cache is behind.
"""
from __future__ import annotations

from datetime import date, timedelta
from unittest.mock import patch

import pandas as pd
import pytest

from nimbus_v3.data.price_loader import PriceLoader


class _Cache:
    def __init__(self, df):
        self.d = {"SYM": df}
        self.writes = 0

    def get(self, k):
        return self.d.get(k)

    def set(self, k, df):
        self.d[k] = df
        self.writes += 1

    def age(self, k):
        return timedelta(hours=1)          # always young by TTL


def _through(last):
    idx = pd.bdate_range("2026-06-01", last)
    return pd.DataFrame(
        {"Open": 1.0, "High": 1.0, "Low": 1.0, "Close": 1.0, "Volume": 1.0},
        index=idx)


def _load(cache, *, market_open, last_session, fetch_result):
    loader = PriceLoader(cache=cache)
    with patch("nimbus_v3.data.price_loader.is_market_open",
               lambda: market_open), \
         patch("nimbus_v3.data.price_loader.last_completed_session_date",
               lambda now=None: last_session), \
         patch.object(PriceLoader, "_download_from_yfinance",
                      lambda self, s, *, years: fetch_result), \
         patch.object(PriceLoader, "_cache_deep_enough",
                      lambda self, s, c, y: True):
        return loader.load("SYM")


@pytest.mark.parametrize("market_open", [True, False])
def test_behind_cache_refetches(market_open):
    """Cache through Fri; last completed session is Mon → must refetch."""
    cache = _Cache(_through("2026-07-31"))
    fresh = _through("2026-08-03")
    out = _load(cache, market_open=market_open,
                last_session=date(2026, 8, 3), fetch_result=fresh)
    assert out.index[-1].date() == date(2026, 8, 3)
    assert cache.writes == 1


def test_current_cache_not_refetched():
    """Cache already covers the last session → served, no fetch."""
    cache = _Cache(_through("2026-08-03"))

    def _boom(self, s, *, years):
        raise AssertionError("must not fetch a current cache")

    loader = PriceLoader(cache=cache)
    with patch("nimbus_v3.data.price_loader.is_market_open", lambda: False), \
         patch("nimbus_v3.data.price_loader.last_completed_session_date",
               lambda now=None: date(2026, 8, 3)), \
         patch.object(PriceLoader, "_download_from_yfinance", _boom), \
         patch.object(PriceLoader, "_cache_deep_enough",
                      lambda self, s, c, y: True):
        out = loader.load("SYM")
    assert out.index[-1].date() == date(2026, 8, 3)
    assert cache.writes == 0


def test_coverage_helper():
    loader = PriceLoader(cache=_Cache(_through("2026-07-31")))
    with patch("nimbus_v3.data.price_loader.last_completed_session_date",
               lambda now=None: date(2026, 8, 3)):
        assert not loader._cache_covers_last_session(_through("2026-07-31"))
        assert loader._cache_covers_last_session(_through("2026-08-03"))
        assert not loader._cache_covers_last_session(pd.DataFrame())
