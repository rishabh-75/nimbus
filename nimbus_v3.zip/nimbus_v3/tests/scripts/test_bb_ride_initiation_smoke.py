"""Smoke tests for run_bb_ride_initiation_validation.py.

Strategy: build a synthetic price+indicator panel where I KNOW
exactly when a ride init event should fire, then assert the script
detects it. End-to-end tests so column name mismatches and off-by-
one errors in lookback windows are caught.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from scripts.run_bb_ride_initiation_validation import (    # noqa: E402
    _compute_ride_init_signals,
    _expand_active_window,
    ACTIVE_WINDOW,
    BBW_EXPANSION_LOOKBACK,
    CONFIRM_WINDOW,
    CROSS_LOOKBACK,
    SLOPE_ACCEL_LOOKBACK,
    SLOPE_ACCEL_THRESHOLD,
)


def _build_synthetic_panel(scenario: str, n_bars: int = 80) -> pd.DataFrame:
    """Build a synthetic enriched dataframe with the columns
    _compute_ride_init_signals expects.

    Scenarios:
      'pure_ride_init' — flat consolidation for first 60 bars,
        then sharp upward break with all conditions for definition C
        clearly true at bar 65+.
      'cross_only_no_slope' — fresh BB cross but SMA20 slope is
        flat (definition A fires, B and C don't).
      'no_cross_at_all' — price stays below upper BB throughout.
    """
    idx = pd.bdate_range("2024-01-01", periods=n_bars)
    df = pd.DataFrame(index=idx)

    if scenario == "pure_ride_init":
        # Bars 0-60: PERFECTLY flat consolidation at price=100, so
        # there are no stray noise crosses contaminating the
        # fresh-cross check. We're testing the pipeline detects a
        # known event, not testing noise robustness.
        # Bars 60+: clear gap-up break + STEEP sustained ramp so
        # the SMA20 slope acceleration clearly clears 0.3 threshold.
        close = np.zeros(n_bars)
        close[:60] = 100.0                            # perfectly flat
        close[60] = 102.5                             # clear break above upper
        close[61:] = 102.5 + 4.0 * np.arange(n_bars - 61)
        df["Close"] = close

        # BB upper roughly 102 in consolidation, expanding once price ramps
        # Mid = 20-bar SMA, upper = mid + 1*std
        df["sma_20"] = pd.Series(close, index=idx).rolling(20, min_periods=20).mean()
        std = pd.Series(close, index=idx).rolling(20, min_periods=20).std()
        df["bb_20_1s_mid"] = df["sma_20"]
        df["bb_20_1s_upper"] = df["bb_20_1s_mid"] + std
        df["bb_20_1s_lower"] = df["bb_20_1s_mid"] - std
        df["bbw_20_1s"] = (
            (df["bb_20_1s_upper"] - df["bb_20_1s_lower"])
            / df["bb_20_1s_mid"] * 100
        )

    elif scenario == "cross_only_no_slope":
        # Sideways grind that finally pokes above the upper BB but
        # without slope acceleration
        rng = np.random.default_rng(2)
        close = 100 + rng.normal(0, 1.2, n_bars)
        # Force a single cross event late
        close[70:73] = [104, 105, 105]    # just above ~102 BB upper
        df["Close"] = close
        df["sma_20"] = pd.Series(close, index=idx).rolling(20, min_periods=20).mean()
        std = pd.Series(close, index=idx).rolling(20, min_periods=20).std()
        df["bb_20_1s_mid"] = df["sma_20"]
        df["bb_20_1s_upper"] = df["bb_20_1s_mid"] + std
        df["bb_20_1s_lower"] = df["bb_20_1s_mid"] - std
        df["bbw_20_1s"] = (
            (df["bb_20_1s_upper"] - df["bb_20_1s_lower"])
            / df["bb_20_1s_mid"] * 100
        )

    elif scenario == "no_cross_at_all":
        rng = np.random.default_rng(3)
        close = 100 + rng.normal(0, 1.0, n_bars)
        df["Close"] = close
        df["sma_20"] = pd.Series(close, index=idx).rolling(20, min_periods=20).mean()
        std = pd.Series(close, index=idx).rolling(20, min_periods=20).std()
        df["bb_20_1s_mid"] = df["sma_20"]
        df["bb_20_1s_upper"] = df["bb_20_1s_mid"] + std
        df["bb_20_1s_lower"] = df["bb_20_1s_mid"] - std
        df["bbw_20_1s"] = (
            (df["bb_20_1s_upper"] - df["bb_20_1s_lower"])
            / df["bb_20_1s_mid"] * 100
        )

    return df


# ══════════════════════════════════════════════════════════════════════
# End-to-end signal detection
# ══════════════════════════════════════════════════════════════════════

class TestRideInitDetection:

    def test_pure_ride_init_fires_definition_c(self):
        """A clear ride-init pattern (flat then sharp ramp, BBW
        expanding) should fire definition C at some point in the
        ramp window."""
        df = _build_synthetic_panel("pure_ride_init", n_bars=100)
        result = _compute_ride_init_signals(df)
        # Definition C should fire at least once in the ramp window
        # (bars 60-99). If not, the script's pipeline is broken.
        ramp_window = result.iloc[60:]
        assert ramp_window["ride_init_c"].any(), (
            "Definition C never fired on a clean ride-init scenario. "
            "Pipeline is broken — check column names, lookback windows, "
            "or threshold tuning."
        )

    def test_pure_ride_init_nested_definitions_consistent(self):
        """Under the new lagged semantics: when C fires at bar T,
        A must have fired within the last CONFIRM_WINDOW bars
        ending at T (inclusive). Same for B."""
        df = _build_synthetic_panel("pure_ride_init", n_bars=100)
        result = _compute_ride_init_signals(df)
        c_fires = result["ride_init_c"]
        if not c_fires.any():
            return    # other test catches non-firing case
        # Compute "A fired in last CONFIRM_WINDOW bars" series
        a_recent = (
            result["ride_init_a"].astype(int)
            .rolling(CONFIRM_WINDOW, min_periods=1)
            .sum() > 0
        )
        # Every C-firing bar must also have a_recent == True
        assert (a_recent[c_fires]).all(), (
            "C fired without A firing in the last CONFIRM_WINDOW bars."
        )
        # Same for B
        b_fires = result["ride_init_b"]
        if b_fires.any():
            assert (a_recent[b_fires]).all(), (
                "B fired without A firing in the last CONFIRM_WINDOW bars."
            )

    def test_no_cross_scenario_never_fires(self):
        """Price never crosses upper BB → no definition should fire."""
        df = _build_synthetic_panel("no_cross_at_all", n_bars=100)
        result = _compute_ride_init_signals(df)
        for d in ("a", "b", "c"):
            col = f"ride_init_{d}"
            assert not result[col].any(), (
                f"Definition {d.upper()} fired when price never "
                f"crossed upper BB. Cross detection is broken."
            )

    def test_missing_columns_returns_all_false(self):
        """If the input dataframe lacks required columns, signals
        should be all-False (graceful degradation), not crash."""
        df = pd.DataFrame({
            "Close": [100, 101, 102],
        }, index=pd.bdate_range("2024-01-01", periods=3))
        result = _compute_ride_init_signals(df)
        for d in ("a", "b", "c"):
            col = f"ride_init_{d}"
            assert col in result.columns
            assert not result[col].any()


# ══════════════════════════════════════════════════════════════════════
# Active window expansion
# ══════════════════════════════════════════════════════════════════════

class TestActiveWindow:

    def test_active_window_extends_signal_forward(self):
        """If signal fires at bar 10, active window should be True
        for bars 10..14 (with ACTIVE_WINDOW=5)."""
        idx = pd.bdate_range("2024-01-01", periods=20)
        signal = pd.Series([False] * 20, index=idx)
        signal.iloc[10] = True
        active = _expand_active_window(signal, window=5)
        # Bars 10, 11, 12, 13, 14 should be active
        assert active.iloc[10]
        assert active.iloc[11]
        assert active.iloc[12]
        assert active.iloc[13]
        assert active.iloc[14]
        # Bar 15 should NOT be active anymore
        assert not active.iloc[15]
        # Bar 9 (before the signal) should not be active
        assert not active.iloc[9]

    def test_active_window_handles_no_fires(self):
        """All-False signal → all-False active."""
        idx = pd.bdate_range("2024-01-01", periods=20)
        signal = pd.Series([False] * 20, index=idx)
        active = _expand_active_window(signal, window=5)
        assert not active.any()

    def test_active_window_overlapping_fires(self):
        """Two close fires → active stays True throughout the
        union of the two windows."""
        idx = pd.bdate_range("2024-01-01", periods=20)
        signal = pd.Series([False] * 20, index=idx)
        signal.iloc[5] = True
        signal.iloc[7] = True
        active = _expand_active_window(signal, window=5)
        # Bars 5..11 should be active (5..9 from first, 7..11 from second)
        for i in range(5, 12):
            assert active.iloc[i], f"Bar {i} should be active"
