"""nimbus_v3.ui.widgets.watchlist_panel — TradingView-style side watchlist.

A slim, collapsible watchlist that lives to the RIGHT of the Dashboard
chart (rather than in a tab of its own). Three columns only —
``Symbol | Chg | Vol`` — because the panel's job is at-a-glance monitoring
while you look at a chart, not analysis. Anything deeper belongs in the
Constituents table or the Edge tab.

Behaviours carried over from the old Watchlist tab:
  * double-click a row  → load that symbol into the Dashboard
  * checkbox per row + "delete selected"

Pure display: the widget renders whatever symbols it is handed and emits
signals. Persistence stays in :mod:`nimbus_v3.data.watchlist`, and the
add/remove decisions stay in MainWindow — this widget owns no state beyond
what it is currently showing.
"""
from __future__ import annotations

import pandas as pd
from PyQt6.QtCore import QEvent, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.constituent_features import (
    extract_constituent_features,
)
from nimbus_v3.ui.theme import (
    BORDER, EM, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED, S2, WHITE,
)

#: Panel width when expanded. Wide enough for a long NSE ticker plus two
#: numeric columns, narrow enough that it doesn't eat the chart.
PANEL_WIDTH = 252

_COLS = ("Symbol", "Chg", "Vol")


class _NumItem(QTableWidgetItem):
    """Sorts on a stored numeric value rather than display text."""

    def __lt__(self, other: QTableWidgetItem) -> bool:
        a = self.data(Qt.ItemDataRole.UserRole)
        b = other.data(Qt.ItemDataRole.UserRole)
        try:
            af, bf = float(a), float(b)
        except (TypeError, ValueError):
            return super().__lt__(other)
        if af != af:            # NaN sinks
            return True
        if bf != bf:
            return False
        return af < bf


class WatchlistPanel(QWidget):
    """Collapsible watchlist strip for the right edge of the chart."""

    #: Double-clicked a row → load this symbol on the Dashboard.
    symbol_activated = pyqtSignal(str)
    #: "Delete selected" → these symbols should be dropped.
    remove_requested = pyqtSignal(list)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

        # No spine / handle of its own: the panel is driven by the
        # WATCHLIST button in the chart toolbar. An always-visible edge
        # sliver was tried and was effectively invisible against the dark
        # theme — a labelled button in the toolbar is discoverable, this was
        # not.
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._body = QWidget()
        self._body.setFixedWidth(PANEL_WIDTH)
        body = QVBoxLayout(self._body)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        self._title = QLabel("WATCHLIST")
        self._title.setFont(QFont(FONT_UI, 8, QFont.Weight.Bold))
        self._title.setStyleSheet(
            f"color: {MUTED}; background: {S2}; padding: 5px 8px; "
            f"border-bottom: 1px solid {BORDER}; letter-spacing: 1px;"
        )
        body.addWidget(self._title)

        self._table = QTableWidget(0, len(_COLS))
        self._table.setHorizontalHeaderLabels(list(_COLS))
        self._table.verticalHeader().setVisible(False)
        self._table.setShowGrid(False)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        # Styled to match the Edge / Constituents tables — same header
        # treatment, same padding, same selection colour. The checkbox
        # indicator is explicitly sized and coloured; Qt's default renders
        # as an oversized pale block that dominates the row.
        self._table.setStyleSheet(
            f"QTableWidget {{ background: transparent; border: none; "
            f"gridline-color: {BORDER}; color: {WHITE}; }}"
            f"QHeaderView::section {{ background: {S2}; color: {MUTED}; "
            f"border: none; border-bottom: 1px solid {BORDER}; "
            f"padding: 6px 5px; font-weight: bold; }}"
            f"QTableWidget::item {{ padding: 5px 5px; }}"
            f"QTableWidget::item:selected {{ background: {BORDER}; "
            f"color: {WHITE}; }}"
            f"QTableWidget::indicator {{ width: 11px; height: 11px; "
            f"border: 1px solid {MUTED}; border-radius: 2px; "
            f"background: transparent; }}"
            f"QTableWidget::indicator:checked {{ background: {EM}; "
            f"border-color: {EM}; }}"
        )
        # Compact rows, matching the density of the Constituents table.
        vh = self._table.verticalHeader()
        vh.setVisible(False)
        vh.setDefaultSectionSize(26)
        hh = self._table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        # Sized to the widest real content, not guessed: Chg holds
        # "-12.34" and Vol holds "3.01x". They were 58/52, which clipped
        # both to an ellipsis.
        self._table.setColumnWidth(1, 62)
        self._table.setColumnWidth(2, 60)
        self._table.cellDoubleClicked.connect(self._on_double_click)
        body.addWidget(self._table, stretch=1)

        root.addWidget(self._body)

        # ── Hover-delete (TradingView-style) ─────────────────────────────
        # A small ✕ that follows the mouse down the rows, replacing the
        # checkbox column + "DELETE SELECTED" footer. Two wins: it removes a
        # whole column of chrome from a 250px panel (which is what was
        # squeezing Symbol and Vol into ellipses), and it puts the action on
        # the row it acts on rather than making the operator check a box,
        # look away to a footer, and click.
        self._del_btn = QPushButton("\u2715", self._table.viewport())
        self._del_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._del_btn.setFixedSize(18, 18)
        self._del_btn.setToolTip("Remove from watchlist")
        self._del_btn.setStyleSheet(
            f"QPushButton {{ background: {S2}; color: {MUTED}; "
            f"border: 1px solid {BORDER}; border-radius: 3px; "
            f"font-family: '{FONT_MONO}'; font-size: 8pt; }}"
            f"QPushButton:hover {{ color: {RED}; border-color: {RED}; }}"
        )
        self._del_btn.clicked.connect(self._on_hover_delete)
        self._del_btn.hide()
        self._hover_row = -1

        self._table.setMouseTracking(True)
        self._table.viewport().setMouseTracking(True)
        self._table.viewport().installEventFilter(self)

        self._symbols: list[str] = []

        # Collapsed by default — the chart is the primary surface; the
        # watchlist is opened when wanted. Width goes to 0 as well as
        # hidden, or the collapsed panel would still reserve its 220px.
        self._collapsed = True
        self._body.setVisible(False)
        self._body.setFixedWidth(0)

    # ── public API ───────────────────────────────────────────────────────

    def set_data(
        self,
        symbols: list[str],
        panel: dict[str, pd.DataFrame] | None,
    ) -> None:
        """Render ``symbols`` from the enriched ``panel``.

        Reuses the SHARED constituent-feature extractor, so a symbol's Chg
        and Vol read identically here, in the Dashboard tables, and on the
        Edge tab. No parallel computation.
        """
        self._symbols = list(symbols)
        self._title.setText(
            f"WATCHLIST \u00b7 {len(symbols)}" if symbols else "WATCHLIST")

        # NO auto-sorting. A watchlist is a CURATED list — the operator
        # chose that order, and re-sorting it on render would scramble their
        # arrangement (and make "row 0" mean something different from what
        # was inserted). Ranked views live in the Edge tab; this is not one.
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(symbols))
        for r, sym in enumerate(symbols):
            df = (panel or {}).get(sym)
            feats = extract_constituent_features(sym, df) if df is not None \
                else None
            chg = feats.chg_1d if feats else float("nan")
            vol = feats.vol_ratio if feats else float("nan")

            s_it = QTableWidgetItem(sym)
            s_it.setForeground(QColor(WHITE))
            self._table.setItem(r, 0, s_it)

            # Chg: positive green / negative red / missing muted — the same
            # rule the Constituents table uses, no dead-zone.
            c_it = _NumItem("\u2014" if chg != chg else f"{chg:+.2f}")
            c_it.setData(Qt.ItemDataRole.UserRole,
                         chg if chg == chg else float("-inf"))
            c_it.setForeground(QColor(
                MUTED if chg != chg else (GREEN if chg >= 0 else RED)))
            c_it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self._table.setItem(r, 1, c_it)

            # Vol: >=1.5x mean = unusual participation, flag GOLD;
            # <=0.5x = volume drought, flag RED. Same thresholds as the
            # Constituents table. (The first cut only had the gold rule, so
            # every quiet row rendered flat grey — which is what made the
            # panel look bleak.)
            v_it = _NumItem("\u2014" if vol != vol else f"{vol:.2f}x")
            v_it.setData(Qt.ItemDataRole.UserRole,
                         vol if vol == vol else float("-inf"))
            if vol != vol:
                v_col = MUTED
            elif vol >= 1.5:
                v_col = GOLD
            elif vol <= 0.5:
                v_col = RED
            else:
                v_col = WHITE
            v_it.setForeground(QColor(v_col))
            v_it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self._table.setItem(r, 2, v_it)

    @property
    def collapsed(self) -> bool:
        return self._collapsed

    def set_expanded(self, expanded: bool) -> None:
        """Show / hide the panel. Driven by the chart toolbar's WATCHLIST
        button, which is the only affordance — the panel has no handle of
        its own.

        The body's fixed width is dropped to 0 on collapse, not merely
        hidden: a hidden-but-fixed-width widget still RESERVES its space in
        the parent layout, so the 'collapsed' panel would go on eating
        220px of chart.

        Order matters. The width is set BEFORE the visibility change and the
        layout is then explicitly re-activated — setting the width on an
        already-hidden widget leaves the parent layout holding a stale
        size-hint, and the panel refuses to shrink back.
        """
        collapsed = not bool(expanded)
        if collapsed == self._collapsed:
            return
        self._collapsed = collapsed
        self._body.setFixedWidth(0 if collapsed else PANEL_WIDTH)
        self._body.setVisible(not collapsed)
        self.updateGeometry()
        lay = self.layout()
        if lay is not None:
            lay.activate()
        parent = self.parentWidget()
        if parent is not None and parent.layout() is not None:
            parent.layout().activate()

    def toggle(self) -> None:
        """Flip the panel open/closed."""
        self.set_expanded(self._collapsed)

    # ── internals ────────────────────────────────────────────────────────

    # ── hover-delete ─────────────────────────────────────────────────────

    def eventFilter(self, obj, event):    # noqa: N802
        """Track the mouse over the table so the ✕ can follow it.

        An event filter on the VIEWPORT (not the table) because that is the
        widget that actually receives the mouse moves; installing it on the
        table alone yields nothing.
        """
        if obj is self._table.viewport():
            if event.type() == QEvent.Type.MouseMove:
                self._place_delete_button(event.position().toPoint())
            elif event.type() == QEvent.Type.Leave:
                self._del_btn.hide()
                self._hover_row = -1
        return super().eventFilter(obj, event)

    def _place_delete_button(self, pos) -> None:
        row = self._table.rowAt(pos.y())
        if row < 0 or self._table.item(row, 0) is None:
            self._del_btn.hide()
            self._hover_row = -1
            return
        self._hover_row = row
        rect = self._table.visualItemRect(self._table.item(row, 0))
        # Park it at the RIGHT edge of the row, clear of the numbers.
        x = self._table.viewport().width() - self._del_btn.width() - 4
        y = rect.y() + (rect.height() - self._del_btn.height()) // 2
        self._del_btn.move(x, y)
        self._del_btn.show()
        self._del_btn.raise_()

    def _on_hover_delete(self) -> None:
        if self._hover_row < 0:
            return
        it = self._table.item(self._hover_row, 0)
        if it is not None and it.text():
            self.remove_requested.emit([it.text()])
        self._del_btn.hide()
        self._hover_row = -1

    def _on_double_click(self, row: int, _col: int) -> None:
        it = self._table.item(row, 0)
        if it is not None and it.text():
            self.symbol_activated.emit(it.text())
