#!/usr/bin/env python3
"""
scripts/run_etf_bb_ride_backtest.py — BB Ride Momentum Backtest on ETFs

Tests whether the BB upper band ride strategy (validated on equities: Sh 0.88,
48% win, trail 3×ATR) works on NSE ETFs.

Key differences vs equities:
  - ETFs have lower volatility → tighter BB bands → fewer 1σ touches?
  - ETF volume is institutional → different volume profiles
  - No sector rotation but ETFs ARE sectors (BANKBEES = banking, ITBEES = IT)
  - Tracking error may cause false touches

Tests:
  1. Does BB(1σ) trigger enough entries on ETFs? If not, test 0.75σ and 0.5σ
  2. Which exit rule works best? (mid_break, trail 2×ATR, trail 3×ATR, SMA break)
  3. VIX segmentation (does ELEVATED/PANIC boost ETF rides like equities?)
  4. ETF-type segmentation (sectoral vs broad vs commodity)
  5. Factor study: which entry conditions predict good ETF rides?

Usage:
    python3 scripts/run_etf_bb_ride_backtest.py
    python3 scripts/run_etf_bb_ride_backtest.py --years 5 --sweep
"""
import argparse, logging, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()
import numpy as np, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("etf_bb_ride")

# ══════════════════════════════════════════════════════════════════════════════
# ETF UNIVERSE
# ══════════════════════════════════════════════════════════════════════════════

_ETF_UNIVERSE = [
    # Broad market
    "NIFTYBEES", "JUNIORBEES", "NV20IETF", "N100",
    # Sectoral — Cyclical
    "BANKBEES", "PSUBNKBEES", "FINIETF",
    "AUTOIETF", "INFRABEES", "CPSEETF",
    "METALIETF", "OILIETF", "COMMOIETF",
    # Sectoral — Defensive
    "ITBEES", "PHARMABEES", "FMCGIETF", "HEALTHIETF",
    # Thematic
    "MOM100", "MIDCAPIETF",
    # Commodity
    "GOLDBEES", "SILVERBEES",
]

_ETF_TYPE = {
    "NIFTYBEES": "BROAD", "JUNIORBEES": "BROAD", "NV20IETF": "BROAD", "N100": "BROAD",
    "BANKBEES": "CYCLICAL", "PSUBNKBEES": "CYCLICAL", "FINIETF": "CYCLICAL",
    "AUTOIETF": "CYCLICAL", "INFRABEES": "CYCLICAL", "CPSEETF": "CYCLICAL",
    "METALIETF": "CYCLICAL", "OILIETF": "CYCLICAL", "COMMOIETF": "CYCLICAL",
    "ITBEES": "DEFENSIVE", "PHARMABEES": "DEFENSIVE", "FMCGIETF": "DEFENSIVE",
    "HEALTHIETF": "DEFENSIVE",
    "MOM100": "THEMATIC", "MIDCAPIETF": "THEMATIC",
    "GOLDBEES": "COMMODITY", "SILVERBEES": "COMMODITY",
}


def fetch_daily(symbol, years=5):
    import yfinance as yf
    try:
        ticker = symbol if symbol.startswith("^") else f"{symbol}.NS"
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", symbol, exc)
        return pd.DataFrame()


def fetch_vix(years=5):
    df = fetch_daily("^INDIAVIX", years)
    if not df.empty and "Close" in df.columns:
        return df["Close"].dropna()
    return None


# ══════════════════════════════════════════════════════════════════════════════
# INDICATORS
# ══════════════════════════════════════════════════════════════════════════════

def compute_indicators(df, bb_period=20, bb_std=1.0):
    c = df["Close"]; h = df["High"]; l = df["Low"]
    v = df["Volume"] if "Volume" in df.columns else pd.Series(0, index=df.index)
    d = df.copy()

    mid = c.rolling(bb_period).mean()
    std = c.rolling(bb_period).std()
    d["BB_Mid"] = mid
    d["BB_Upper"] = mid + bb_std * std
    d["BB_Lower"] = mid - bb_std * std
    band = (d["BB_Upper"] - d["BB_Lower"]).replace(0, np.nan)
    d["BB_Pct"] = (c - d["BB_Lower"]) / band
    d["BBW"] = band / mid.replace(0, np.nan) * 100
    d["BBW_slope"] = d["BBW"].diff(5)

    d["SMA_10"] = c.rolling(10).mean()
    d["SMA_20"] = mid
    d["SMA_50"] = c.rolling(50, min_periods=30).mean()

    tr = pd.concat([h-l, (h-c.shift(1)).abs(), (l-c.shift(1)).abs()], axis=1).max(axis=1)
    d["ATR"] = tr.rolling(14).mean()

    vol_avg = v.rolling(20).mean().replace(0, np.nan)
    d["VOL_RATIO"] = v / vol_avg

    delta = c.diff()
    gain = delta.clip(lower=0); loss = -delta.clip(upper=0)
    with np.errstate(divide='ignore', invalid='ignore'):
        rs = np.where(loss.rolling(14).mean() > 0,
                      gain.rolling(14).mean() / loss.rolling(14).mean(), 0)
        d["RSI"] = 100 - (100 / (1 + rs))

    tp = (h+l+c)/3; mf = tp*v
    pmf = pd.Series(np.where(tp>tp.shift(1), mf, 0), index=df.index)
    nmf = pd.Series(np.where(tp<tp.shift(1), mf, 0), index=df.index)
    with np.errstate(divide='ignore', invalid='ignore'):
        mfr = np.where(nmf.rolling(14).sum() > 0,
                       pmf.rolling(14).sum() / nmf.rolling(14).sum(), 0)
        d["MFI"] = 100 - (100 / (1 + mfr))

    up = h.diff(); dn = -l.diff()
    pdm = pd.Series(np.where((up>dn)&(up>0), up, 0), index=df.index)
    mdm = pd.Series(np.where((dn>up)&(dn>0), dn, 0), index=df.index)
    pdi = 100 * pdm.rolling(14).mean() / d["ATR"].replace(0, np.nan)
    mdi = 100 * mdm.rolling(14).mean() / d["ATR"].replace(0, np.nan)
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    d["ADX"] = dx.rolling(14).mean()
    d["ROC_10"] = c.pct_change(10) * 100

    return d


# ══════════════════════════════════════════════════════════════════════════════
# TRADE SIMULATION
# ══════════════════════════════════════════════════════════════════════════════

def simulate_trades(df, symbol, vix_series=None, params=None):
    if params is None:
        params = {}

    bb_period = params.get("bb_period", 20)
    bb_std = params.get("bb_std", 1.0)
    min_vol = params.get("min_vol", 0.0)
    exit_rule = params.get("exit_rule", "mid_break")
    trailing_atr = params.get("trailing_atr", 2.0)
    profit_target = params.get("profit_target", 10.0)
    max_hold = params.get("max_hold", 30)
    stop_loss = params.get("stop_loss", -5.0)

    d = compute_indicators(df, bb_period, bb_std)
    c = d["Close"].values.astype(float)
    upper = d["BB_Upper"].values.astype(float)
    mid = d["BB_Mid"].values.astype(float)
    sma50 = d["SMA_50"].values.astype(float)
    atr = d["ATR"].values.astype(float)
    vol_ratio = d["VOL_RATIO"].values.astype(float)
    pctb = d["BB_Pct"].values.astype(float)
    adx = d["ADX"].values.astype(float)
    mfi = d["MFI"].values.astype(float)
    rsi = d["RSI"].values.astype(float)
    bbw = d["BBW"].values.astype(float)
    bbw_slope = d["BBW_slope"].values.astype(float)
    roc = d["ROC_10"].values.astype(float)
    dates = d.index

    trades = []
    was_below = True
    in_trade = False
    cooldown = 0

    for i in range(bb_period + 15, len(c) - 1):
        if np.isnan(upper[i]) or np.isnan(mid[i]):
            continue
        if cooldown > 0:
            cooldown -= 1; continue

        at_upper = c[i] >= upper[i]

        if in_trade:
            pnl = (c[i] / entry_price - 1) * 100
            bars_held = i - entry_bar
            exited = False; exit_reason = ""

            if pnl >= profit_target:
                exited = True; exit_reason = "PT"
            elif pnl <= stop_loss:
                exited = True; exit_reason = "SL"
            elif bars_held >= max_hold:
                exited = True; exit_reason = "MAX_HOLD"
            elif exit_rule == "mid_break" and c[i] < mid[i]:
                exited = True; exit_reason = "MID_BREAK"
            elif exit_rule == "upper_break" and c[i] < upper[i]:
                exited = True; exit_reason = "UPPER_BREAK"
            elif exit_rule == "trailing":
                peak = max(c[entry_bar:i+1])
                trail_stop = peak - trailing_atr * atr[i]
                if c[i] < trail_stop:
                    exited = True; exit_reason = "TRAIL_STOP"
            elif exit_rule == "sma10_break":
                sma10 = d["SMA_10"].values[i]
                if not np.isnan(sma10) and c[i] < sma10:
                    exited = True; exit_reason = "SMA10_BREAK"

            if exited:
                exit_price = c[i]
                final_pnl = (exit_price / entry_price - 1) * 100
                peak_price = max(c[entry_bar:i+1])
                max_gain = (peak_price / entry_price - 1) * 100

                entry_vix = None
                if vix_series is not None:
                    vix_idx = vix_series.index.get_indexer([dates[entry_bar]], method="ffill")
                    if vix_idx[0] >= 0:
                        entry_vix = float(vix_series.iloc[vix_idx[0]])

                etf_type = _ETF_TYPE.get(symbol, "UNKNOWN")

                trades.append({
                    "symbol": symbol,
                    "entry_date": str(dates[entry_bar].date()),
                    "exit_date": str(dates[i].date()),
                    "entry_price": round(entry_price, 2),
                    "exit_price": round(exit_price, 2),
                    "pnl_pct": round(final_pnl, 3),
                    "max_gain": round(max_gain, 2),
                    "bars_held": bars_held,
                    "exit_reason": exit_reason,
                    "win": final_pnl > 0,
                    "entry_pctb": round(float(pctb[entry_bar]), 3) if not np.isnan(pctb[entry_bar]) else 1.0,
                    "entry_vol": round(float(vol_ratio[entry_bar]), 2) if not np.isnan(vol_ratio[entry_bar]) else 1.0,
                    "entry_mfi": round(float(mfi[entry_bar]), 1) if not np.isnan(mfi[entry_bar]) else 50,
                    "entry_rsi": round(float(rsi[entry_bar]), 1) if not np.isnan(rsi[entry_bar]) else 50,
                    "entry_adx": round(float(adx[entry_bar]), 1) if not np.isnan(adx[entry_bar]) else 20,
                    "entry_bbw": round(float(bbw[entry_bar]), 2) if not np.isnan(bbw[entry_bar]) else 5,
                    "entry_roc": round(float(roc[entry_bar]), 1) if not np.isnan(roc[entry_bar]) else 0,
                    "vix": round(entry_vix, 1) if entry_vix else None,
                    "vix_regime": _vix_regime(entry_vix),
                    "etf_type": etf_type,
                })

                in_trade = False
                was_below = c[i] < upper[i]
                cooldown = 2
                continue

        if not in_trade and was_below and at_upper:
            if vol_ratio[i] < min_vol:
                was_below = False; continue
            entry_price = c[i]; entry_bar = i
            in_trade = True; was_below = False
        elif not at_upper:
            was_below = True

    return trades


def _vix_regime(v):
    if v is None: return "UNKNOWN"
    if v > 22: return "PANIC"
    if v >= 18: return "ELEVATED"
    if v >= 13: return "NORMAL"
    return "LOW"


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def sharpe(returns):
    if len(returns) < 2: return 0
    m = np.mean(returns); s = np.std(returns, ddof=1)
    return (m / s * np.sqrt(252)) if s > 0 else 0


def summarize(trades, label=""):
    if not trades:
        print(f"  {label}: NO TRADES")
        return
    df = pd.DataFrame(trades)
    n = len(df)
    wins = df["win"].sum()
    wr = wins / n * 100
    avg = df["pnl_pct"].mean()
    med = df["pnl_pct"].median()
    sh = sharpe(df["pnl_pct"].values)
    avg_bars = df["bars_held"].mean()
    total_ret = df["pnl_pct"].sum()
    pf = df.loc[df["pnl_pct"]>0, "pnl_pct"].sum() / max(abs(df.loc[df["pnl_pct"]<0, "pnl_pct"].sum()), 0.01)
    print(f"  {label}: N={n:,}  Win={wr:.1f}%  Avg={avg:+.2f}%  Med={med:+.2f}%  "
          f"Sh={sh:.2f}  PF={pf:.2f}  Bars={avg_bars:.0f}  Total={total_ret:+.1f}%")
    return {"label": label, "n": n, "win_rate": wr, "avg": avg, "sharpe": sh, "pf": pf}


def factor_correlation(trades, label):
    """Correlate entry factors with forward returns."""
    df = pd.DataFrame(trades)
    if len(df) < 20:
        print(f"\n  {label}: too few trades for factor study")
        return
    factors = ["entry_vol", "entry_mfi", "entry_rsi", "entry_adx", "entry_bbw", "entry_roc", "entry_pctb"]
    print(f"\n  {label} Factor correlations (r vs pnl_pct):")
    for f in factors:
        if f in df.columns:
            valid = df[[f, "pnl_pct"]].dropna()
            if len(valid) > 10:
                r = valid[f].corr(valid["pnl_pct"])
                print(f"    {f:18s}  r={r:+.3f}  {'✓ VALID' if abs(r) > 0.03 else '✗ noise'}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="ETF BB Ride Backtest")
    parser.add_argument("--years", type=int, default=5)
    parser.add_argument("--sweep", action="store_true")
    args = parser.parse_args()

    print(f"\n{'='*72}")
    print(f"  ETF BB RIDE BACKTEST — {len(_ETF_UNIVERSE)} ETFs, {args.years}yr")
    print(f"{'='*72}")

    # ── Fetch data ────────────────────────────────────────────────
    print("\n[1/8] Fetching VIX...")
    vix_series = fetch_vix(args.years)
    print(f"  VIX: {len(vix_series)} bars" if vix_series is not None else "  VIX: unavailable")

    print(f"\n[2/8] Fetching {len(_ETF_UNIVERSE)} ETFs...")
    price_data = {}
    for sym in _ETF_UNIVERSE:
        df = fetch_daily(sym, args.years)
        if not df.empty and len(df) > 100:
            price_data[sym] = df
            logger.info("  %s: %d bars", sym, len(df))
        else:
            logger.warning("  %s: skipped (too short)", sym)
    print(f"  Loaded: {len(price_data)} ETFs with sufficient data")

    # ══════════════════════════════════════════════════════════════
    # SECTION 1: Entry frequency — does BB(1σ) even trigger?
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print("  [3/8] ENTRY FREQUENCY — BB std comparison")
    print(f"{'='*72}")

    for bb_std in [0.5, 0.75, 1.0, 1.5, 2.0]:
        total_entries = 0
        total_bars = 0
        for sym, df in price_data.items():
            d = compute_indicators(df, bb_period=20, bb_std=bb_std)
            c = d["Close"].values
            upper = d["BB_Upper"].values
            was_below = True
            for i in range(35, len(c)):
                if np.isnan(upper[i]): continue
                at_upper = c[i] >= upper[i]
                if was_below and at_upper:
                    total_entries += 1
                    was_below = False
                elif not at_upper:
                    was_below = True
            total_bars += len(c) - 35
        freq = total_entries / (total_bars / 252) if total_bars > 0 else 0
        print(f"  BB({bb_std:.1f}σ): {total_entries:,} entries across {len(price_data)} ETFs "
              f"({freq:.0f}/yr, {total_entries/max(len(price_data),1):.1f}/ETF)")

    # ══════════════════════════════════════════════════════════════
    # SECTION 2: Default backtest — BB(1σ) mid-break exit
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print("  [4/8] DEFAULT BACKTEST — BB(1σ), mid-break exit")
    print(f"{'='*72}")

    all_trades = []
    for sym, df in price_data.items():
        trades = simulate_trades(df, sym, vix_series=vix_series)
        all_trades.extend(trades)
    summarize(all_trades, "BB(1σ) DEFAULT")

    # Per-ETF breakdown
    print("\n  Per-ETF:")
    for sym in sorted(price_data.keys()):
        sym_trades = [t for t in all_trades if t["symbol"] == sym]
        if sym_trades:
            wr = sum(1 for t in sym_trades if t["win"]) / len(sym_trades) * 100
            avg = np.mean([t["pnl_pct"] for t in sym_trades])
            print(f"    {sym:18s}  N={len(sym_trades):3d}  Win={wr:5.1f}%  Avg={avg:+.2f}%")

    # ══════════════════════════════════════════════════════════════
    # SECTION 3: BB std comparison (full backtest per std)
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print("  [5/8] BB STD COMPARISON — full backtest per σ")
    print(f"{'='*72}")

    best_std = None
    best_sharpe = -99
    for bb_std in [0.5, 0.75, 1.0, 1.5]:
        trades_std = []
        for sym, df in price_data.items():
            p = {"bb_std": bb_std, "exit_rule": "mid_break", "profit_target": 10, "stop_loss": -5, "max_hold": 30}
            trades_std.extend(simulate_trades(df, sym, vix_series=vix_series, params=p))
        result = summarize(trades_std, f"BB({bb_std}σ)")
        if result and result["sharpe"] > best_sharpe:
            best_sharpe = result["sharpe"]
            best_std = bb_std

    print(f"\n  → Best σ: {best_std} (Sh {best_sharpe:.2f})")

    # ══════════════════════════════════════════════════════════════
    # SECTION 4: Exit rule comparison
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [6/8] EXIT RULE COMPARISON — using BB({best_std}σ)")
    print(f"{'='*72}")

    exit_configs = [
        ("mid_break", {"exit_rule": "mid_break"}),
        ("upper_break", {"exit_rule": "upper_break"}),
        ("trail_2xATR", {"exit_rule": "trailing", "trailing_atr": 2.0}),
        ("trail_3xATR", {"exit_rule": "trailing", "trailing_atr": 3.0}),
        ("sma10_break", {"exit_rule": "sma10_break"}),
        ("PT5_SL3", {"exit_rule": "trailing", "trailing_atr": 2.0, "profit_target": 5, "stop_loss": -3}),
        ("PT10_SL5", {"exit_rule": "trailing", "trailing_atr": 3.0, "profit_target": 10, "stop_loss": -5}),
        ("PT8_SL4", {"exit_rule": "trailing", "trailing_atr": 2.5, "profit_target": 8, "stop_loss": -4}),
    ]

    best_exit = None
    best_exit_sh = -99
    for name, overrides in exit_configs:
        p = {"bb_std": best_std, "profit_target": 10, "stop_loss": -5, "max_hold": 30}
        p.update(overrides)
        trades_exit = []
        for sym, df in price_data.items():
            trades_exit.extend(simulate_trades(df, sym, vix_series=vix_series, params=p))
        result = summarize(trades_exit, name)
        if result and result["sharpe"] > best_exit_sh:
            best_exit_sh = result["sharpe"]
            best_exit = name

    print(f"\n  → Best exit: {best_exit} (Sh {best_exit_sh:.2f})")

    # ══════════════════════════════════════════════════════════════
    # SECTION 5: VIX regime segmentation
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print("  [7/8] VIX REGIME SEGMENTATION")
    print(f"{'='*72}")

    if all_trades:
        for regime in ["PANIC", "ELEVATED", "NORMAL", "LOW", "UNKNOWN"]:
            seg = [t for t in all_trades if t.get("vix_regime") == regime]
            summarize(seg, regime)

        # ETF type segmentation
        print("\n  ETF Type:")
        for etype in ["CYCLICAL", "DEFENSIVE", "BROAD", "THEMATIC", "COMMODITY"]:
            seg = [t for t in all_trades if t.get("etf_type") == etype]
            summarize(seg, etype)

        # Cross: VIX regime × ETF type
        print("\n  VIX × ETF Type (money table):")
        for regime in ["PANIC", "ELEVATED", "NORMAL", "LOW"]:
            for etype in ["CYCLICAL", "BROAD", "DEFENSIVE", "COMMODITY"]:
                seg = [t for t in all_trades
                       if t.get("vix_regime") == regime and t.get("etf_type") == etype]
                if len(seg) >= 5:
                    summarize(seg, f"{regime}+{etype}")

    # ══════════════════════════════════════════════════════════════
    # SECTION 6: Factor study
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print("  [8/8] FACTOR STUDY")
    print(f"{'='*72}")

    if len(all_trades) >= 30:
        factor_correlation(all_trades, "ALL ETFs")

        # Factor study per ETF type
        for etype in ["CYCLICAL", "BROAD", "COMMODITY"]:
            seg = [t for t in all_trades if t.get("etf_type") == etype]
            if len(seg) >= 20:
                factor_correlation(seg, etype)

    # ══════════════════════════════════════════════════════════════
    # PARAMETER SWEEP (optional)
    # ══════════════════════════════════════════════════════════════
    if args.sweep:
        print(f"\n{'='*72}")
        print("  PARAMETER SWEEP")
        print(f"{'='*72}")

        sweep_results = []
        for bb_std in [0.5, 0.75, 1.0]:
            for exit_rule in ["mid_break", "trailing"]:
                for trail_atr in ([2.0, 3.0] if exit_rule == "trailing" else [2.0]):
                    for pt in [5, 8, 10]:
                        for sl in [-3, -5]:
                            for mh in [20, 30, 40]:
                                p = {
                                    "bb_std": bb_std, "exit_rule": exit_rule,
                                    "trailing_atr": trail_atr, "profit_target": pt,
                                    "stop_loss": sl, "max_hold": mh,
                                }
                                trades_sw = []
                                for sym, df in price_data.items():
                                    trades_sw.extend(simulate_trades(df, sym, vix_series=vix_series, params=p))
                                if trades_sw:
                                    n = len(trades_sw)
                                    wr = sum(1 for t in trades_sw if t["win"]) / n * 100
                                    avg = np.mean([t["pnl_pct"] for t in trades_sw])
                                    sh = sharpe(np.array([t["pnl_pct"] for t in trades_sw]))
                                    config = f"σ={bb_std} {exit_rule} trail={trail_atr} PT={pt} SL={sl} MH={mh}"
                                    sweep_results.append({
                                        "config": config, "n": n, "wr": wr,
                                        "avg": avg, "sharpe": sh,
                                    })

        if sweep_results:
            sdf = pd.DataFrame(sweep_results).sort_values("sharpe", ascending=False)
            print("\n  Top 15 configs by Sharpe:")
            for _, row in sdf.head(15).iterrows():
                print(f"    Sh={row['sharpe']:.2f}  Win={row['wr']:.1f}%  Avg={row['avg']:+.2f}%  "
                      f"N={row['n']:4d}  {row['config']}")

    # ══════════════════════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print("  CONCLUSION")
    print(f"{'='*72}")
    if all_trades:
        n = len(all_trades)
        wr = sum(1 for t in all_trades if t["win"]) / n * 100
        avg = np.mean([t["pnl_pct"] for t in all_trades])
        sh = sharpe(np.array([t["pnl_pct"] for t in all_trades]))
        print(f"  Default BB(1σ): N={n}, Win={wr:.1f}%, Avg={avg:+.2f}%, Sh={sh:.2f}")
        print(f"  Best σ: {best_std}")
        print(f"  Best exit: {best_exit} (Sh {best_exit_sh:.2f})")
        if n >= 30:
            viable = sh > 0.5 and wr > 40
            print(f"\n  {'✓ VIABLE' if viable else '✗ NOT VIABLE'} — "
                  f"{'BB ride works on ETFs' if viable else 'BB ride does NOT work on ETFs with these params'}")
    else:
        print("  No trades generated — BB ride may not suit ETF volatility profile")

    print(f"\n{'='*72}\n")


if __name__ == "__main__":
    main()
