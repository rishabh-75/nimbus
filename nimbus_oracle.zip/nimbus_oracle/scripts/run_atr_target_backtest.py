#!/usr/bin/env python3
"""
scripts/run_atr_target_backtest.py — Validate ATR-based dynamic targets.

Compares:
  1. Fixed +5% PT (current baseline)
  2. ATR-scaled PT by grade (A+ = 3.0× ATR, A = 2.5×, B+ = 2.0×, B = 1.5×)
  3. Fixed ATR multiples (2× ATR for all, 2.5× for all, etc.)

For each strategy, simulates exits using daily OHLC data:
  - PT hit: high >= entry * (1 + target_pct/100) → win at target_pct
  - SL hit: low <= entry * (1 + stop_pct/100) → loss at stop_pct
  - BBW exit: if BBW contracts while above SMA → exit at close
  - MAX: 30 calendar days → exit at close

Reports: win rate, avg PnL, Sharpe, profit factor, PT hit rate, avg hold days.

Usage:
    python3 scripts/run_atr_target_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("atr_bt")


def simulate_exit(entry_date, entry_price, target_pct, stop_pct, price_df, max_days=30):
    """
    Simulate trade exit using daily OHLC.

    Returns: (exit_date, exit_price, exit_reason, pnl_pct, hold_days)
    """
    future = price_df[price_df.index > entry_date].head(max_days)
    if future.empty:
        return entry_date, entry_price, "NO_DATA", 0, 0

    pt_price = entry_price * (1 + target_pct / 100)
    sl_price = entry_price * (1 + stop_pct / 100)  # stop_pct is negative

    # Compute BBW and SMA for exit
    close_col = "Close"
    if close_col not in future.columns:
        close_col = [c for c in future.columns if "close" in c.lower()][0]

    sma = price_df[close_col].rolling(20).mean()
    bb_std = price_df[close_col].rolling(20).std()
    bb_upper = sma + 2 * bb_std
    bb_lower = sma - 2 * bb_std
    bbw = ((bb_upper - bb_lower) / sma.replace(0, np.nan) * 100)
    bbw_slope = bbw.diff(5)

    for i, (dt, row) in enumerate(future.iterrows()):
        high = row.get("High", row.get("high", entry_price))
        low = row.get("Low", row.get("low", entry_price))
        close = row.get(close_col, entry_price)
        days = (dt - entry_date).days

        # Check PT hit
        if high >= pt_price:
            return dt, pt_price, "PT", target_pct, days

        # Check SL hit
        if low <= sl_price:
            return dt, sl_price, "SL", stop_pct, days

        # Check BBW contraction exit (above SMA and BBW contracting)
        if dt in bbw_slope.index and dt in sma.index:
            if close > sma[dt] and bbw_slope[dt] < 0:
                pnl = (close - entry_price) / entry_price * 100
                return dt, close, "BBW", pnl, days

    # Max days exit
    last = future.iloc[-1]
    close = last.get(close_col, entry_price)
    pnl = (close - entry_price) / entry_price * 100
    days = (future.index[-1] - entry_date).days
    return future.index[-1], close, "MAX", pnl, days


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="atr_target_backtest_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    # Load price + feature data
    from modules.dual_mode import compute_dual_mode
    from modules.conviction import ConvictionEngine
    engine = ConvictionEngine()

    price_cache = {}
    for sym in trades_df["symbol"].unique():
        f = f"data/backtest_cache/{sym}_1d.parquet"
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except: pass

    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=60)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    # Build feature + ATR data for each trade
    logger.info("Computing features + ATR for each trade...")
    rows = []
    skipped = 0
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in price_cache: skipped += 1; continue
        pdf = price_cache[sym]
        mask = pdf.index <= trade["entry_date"]
        if mask.sum() < 40: skipped += 1; continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient: skipped += 1; continue

            vmask = vix_series.index <= trade["entry_date"]
            vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0
            conv = engine.compute(sig, vix=vix)

            # Get entry price
            entry_close = float(pdf.loc[mask].iloc[-1]["Close"])
            atr_pct = (sig.atr / entry_close * 100) if sig.atr > 0 and entry_close > 0 else 2.0

            rows.append({
                "symbol": sym, "entry_date": trade["entry_date"],
                "entry_price": entry_close,
                "grade": conv.grade, "atr_pct": atr_pct,
                "target_pct_dynamic": conv.target_pct,
                "stop_pct_dynamic": conv.stop_pct,
                "original_pnl": trade["pnl_pct"],
                "original_exit": trade["exit_reason"],
            })
        except: skipped += 1
        if (len(rows) + skipped) % 500 == 0:
            logger.info("  %d/%d processed", len(rows), len(trades_df))

    df = pd.DataFrame(rows)
    logger.info("Ready: %d trades (%d skipped)", len(df), skipped)

    # ══════════════════════════════════════════════════════════════════
    # SIMULATE EXITS FOR EACH STRATEGY
    # ══════════════════════════════════════════════════════════════════

    GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6}
    tradeable = df[df["grade"].isin(["A+", "A", "B+", "B"])].copy()
    logger.info("Tradeable (grade B+): %d trades", len(tradeable))

    strategies = {
        "Fixed +5% PT / -3% SL": {"target": 5.0, "stop": -3.0, "mode": "fixed"},
        "Fixed +3% PT / -2% SL": {"target": 3.0, "stop": -2.0, "mode": "fixed"},
        "Fixed +4% PT / -2.5% SL": {"target": 4.0, "stop": -2.5, "mode": "fixed"},
        "2.0× ATR PT / 1.5× SL": {"target_mult": 2.0, "stop_mult": 1.5, "mode": "atr_fixed"},
        "2.5× ATR PT / 1.5× SL": {"target_mult": 2.5, "stop_mult": 1.5, "mode": "atr_fixed"},
        "3.0× ATR PT / 1.5× SL": {"target_mult": 3.0, "stop_mult": 1.5, "mode": "atr_fixed"},
        "Grade-scaled ATR (current)": {"mode": "grade_atr"},
    }

    # Cap maps for grade-scaled
    TARGET_ATR = {"A+": 3.0, "A": 2.5, "B+": 2.0, "B": 1.5}
    STOP_ATR = {"A+": 1.5, "A": 1.5, "B+": 1.5, "B": 1.5}
    TARGET_MAX = {"A+": 8.0, "A": 5.0, "B+": 4.0, "B": 3.0}
    TARGET_MIN = 1.5
    STOP_MAX = 4.0

    report = []
    report.append("=" * 80)
    report.append("ATR TARGET BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(tradeable)} (grade B and above)")
    report.append(f"Period: {tradeable['entry_date'].min().date()} to {tradeable['entry_date'].max().date()}")
    report.append("=" * 80)

    results_by_strategy = {}

    for strat_name, cfg in strategies.items():
        logger.info("Simulating: %s", strat_name)
        exits = []

        for _, row in tradeable.iterrows():
            sym = row["symbol"]
            if sym not in price_cache: continue

            if cfg["mode"] == "fixed":
                tgt = cfg["target"]
                stp = -abs(cfg["stop"])
            elif cfg["mode"] == "atr_fixed":
                tgt = row["atr_pct"] * cfg["target_mult"]
                stp = -row["atr_pct"] * cfg["stop_mult"]
                tgt = max(TARGET_MIN, min(tgt, 8.0))
                stp = max(-STOP_MAX, stp)
            elif cfg["mode"] == "grade_atr":
                g = row["grade"]
                if g not in TARGET_ATR: continue
                tgt = row["atr_pct"] * TARGET_ATR[g]
                stp = -row["atr_pct"] * STOP_ATR[g]
                tgt = max(TARGET_MIN, min(tgt, TARGET_MAX.get(g, 5.0)))
                stp = max(-STOP_MAX, stp)

            dt, px, reason, pnl, hold = simulate_exit(
                row["entry_date"], row["entry_price"], tgt, stp, price_cache[sym]
            )
            exits.append({
                "pnl_pct": pnl, "exit_reason": reason, "hold_days": hold,
                "target_pct": tgt, "stop_pct": stp, "grade": row["grade"],
            })

        edf = pd.DataFrame(exits)
        if len(edf) < 20:
            results_by_strategy[strat_name] = None
            continue

        wr = (edf["pnl_pct"] > 0).mean() * 100
        avg = edf["pnl_pct"].mean()
        std = edf["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        wins = edf[edf["pnl_pct"] > 0]["pnl_pct"].sum()
        losses = abs(edf[edf["pnl_pct"] < 0]["pnl_pct"].sum())
        pf = wins / losses if losses > 0 else 999
        pt_pct = (edf["exit_reason"] == "PT").mean() * 100
        sl_pct = (edf["exit_reason"] == "SL").mean() * 100
        bbw_pct = (edf["exit_reason"] == "BBW").mean() * 100
        avg_hold = edf["hold_days"].mean()

        eq = (1 + edf["pnl_pct"] / 100).cumprod()
        mdd = ((eq - eq.cummax()) / eq.cummax() * 100).min()

        results_by_strategy[strat_name] = {
            "n": len(edf), "wr": wr, "avg": avg, "sh": sh, "pf": pf,
            "pt": pt_pct, "sl": sl_pct, "bbw": bbw_pct,
            "hold": avg_hold, "mdd": mdd,
        }

    # ══════════════════════════════════════════════════════════════════
    # REPORT
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 80)
    report.append("STRATEGY COMPARISON")
    report.append("=" * 80)
    report.append(f"\n  {'Strategy':35s} {'N':>5s} {'Win%':>6s} {'Avg':>7s} {'Sh':>6s} {'PF':>5s} {'PT%':>5s} {'SL%':>5s} {'BBW%':>5s} {'Hold':>5s} {'MDD':>7s}")

    best_sh = -999
    best_strat = None
    for name, s in results_by_strategy.items():
        if s is None:
            report.append(f"  {name:35s}  (insufficient data)")
            continue
        report.append(f"  {name:35s} {s['n']:5d} {s['wr']:5.1f}% {s['avg']:+6.3f}% {s['sh']:5.2f} {s['pf']:4.2f} {s['pt']:4.0f}% {s['sl']:4.0f}% {s['bbw']:4.0f}% {s['hold']:4.1f}d {s['mdd']:+6.1f}%")
        if s["sh"] > best_sh:
            best_sh = s["sh"]
            best_strat = name

    report.append(f"\n  BEST: {best_strat} (Sharpe={best_sh:.2f})")

    # ══════════════════════════════════════════════════════════════════
    # GRADE-SCALED BREAKDOWN
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 80)
    report.append("GRADE-SCALED ATR — BREAKDOWN BY GRADE")
    report.append("=" * 80)

    strat_cfg = {"mode": "grade_atr"}
    for g in ["A+", "A", "B+", "B"]:
        g_trades = tradeable[tradeable["grade"] == g]
        exits = []
        for _, row in g_trades.iterrows():
            sym = row["symbol"]
            if sym not in price_cache: continue
            tgt = row["atr_pct"] * TARGET_ATR[g]
            stp = -row["atr_pct"] * STOP_ATR[g]
            tgt = max(TARGET_MIN, min(tgt, TARGET_MAX[g]))
            stp = max(-STOP_MAX, stp)
            dt, px, reason, pnl, hold = simulate_exit(
                row["entry_date"], row["entry_price"], tgt, stp, price_cache[sym]
            )
            exits.append({"pnl_pct": pnl, "exit_reason": reason, "hold_days": hold, "target_pct": tgt})

        edf = pd.DataFrame(exits)
        if len(edf) < 5: continue
        wr = (edf["pnl_pct"] > 0).mean() * 100
        avg = edf["pnl_pct"].mean()
        pt = (edf["exit_reason"] == "PT").mean() * 100
        avg_tgt = edf["target_pct"].mean()
        avg_hold = edf["hold_days"].mean()
        report.append(f"  {g:3s}: N={len(edf):4d}  Win={wr:.1f}%  Avg={avg:+.3f}%  PT={pt:.0f}%  AvgTarget={avg_tgt:.1f}%  AvgHold={avg_hold:.0f}d")

    # ══════════════════════════════════════════════════════════════════
    # ORIGINAL vs SIMULATED (same exits)
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 80)
    report.append("ORIGINAL BACKTEST vs SIMULATED EXITS")
    report.append("=" * 80)
    report.append("  (Original used walkforward fixed +5% PT / BBW / 30d MAX)")

    orig_wr = (tradeable["original_pnl"] > 0).mean() * 100
    orig_avg = tradeable["original_pnl"].mean()
    orig_std = tradeable["original_pnl"].std()
    orig_sh = orig_avg / orig_std * np.sqrt(252/10) if orig_std > 0 else 0
    report.append(f"\n  Original:       Win={orig_wr:.1f}%  Avg={orig_avg:+.3f}%  Sh={orig_sh:.2f}")

    gs = results_by_strategy.get("Grade-scaled ATR (current)")
    if gs:
        report.append(f"  Grade-scaled:   Win={gs['wr']:.1f}%  Avg={gs['avg']:+.3f}%  Sh={gs['sh']:.2f}")
    f5 = results_by_strategy.get("Fixed +5% PT / -3% SL")
    if f5:
        report.append(f"  Fixed 5%/3%:    Win={f5['wr']:.1f}%  Avg={f5['avg']:+.3f}%  Sh={f5['sh']:.2f}")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
