"""NSE market-session helpers.

IST-based utilities for answering "is the market open right now" and
"what's the current IST wall-clock time" — questions that recur in
several places (status-bar labels, data-loader freshness decisions,
auto-refresh scheduling).

Kept deliberately tiny: only two functions. More session-semantics
like "last expected bar date" or "is a trading day" can be added here
later as callers appear.

NSE cash-market hours:
    Monday–Friday, 09:15–15:30 IST.

We do NOT check the NSE holiday calendar. The failure mode on a
holiday is cosmetic (the label might say "live" when the exchange
is actually closed); it doesn't corrupt any data. Adding holiday
awareness would require a maintained calendar file, which isn't
worth the complexity for the cost of the edge case.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Final

#: India Standard Time — UTC+05:30. Matches oracle's convention in
#: ``modules/data.py::is_market_open`` so behavior is identical.
_IST: Final[timezone] = timezone(timedelta(hours=5, minutes=30))


def now_ist() -> datetime:
    """Return the current wall-clock time in IST.

    Used anywhere session-aware logic needs a "now" reference.
    Always tz-aware so arithmetic with other tz-aware datetimes is
    well-defined.
    """
    return datetime.now(tz=_IST)


def is_market_open(now: datetime | None = None) -> bool:
    """Return ``True`` iff NSE's cash market is currently open.

    Window: Monday–Friday, 09:15–15:30 IST. Weekends return ``False``.
    Holidays are NOT checked — see module docstring.

    Args:
        now: Optional override for testing. When ``None`` (the
            production path), reads :func:`now_ist`.
    """
    if now is None:
        now = now_ist()
    # Weekday is 0-6 with Monday=0, Sunday=6; weekends are >=5.
    if now.weekday() >= 5:
        return False
    open_ = now.replace(hour=9, minute=15, second=0, microsecond=0)
    close_ = now.replace(hour=15, minute=30, second=0, microsecond=0)
    return open_ <= now <= close_
