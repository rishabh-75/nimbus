#!/usr/bin/env python3
"""rrg_lookback_probe.py — what is the right RRG window?

THE QUESTION
------------
DIRECTION (RRG) runs on ``RRG_LOOKBACK`` = 50 while STRENGTH runs on 20.
Should direction be shortened toward 20 to make the tool faster?

"Best" needs a definition that is not aesthetic, so this measures three
things, in increasing order of how much they matter:

1. RESOLUTION — are all four quadrants actually populated? A window that
   collapses to Leading/Lagging has thrown away the transition states, and
   the maturity gate (Fresh/Turning/Stable/Extended/Maturing) keys off the
   momentum slope that has just gone flat. Cheap to measure, and a hard
   floor: a 2-quadrant RRG is not an RRG.

2. INDEPENDENCE — rho(strength, RS-Ratio). The score model is
   ``strength x direction_gate x seasonal_gate x breadth_gate``, which
   assumes semi-independent confirmations. If direction is just strength
   restated, the score multiplies strength by itself and calls the result
   confluence. Direction earns its place ONLY by carrying information
   strength does not, and that comes from measuring RS over a LONGER window
   than strength.

3. PREDICTION — does the quadrant actually separate forward industry
   returns, and at which window best? This is the part that has never been
   tested. Note the app makes a SPECIFIC, falsifiable claim in
   ``_ODDS_QUADRANT_RANK``:

       Improving > Leading > Weakening > Lagging

   i.e. catch rotation as it starts; a fading leader (Weakening) is a trap
   that ranks BELOW a confirmed leader. This probe tests that ordering
   directly, per lookback.

   Every prior probe in this repo tested SINGLE-NAME timing and came back
   null. This is the first test of the INDUSTRY-level signal — the thing
   the rest of the app is built on — so it deserves a clean read either way.

HOW TO PICK A WINNER WITHOUT FOOLING YOURSELF
---------------------------------------------
Sweeping ~8 windows x 3 horizons is ~24 comparisons. The best cell WILL
look good by luck. Two disciplines are built into the output:

  * A random control (``ctl:shuffled``) that shuffles quadrant labels within
    each date. If the real spread does not clear it, there is nothing.
  * PLATEAU, NOT PEAK. A real parameter effect is SMOOTH: neighbouring
    windows behave similarly and the good region is broad. A single spike
    at 35 with dips at 30 and 40 is noise, however large its t-stat. The
    output prints the whole curve so the shape is visible, and you should
    pick the middle of a plateau rather than the argmax.

STATISTICS
----------
Industries move together, so trades/observations on one date are not
independent. All t-stats are DATE-CLUSTERED (collapse to one observation
per date, then t-test across dates). The naive per-observation t is shown
alongside so the inflation stays visible.

USAGE
    python rrg_lookback_probe.py
    python rrg_lookback_probe.py --lookbacks 20,30,40,50,60,80 --dates 40
    python rrg_lookback_probe.py --horizons 10,20 --strength-lookback 20
"""
from __future__ import annotations

import argparse
import statistics
import sys
from collections import Counter

DEFAULT_LOOKBACKS = "20,25,30,35,40,50,60,80"


# --------------------------------------------------------------------------
# stats
# --------------------------------------------------------------------------
def _mean(xs, default=float("nan")) -> float:
    """Mean that never raises. statistics.mean([]) raises, and an all-NaN
    series filters to empty — which is a normal outcome for a window that
    could not be scored, not an error worth crashing a multi-minute run."""
    vals = [x for x in xs if x == x]
    return statistics.mean(vals) if vals else default


def _t_of(xs) -> float:
    if len(xs) < 2:
        return 0.0
    m = statistics.mean(xs)
    sd = statistics.stdev(xs)
    return m / (sd / len(xs) ** 0.5) if sd > 0 else 0.0


def _clustered_t(obs) -> tuple[float, float, int, int]:
    """obs = [(date, value)] -> (mean, clustered_t, n_obs, n_dates)."""
    by_date: dict = {}
    for d, v in obs:
        by_date.setdefault(d, []).append(v)
    dm = [_mean(v) for v in by_date.values()]
    dm = [x for x in dm if x == x]
    vals = [v for _, v in obs if v == v]
    if not vals:
        return (float("nan"), 0.0, 0, 0)
    return (_mean(vals), _t_of(dm), len(vals), len(dm))


def spearman(a: dict, b: dict) -> float:
    ks = [k for k in a if k in b]
    n = len(ks)
    if n < 3:
        return float("nan")
    ra = {k: i for i, k in enumerate(sorted(ks, key=lambda k: -a[k]))}
    rb = {k: i for i, k in enumerate(sorted(ks, key=lambda k: -b[k]))}
    d2 = sum((ra[k] - rb[k]) ** 2 for k in ks)
    return 1.0 - 6.0 * d2 / (n * (n * n - 1))


# --------------------------------------------------------------------------
# panel
# --------------------------------------------------------------------------
def load_panel(engine, ind_db):
    from nimbus_v3.data.cache import ParquetCache
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.paths import cache_dir

    raw = ParquetCache(base_dir=cache_dir("equity_price"))
    ec = EnrichedPanelCache(raw_cache=raw,
                            schema_hash=engine.enrichment_schema_hash())
    panel, members = {}, {}
    for sym in sorted(ind_db):
        # Explicit None checks — `a or b` would call bool() on a DataFrame,
        # which pandas refuses ("truth value is ambiguous").
        df = ec.get_if_fresh(sym)
        if df is None:
            df = ec.get_stale(sym)
        if df is None:
            try:
                r = raw.get(sym)
            except Exception:            # noqa: BLE001
                r = None
            if r is not None and not r.empty:
                try:
                    df = engine.enrich(r, sym)
                except Exception:        # noqa: BLE001
                    df = None
        if df is None or df.empty:
            continue
        panel[sym] = df
        rec = ind_db.get(sym)
        if rec is not None and rec.industry:
            members.setdefault(rec.industry, []).append(sym)
    return panel, members


def _slice(panel, asof):
    """Panel truncated at ``asof``. DATE-based, never positional — symbols
    have different histories and positional slicing would silently compare
    mismatched dates (the harness bug this repo has been bitten by)."""
    out = {}
    for s, df in panel.items():
        h = df.loc[:asof]
        if len(h) >= 90:
            out[s] = h
    return out


def _fwd_excess(panel, members, asof, horizon):
    """Forward EXCESS return per industry: the equal-weighted mean member
    return over the next ``horizon`` bars, minus the same for the whole
    cross-section. Excess, so it measures whether the QUADRANT picked the
    right industries, not whether the market rose."""
    per_sym = {}
    for s, df in panel.items():
        idx = df.index
        pos = idx.searchsorted(asof, side="right") - 1
        if pos < 0 or pos + horizon >= len(idx):
            continue
        c = df["Close"].to_numpy(dtype=float)
        if c[pos] > 0:
            per_sym[s] = (c[pos + horizon] / c[pos] - 1.0) * 100.0
    if len(per_sym) < 50:
        return None
    mkt = _mean(list(per_sym.values()))
    out = {}
    for ind, syms in members.items():
        vals = [per_sym[s] for s in syms if s in per_sym]
        if len(vals) >= 3:
            out[ind] = _mean(vals) - mkt
    return out or None


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lookbacks", default=DEFAULT_LOOKBACKS)
    ap.add_argument("--horizons", default="10,20")
    ap.add_argument("--strength-lookback", type=int, default=20,
                    help="strength window to measure independence against")
    ap.add_argument("--dates", type=int, default=36)
    ap.add_argument("--step", type=int, default=10)
    ap.add_argument("--seed", type=int, default=17)
    args = ap.parse_args()

    import numpy as np
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    from nimbus_v3.compute.market_pulse_common import (
        industry_rs_excess,
        window_return_pct,
    )
    from nimbus_v3.compute.rrg import Quadrant, compute_rrg
    from nimbus_v3.data.industry_db import load_industry_db

    lookbacks = [int(x) for x in args.lookbacks.split(",")]
    horizons = [int(x) for x in args.horizons.split(",")]
    rng = np.random.default_rng(args.seed)

    eng = StrategyComputeEngine()
    db = load_industry_db()
    print("loading panel...", file=sys.stderr)
    panel, members = load_panel(eng, db)
    if not panel:
        print("panel empty — run the app once first.", file=sys.stderr)
        return 1
    members = {k: v for k, v in members.items()
               if k not in ("ALL", "Unknown", "") and len(v) >= 5}
    bench = None
    for cand in ("CNX500", "NIFTY500", "NIFTY50"):
        if cand in panel:
            bench = panel[cand]["Close"]
            break
    all_dates = sorted({d for df in panel.values() for d in df.index})
    print(f"  {len(panel)} symbols · {len(members)} industries · "
          f"{len(all_dates)} days", file=sys.stderr)

    # accumulators
    struct: dict[int, dict] = {lb: {"quad": Counter(), "rho": [],
                                    "flip": [], "prev": {}}
                               for lb in lookbacks}
    pred: dict = {(lb, h): {q: [] for q in
                            ["Improving", "Leading", "Weakening", "Lagging",
                             "ctl:shuffled", "_spread", "_rankrho"]}
                  for lb in lookbacks for h in horizons}

    maxh = max(horizons)
    used = 0
    for i in range(args.dates):
        di = len(all_dates) - maxh - 2 - i * args.step
        if di < 260:
            break
        asof = all_dates[di]
        sub = _slice(panel, asof)
        if len(sub) < 100:
            continue
        b = bench.loc[:asof] if bench is not None else None
        used += 1
        print(f"  {used}/{args.dates}  {asof.date()}", file=sys.stderr)

        # strength (fixed window) for the independence check
        rot = compute_industry_rotation(members, sub,
                                        lookback=args.strength_lookback)
        bret = (window_return_pct(b, args.strength_lookback)
                if b is not None else 0.0)
        strength = industry_rs_excess(
            {r.industry: r.roc for r in rot.industries}, bret)

        fwd = {h: _fwd_excess(panel, members, asof, h) for h in horizons}

        for lb in lookbacks:
            r = compute_rrg(members, sub, b, lookback=lb)
            if not r.points:
                continue
            st = struct[lb]
            quads = {p.industry: p.quadrant.value for p in r.points}
            st["quad"].update(quads.values())
            st["rho"].append(spearman(
                strength, {p.industry: p.rs_ratio for p in r.points}))
            # quadrant stability between consecutive sampled dates
            if st["prev"]:
                shared = set(quads) & set(st["prev"])
                if shared:
                    st["flip"].append(
                        sum(quads[k] != st["prev"][k] for k in shared)
                        / len(shared))
            st["prev"] = quads

            for h in horizons:
                f = fwd.get(h)
                if not f:
                    continue
                cell = pred[(lb, h)]
                inds = [k for k in quads if k in f]
                if len(inds) < 8:
                    continue
                for k in inds:
                    cell[quads[k]].append((asof, f[k]))
                # control: shuffle labels within this date
                lab = [quads[k] for k in inds]
                rng.shuffle(lab)
                for k, q in zip(inds, lab):
                    if q == "Leading":
                        cell["ctl:shuffled"].append((asof, f[k]))
                # headline spread: Leading - Lagging
                lead = [f[k] for k in inds if quads[k] == "Leading"]
                lag = [f[k] for k in inds if quads[k] == "Lagging"]
                if lead and lag:
                    cell["_spread"].append(
                        (asof, _mean(lead) - _mean(lag)))
                # does the app's odds ordering rank forward returns?
                rank = {"Improving": 0, "Leading": 1,
                        "Weakening": 2, "Lagging": 3}
                a = {k: -rank[quads[k]] for k in inds}
                cell["_rankrho"].append((asof, spearman(a, {k: f[k]
                                                            for k in inds})))

    if used == 0:
        print("no usable dates.", file=sys.stderr)
        return 1

    # ---------------- structural ----------------
    print()
    print("=" * 92)
    print(f"  RRG LOOKBACK SWEEP  ({used} as-of dates · strength window "
          f"{args.strength_lookback}d)")
    print("=" * 92)
    print("\n  1) RESOLUTION & INDEPENDENCE  (no forward returns involved)")
    print(f"    {'lb':>4}{'quads':>7}{'rho(str,RS)':>13}{'flip%':>8}"
          f"   quadrant mix")
    print("    " + "-" * 82)
    for lb in lookbacks:
        st = struct[lb]
        tot = sum(st["quad"].values())
        if not tot:
            continue
        mix = " ".join(f"{q[:4]}{100*st['quad'][q]/tot:.0f}%" for q in
                       ("Leading", "Weakening", "Lagging", "Improving")
                       if st["quad"][q])
        rho = _mean(st["rho"])
        flip = 100 * _mean(st["flip"])
        warn = "  <-- degenerate" if abs(rho) > 0.90 else ""
        nq = sum(1 for q in st["quad"] if st["quad"][q])
        print(f"    {lb:>4}{nq:>7}{rho:>13.3f}{flip:>8.1f}   {mix}{warn}")
    print("\n    quads  : 4 = all states alive. <4 means the maturity gate has")
    print("             lost the momentum resolution it keys off.")
    print("    rho    : direction vs strength. >0.90 = direction is strength")
    print("             restated; the gate multiplies strength by itself.")
    print("    flip%  : quadrant changes between sampled dates. High = whipsaw,")
    print("             very low = stale. Judge with the step size in mind.")

    # ---------------- predictive ----------------
    for h in horizons:
        print()
        print("  " + "-" * 88)
        print(f"  2) PREDICTION — {h}-day forward INDUSTRY excess return")
        print(f"    {'lb':>4}{'Impr':>8}{'Lead':>8}{'Weak':>8}{'Lag':>8}"
              f"{'L-Lag':>9}{'t':>6}{'ctl':>8}{'oddsRho':>9}{'t':>6}")
        print("    " + "-" * 84)
        for lb in lookbacks:
            cell = pred[(lb, h)]
            def m(k):
                return _mean([x for _, x in cell[k]])
            sp, spt, _, _ = _clustered_t(cell["_spread"])
            rr, rrt, _, _ = _clustered_t(cell["_rankrho"])
            ctl = m("ctl:shuffled")
            s1 = "*" if abs(spt) > 2 else " "
            s2 = "*" if abs(rrt) > 2 else " "
            print(f"    {lb:>4}{m('Improving'):>+8.2f}{m('Leading'):>+8.2f}"
                  f"{m('Weakening'):>+8.2f}{m('Lagging'):>+8.2f}"
                  f"{sp:>+9.2f}{spt:>5.1f}{s1}{ctl:>+8.2f}"
                  f"{rr:>+9.3f}{rrt:>5.1f}{s2}")
        print()
        print("    L-Lag  : Leading minus Lagging forward excess. The headline.")
        print("    ctl    : same-size random cohort (labels shuffled within")
        print("             date). The Leading column must beat THIS, not 0.")
        print("    oddsRho: does Improving>Leading>Weakening>Lagging actually")
        print("             rank forward returns? Positive = the app's ordering")
        print("             holds; ~0 = quadrant carries no ordering info.")

    print()
    print("  HOW TO CHOOSE")
    print("  * Rule out any window with <4 quadrants or rho>0.90 FIRST — those")
    print("    are broken instruments regardless of what they score.")
    print("  * Then look for a PLATEAU in L-Lag / oddsRho, not the argmax.")
    print("    Sweeping ~%d windows x %d horizons, the best cell will look good"
          % (len(lookbacks), len(horizons)))
    print("    by luck. A real effect is SMOOTH in the parameter: neighbours")
    print("    agree. A lone spike between two dips is noise.")
    print("  * If NO window separates Leading from Lagging beyond the control,")
    print("    that is the finding — the direction gate is decoration, and the")
    print("    honest response is to simplify the score, not retune it.")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
