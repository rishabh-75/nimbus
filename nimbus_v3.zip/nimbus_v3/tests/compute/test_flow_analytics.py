"""Tests for ``nimbus_v3.compute.flow_analytics.FlowAnalyticsEngine``.

The engine was extracted from the UI panel this turn. These tests
pin the behavior that older tests in ``tests/ui/test_macro_flow_panel.py``
covered via the UI paths — verdict labels fire correctly, movers are
ranked right, threshold overrides work.

Strategy
--------
Most tests forge ``MacroFlowResult`` fixtures directly rather than
going through ``detect_flows`` with synthetic prices. The engine's job
is to *consume* MacroFlowResult values and produce a verdict, so the
upstream price-generation path is orthogonal and tested separately in
``tests/macro/test_flow_detector.py``.
"""
from __future__ import annotations

import pandas as pd
import pytest

from nimbus_v3.compute.flow_analytics import (
    CategoryStats,
    FlowAnalyticsEngine,
    FlowAnalyticsResult,
    MacroVerdict,
)
from nimbus_v3.macro.flow_detector import MacroFlowResult
from nimbus_v3.macro.universe import (
    COMMODITY_UNIVERSE, CommodityCategory, CommodityInstrument,
)


# ══════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════

def _forge_result(
    ticker: str, category: CommodityCategory,
    z10: float, z30: float, z60: float,
    *, name: str | None = None, close: float = 100.0,
) -> MacroFlowResult:
    """Build a MacroFlowResult bypassing detect_flows.

    The three z-scores are the only thing the verdict compute
    actually reads; everything else (price, pct changes, listing
    cycle) is filler to satisfy the dataclass."""
    instr = CommodityInstrument(
        ticker=ticker,
        name=name or ticker,
        category=category,
        root=ticker[:2],
        exchange="TEST",
        listing_cycle=("H",),
    )
    return MacroFlowResult(
        instrument=instr,
        asof_date=pd.Timestamp("2026-04-21"),
        close_price=close,
        pct_change_1d=0.0,
        pct_change_5d=0.0,
        price_z_10d=z10,
        price_z_30d=z30,
        price_z_60d=z60,
    )


# ══════════════════════════════════════════════════════════════════════
# Verdict label tests — one per regime branch
# ══════════════════════════════════════════════════════════════════════

class TestVerdictLabels:
    """The verdict function has 8 branches (7 named regimes + MIXED).
    One test per branch, structured to isolate the triggering
    condition."""

    def test_risk_off_when_precious_bid_energy_dumping(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 1.0, 1.0, 0.8),
            _forge_result("CL=F", CommodityCategory.ENERGY, -1.2, -1.0, -0.8),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "RISK-OFF"

    def test_inflationary_when_all_three_cyclical_hot(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.6, 0.7, 0.8),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, 0.7, 0.8, 0.9),
            _forge_result("CL=F", CommodityCategory.ENERGY, 1.0, 1.1, 1.2),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "INFLATIONARY"

    def test_deflationary_when_all_three_cyclical_soft(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, -0.6, -0.7, -0.8),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, -0.7, -0.8, -0.9),
            _forge_result("CL=F", CommodityCategory.ENERGY, -1.0, -1.1, -1.2),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "DEFLATIONARY"

    def test_risk_on_when_cyclicals_lead_without_havens(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.1, 0.0, 0.0),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, 0.8, 0.9, 1.0),
            _forge_result("CL=F", CommodityCategory.ENERGY, 0.6, 0.7, 0.8),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "RISK-ON"

    def test_goldilocks_when_industrial_hot_energy_soft(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.0, 0.1, 0.0),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, 0.8, 0.9, 1.0),
            _forge_result("CL=F", CommodityCategory.ENERGY, -0.4, -0.5, -0.6),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "GOLDILOCKS"

    def test_stagflation_when_energy_hot_industrial_soft(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("CL=F", CommodityCategory.ENERGY, 0.8, 0.9, 1.0),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, -0.4, -0.5, -0.6),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "STAGFLATION"

    def test_commodity_deflation_when_cyclicals_dump_gold_quiet(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.0, 0.1, -0.1),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, -0.8, -0.9, -1.0),
            _forge_result("CL=F", CommodityCategory.ENERGY, -0.6, -0.7, -0.8),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "COMMODITY DEFLATION"

    def test_mixed_when_no_pattern_fires(self):
        """All categories near zero — no diagnostic pattern."""
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.1, 0.2, 0.0),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, 0.2, 0.1, 0.0),
            _forge_result("CL=F", CommodityCategory.ENERGY, -0.1, 0.0, 0.1),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.label == "MIXED"


# ══════════════════════════════════════════════════════════════════════
# Strength banding
# ══════════════════════════════════════════════════════════════════════

class TestVerdictStrength:

    def test_strong_signal_when_category_mean_at_or_above_1_5(self):
        engine = FlowAnalyticsEngine()
        # Energy averaging 1.6z across its 3 instruments → strong.
        results = [
            _forge_result("CL=F", CommodityCategory.ENERGY, 1.6, 1.6, 1.6),
            _forge_result("NG=F", CommodityCategory.ENERGY, 1.6, 1.6, 1.6),
            _forge_result("HG=F", CommodityCategory.INDUSTRIAL, 0.2, 0.2, 0.2),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.strength == "strong signal"

    def test_moderate_when_category_mean_between_0_8_and_1_5(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("CL=F", CommodityCategory.ENERGY, 1.0, 1.0, 1.0),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.strength == "moderate"

    def test_weak_when_all_categories_near_zero(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("CL=F", CommodityCategory.ENERGY, 0.1, 0.0, -0.1),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.strength == "weak · mixed"


# ══════════════════════════════════════════════════════════════════════
# Movers — ranking
# ══════════════════════════════════════════════════════════════════════

class TestMovers:

    def test_movers_up_sorted_by_descending_avg_z(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("A", CommodityCategory.ENERGY, 2.0, 2.0, 2.0),
            _forge_result("B", CommodityCategory.ENERGY, 1.0, 1.0, 1.0),
            _forge_result("C", CommodityCategory.ENERGY, 3.0, 3.0, 3.0),
        ]
        verdict = engine.compute_verdict(results)
        # Top 3 up, ordered descending
        tickers_up = [m[0] for m in verdict.movers_up]
        assert tickers_up == ["C", "A", "B"]

    def test_movers_down_sorted_by_ascending_avg_z(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("A", CommodityCategory.ENERGY, -2.0, -2.0, -2.0),
            _forge_result("B", CommodityCategory.ENERGY, -1.0, -1.0, -1.0),
            _forge_result("C", CommodityCategory.ENERGY, -3.0, -3.0, -3.0),
        ]
        verdict = engine.compute_verdict(results)
        tickers_dn = [m[0] for m in verdict.movers_down]
        assert tickers_dn == ["C", "A", "B"]   # most negative first

    def test_movers_skip_neutral_instruments(self):
        """Instruments near zero shouldn't appear in either mover list."""
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("UP", CommodityCategory.ENERGY, 1.5, 1.5, 1.5),
            _forge_result("FLAT", CommodityCategory.ENERGY, 0.0, 0.0, 0.0),
            _forge_result("DN", CommodityCategory.ENERGY, -1.5, -1.5, -1.5),
        ]
        verdict = engine.compute_verdict(results)
        assert "FLAT" not in [m[0] for m in verdict.movers_up]
        assert "FLAT" not in [m[0] for m in verdict.movers_down]


# ══════════════════════════════════════════════════════════════════════
# Category stats
# ══════════════════════════════════════════════════════════════════════

class TestCategoryStats:

    def test_all_categories_always_in_order(self):
        """Even empty categories appear in the by_category tuple, in
        the fixed display order."""
        engine = FlowAnalyticsEngine()
        # Only two categories populated
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.5, 0.5, 0.5),
            _forge_result("CL=F", CommodityCategory.ENERGY, -0.5, -0.5, -0.5),
        ]
        verdict = engine.compute_verdict(results)
        cats_in_order = [cs.category for cs in verdict.by_category]
        assert cats_in_order == list(FlowAnalyticsEngine.CAT_ORDER)

    def test_empty_categories_report_nan_mean_and_zero_counts(self):
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("GC=F", CommodityCategory.PRECIOUS, 0.5, 0.5, 0.5),
        ]
        verdict = engine.compute_verdict(results)
        agri = next(
            cs for cs in verdict.by_category
            if cs.category == CommodityCategory.AGRICULTURAL
        )
        assert agri.total == 0
        assert agri.bulls == 0
        assert agri.bears == 0
        assert agri.mean_z != agri.mean_z   # NaN check

    def test_bull_count_uses_engine_threshold(self):
        """A custom engine with tighter threshold should count more bulls."""
        tight = FlowAnalyticsEngine(bull_z=0.3, bear_z=-0.3)
        results = [
            _forge_result("A", CommodityCategory.ENERGY, 0.4, 0.4, 0.4),
            _forge_result("B", CommodityCategory.ENERGY, 0.4, 0.4, 0.4),
        ]
        v_tight = tight.compute_verdict(results)
        energy = next(
            cs for cs in v_tight.by_category
            if cs.category == CommodityCategory.ENERGY
        )
        assert energy.bulls == 2   # both above 0.3

        # Default engine (bull_z=0.5) should count zero bulls
        default = FlowAnalyticsEngine()
        v_default = default.compute_verdict(results)
        energy_default = next(
            cs for cs in v_default.by_category
            if cs.category == CommodityCategory.ENERGY
        )
        assert energy_default.bulls == 0   # neither above 0.5


# ══════════════════════════════════════════════════════════════════════
# NaN handling
# ══════════════════════════════════════════════════════════════════════

class TestNaNHandling:

    def test_instrument_with_all_nan_z_is_dropped_from_movers(self):
        """Pre-warmup instruments (insufficient history) have NaN
        z-scores. They should be filtered out of the verdict compute
        entirely — not appear in movers or category stats."""
        engine = FlowAnalyticsEngine()
        import math
        results = [
            _forge_result("OK", CommodityCategory.ENERGY, 1.0, 1.0, 1.0),
            _forge_result(
                "NAN", CommodityCategory.ENERGY,
                float("nan"), float("nan"), float("nan"),
            ),
        ]
        verdict = engine.compute_verdict(results)
        assert verdict.total_count == 1
        all_mover_tickers = (
            [m[0] for m in verdict.movers_up]
            + [m[0] for m in verdict.movers_down]
        )
        assert "NAN" not in all_mover_tickers

    def test_partial_nan_is_averaged_over_the_non_nan_windows(self):
        """If 10d z is NaN but 30d/60d are finite, use the finite
        values. Shouldn't silently zero-out the instrument."""
        engine = FlowAnalyticsEngine()
        result = _forge_result(
            "T", CommodityCategory.ENERGY,
            float("nan"), 1.5, 1.5,
        )
        # avg_z of (NaN-excluded, 1.5, 1.5) = 1.5
        avg = FlowAnalyticsEngine._avg_z(result)
        assert avg == pytest.approx(1.5)


# ══════════════════════════════════════════════════════════════════════
# End-to-end through analyze()
# ══════════════════════════════════════════════════════════════════════

class TestAnalyzeEndToEnd:
    """Smoke test that the top-level analyze() pipeline is wired
    correctly — takes a price panel, runs detect_flows, computes
    verdict, returns bundled FlowAnalyticsResult."""

    def test_empty_panel_returns_mixed_verdict(self):
        engine = FlowAnalyticsEngine()
        result = engine.analyze(panel={})
        assert isinstance(result, FlowAnalyticsResult)
        assert result.verdict.label == "MIXED"
        assert result.verdict.total_count == 0
        assert len(result.results) == 0

    def test_analyze_returns_frozen_bundle(self):
        engine = FlowAnalyticsEngine()
        result = engine.analyze(panel={})
        # FlowAnalyticsResult is frozen — attempting to mutate raises.
        with pytest.raises((AttributeError, Exception)):
            result.verdict = None  # type: ignore[misc]


# ══════════════════════════════════════════════════════════════════════
# Threshold-override plumbing
# ══════════════════════════════════════════════════════════════════════

class TestThresholdOverrides:

    def test_default_engine_uses_module_constants(self):
        engine = FlowAnalyticsEngine()
        assert engine.BULL_Z == 0.5
        assert engine.BEAR_Z == -0.5
        assert engine.STRONG_Z == 1.5
        assert engine.MODERATE_Z == 0.8

    def test_custom_engine_respects_overrides(self):
        engine = FlowAnalyticsEngine(
            bull_z=0.8, bear_z=-0.8,
            strong_z=2.0, moderate_z=1.0,
        )
        assert engine.BULL_Z == 0.8
        assert engine.BEAR_Z == -0.8
        assert engine.STRONG_Z == 2.0
        assert engine.MODERATE_Z == 1.0

    def test_stateless_between_calls(self):
        """Two calls with identical inputs produce verdicts with equal
        field values (excluding NaN fields where ``nan != nan`` by
        IEEE semantics — the auto-generated ``__eq__`` propagates
        that, so we compare the non-NaN-bearing fields explicitly)."""
        engine = FlowAnalyticsEngine()
        results = [
            _forge_result("A", CommodityCategory.ENERGY, 1.0, 1.0, 1.0),
            _forge_result("B", CommodityCategory.INDUSTRIAL, -0.5, -0.5, -0.5),
        ]
        v1 = engine.compute_verdict(results)
        v2 = engine.compute_verdict(results)
        # Non-NaN scalar fields
        assert v1.label == v2.label
        assert v1.color == v2.color
        assert v1.strength == v2.strength
        assert v1.reasons == v2.reasons
        assert v1.movers_up == v2.movers_up
        assert v1.movers_down == v2.movers_down
        assert v1.bulls_count == v2.bulls_count
        assert v1.bears_count == v2.bears_count
        assert v1.total_count == v2.total_count
        # Category stats: compare by category + counts (skip mean_z
        # when NaN since nan != nan).
        for c1, c2 in zip(v1.by_category, v2.by_category):
            assert c1.category == c2.category
            assert c1.total == c2.total
            assert c1.bulls == c2.bulls
            assert c1.bears == c2.bears
            if c1.mean_z == c1.mean_z:    # non-NaN
                assert c1.mean_z == c2.mean_z


# ══════════════════════════════════════════════════════════════════════
# REBOUND tag — the commodity mean-reversion signal
# ══════════════════════════════════════════════════════════════════════

class TestRebound:
    """REBOUND fires when ``z_60d < -2`` AND vol regime is not volatile.
    Research from scripts/run_commodity_flow_research_v2.py validated
    this across 4 subsets (Agricultural category + calm/normal regimes)
    with effect sizes of +1.35 to +3.55pp forward-return and t>3."""

    def test_fires_on_z60_below_threshold_in_calm_regime(self):
        r = _forge_result("A", CommodityCategory.ENERGY, 0.0, 0.0, -2.5)
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "calm")
        assert fires is True

    def test_fires_on_z60_below_threshold_in_normal_regime(self):
        r = _forge_result("A", CommodityCategory.ENERGY, 0.0, 0.0, -2.5)
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "normal")
        assert fires is True

    def test_does_not_fire_in_volatile_regime(self):
        """The critical gate: in volatile regimes the signal flips
        sign (research showed -0.80pp t=-2.18). Tag must not fire."""
        r = _forge_result("A", CommodityCategory.ENERGY, 0.0, 0.0, -2.5)
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "volatile")
        assert fires is False

    def test_does_not_fire_in_unknown_regime(self):
        """When we can't classify the regime (insufficient history),
        the tag refuses to fire — conservative default."""
        r = _forge_result("A", CommodityCategory.ENERGY, 0.0, 0.0, -2.5)
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "unknown")
        assert fires is False

    def test_does_not_fire_when_z60_above_threshold(self):
        r = _forge_result("A", CommodityCategory.ENERGY, 0.0, 0.0, -1.5)
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "calm")
        assert fires is False

    def test_does_not_fire_when_z60_is_nan(self):
        """Pre-warmup instrument (insufficient history → NaN z-scores)
        must not trigger the tag even in calm regime."""
        r = _forge_result(
            "A", CommodityCategory.ENERGY, 0.0, 0.0, float("nan"),
        )
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "calm")
        assert fires is False

    def test_fires_exactly_at_threshold_does_not_fire(self):
        """Strict inequality: z_60d must be STRICTLY less than -2."""
        r = _forge_result("A", CommodityCategory.ENERGY, 0.0, 0.0, -2.0)
        fires = FlowAnalyticsEngine._should_fire_rebound(r, "calm")
        assert fires is False


# ══════════════════════════════════════════════════════════════════════
# Vol regime classification
# ══════════════════════════════════════════════════════════════════════

class TestVolRegime:
    """The regime classifier computes panel-wide 60d realized vol,
    compares against a 500-day tercile distribution, and returns
    one of calm / normal / volatile / unknown."""

    @staticmethod
    def _synthetic_panel(
        n_days: int = 800, n_tickers: int = 5,
        *, noise_scale: float = 0.01, seed: int = 0,
    ) -> dict:
        """Build a synthetic commodity panel with controllable
        volatility. Each ticker gets a simple random-walk close
        series with per-day log-returns drawn from N(0, noise_scale).
        """
        import numpy as np
        rng = np.random.default_rng(seed)
        idx = pd.bdate_range("2020-01-01", periods=n_days)
        panel = {}
        for i in range(n_tickers):
            log_rets = rng.normal(0, noise_scale, n_days)
            closes = 100 * np.cumprod(np.exp(log_rets))
            panel[f"T{i}=F"] = pd.DataFrame(
                {"Close": closes, "Volume": 1e6}, index=idx,
            )
        return panel

    def test_empty_panel_returns_unknown(self):
        assert (
            FlowAnalyticsEngine._compute_vol_regime({}, asof_date=None)
            == "unknown"
        )

    def test_insufficient_history_returns_unknown(self):
        panel = self._synthetic_panel(n_days=100)   # way below 500
        regime = FlowAnalyticsEngine._compute_vol_regime(
            panel, asof_date=None,
        )
        assert regime == "unknown"

    def test_classifies_to_one_of_three_labels_with_enough_history(self):
        """With 800 days of synthetic data, the regime must classify
        as calm/normal/volatile — never unknown."""
        panel = self._synthetic_panel(n_days=800)
        regime = FlowAnalyticsEngine._compute_vol_regime(
            panel, asof_date=None,
        )
        assert regime in ("calm", "normal", "volatile")

    def test_asof_date_respected(self):
        """When asof_date is provided, only bars up to that date are
        used for the vol calculation. Regime at a historical date
        should be classifiable without leakage from later bars."""
        panel = self._synthetic_panel(n_days=800)
        asof = pd.Timestamp("2021-06-01")
        regime = FlowAnalyticsEngine._compute_vol_regime(
            panel, asof_date=asof,
        )
        # May be unknown if insufficient history before asof, but
        # should never raise.
        assert regime in ("calm", "normal", "volatile", "unknown")


# ══════════════════════════════════════════════════════════════════════
# End-to-end — analyze() wiring
# ══════════════════════════════════════════════════════════════════════

class TestAnalyzeWithRebound:
    """The analyze() pipeline wires regime + rebound enrichment
    together. Verifies the full flow produces results with is_rebound
    set correctly AND a vol_regime label on the bundle."""

    def test_analyze_attaches_vol_regime_to_result(self):
        engine = FlowAnalyticsEngine()
        # Use real universe tickers so detect_flows can match them
        panel = {}
        import numpy as np
        rng = np.random.default_rng(42)
        idx = pd.bdate_range("2020-01-01", periods=800)
        for instr in COMMODITY_UNIVERSE[:5]:    # first 5 is enough
            log_rets = rng.normal(0, 0.01, 800)
            closes = 100 * np.cumprod(np.exp(log_rets))
            panel[instr.ticker] = pd.DataFrame(
                {"Close": closes, "Volume": 1e6}, index=idx,
            )
        result = engine.analyze(panel=panel)
        assert result.vol_regime in ("calm", "normal", "volatile", "unknown")

    def test_analyze_attaches_is_rebound_per_instrument(self):
        """Every MacroFlowResult in the bundle has is_rebound set —
        False by default on the dataclass, but should be a real bool
        (not None) after engine.analyze() runs."""
        engine = FlowAnalyticsEngine()
        panel = {}
        import numpy as np
        rng = np.random.default_rng(7)
        idx = pd.bdate_range("2020-01-01", periods=800)
        for instr in COMMODITY_UNIVERSE[:3]:
            log_rets = rng.normal(0, 0.01, 800)
            closes = 100 * np.cumprod(np.exp(log_rets))
            panel[instr.ticker] = pd.DataFrame(
                {"Close": closes, "Volume": 1e6}, index=idx,
            )
        result = engine.analyze(panel=panel)
        for r in result.results:
            assert isinstance(r.is_rebound, bool)

    def test_analyze_with_empty_panel_does_not_raise(self):
        engine = FlowAnalyticsEngine()
        result = engine.analyze(panel={})
        assert result.vol_regime == "unknown"
        assert len(result.results) == 0
