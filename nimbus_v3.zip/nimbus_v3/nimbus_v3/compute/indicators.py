"""nimbus_v3.compute.indicators — canonical stateless indicator math.

Every indicator used in the slim profile lives here, in exactly one
place. The Market Pulse tab, the BB ride classifier, the dashboard
chart overlay, and any future research script all read the resulting
columns; none of them recompute.

Function contract
─────────────────
Each public function takes a DataFrame with at minimum the OHLCV
columns (``Open``, ``High``, ``Low``, ``Close``, ``Volume``) indexed
by a ``DatetimeIndex``, and returns a **new** DataFrame with the
indicator columns added. Input is never mutated.

Numerical conventions
─────────────────────
- BBW is (upper − lower) / mid in percent.
- BBW percentile is a rolling percentile over 100 bars, in percent (0–100).
- ATR is Wilder's smoothing; ATR% is ATR / close × 100.

Slim profile (post-refactor)
────────────────────────────
The retained surface is intentionally minimal: ``add_moving_averages``,
``add_atr``, ``add_bollinger``, ``add_bollinger_bandwidth``,
``add_data_sufficiency``. Earlier helpers (Williams %R, RSI, MFI, ADX,
drawdowns, streaks, volume_ratio, ROC, position-vs-MA flags) were
research-era artefacts; deleted because nothing on the live path
reads them anymore.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# ══════════════════════════════════════════════════════════════════════════════
# OHLCV validation
# ══════════════════════════════════════════════════════════════════════════════

_OHLCV_COLUMNS = ("Open", "High", "Low", "Close", "Volume")


def _require_ohlcv(df: pd.DataFrame) -> None:
    """Raise if the required OHLCV columns are absent. Shared precondition."""
    missing = [c for c in _OHLCV_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"DataFrame is missing required OHLCV column(s): {missing}. "
            f"Present columns: {list(df.columns)}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# Moving averages
# ══════════════════════════════════════════════════════════════════════════════

def add_moving_averages(
    df: pd.DataFrame,
    periods: tuple[int, ...] = (20,),
) -> pd.DataFrame:
    """Add ``sma_<N>`` columns for each ``N`` in ``periods``."""
    _require_ohlcv(df)
    out = df.copy()
    close = out["Close"]
    for p in periods:
        out[f"sma_{p}"] = close.rolling(window=p, min_periods=p).mean()
    return out


# ══════════════════════════════════════════════════════════════════════════════
# Average True Range
# ══════════════════════════════════════════════════════════════════════════════

def add_atr(df: pd.DataFrame, period: int = 14) -> pd.DataFrame:
    """Add ``atr_<period>`` (absolute) and ``atr_<period>_pct`` (% of close).

    Uses Wilder's exponential smoothing (alpha = 1/period). The
    `_pct` column is the dimensionless form most useful for cross-
    symbol comparisons (e.g. ATR-trail stop sizing on the Dashboard).
    """
    _require_ohlcv(df)
    out = df.copy()
    high = out["High"]
    low = out["Low"]
    close = out["Close"]
    prev_close = close.shift(1)
    tr = pd.concat(
        [
            (high - low),
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    atr = tr.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    out[f"atr_{period}"] = atr
    out[f"atr_{period}_pct"] = atr / close.replace(0.0, np.nan) * 100.0
    return out


# ══════════════════════════════════════════════════════════════════════════════
# Bollinger Bands
# ══════════════════════════════════════════════════════════════════════════════

def add_bollinger(
    df: pd.DataFrame,
    period: int = 20,
    std_dev: float = 1.0,
    prefix: str = "bb_20_1s",
) -> pd.DataFrame:
    """Add Bollinger Bands at ``std_dev`` standard deviations around the SMA.

    Produces columns:
        ``<prefix>_upper``, ``<prefix>_mid``, ``<prefix>_lower``, ``<prefix>_pct``

    ``<prefix>_pct`` = (close − lower) / (upper − lower), clamped to avoid
    division by zero. Range is typically [0, 1] but can go outside during
    breakouts (e.g. %B > 1 means close is above the upper band).
    """
    _require_ohlcv(df)
    out = df.copy()
    close = out["Close"]
    mid = close.rolling(window=period, min_periods=period).mean()
    std = close.rolling(window=period, min_periods=period).std(ddof=0)
    upper = mid + std_dev * std
    lower = mid - std_dev * std
    band = (upper - lower).replace(0.0, np.nan)
    out[f"{prefix}_upper"] = upper
    out[f"{prefix}_mid"] = mid
    out[f"{prefix}_lower"] = lower
    out[f"{prefix}_pct"] = (close - lower) / band
    return out


def add_bollinger_bandwidth(
    df: pd.DataFrame,
    period: int = 20,
    std_dev: float = 1.0,
    prefix: str = "bb_20_1s",
    slope_window: int = 5,
    pctl_window: int = 100,
) -> pd.DataFrame:
    """Add ``bbw_<prefix-suffix>``, ``bbw_<...>_slope``, ``bbw_<...>_pctl``.

    BBW = (upper − lower) / mid × 100 (in percent).
    Slope = BBW − BBW.shift(``slope_window``).
    Percentile = rolling percentile over ``pctl_window`` bars (0–100).

    Requires the corresponding Bollinger columns (upper/mid/lower).
    The column key is derived from ``prefix``: e.g. ``prefix="bb_20_1s"``
    → ``bbw_20_1s``, ``bbw_20_1s_slope``, ``bbw_20_1s_pctl``.
    """
    out = df.copy()
    upper_col = f"{prefix}_upper"
    lower_col = f"{prefix}_lower"
    mid_col = f"{prefix}_mid"
    for c in (upper_col, lower_col, mid_col):
        if c not in out.columns:
            raise ValueError(
                f"add_bollinger_bandwidth: {c!r} missing; "
                f"call add_bollinger first"
            )
    bbw_key = f"bbw_{prefix.removeprefix('bb_')}"
    bbw = (
        (out[upper_col] - out[lower_col])
        / out[mid_col].replace(0.0, np.nan)
        * 100.0
    )
    out[bbw_key] = bbw
    out[f"{bbw_key}_slope"] = bbw - bbw.shift(slope_window)
    # Rolling percentile rank in percent.
    out[f"{bbw_key}_pctl"] = (
        bbw.rolling(window=pctl_window, min_periods=pctl_window)
        .rank(pct=True)
        * 100.0
    )
    return out


# ══════════════════════════════════════════════════════════════════════════════
# Warmup gate
# ══════════════════════════════════════════════════════════════════════════════

def add_data_sufficiency(df: pd.DataFrame, min_bars: int) -> pd.DataFrame:
    """Add boolean ``data_sufficient`` column.

    True from the ``min_bars``-th bar (0-indexed: bar_index >= min_bars - 1)
    onward. Callers should treat False bars as having unreliable
    long-lookback fields.
    """
    out = df.copy()
    n = len(out)
    flags = np.zeros(n, dtype=bool)
    if n >= min_bars:
        flags[min_bars - 1:] = True
    out["data_sufficient"] = flags
    return out
