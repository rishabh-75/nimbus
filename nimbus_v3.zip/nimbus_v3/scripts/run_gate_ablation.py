"""scripts/run_gate_ablation.py — per-gate forward-return ablation.

For each quality gate in ``classify_phase`` (above_20, ROC_20 floor,
ROC_5 floor, deceleration, distribution, V-recovery), measures whether
the gate's NEUTRAL-routing decision earns its keep empirically.

Question answered
-----------------
When gate G fires and routes a stock from base-phase P to NEUTRAL,
does that stock subsequently UNDERPERFORM the stocks G didn't flag?

If yes → gate is pulling its weight (delta is negative and large,
     t-stat well past ±2).
If no  → gate is noise (delta near zero, t-stat small).
If reversed → gate is harmful (delta positive, t-stat well past +2).
     Should be dropped or re-thresholded.

What it does
------------
1. Loads the same equity panel the main calibration script uses.
2. Computes features identically (reusing ``compute_features`` from
   ``run_phase_calibration``).
3. For each base phase (EUPHORIA, LATE, MID, EARLY) and each gate
   that applies to that phase, splits rows into:
       - fired:   gate evaluated True, stock was routed to NEUTRAL
       - unfired: gate evaluated False, stock kept in the base phase
                  (but may have been routed out by a DIFFERENT gate —
                   we restrict "unfired" to rows the gate under test
                   did NOT flag, regardless of others)
   Then measures mean ``fwd_10d`` return and ``fwd_dd_10d`` drawdown
   for each population.
4. Reports Welch's t-stat on the difference in means. ``|t| >= 2`` is
   the rough bar for "statistically different" (95% CI); with tens of
   thousands of observations this is easy to clear by chance on small
   effects, so we also care about ABSOLUTE delta magnitude. A gate
   that is statistically significant but only moves returns by 5 bps
   isn't worth the code complexity.

How to interpret the output
---------------------------
For each gate row, three numbers matter:

  n_fired       — sample size of the "gate routed this to NEUTRAL"
                  cohort. If tiny (<100), the gate almost never
                  fires and the conclusion is unreliable.
  delta_pp      — percentage-point difference in mean fwd_10d return
                  between fired and unfired cohorts. Negative is
                  good (gate correctly identified underperformers).
                  Positive is BAD (gate is flagging winners).
  t_stat        — Welch's t. Negative of large magnitude = strong
                  evidence the gate works. Positive of large magnitude
                  = strong evidence the gate is harmful.

Run::

    python scripts/run_gate_ablation.py

Writes:
  - ``data/gate_ablation.csv``  — full results table
  - stdout — formatted report
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# Repo root importable when run directly.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nimbus_v3.analysis.trend_phase import (   # noqa: E402
    PhaseThresholds, TrendPhase,
)
from nimbus_v3.research.equity_universe import load_equity_panel   # noqa: E402
from scripts.run_phase_calibration import compute_features, HORIZONS   # noqa: E402


logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("gate_ablation")


# ══════════════════════════════════════════════════════════════════════════════
# Gate definitions
# ══════════════════════════════════════════════════════════════════════════════
#
# Each gate is a named boolean expression over the feature columns, paired
# with the set of base phases it applies to. The `apply_to` set is used to
# filter the population before evaluating the gate: a gate that only applies
# to MID shouldn't be ablated against LATE-tagged rows.
#
# Gates here match the logic in ``classify_phase`` and ``classify_rows`` —
# if those change, this file needs updating to stay in sync.


def build_gate_masks(feats: pd.DataFrame) -> dict[str, np.ndarray]:
    """Build a boolean mask for each individual gate.

    Each mask is True where the gate's condition is satisfied (i.e.
    the gate would fire and route the row to NEUTRAL). The masks are
    evaluated over ALL rows; callers filter by base phase when
    computing ablation statistics.
    """
    close = feats["close"].to_numpy()
    sma_20 = feats["sma_20"].to_numpy()
    roc_5 = feats["roc_5"].to_numpy()
    roc_10 = feats["roc_10"].to_numpy()
    roc_20 = feats["roc_20"].to_numpy()
    vol_chg_20 = feats["vol_chg_20"].to_numpy()

    return {
        # Short-term support broken.
        "above_20":      close <= sma_20,
        # ROC_20 floor (three tiers matching the classifier):
        "roc_20_lt_m3":  roc_20 < -3.0,       # EUPHORIA
        "roc_20_lt_m2":  roc_20 < -2.0,       # LATE, MID
        "roc_20_lt_m1":  roc_20 < -1.0,       # EARLY
        # ROC_5 floors:
        "roc_5_lt_m1":   roc_5 < -1.0,        # MID
        "roc_5_lt_m05":  roc_5 < -0.5,        # EARLY
        # Both recent ROCs negative — trend decelerating in real time.
        "deceleration":  (roc_5 < 0) & (roc_10 < 0),
        # Distribution at extension — weak price on collapsing volume.
        "distribution":  (roc_5 < 0) & (vol_chg_20 < -40.0),
        # V-recovery bounce — large recent ROC_10 with imbalanced ratio.
        "v_recovery": (
            (roc_20 > 0) & (roc_20 < 8.0)
            & (roc_10 > 10.0)
            & (roc_10 > 2.5 * roc_20)
        ),
    }


# Which gates to ablate against which phases. This is intentionally
# BROADER than what the live classifier applies — the ablation is a
# research tool, so we want to test BOTH currently-active gates
# (validating they still earn edge) AND previously-dropped gates
# (checking they should stay dropped).
#
# Current live-classifier gates (post-Apr-2026 ablation):
#   - EUPHORIA: roc_20_lt_m3, distribution
#   - LATE:     roc_20_lt_m2, v_recovery
#   - MID:      none
#   - EARLY:    none
#
# Every other (gate, phase) pair below was tested and rejected — if
# re-running ablation on updated data, verify those stay rejected.
# See data/gate_ablation.csv for the reference numbers.
GATE_TO_PHASES: dict[str, list[str]] = {
    "above_20":     ["MID", "EARLY"],
    "roc_20_lt_m3": ["EUPHORIA"],
    "roc_20_lt_m2": ["LATE", "MID"],
    "roc_20_lt_m1": ["EARLY"],
    "roc_5_lt_m1":  ["MID"],
    "roc_5_lt_m05": ["EARLY"],
    "deceleration": ["MID", "EARLY"],
    "distribution": ["EUPHORIA", "LATE", "MID", "EARLY"],
    "v_recovery":   ["EUPHORIA", "LATE", "MID"],
}


# ══════════════════════════════════════════════════════════════════════════════
# Base phase assignment — same as classify_rows but WITHOUT quality gates
# ══════════════════════════════════════════════════════════════════════════════

def compute_base_phase(
    feats: pd.DataFrame, thresh: PhaseThresholds,
) -> pd.Series:
    """Assign the base phase (pre-quality-gates) for each row.

    This is the phase the row would land in if every quality gate
    were disabled — the starting point for ablation. For rows that
    today route to NEUTRAL via a gate, the base phase tells us
    what they "would have been" without that gate.
    """
    close = feats["close"].to_numpy()
    sma_20 = feats["sma_20"].to_numpy()
    sma_50 = feats["sma_50"].to_numpy()
    roc_5 = feats["roc_5"].to_numpy()
    roc_20 = feats["roc_20"].to_numpy()
    bb_pct = feats["bb_pct"].to_numpy()

    with np.errstate(divide="ignore", invalid="ignore"):
        ext_pct = np.where(
            sma_50 > 0, (close - sma_50) / sma_50 * 100.0, 0.0,
        )
    roc_accel = roc_5 - roc_20
    above_20 = close > sma_20
    above_50 = close > sma_50

    phases = np.full(len(feats), TrendPhase.NEUTRAL.value, dtype=object)
    phases[(~above_50) & (~above_20)] = TrendPhase.DECLINE.value

    in_up = above_50 & (sma_50 > 0)
    euphoria = (
        in_up
        & (ext_pct >= thresh.ext_euphoric)
        & ((roc_accel > 0) | (bb_pct >= thresh.bb_parabolic))
    )
    late = (
        in_up & ~euphoria
        & ((ext_pct >= thresh.ext_mature) | (bb_pct >= thresh.bb_stretched))
    )
    mid = in_up & ~euphoria & ~late & (ext_pct >= thresh.ext_healthy)
    early = in_up & ~euphoria & ~late & ~mid

    phases[euphoria] = TrendPhase.EUPHORIA.value
    phases[late] = TrendPhase.LATE.value
    phases[mid] = TrendPhase.MID.value
    phases[early] = TrendPhase.EARLY.value

    return pd.Series(phases, index=feats.index, name="base_phase")


# ══════════════════════════════════════════════════════════════════════════════
# Statistics
# ══════════════════════════════════════════════════════════════════════════════

def welch_t(a: np.ndarray, b: np.ndarray) -> float:
    """Welch's t-stat for unequal-variance two-sample means.

    Returns ``nan`` when either sample has <2 observations or zero
    variance. We interpret ``|t| >= 2`` as the rough 95% CI bar.
    """
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(va / na + vb / nb)
    if denom == 0 or not np.isfinite(denom):
        return float("nan")
    return float((a.mean() - b.mean()) / denom)


def ablate_gate(
    feats: pd.DataFrame,
    gate_name: str,
    gate_mask: np.ndarray,
    base_phase: pd.Series,
    phase: str,
    fwd_col: str = "fwd_10d",
    dd_col: str = "fwd_dd_10d",
) -> dict:
    """Ablate a single gate against a single base phase.

    Splits rows with ``base_phase == phase`` into:
      - fired:   rows where ``gate_mask`` is True (gate routed to NEUTRAL)
      - unfired: rows where ``gate_mask`` is False (gate didn't fire)

    Measures mean fwd_10d return and fwd_dd_10d drawdown for each,
    and the Welch t-stat on the return difference.

    A well-working gate shows:
      fired mean < unfired mean (the gate flagged underperformers)
      t_stat    negative and large magnitude (statistically meaningful)
    """
    mask_phase = (base_phase.to_numpy() == phase)
    # Intersection with valid forward returns — drop rows where fwd_10d is NaN
    # (end-of-panel rows with no future data).
    fwd = feats[fwd_col].to_numpy()
    dd = feats[dd_col].to_numpy()
    valid = mask_phase & np.isfinite(fwd)

    fired = valid & gate_mask
    unfired = valid & ~gate_mask

    fwd_fired = fwd[fired]
    fwd_unfired = fwd[unfired]
    dd_fired = dd[fired]
    dd_unfired = dd[unfired]

    return {
        "gate": gate_name,
        "phase": phase,
        "n_fired": int(fired.sum()),
        "n_unfired": int(unfired.sum()),
        "fwd10_fired_pct": (
            float(fwd_fired.mean() * 100) if len(fwd_fired) else float("nan")
        ),
        "fwd10_unfired_pct": (
            float(fwd_unfired.mean() * 100) if len(fwd_unfired) else float("nan")
        ),
        "delta_pp": (
            float((fwd_fired.mean() - fwd_unfired.mean()) * 100)
            if len(fwd_fired) and len(fwd_unfired)
            else float("nan")
        ),
        "dd_fired_pct": (
            float(dd_fired.mean() * 100) if len(dd_fired) else float("nan")
        ),
        "dd_unfired_pct": (
            float(dd_unfired.mean() * 100) if len(dd_unfired) else float("nan")
        ),
        "t_stat": welch_t(fwd_fired, fwd_unfired),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════════════

def _verdict(row: dict) -> str:
    """Human-readable verdict on one ablation row.

    Thresholds:
      strong working   — delta <= -0.5pp AND t <= -2
      weak working     — delta <= -0.2pp AND t <= -1.5
      noise            — |delta| <  0.2pp OR |t| < 1
      harmful weak     — delta >= +0.2pp AND t >=  1.5
      harmful strong   — delta >= +0.5pp AND t >=  2
      inconclusive     — otherwise

    Applied only when n_fired >= 100 (else sample too small to judge).
    """
    if row["n_fired"] < 100:
        return "too few fires to judge"
    d, t = row["delta_pp"], row["t_stat"]
    if np.isnan(d) or np.isnan(t):
        return "n/a"
    if d <= -0.5 and t <= -2:
        return "STRONG working"
    if d <= -0.2 and t <= -1.5:
        return "weak working"
    if d >= 0.5 and t >= 2:
        return "STRONG HARMFUL"
    if d >= 0.2 and t >= 1.5:
        return "weak harmful"
    if abs(d) < 0.2 or abs(t) < 1:
        return "noise"
    return "inconclusive"


def print_report(rows: list[dict]) -> None:
    """Pretty-print the ablation table grouped by base phase."""
    hdr = (
        f"{'gate':16s}  {'phase':9s}  {'n_fire':>7s}  {'n_keep':>7s}  "
        f"{'fired%':>8s}  {'kept%':>8s}  {'Δ pp':>8s}  {'dd_f%':>7s}  "
        f"{'dd_k%':>7s}  {'t':>7s}  verdict"
    )
    sep = "─" * len(hdr)
    print("\n" + sep)
    print(hdr)
    print(sep)

    # Group by phase so related rows sit together.
    for phase in ("EUPHORIA", "LATE", "MID", "EARLY"):
        phase_rows = [r for r in rows if r["phase"] == phase]
        if not phase_rows:
            continue
        # Sort within phase by |delta| descending — biggest effects first.
        phase_rows.sort(key=lambda r: (
            -abs(r["delta_pp"]) if not np.isnan(r["delta_pp"]) else 0
        ))
        for r in phase_rows:
            v = _verdict(r)
            fwd_f = r["fwd10_fired_pct"]
            fwd_k = r["fwd10_unfired_pct"]
            d = r["delta_pp"]
            dd_f = r["dd_fired_pct"]
            dd_k = r["dd_unfired_pct"]
            t = r["t_stat"]
            print(
                f"{r['gate']:16s}  {r['phase']:9s}  "
                f"{r['n_fired']:>7,d}  {r['n_unfired']:>7,d}  "
                f"{fwd_f:>+7.3f}  {fwd_k:>+7.3f}  {d:>+7.3f}  "
                f"{dd_f:>+6.2f}  {dd_k:>+6.2f}  {t:>+6.2f}  {v}"
            )
        print(sep)


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Loading equity panel …")
    panel = load_equity_panel(verbose=False)
    log.info("Panel: %d symbols", len(panel))

    all_rows: list[pd.DataFrame] = []
    for sym, df in panel.items():
        feats = compute_features(df)
        if len(feats) < 100:
            continue
        feats["symbol"] = sym
        all_rows.append(feats)

    feats = pd.concat(all_rows, ignore_index=True)
    log.info(
        "Feature table: %d rows across %d symbols",
        len(feats), feats["symbol"].nunique(),
    )

    # Verify required columns present.
    need = {"fwd_10d", "fwd_dd_10d", "roc_10", "vol_chg_20"}
    missing = need - set(feats.columns)
    if missing:
        log.error("Missing feature columns: %s", missing)
        sys.exit(1)

    base = compute_base_phase(feats, PhaseThresholds())
    log.info("Base phase distribution (pre-gates):")
    for ph, n in base.value_counts().items():
        log.info("  %-9s  %8d", ph, n)

    gate_masks = build_gate_masks(feats)

    rows: list[dict] = []
    for gate_name, phases in GATE_TO_PHASES.items():
        mask = gate_masks[gate_name]
        for phase in phases:
            rows.append(ablate_gate(feats, gate_name, mask, base, phase))

    print_report(rows)

    # Also compute the aggregate effect: compare CURRENT (all gates active)
    # vs BASE (no gates). This tells us how much the gates collectively
    # move the phase-level forward returns.
    from scripts.run_phase_calibration import classify_rows
    current = classify_rows(feats, PhaseThresholds())
    print("\n" + "─" * 72)
    print("Aggregate phase-level effect (with all gates active):")
    print("─" * 72)
    print(f"{'phase':10s}  {'n_base':>8s}  {'n_now':>8s}  "
          f"{'fwd10_base%':>12s}  {'fwd10_now%':>11s}  {'Δ pp':>8s}")
    print("─" * 72)
    for phase in ("EARLY", "MID", "LATE", "EUPHORIA", "NEUTRAL", "DECLINE"):
        base_sel = (base.to_numpy() == phase) & np.isfinite(feats["fwd_10d"].to_numpy())
        now_sel = (current.to_numpy() == phase) & np.isfinite(feats["fwd_10d"].to_numpy())
        n_b, n_n = int(base_sel.sum()), int(now_sel.sum())
        if n_b == 0 and n_n == 0:
            continue
        fwd = feats["fwd_10d"].to_numpy()
        base_mean = (fwd[base_sel].mean() * 100) if n_b > 0 else float("nan")
        now_mean = (fwd[now_sel].mean() * 100) if n_n > 0 else float("nan")
        delta = (now_mean - base_mean) if (n_b and n_n) else float("nan")
        print(f"{phase:10s}  {n_b:>8,d}  {n_n:>8,d}  "
              f"{base_mean:>+11.3f}  {now_mean:>+10.3f}  {delta:>+7.3f}")
    print("─" * 72)

    out_df = pd.DataFrame(rows)
    out_path = Path("data/gate_ablation.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    log.info("\nFull table written to %s", out_path)

    # Summary: any harmful or noise gates?
    harmful = [r for r in rows if _verdict(r).startswith("STRONG HARMFUL")]
    noise = [r for r in rows if _verdict(r) == "noise" and r["n_fired"] >= 100]
    if harmful:
        log.warning("\n⚠  %d gate×phase pair(s) flagged as STRONG HARMFUL:", len(harmful))
        for r in harmful:
            log.warning("    %s / %s: delta=%+.2fpp, t=%+.2f",
                        r["gate"], r["phase"], r["delta_pp"], r["t_stat"])
    if noise:
        log.info("\n— %d gate×phase pair(s) flagged as noise (|Δ| < 0.2pp or |t| < 1):",
                 len(noise))
        for r in noise:
            log.info("    %s / %s: delta=%+.2fpp, t=%+.2f",
                     r["gate"], r["phase"], r["delta_pp"], r["t_stat"])
    if not harmful and not noise:
        log.info("\n✓ All gates working (no harmful or noise pairs).")


if __name__ == "__main__":
    main()
