"""Tests for ``nimbus_v3.data.industry_states_cache.IndustryStatesCache``."""
from __future__ import annotations

import os
import pickle
import time
from pathlib import Path

import pytest

from nimbus_v3.data.industry_states_cache import IndustryStatesCache


# ══════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════

@pytest.fixture
def enriched_root(tmp_path) -> Path:
    """An empty 'enriched cache' directory to compare mtimes against.
    The cache stat()s files in this directory, so we create it
    up-front; tests that want freshness-timing control touch files
    inside it directly."""
    root = tmp_path / "enriched" / "e_hash00"
    root.mkdir(parents=True, exist_ok=True)
    return root


@pytest.fixture
def states_cache(enriched_root, tmp_path) -> IndustryStatesCache:
    """Empty states cache, composite schema hash."""
    return IndustryStatesCache(
        enriched_root=enriched_root,
        schema_hash="e_hash00-a_hash00",
        root=tmp_path / "states",
    )


def _fake_states() -> dict:
    """Minimal dict standing in for ``dict[str, IndustryRelativeState]``.
    The cache is type-agnostic; this suffices to exercise roundtrip."""
    return {
        "SBIN": {"alpha_60d": 2.3, "is_alpha_leader": True},
        "RELIANCE": {"alpha_60d": -0.5, "is_alpha_leader": False},
    }


# ══════════════════════════════════════════════════════════════════════
# Basic flow
# ══════════════════════════════════════════════════════════════════════

class TestBasicGetSet:

    def test_empty_cache_returns_none(self, states_cache):
        assert states_cache.get_if_fresh() is None

    def test_exists_false_on_empty(self, states_cache):
        assert states_cache.exists() is False

    def test_set_then_get_roundtrip(self, states_cache):
        data = _fake_states()
        states_cache.set(data)
        hit = states_cache.get_if_fresh()
        assert hit == data

    def test_exists_true_after_set(self, states_cache):
        states_cache.set(_fake_states())
        assert states_cache.exists() is True

    def test_set_overwrites_existing(self, states_cache):
        states_cache.set({"A": 1})
        states_cache.set({"B": 2})
        assert states_cache.get_if_fresh() == {"B": 2}


# ══════════════════════════════════════════════════════════════════════
# Freshness detection
# ══════════════════════════════════════════════════════════════════════

class TestFreshness:

    def test_fresh_when_enriched_dir_older(
        self, enriched_root, states_cache,
    ):
        """If no file in the enriched dir is newer than the cache
        file, the cache is fresh."""
        # Create some files in enriched_root, then the cache after —
        # cache should be fresh.
        (enriched_root / "SYM1.parquet").write_bytes(b"x")
        (enriched_root / "SYM2.parquet").write_bytes(b"x")
        time.sleep(0.02)
        states_cache.set(_fake_states())

        hit = states_cache.get_if_fresh()
        assert hit is not None

    def test_stale_when_enriched_file_newer(
        self, enriched_root, states_cache,
    ):
        """If any enriched file has a strictly-later mtime than the
        cache file, the cache is stale."""
        states_cache.set(_fake_states())
        # Touch a file in enriched_root with a mtime strictly after
        # the cache file.
        target = enriched_root / "RECENT.parquet"
        target.write_bytes(b"x")
        cache_mtime = states_cache.file_path.stat().st_mtime
        os.utime(target, (cache_mtime + 1, cache_mtime + 1))

        hit = states_cache.get_if_fresh()
        assert hit is None

    def test_fresh_when_enriched_dir_empty(
        self, states_cache,
    ):
        """An empty enriched directory has no files — so no newer
        mtime can exist. The cache remains fresh."""
        states_cache.set(_fake_states())
        hit = states_cache.get_if_fresh()
        assert hit is not None

    def test_fresh_when_enriched_dir_missing(
        self, tmp_path,
    ):
        """If the enriched directory itself doesn't exist, no freshness
        check can be made — the cached value is still returned (caller
        decides whether it's meaningful)."""
        # Point at a non-existent enriched dir
        c = IndustryStatesCache(
            enriched_root=tmp_path / "does_not_exist",
            schema_hash="x-y",
            root=tmp_path / "states",
        )
        c.set(_fake_states())
        hit = c.get_if_fresh()
        assert hit is not None


# ══════════════════════════════════════════════════════════════════════
# Schema-hash namespacing
# ══════════════════════════════════════════════════════════════════════

class TestSchemaNamespacing:

    def test_different_schema_hashes_are_isolated(
        self, enriched_root, tmp_path,
    ):
        """Two caches with different schema hashes don't share a
        pickle file. Writing to one produces no hit in the other."""
        root = tmp_path / "states"
        c1 = IndustryStatesCache(
            enriched_root=enriched_root,
            schema_hash="v1hash00", root=root,
        )
        c2 = IndustryStatesCache(
            enriched_root=enriched_root,
            schema_hash="v2hash00", root=root,
        )
        c1.set({"v1": "data"})
        assert c2.get_if_fresh() is None
        assert c1.get_if_fresh() == {"v1": "data"}

    def test_schema_hash_property_exposes_value(
        self, enriched_root, tmp_path,
    ):
        c = IndustryStatesCache(
            enriched_root=enriched_root,
            schema_hash="deadbeef-cafe1234",
            root=tmp_path / "states",
        )
        assert c.schema_hash == "deadbeef-cafe1234"


# ══════════════════════════════════════════════════════════════════════
# Corruption handling
# ══════════════════════════════════════════════════════════════════════

class TestCorruption:

    def test_corrupt_pickle_returns_none_and_removes_file(
        self, states_cache,
    ):
        # Write garbage bytes in place of a pickle file
        states_cache.file_path.write_bytes(b"\x00\x01not_a_pickle")
        result = states_cache.get_if_fresh()
        assert result is None
        # The corrupt file should have been removed
        assert not states_cache.file_path.is_file()


# ══════════════════════════════════════════════════════════════════════
# Real-world integration with analytics_schema_hash
# ══════════════════════════════════════════════════════════════════════

class TestAnalyticsSchemaHash:
    """Verify IndustryAnalyticsEngine produces a stable hash."""

    def test_hash_is_stable_across_calls(self):
        from nimbus_v3.compute.industry_analytics import (
            IndustryAnalyticsEngine,
        )
        h1 = IndustryAnalyticsEngine.analytics_schema_hash()
        h2 = IndustryAnalyticsEngine.analytics_schema_hash()
        assert h1 == h2

    def test_hash_length_and_format(self):
        from nimbus_v3.compute.industry_analytics import (
            IndustryAnalyticsEngine,
        )
        h = IndustryAnalyticsEngine.analytics_schema_hash()
        assert len(h) == 8
        assert all(c in "0123456789abcdef" for c in h)
