"""Market Pulse research-report generator.

Culminates every Market Pulse view — regime, confluence, edge, seasonality
— into one comprehensive Markdown document: a full-board analyst-style
research paper. The intent is twofold: a single place to read the whole
board, and a machine-readable artifact whose parameters and raw numbers are
fully exposed, so the numbers can be independently audited (fed to an LLM
to check internal consistency and hunt for statistical loopholes).

Design choices:

* **Markdown** — renders for humans, feeds back to an LLM cleanly.
* **Full board** — every industry, every edge symbol, no truncation. It is
  meant to be comprehensive, not a highlight reel.
* **Parameter appendix** — every constant that shaped the numbers
  (lookbacks, κ, gate floors, ADTV bounds) is listed, so the output is
  reproducible and the derivations are transparent.
* **No auto-flagging** — the report states the numbers faithfully and does
  NOT editorialise about which are weak; that judgement is left to the
  reader, so the report doesn't bias where attention goes.

Stateless: takes already-computed results, returns a string. Writes
nothing itself.
"""
from __future__ import annotations

from datetime import datetime

from nimbus_v3.compute import market_pulse_config as cfg
from nimbus_v3.compute.confluence import ConfluenceResult
from nimbus_v3.compute.equity_edge import EdgeResult
from nimbus_v3.compute.industry_rotation import RotationResult
from nimbus_v3.compute.industry_seasonality import SeasonalityGrid

_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def _f(v: float, fmt: str = "{:+.2f}") -> str:
    """Format a float, or an em-dash for NaN/None."""
    if v is None or v != v:
        return "—"
    return fmt.format(v)


def _table(headers: list[str], rows: list[list[str]]) -> str:
    """Render a Markdown table."""
    out = ["| " + " | ".join(headers) + " |",
           "| " + " | ".join("---" for _ in headers) + " |"]
    for r in rows:
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)


def _header(
    universe_size: int,
    n_industries: int,
    month: int,
    data_asof: str | None,
) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    asof = data_asof or "—"
    return (
        f"# Nimbus · Market Pulse Research Report\n\n"
        f"*Generated {now} · data as of {asof} · "
        f"{universe_size} symbols across {n_industries} industries · "
        f"actionable month: {_MONTHS[month - 1]}*\n\n"
        f"> This report is a faithful dump of what the Market Pulse engines "
        f"computed. Every parameter that shaped the numbers is listed in the "
        f"Parameters appendix, so the figures are reproducible and the "
        f"derivations auditable. It deliberately does **not** editorialise "
        f"about which numbers are weak — that judgement is left to the "
        f"reader.\n"
    )


def _regime_section(conf: ConfluenceResult, market_breadth: float | None) -> str:
    mb = (f"{market_breadth * 100:.0f}%"
          if market_breadth is not None and market_breadth == market_breadth
          else "—")
    lines = [
        "## 1 · Market regime\n",
        f"- **Regime:** {conf.regime_label} "
        f"({conf.regime_signals_on}/{conf.regime_n_signals} signals on)",
        f"- **Universe breadth (% above SMA50):** {mb}",
        "",
        "Regime is context for the confluence read — it does not scale "
        "individual scores. Breadth here is the market-wide reference the "
        "per-industry breadth gate is judged against.\n",
    ]
    return "\n".join(lines)


def _confluence_section(conf: ConfluenceResult) -> str:
    headers = ["#", "Industry", "Score", "Confidence", "Strength",
               "Str Rank", "Breadth", "Direction", "Dir Score",
               "Seasonal", "Sea Rank", "Sea Reliab", "Members"]
    rows = []
    for i, r in enumerate(conf.rows, 1):
        rows.append([
            str(i), r.industry, _f(r.score, "{:.1f}"),
            _f(r.confidence * 100, "{:.0f}"),
            _f(r.strength.value), _f(r.strength.percentile, "{:.0f}"),
            (_f(r.breadth * 100, "{:.0f}") if r.breadth == r.breadth
             else "—"),
            r.direction.detail or "—",
            _f(r.direction.percentile, "{:.0f}"),
            _f(r.seasonal.value), _f(r.seasonal.percentile, "{:.0f}"),
            _f(r.seasonal.confidence * 100, "{:.0f}"),
            str(r.n_members),
        ])
    return (
        "## 2 · Confluence — rotation candidates\n\n"
        "Industries ranked by cross-view confluence. Score = strength "
        "percentile × direction gate × seasonal gate × breadth gate "
        "(+ a small elite-seasonal lift). Confidence is the gate product "
        "(how much all factors corroborate). A top score needs strength, "
        "favourable direction, a trustworthy seasonal, and broad "
        "participation to agree.\n\n"
        + _table(headers, rows) + "\n"
    )


def _edge_section(edge: EdgeResult) -> str:
    headers = ["#", "Symbol", "Industry", "Exp Edge %", "Reward/Risk",
               "Chg", "Chg5d%", "Chg10d%", "RS Excess %", "Trust",
               "Member Shift %", "ATR %", "ADTV ₹cr", "Liq Gate", "Conf",
               "Vol", "Vol vs Peers"]
    rows = []
    for i, r in enumerate(edge.rows, 1):
        rows.append([
            str(i), r.symbol, r.industry,
            _f(r.expected_edge), _f(r.reward_to_risk, "{:+.3f}"),
            _f(r.chg_1d), _f(r.chg_5d), _f(r.chg_10d),
            _f(r.industry_rs_excess, "{:+.1f}"),
            _f(r.trust * 100, "{:.0f}"),
            _f(r.member_shift),
            _f(r.atr_pct, "{:.2f}"),
            (_f(r.adtv / 1e7, "{:.0f}") if r.adtv == r.adtv else "—"),
            _f(r.liquidity_gate, "{:.2f}"),
            _f(getattr(r, "confirmation", 1.0), "{:.2f}"),
            _f(getattr(r, "vol_ratio", float("nan")), "{:.2f}"),
            _f(getattr(r, "vol_shift", float("nan")), "{:.2f}"),
        ])
    return (
        "## 3 · Edge — momentum-implied expected excess return\n\n"
        f"Per-symbol expected return in excess of the benchmark over "
        f"{edge.horizon_days}d, shrunk by momentum-persistence "
        f"(κ={edge.kappa:.2f}) and confluence trust, then by a liquidity "
        f"gate; ranked by reward-to-risk (edge ÷ ATR%). **This is a "
        f"momentum estimate, NOT a valuation risk premium** — it inherits "
        f"every limitation of momentum (regime-dependence, reversal risk). "
        f"μ̂ = (κ · RS_excess · trust + κ · tilt · member_excess · trust) · "
        f"liquidity_gate · confirmation.\n\n"
        f"**Conf** is the member-participation haircut: the industry edge is "
        f"identical for every member, so a name sitting still (no band-ride "
        f"streak, no volume surge, no thrust) is discounted rather than "
        f"inheriting the full industry edge. NOTE: this gate makes the board "
        f"a more honest description of what is moving, but walk-forward "
        f"tests showed NO improvement in forward returns — treat the "
        f"ordering as rotation context, not an alpha signal.\n\n"
        f"**Vol** is self-relative (volume / its own 20-bar mean); "
        f"**Vol vs Peers** divides that by the industry's median, separating "
        f"'this stock is busy' from 'the whole sector is busy'. A blowoff "
        f"above 3x is PENALISED, not rewarded: measured over 1,242 trading "
        f"days, names at >=5x their own average returned -0.85% excess over "
        f"the next 5 days (t=-5.1), with a clean monotonic dose-response. In "
        f"this universe a volume spike is more often distribution than "
        f"accumulation. The effect is real but small — it is here to stop "
        f"the board PROMOTING blowoffs, not to create a tradeable short.\n\n"
        + _table(headers, rows) + "\n"
    )


def _seasonality_section(
    seas: SeasonalityGrid, month: int,
    industries: set[str] | None = None,
) -> str:
    from nimbus_v3.compute.seasonality import seasonal_reliability
    mi = month - 1
    headers = ["Industry", f"{_MONTHS[mi]} Avg %", "Hit %", "σ %",
               "Reliability", "Quality", "Members"]
    rows = []
    for row in seas.rows:
        # Only show industries that are ALSO in the confluence ranking, so
        # the report is internally consistent (no industries here that were
        # filtered out of confluence by MIN_MEMBERS).
        if industries is not None and row.industry not in industries:
            continue
        avg = row.avg_returns[mi]
        if avg != avg:
            continue
        std = row.std_returns[mi]
        rel = seasonal_reliability(avg, std)
        rows.append([
            row.industry,
            _f(avg), _f(row.hit_rates[mi], "{:.0f}"),
            _f(std, "{:.1f}"),
            _f(rel * 100, "{:.0f}") if rel == rel else "—",
            _f(row.seasonal_quality[mi], "{:.2f}"),
            str(row.cell_n_members[mi]),
        ])
    # Sort by current-month avg return descending.
    rows.sort(key=lambda x: (x[1] == "—", -_num(x[1])))
    return (
        f"## 4 · Seasonality — {_MONTHS[mi]} edge by industry\n\n"
        f"Historical calendar tendency for the actionable month. Avg = mean "
        f"monthly return; Hit = share of years positive; σ = dispersion; "
        f"Reliability = SNR-based confidence; Quality = member-lumpiness-"
        f"aware quality (weight-aware member reliability × concentration). "
        f"Sorted by average return.\n\n"
        + _table(headers, rows) + "\n"
    )


def _num(s: str) -> float:
    try:
        return float(s.replace("+", "").replace("%", ""))
    except (ValueError, AttributeError):
        return float("-inf")


def _parameters_section(edge: EdgeResult) -> str:
    return (
        "## 5 · Parameters appendix\n\n"
        "Every constant that shaped the numbers above. The figures are "
        "reproducible from these plus the price panel.\n\n"
        "### Lookbacks (horizons)\n\n"
        + _table(["Parameter", "Value", "Meaning"], [
            ["STRENGTH_LOOKBACK", f"{cfg.STRENGTH_LOOKBACK}d",
             "ROC window for the strength factor (rotation-speed dial)"],
            ["RRG_LOOKBACK", f"{cfg.RRG_LOOKBACK}d",
             "RS-series window for the direction (RRG) factor"],
        ]) + "\n\n"
        "### Edge model\n\n"
        + _table(["Parameter", "Value", "Meaning"], [
            ["EDGE_PERSISTENCE_KAPPA", f"{cfg.EDGE_PERSISTENCE_KAPPA:.2f}",
             "Momentum persistence haircut κ (trailing RS mean-reverts)"],
            ["EDGE_MEMBER_TILT", f"{cfg.EDGE_MEMBER_TILT:.2f}",
             "Strength of the within-industry member shift"],
            ["EDGE_MIN_ATR_PCT", f"{cfg.EDGE_MIN_ATR_PCT:.2f}",
             "Floor on the ATR% reward-to-risk denominator"],
            ["EDGE_ADTV_FLOOR",
             f"₹{cfg.EDGE_ADTV_FLOOR / 1e7:.0f}cr",
             "ADTV at/below which liquidity gate is fully floored"],
            ["EDGE_ADTV_CEILING",
             f"₹{cfg.EDGE_ADTV_CEILING / 1e7:.0f}cr",
             "ADTV at/above which liquidity gate is 1.0 (no discount)"],
            ["EDGE_LIQUIDITY_FLOOR", f"{cfg.EDGE_LIQUIDITY_FLOOR:.2f}",
             "Floor of the liquidity gate (thin-name edge retention)"],
            ["edge horizon", f"{edge.horizon_days}d",
             "Horizon the expected edge is expressed over"],
        ]) + "\n\n"
        "### Confluence gates\n\n"
        "Direction gates {Leading/Improving 1.00, Weakening 0.55, "
        "Lagging 0.35, Extended capped 0.75}; seasonal gate floor 0.20 "
        "(near-veto); breadth gate floor 0.60, spread 30pp (market-"
        "relative). Values are hard-coded constants in `confluence.py`; see "
        "that module for the full derivation.\n"
    )


def generate_report(
    confluence: ConfluenceResult,
    rotation: RotationResult,
    edge: EdgeResult,
    seasonality: SeasonalityGrid,
    month: int,
    *,
    universe_size: int,
    market_breadth: float | None = None,
    data_asof: str | None = None,
) -> str:
    """Build the full Market Pulse research report as Markdown.

    Args:
        confluence: the confluence result (industry ranking + factors).
        rotation: the rotation result (for industry count).
        edge: the per-symbol edge result.
        seasonality: the seasonality grid (current-month edge read).
        month: actionable month 1..12.
        universe_size: number of symbols in the panel.
        market_breadth: universe-wide breadth (0..1) for the regime line.
        data_asof: human string for data freshness (e.g. last bar date).

    Returns:
        A Markdown document string.
    """
    n_ind = len(rotation.industries) if rotation is not None else \
        len(confluence.rows)
    conf_industries = {r.industry for r in confluence.rows}
    parts = [
        _header(universe_size, n_ind, month, data_asof),
        _regime_section(confluence, market_breadth),
        _confluence_section(confluence),
        _edge_section(edge),
        _seasonality_section(seasonality, month, conf_industries),
        _parameters_section(edge),
        "\n---\n*Nimbus v3 · Market Pulse · generated report. Momentum & "
        "technical signals only — no fundamental / valuation inputs. "
        "Validate against realised returns before trading.*\n",
    ]
    return "\n\n".join(parts)
