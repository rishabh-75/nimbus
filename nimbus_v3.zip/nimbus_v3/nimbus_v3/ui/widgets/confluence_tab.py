"""nimbus_v3.ui.widgets.confluence_tab — cross-view confluence table.

The lead Market-Pulse sub-tab: a single ranked read of where the four
views agree on rotation candidates. Pure renderer over
``compute.confluence.compute_confluence`` — it computes nothing, it only
displays the ranked result and routes clicks to the breakdown views.

Layout:
  * A regime banner across the top (context, not a gate — the engine does
    not let regime scale scores; the banner just frames the read).
  * A ranked table: Industry · Score · Confidence, then the three factor
    groups each shown as raw value + percentile + confidence, so the
    composite is fully auditable — you can see WHY each industry ranks
    where it does. A clicked row emits ``industry_activated`` so the
    container can jump to that industry in the RRG / Seasonality views.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.confluence import ConfluenceResult
from nimbus_v3.compute.horizon_views import HorizonSet
from nimbus_v3.compute.market_pulse_config import (
    DEFAULT_EDGE_HORIZON,
    EDGE_HORIZONS,
)
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, EM, FONT_MONO, GOLD, GREEN, MUTED, RED,
    S2, WHITE,
)


def _score_color(score: float) -> QColor:
    """Green (high) → grey (mid) → red (low) for the composite score."""
    if score != score:
        return QColor(S2)
    t = max(0.0, min(1.0, score / 100.0))
    if t >= 0.5:
        # grey → green
        f = (t - 0.5) * 2.0
        base = QColor(S2)
        tgt = QColor(EM)
    else:
        f = (0.5 - t) * 2.0
        base = QColor(S2)
        tgt = QColor(RED)
    r = int(base.red() + (tgt.red() - base.red()) * f)
    g = int(base.green() + (tgt.green() - base.green()) * f)
    b = int(base.blue() + (tgt.blue() - base.blue()) * f)
    return QColor(r, g, b)


def _conf_color(conf: float) -> QColor:
    """Grey (low confidence) → blue (high) — trust, not direction."""
    if conf != conf:
        return QColor(MUTED)
    t = max(0.0, min(1.0, conf))
    base = QColor(MUTED)
    tgt = QColor(BLUE)
    r = int(base.red() + (tgt.red() - base.red()) * t)
    g = int(base.green() + (tgt.green() - base.green()) * t)
    b = int(base.blue() + (tgt.blue() - base.blue()) * t)
    return QColor(r, g, b)


class _NumItem(QTableWidgetItem):
    """Table item that sorts by a stored numeric value, not display text."""
    def __lt__(self, other: "QTableWidgetItem") -> bool:
        a = self.data(Qt.ItemDataRole.UserRole)
        b = other.data(Qt.ItemDataRole.UserRole)
        try:
            af = float(a)
            bf = float(b)
        except (TypeError, ValueError):
            return super().__lt__(other)
        if af != af:
            return True
        if bf != bf:
            return False
        return af < bf


class ConfluenceTab(QWidget):
    """Ranked cross-view confluence table with a regime context banner."""

    #: Emitted with the industry name when a row is activated (clicked),
    #: so the container can jump to that industry in a breakdown view.
    industry_activated = pyqtSignal(str)
    #: Emitted when the user picks a strength horizon HERE. The parent owns
    #: the horizon and applies it to every tab, so Confluence Strength and
    #: Edge RS Excess — which are the SAME quantity — can never disagree.
    horizon_changed = pyqtSignal(int)

    _COLS = (
        "Industry", "Score", "Confidence",
        "Strength", "Strength Rank", "Breadth",
        "Direction", "Direction Score",
        "Seasonal", "Seasonal Rank", "Seasonal Reliability",
        "Members",
    )

    _MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        self._title = QLabel("CONFLUENCE · rotation candidates")
        self._title.setFont(QFont(FONT_MONO, 11, QFont.Weight.Bold))
        self._title.setStyleSheet(f"color: {WHITE}; letter-spacing: 1px;")

        # ≥3y-members toggle — defaults ON, so the seasonal factor uses the
        # stable (≥3y) grid: thin-history industries don't inflate the
        # seasonal read. Flipping it swaps between two precomputed
        # confluence results (no recompute).
        self._stable_only = True
        self._btn_stable = QPushButton("≥3y members")
        self._btn_stable.setFont(QFont(FONT_MONO, 9))
        self._btn_stable.setCheckable(True)
        self._btn_stable.setChecked(True)
        self._btn_stable.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_stable.setStyleSheet(_TOGGLE_QSS)
        self._btn_stable.setToolTip(
            "Use the ≥3-year-members seasonality grid for the seasonal "
            "factor, so industries with thin history don't inflate the "
            "ranking. On by default.")
        self._btn_stable.clicked.connect(self._toggle_stable)

        # Strength-horizon toggle. STRENGTH is the base magnitude the whole
        # score multiplies, so this reorders the board — it is not a display
        # option. Shared with the Edge tab via the parent: the two tabs show
        # the same quantity and must agree on its window.
        self._horizon = DEFAULT_EDGE_HORIZON
        self._btn_horizon: dict[int, QPushButton] = {}
        horizon_row = QHBoxLayout()
        horizon_row.setContentsMargins(0, 0, 0, 0)
        horizon_row.setSpacing(4)
        for h in EDGE_HORIZONS:
            b = QPushButton(f"{h}d")
            b.setFont(QFont(FONT_MONO, 9))
            b.setCheckable(True)
            b.setChecked(h == self._horizon)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(_TOGGLE_QSS)
            b.setToolTip(
                f"Measure STRENGTH over {h} trading days. Strength is the "
                f"base magnitude the score multiplies, so this re-ranks the "
                f"board. Direction (RRG, 50d), seasonality and breadth are "
                f"unaffected — they do not depend on this window. Shared "
                f"with the Edge tab.")
            b.clicked.connect(
                lambda _checked=False, hh=h: self._request_horizon(hh))
            self._btn_horizon[h] = b
            horizon_row.addWidget(b)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.addWidget(self._title)
        title_row.addStretch(1)
        title_row.addLayout(horizon_row)
        title_row.addSpacing(10)
        title_row.addWidget(self._btn_stable)
        root.addLayout(title_row)

        self._subtitle = QLabel("")
        self._subtitle.setFont(QFont(FONT_MONO, 9))
        self._subtitle.setStyleSheet(f"color: {MUTED};")
        self._subtitle.setWordWrap(True)
        root.addWidget(self._subtitle)

        # Regime banner — context only.
        self._banner = QLabel("")
        self._banner.setFont(QFont(FONT_MONO, 9, QFont.Weight.Bold))
        self._banner.setStyleSheet(
            f"color: {MUTED}; background: {S2}; border: 1px solid {BORDER}; "
            f"padding: 4px 8px;")
        self._banner.setVisible(False)
        root.addWidget(self._banner)

        self._table = QTableWidget()
        self._table.setColumnCount(len(self._COLS))
        self._table.setHorizontalHeaderLabels(self._COLS)
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setSortingEnabled(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(_TABLE_QSS)
        self._table.setShowGrid(False)
        hh = self._table.horizontalHeader()
        # Numeric/label columns size to fit their header+data. The Industry
        # column is held at a fixed, readable width so full names
        # ("Pharmaceuticals & Biotechnology") are never truncated to
        # "Phar…"; if the total exceeds the viewport the table scrolls
        # horizontally (a scrollbar is available).
        hh.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        hh.setMinimumSectionSize(56)
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self._table.setColumnWidth(0, 220)
        self._table.cellDoubleClicked.connect(self._on_cell_activated)
        root.addWidget(self._table, stretch=1)

        self._empty = QLabel("No rotation data yet.")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setVisible(False)
        root.addWidget(self._empty)

        self._rows_cache: tuple = ()
        self._result_all: ConfluenceResult | None = None
        self._result_stable: ConfluenceResult | None = None
        #: The engine's multi-horizon result. When present it supersedes the
        #: single-horizon pair above; the two toggles then select a member of
        #: it (horizon x ≥3y) with no recomputation.
        self._horizon_set: HorizonSet | None = None

    def set_horizon_set(self, horizon_set: HorizonSet | None) -> None:
        """Display an engine-computed multi-horizon result.

        Every combination of (horizon x ≥3y-members) is already built, so
        both toggles are pointer swaps. This view computes nothing and never
        pairs a rotation with a mismatched benchmark — the engine owns that.
        """
        self._horizon_set = horizon_set
        available = set(horizon_set.horizons) if horizon_set else set()
        if horizon_set is not None and self._horizon not in available:
            self._horizon = (horizon_set.default_horizon
                             if horizon_set.default_horizon in available
                             else next(iter(sorted(available)),
                                       self._horizon))
        self._sync_horizon_buttons()
        self._render_active()

    def set_horizon(self, horizon: int) -> None:
        """Apply a horizon chosen elsewhere. Emits nothing (no signal loop)."""
        if horizon == self._horizon:
            self._sync_horizon_buttons()
            return
        self._horizon = horizon
        self._sync_horizon_buttons()
        self._render_active()

    def _request_horizon(self, horizon: int) -> None:
        """A horizon button was clicked — announce it; the parent applies it
        here and to the Edge tab so the two cannot drift apart."""
        if horizon == self._horizon:
            self._sync_horizon_buttons()
            return
        self.horizon_changed.emit(horizon)

    def _sync_horizon_buttons(self) -> None:
        """Keep the horizon group exclusive and reflect the active window."""
        available = (set(self._horizon_set.horizons)
                     if self._horizon_set is not None else set())
        for h, b in self._btn_horizon.items():
            b.setChecked(h == self._horizon)
            b.setEnabled(h in available)

    def set_results(
        self,
        result_all: ConfluenceResult,
        result_stable: ConfluenceResult,
    ) -> None:
        """Store both confluence variants for a SINGLE horizon.

        Back-compatible path for callers and tests that predate the horizon
        set. The horizon buttons are inert here — there is only one window
        to show — so they disable rather than implying a choice.
        """
        self._horizon_set = None
        self._result_all = result_all
        self._result_stable = result_stable
        self._sync_horizon_buttons()
        self._render_active()   # re-mirrors the same pair; harmless

    def _active_pair(self) -> tuple:
        """(all, stable) confluence results for the active horizon."""
        if self._horizon_set is not None:
            view = self._horizon_set.get(self._horizon)
            if view is None:
                return (None, None)
            return (view.confluence_all, view.confluence_stable)
        return (self._result_all, self._result_stable)

    def _render_active(self) -> None:
        result_all, result_stable = self._active_pair()
        # Keep these mirroring whatever is CURRENTLY displayed, so they stay
        # a truthful description of the active read on both the horizon-set
        # and single-horizon paths (external readers and tests rely on it).
        self._result_all, self._result_stable = result_all, result_stable
        active = result_stable if self._stable_only else result_all
        self.set_result(active)

    def _toggle_stable(self) -> None:
        self._stable_only = self._btn_stable.isChecked()
        self._render_active()

    def set_result(self, result: ConfluenceResult) -> None:
        """Render a confluence result. Pure display — no computation."""
        if result is None or not result.has_data:
            self._table.setVisible(False)
            self._empty.setVisible(True)
            self._banner.setVisible(False)
            self._subtitle.setText("")
            return
        self._table.setVisible(True)
        self._empty.setVisible(False)

        month = self._MONTHS[result.month - 1]
        member_note = ("≥3y-members seasonality" if self._stable_only
                       else "all-members seasonality")
        self._subtitle.setText(
            f"strength gated by direction & seasonality ({month}, "
            f"{member_note}) — a top score needs all three to agree · "
            f"score is a RELATIVE standing within today's industries, not "
            f"a forecast · double-click a row to inspect")

        # Regime banner (context, never scores).
        self._render_banner(result)

        self._rows_cache = result.rows
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(result.rows))
        for r, row in enumerate(result.rows):
            self._fill_row(r, row)
        self._table.setSortingEnabled(True)
        self._table.sortItems(1, Qt.SortOrder.DescendingOrder)

    def _render_banner(self, result: ConfluenceResult) -> None:
        label = result.regime_label
        if label in ("", "—"):
            self._banner.setVisible(False)
            return
        tone = {
            "RISK_ON": (GREEN, "leadership broad — conditions favour "
                               "rotating into strength"),
            "NEUTRAL": (GOLD, "mixed breadth — confirm conviction before "
                              "rotating"),
            "RISK_OFF": (RED, "breadth narrow — leadership thin, treat "
                              "scores with extra caution"),
        }.get(label, (MUTED, ""))
        colour, note = tone
        self._banner.setText(
            f"  MARKET REGIME  {label}   "
            f"({result.regime_signals_on}/{result.regime_n_signals} "
            f"signals)   ·   {note}")
        self._banner.setStyleSheet(
            f"color: {colour}; background: {S2}; "
            f"border: 1px solid {BORDER}; border-left: 3px solid {colour}; "
            f"padding: 4px 8px;")
        self._banner.setVisible(True)

    def _fill_row(self, r: int, row) -> None:
        def num(text, sortval, colour=None, align_right=True):
            it = _NumItem()
            it.setData(Qt.ItemDataRole.DisplayRole, text)
            it.setData(Qt.ItemDataRole.UserRole, sortval)
            # All int/float columns are centre-aligned for a clean grid.
            it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if colour is not None:
                it.setForeground(QColor(colour))
            return it

        def txt(text, colour=None, align_left=True, centre=False):
            it = QTableWidgetItem(text)
            if centre:
                it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            elif align_left:
                it.setTextAlignment(Qt.AlignmentFlag.AlignLeft
                                    | Qt.AlignmentFlag.AlignVCenter)
            if colour is not None:
                it.setForeground(QColor(colour))
            return it

        def pct(p):
            return ("—", float("nan")) if p != p else (f"{p:.0f}", p)

        def val(v, fmt):
            return ("—", float("nan")) if v != v else (format(v, fmt), v)

        score_txt, score_v = val(row.score, ".1f")
        si = num(score_txt, score_v)
        si.setForeground(QColor(WHITE))
        si.setBackground(_score_color(row.score))
        si.setFont(QFont(FONT_MONO, 10, QFont.Weight.Bold))

        conf_txt = "—" if row.confidence != row.confidence \
            else f"{row.confidence*100:.0f}"
        ci = num(conf_txt, row.confidence, colour=None)
        ci.setForeground(_conf_color(row.confidence))

        # Factor cells: raw value + percentile + (seasonal) reliability.
        s_val_t, s_val_v = val(row.strength.value, "+.1f")
        s_pct_t, s_pct_v = pct(row.strength.percentile)
        d_val_t = row.direction.detail or "—"
        d_pct_t, d_pct_v = pct(row.direction.percentile)
        z_val_t, z_val_v = val(row.seasonal.value, "+.1f")
        z_pct_t, z_pct_v = pct(row.seasonal.percentile)
        z_rel_t = "—" if row.seasonal.confidence != row.seasonal.confidence \
            else f"{row.seasonal.confidence*100:.0f}"

        # Breadth: % of members above own SMA50. Coloured by the gate that
        # was applied — near 1.0 (broad, no discount) reads neutral/green;
        # a discounted (narrow) move reads amber, so the participation
        # caveat is visible at a glance.
        b = getattr(row, "breadth", float("nan"))
        b_gate = getattr(row, "breadth_gate", 1.0)
        if b != b:
            b_txt, b_val, b_col = "—", float("nan"), MUTED
        else:
            b_txt, b_val = f"{b*100:.0f}", b
            b_col = MUTED if b_gate >= 0.999 else GOLD

        cells = [
            txt(row.industry, WHITE),
            si,
            ci,
            num(s_val_t, s_val_v, GREEN if s_val_v == s_val_v
                and s_val_v >= 0 else RED),
            num(s_pct_t, s_pct_v, MUTED),
            num(b_txt, b_val, b_col),
            txt(d_val_t, _direction_colour(row.direction.percentile),
                centre=True),
            num(d_pct_t, d_pct_v, MUTED),
            num(z_val_t, z_val_v, GREEN if z_val_v == z_val_v
                and z_val_v >= 0 else (RED if z_val_v == z_val_v else MUTED)),
            num(z_pct_t, z_pct_v, MUTED),
            num(z_rel_t, row.seasonal.confidence,
                _conf_color(row.seasonal.confidence)),
            num(str(row.n_members), row.n_members, MUTED),
        ]
        for c, item in enumerate(cells):
            self._table.setItem(r, c, item)

        tip = (
            f"{row.industry}\n"
            f"score {row.score:.0f}/100 · overall confidence "
            f"{row.confidence*100:.0f}%\n"
            f"strength: {row.strength.value:+.1f} "
            f"({row.strength.percentile:.0f} pct)\n"
            f"breadth: {b_txt if b == b else '—'}"
            f"{'%' if b == b else ''} above SMA50"
            f"{f' · gate ×{b_gate:.2f}' if b == b and b_gate < 0.999 else ''}\n"
            f"direction: {row.direction.detail} "
            f"({row.direction.percentile:.0f} pct)\n"
            f"seasonal: {z_val_t} ({z_pct_t} pct, "
            f"{z_rel_t}/100 reliable)")
        for c in range(len(self._COLS)):
            it = self._table.item(r, c)
            if it is not None:
                it.setToolTip(tip)

    def _on_cell_activated(self, row: int, _col: int) -> None:
        item = self._table.item(row, 0)
        if item is not None:
            self.industry_activated.emit(item.text())


def _direction_colour(percentile: float) -> str:
    """Colour the direction label by its desirability percentile."""
    if percentile != percentile:
        return MUTED
    if percentile >= 66:
        return GREEN
    if percentile >= 33:
        return GOLD
    return RED


_TOGGLE_QSS = f"""
QPushButton {{
    background: {S2};
    color: {MUTED};
    border: 1px solid {BORDER};
    border-radius: 3px;
    padding: 3px 10px;
}}
QPushButton:checked {{
    color: {EM};
    border: 1px solid {EM};
}}
QPushButton:hover {{ color: {WHITE}; }}
"""


_TABLE_QSS = f"""
QTableWidget {{
    background: {BG};
    border: 1px solid {BORDER};
    gridline-color: transparent;
    color: {WHITE};
}}
QTableWidget::item {{ padding: 3px 4px; }}
QTableWidget::item:selected {{ background: {S2}; }}
QHeaderView::section:horizontal {{
    background: {S2};
    color: {WHITE};
    border: none;
    padding: 4px 4px;
    font-family: '{FONT_MONO}';
    font-size: 9pt;
    font-weight: bold;
}}
"""
