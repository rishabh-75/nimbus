"""Tests for nimbus_v3.compute.seasonality."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.seasonality import (
    MIN_YEARS,
    compute_seasonality,
)


def _series_from_monthly_returns(monthly_pct: dict[int, float], years: int):
    """Build a daily Close series that yields the given per-month
    returns (approx) across ``years`` years. Each month moves by its
    target pct from the prior month-end."""
    dates = pd.bdate_range("2018-01-01", periods=years * 252)
    close = pd.Series(100.0, index=dates, dtype=float)
    # Apply a step at the first business day of each month.
    level = 100.0
    cur_month = None
    for i, d in enumerate(dates):
        if d.month != cur_month:
            cur_month = d.month
            level *= (1.0 + monthly_pct.get(d.month, 0.0))
        close.iloc[i] = level
    return close


def test_empty_series_has_no_data():
    r = compute_seasonality(pd.Series(dtype=float))
    assert r.n_years == 0
    assert not r.has_data
    assert r.strongest is None
    assert len(r.months) == 12


def test_insufficient_years_flagged():
    dates = pd.bdate_range("2024-01-01", periods=60)
    close = pd.Series(np.linspace(100, 110, 60), index=dates)
    r = compute_seasonality(close)
    assert r.n_years < MIN_YEARS
    assert not r.has_data


def test_strongest_and_weakest_identified():
    # Jul strongly positive, Jan strongly negative, across 5 years.
    monthly = {7: 0.05, 1: -0.04}
    close = _series_from_monthly_returns(monthly, years=5)
    r = compute_seasonality(close)
    assert r.has_data
    assert r.n_years >= MIN_YEARS
    assert r.strongest is not None and r.weakest is not None
    assert r.strongest.month == 7
    assert r.weakest.month == 1


def test_hit_rate_bounds_and_extremes():
    monthly = {3: 0.03, 9: -0.03}
    close = _series_from_monthly_returns(monthly, years=5)
    r = compute_seasonality(close)
    for m in r.months:
        if m.hit_rate == m.hit_rate:    # not NaN
            assert 0.0 <= m.hit_rate <= 100.0
    # A consistently-up month should have the best hit rate; a
    # consistently-down month the worst.
    assert r.best_hit is not None and r.worst_hit is not None
    assert r.best_hit.hit_rate >= r.worst_hit.hit_rate


def test_cumulative_path_length_and_monotone_pieces():
    monthly = {m: 0.01 for m in range(1, 13)}    # +1% every month
    close = _series_from_monthly_returns(monthly, years=5)
    r = compute_seasonality(close)
    assert len(r.cumulative_path) == 12
    # All-positive months → strictly increasing cumulative path.
    path = r.cumulative_path
    assert all(path[i] <= path[i + 1] + 1e-9 for i in range(11))


def test_twelve_months_always_present():
    close = _series_from_monthly_returns({6: 0.02}, years=4)
    r = compute_seasonality(close)
    assert len(r.months) == 12
    assert [m.month for m in r.months] == list(range(1, 13))
    assert [m.label for m in r.months][:3] == ["Jan", "Feb", "Mar"]


def test_month_stat_accessor():
    from nimbus_v3.compute.seasonality import month_stat
    monthly = {6: 0.02}
    close = _series_from_monthly_returns(monthly, years=4)
    r = compute_seasonality(close)
    jun = month_stat(r, 6)
    assert jun is not None
    assert jun.month == 6
    assert jun.label == "Jun"
    # out of range
    assert month_stat(r, 0) is None
    assert month_stat(r, 13) is None
