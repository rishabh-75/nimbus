"""Tests for nimbus_v3.compute.indicators (slim profile).

Covers the surviving five surfaces: ``_require_ohlcv``,
``add_moving_averages``, ``add_atr``, ``add_bollinger``,
``add_bollinger_bandwidth``, and ``add_data_sufficiency``. Earlier
helpers (Williams %R, RSI, MFI, ADX, drawdowns, streaks,
volume_ratio, ROC, position_vs_ma) were research-era and have been
deleted; their tests went with them.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute import indicators as ind


# ══════════════════════════════════════════════════════════════════════════════
# OHLCV validation
# ══════════════════════════════════════════════════════════════════════════════

def test_require_ohlcv_raises_on_missing() -> None:
    df = pd.DataFrame(
        {"Open": [1.0], "High": [1.0], "Low": [1.0], "Close": [1.0]}
    )
    # Missing 'Volume' — exercised via add_moving_averages, which
    # calls _require_ohlcv internally.
    with pytest.raises(ValueError, match="Volume"):
        ind.add_moving_averages(df)


def test_require_ohlcv_passes_when_complete(ohlcv_300) -> None:
    # Should not raise.
    out = ind.add_moving_averages(ohlcv_300, periods=(20,))
    assert "sma_20" in out.columns


# ══════════════════════════════════════════════════════════════════════════════
# Moving averages
# ══════════════════════════════════════════════════════════════════════════════

def test_sma_values_against_manual_compute(ohlcv_300) -> None:
    out = ind.add_moving_averages(ohlcv_300, periods=(20,))
    expected_last = ohlcv_300["Close"].iloc[-20:].mean()
    assert out["sma_20"].iloc[-1] == pytest.approx(expected_last)


def test_sma_warmup_is_nan(ohlcv_300) -> None:
    out = ind.add_moving_averages(ohlcv_300, periods=(20,))
    assert out["sma_20"].iloc[:19].isna().all()
    assert not np.isnan(out["sma_20"].iloc[19])


def test_sma_supports_multiple_periods(ohlcv_300) -> None:
    out = ind.add_moving_averages(ohlcv_300, periods=(10, 50))
    assert "sma_10" in out.columns
    assert "sma_50" in out.columns
    assert out["sma_10"].iloc[:9].isna().all()
    assert out["sma_50"].iloc[:49].isna().all()


# ══════════════════════════════════════════════════════════════════════════════
# ATR
# ══════════════════════════════════════════════════════════════════════════════

def test_atr_columns_present(ohlcv_300) -> None:
    out = ind.add_atr(ohlcv_300, period=14)
    assert "atr_14" in out.columns
    assert "atr_14_pct" in out.columns


def test_atr_is_positive_post_warmup(ohlcv_300) -> None:
    out = ind.add_atr(ohlcv_300, period=14)
    # Wilder's EMA needs `period` bars before the first value.
    assert (out["atr_14"].iloc[14:].dropna() > 0).all()


def test_atr_pct_relative_to_close(ohlcv_300) -> None:
    out = ind.add_atr(ohlcv_300, period=14)
    last_atr = out["atr_14"].iloc[-1]
    last_close = out["Close"].iloc[-1]
    expected_pct = last_atr / last_close * 100.0
    assert out["atr_14_pct"].iloc[-1] == pytest.approx(expected_pct)


# ══════════════════════════════════════════════════════════════════════════════
# Bollinger Bands
# ══════════════════════════════════════════════════════════════════════════════

def test_bollinger_columns_present(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    for col in ("bb_20_1s_upper", "bb_20_1s_mid", "bb_20_1s_lower", "bb_20_1s_pct"):
        assert col in out.columns


def test_bollinger_mid_equals_sma(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    expected_sma = ohlcv_300["Close"].rolling(20, min_periods=20).mean().iloc[-1]
    assert out["bb_20_1s_mid"].iloc[-1] == pytest.approx(expected_sma)


def test_bollinger_upper_above_lower(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    valid = out.dropna(subset=["bb_20_1s_upper", "bb_20_1s_lower"])
    assert (valid["bb_20_1s_upper"] >= valid["bb_20_1s_lower"]).all()


def test_bollinger_pct_in_typical_range(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    pct = out["bb_20_1s_pct"].dropna()
    # Most of a tight envelope's distribution lands in [-0.5, 1.5];
    # we accept anything finite — the band-clamp logic is tested via
    # the ride classifier suite.
    assert pct.notna().sum() > 100
    assert np.isfinite(pct).all()


# ══════════════════════════════════════════════════════════════════════════════
# Bollinger bandwidth
# ══════════════════════════════════════════════════════════════════════════════

def test_bbw_requires_bollinger_first(ohlcv_300) -> None:
    with pytest.raises(ValueError, match="bb_20_1s_upper"):
        ind.add_bollinger_bandwidth(
            ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s",
        )


def test_bbw_columns_present(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    out = ind.add_bollinger_bandwidth(
        out, period=20, std_dev=1.0, prefix="bb_20_1s",
        slope_window=5, pctl_window=100,
    )
    for col in ("bbw_20_1s", "bbw_20_1s_slope", "bbw_20_1s_pctl"):
        assert col in out.columns


def test_bbw_value_against_manual_compute(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    out = ind.add_bollinger_bandwidth(
        out, period=20, std_dev=1.0, prefix="bb_20_1s",
        slope_window=5, pctl_window=100,
    )
    upper = out["bb_20_1s_upper"].iloc[-1]
    lower = out["bb_20_1s_lower"].iloc[-1]
    mid = out["bb_20_1s_mid"].iloc[-1]
    expected = (upper - lower) / mid * 100.0
    assert out["bbw_20_1s"].iloc[-1] == pytest.approx(expected)


def test_bbw_percentile_in_0_100_range(ohlcv_300) -> None:
    out = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    out = ind.add_bollinger_bandwidth(
        out, period=20, std_dev=1.0, prefix="bb_20_1s",
        slope_window=5, pctl_window=100,
    )
    pctl = out["bbw_20_1s_pctl"].dropna()
    assert (pctl >= 0).all() and (pctl <= 100).all()


# ══════════════════════════════════════════════════════════════════════════════
# Data sufficiency
# ══════════════════════════════════════════════════════════════════════════════

def test_data_sufficiency_flag(ohlcv_300) -> None:
    out = ind.add_data_sufficiency(ohlcv_300, min_bars=200)
    assert out["data_sufficient"].iloc[:199].sum() == 0
    assert out["data_sufficient"].iloc[199:].all()


def test_data_sufficiency_short_frame(ohlcv_100) -> None:
    out = ind.add_data_sufficiency(ohlcv_100, min_bars=200)
    assert not out["data_sufficient"].any()


# ══════════════════════════════════════════════════════════════════════════════
# Mutation safety
# ══════════════════════════════════════════════════════════════════════════════

def test_enrichment_functions_do_not_mutate_input(ohlcv_300) -> None:
    before = ohlcv_300.copy()
    _ = ind.add_moving_averages(ohlcv_300, periods=(20,))
    _ = ind.add_atr(ohlcv_300, period=14)
    _ = ind.add_bollinger(ohlcv_300, period=20, std_dev=1.0, prefix="bb_20_1s")
    pd.testing.assert_frame_equal(before, ohlcv_300)
