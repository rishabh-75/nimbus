#!/usr/bin/env python3
"""
scripts/run_fold_comparison.py — Per-fold performance breakdown.

Uses ONLY wf_oos_trades.csv (no enrichment, no fetching). Compares the five
walk-forward folds across:
  - Sample size, win rate, avg/med PnL, Sharpe-ish
  - Tier mix (PRIMARY vs SECONDARY)
  - Exit reason mix (where do trades end?)
  - Bars held distribution

GOAL:
  Test the hypothesis that fold 3 was structurally different from the others
  (looser entries, more winners, different exit mix) — which would explain
  why the BB %B upper-mid bucket existed only in fold 3 and won 80% of trades.

If fold 3 just outperformed everything, the question becomes "what did fold 3
do differently that worked, and can we replicate it." If fold 3 looks like
the others, the upper-mid finding was pure noise concentrated by chance.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd


CSV_PATH = "data/backtest_results/wf_oos_trades.csv"


def header(text: str, char: str = "="):
    print("\n" + char * 78)
    print(f"  {text}")
    print(char * 78)


def stats(s: pd.DataFrame) -> dict:
    if len(s) == 0:
        return {}
    pnl = s["pnl_pct"]
    return {
        "n": len(s),
        "win_pct": float((pnl > 0).mean() * 100),
        "avg_pnl": float(pnl.mean()),
        "med_pnl": float(pnl.median()),
        "std_pnl": float(pnl.std()),
        "sharpe": float(pnl.mean() / pnl.std() * np.sqrt(252 / s["bars_held"].mean()))
                  if pnl.std() > 0 and s["bars_held"].mean() > 0 else 0.0,
        "bars_avg": float(s["bars_held"].mean()),
    }


def fold_overview(df: pd.DataFrame):
    header("FOLD OVERVIEW")
    print(f"\n  {'Fold':<6s}  {'Dates':<28s}  {'N':>6s}  {'Win%':>6s}  {'Avg':>8s}  {'Med':>8s}  {'Sh':>6s}  {'Bars':>5s}")
    print(f"  {'-'*6}  {'-'*28}  {'-'*6}  {'-'*6}  {'-'*8}  {'-'*8}  {'-'*6}  {'-'*5}")
    for fold in sorted(df["fold"].unique()):
        sub = df[df["fold"] == fold]
        s = stats(sub)
        d_min = sub["entry_date"].min().date()
        d_max = sub["entry_date"].max().date()
        date_str = f"{d_min} → {d_max}"
        print(f"  fold={fold}  {date_str:<28s}  {s['n']:>6d}  {s['win_pct']:>5.1f}%  "
              f"{s['avg_pnl']:>+7.2f}%  {s['med_pnl']:>+7.2f}%  {s['sharpe']:>+5.2f}  {s['bars_avg']:>4.1f}")
    print()
    overall = stats(df)
    print(f"  {'all':<6s}  {'(combined)':<28s}  {overall['n']:>6d}  {overall['win_pct']:>5.1f}%  "
          f"{overall['avg_pnl']:>+7.2f}%  {overall['med_pnl']:>+7.2f}%  {overall['sharpe']:>+5.2f}  {overall['bars_avg']:>4.1f}")


def tier_breakdown(df: pd.DataFrame):
    header("TIER MIX BY FOLD (PRIMARY = MR · SECONDARY = Ride)")
    print(f"\n  {'Fold':<6s}  {'Tier':<12s}  {'N':>6s}  {'Win%':>6s}  {'Avg':>8s}  {'Sh':>6s}")
    print(f"  {'-'*6}  {'-'*12}  {'-'*6}  {'-'*6}  {'-'*8}  {'-'*6}")
    for fold in sorted(df["fold"].unique()):
        sub = df[df["fold"] == fold]
        for tier in sorted(sub["tier"].unique()):
            tier_sub = sub[sub["tier"] == tier]
            if len(tier_sub) < 5:
                continue
            s = stats(tier_sub)
            print(f"  fold={fold}  {tier:<12s}  {s['n']:>6d}  {s['win_pct']:>5.1f}%  "
                  f"{s['avg_pnl']:>+7.2f}%  {s['sharpe']:>+5.2f}")
        print()


def exit_reason_breakdown(df: pd.DataFrame):
    header("EXIT REASON MIX BY FOLD")
    reasons = sorted(df["exit_reason"].unique())
    print(f"\n  Distribution as % of fold (and avg PnL per reason)")
    print(f"\n  {'Fold':<6s}  ", end="")
    for r in reasons:
        print(f"{r:<22s}", end="")
    print()
    print(f"  {'-'*6}  " + "  ".join("-" * 20 for _ in reasons))

    for fold in sorted(df["fold"].unique()):
        sub = df[df["fold"] == fold]
        n_total = len(sub)
        print(f"  fold={fold}  ", end="")
        for r in reasons:
            r_sub = sub[sub["exit_reason"] == r]
            pct = len(r_sub) / n_total * 100 if n_total else 0
            avg = r_sub["pnl_pct"].mean() if len(r_sub) else 0
            print(f"{len(r_sub):4d} ({pct:4.1f}%) {avg:+5.1f}%   ", end="")
        print()


def fold_3_deep_dive(df: pd.DataFrame):
    """Specifically compare fold 3 against the rest of the dataset."""
    header("FOLD 3 vs REST — IS IT REALLY DIFFERENT?")
    f3 = df[df["fold"] == 3]
    rest = df[df["fold"] != 3]

    s3 = stats(f3)
    sr = stats(rest)

    print(f"\n  Metric           Fold 3       Rest         Δ")
    print(f"  {'-'*16}  {'-'*10}  {'-'*10}  {'-'*8}")
    metrics = [
        ("N",            f"{s3['n']:>6d}",        f"{sr['n']:>6d}",        f"{s3['n'] - sr['n']:+d}"),
        ("Win rate",     f"{s3['win_pct']:>5.1f}%", f"{sr['win_pct']:>5.1f}%", f"{s3['win_pct'] - sr['win_pct']:+5.1f}pp"),
        ("Avg PnL",      f"{s3['avg_pnl']:>+5.2f}%", f"{sr['avg_pnl']:>+5.2f}%", f"{s3['avg_pnl'] - sr['avg_pnl']:+5.2f}%"),
        ("Med PnL",      f"{s3['med_pnl']:>+5.2f}%", f"{sr['med_pnl']:>+5.2f}%", f"{s3['med_pnl'] - sr['med_pnl']:+5.2f}%"),
        ("Sharpe-ish",   f"{s3['sharpe']:>+5.2f}",  f"{sr['sharpe']:>+5.2f}",  f"{s3['sharpe'] - sr['sharpe']:+5.2f}"),
        ("Bars held",    f"{s3['bars_avg']:>5.1f}", f"{sr['bars_avg']:>5.1f}", f"{s3['bars_avg'] - sr['bars_avg']:+5.1f}"),
    ]
    for name, a, b, d in metrics:
        print(f"  {name:<16s}  {a:<10s}  {b:<10s}  {d}")

    # Tier mix
    f3_tiers = f3["tier"].value_counts(normalize=True) * 100
    rest_tiers = rest["tier"].value_counts(normalize=True) * 100
    print(f"\n  Tier mix:")
    for tier in sorted(set(f3_tiers.index) | set(rest_tiers.index)):
        a = f3_tiers.get(tier, 0)
        b = rest_tiers.get(tier, 0)
        print(f"    {tier:<12s}  fold 3: {a:5.1f}%   rest: {b:5.1f}%   Δ {a-b:+5.1f}pp")


def verdict(df: pd.DataFrame):
    header("INTERPRETATION")
    f3 = df[df["fold"] == 3]
    rest = df[df["fold"] != 3]
    s3 = stats(f3)
    sr = stats(rest)

    win_diff = s3["win_pct"] - sr["win_pct"]
    pnl_diff = s3["avg_pnl"] - sr["avg_pnl"]
    sharpe_diff = s3["sharpe"] - sr["sharpe"]

    print()
    if abs(win_diff) < 2 and abs(pnl_diff) < 0.2 and abs(sharpe_diff) < 0.15:
        print("  Fold 3 looks STATISTICALLY SIMILAR to the other folds.")
        print("  → The upper-mid bucket finding was concentration noise, not real edge.")
        print("  → BB %B investigation can be CLOSED for good.")
        print("  → No follow-up needed.")
    elif win_diff > 3 or pnl_diff > 0.4 or sharpe_diff > 0.3:
        print("  Fold 3 is MEASURABLY BETTER than the other folds.")
        print(f"  Win rate: {win_diff:+.1f}pp · Avg PnL: {pnl_diff:+.2f}% · Sharpe: {sharpe_diff:+.2f}")
        print()
        print("  This means fold 3's parameter set actually generated higher-quality trades.")
        print("  The upper-mid bucket was a side effect — the real signal is whatever fold 3")
        print("  did differently in entry selection.")
        print()
        print("  RECOMMENDED FOLLOW-UP:")
        print("    Compare the fold 3 parameter set against fold 1/2/4/5 parameters")
        print("    in the walk-forward backtest output. The differences are the lever.")
    elif win_diff < -3 or pnl_diff < -0.4 or sharpe_diff < -0.3:
        print("  Fold 3 is WORSE than the other folds overall.")
        print("  → The upper-mid bucket was a small island of strength in a weak fold.")
        print("  → BB %B investigation: REJECTED, but for an interesting reason.")
        print("  → Worth checking what fold 3's overall weakness came from.")
    else:
        print("  Fold 3 is SLIGHTLY DIFFERENT from the others, but not dramatically.")
        print(f"  Win rate: {win_diff:+.1f}pp · Avg PnL: {pnl_diff:+.2f}% · Sharpe: {sharpe_diff:+.2f}")
        print("  → Probably not enough signal to act on.")
        print("  → BB %B investigation: closed, fold-specific concentration was likely noise.")


def main():
    if not os.path.exists(CSV_PATH):
        print(f"ERROR: {CSV_PATH} not found")
        sys.exit(1)

    df = pd.read_csv(CSV_PATH)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    print(f"\nLoaded {len(df):,} trades from {CSV_PATH}")

    fold_overview(df)
    tier_breakdown(df)
    exit_reason_breakdown(df)
    fold_3_deep_dive(df)
    verdict(df)


if __name__ == "__main__":
    main()
