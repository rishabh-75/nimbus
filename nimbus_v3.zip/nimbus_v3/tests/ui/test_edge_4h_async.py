"""The 4h column fills in asynchronously after the cache warms, without a
recompute, and a later cache miss never wipes a flag already shown."""
from __future__ import annotations

import dataclasses

import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.compute.equity_edge import (
    EdgeHorizonSet,
    EdgeResult,
    SymbolEdge,
)
from nimbus_v3.ui.widgets.edge_tab import EdgeTab

_FIELDS = [f.name for f in dataclasses.fields(SymbolEdge)]
_UP, _DOWN, _UNK = "\u25b2", "\u2014", "?"


@pytest.fixture(scope="module")
def qapp():
    yield QApplication.instance() or QApplication([])


def _tab(syms):
    rows = tuple(SymbolEdge(**{
        n: (s if n == "symbol" else "Chem" if n == "industry"
            else None if n == "above_4h" else 1.0) for n in _FIELDS})
        for s in syms)
    w = EdgeTab()
    w.set_horizon_set(EdgeHorizonSet(
        results=(EdgeResult(rows=rows, horizon_days=10, kappa=0.5),),
        default_horizon=10))
    return w


def _col(w):
    m = w._model
    c = w._COLS.index("4h")
    return {m.data(m.index(r, w._COLS.index("Symbol"))): m.data(m.index(r, c))
            for r in range(m.rowCount())}


def test_starts_unknown_then_fills(qapp):  # noqa: ARG001
    w = _tab(["AAA", "BBB", "CCC"])
    assert set(_col(w).values()) == {_UNK}          # cold cache
    w.update_above_4h({"AAA": True, "BBB": False})
    assert _col(w) == {"AAA": _UP, "BBB": _DOWN, "CCC": _UNK}


def test_later_miss_does_not_wipe_known_flag(qapp):  # noqa: ARG001
    w = _tab(["AAA", "CCC"])
    w.update_above_4h({"AAA": True})
    w.update_above_4h({"AAA": None, "CCC": True})    # AAA missed this pass
    assert _col(w) == {"AAA": _UP, "CCC": _UP}


def test_empty_update_is_noop(qapp):  # noqa: ARG001
    w = _tab(["AAA"])
    w.update_above_4h(None)
    w.update_above_4h({})
    assert _col(w) == {"AAA": _UNK}
