#!/usr/bin/env python3
"""self_valuation_probe.py — a P/E-band analog with NO earnings: is a name's
own price-to-"fair-value-proxy" ratio, z-scored against ITS OWN history,
predictive of forward return?

THE IDEA (distinct from everything probed before)
─────────────────────────────────────────────────
Every prior seasonal/value probe was CROSS-SECTIONAL — "cheap vs peers" — and
died on sector confounding (a 40x software name isn't expensive, it's
software). This is SELF-REFERENTIAL: judge each name only against its own
history. A forward P/E asks "price / expected earnings"; we have no earnings,
so we substitute proxies for the level price "should" track, form the ratio,
and z-score it against the name's own trailing history. 2σ below its own norm
= "cheap for itself" = the P/E-band-bottom analog.

Self-normalisation is the reason this MIGHT behave differently: it removes the
sector level that sank seasonal-magnitude — a name is compared only to itself,
so "software trades rich" is normalised away and only "rich FOR THIS NAME"
remains.

THE HONEST PRIOR (state it, then test past it)
──────────────────────────────────────────────
Mechanically this is still MEAN REVERSION ("below its own norm → snap back"),
and this panel has rejected reversion at every turn (entry_probe, gap probe).
So the base rate says null or momentum-signed. Self-normalisation is a genuine
untested axis, so the prior is weaker than before — worth one real probe, not
a dismissal. The SIGN is the whole game:
    cheap-for-itself → high fwd return  = self-referential value works (NEW).
    rich-for-itself  → high fwd return  = momentum again (redundant with %B).
    flat                                 = null, like the others.

RATIOS TESTED (each z-scored vs the name's OWN trailing ZWIN history)
────────────────────────────────────────────────────────────────────
  price_over_median   price / trailing-median price. The cleanest self-
                      referential stretch — the raw "P/E band".
  price_over_seasonal price / a seasonal-EXPECTED price path (the industry's
                      monthly seasonal returns compounded forward from a
                      lookback anchor). This is the "Price/seasonality against
                      its own history" the request named. Industry seasonal
                      pattern (more data) — swap SEASONAL_SOURCE to 'self' for
                      the name's own thinner pattern.
  price_over_rs       price / its own relative-strength-implied level (price
                      detrended by the name's RS vs market).

BUCKETING & SIGN CONVENTION
Each ratio's own-history z at the entry bar → deciles (D1 = cheapest-for-
itself, D10 = richest). Report forward FWD-day excess per decile and the
D1−D10 spread (so POSITIVE = cheap beats rich = reversion/value works).

CONTROLS (per ratio)
  ctl:random    shuffle the z labels → spread ~0.
  ctl:vs-%B     THE redundancy gate. Re-run the SAME test but bucket by the
                name's %B (bb_20_1s_pct) instead. If price_over_median's curve
                is just the %B curve, the ratio adds nothing over the band
                signal you already have. The self-referential ratio must show
                a curve NOT reproduced by %B to be worth anything.
  shuffle-dates canary → ~0 (clustered on symbol-month, the honest unit).

DISCIPLINE: date/symbol-month-clustered t; no lookahead (z baseline and
seasonal expectation use only each name's history strictly before the entry
bar); forward return date-grid sliced.

Run from the dir containing ./data:
    cd /Users/srishabh/Monarch/nimbus
    python nimbus_v3/self_valuation_probe.py
    python nimbus_v3/self_valuation_probe.py --selftest
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

FWD = 20
SAMPLE_EVERY = 5
ZWIN = 504               # own-history window for the z-score (~2 trading yrs)
MEDIAN_WIN = 252         # trailing median window for price_over_median
RS_WIN = 120             # RS detrend window for price_over_rs
MIN_SEASON_YEARS = 3
SEASONAL_SOURCE = "industry"   # 'industry' | 'self'
PCTB = "bb_20_1s_pct"


# ── ratio builders (all return a full Series aligned to df.index) ───────────
def ratio_price_over_median(df, *, win=MEDIAN_WIN):
    import numpy as np
    c = df["Close"].astype(float)
    med = c.rolling(win, min_periods=win // 2).median()
    return c / med.replace(0.0, np.nan)


def ratio_price_over_rs(df, market_close, *, win=RS_WIN):
    """price / (its own RS-implied level). RS = close/market, normalised to
    its trailing mean; implied level = market × mean(RS over win). The ratio
    is close / implied = RS / mean(RS) — i.e. how stretched the name's
    relative strength is vs its own recent norm."""
    import numpy as np
    import pandas as pd
    c = df["Close"].astype(float)
    m = market_close.reindex(c.index).ffill()
    rs = c / m.replace(0.0, np.nan)
    return rs / rs.rolling(win, min_periods=win // 2).mean()


def ratio_price_over_seasonal(df, industry_close, asof_index, *,
                              source=SEASONAL_SOURCE):
    """price / seasonal-EXPECTED price. Build an expected path by compounding
    the (industry or self) monthly seasonal return pattern from a rolling
    anchor, using ONLY history before each point. Returns a Series aligned to
    df.index (NaN where insufficient history). Computed per-request per symbol
    — the cold path, called once per sampled bar via a cache in build_records.
    This function returns the RATIO at a single asof (scalar) for efficiency.
    """
    # Implemented at the call site (needs per-asof no-lookahead seasonal);
    # see seasonal_expected_ratio_at.
    raise NotImplementedError


def _monthly_pattern(close, asof):
    """{month: avg monthly return} from history strictly before asof."""
    import numpy as np
    from nimbus_v3.compute.seasonality import _monthly_returns
    hist = close.loc[close.index < asof]
    if hist.empty:
        return {}
    m = _monthly_returns(hist)
    if m.empty:
        return {}
    out = {}
    for mo in range(1, 13):
        v = m[m.index.month == mo].to_numpy(dtype=float)
        v = v[np.isfinite(v)]
        if len(v) >= MIN_SEASON_YEARS:
            out[mo] = float(np.mean(v))
    return out


def seasonal_expected_ratio_at(df, seasonal_close, i):
    """price[i] / seasonal-expected price[i].

    Expected price = price[i-1] grown by the seasonal pattern's expected
    return for the month spanning [i-1, i]. A name sitting BELOW its
    seasonally-expected level is 'cheap for itself' this month. Uses only
    history before df.index[i] (pattern) — no lookahead.
    """
    import numpy as np
    asof = df.index[i]
    pat = _monthly_pattern(seasonal_close, asof)
    if not pat:
        return float("nan")
    mo = asof.month
    exp_ret = pat.get(mo)
    if exp_ret is None:
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    if i < 21 or c[i - 21] <= 0:      # ~1 month back as the anchor
        return float("nan")
    # expected price this month ≈ price one month ago × (1 + seasonal monthly)
    expected = c[i - 21] * (1.0 + exp_ret)
    if expected <= 0:
        return float("nan")
    return c[i] / expected


# ── own-history z-score (no lookahead) ──────────────────────────────────────
def zscore_at(series_vals, i, *, win=ZWIN):
    import numpy as np
    lo = max(0, i - win)
    hist = series_vals[lo:i]              # STRICTLY before i
    hist = hist[np.isfinite(hist)]
    if len(hist) < win // 3:
        return float("nan")
    mu, sd = hist.mean(), hist.std(ddof=1)
    if sd <= 0:
        return float("nan")
    return (series_vals[i] - mu) / sd


def forward_excess(df, i, market_cum, *, fwd=FWD):
    import numpy as np
    if i + fwd >= len(df):
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    r = c[i + fwd] / c[i] - 1.0
    d0, d1 = df.index[i], df.index[i + fwd]
    m0, m1 = market_cum.get(d0), market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan")
    rm = m1 / m0 - 1.0
    if not (np.isfinite(r) and np.isfinite(rm)):
        return float("nan")
    return r - rm


# ── inference (clustered on SYMBOL-month — the honest unit) ─────────────────
def clustered_mean(pairs):
    import numpy as np
    by = defaultdict(list)
    for k, x in pairs:
        if x == x:
            by[k].append(x)
    dm = [float(np.mean(v)) for v in by.values()]
    if len(dm) < 3:
        return float("nan"), 0
    return float(np.mean(dm)), len(dm)


def welch(a_pairs, b_pairs):
    import numpy as np
    def dm(p):
        d = defaultdict(list)
        for k, x in p:
            if x == x:
                d[k].append(x)
        return np.array([np.mean(v) for v in d.values()])
    a, b = dm(a_pairs), dm(b_pairs)
    if len(a) < 3 or len(b) < 3:
        return float("nan")
    se = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
    return (a.mean()-b.mean())/se if se > 0 else float("nan")


def decile_report(rows, key_i, label, *, rng=None, shuffle_key=False,
                  shuffle_dates=False):
    """rows: [clusterkey, fwd, z_median, z_rs, z_seasonal, pctb, date].
    Bucket by column key_i into deciles; print per-decile fwd mean and the
    D1(cheap)−D10(rich) spread with symbol-month clustering."""
    import numpy as np
    rec = [r[:] for r in rows]
    if shuffle_key and rng is not None:
        ks = [r[key_i] for r in rec]
        rng.shuffle(ks)
        for r, k in zip(rec, ks):
            r[key_i] = k
    if shuffle_dates and rng is not None:
        # reassign the cluster key's month via a shuffled date
        ds = [r[6] for r in rec]
        rng.shuffle(ds)
        for r, d in zip(rec, ds):
            r[0] = (r[0][0], d.year, d.month)

    vals = np.array([r[key_i] for r in rec if r[key_i] == r[key_i]])
    if len(vals) < 20:
        print(f"\n─── {label}: too few points")
        return {"spread": float("nan"), "welch": float("nan")}
    edges = [np.quantile(vals, q/10) for q in range(1, 10)]

    def dec(x):
        if x != x:
            return None
        for di, e in enumerate(edges):
            if x <= e:
                return di
        return 9

    buckets = defaultdict(list)
    for r in rec:
        d = dec(r[key_i])
        if d is not None:
            buckets[d].append((r[0], r[1]))
    print(f"\n─── {label} " + "─" * max(2, 46 - len(label)))
    means = []
    for d in range(10):
        m, nc = clustered_mean(buckets.get(d, []))
        means.append(m)
        cell = "  nan " if m != m else f"{m*100:+6.2f}%"
        tag = "cheap" if d == 0 else "rich" if d == 9 else ""
        print(f"  D{d+1:<2} {tag:5}: {cell}   clusters {nc}")
    # D1 (cheap) − D10 (rich): POSITIVE = cheap-for-itself outperforms
    cheap = buckets.get(0, [])
    rich = buckets.get(9, [])
    cm, _ = clustered_mean(cheap)
    rm, _ = clustered_mean(rich)
    spread = (cm - rm) if (cm == cm and rm == rm) else float("nan")
    w = welch(cheap, rich)
    print(f"  ── D1(cheap) − D10(rich) = {spread*100:+.2f}%   Welch-t = {w:+.2f}")
    return {"spread": spread, "welch": w, "means": means}


# ── build ───────────────────────────────────────────────────────────────────
def build_rows(panel, sym_to_industry, comps, market_close, market_cum):
    import numpy as np
    rows = []
    for sym, df in panel.items():
        ind = sym_to_industry.get(sym)
        if "Close" not in df.columns or len(df) < ZWIN + FWD + 30:
            continue
        seas_close = comps.get(ind) if SEASONAL_SOURCE == "industry" \
            else df["Close"]
        r_med = ratio_price_over_median(df).to_numpy(dtype=float)
        r_rs = ratio_price_over_rs(df, market_close).to_numpy(dtype=float)
        pctb = (df[PCTB].to_numpy(dtype=float) if PCTB in df.columns
                else np.full(len(df), np.nan))
        for i in range(ZWIN, len(df) - FWD - 1, SAMPLE_EVERY):
            fx = forward_excess(df, i, market_cum)
            if fx != fx:
                continue
            zm = zscore_at(r_med, i)
            zr = zscore_at(r_rs, i)
            # seasonal ratio (scalar at i), then z vs a short own-history of it
            zs = float("nan")
            if seas_close is not None:
                sr = seasonal_expected_ratio_at(df, seas_close, i)
                if sr == sr:
                    # cheap z proxy: compare sr to 1.0 in log space, scaled by
                    # the name's own recent ratio dispersion isn't available
                    # cheaply here, so use (sr−1) directly as the signed stretch
                    zs = sr - 1.0
            key = (sym, df.index[i].year, df.index[i].month)
            rows.append([key, fx, zm, zr, zs,
                         pctb[i], df.index[i]])
    return rows


def build_market(panel, *, min_count=20):
    import numpy as np
    import pandas as pd
    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                sums[idx[i]] += c[i]/c[i-1] - 1.0
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    dates = sorted(daily)
    cum, acc, lvl = {}, 1.0, {}
    for d in dates:
        acc *= 1.0 + daily[d]
        cum[d] = acc
        lvl[d] = acc
    return cum, pd.Series(lvl).sort_index()


def build_composites(panel, sym_to_industry):
    from nimbus_v3.compute.industry_composite import build_industry_composite
    members = defaultdict(list)
    for sym, ind in sym_to_industry.items():
        if sym in panel:
            members[ind].append(sym)
    out = {}
    for ind, syms in members.items():
        comp, _ = build_industry_composite(
            syms, panel, min_members=3, min_bars=250, lookback=None)
        if comp is not None:
            out[ind] = comp
    return out


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db
    from strategy_probe import load_panel

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — run from dir with ./data", file=sys.stderr)
        return 1
    print("composites + market...", file=sys.stderr)
    comps = build_composites(panel, sym_to_industry)
    market_cum, market_close = build_market(panel)
    print("building rows (z-scores per name — a minute)...", file=sys.stderr)
    rows = build_rows(panel, sym_to_industry, comps, market_close, market_cum)
    print(f"rows: {len(rows)}", file=sys.stderr)

    rng = np.random.default_rng(args.seed)
    results = {}
    for name, ki in [("price_over_median", 2), ("price_over_rs", 3),
                     ("price_over_seasonal", 4)]:
        print("\n" + "#" * 60 + f"\n# {name}\n" + "#" * 60)
        r = decile_report(rows, ki, f"REAL {name} (D1 cheap → D10 rich)")
        decile_report(rows, ki, f"ctl:random {name}", rng=rng, shuffle_key=True)
        decile_report(rows, ki, f"ctl:shuffle-dates {name}", rng=rng,
                      shuffle_dates=True)
        results[name] = r

    # redundancy vs %B — does price_over_median just reproduce the band?
    print("\n" + "#" * 60 + "\n# ctl:vs-%B (redundancy gate)\n" + "#" * 60)
    pctb_res = decile_report(rows, 5, "bucket by %B (bb_20_1s_pct)")

    print("\n" + "=" * 68)
    print("VERDICT")
    any_real = False
    for name, r in results.items():
        s, w = r["spread"], r["welch"]
        if s == s and abs(w) > 2:
            any_real = True
            sign = ("cheap-for-itself wins → self-referential VALUE/reversion"
                    if s > 0 else
                    "rich-for-itself wins → MOMENTUM (likely redundant w/ %B)")
            print(f"  {name}: D1−D10 {s*100:+.2f}%, t {w:+.2f} → {sign}")
        else:
            print(f"  {name}: D1−D10 {s*100:+.2f}%, t {w:+.2f} → null")
    print()
    pw = pctb_res["welch"]
    print(f"  %B bucket D1−D10 t = {pw:+.2f} (compare shape to price_over_median:"
          f" if identical, the ratio is redundant with the band).")
    if not any_real:
        print("  → Nothing clears |t|>2. Self-referential valuation does not")
        print("    predict on this panel either. Build nothing.")
    else:
        print("  → A ratio cleared the bar. Check its SIGN and whether its")
        print("    curve differs from %B before believing it is NEW. If it is")
        print("    'rich wins' and matches %B, it is momentum you already have.")
    return 0


def _selftest(args):
    """Two worlds:
      A) VALUE — forward return ∝ −z (cheap-for-itself outperforms) → D1−D10
         must be POSITIVE and significant.
      B) NULL — forward return independent of z → D1−D10 ~0.
    Plus: random-key control collapses A.
    """
    import numpy as np
    import pandas as pd
    dates = pd.bdate_range("2016-01-01", periods=2000)

    def synth(value):
        rng = np.random.default_rng(args.seed)
        rows = []
        for s in range(60):
            sym = f"S{s:02d}"
            for _ in range(400):
                i = rng.integers(len(dates))
                d = dates[i]
                z = rng.normal(0, 1)          # own-history z of the ratio
                if value:
                    fwd = -0.01 * z + rng.normal(0, 0.05)   # cheap → up
                else:
                    fwd = rng.normal(0, 0.05)
                key = (sym, d.year, d.month)
                rows.append([key, fwd, z, rng.normal(), rng.normal(),
                             rng.normal(), d])
        return rows

    rng = np.random.default_rng(args.seed)
    print("\n####### A: VALUE world (cheap-for-itself wins) #######")
    A = decile_report(synth(True), 2, "A price_over_median")
    Ar = decile_report(synth(True), 2, "A ctl:random", rng=rng, shuffle_key=True)
    print("\n####### B: NULL world #######")
    B = decile_report(synth(False), 2, "B price_over_median")

    A_ok = A["spread"] > 0 and A["welch"] > 2
    Ar_dead = not (abs(Ar["welch"]) > 2)
    B_dead = not (abs(B["welch"]) > 2)
    print("\n" + "=" * 68)
    print(f"A value detected (D1>D10, t>2):     {A_ok}")
    print(f"A random-key collapses:             {Ar_dead}")
    print(f"B null reads ~0:                    {B_dead}")
    ok = A_ok and Ar_dead and B_dead
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
