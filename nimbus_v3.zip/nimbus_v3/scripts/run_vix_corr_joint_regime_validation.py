"""Research: do VIX × CORR joint regimes carry signal beyond either
signal alone?

Hypothesis: certain pairings of VIX pace regime and correlation
regime may produce forward-return effects that are meaningfully
larger (or smaller) than either signal carries individually. Most
interesting candidates a-priori:

  (RISING, HIGH)  — peak stress: fear building AND cross-section
                    panicking together. Could be either deepest
                    fear (worse fwd lift) or maximal "buy the dip"
                    setup (best fwd lift) — research will tell us.
  (STABLE, NORMAL) — the muddled middle of muddled middles.
                    Possibly worst regime (compounded "no edge").
  (FALLING, HIGH) — fear dissipating + recovery in progress.
                    Probably already-priced bounce; lift may be
                    smaller than HIGH alone.
  (STABLE, LOW)   — orderly bull regime + quiet vol. Classic
                    "boring grind up" — neutral to slightly
                    positive.

Methodology:
  1. Build VIX regime series from VIXPaceClassifier on cached VIX.
  2. Build CORR regime series from CorrelationRegimeClassifier on
     industry returns panel.
  3. Cross-tabulate into 9 joint cells (UNKNOWN bars excluded).
  4. For each (joint_cell, fold): pool member-symbol fwd_10d
     returns; measure lift vs universe baseline AND vs marginals.
  5. Walk-forward 4 folds, 10-bar purge.

SHIP RULE (decided up front, stricter than marginal research):
  A joint cell ships only if BOTH:
    a) Sign agreement ≥ 75% across folds (≥ 3 of 4)
    b) |Mean test lift vs baseline| ≥ 0.5 pp
    c) |Mean test lift| EXCEEDS the larger of the two marginal
       lifts by ≥ 0.5 pp on the same test fold

Criterion (c) is the key add. Without it we'd just be re-validating
the marginals through a finer slicing of the data. We want joint
cells where the combination *adds* signal.

Output: scripts/output/vix_corr_joint_regime_validation.txt
"""
from __future__ import annotations

import logging
import sys
from datetime import timedelta
from pathlib import Path

# Make project root importable
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.correlation_regime import (
    CORR_WINDOW,
    PCTILE_WINDOW,
)
from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.vix_pace import (
    REGIME_FALLING as VIX_FALLING,
    REGIME_RISING as VIX_RISING,
    REGIME_STABLE as VIX_STABLE,
    VIXPaceClassifier,
)
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.data.industry_db import load_industry_db
from nimbus_v3.data.nse_client import NSEClient
from nimbus_v3.data.vix_loader import VIXLoader
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns
from scripts.run_correlation_regime_validation import (    # noqa: E402
    _build_industry_returns,
    _classify_regimes as _classify_corr_regimes,
    _make_expanding_folds,
    _mean_pairwise_correlation_series,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("vix_corr_joint")


_EQ_CACHE_DIR: Path = _ROOT / "data" / "cache" / "enriched"
_OUT_PATH: Path = _ROOT / "scripts" / "output" / "vix_corr_joint_regime_validation.txt"


# ══════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════

_VIX_REGIMES: tuple[str, ...] = (VIX_RISING, VIX_STABLE, VIX_FALLING)

# NOTE: The CORR labels here are the *research-script* labels
# ("HIGH_CORR", "NORMAL", "LOW_CORR"), not the production-module
# labels ("HIGH", "NORMAL", "LOW"). This is because we use the
# research script's _classify_regimes function which returns the
# suffixed names. The production module compute/correlation_regime.py
# uses unsuffixed labels for UI display. They're equivalent regimes,
# different string conventions. Don't conflate them — match the
# function we're calling.
_CORR_HIGH_LABEL: str = "HIGH_CORR"
_CORR_NORMAL_LABEL: str = "NORMAL"
_CORR_LOW_LABEL: str = "LOW_CORR"
_CORR_REGIMES: tuple[str, ...] = (
    _CORR_HIGH_LABEL, _CORR_NORMAL_LABEL, _CORR_LOW_LABEL,
)

_N_FOLDS: int = 4
_PURGE_BARS: int = 10

#: Standard ship criteria — same as marginal research.
_SHIP_FOLD_AGREEMENT_THRESHOLD: float = 0.75
_SHIP_MIN_LIFT_PP: float = 0.5

#: NEW: incremental-edge requirement. Joint cell must add ≥ this
#: many pp on top of the larger marginal lift to count as a real
#: joint signal.
_SHIP_INCREMENTAL_LIFT_PP: float = 0.5

#: Cosmetic.
_DIV_WIDE: str = "═" * 78
_DIV_THIN: str = "─" * 78


# ══════════════════════════════════════════════════════════════════════
# Data prep — equity + VIX
# ══════════════════════════════════════════════════════════════════════

def _prepare_data() -> dict:
    """Load equity panel (cached + enriched) AND VIX history.

    Unlike run_correlation_regime_validation.py's equity-only prep,
    we need VIX to compute the joint regime. If VIX load fails the
    whole script aborts — there's no graceful fallback for joint
    research.
    """
    # Equity prep
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    log.info("Equity panel: %d symbols", len(raw_panel))
    if not raw_panel:
        raise RuntimeError("Equity panel empty — no cached data available")

    log.info("Enriching (cache-first)...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    hits = misses = 0
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
            hits += 1
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
                misses += 1
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched panel: %d symbols (cache: %d hits, %d misses)",
             len(enriched_panel), hits, misses)

    log.info("Attaching forward returns...")
    panel_w_fwd: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        panel_w_fwd[sym] = add_forward_returns(df)

    log.info("Loading industry DB...")
    ind_db = load_industry_db()
    industry_map: dict[str, str] = {
        sym: rec.industry for sym, rec in ind_db.items()
    }

    # VIX prep
    log.info("Loading VIX history...")
    vix_loader = VIXLoader(
        nse_client=NSEClient(),
        cache=ParquetCache(Path("data/cache/vix")),
        default_history_years=10,
    )
    vix_df = vix_loader.load_history(cache_ttl=timedelta(days=30))
    if vix_df is None or vix_df.empty:
        raise RuntimeError(
            "VIX history unavailable — joint regime research aborted"
        )
    log.info("VIX history: %d bars", len(vix_df))

    return {
        "panel_w_fwd":     panel_w_fwd,
        "industry_map":    industry_map,
        "vix_close":       vix_df["Close"],
    }


# ══════════════════════════════════════════════════════════════════════
# Build VIX regime series (covers full panel date range)
# ══════════════════════════════════════════════════════════════════════

def _vix_regime_series(vix_close: pd.Series) -> pd.Series:
    """Compute VIX regime label per bar via VIXPaceClassifier.

    The classifier exposes classify_current() (latest bar). For a
    historical series we replicate its math inline to label every
    bar. Constants come from the classifier class so we stay in
    sync with any parameter changes there.
    """
    from nimbus_v3.compute.vix_pace import REGIME_UNKNOWN as VIX_UNKNOWN
    slope_win = VIXPaceClassifier.SLOPE_WINDOW
    z_baseline = VIXPaceClassifier.Z_BASELINE_WINDOW
    z_cutoff = VIXPaceClassifier.Z_CUTOFF
    # 20-day average daily Δ in VIX
    slope = vix_close.diff(slope_win) / slope_win
    # z-score against trailing 252-day distribution
    slope_mean = slope.rolling(z_baseline).mean()
    slope_std = slope.rolling(z_baseline).std()
    z = (slope - slope_mean) / slope_std

    out = pd.Series(VIX_UNKNOWN, index=vix_close.index, dtype=object)
    out[z > z_cutoff] = VIX_RISING
    out[z < -z_cutoff] = VIX_FALLING
    out[(z >= -z_cutoff) & (z <= z_cutoff)] = VIX_STABLE
    out[z.isna()] = pd.NA
    return out


# ══════════════════════════════════════════════════════════════════════
# Aggregate fwd_10d returns per joint cell
# ══════════════════════════════════════════════════════════════════════

def _aggregate_joint_lift(
    panel_w_fwd: dict[str, pd.DataFrame],
    vix_regime: pd.Series,
    corr_regime: pd.Series,
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
) -> tuple[dict, float, dict, dict]:
    """For each (vix_regime, corr_regime) joint cell, pool member-
    symbol fwd_10d returns across symbols on bars classified as
    that joint cell within [date_start, date_end].

    Returns:
      joint_stats: {(vix, corr): {n_obs, mean_pp, lift_pp}}
      universe_baseline_pp
      vix_marginal_stats: {vix_regime: {n_obs, mean_pp, lift_pp}}
      corr_marginal_stats: {corr_regime: {n_obs, mean_pp, lift_pp}}

    The marginals are computed on the SAME date range so they're
    directly comparable to the joint cell.
    """
    # Date-bound the regime series
    vix_in = vix_regime[(vix_regime.index >= date_start)
                        & (vix_regime.index <= date_end)]
    corr_in = corr_regime[(corr_regime.index >= date_start)
                          & (corr_regime.index <= date_end)]

    # Align on intersection of dates
    common_dates = vix_in.index.intersection(corr_in.index)
    vix_aligned = vix_in.reindex(common_dates)
    corr_aligned = corr_in.reindex(common_dates)

    # Build joint regime series
    joint = pd.Series(
        list(zip(vix_aligned.values, corr_aligned.values)),
        index=common_dates,
    )

    by_joint: dict[tuple[str, str], list[float]] = {
        (v, c): [] for v in _VIX_REGIMES for c in _CORR_REGIMES
    }
    by_vix: dict[str, list[float]] = {v: [] for v in _VIX_REGIMES}
    by_corr: dict[str, list[float]] = {c: [] for c in _CORR_REGIMES}
    all_returns: list[float] = []

    for sym, df in panel_w_fwd.items():
        if "fwd_ret_10d" not in df.columns:
            continue
        aligned = df["fwd_ret_10d"].reindex(common_dates)
        for date, fwd in aligned.items():
            if pd.isna(fwd):
                continue
            v = vix_aligned.loc[date]
            c = corr_aligned.loc[date]
            if pd.isna(v) or pd.isna(c):
                continue
            if v not in _VIX_REGIMES or c not in _CORR_REGIMES:
                continue
            fwd_pp = float(fwd) * 100
            by_joint[(v, c)].append(fwd_pp)
            by_vix[v].append(fwd_pp)
            by_corr[c].append(fwd_pp)
            all_returns.append(fwd_pp)

    universe_baseline = (
        float(np.mean(all_returns)) if all_returns else 0.0
    )

    def _summarize(buckets, regimes):
        out = {}
        for r in regimes:
            obs = buckets[r]
            if obs:
                mean_pp = float(np.mean(obs))
                out[r] = {
                    "n_obs":   len(obs),
                    "mean_pp": mean_pp,
                    "lift_pp": mean_pp - universe_baseline,
                }
            else:
                out[r] = {"n_obs": 0, "mean_pp": 0.0, "lift_pp": 0.0}
        return out

    # Joint
    joint_stats: dict[tuple[str, str], dict] = {}
    for (v, c), obs in by_joint.items():
        if obs:
            mean_pp = float(np.mean(obs))
            joint_stats[(v, c)] = {
                "n_obs":   len(obs),
                "mean_pp": mean_pp,
                "lift_pp": mean_pp - universe_baseline,
            }
        else:
            joint_stats[(v, c)] = {
                "n_obs": 0, "mean_pp": 0.0, "lift_pp": 0.0,
            }

    return (
        joint_stats,
        universe_baseline,
        _summarize(by_vix, _VIX_REGIMES),
        _summarize(by_corr, _CORR_REGIMES),
    )


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data (equity + VIX)...")
    try:
        prepared = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    panel_w_fwd = prepared["panel_w_fwd"]
    industry_map = prepared["industry_map"]
    vix_close = prepared["vix_close"]

    # Build regime series
    log.info("Building VIX regime series...")
    vix_regime = _vix_regime_series(vix_close)

    log.info("Building CORR regime series...")
    industry_returns = _build_industry_returns(panel_w_fwd, industry_map)
    corr_full_series = _mean_pairwise_correlation_series(industry_returns)
    corr_regime = _classify_corr_regimes(corr_full_series)

    # Date range = intersection of valid VIX + CORR labels
    common_dates = (
        vix_regime.dropna().index
        .intersection(corr_regime.dropna().index)
    )
    if len(common_dates) < 252:
        log.error(
            "Too few common-date bars for joint analysis: %d",
            len(common_dates),
        )
        return
    folds = _make_expanding_folds(common_dates, _N_FOLDS)

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("VIX × CORR JOINT REGIME — WALK-FORWARD VALIDATION")
        emit(_DIV_WIDE)
        emit("Hypothesis: certain (VIX, CORR) joint cells produce")
        emit("forward-return effects beyond what either signal alone")
        emit("predicts. Stricter ship rule than marginal research:")
        emit("the joint cell must EXCEED the larger marginal by")
        emit(f"≥{_SHIP_INCREMENTAL_LIFT_PP}pp to count.")
        emit("")
        emit(f"Common-date bars: {len(common_dates)} "
             f"({common_dates.min().date()} → {common_dates.max().date()})")
        emit("")
        emit("Fold boundaries:")
        for i, (te_end, ts_start, ts_end) in enumerate(folds):
            emit(f"  Fold {i+1}: train → {te_end.date()}, "
                 f"test {ts_start.date()} → {ts_end.date()}")
        emit("")

        # ── Run all folds ──────────────────────────────────────
        fold_results = []
        for fi, (train_end, test_start, test_end) in enumerate(folds):
            train_start = common_dates.min()
            train_jt, train_base, train_v_marg, train_c_marg = (
                _aggregate_joint_lift(
                    panel_w_fwd, vix_regime, corr_regime,
                    train_start, train_end,
                )
            )
            test_jt, test_base, test_v_marg, test_c_marg = (
                _aggregate_joint_lift(
                    panel_w_fwd, vix_regime, corr_regime,
                    test_start, test_end,
                )
            )
            fold_results.append({
                "train_jt":     train_jt,
                "test_jt":      test_jt,
                "train_v_marg": train_v_marg,
                "train_c_marg": train_c_marg,
                "test_v_marg":  test_v_marg,
                "test_c_marg":  test_c_marg,
                "train_base":   train_base,
                "test_base":    test_base,
            })

            emit(_DIV_WIDE)
            emit(f"FOLD {fi + 1}: train → {train_end.date()} | "
                 f"test {test_start.date()} → {test_end.date()}")
            emit(_DIV_WIDE)
            emit(f"  Train baseline: {train_base:+.2f}pp  |  "
                 f"Test baseline: {test_base:+.2f}pp")
            emit("")
            emit("  Marginal lifts (test fold):")
            for v in _VIX_REGIMES:
                m = test_v_marg[v]
                emit(f"    VIX {v:<8} {m['lift_pp']:>+7.2f}pp  "
                     f"(n={m['n_obs']})")
            for c in _CORR_REGIMES:
                m = test_c_marg[c]
                emit(f"    CORR {c:<8} {m['lift_pp']:>+7.2f}pp  "
                     f"(n={m['n_obs']})")
            emit("")
            emit("  Joint-cell lifts (test fold):")
            emit(f"  {'VIX':<10} {'CORR':<10} {'TRAIN_LIFT':>11} "
                 f"{'TEST_LIFT':>11} {'TEST_N':>9}  {'INCR':>7}")
            for v in _VIX_REGIMES:
                for c in _CORR_REGIMES:
                    tr = train_jt.get((v, c), {"lift_pp": 0, "n_obs": 0})
                    te = test_jt.get((v, c), {"lift_pp": 0, "n_obs": 0})
                    # Incremental lift over the larger marginal
                    larger_marg = max(
                        abs(test_v_marg[v]["lift_pp"]),
                        abs(test_c_marg[c]["lift_pp"]),
                    )
                    if abs(te["lift_pp"]) > larger_marg:
                        incr = abs(te["lift_pp"]) - larger_marg
                        incr_str = f"+{incr:.2f}"
                    else:
                        incr_str = "—"
                    emit(f"  {v:<10} {c:<10} "
                         f"{tr['lift_pp']:>+10.2f}pp "
                         f"{te['lift_pp']:>+10.2f}pp "
                         f"{te['n_obs']:>9d}  {incr_str:>7}")
            emit("")

        # ── Aggregate verdict per joint cell ──────────────────
        emit(_DIV_WIDE)
        emit("FINAL SUMMARY — JOINT CELL VERDICTS")
        emit(_DIV_WIDE)
        emit("Ship criteria (all three must hold):")
        emit(f"  a) Sign agreement ≥ {_SHIP_FOLD_AGREEMENT_THRESHOLD:.0%} "
             "across folds")
        emit(f"  b) |Mean test lift| ≥ {_SHIP_MIN_LIFT_PP}pp")
        emit(f"  c) |Mean test lift| exceeds larger marginal by "
             f"≥ {_SHIP_INCREMENTAL_LIFT_PP}pp")
        emit("")
        emit(f"  {'VIX':<8} | {'CORR':<8} | {'AGREE':>5} | "
             f"{'LIFT':>8} | {'INCR':>8} | SHIP")
        emit(_DIV_THIN)

        any_ship = False
        for v in _VIX_REGIMES:
            for c in _CORR_REGIMES:
                test_lifts = [
                    f["test_jt"].get((v, c), {"lift_pp": 0, "n_obs": 0})["lift_pp"]
                    for f in fold_results
                ]
                test_ns = [
                    f["test_jt"].get((v, c), {"lift_pp": 0, "n_obs": 0})["n_obs"]
                    for f in fold_results
                ]
                # Per-fold larger marginal — for the incremental
                # check we want the test-fold marginal in each fold
                fold_larger_marg = []
                fold_incr_lifts = []
                for fi, fr in enumerate(fold_results):
                    lm = max(
                        abs(fr["test_v_marg"][v]["lift_pp"]),
                        abs(fr["test_c_marg"][c]["lift_pp"]),
                    )
                    fold_larger_marg.append(lm)
                    fold_incr_lifts.append(
                        abs(test_lifts[fi]) - lm
                        if test_ns[fi] >= 50 else None
                    )

                valid = [
                    (li, n) for li, n in zip(test_lifts, test_ns) if n >= 50
                ]
                if not valid:
                    emit(f"  {v:<8} | {c:<8} | {'—':>5} | "
                         f"{'—':>8} | {'—':>8} | —  (no n≥50 folds)")
                    continue
                lifts_only = [v_[0] for v_ in valid]
                mean_lift = float(np.mean(lifts_only))
                same_sign = sum(
                    1 for li in lifts_only if (li >= 0) == (mean_lift >= 0)
                )
                agreement = same_sign / len(lifts_only)
                # Mean incremental lift across valid folds
                valid_incr = [x for x in fold_incr_lifts if x is not None]
                mean_incr = (
                    float(np.mean(valid_incr)) if valid_incr else -999
                )

                sign_ok = agreement >= _SHIP_FOLD_AGREEMENT_THRESHOLD
                lift_ok = abs(mean_lift) >= _SHIP_MIN_LIFT_PP
                incr_ok = mean_incr >= _SHIP_INCREMENTAL_LIFT_PP
                ship = sign_ok and lift_ok and incr_ok
                if ship:
                    any_ship = True
                ship_str = "YES" if ship else "—"
                emit(f"  {v:<8} | {c:<8} | "
                     f"{f'{agreement * 100:.0f}%':>5} | "
                     f"{mean_lift:>+7.2f}pp | "
                     f"{f'+{mean_incr:.2f}pp' if mean_incr > -100 else '—':>8} | "
                     f"{ship_str}")

        emit("")
        emit(_DIV_WIDE)
        if any_ship:
            emit("VERDICT: JOINT cells with incremental edge exist.")
            emit("Recommend surfacing as combined-state indicator")
            emit("alongside individual VIX and CORR badges.")
        else:
            emit("VERDICT: NO JOINT CELLS pass the stricter rule.")
            emit("Joint signals don't add edge beyond what the")
            emit("marginal VIX or CORR badges already carry. Don't")
            emit("ship a combined indicator. The two badges side-")
            emit("by-side already give the operator everything the")
            emit("data supports.")
        emit(_DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
