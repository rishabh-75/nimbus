"""nimbus_v3.context.sector_context — per-symbol sector context provider.

Produces a ``SectorContext`` by combining three inputs:

1. The symbol's sector — looked up from the injected ``Universe``'s
   ``SymbolMeta``. No hard-coded sector dictionary.
2. The sector index's price history — loaded via the injected index
   ``PriceLoader`` using a sector→yfinance-ticker map.
3. The broad-market index history — same loader, default ``^CRSLDX``
   (NIFTY 500) for the RS benchmark.

Computed fields
───────────────
- ``rs_regime``: LEADING / NEUTRAL / LAGGING based on a 3-pp threshold
  on ``rs_20d``.
- ``rs_20d``: sector 20-day return minus broad-market 20-day return,
  percentage points.
- ``realized_vol_20d``: annualised (√252) standard deviation of the
  sector's daily log returns over the last 20 trading days, in percent.
- ``vol_z_score``: z-score of ``realized_vol_20d`` versus the rolling
  1-year distribution of the same metric.

Sector type (CYCLICAL / DEFENSIVE) is left ``None`` here — it is
classified by Phase 7 research on per-sector sensitivity to rate and
commodity regimes, not hard-coded.
"""
from __future__ import annotations

import logging
from typing import Final

import numpy as np
import pandas as pd

from nimbus_v3.core.context import SectorContext
from nimbus_v3.core.types import RSRegime
from nimbus_v3.core.universe import Universe
from nimbus_v3.data.price_loader import PriceLoader


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Sector → yfinance ticker map
# ══════════════════════════════════════════════════════════════════════════════

#: Map from canonical sector name (as produced by ``UniverseBuilder``) to
#: the yfinance ticker for the corresponding sectoral index. Sectors
#: that don't have a dedicated yfinance ticker (or aren't mapped yet)
#: return ``None`` from :func:`_sector_to_ticker` and the provider
#: falls back to the broad-market index for that symbol.
_SECTOR_TICKERS: Final[dict[str, str]] = {
    "Banking": "^NSEBANK",
    "Private Banking": "^NSEBANK",      # closest available proxy
    "PSU Banking": "^CNXPSUBANK",
    "Information Technology": "^CNXIT",
    "Auto": "^CNXAUTO",
    "Pharmaceuticals": "^CNXPHARMA",
    "FMCG": "^CNXFMCG",
    "Metals": "^CNXMETAL",
    "Energy": "^CNXENERGY",
    "Realty": "^CNXREALTY",
    "Media": "^CNXMEDIA",
    "Consumer Durables": "^CNXCONSUM",
    "Oil & Gas": "^CNXENERGY",           # closest published proxy
    "Healthcare": "^CNXPHARMA",          # closest published proxy
    "Infrastructure": "^CNXINFRA",
}

#: Broad-market benchmark ticker for the RS calculation.
_DEFAULT_BROAD_TICKER: Final[str] = "^CRSLDX"  # NIFTY 500

#: RS-regime thresholds in percentage points of ``rs_20d``.
_RS_LEADING_PP: Final[float] = 3.0
_RS_LAGGING_PP: Final[float] = -3.0


# ══════════════════════════════════════════════════════════════════════════════
# Provider
# ══════════════════════════════════════════════════════════════════════════════

#: Known NSE indices with yfinance tickers. When a symbol isn't in the
#: loaded universe but IS a known index, the provider computes its
#: context using the index's own price series rather than returning
#: None — what the operator expects on the Dashboard when clicking
#: NIFTY / BANKNIFTY etc.
_INDEX_TICKERS: Final[dict[str, str]] = {
    "NIFTY":      "^NSEI",
    "BANKNIFTY":  "^NSEBANK",
    "FINNIFTY":   "NIFTY_FIN_SERVICE.NS",
    "MIDCPNIFTY": "NIFTY_MID_SELECT.NS",
    "NIFTYNXT50": "^NSMIDCP",    # closest widely-served proxy
}

#: Display name mapping for indices — shown in the Sector Context
#: section in lieu of an actual sector.
_INDEX_DISPLAY_NAME: Final[dict[str, str]] = {
    "NIFTY":      "NIFTY 50 Index",
    "BANKNIFTY":  "Bank Nifty Index",
    "FINNIFTY":   "Fin Services Index",
    "MIDCPNIFTY": "Midcap Select Index",
    "NIFTYNXT50": "NIFTY Next 50 Index",
}


class SectorContextProvider:
    """``ContextProvider[SectorContext]`` over Universe + index PriceLoader.

    The same ``PriceLoader`` class is used for both equities and indices;
    the caller constructs this one with ``yfinance_suffix=""`` so the
    ``^NSEBANK``-style tickers pass through unchanged.
    """

    def __init__(
        self,
        index_price_loader: PriceLoader,
        universe: Universe,
        *,
        broad_ticker: str = _DEFAULT_BROAD_TICKER,
        sector_tickers: dict[str, str] | None = None,
        rs_leading_pp: float = _RS_LEADING_PP,
        rs_lagging_pp: float = _RS_LAGGING_PP,
    ) -> None:
        self._loader = index_price_loader
        self._universe = universe
        self._broad_ticker = broad_ticker
        self._sector_tickers = (
            sector_tickers if sector_tickers is not None else dict(_SECTOR_TICKERS)
        )
        self._rs_leading = rs_leading_pp
        self._rs_lagging = rs_lagging_pp

    def build(
        self,
        *,
        symbol: str | None,
        asof_date: pd.Timestamp,
    ) -> SectorContext | None:
        if not symbol:
            return None
        sym = symbol.upper()
        asof = _normalise(asof_date)

        # ── Index path ────────────────────────────────────────────────
        # Symbols that map to a known index ticker get their own
        # SectorContext computed from the index's own series — RS
        # defined as zero vs self, vol from the index's 20d returns.
        # This replaces the "stock not in index" empty state when an
        # operator clicks NIFTY / BANKNIFTY / FINNIFTY / etc.
        if sym in _INDEX_TICKERS:
            idx_ticker = _INDEX_TICKERS[sym]
            from nimbus_v3.core.types import RSRegime
            vol_20d: float | None = None
            vol_z: float | None = None
            try:
                idx_hist = self._loader.load(idx_ticker)
                if idx_hist is not None and not idx_hist.empty:
                    vol_20d = _annualised_vol(idx_hist, asof, window=20)
                    vol_z = _vol_zscore(
                        idx_hist, asof,
                        short_window=20, baseline_window=252,
                    )
                    logger.info(
                        "sector_context: %s (index path) vol_20d=%s vol_z=%s "
                        "from %d bars of %s",
                        sym,
                        f"{vol_20d:.2f}" if vol_20d is not None else "—",
                        f"{vol_z:+.2f}" if vol_z is not None else "—",
                        len(idx_hist), idx_ticker,
                    )
                else:
                    logger.warning(
                        "sector_context: %s → %s fetch returned empty; "
                        "rendering panel without vol numbers",
                        sym, idx_ticker,
                    )
            except Exception:    # noqa: BLE001
                logger.exception(
                    "sector_context: %s → %s fetch raised; "
                    "rendering panel without vol numbers",
                    sym, idx_ticker,
                )
            # Always return a populated SectorContext — the panel is
            # useful even without vol numbers (sector_name + industry
            # tell the operator which index they're looking at).
            return SectorContext(
                asof_date=asof,
                symbol=sym,
                sector_name=_INDEX_DISPLAY_NAME.get(sym, sym),
                sector_type=None,
                rs_regime=RSRegime.NEUTRAL,    # self vs self — no drift
                rs_20d=0.0,
                realized_vol_20d=vol_20d if vol_20d is not None else 0.0,
                vol_z_score=vol_z,
                macro_sector="Index",
                industry="Broad Market",
                basic_industry=_INDEX_DISPLAY_NAME.get(sym, sym),
            )

        # ── Equity path ──────────────────────────────────────────────
        # Prefer the loaded universe's SymbolMeta (set by scan);
        # fall back to the 495-entry industry_db for pre-scan calls
        # when the universe is still empty. Without the fallback,
        # every pre-scan equity click shows 'Sector context
        # unavailable' even though we have the data on disk.
        meta = self._universe.symbols.get(sym)
        if meta is None:
            try:
                from nimbus_v3.data.industry_db import load_industry_db
                entry = load_industry_db().get(sym)
            except Exception:    # noqa: BLE001
                logger.exception(
                    "sector_context: industry_db load failed for %s", sym,
                )
                entry = None
            if entry is None:
                return None
            # Build a minimal SymbolMeta shim so the rest of the path
            # works unchanged. Uses the DB's sector naming so the
            # sector-ticker lookup hits.
            from nimbus_v3.core.universe import SymbolMeta
            meta = SymbolMeta(
                symbol=sym,
                macro_sector=entry.macro_sector,
                sector=entry.sector,
                industry=entry.industry,
                basic_industry=entry.basic_industry,
            )

        sector_name = meta.sector
        sector_ticker = self._sector_tickers.get(sector_name)

        broad_hist = self._loader.load(self._broad_ticker) if self._broad_ticker else pd.DataFrame()
        sector_hist = (
            self._loader.load(sector_ticker) if sector_ticker else pd.DataFrame()
        )

        rs_20d = _rs_20d(sector_hist, broad_hist, asof)
        rs_regime = _classify_rs(rs_20d, self._rs_leading, self._rs_lagging)
        vol_20d = _annualised_vol(sector_hist, asof, window=20)
        vol_z = _vol_zscore(sector_hist, asof, short_window=20, baseline_window=252)

        return SectorContext(
            asof_date=asof,
            symbol=sym,
            sector_name=sector_name,
            sector_type=None,          # Phase 7 research decides.
            rs_regime=rs_regime,
            rs_20d=rs_20d if rs_20d is not None else 0.0,
            realized_vol_20d=vol_20d if vol_20d is not None else 0.0,
            vol_z_score=vol_z,
            macro_sector=meta.macro_sector,
            industry=meta.industry,
            basic_industry=meta.basic_industry,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Helpers — pure, separately testable
# ══════════════════════════════════════════════════════════════════════════════

def _normalise(ts: pd.Timestamp) -> pd.Timestamp:
    t = pd.Timestamp(ts)
    if t.tz is not None:
        t = t.tz_localize(None)
    return t.normalize()


def _roc(df: pd.DataFrame, asof: pd.Timestamp, *, window: int) -> float | None:
    if df is None or df.empty:
        return None
    eligible = df.loc[:asof]
    if len(eligible) < window + 1:
        return None
    close_now = float(eligible["Close"].iloc[-1])
    close_then = float(eligible["Close"].iloc[-(window + 1)])
    if close_then == 0 or np.isnan(close_then):
        return None
    return (close_now / close_then - 1.0) * 100.0


def _rs_20d(
    sector_hist: pd.DataFrame,
    broad_hist: pd.DataFrame,
    asof: pd.Timestamp,
) -> float | None:
    sec_roc = _roc(sector_hist, asof, window=20)
    broad_roc = _roc(broad_hist, asof, window=20)
    if sec_roc is None or broad_roc is None:
        return None
    return sec_roc - broad_roc


def _classify_rs(rs_20d: float | None, leading: float, lagging: float) -> RSRegime:
    if rs_20d is None:
        return RSRegime.NEUTRAL
    if rs_20d >= leading:
        return RSRegime.LEADING
    if rs_20d <= lagging:
        return RSRegime.LAGGING
    return RSRegime.NEUTRAL


def _annualised_vol(
    df: pd.DataFrame, asof: pd.Timestamp, *, window: int,
) -> float | None:
    """Annualised (√252) realised vol of daily log returns, percent."""
    if df is None or df.empty:
        return None
    eligible = df.loc[:asof]
    if len(eligible) < window + 1:
        return None
    closes = eligible["Close"].iloc[-(window + 1) :]
    with np.errstate(invalid="ignore", divide="ignore"):
        log_rets = np.log(closes / closes.shift(1)).dropna()
    if len(log_rets) < window:
        return None
    sigma_daily = float(log_rets.std(ddof=0))
    if np.isnan(sigma_daily) or sigma_daily == 0:
        return 0.0
    return sigma_daily * np.sqrt(252) * 100.0


def _vol_zscore(
    df: pd.DataFrame,
    asof: pd.Timestamp,
    *,
    short_window: int,
    baseline_window: int,
) -> float | None:
    """Z-score of the current ``short_window`` annualised vol vs. the
    distribution of the same metric over the preceding
    ``baseline_window`` trading days."""
    if df is None or df.empty:
        return None
    eligible = df.loc[:asof]
    if len(eligible) < short_window + baseline_window + 1:
        return None
    closes = eligible["Close"]
    with np.errstate(invalid="ignore", divide="ignore"):
        log_rets = np.log(closes / closes.shift(1))
    # Rolling std of log returns × √252 × 100.
    rolling_vol = (
        log_rets.rolling(window=short_window, min_periods=short_window).std(ddof=0)
        * np.sqrt(252)
        * 100.0
    )
    clean = rolling_vol.dropna()
    if len(clean) < baseline_window + 1:
        return None
    current = float(clean.iloc[-1])
    baseline = clean.iloc[-(baseline_window + 1) : -1]
    mu = float(baseline.mean())
    sigma = float(baseline.std(ddof=0))
    if sigma == 0 or np.isnan(sigma):
        return None
    return (current - mu) / sigma
