"""nimbus_v3.core.fno_symbols — NSE F&O eligible symbol list.

The list is hardcoded rather than fetched because:
    1. NSE changes the F&O universe quarterly — drift is slow.
    2. The file is small and reviewable in diffs; a live fetch on
       startup adds network latency to every launch and silently
       fails behind firewalls.
    3. Downstream code (:class:`Sidebar`, scanner fallbacks) can
       import this unconditionally without waiting on HTTP.

Scope
─────
* Indexes: NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, NIFTYNXT50 —
  the symbols with listed index options on NSE.
* Single-stock F&O: the ~180 equities carrying listed futures &
  options, drawn from NSE's F&O eligibility list. Ordering is
  alphabetical for deterministic combo layout.

If a symbol the operator wants isn't here, the sidebar's manual
entry box still works — the combo is a convenience, not a gate.
"""
from __future__ import annotations

from typing import Final


#: Index options — always at the top of the combo so operators
#: looking for NIFTY / BANKNIFTY don't have to scroll.
FNO_INDEX_SYMBOLS: Final[tuple[str, ...]] = (
    "NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTYNXT50",
)


#: Equity F&O list — NSE derivatives-eligible stocks. Kept sorted
#: alphabetically so the combo renders in a predictable order.
FNO_EQUITY_SYMBOLS: Final[tuple[str, ...]] = (
    "AARTIIND", "ABB", "ABBOTINDIA", "ABCAPITAL", "ABFRL",
    "ACC", "ADANIENSOL", "ADANIENT", "ADANIGREEN", "ADANIPORTS",
    "ALKEM", "AMBUJACEM", "ANGELONE", "APLAPOLLO", "APOLLOHOSP",
    "APOLLOTYRE", "ASHOKLEY", "ASIANPAINT", "ASTRAL", "ATGL",
    "AUBANK", "AUROPHARMA", "AXISBANK", "BAJAJ-AUTO", "BAJAJFINSV",
    "BAJFINANCE", "BALKRISIND", "BALRAMCHIN", "BANDHANBNK", "BANKBARODA",
    "BANKINDIA", "BATAINDIA", "BEL", "BERGEPAINT", "BHARATFORG",
    "BHARTIARTL", "BHEL", "BIOCON", "BOSCHLTD", "BPCL",
    "BRITANNIA", "BSE", "BSOFT", "CAMS", "CANBK",
    "CANFINHOME", "CDSL", "CESC", "CGPOWER", "CHAMBLFERT",
    "CHOLAFIN", "CIPLA", "COALINDIA", "COFORGE", "COLPAL",
    "CONCOR", "COROMANDEL", "CROMPTON", "CUMMINSIND", "CYIENT",
    "DABUR", "DALBHARAT", "DEEPAKNTR", "DELHIVERY", "DIVISLAB",
    "DIXON", "DLF", "DMART", "DRREDDY", "EICHERMOT",
    "ESCORTS", "EXIDEIND", "FEDERALBNK", "FINCABLES", "FORTIS",
    "GAIL", "GLENMARK", "GMRAIRPORT", "GNFC", "GODREJCP",
    "GODREJPROP", "GRANULES", "GRASIM", "HAL", "HAVELLS",
    "HCLTECH", "HDFCAMC", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO",
    "HFCL", "HINDALCO", "HINDCOPPER", "HINDPETRO", "HINDUNILVR",
    "HUDCO", "ICICIBANK", "ICICIGI", "ICICIPRULI", "IDEA",
    "IDFCFIRSTB", "IEX", "IGL", "INDHOTEL", "INDIACEM",
    "INDIANB", "INDIGO", "INDUSINDBK", "INDUSTOWER", "INFY",
    "IOC", "IRB", "IRCTC", "IRFC", "ITC",
    "JINDALSTEL", "JIOFIN", "JKCEMENT", "JSL", "JSWENERGY",
    "JSWSTEEL", "JUBLFOOD", "KALYANKJIL", "KEI", "KOTAKBANK",
    "KPITTECH", "LALPATHLAB", "LAURUSLABS", "LICHSGFIN", "LICI",
    "LT", "LTF", "LTIM", "LTTS", "LUPIN",
    "M&M", "M&MFIN", "MANAPPURAM", "MARICO", "MARUTI",
    "MAXHEALTH", "MCX", "METROPOLIS", "MFSL", "MGL",
    "MOTHERSON", "MPHASIS", "MRF", "MUTHOOTFIN", "NATIONALUM",
    "NAUKRI", "NBCC", "NCC", "NESTLEIND", "NHPC",
    "NMDC", "NTPC", "NYKAA", "OBEROIRLTY", "OFSS",
    "OIL", "ONGC", "PAGEIND", "PATANJALI", "PAYTM",
    "PEL", "PERSISTENT", "PETRONET", "PFC", "PGEL",
    "PHOENIXLTD", "PIDILITIND", "PIIND", "PNB", "POLICYBZR",
    "POLYCAB", "POONAWALLA", "POWERGRID", "PRESTIGE", "RBLBANK",
    "RECLTD", "RELIANCE", "SAIL", "SBICARD", "SBILIFE",
    "SBIN", "SHREECEM", "SHRIRAMFIN", "SIEMENS", "SJVN",
    "SOLARINDS", "SONACOMS", "SRF", "SUNPHARMA", "SUNTV",
    "SUPREMEIND", "SYNGENE", "TATACHEM", "TATACOMM", "TATACONSUM",
    "TATAELXSI", "TATAMOTORS", "TATAPOWER", "TATASTEEL", "TATATECH",
    "TCS", "TECHM", "TIINDIA", "TITAGARH", "TITAN",
    "TORNTPHARM", "TORNTPOWER", "TRENT", "TVSMOTOR", "UBL",
    "ULTRACEMCO", "UNIONBANK", "UNITDSPR", "UPL", "VBL",
    "VEDL", "VOLTAS", "WIPRO", "YESBANK", "ZYDUSLIFE",
)


#: Combined list — indices first, then equities alphabetical. This
#: is what the sidebar combo shows by default when no live universe
#: is loaded.
FNO_ALL_SYMBOLS: Final[tuple[str, ...]] = (
    FNO_INDEX_SYMBOLS + FNO_EQUITY_SYMBOLS
)


__all__ = (
    "FNO_INDEX_SYMBOLS",
    "FNO_EQUITY_SYMBOLS",
    "FNO_ALL_SYMBOLS",
)
