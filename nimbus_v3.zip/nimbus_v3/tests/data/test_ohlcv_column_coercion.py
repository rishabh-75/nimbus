"""Regression: yfinance column-layout chaos must never reach parquet.

The observed crash: yfinance returned duplicate flat columns
(['Open','Open',...]); the old normalize's ``df[wanted]`` kept both, and
``to_parquet`` died with "Duplicate column names found". These pin every
layout the loaders have to survive, and that both loaders share one fix.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.data.base import coerce_ohlcv_columns

_CANON = ["Open", "High", "Low", "Close", "Volume"]


def _idx(n=5):
    return pd.date_range("2026-01-01", periods=n)


@pytest.mark.parametrize("cols", [
    pytest.param(pd.MultiIndex.from_tuples(
        [(f, "RELIANCE.NS") for f in _CANON]), id="multiindex-field-first"),
    pytest.param(pd.MultiIndex.from_tuples(
        [("RELIANCE.NS", f) for f in _CANON]), id="multiindex-ticker-first"),
    pytest.param(["Open", "Open", "High", "High", "Low", "Low",
                  "Close", "Close", "Volume", "Volume"], id="flat-duplicated"),
    pytest.param(_CANON, id="clean-flat"),
    pytest.param(["Open", "High", "Low", "Close", "Adj Close", "Volume"],
                 id="with-adj-close"),
])
def test_coerce_yields_clean_unique_columns(cols):
    ncols = len(cols)
    df = pd.DataFrame(np.random.rand(5, ncols), index=_idx(), columns=cols)
    out = coerce_ohlcv_columns(df)
    assert list(out.columns) == _CANON
    assert not out.columns.duplicated().any()


def test_result_survives_parquet(tmp_path):
    """The actual failure mode: the write must succeed."""
    df = pd.DataFrame(
        np.random.rand(5, 10), index=_idx(),
        columns=["Open", "Open", "High", "High", "Low", "Low",
                 "Close", "Close", "Volume", "Volume"])
    out = coerce_ohlcv_columns(df)
    out.to_parquet(tmp_path / "t.parquet", engine="pyarrow")   # must not raise


def test_ticker_first_multiindex_keeps_field_names_not_tickers():
    """The subtle one: flattening to level 0 blindly would give ticker
    strings. The helper must pick the field level."""
    df = pd.DataFrame(
        np.random.rand(5, 5), index=_idx(),
        columns=pd.MultiIndex.from_tuples([("RELIANCE.NS", f)
                                           for f in _CANON]))
    out = coerce_ohlcv_columns(df)
    assert list(out.columns) == _CANON


def test_both_loaders_use_the_shared_helper():
    """Guard against re-duplicating the logic — the two normalize paths
    must both route through coerce_ohlcv_columns."""
    import inspect

    from nimbus_v3.data import intraday_loader, price_loader
    assert "coerce_ohlcv_columns" in inspect.getsource(
        price_loader.PriceLoader._normalize)
    assert "coerce_ohlcv_columns" in inspect.getsource(
        intraday_loader.IntradayLoader._normalize)


def test_empty_is_safe():
    assert coerce_ohlcv_columns(pd.DataFrame()).empty
