"""nimbus_v3.ui.widgets.dashboard_tab — single-symbol cockpit.

Slim layout (post-refactor)
───────────────────────────

    ┌─────────────────────────────────────────┬───────────────────────┐
    │ Header strip                             │ Workflow Analysis      │
    │   SYMBOL  SPOT  ±%        timestamp      │ ─ Options Overlay      │
    ├─────────────────────────────────────────┤                        │
    │                                          │ ─ Industry Context     │
    │                                          │                        │
    │              Price chart                 │                        │
    │              (BB envelope, SMA20,        │                        │
    │               options walls overlay)     │                        │
    │                                          │                        │
    │                                          │                        │
    └─────────────────────────────────────────┴───────────────────────┘

Public API (locked)
───────────────────
    :meth:`set_symbol(symbol, *, enriched_df, options_ctx, industry,
                       member_count, asof_label)`
    :meth:`clear()`

The dashboard receives pre-built domain objects from MainWindow
(enriched dataframe, OptionsContext). It does NOT call any provider or
classifier directly — interpretation routing is MainWindow's job;
rendering is the dashboard's.
"""
from __future__ import annotations

import logging

import pandas as pd
from PyQt6.QtCore import QSize, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QIcon
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSplitter,
    QTabWidget, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.seasonality import compute_seasonality
from nimbus_v3.core.context import OptionsContext
from nimbus_v3.core.universe import Universe
from nimbus_v3.ui.presenters import (
    EMPTY_HEADER_VIEW, HeaderView, build_header_view,
)
from nimbus_v3.ui.theme import (
    BORDER, EM, FONT_MONO, FONT_UI, MUTED,
    SURFACE, WHITE,
)
from nimbus_v3.ui.widgets.industry_tables import (
    ConstituentsTable, IndustriesTable,
)
from nimbus_v3.ui.widgets.price_chart import PriceChart
from nimbus_v3.ui.widgets.watchlist_panel import WatchlistPanel
from nimbus_v3.ui.widgets.seasonality_widget import SeasonalityWidget


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Local style helpers
# ══════════════════════════════════════════════════════════════════════════════


def _mono(size: int, bold: bool = False) -> QFont:
    f = QFont(FONT_MONO, size)
    f.setBold(bold)
    return f


def _sans(size: int, bold: bool = False) -> QFont:
    f = QFont(FONT_UI, size)
    f.setBold(bold)
    return f


def _kv_row(label: str, *, value_font_size: int = 9) -> tuple[QWidget, QLabel]:
    """Build a label/value row. Returns ``(row_widget, value_label)``
    so the caller can update the value later."""
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(8)
    k = QLabel(label.upper())
    k.setFont(_sans(7))
    k.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
    k.setFixedWidth(96)
    lay.addWidget(k)
    v = QLabel("—")
    v.setFont(_mono(value_font_size, bold=True))
    v.setStyleSheet(f"color: {MUTED};")
    v.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    lay.addWidget(v, stretch=1)
    return w, v


# ══════════════════════════════════════════════════════════════════════════════
# Dashboard tab
# ══════════════════════════════════════════════════════════════════════════════


class DashboardTab(QWidget):
    """Single-symbol trading cockpit + embedded industry/constituents
    tables (unified profile).

    Public API:
        ``set_symbol(symbol, *, enriched_df=None,
            options_ctx=None, industry=None,
            member_count=0, asof_label="")`` — render the chart-side
            cockpit for one symbol.

        ``set_panel(panel, universe)`` — push the enriched panel +
            universe down to the embedded Industries table.

        ``clear()`` — return every panel to empty state.

    Signals:
        ``symbol_activated(str)`` — emitted when the operator
            double-clicks a row in the embedded Constituents table.
            MainWindow connects this to the symbol-load pathway.

    Selection model:
        - Sidebar drives the chart only — the tables don't move
          when the user picks a symbol from the combo. This is
          intentional: the operator can keep one symbol on the chart
          while exploring industry context independently below.
        - Click on Industries → repopulate Constituents (chart stays).
        - Double-click on Constituents → emits ``symbol_activated``;
          MainWindow loads the symbol on the chart.

    This widget owns layout and view rendering only. All domain types
    are produced by MainWindow (which talks to compute, classifiers,
    and providers) and passed in.
    """

    symbol_activated = pyqtSignal(str)
    #: Chart-toolbar controls. The Dashboard does not act on these itself —
    #: MainWindow owns the options fetch and the watchlist persistence.
    add_to_watchlist = pyqtSignal(str)          # symbol to watchlist
    options_overlay_toggled = pyqtSignal(bool)  # True = fetch + draw options

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._symbol: str = ""
        # Captured by set_panel; used by _on_industry_selected to
        # rebuild the constituents table from the same panel.
        self._panel: dict[str, pd.DataFrame] = {}
        self._universe: Universe | None = None
        # Populated by ``set_panel``; consumed by the embedded
        # Tracked across set_symbol() calls so set_panel() can
        # default the Constituents table to the active chart
        # symbol's industry — gives the operator a populated
        # bottom strip without requiring a click.
        self._current_industry: str | None = None
        self._build_ui()
        self.clear()

    def showEvent(self, event):    # noqa: ANN001, N802
        """Set the chart/tables split to 60/40 the first time the tab
        becomes visible, when it finally has a real height. Done once;
        afterwards the operator's manual drags are preserved.

        Skipped while the tables are collapsed — forcing a 60/40 split then
        would hand 40% of the height to a hidden widget, leaving a dead band
        under the chart.
        """
        super().showEvent(event)
        if self._tables_collapsed:
            self._apply_collapsed_sizes()
            return
        if not self._v_split_sized:
            h = self._v_split.height()
            if h > 0:
                self._v_split.setSizes([int(h * 0.6), int(h * 0.4)])
                self._v_split_sized = True

    def _apply_collapsed_sizes(self) -> None:
        """Give the chart everything except the toggle bar's own height.

        The splitter handle takes a pixel or two of its own, so we subtract
        that too — otherwise the chart is sized a hair too tall and its
        bottom axis gets clipped.
        """
        h = self._v_split.height()
        if h <= 0:
            return
        bar = self._tables_toggle.height() or 22
        handle = self._v_split.handleWidth()
        self._v_split.setSizes([max(0, h - bar - handle), bar])

    def _sync_tables_toggle(self) -> None:
        """Keep the toggle's caption in step with the collapsed state."""
        if self._tables_collapsed:
            self._tables_toggle.setText("\u25b2  INDUSTRIES · CONSTITUENTS")
            self._tables_toggle.setToolTip("Show the industry tables")
        else:
            self._tables_toggle.setText("\u25bc  INDUSTRIES · CONSTITUENTS")
            self._tables_toggle.setToolTip("Hide the industry tables")

    def _toggle_tables(self) -> None:
        """Collapse / expand the bottom tables strip."""
        self._tables_collapsed = not self._tables_collapsed
        self._tables_body.setVisible(not self._tables_collapsed)
        self._sync_tables_toggle()
        if self._tables_collapsed:
            self._apply_collapsed_sizes()
        else:
            h = self._v_split.height()
            if h > 0:
                self._v_split.setSizes([int(h * 0.6), int(h * 0.4)])
                self._v_split_sized = True

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def set_symbol(
        self,
        symbol: str,
        *,
        enriched_df: pd.DataFrame | None = None,
        options_ctx: OptionsContext | None = None,
        industry: str | None = None,
        company: str = "",
        member_count: int = 0,
        asof_label: str = "",
    ) -> None:
        """Render the dashboard for ``symbol`` from pre-built artefacts.

        Args:
            symbol: ticker text shown in the header.
            enriched_df: indicator-enriched OHLCV. Used for the chart
                and the header's spot/delta. Empty / ``None`` keeps the
                empty placeholder.
            options_ctx: live :class:`OptionsContext` if the symbol is
                F&O-listed. Drives both the chart's wall overlay and
                the Options Overlay panel on the right rail.
            industry: NSE four-level "industry" string for this symbol.
                Used for the Constituents table auto-select.
            member_count: peers contributing to the industry.
            asof_label: free-form date/time string for the header.
        """
        prev_symbol = self._symbol
        self._symbol = symbol or ""
        symbol_changed = (self._symbol != prev_symbol)
        # Stash for set_panel-driven Constituents auto-select. Updated
        # whether the chart load succeeded or not — operator picked
        # this symbol and that's the industry we should default to.
        self._current_industry = industry

        # Header.
        self.apply_header(
            build_header_view(
                self._symbol, enriched_df, asof_label=asof_label,
                company=company)
        )

        # Chart.
        self._chart.set_data(
            enriched_df, options=options_ctx,
            bars=PriceChart.MAX_BARS, focus_bars=PriceChart.DEFAULT_BARS,
        )

        # Per-symbol seasonality (sub-tab beside the chart). Computed
        # from the enriched frame's Close; renders its own empty-state
        # if the symbol has < 3 years of history.
        if enriched_df is not None and not enriched_df.empty \
                and "Close" in enriched_df.columns:
            self._seasonality.set_result(compute_seasonality(enriched_df["Close"]))

        # Sidebar Options Overlay (relocated from the deleted
        # right-rail). Industry Context Card was eliminated — its
        # info is already in the bottom-strip Industries table
        # roll-up + the Industry section of the sidebar.
        # ``industry`` and ``member_count``
        # are still accepted in the signature for compatibility but
        # only used for the table auto-select logic below.

        # If the panel is already loaded and the operator just
        # switched the chart to a symbol whose industry exists in
        # the table, mirror that selection over to the bottom
        # strip — but ONLY if the operator hasn't manually pinned a
        # different industry (don't yank the tables out from under
        # them — a programmatic default is overwriteable).
        #
        # This intentionally fires when browsing the ALL group:
        # double-clicking a constituent out of the universe-wide ALL
        # list pivots the Constituents table to that symbol's
        # industry, which is the natural "drill into this name's
        # peers" gesture. (ALL is a programmatic default, never a
        # pin, so it doesn't block the pivot.)
        #
        # Gated on ``symbol_changed`` so that data-refresh re-renders
        # of the *same* symbol (MainWindow._on_price_ready → re-render
        # on every price tick) do NOT re-pivot — that re-pivot was the
        # source of the tables jumping off the operator's current
        # group when fresh data landed.
        #
        # ALSO gated on NOT currently browsing ALL: when the operator is
        # on the universe-wide ALL list and picks a symbol, the
        # selection must STAY on ALL (sticky) rather than snapping to
        # that symbol's industry. ALL is a deliberate "scan everything"
        # view; selecting a name from it shouldn't collapse it.
        browsing_all = self._industries_table.selected_industry() == "ALL"
        if (
            symbol_changed
            and not browsing_all
            and self._panel
            and industry
            and self._industries_table.is_known_industry(industry)
            and not self._industries_table.is_user_pinned()
        ):
            self._industries_table.select_industry(industry)

    def apply_header(self, view: HeaderView) -> None:
        """Apply a pre-built header view (also called directly by
        MainWindow on freshness ticks)."""
        self._h_symbol_lbl.setText(view.symbol)
        self._h_company_lbl.setText(view.company or "")
        self._h_spot_lbl.setText(view.spot_text)
        self._h_change_lbl.setText(view.change_text)
        self._h_change_lbl.setStyleSheet(f"color: {view.change_color};")
        self._h_asof_lbl.setText(view.asof_text)
        self._h_asof_lbl.setStyleSheet(f"color: {view.asof_color};")


    def set_panel(
        self,
        panel: dict[str, pd.DataFrame] | None,
        universe: Universe | None,
    ) -> None:
        """Push the enriched panel + universe to the embedded
        Industries / Constituents tables.

        Called by MainWindow once the panel finishes loading. The
        tables compute their own Early-Entry scores cohort-relatively
        from the panel directly; no pre-built classification cache is
        needed any more.

        Args:
            panel: ``{symbol: enriched_df}``.
            universe: source for industry grouping + per-symbol metadata.

        Constituents auto-select rule:
          - If the chart's current industry is one of the visible
            rows, that row is selected.
          - Otherwise the pinned ALL row is selected so the bottom
            strip is never empty when there's data on screen.
        """
        self._panel = panel or {}
        self._universe = universe

        prev_selection = self._industries_table.selected_industry()
        prev_pinned = self._industries_table.is_user_pinned()

        self._industries_table.refresh(self._panel, universe)

        # If there was already a selection (the common case on a
        # data-refresh re-push), restore it verbatim — preserving
        # the pinned flag so a user-chosen industry stays pinned and
        # a subsequent set_symbol() won't pivot off it. Skip the
        # default-selection heuristic entirely.
        if (
            prev_selection is not None
            and self._industries_table.is_known_industry(prev_selection)
        ):
            self._industries_table.select_industry(
                prev_selection, user_initiated=prev_pinned,
            )
            return

        # No prior selection (genuine first panel load) — pick a
        # sensible default to populate Constituents.
        target = None
        if (
            self._current_industry
            and self._industries_table.is_known_industry(self._current_industry)
        ):
            target = self._current_industry
        elif self._industries_table.has_all_row():
            target = "ALL"
        if target is not None:
            self._industries_table.select_industry(target)
        else:
            self._constituents_table.clear()

    def clear(self) -> None:
        """Reset every panel to empty state."""
        self._symbol = ""
        self._panel = {}
        self._universe = None
        self._current_industry = None
        self.apply_header(EMPTY_HEADER_VIEW)
        self._chart.set_data(None, options=None)
        self._industries_table.clear()
        self._constituents_table.clear()

    # ══════════════════════════════════════════════════════════════════════
    # Internal slots
    # ══════════════════════════════════════════════════════════════════════

    def industry_riding_map(self) -> dict:
        """Per-industry ``{industry: (riders, members)}`` from the
        embedded Industries table — for ALL-cohort / watchlist
        participation scoring."""
        return self._industries_table.riding_map()

    def _on_industry_selected(self, industry: str) -> None:
        """Click on an industry row → repopulate the constituents
        table with that industry's members, scored cohort-relatively.

        The per-industry riding map (riders/members) is passed for the
        ALL cohort so the table can show participation context.
        """
        if not industry or not self._panel:
            self._constituents_table.clear()
            return
        members = self._industries_table.members_for(industry)
        riding = (
            self._industries_table.riding_map()
            if industry == "ALL" else None
        )
        self._constituents_table.set_industry(
            industry, members, self._panel, self._universe,
            industry_riding=riding,
        )

    # ══════════════════════════════════════════════════════════════════════
    # Build
    # ══════════════════════════════════════════════════════════════════════

    def _build_ui(self) -> None:
        root = QHBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        # ── Centre column: header + (chart over tables) ──────────────
        centre = QWidget()
        centre_lay = QVBoxLayout(centre)
        centre_lay.setContentsMargins(0, 0, 0, 0)
        centre_lay.setSpacing(8)

        centre_lay.addWidget(self._build_header_strip())

        # Vertical splitter — chart on top, tables strip on bottom.
        # Default 70/30 split; the operator can drag the divider.
        v_split = QSplitter(Qt.Orientation.Vertical)
        v_split.setChildrenCollapsible(False)
        # The handle is deliberately 1px and transparent. It used to be a
        # 6px BORDER-coloured bar, which sat directly under the chart and
        # ate the date-axis labels. The tables strip now has its own toggle
        # bar (which doubles as the visual divider), so a chunky grab handle
        # is redundant — it is kept only as a thin drag target for anyone who
        # wants to fine-tune the split by hand.
        v_split.setHandleWidth(1)
        v_split.setStyleSheet(
            "QSplitter::handle { background: transparent; }"
        )

        self._chart = PriceChart()
        self._chart.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding,
        )
        # Top area is a sub-tab: Price chart | per-symbol Seasonality.
        # Keeps the dashboard layout intact while giving seasonality the
        # full chart area when selected.
        self._top_tabs = QTabWidget()
        self._top_tabs.setTabPosition(QTabWidget.TabPosition.North)
        self._top_tabs.addTab(self._chart, "Price")
        self._seasonality = SeasonalityWidget()
        self._top_tabs.addTab(self._seasonality, "Seasonality")

        # ── Chart controls, parked in the sub-tab bar's corner ────────────
        # These are all CHART-level concerns, so they belong on the chart's
        # own tab bar rather than scattered down the sidebar (where the
        # options-overlay toggle and add-to-watchlist used to live, far from
        # the thing they act on).
        self._chart_controls = QWidget()
        cc = QHBoxLayout(self._chart_controls)
        cc.setContentsMargins(0, 0, 8, 0)
        cc.setSpacing(6)

        self._options_toggle = self._chart_btn(
            "OPT", "Options overlay — draw max-pain / OI walls. Off by "
                   "default: it forces an options fetch on every symbol load.",
            checkable=True)
        self._options_toggle.toggled.connect(
            self.options_overlay_toggled.emit)
        cc.addWidget(self._options_toggle)

        self._vp_toggle = self._chart_btn(
            "VP", "Volume profile — POC / value-area levels. RECONSTRUCTED "
                  "from daily bars (volume distributed across each day's "
                  "range, not measured at each price), so treat single-level "
                  "precision with suspicion.",
            checkable=True)
        self._vp_toggle.toggled.connect(self._chart.set_volume_profile_visible)
        cc.addWidget(self._vp_toggle)

        self._add_watch_btn = self._chart_btn(
            "+ WATCH", "Add the charted symbol to the watchlist")
        self._add_watch_btn.clicked.connect(self._on_add_to_watchlist)
        cc.addWidget(self._add_watch_btn)

        self._watch_toggle = self._chart_btn(
            "", "Show / hide the watchlist panel", checkable=True)
        self._watch_toggle.setIcon(self._watchlist_icon(MUTED))
        self._watch_toggle.setIconSize(QSize(16, 16))
        self._watch_toggle.setFixedWidth(38)
        # The icon is a painted pixmap, so it does NOT inherit the QSS
        # :checked colour the way text does — repaint it on state change or
        # the button's ON state would be invisible.
        self._watch_toggle.toggled.connect(
            lambda on: self._watch_toggle.setIcon(
                self._watchlist_icon(EM if on else MUTED)))
        cc.addWidget(self._watch_toggle)

        self._top_tabs.setCornerWidget(
            self._chart_controls, Qt.Corner.TopRightCorner)

        # Chart + watchlist share the splitter's TOP pane, side by side.
        #
        # Putting the watchlist inside this pane (rather than beside the
        # whole splitter) is what makes it track the chart's height: when
        # the bottom tables expand, the top pane shrinks and the watchlist
        # shrinks with it, staying exactly chart-height. A panel mounted
        # outside the splitter would instead span the full dashboard and
        # run past the tables.
        top_row = QWidget()
        top_lay = QHBoxLayout(top_row)
        top_lay.setContentsMargins(0, 0, 0, 0)
        top_lay.setSpacing(0)
        top_lay.addWidget(self._top_tabs, stretch=1)

        self._watchlist_panel = WatchlistPanel()
        top_lay.addWidget(self._watchlist_panel)

        # The panel no longer owns a visible spine — it is driven from the
        # toolbar button above, which is the discoverable place for it.
        self._watch_toggle.toggled.connect(
            self._watchlist_panel.set_expanded)

        v_split.addWidget(top_row)

        # Bottom strip: a slim always-visible toggle bar, above a
        # collapsible body holding the industries | constituents tables.
        #
        # The bar has to live OUTSIDE the collapsible part — if the whole
        # strip collapsed there would be nothing left to click to bring it
        # back, and the operator would have to hunt for the splitter handle.
        bottom = QWidget()
        bottom_lay = QVBoxLayout(bottom)
        bottom_lay.setContentsMargins(0, 0, 0, 0)
        bottom_lay.setSpacing(0)

        self._tables_toggle = QPushButton()
        self._tables_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self._tables_toggle.setFixedHeight(22)
        self._tables_toggle.setStyleSheet(
            f"QPushButton {{ background: {SURFACE}; color: {MUTED}; "
            f"border: none; border-top: 1px solid {BORDER}; "
            f"text-align: left; padding: 0 10px; "
            f"font-family: '{FONT_MONO}'; font-size: 8pt; }}"
            f"QPushButton:hover {{ color: {WHITE}; }}"
        )
        self._tables_toggle.clicked.connect(self._toggle_tables)
        bottom_lay.addWidget(self._tables_toggle)

        # The collapsible body.
        self._tables_body = QWidget()
        body_lay = QHBoxLayout(self._tables_body)
        body_lay.setContentsMargins(0, 0, 0, 0)
        body_lay.setSpacing(0)

        h_split = QSplitter(Qt.Orientation.Horizontal)
        h_split.setChildrenCollapsible(False)
        h_split.setHandleWidth(6)
        h_split.setStyleSheet(
            f"QSplitter::handle {{ background: {BORDER}; }}"
        )

        self._industries_table = IndustriesTable()
        self._constituents_table = ConstituentsTable()
        h_split.addWidget(self._industries_table)
        h_split.addWidget(self._constituents_table)
        # Default split: industries 40%, constituents 60% — the
        # constituents block is denser (more rows, longer Symbol
        # column) and benefits from the extra width.
        h_split.setStretchFactor(0, 2)
        h_split.setStretchFactor(1, 3)
        body_lay.addWidget(h_split)
        bottom_lay.addWidget(self._tables_body, stretch=1)

        # Floor the tables strip so the chart can't squeeze it down to
        # a sliver — the operator needs several constituent rows visible
        # at once. The splitter is still draggable above this minimum.
        #
        # NB this minimum applies to the BODY, not the whole strip: putting
        # it on `bottom` would fight the collapse, pinning the strip open at
        # 240px however hard we tried to shrink it.
        self._tables_body.setMinimumHeight(240)
        v_split.addWidget(bottom)

        # 60 / 40 chart-to-tables ratio. Stretch factors alone don't
        # reliably win over the chart's Expanding size hint on first
        # show, so we also set explicit sizes once the splitter has a
        # real height (see showEvent). This keeps startup at 60/40 while
        # leaving the handle fully draggable afterwards.
        v_split.setStretchFactor(0, 6)
        v_split.setStretchFactor(1, 4)
        self._v_split = v_split
        self._v_split_sized = False

        # Tables start COLLAPSED — the chart is the primary surface, and the
        # tables are a drill-down the operator opens when they want it.
        self._tables_collapsed = True
        self._tables_body.setVisible(False)
        self._sync_tables_toggle()

        # Wire selection — industry click drives constituent
        # repopulation. Single internal connection; MainWindow can
        # also call set_industry_panel() to push fresh data on
        # refresh.
        self._industries_table.industry_selected.connect(
            self._on_industry_selected,
        )
        # Bubble constituent double-clicks up as the public signal —
        # MainWindow uses this to load the symbol on the chart.
        self._constituents_table.symbol_activated.connect(
            self.symbol_activated,
        )

        centre_lay.addWidget(v_split, stretch=1)
        # Centre column spans the full width — the former Workflow
        # Analysis right rail (OPTIONS OVERLAY + INDUSTRY CONTEXT) was
        # removed; those panels now live in the sidebar. The chart +
        # bottom tables strip own the entire content area.
        root.addWidget(centre, stretch=1)

    def _build_header_strip(self) -> QFrame:
        strip = QFrame()
        strip.setFixedHeight(48)
        strip.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; "
            f"border-radius: 4px;"
        )

        lay = QHBoxLayout(strip)
        lay.setContentsMargins(14, 6, 14, 6)
        lay.setSpacing(18)

        self._h_symbol_lbl = QLabel("—")
        self._h_symbol_lbl.setFont(_mono(14, bold=True))
        self._h_symbol_lbl.setStyleSheet(f"color: {WHITE};")
        lay.addWidget(self._h_symbol_lbl)

        # Company name — the human-readable name for the ticker, sourced
        # from the industry DB. Muted so the ticker stays the anchor.
        self._h_company_lbl = QLabel("")
        self._h_company_lbl.setFont(_sans(11))
        self._h_company_lbl.setStyleSheet(f"color: {MUTED};")
        lay.addWidget(self._h_company_lbl)

        # Vertical divider before price.
        lay.addWidget(self._vbar())

        self._h_spot_lbl = QLabel("—")
        self._h_spot_lbl.setFont(_mono(13, bold=True))
        self._h_spot_lbl.setStyleSheet(f"color: {WHITE};")
        lay.addWidget(self._h_spot_lbl)

        self._h_change_lbl = QLabel("—")
        self._h_change_lbl.setFont(_mono(11, bold=True))
        self._h_change_lbl.setStyleSheet(f"color: {MUTED};")
        lay.addWidget(self._h_change_lbl)

        lay.addStretch(1)

        self._h_asof_lbl = QLabel("")
        self._h_asof_lbl.setFont(_mono(8))
        self._h_asof_lbl.setStyleSheet(f"color: {MUTED};")
        lay.addWidget(self._h_asof_lbl)

        return strip

    @staticmethod
    def _vbar() -> QFrame:
        bar = QFrame()
        bar.setFrameShape(QFrame.Shape.VLine)
        bar.setFixedWidth(1)
        bar.setStyleSheet(f"background: {BORDER}; border: none;")
        return bar

    @staticmethod
    def _watchlist_icon(colour: str) -> "QIcon":
        """A TradingView-style 'list' glyph, painted rather than typed.

        Drawn as a pixmap instead of using a unicode character: the glyph we
        want (a bordered list) is not reliably present across the fonts this
        app might land on, and a missing glyph renders as a tofu box.
        """
        from PyQt6.QtGui import QIcon, QPainter, QPen, QPixmap

        pm = QPixmap(16, 16)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        pen = QPen(QColor(colour))
        pen.setWidth(1)
        p.setPen(pen)
        # Outer frame + three "rows", i.e. a watchlist.
        p.drawRect(2, 1, 11, 13)
        for y in (4, 7, 10):
            p.drawLine(5, y, 11, y)
        p.end()
        return QIcon(pm)

    @staticmethod
    def _chart_btn(label: str, tooltip: str, *, checkable: bool = False):
        """A compact chart-toolbar button, styled like the sidebar's.

        Checkable buttons show their ON state with the emerald accent, so a
        live overlay is obvious at a glance rather than needing a checkbox
        the operator has to squint at.
        """
        b = QPushButton(label)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setFixedHeight(26)
        b.setCheckable(checkable)
        b.setToolTip(tooltip)
        b.setStyleSheet(
            f"QPushButton {{ background: {SURFACE}; color: {MUTED}; "
            f"border: 1px solid {BORDER}; border-radius: 3px; "
            f"padding: 0 10px; font-family: '{FONT_MONO}'; font-size: 10pt; "
            f"letter-spacing: 1px; }}"
            f"QPushButton:hover {{ color: {WHITE}; border-color: {MUTED}; }}"
            f"QPushButton:checked {{ color: {EM}; border-color: {EM}; }}"
        )
        return b

    def options_overlay_enabled(self) -> bool:
        """Is the options overlay switched on?

        MainWindow polls this before loading a symbol: when OFF it skips the
        options fetch entirely, so the symbol loads from the price cache
        alone (much faster) and the chart behaves exactly as if no options
        data existed.
        """
        return self._options_toggle.isChecked()

    def _on_add_to_watchlist(self) -> None:
        """Ask MainWindow to watchlist the charted symbol. The Dashboard
        does not own the watchlist — persistence stays in one place."""
        if self._symbol:
            self.add_to_watchlist.emit(self._symbol)

    @property
    def symbol(self) -> str:
        return self._symbol

    @property
    def watchlist_panel(self) -> WatchlistPanel:
        """The collapsible watchlist beside the chart. MainWindow owns the
        persistence and the add/remove decisions; this just exposes the
        widget so those signals can be wired."""
        return self._watchlist_panel
