"""Test fixtures for UI tests — offscreen Qt, shared QApplication."""
from __future__ import annotations

import os
import sys

# Must be set BEFORE the first QApplication construction. Conftest runs
# before any test imports, so setting it here covers every UI test.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PyQt6.QtWidgets import QApplication


@pytest.fixture(scope="session")
def qapp():
    """Session-scoped QApplication. Qt requires exactly one per process."""
    app = QApplication.instance() or QApplication(sys.argv)
    yield app
    # Do not call app.quit() — pytest tears down the process and letting
    # Qt clean up naturally is more reliable across platforms.
