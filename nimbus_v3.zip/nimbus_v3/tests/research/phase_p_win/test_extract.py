"""Tests for ``research.phase_p_win.extract``.

Three areas covered:

  1. **Ride-exit semantics.** Synthetic OHLCV with a known
     close-below-band bar exits at the right index and computes
     the right return.
  2. **Open-ride handling.** When the ride hasn't exited within
     available history, the event is flagged ``is_resolved=False``
     and outcome fields are ``None``.
  3. **Look-ahead safety.** Features computed at bar t equal the
     features computed on a frame truncated to bar t. Any leakage
     would show up as different feature values in the two passes.
  4. **Input validation.** Missing columns / short history /
     mismatched index lengths raise ValueError.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import RideEngine
from nimbus_v3.research.phase_p_win.extract import (
    extract_fire_events,
    events_to_dataframe,
)
from nimbus_v3.research.phase_p_win.schema import (
    FireEvent,
    MIN_HISTORY_BARS,
    REQUIRED_ENRICHED_COLUMNS,
)


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════════════


def _enriched_real(name: str = "AWL") -> pd.DataFrame:
    """Real enriched data — the parquets we use for regression."""
    df = pd.read_parquet(f"/mnt/user-data/uploads/{name}.parquet")
    return StrategyComputeEngine().enrich(df, name)


@pytest.fixture(scope="module")
def awl_enriched() -> pd.DataFrame:
    return _enriched_real("AWL")


@pytest.fixture(scope="module")
def awl_ride_result(awl_enriched):
    return RideEngine().classify(awl_enriched)


@pytest.fixture(scope="module")
def awl_events(awl_enriched, awl_ride_result):
    return extract_fire_events("AWL", awl_enriched, awl_ride_result)


# ══════════════════════════════════════════════════════════════════════════════
# Input validation
# ══════════════════════════════════════════════════════════════════════════════


class TestInputValidation:
    def test_missing_required_column_raises(self, awl_enriched, awl_ride_result):
        bad = awl_enriched.drop(columns=["sma_20"])
        with pytest.raises(ValueError, match="missing columns"):
            extract_fire_events("AWL", bad, awl_ride_result)

    def test_short_history_raises(self):
        engine = StrategyComputeEngine()
        # Only 50 bars — well below MIN_HISTORY_BARS.
        rng = np.random.default_rng(0)
        prices = 100 + np.cumsum(rng.normal(0, 1, 50))
        df = pd.DataFrame(
            {
                "Open": prices, "High": prices * 1.01, "Low": prices * 0.99,
                "Close": prices, "Volume": [1_000_000] * 50,
            },
            index=pd.bdate_range("2024-01-01", periods=50),
        )
        # enrich() may produce NaN-heavy frames at this length, but
        # the row count is what extract checks first.
        try:
            enriched = engine.enrich(df, "X")
        except Exception:
            pytest.skip("enrichment failed for tiny frame, can't test")

        # Build a synthetic empty RideResult of matching length.
        from nimbus_v3.compute.ride_initiation import RideResult
        rr = RideResult(
            phase=pd.Series(["NONE"] * len(enriched), index=enriched.index),
            score=pd.Series([float("nan")] * len(enriched), index=enriched.index),
            fire=pd.Series([False] * len(enriched), index=enriched.index),
        )
        with pytest.raises(ValueError, match="bars"):
            extract_fire_events("X", enriched, rr)

    def test_mismatched_index_length_raises(self, awl_enriched):
        from nimbus_v3.compute.ride_initiation import RideResult
        # RideResult shorter than enriched df.
        rr = RideResult(
            phase=pd.Series(["NONE"] * 100, index=awl_enriched.index[:100]),
            score=pd.Series([float("nan")] * 100, index=awl_enriched.index[:100]),
            fire=pd.Series([False] * 100, index=awl_enriched.index[:100]),
        )
        with pytest.raises(ValueError, match="must match"):
            extract_fire_events("AWL", awl_enriched, rr)

    def test_min_history_constant_locked(self):
        """The threshold is contractual — changes affect which
        symbols make it into the corpus."""
        assert MIN_HISTORY_BARS == 200

    def test_required_columns_complete(self):
        """Every column extract reads must be in the contract."""
        for col in (
            "Open", "High", "Low", "Close", "Volume",
            "sma_20", "bb_20_1s_upper", "bb_20_1s_lower",
            "bb_20_1s_mid", "bbw_20_1s", "bb_20_1s_pct",
        ):
            assert col in REQUIRED_ENRICHED_COLUMNS


# ══════════════════════════════════════════════════════════════════════════════
# Outcome — ride-exit semantics
# ══════════════════════════════════════════════════════════════════════════════


class TestOutcome:
    def test_resolved_event_has_complete_outcome(self, awl_events):
        """At least one resolved fire exists in AWL's history."""
        resolved = [e for e in awl_events if e.is_resolved]
        assert len(resolved) > 0
        for e in resolved:
            assert e.hold_bars is not None
            assert e.hold_bars >= 1
            assert e.exit_idx is not None
            assert e.exit_idx > e.trigger_idx
            assert e.return_pct is not None
            assert isinstance(e.return_pct, float)

    def test_unresolved_event_has_null_outcome(self, awl_events):
        """At least one fire is open (the most recent)."""
        unresolved = [e for e in awl_events if not e.is_resolved]
        # AWL's last fire today is RETEST, just opened — should be unresolved.
        if not unresolved:
            pytest.skip("AWL has no unresolved events in this fixture")
        for e in unresolved:
            assert e.hold_bars is None
            assert e.exit_idx is None
            assert e.return_pct is None

    def test_exit_is_first_bar_close_below_upper_band(self, awl_enriched, awl_events):
        """Verify the recorded exit_idx is the first bar after
        trigger where Close < bb_20_1s_upper."""
        closes = awl_enriched["Close"].values
        bb_upper = awl_enriched["bb_20_1s_upper"].values
        for e in awl_events:
            if not e.is_resolved:
                continue
            # Walk from trigger+1 to exit_idx; every bar before
            # exit must have close >= upper, and exit bar must
            # have close < upper.
            for j in range(e.trigger_idx + 1, e.exit_idx):
                u = bb_upper[j]
                c = closes[j]
                if not np.isfinite(c) or not np.isfinite(u):
                    continue
                assert c >= u, (
                    f"event at trigger={e.trigger_idx} should not have "
                    f"exited at {j} (close={c} >= upper={u}) but did at "
                    f"{e.exit_idx}"
                )
            assert closes[e.exit_idx] < bb_upper[e.exit_idx]

    def test_return_pct_matches_close_ratio(self, awl_enriched, awl_events):
        """Sanity: return_pct = (close[exit] / close[trigger] - 1) × 100."""
        closes = awl_enriched["Close"].values
        for e in awl_events:
            if not e.is_resolved:
                continue
            expected = 100.0 * (closes[e.exit_idx] / closes[e.trigger_idx] - 1)
            assert e.return_pct == pytest.approx(expected, abs=1e-6)


# ══════════════════════════════════════════════════════════════════════════════
# Look-ahead safety
# ══════════════════════════════════════════════════════════════════════════════


class TestLookAheadSafety:
    """Features at trigger t must equal the same features computed
    on a frame truncated to t. Otherwise we have leakage."""

    def test_features_invariant_under_truncation(self, awl_enriched, awl_ride_result):
        """Pick a fire roughly 60% through history. Re-compute
        features on the truncated frame ending at the trigger
        bar. They must match the full-frame features at that idx."""
        events_full = extract_fire_events("AWL", awl_enriched, awl_ride_result)
        # Pick a CONT event partway through (skip the very first
        # one to avoid warm-up edge cases).
        cont_events = [e for e in events_full if e.phase == "CONT"]
        assert len(cont_events) > 5, "need a few CONT events for this test"
        target = cont_events[len(cont_events) // 2]

        # Truncate enriched + ride_result to bar trigger_idx
        # (inclusive). The truncated extract would only have
        # access to bars ≤ trigger when computing features.
        cutoff = target.trigger_idx + 1    # +1 because slicing is exclusive
        df_trunc = awl_enriched.iloc[:cutoff].copy()

        # Need a RideResult that matches df_trunc's length and is
        # at least MIN_HISTORY_BARS. If trigger_idx is below that,
        # extract will refuse.
        if cutoff < MIN_HISTORY_BARS:
            pytest.skip("trigger too early — truncated frame too short")

        from nimbus_v3.compute.ride_initiation import RideResult
        rr_trunc = RideResult(
            phase=awl_ride_result.phase.iloc[:cutoff].copy(),
            score=awl_ride_result.score.iloc[:cutoff].copy(),
            fire=awl_ride_result.fire.iloc[:cutoff].copy(),
        )

        events_trunc = extract_fire_events("AWL", df_trunc, rr_trunc)
        # Find the same trigger in the truncated extract.
        match = [e for e in events_trunc if e.trigger_idx == target.trigger_idx]
        assert len(match) == 1, (
            f"expected to find trigger {target.trigger_idx} in truncated "
            f"extract; got {len(match)}"
        )
        truncated = match[0]

        # Features must be identical.
        feat_names = (
            "pct_b_at_trigger", "sma20_slope_pct", "sma50_slope_pct",
            "bb_width_pctile", "vol_ratio_20", "atr_14_pct",
            "bars_since_sma20_above_sma50", "body_above_count_prior_5",
        )
        for name in feat_names:
            full_val = getattr(target, name)
            trunc_val = getattr(truncated, name)
            assert full_val == pytest.approx(trunc_val, abs=1e-9), (
                f"{name}: full-frame {full_val} != truncated {trunc_val} — "
                "look-ahead leak"
            )


# ══════════════════════════════════════════════════════════════════════════════
# Output flattening
# ══════════════════════════════════════════════════════════════════════════════


class TestEventsToDataframe:
    def test_round_trips_to_dataframe(self, awl_events):
        df = events_to_dataframe(awl_events)
        assert len(df) == len(awl_events)
        # Every FireEvent attribute should be a column.
        for col in (
            "symbol", "phase", "trigger_idx", "trigger_date",
            "hold_bars", "exit_idx", "return_pct", "is_resolved",
            "pct_b_at_trigger", "sma20_slope_pct", "sma50_slope_pct",
            "bb_width_pctile", "vol_ratio_20", "atr_14_pct",
            "bars_since_sma20_above_sma50", "body_above_count_prior_5",
        ):
            assert col in df.columns, f"{col} missing from events df"

    def test_empty_events_yields_empty_df(self):
        df = events_to_dataframe([])
        assert len(df) == 0


# ══════════════════════════════════════════════════════════════════════════════
# Phase semantics
# ══════════════════════════════════════════════════════════════════════════════


class TestPhaseSemantics:
    def test_only_active_phases_emitted(self, awl_events):
        """No NONE / em-dash bars in the events list."""
        phases = {e.phase for e in awl_events}
        assert phases.issubset({"INIT", "RETEST", "CONT"})

    def test_consecutive_cont_bars_become_separate_events(
        self, awl_enriched, awl_ride_result, awl_events,
    ):
        """Per spec: each CONT bar is an independent fire event,
        evaluated separately."""
        cont_indices = sorted(e.trigger_idx for e in awl_events if e.phase == "CONT")
        # Walk the ride_result; every bar where phase == CONT must
        # appear in cont_indices (we may skip warm-up bars where
        # features have NaN, but for AWL with 500 bars that's a
        # very small region).
        phase_arr = awl_ride_result.phase.values
        cont_bars_in_result = {
            i for i in range(len(phase_arr)) if phase_arr[i] == "CONT"
        }
        # All extracted CONT triggers must be in the set of CONT
        # bars in the result.
        for idx in cont_indices:
            assert idx in cont_bars_in_result, (
                f"extracted CONT trigger at {idx} but "
                "ride_result.phase says otherwise"
            )
