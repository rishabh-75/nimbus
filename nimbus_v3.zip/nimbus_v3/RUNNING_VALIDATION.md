# Running Strategy Validation

## TL;DR

```bash
cd nimbus_v3
pip install -e .                              # one time
python scripts/run_strategy_validation.py     # gate ablation + sweeps
python scripts/run_oos_validation.py          # train/test split
python scripts/run_normal_regime_search.py    # search for normal-regime setups
python scripts/run_etf_validation.py          # ETF Momentum + alternatives
```

Each script auto-fetches whatever data it needs on first run. Subsequent
runs use the local parquet cache and finish in seconds. There is no
configuration to edit.

---

## What happens on first run

The first script invocation triggers a one-time download of ~170 NIFTY
200 symbols from yfinance into `data/cache/equity_price/`. This takes
**5-10 minutes** depending on your connection. You'll see a progress
line per symbol:

```
Equity panel: 170/170 symbols not yet cached — fetching now (one-time, ~340s)
  [  1/170] 360ONE        1505 bars
  [  2/170] ABB           1505 bars
  ...
```

Subsequent runs (whether of the same script or any other) skip
straight to the analysis:

```
Equity panel: 170 symbols ready (3.2s); 0 skipped
```

The same cache directory is shared across all four scripts, so you only
pay the fetch cost once.

---

## What each script tells you

### `run_strategy_validation.py`

In-sample ablation: for each of MR / Breakout / Ride, drops one gate
at a time and reports trade count + mean forward return delta. Followed
by parameter sweeps for each numeric threshold. Use this when you want
to understand which gates carry the alpha and how sensitive each
parameter is.

### `run_oos_validation.py`

Train (2020-03 → 2024-12) / test (2025-01 → 2026-04) split. Reports
lift-over-universe-baseline for each strategy on both periods.
Strategies whose lift survives OOS are validated; those whose lift
collapses are overfit.

### `run_normal_regime_search.py`

Tests 12 candidate strategies designed to fire when MR is silent
(normal VIX regime). Each candidate is evaluated on both train and
OOS test. Acceptance requires `test_n ≥ 200`, `test_lift ≥ +0.3pp`,
`|decay| ≤ 0.5pp`, and `test_t_stat ≥ 2.0`. Round 2 conditions every
candidate on a market-trend regime filter.

### `run_etf_validation.py`

Fetches ~20 liquid Indian ETFs and tests the current ETF Momentum
strategy plus four alternatives. Looser n threshold (50 vs 200) since
the ETF universe is smaller.

---

## Reading the output

Each acceptance table has these columns:

```
STRATEGY              tr n    tr lift   tr t   te n    te lift   te t   decay   ACCEPT?
```

- **`lift`** = strategy mean 10d return − period universe baseline mean,
  in percentage points. Positive = beat the average bar.
- **`t`** = paired-test t-statistic against the universe baseline.
  `t ≥ 2.0` ≈ p ≤ 0.05.
- **`decay`** = `te lift − tr lift`. Negative = overfit on train.
  Positive = strategy improved OOS (interesting!).
- **`ACCEPT?`** = passes all four criteria above.

A row that just barely fails one criterion is worth inspecting
manually — strict thresholds are designed to control false-positive
rate, not to perfectly classify every candidate.

---

## Customising the universe

Edit `nimbus_v3/research/equity_universe.py::DEFAULT_SYMBOLS` to add
or remove NSE symbols. After changing the list, delete the cache
directory and re-run any script:

```bash
rm -rf data/cache/equity_price
python scripts/run_strategy_validation.py     # re-fetches with new universe
```

For ETFs, edit `nimbus_v3/research/etf_universe.py` similarly.

---

## Using real VIX data instead of the synthetic proxy

The scripts default to a cross-sectional realised-vol proxy. To swap
in actual NSE VIX, edit any script's `main()` to replace these two lines:

```python
vix_df = build_vix_proxy(panel, smoothing=5)
streak = compute_vix_streaks(vix_df, high_threshold=...)
```

with:

```python
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.nse_client import NSEClient
from nimbus_v3.data.vix_loader import VIXLoader
from nimbus_v3.research.harness import streaks_from_real_vix
from pathlib import Path

vix_loader = VIXLoader(NSEClient(), ParquetCache(Path("data/cache/vix")))
vix_history = vix_loader.load_history(years=6)
streak = streaks_from_real_vix(vix_history, high_threshold=20.0)
```

Real India VIX is in the 12-25 range typically. A reasonable HIGH
threshold is 18-20.

---

## Common gotchas

- **Some symbols marked "insufficient data"** — newer NIFTY 200
  entries (LTM, ETERNAL, JIOFIN) sometimes lack 6-year history on
  yfinance. They get skipped automatically. ~170 of 174 symbols
  loading is normal.

- **yfinance rate limiting** — fewer-than-expected symbols loaded.
  Wait 5 min and re-run; cached symbols are skipped instantly,
  only failed ones retry.

- **NSE rate-limited** — only relevant if you swap in real VIX. The
  `NSEClient` enforces 5-min cooldown after failures. To verify:

  ```bash
  python -c "from nimbus_v3.data.nse_client import NSEClient; \
              c = NSEClient(); print(c.is_in_cooldown('https://www.nseindia.com'))"
  ```
