#!/usr/bin/env python3
"""seasonal_rrg_redundancy_probe.py — does next-month sector seasonality add
anything OVER the rotation state Nimbus already computes (RRG quadrant)?

WHERE THIS SITS
───────────────
seasonal_magnitude_probe established that next-month seasonal MAGNITUDE
predicts forward return out of sample (TEST Q4−Q1 = +1.66%, t = +3.01, beat
every random seed, broad across industries) — BUT it collapsed under sector-
neutralisation (−0.52%, t = −1.11). Reading: the effect is SECTOR
seasonality, not security-level. Sector seasonality is largely a rotation
statement — "this industry is entering a strong stretch" — and Nimbus ALREADY
models rotation directly (RRG quadrant, rotation rank). So the open question,
the one that decides whether this earns any UI:

    Does next-month seasonality predict forward INDUSTRY return AFTER
    controlling for the industry's CURRENT RRG quadrant?

If a strong-seasonal industry is usually ALREADY Leading/Improving, the
seasonal signal is redundant with rotation and there is nothing new to build.
If seasonality still sorts forward return WITHIN each quadrant, it carries
information rotation does not, and an industry-level "seasonal tail-wind" flag
is worth adding.

DESIGN
──────
Unit of observation = (industry, as-of date), sampled every SAMPLE_EVERY days.
For each:
  • quadrant  — the RRG quadrant AS-OF that date, computed with the app's own
    math (RS = composite/benchmark ×100, smoothed RS_SMOOTH; momentum = ROC
    over MOM_LOOKBACK; _quadrant(rs, mom)). Strictly trailing — no lookahead.
  • seasonal  — next calendar month's average composite return, from history
    strictly before the date (same as the magnitude probe).
  • fwd       — the industry composite's FWD-day forward return minus the
    equal-weight market over the same dates.

Then a DOUBLE SORT: within each quadrant, split seasonal at its median and
compare forward return (high-seasonal − low-seasonal). Pooled across quadrants
with date-clustering. The number that matters is the WITHIN-QUADRANT seasonal
spread:

    ≈ 0  → seasonality is subsumed by rotation. Build nothing; rotation
           already captures it.
    > 0 and clustered-t > 2 → seasonality adds over rotation. An industry-
           level seasonal-tail-wind flag is justified.

CONTROLS
  ctl:random-seasonal  shuffle the seasonal labels → within-quadrant spread ~0.
  ctl:shuffle-dates    clustering canary ~0.
Also prints the quadrant×seasonal cell means so you can SEE whether high
seasonal only ever coincides with Leading/Improving (redundant) or shows up
across quadrants (additive).

Run from the dir containing ./data:
    cd /Users/srishabh/Monarch/nimbus
    python nimbus_v3/seasonal_rrg_redundancy_probe.py
    python nimbus_v3/seasonal_rrg_redundancy_probe.py --selftest
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

FWD = 20
SAMPLE_EVERY = 5
MIN_SEASON_YEARS = 3
RRG_LOOKBACK = 50        # matches market_pulse_config.RRG_LOOKBACK
RS_SMOOTH = 5            # matches rrg.RS_SMOOTH
MOM_LOOKBACK = 10        # matches rrg.MOM_LOOKBACK


# ── RRG quadrant AS-OF a date (app math, strictly trailing) ─────────────────
def quadrant_asof(comp, bench, asof, *, lookback=RRG_LOOKBACK):
    """Return the RRG quadrant string for one industry as-of ``asof`` using
    only data at or before it. Mirrors compute_rrg's RS/momentum math."""
    import numpy as np
    import pandas as pd

    from nimbus_v3.compute.rrg import _quadrant

    c = comp.loc[comp.index <= asof]
    b = bench.loc[bench.index <= asof]
    joined = pd.concat([c.rename("ind"), b.rename("bench")],
                       axis=1, sort=False).dropna().tail(
                           lookback + MOM_LOOKBACK + RS_SMOOTH + 5)
    if len(joined) < MOM_LOOKBACK + 2:
        return None
    rs = joined["ind"] / joined["bench"]
    rs = rs / rs.mean() * 100.0
    rs = rs.rolling(RS_SMOOTH, min_periods=1).mean()
    mom = (rs / rs.shift(MOM_LOOKBACK) - 1.0) * 100.0 + 100.0
    mom = mom.dropna()
    if mom.empty:
        return None
    cur_rs = float(rs.loc[mom.index].iloc[-1])
    cur_mom = float(mom.iloc[-1])
    if cur_rs != cur_rs or cur_mom != cur_mom:
        return None
    return _quadrant(cur_rs, cur_mom).value


def next_month_seasonal_mean(comp, asof, *, min_years=MIN_SEASON_YEARS):
    import numpy as np
    import pandas as pd

    from nimbus_v3.compute.seasonality import _monthly_returns

    hist = comp.loc[comp.index < asof]
    if hist.empty:
        return float("nan")
    monthly = _monthly_returns(hist)
    if monthly.empty:
        return float("nan")
    target = (pd.Timestamp(asof).month % 12) + 1
    vals = monthly[monthly.index.month == target].to_numpy(dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < min_years:
        return float("nan")
    return float(np.mean(vals))


def composite_fwd_excess(comp, asof, market_cum, *, fwd=FWD):
    """FWD-day forward return of the composite from asof, minus market."""
    import numpy as np

    idx = comp.index
    pos = idx.searchsorted(asof)
    if pos >= len(idx) or idx[pos] != asof:
        # asof must be an actual bar
        return float("nan")
    if pos + fwd >= len(idx):
        return float("nan")
    c = comp.to_numpy(dtype=float)
    if c[pos] <= 0:
        return float("nan")
    r = c[pos + fwd] / c[pos] - 1.0
    d0, d1 = idx[pos], idx[pos + fwd]
    m0, m1 = market_cum.get(d0), market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan")
    rm = m1 / m0 - 1.0
    if not (np.isfinite(r) and np.isfinite(rm)):
        return float("nan")
    return r - rm


# ── inference ───────────────────────────────────────────────────────────────
def clustered(pairs):
    import numpy as np

    by = defaultdict(list)
    for d, x in pairs:
        if x == x:
            by[d].append(x)
    dm = [float(np.mean(v)) for v in by.values()]
    if len(dm) < 3:
        return float("nan"), float("nan"), len(dm), sum(len(v) for v in by.values())
    a = np.array(dm)
    m = float(a.mean())
    se = float(a.std(ddof=1)/np.sqrt(len(a)))
    return m, (m/se if se > 0 else float("nan")), len(a), sum(len(v) for v in by.values())


def welch(hi, lo):
    import numpy as np

    def dm(p):
        d = defaultdict(list)
        for dt, x in p:
            if x == x:
                d[dt].append(x)
        return np.array([np.mean(v) for v in d.values()])
    a, b = dm(hi), dm(lo)
    if len(a) < 3 or len(b) < 3:
        return float("nan")
    se = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
    return (a.mean()-b.mean())/se if se > 0 else float("nan")


QUADS = ["Leading", "Improving", "Weakening", "Lagging"]


def within_quadrant_spread(records, *, rng=None, shuffle_seasonal=False,
                           shuffle_dates=False, label=""):
    """records: [date, fwd, seasonal, quadrant, industry]. Within each
    quadrant split seasonal at the quadrant's own median; pool (high) and
    (low) across quadrants; report high−low.

    CLUSTERING — the correction that matters. Observations are NOT
    independent across sampled dates: every date inside one (industry, year,
    month) carries a near-identical seasonal value and heavily overlapping
    forward windows, so they are effectively ONE observation. The t-test is
    therefore taken across (industry, year, month) CLUSTERS, not across dates.
    Per-date clustering (the previous version) massively over-counted
    independent observations — the shuffle-dates canary running hot at t≈2.9
    was exactly this leak. Industry-month is the honest unit; the surviving
    t is smaller but real.

    (Residual caveat, stated honestly: adjacent industry-months still overlap
    slightly through the 20-day forward window, and different industries in
    the same month co-move with the market. So even this is a mild
    over-count — treat a borderline t with suspicion.)
    """
    import numpy as np

    def cluster_key(r):
        # (industry, year, month) — the independent unit.
        return (r[4], r[0].year, r[0].month)

    rec = [r[:] for r in records]
    if shuffle_seasonal and rng is not None:
        s = [r[2] for r in rec]
        rng.shuffle(s)
        for r, v in zip(rec, s):
            r[2] = v
    if shuffle_dates and rng is not None:
        ds = [r[0] for r in rec]
        rng.shuffle(ds)
        for r, d in zip(rec, ds):
            r[0] = d

    hi_all, lo_all = [], []
    print(f"\n─── {label} " + "─" * max(2, 46 - len(label)))
    print(f"  {'quadrant':10}  {'lo-seas':>9}  {'hi-seas':>9}  {'hi−lo':>8}  "
          f"{'n':>5}  {'clusters':>8}")
    for q in QUADS:
        qr = [r for r in rec if r[3] == q]
        if len(qr) < 8:
            print(f"  {q:10}  {'—':>9}  {'—':>9}  {'—':>8}  {len(qr):>5}")
            continue
        med = float(np.median([r[2] for r in qr]))
        lo = [(cluster_key(r), r[1]) for r in qr if r[2] <= med]
        hi = [(cluster_key(r), r[1]) for r in qr if r[2] > med]
        lm, _, _, _ = clustered(lo)
        hm, _, ncl_hi, _ = clustered(hi)
        hi_all.extend(hi)
        lo_all.extend(lo)
        d = (hm - lm) if (hm == hm and lm == lm) else float("nan")
        print(f"  {q:10}  {lm*100:+8.2f}%  {hm*100:+8.2f}%  {d*100:+7.2f}%"
              f"  {len(qr):>5}  {ncl_hi:>8}")
    spread_hi, _, nd, _ = clustered(hi_all)
    spread_lo, _, _, _ = clustered(lo_all)
    w = welch(hi_all, lo_all)
    diff = (spread_hi - spread_lo) if (spread_hi == spread_hi and spread_lo == spread_lo) else float("nan")
    print(f"  ── pooled within-quadrant  hi−lo = {diff*100:+.2f}%   "
          f"Welch-t = {w:+.2f}   industry-month clusters (hi) {nd}")
    return {"diff": diff, "welch": w}


def build_records(panel, sym_to_industry, comps, bench, market):
    seasonal_cache, quad_cache = {}, {}
    records = []
    for ind, comp in comps.items():
        idx = comp.index
        for pos in range(260, len(idx) - FWD - 1, SAMPLE_EVERY):
            asof = idx[pos]
            fx = composite_fwd_excess(comp, asof, market)
            if fx != fx:
                continue
            sk = (ind, asof.year, asof.month)
            if sk not in seasonal_cache:
                seasonal_cache[sk] = next_month_seasonal_mean(comp, asof)
            sm = seasonal_cache[sk]
            if sm != sm:
                continue
            q = quadrant_asof(comp, bench, asof)
            if q is None:
                continue
            records.append([asof, fx, sm, q, ind])
    return records


def build_market_cum(panel, *, min_count=20):
    import numpy as np

    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                sums[idx[i]] += c[i]/c[i-1] - 1.0
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    cum, acc = {}, 1.0
    for d in sorted(daily):
        acc *= 1.0 + daily[d]
        cum[d] = acc
    return cum


def build_composites(panel, sym_to_industry):
    from nimbus_v3.compute.industry_composite import build_industry_composite

    members = defaultdict(list)
    for sym, ind in sym_to_industry.items():
        if sym in panel:
            members[ind].append(sym)
    out = {}
    for ind, syms in members.items():
        comp, _ = build_industry_composite(
            syms, panel, min_members=3, min_bars=250, lookback=None)
        if comp is not None:
            out[ind] = comp
    return out


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np
    import pandas as pd

    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db
    from strategy_probe import load_panel

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — run from dir with ./data", file=sys.stderr)
        return 1
    print("composites + market...", file=sys.stderr)
    comps = build_composites(panel, sym_to_industry)
    market = build_market_cum(panel)
    bench = pd.concat(comps.values(), axis=1, sort=False).mean(axis=1)
    print("building records (this walks RRG per date — a minute)...",
          file=sys.stderr)
    records = build_records(panel, sym_to_industry, comps, bench, market)
    print(f"records: {len(records)}", file=sys.stderr)

    rng = np.random.default_rng(args.seed)
    real = within_quadrant_spread(records, label="REAL within-quadrant seasonal")
    within_quadrant_spread(records, rng=rng, shuffle_seasonal=True,
                           label="ctl:random-seasonal")
    within_quadrant_spread(records, rng=rng, shuffle_dates=True,
                           label="ctl:shuffle-dates (≈0)")

    print("\n" + "=" * 68)
    print("VERDICT")
    adds = real["diff"] > 0 and real["welch"] > 2
    if adds:
        print(f"  Within-quadrant seasonal spread = {real['diff']*100:+.2f}%, "
              f"t = {real['welch']:+.2f}.")
        print("  Seasonality sorts forward INDUSTRY return even after fixing")
        print("  the RRG quadrant → it carries information rotation does NOT.")
        print("  → Build the industry-level seasonal tail-wind flag (context")
        print("    in the rotation/confluence view, keyed to a lead-time")
        print("    window). NOT a per-name score — sector-neutral already")
        print("    said the name-level content isn't there.")
    else:
        print(f"  Within-quadrant seasonal spread = {real['diff']*100:+.2f}%, "
              f"t = {real['welch']:+.2f} — not significant.")
        print("  Once you know the RRG quadrant, next-month seasonality adds")
        print("  little to nothing. It is SUBSUMED by the rotation model you")
        print("  already have. → Build nothing. The honest end of the thread:")
        print("  the seasonal signal was real but is already expressed by RRG.")
    return 0


def _selftest(args):
    """Two worlds:
      A) ADDITIVE — forward return depends on seasonal INDEPENDENTLY of
         quadrant → within-quadrant spread must be detected.
      B) REDUNDANT — forward return depends only on quadrant, and seasonal is
         merely CORRELATED with quadrant → within-quadrant spread ~0.
    """
    import numpy as np
    import pandas as pd

    dates = pd.bdate_range("2016-01-01", periods=1200)

    def synth(additive):
        rng = np.random.default_rng(args.seed)
        recs = []
        inds = [f"Ind{k:02d}" for k in range(30)]
        for _ in range(20000):
            d = dates[rng.integers(len(dates))]
            ind = inds[rng.integers(len(inds))]
            q = QUADS[rng.integers(4)]
            q_effect = {"Leading": 0.01, "Improving": 0.004,
                        "Weakening": -0.004, "Lagging": -0.01}[q]
            # seasonal correlated with quadrant in BOTH worlds
            seas = q_effect + rng.normal(0, 0.01)
            if additive:
                # independent seasonal contribution on top of quadrant
                indep = rng.normal(0, 0.01)
                seas = seas + indep
                fwd = q_effect + 0.5 * indep + rng.normal(0, 0.04)
            else:
                # forward depends ONLY on quadrant; seasonal is a bystander
                fwd = q_effect + rng.normal(0, 0.04)
            recs.append([d, fwd, seas, q, ind])
        return recs

    print("\n########## A: ADDITIVE (seasonal adds within quadrant) ##########")
    A = within_quadrant_spread(synth(True), label="A within-quadrant")
    print("\n########## B: REDUNDANT (seasonal is just quadrant) ##########")
    B = within_quadrant_spread(synth(False), label="B within-quadrant")

    A_ok = A["diff"] > 0 and A["welch"] > 2
    B_ok = not (B["welch"] > 2)
    print("\n" + "=" * 68)
    print(f"A additive detected within quadrant:   {A_ok}")
    print(f"B redundant correctly reads as ~0:     {B_ok}")
    ok = A_ok and B_ok
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
