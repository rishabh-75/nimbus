#!/usr/bin/env python3
"""
scripts/run_etf_pairs_study.py — Kalman Filter ETF Pairs Trading Research

Tests whether NSE ETF pairs have tradeable spread mean-reversion.

Methodology:
  1. Identify natural pairs (sector vs broad, gold vs silver, etc.)
  2. Test cointegration (Engle-Granger) over rolling windows
  3. Apply Kalman filter for dynamic hedge ratio β(t)
  4. Compute z-score of Kalman spread
  5. Backtest: enter on z > 2 (or z < -2), exit on z → 0
  6. VIX regime segmentation (do pairs work better in specific regimes?)

Kalman state-space model:
  Observation:  y(t) = β(t) · x(t) + ε(t)      [ETF_A = β · ETF_B + noise]
  Transition:   β(t) = β(t-1) + η(t)             [β drifts as a random walk]

The Kalman filter estimates β(t) adaptively — no fixed lookback window.
This is strictly superior to OLS rolling regression for non-stationary pairs.

Usage:
    python3 scripts/run_etf_pairs_study.py
    python3 scripts/run_etf_pairs_study.py --years 5 --entry-z 2.0
"""
import argparse, logging, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()
import numpy as np, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("etf_pairs")


# ══════════════════════════════════════════════════════════════════════════════
# NATURAL PAIRS
# ══════════════════════════════════════════════════════════════════════════════

_PAIRS = [
    # Sector vs Broad
    ("BANKBEES", "NIFTYBEES", "Bank vs Nifty"),
    ("ITBEES", "NIFTYBEES", "IT vs Nifty"),
    ("PSUBNKBEES", "BANKBEES", "PSU Bank vs Bank"),
    ("PSUBNKBEES", "NIFTYBEES", "PSU Bank vs Nifty"),
    ("INFRABEES", "NIFTYBEES", "Infra vs Nifty"),
    ("PHARMABEES", "NIFTYBEES", "Pharma vs Nifty"),
    # Commodity
    ("GOLDBEES", "SILVERBEES", "Gold vs Silver"),
    # Size factor
    ("JUNIORBEES", "NIFTYBEES", "Junior vs Nifty"),
    ("MIDCAPIETF", "NIFTYBEES", "Midcap vs Nifty"),
    # Thematic
    ("MOM100", "NIFTYBEES", "Momentum vs Nifty"),
    ("CPSEETF", "NIFTYBEES", "CPSE vs Nifty"),
]


def fetch_daily(symbol, years=5):
    import yfinance as yf
    try:
        ticker = f"{symbol}.NS"
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", symbol, exc)
        return pd.DataFrame()


def fetch_vix(years=5):
    df = fetch_daily("^INDIAVIX".replace(".NS", ""), years)
    if not df.empty and "Close" in df.columns:
        return df["Close"].dropna()
    return None


# ══════════════════════════════════════════════════════════════════════════════
# COINTEGRATION TEST
# ══════════════════════════════════════════════════════════════════════════════

def test_cointegration(y, x, window=252):
    """
    Engle-Granger cointegration test over rolling windows.
    Returns: (is_cointegrated, avg_half_life, pct_windows_cointegrated)
    """
    from numpy.linalg import lstsq

    n = len(y)
    if n < window + 50:
        return False, 0, 0

    coint_count = 0
    half_lives = []
    total_windows = 0

    for start in range(0, n - window, window // 4):
        end = start + window
        if end > n:
            break
        total_windows += 1

        y_w = y[start:end]
        x_w = x[start:end]

        # OLS: y = β·x + α + ε
        X = np.column_stack([x_w, np.ones(len(x_w))])
        beta, _, _, _ = lstsq(X, y_w, rcond=None)
        spread = y_w - beta[0] * x_w - beta[1]

        # ADF-like test: Δspread = ρ·spread(-1) + ε
        ds = np.diff(spread)
        s_lag = spread[:-1]
        if len(s_lag) < 10 or np.std(s_lag) < 1e-10:
            continue

        X_adf = np.column_stack([s_lag, np.ones(len(s_lag))])
        rho_vec, _, _, _ = lstsq(X_adf, ds, rcond=None)
        rho = rho_vec[0]

        # Critical value for N=252: ~-2.87 at 5%
        # t-stat approximation
        resid = ds - X_adf @ rho_vec
        se = np.sqrt(np.sum(resid**2) / (len(resid) - 2)) / np.sqrt(np.sum(s_lag**2))
        if se > 0:
            t_stat = rho / se
            if t_stat < -2.87:
                coint_count += 1

        # Half-life of mean reversion
        if rho < 0:
            hl = -np.log(2) / rho
            if 1 < hl < 120:
                half_lives.append(hl)

    pct_coint = coint_count / max(total_windows, 1) * 100
    avg_hl = np.mean(half_lives) if half_lives else 0
    is_coint = pct_coint > 40  # cointegrated in >40% of windows

    return is_coint, avg_hl, pct_coint


# ══════════════════════════════════════════════════════════════════════════════
# KALMAN FILTER
# ══════════════════════════════════════════════════════════════════════════════

class KalmanHedgeRatio:
    """
    Kalman filter for dynamic hedge ratio estimation.

    State: β(t) = [hedge_ratio, intercept]
    Observation: y(t) = β(t)' · [x(t), 1] + ε(t)

    Parameters:
        delta: transition covariance scaling (higher = faster adaptation)
        ve: observation noise variance (higher = smoother estimates)
    """

    def __init__(self, delta=1e-4, ve=1e-3):
        self.delta = delta
        self.ve = ve
        # State: [hedge_ratio, intercept]
        self.beta = np.zeros(2)
        self.P = np.eye(2)  # state covariance
        self.R = np.eye(1) * ve  # observation noise

    def update(self, y, x):
        """Single Kalman step. Returns (hedge_ratio, spread, spread_var)."""
        F = np.array([[x, 1.0]])  # observation matrix

        # Predict
        Q = self.P * self.delta / (1 - self.delta)  # transition noise
        P_pred = self.P + Q

        # Update
        y_hat = F @ self.beta
        e = y - y_hat[0]  # innovation
        S = F @ P_pred @ F.T + self.R  # innovation variance
        K = P_pred @ F.T / S[0, 0]  # Kalman gain

        self.beta = self.beta + K.flatten() * e
        self.P = P_pred - K @ F @ P_pred

        return self.beta[0], e, S[0, 0]

    def run(self, y_series, x_series):
        """Run Kalman filter over full series. Returns DataFrame."""
        n = len(y_series)
        betas = np.zeros(n)
        spreads = np.zeros(n)
        spread_vars = np.zeros(n)

        for i in range(n):
            b, e, s = self.update(y_series[i], x_series[i])
            betas[i] = b
            spreads[i] = e
            spread_vars[i] = s

        # Z-score of spread
        spread_std = np.sqrt(spread_vars)
        spread_std[spread_std < 1e-10] = 1e-10
        z_scores = spreads / spread_std

        return pd.DataFrame({
            "beta": betas,
            "spread": spreads,
            "spread_var": spread_vars,
            "z_score": z_scores,
        })


# ══════════════════════════════════════════════════════════════════════════════
# PAIRS BACKTEST
# ══════════════════════════════════════════════════════════════════════════════

def backtest_pair(y_prices, x_prices, vix_series=None,
                  entry_z=2.0, exit_z=0.5, stop_z=4.0,
                  max_hold=30, delta=1e-4, ve=1e-3):
    """
    Backtest Kalman pairs strategy.

    Entry: |z| > entry_z (go short spread if z > entry_z, long if z < -entry_z)
    Exit: |z| < exit_z (spread reverted)
    Stop: |z| > stop_z (spread diverging — cut loss)
    Max hold: force exit after max_hold bars

    Returns list of trade dicts.
    """
    kf = KalmanHedgeRatio(delta=delta, ve=ve)
    result = kf.run(y_prices.values, x_prices.values)

    z = result["z_score"].values
    betas = result["beta"].values
    spreads = result["spread"].values
    dates = y_prices.index

    trades = []
    in_trade = False
    warmup = 60  # skip first 60 bars for Kalman convergence

    for i in range(warmup, len(z)):
        if np.isnan(z[i]) or np.isinf(z[i]):
            continue

        if in_trade:
            bars = i - entry_bar
            current_z = z[i]

            # Exit conditions
            exited = False
            exit_reason = ""

            if direction == "short" and current_z < exit_z:
                exited = True; exit_reason = "REVERT"
            elif direction == "long" and current_z > -exit_z:
                exited = True; exit_reason = "REVERT"
            elif abs(current_z) > stop_z:
                exited = True; exit_reason = "STOP"
            elif bars >= max_hold:
                exited = True; exit_reason = "MAX_HOLD"

            if exited:
                # PnL: spread change × direction
                spread_pnl = spreads[i] - spreads[entry_bar]
                if direction == "short":
                    spread_pnl = -spread_pnl

                # Convert to % of entry price (approximation)
                entry_price = y_prices.values[entry_bar]
                pnl_pct = (spread_pnl / entry_price) * 100 if entry_price > 0 else 0

                # VIX at entry
                entry_vix = None
                vix_regime = "UNKNOWN"
                if vix_series is not None:
                    vix_idx = vix_series.index.get_indexer([dates[entry_bar]], method="ffill")
                    if vix_idx[0] >= 0:
                        entry_vix = float(vix_series.iloc[vix_idx[0]])
                        if entry_vix > 22: vix_regime = "PANIC"
                        elif entry_vix >= 18: vix_regime = "ELEVATED"
                        elif entry_vix >= 13: vix_regime = "NORMAL"
                        else: vix_regime = "LOW"

                trades.append({
                    "entry_date": str(dates[entry_bar].date()),
                    "exit_date": str(dates[i].date()),
                    "direction": direction,
                    "entry_z": round(z[entry_bar], 2),
                    "exit_z": round(current_z, 2),
                    "entry_beta": round(betas[entry_bar], 4),
                    "pnl_pct": round(pnl_pct, 3),
                    "bars_held": bars,
                    "exit_reason": exit_reason,
                    "win": pnl_pct > 0,
                    "vix": round(entry_vix, 1) if entry_vix else None,
                    "vix_regime": vix_regime,
                })

                in_trade = False
                continue

        # Entry conditions
        if not in_trade:
            if z[i] > entry_z:
                in_trade = True
                direction = "short"  # spread too wide, bet on contraction
                entry_bar = i
            elif z[i] < -entry_z:
                in_trade = True
                direction = "long"  # spread too tight, bet on expansion
                entry_bar = i

    return trades


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def sharpe(returns):
    if len(returns) < 2: return 0
    m = np.mean(returns); s = np.std(returns, ddof=1)
    return (m / s * np.sqrt(252)) if s > 0 else 0


def summarize(trades, label=""):
    if not trades:
        print(f"    {label}: NO TRADES")
        return None
    df = pd.DataFrame(trades)
    n = len(df)
    wins = df["win"].sum()
    wr = wins / n * 100
    avg = df["pnl_pct"].mean()
    med = df["pnl_pct"].median()
    sh = sharpe(df["pnl_pct"].values)
    avg_bars = df["bars_held"].mean()
    pf = df.loc[df["pnl_pct"]>0, "pnl_pct"].sum() / max(abs(df.loc[df["pnl_pct"]<0, "pnl_pct"].sum()), 0.01)
    total = df["pnl_pct"].sum()
    print(f"    {label}: N={n:,}  Win={wr:.1f}%  Avg={avg:+.2f}%  Med={med:+.2f}%  "
          f"Sh={sh:.2f}  PF={pf:.2f}  Bars={avg_bars:.0f}  Total={total:+.1f}%")
    return {"label": label, "n": n, "wr": wr, "avg": avg, "sharpe": sh, "pf": pf, "total": total}


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--years", type=int, default=5)
    parser.add_argument("--entry-z", type=float, default=2.0)
    parser.add_argument("--sweep", action="store_true")
    args = parser.parse_args()

    print(f"\n{'='*72}")
    print(f"  ETF PAIRS TRADING STUDY — Kalman Filter")
    print(f"  {len(_PAIRS)} pairs, {args.years}yr, entry z={args.entry_z}")
    print(f"{'='*72}")

    # ── Fetch data ────────────────────────────────────────────
    print(f"\n[1/6] Fetching VIX...")
    vix_series = fetch_vix(args.years)

    print(f"\n[2/6] Fetching ETF prices...")
    all_symbols = set()
    for a, b, _ in _PAIRS:
        all_symbols.add(a); all_symbols.add(b)
    price_data = {}
    for sym in sorted(all_symbols):
        df = fetch_daily(sym, args.years)
        if not df.empty and len(df) > 100:
            price_data[sym] = df["Close"]
            logger.info("  %s: %d bars", sym, len(df))
        else:
            logger.warning("  %s: SKIPPED", sym)
    print(f"  Loaded: {len(price_data)} ETFs")

    # ══════════════════════════════════════════════════════════
    # SECTION 1: Cointegration screening
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [3/6] COINTEGRATION SCREENING")
    print(f"{'='*72}")

    viable_pairs = []
    for sym_y, sym_x, label in _PAIRS:
        if sym_y not in price_data or sym_x not in price_data:
            print(f"    {label}: SKIPPED (missing data)")
            continue
        y = price_data[sym_y]; x = price_data[sym_x]
        common = y.index.intersection(x.index)
        if len(common) < 200:
            print(f"    {label}: SKIPPED ({len(common)} common bars)")
            continue
        y_c = y.reindex(common).values; x_c = x.reindex(common).values

        is_coint, avg_hl, pct_coint = test_cointegration(y_c, x_c)
        status = "✓ COINT" if is_coint else "✗ NO"
        print(f"    {label:28s}  {status}  HL={avg_hl:.0f}d  Coint%={pct_coint:.0f}%")

        if is_coint:
            viable_pairs.append((sym_y, sym_x, label, avg_hl, pct_coint))

    print(f"\n  Viable pairs: {len(viable_pairs)} / {len(_PAIRS)}")

    if not viable_pairs:
        print("\n  No cointegrated pairs found. Kalman pairs NOT viable for NSE ETFs.")
        return

    # ══════════════════════════════════════════════════════════
    # SECTION 2: Kalman spread characteristics
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [4/6] KALMAN SPREAD CHARACTERISTICS")
    print(f"{'='*72}")

    for sym_y, sym_x, label, avg_hl, pct_coint in viable_pairs:
        y = price_data[sym_y]; x = price_data[sym_x]
        common = y.index.intersection(x.index)
        y_c = y.reindex(common); x_c = x.reindex(common)

        kf = KalmanHedgeRatio()
        result = kf.run(y_c.values, x_c.values)
        z = result["z_score"].values[60:]  # skip warmup

        print(f"\n    {label}:")
        print(f"      Beta range: {result['beta'].min():.3f} to {result['beta'].max():.3f}")
        print(f"      Z-score: mean={np.nanmean(z):.2f}  std={np.nanstd(z):.2f}")
        print(f"      % time |z|>2: {np.sum(np.abs(z) > 2) / len(z) * 100:.1f}%")
        print(f"      % time |z|>3: {np.sum(np.abs(z) > 3) / len(z) * 100:.1f}%")
        print(f"      Max |z|: {np.nanmax(np.abs(z)):.1f}")
        # Mean-reversion speed: autocorrelation of z
        if len(z) > 10:
            ac1 = np.corrcoef(z[1:], z[:-1])[0, 1]
            print(f"      Z autocorrelation(1): {ac1:.3f} (lower = faster reversion)")

    # ══════════════════════════════════════════════════════════
    # SECTION 3: Backtest — default params
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [5/6] BACKTEST — entry z={args.entry_z}")
    print(f"{'='*72}")

    all_trades = []
    pair_results = []
    for sym_y, sym_x, label, avg_hl, pct_coint in viable_pairs:
        y = price_data[sym_y]; x = price_data[sym_x]
        common = y.index.intersection(x.index)
        y_c = y.reindex(common); x_c = x.reindex(common)

        trades = backtest_pair(y_c, x_c, vix_series=vix_series,
                               entry_z=args.entry_z, max_hold=int(avg_hl * 2))
        r = summarize(trades, label)
        if r:
            pair_results.append(r)
        all_trades.extend(trades)

    print(f"\n    AGGREGATE:")
    summarize(all_trades, "ALL PAIRS")

    # VIX segmentation
    if all_trades:
        print(f"\n    VIX Regime:")
        for regime in ["PANIC", "ELEVATED", "NORMAL", "LOW"]:
            seg = [t for t in all_trades if t.get("vix_regime") == regime]
            summarize(seg, regime)

        # Direction split
        print(f"\n    Direction:")
        for d in ["short", "long"]:
            seg = [t for t in all_trades if t.get("direction") == d]
            summarize(seg, d.upper())

        # Exit reason
        print(f"\n    Exit Reason:")
        for er in ["REVERT", "STOP", "MAX_HOLD"]:
            seg = [t for t in all_trades if t.get("exit_reason") == er]
            if seg:
                summarize(seg, er)

    # ══════════════════════════════════════════════════════════
    # SECTION 4: Parameter sweep (optional)
    # ══════════════════════════════════════════════════════════
    if args.sweep and viable_pairs:
        print(f"\n{'='*72}")
        print(f"  [6/6] PARAMETER SWEEP")
        print(f"{'='*72}")

        sweep_results = []
        for entry_z in [1.5, 2.0, 2.5, 3.0]:
            for exit_z in [0.3, 0.5, 0.75]:
                for delta in [1e-5, 1e-4, 1e-3]:
                    for mh_mult in [1.5, 2.0, 3.0]:
                        trades_sw = []
                        for sym_y, sym_x, label, avg_hl, pct_coint in viable_pairs:
                            y = price_data[sym_y]; x = price_data[sym_x]
                            common = y.index.intersection(x.index)
                            y_c = y.reindex(common); x_c = x.reindex(common)
                            t = backtest_pair(y_c, x_c, vix_series=vix_series,
                                              entry_z=entry_z, exit_z=exit_z,
                                              max_hold=int(avg_hl * mh_mult), delta=delta)
                            trades_sw.extend(t)
                        if trades_sw:
                            n = len(trades_sw)
                            wr = sum(1 for t in trades_sw if t["win"]) / n * 100
                            avg = np.mean([t["pnl_pct"] for t in trades_sw])
                            sh = sharpe(np.array([t["pnl_pct"] for t in trades_sw]))
                            config = f"z={entry_z} exit={exit_z} δ={delta:.0e} mh={mh_mult:.1f}×HL"
                            sweep_results.append({
                                "config": config, "n": n, "wr": wr,
                                "avg": avg, "sharpe": sh,
                            })

        if sweep_results:
            sdf = pd.DataFrame(sweep_results).sort_values("sharpe", ascending=False)
            print(f"\n    Top 10 configs by Sharpe:")
            for _, row in sdf.head(10).iterrows():
                print(f"      Sh={row['sharpe']:.2f}  Win={row['wr']:.1f}%  Avg={row['avg']:+.2f}%  "
                      f"N={row['n']:4d}  {row['config']}")
    elif not args.sweep:
        print(f"\n  [6/6] PARAMETER SWEEP — skipped (use --sweep)")

    # ══════════════════════════════════════════════════════════
    # CONCLUSION
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  CONCLUSION")
    print(f"{'='*72}")

    if all_trades:
        n = len(all_trades)
        wr = sum(1 for t in all_trades if t["win"]) / n * 100
        sh = sharpe(np.array([t["pnl_pct"] for t in all_trades]))
        revert_pct = sum(1 for t in all_trades if t["exit_reason"] == "REVERT") / n * 100
        print(f"  Total trades: {n}")
        print(f"  Win rate: {wr:.1f}%")
        print(f"  Sharpe: {sh:.2f}")
        print(f"  Revert exits: {revert_pct:.1f}% (target: >60%)")
        print(f"  Cointegrated pairs: {len(viable_pairs)} / {len(_PAIRS)}")

        viable = sh > 0.5 and wr > 50 and revert_pct > 40
        print(f"\n  {'✓ VIABLE' if viable else '✗ NOT VIABLE'} — "
              f"{'Kalman pairs trading works on NSE ETFs' if viable else 'Insufficient edge for live trading'}")

        if not viable:
            print(f"\n  Possible reasons:")
            if sh <= 0.5:
                print(f"    - Sharpe {sh:.2f} too low (need > 0.5)")
            if wr <= 50:
                print(f"    - Win rate {wr:.1f}% too low (need > 50%)")
            if revert_pct <= 40:
                print(f"    - Only {revert_pct:.1f}% trades exit via reversion (spreads don't mean-revert enough)")
            print(f"    - NSE ETFs may have too much tracking error / low liquidity for pairs")
            print(f"    - Consider: wider entry z, longer hold, or different pair selection")
    else:
        print(f"  No trades generated. Pairs trading NOT viable for NSE ETFs.")

    print(f"\n{'='*72}\n")


if __name__ == "__main__":
    main()
