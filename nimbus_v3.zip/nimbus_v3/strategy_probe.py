#!/usr/bin/env python3
"""strategy_probe.py — the band ride as an actual TRADE, not a fixed horizon.

WHAT CHANGED, AND WHY IT MATTERS
--------------------------------
Every probe before this one measured forward return at a FIXED horizon
(5/10/20 bars) from sampled dates. That is the correct test for the Edge
tab's column, which literally claims "expected 20d excess return". It is the
WRONG test for a trading strategy, for one specific reason:

    A trend edge, if it exists, lives in the DURATION of the ride.
    A few long rides pay for many short ones. Cutting every trade at an
    arbitrary day 5 destroys exactly the structure you are trying to
    measure — it averages the 40-day winner and the 2-day scratch into
    the same cell and reports the mean as "no edge".

So this simulates the trade as stated:

    BUY   the first bar the body clears the upper band  (streak == 1)
    SELL  the first bar the body drops back below it
    HOLD  is however long that takes. That IS the horizon.

("body" = min(Open, Close) > upper band — the same definition as
compute/band_ride.body_above_streak and entry_probe, so the probe and the
app agree on what a ride is.)

THE TRAP THIS PROBE IS BUILT AROUND
-----------------------------------
"Hold while above the upper band" MECHANICALLY holds through up-moves and
exits on down-moves. On any series with positive drift that rule shows a
positive average return — with NO predictive content whatsoever. It is an
artefact of the exit rule, not an edge.

Reporting "the strategy made +X%" therefore proves nothing. The number that
means something is the strategy against controls that share the same
mechanical advantage:

    ctl:random-entry     RANDOM entry date, THEN THE IDENTICAL EXIT RULE.
                         <-- THE decisive control. It isolates the ENTRY
                         signal. If the real entries do not beat this, the
                         band-cross tells you nothing and the exit rule was
                         doing all the work.
    ctl:matched-hold     random entry, held for the SAME NUMBER OF BARS as a
                         real trade (duration distribution matched, exit rule
                         removed). Isolates what the EXIT rule contributes.
    ctl:buy-and-hold     the same capital in the equal-weight market over the
                         same dates.

STATISTICS: WHY PER-TRADE t-STATS ARE A LIE HERE
------------------------------------------------
Band crosses CLUSTER. On a strong tape hundreds of names cross on the same
day, and those trades then rise and fall together. They are nowhere near
independent observations. A naive t-stat over ~25,000 correlated trades will
look enormous and mean nothing — this is the single easiest way to fool
yourself in an event study.

So significance is computed on DATE-CLUSTERED means: average the excess
across all trades sharing an entry date, then t-test across DATES. The
per-trade count is shown for context but never used for inference. Both are
printed so the inflation is visible.

BENCHMARKING WITH VARIABLE HOLDING PERIODS
------------------------------------------
Trades have different lengths, so raw returns are not comparable across
trades and cannot be averaged naively. Every trade is therefore scored as
EXCESS over the equal-weight cross-section measured across THE SAME
CALENDAR DATES as that trade. A 40-day winner in a 40-day bull tape is not
credited for the tape.

Per-day excess is also reported: capital tied up for 40 days to make what
another trade made in 4 is not the same result, and the mean-per-trade
column hides that.

ALSO CONTROLLED
---------------
  * EXECUTION LAG. Signal at bar t's close is not tradeable at bar t. Entry
    and exit both fill at the NEXT bar's open by default (--exec next-open).
    --exec same-close is available to show how much of any edge is an
    artefact of filling at the signal bar itself.
  * COSTS. --cost-bps round-trip (brokerage + STT + impact). A rule that
    trades often can be gross-positive and net-negative; that must be
    visible, not assumed away.
  * RIGHT-CENSORING. Trades still open at the end of the data are marked to
    the last bar and counted, not silently dropped (dropping them biases
    against long winners).
  * TAIL STRUCTURE. Mean, median, win rate, payoff, best/worst decile
    contribution, and the holding-period distribution. A trend edge is
    tail-driven; a mean alone cannot show it, and a median alone will hide
    it.

USAGE
    python strategy_probe.py
    python strategy_probe.py --cost-bps 30 --exec next-open
    python strategy_probe.py --exit below-mid       # sensitivity, not search
    python strategy_probe.py --selftest             # verify on synthetic data
"""
from __future__ import annotations

import argparse
import statistics
import sys

VOL_WINDOW = 20
UPPER = "bb_20_1s_upper"
MID = "bb_20_1s_mid"
LOWER = "bb_20_1s_lower"


# --------------------------------------------------------------------------
# stats
# --------------------------------------------------------------------------
def _t_of(xs):
    if len(xs) < 2:
        return 0.0
    m = statistics.mean(xs)
    se = statistics.stdev(xs) / (len(xs) ** 0.5)
    return m / se if se > 0 else 0.0


def _clustered(trades, key="excess"):
    """Mean and t-stat clustered BY ENTRY DATE.

    Trades sharing an entry date are driven by the same market move and are
    not independent. Collapsing to one observation per date is the minimum
    honest correction; the per-trade t is reported alongside purely to show
    how badly the naive version overstates.
    """
    by_date = {}
    for t in trades:
        by_date.setdefault(t["entry_date"], []).append(t[key])
    date_means = [statistics.mean(v) for v in by_date.values()]
    per_trade = [t[key] for t in trades]
    return {
        "n_trades": len(trades),
        "n_dates": len(date_means),
        "mean": statistics.mean(per_trade) if per_trade else float("nan"),
        "median": statistics.median(per_trade) if per_trade else float("nan"),
        "t_clustered": _t_of(date_means),
        "t_naive": _t_of(per_trade),
    }


# --------------------------------------------------------------------------
# panel
# --------------------------------------------------------------------------
def load_panel(engine, ind_db):
    from nimbus_v3.data.cache import ParquetCache
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.paths import cache_dir

    raw = ParquetCache(base_dir=cache_dir("equity_price"))
    ec = EnrichedPanelCache(raw_cache=raw,
                            schema_hash=engine.enrichment_schema_hash())
    panel = {}
    for sym in sorted(ind_db):
        df = ec.get_if_fresh(sym)
        if df is None:
            df = ec.get_stale(sym)
        if df is None:
            try:
                r = raw.get(sym)
            except Exception:            # noqa: BLE001
                r = None
            if r is not None and not r.empty:
                try:
                    df = engine.enrich(r, sym)
                except Exception:        # noqa: BLE001
                    df = None
        if df is not None and not df.empty and UPPER in df.columns:
            panel[sym] = df
    return panel


# --------------------------------------------------------------------------
# the market benchmark: equal-weight cross-section, by DATE
# --------------------------------------------------------------------------
def build_market(panel):
    """Equal-weight daily return index across every symbol, keyed by date.

    Built from daily cross-sectional MEAN returns, so a symbol contributes
    only on dates it actually traded. Used to de-market each trade over its
    OWN holding dates.
    """
    import numpy as np

    sums, counts = {}, {}
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        r = np.full(len(c), np.nan)
        r[1:] = c[1:] / c[:-1] - 1.0
        for i in range(1, len(c)):
            v = r[i]
            if np.isfinite(v):
                d = idx[i]
                sums[d] = sums.get(d, 0.0) + v
                counts[d] = counts.get(d, 0) + 1
    daily = {d: sums[d] / counts[d] for d in sums if counts[d] >= 20}
    # cumulative index over sorted dates
    dates = sorted(daily)
    cum, lvl = {}, 1.0
    for d in dates:
        lvl *= (1.0 + daily[d])
        cum[d] = lvl
    return cum


def _mkt_return(mkt_cum, d0, d1):
    """Equal-weight market return between two dates, in %."""
    a, b = mkt_cum.get(d0), mkt_cum.get(d1)
    if a is None or b is None or a <= 0:
        return float("nan")
    return (b / a - 1.0) * 100.0


# --------------------------------------------------------------------------
# trade simulation
# --------------------------------------------------------------------------
def _exit_condition(exit_rule, o, c, up, mid, t):
    """True when the position should be CLOSED at bar t."""
    import numpy as np

    if exit_rule == "below-upper":       # the stated rule
        return not (min(o[t], c[t]) > up[t])
    if exit_rule == "close-below-upper":  # looser: close alone
        return not (c[t] > up[t])
    if exit_rule == "below-mid":          # sensitivity: ride to the mid band
        return not (np.isfinite(mid[t]) and c[t] > mid[t])
    raise ValueError(exit_rule)


def simulate(panel, mkt_cum, exit_rule, exec_mode, cost_bps,
             rng=None, random_entry=False, hold_bars=None):
    """Run the trade rule over every symbol.

    random_entry : ignore the signal; start trades on random bars instead.
                   Same exit rule. THIS IS THE DECISIVE CONTROL.
    hold_bars    : if given, ignore the exit rule and hold exactly N bars
                   (N drawn from the real duration distribution). Isolates
                   what the exit rule contributes.

    No lookahead: the entry signal is read from bar t; the fill is bar t+1's
    open under the default exec mode. The exit is detected at bar u and
    filled at u+1's open.
    """
    import numpy as np

    trades = []
    for sym, df in panel.items():
        n = len(df)
        if n < VOL_WINDOW + 60:
            continue
        o = df["Open"].to_numpy(dtype=float)
        c = df["Close"].to_numpy(dtype=float)
        up = df[UPPER].to_numpy(dtype=float)
        mid = (df[MID].to_numpy(dtype=float) if MID in df.columns
               else np.full(n, np.nan))
        idx = df.index
        body = (np.minimum(o, c) > up)

        start = VOL_WINDOW + 25
        t = start
        while t < n - 2:
            if random_entry:
                # Random entry, but only where a real trade COULD have been
                # opened (same eligible date range) so the comparison is
                # like-for-like rather than sampling a different era.
                if rng.random() > 0.02:      # ~ match real entry frequency
                    t += 1
                    continue
                is_entry = True
            else:
                # streak == 1: body above band today, NOT yesterday.
                is_entry = body[t] and not body[t - 1]

            if not is_entry:
                t += 1
                continue

            # ---- entry fill -------------------------------------------
            if exec_mode == "next-open":
                ei = t + 1
                if ei >= n:
                    break
                entry_px = o[ei]
            else:                              # same-close
                ei = t
                entry_px = c[t]
            if not np.isfinite(entry_px) or entry_px <= 0:
                t += 1
                continue

            # ---- walk forward to the exit -----------------------------
            censored = False
            if hold_bars is not None:
                xi = min(ei + int(hold_bars), n - 1)
                if xi >= n - 1:
                    censored = True
            else:
                u = ei
                while u < n and not _exit_condition(exit_rule, o, c, up,
                                                    mid, u):
                    u += 1
                if u >= n:                     # still open at data end
                    xi = n - 1
                    censored = True
                else:
                    xi = (u + 1 if exec_mode == "next-open" and u + 1 < n
                          else u)

            exit_px = (o[xi] if exec_mode == "next-open" and not censored
                       else c[xi])
            if not np.isfinite(exit_px) or exit_px <= 0:
                t = xi + 1
                continue

            held = max(1, xi - ei)
            raw = (exit_px / entry_px - 1.0) * 100.0
            raw_net = raw - cost_bps / 100.0        # round-trip, in %

            mret = _mkt_return(mkt_cum, idx[ei], idx[xi])
            if not np.isfinite(mret):
                t = xi + 1
                continue

            # MAE / MFE over the holding window — how much heat was taken
            seg = c[ei:xi + 1]
            mfe = (float(np.nanmax(seg)) / entry_px - 1.0) * 100.0
            mae = (float(np.nanmin(seg)) / entry_px - 1.0) * 100.0

            trades.append({
                "sym": sym,
                "entry_date": idx[ei],
                "exit_date": idx[xi],
                "held": held,
                "raw": raw_net,
                "mkt": mret,
                "excess": raw_net - mret,
                "excess_per_day": (raw_net - mret) / held,
                "mfe": mfe,
                "mae": mae,
                "censored": censored,
            })
            # no pyramiding: resume scanning after the exit
            t = xi + 1
    return trades


# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------
def describe(trades, label, base=None):
    if not trades:
        print(f"  {label:<22} (no trades)")
        return None
    st = _clustered(trades)
    ex = [t["excess"] for t in trades]
    wins = [e for e in ex if e > 0]
    losses = [e for e in ex if e <= 0]
    wr = 100.0 * len(wins) / len(ex)
    payoff = ((statistics.mean(wins) / abs(statistics.mean(losses)))
              if wins and losses else float("nan"))
    held = [t["held"] for t in trades]
    epd = statistics.mean(t["excess_per_day"] for t in trades)

    star = " *" if abs(st["t_clustered"]) > 2 else ""
    vs = ""
    if base is not None:
        vs = f"{st['mean'] - base:+.2f}%"
    print(f"  {label:<22}{st['n_trades']:>8}{st['mean']:>+9.2f}%"
          f"{st['median']:>+9.2f}%{wr:>7.0f}%{payoff:>8.2f}"
          f"{statistics.median(held):>7.0f}{epd:>+9.3f}%"
          f"{st['t_clustered']:>7.1f}{star:<2}{vs:>9}")
    return st


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--exit", default="below-upper",
                    choices=["below-upper", "close-below-upper", "below-mid"],
                    help="exit rule. Default is the stated one: sell the "
                         "moment the body dips below the upper band.")
    ap.add_argument("--exec", dest="exec_mode", default="next-open",
                    choices=["next-open", "same-close"],
                    help="fill timing. next-open is honest; same-close "
                         "assumes you trade the signal bar itself.")
    ap.add_argument("--cost-bps", type=float, default=20.0,
                    help="round-trip cost in bps (brokerage+STT+impact)")
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--csv", default=None)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.selftest:
        return _selftest(args)

    import numpy as np
    import pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    if not panel:
        print("panel empty — run the app once first.", file=sys.stderr)
        return 1
    lens = sorted(len(df) for df in panel.values())
    print(f"  {len(panel)} symbols   bars: min={lens[0]} "
          f"median={lens[len(lens) // 2]} max={lens[-1]}", file=sys.stderr)
    print("building equal-weight market...", file=sys.stderr)
    mkt = build_market(panel)
    print(f"  {len(mkt)} market dates", file=sys.stderr)

    rng = np.random.default_rng(args.seed)

    print("simulating band rides...", file=sys.stderr)
    real = simulate(panel, mkt, args.exit, args.exec_mode, args.cost_bps)
    if not real:
        print("no trades generated.", file=sys.stderr)
        return 1

    # duration distribution -> matched-hold control
    holds = [t["held"] for t in real]
    print("simulating controls...", file=sys.stderr)
    ctl_rand = simulate(panel, mkt, args.exit, args.exec_mode, args.cost_bps,
                        rng=np.random.default_rng(args.seed + 1),
                        random_entry=True)
    med_hold = int(statistics.median(holds))
    ctl_hold = simulate(panel, mkt, args.exit, args.exec_mode, args.cost_bps,
                        rng=np.random.default_rng(args.seed + 2),
                        random_entry=True, hold_bars=med_hold)

    print()
    print("=" * 104)
    print("  BAND RIDE AS A TRADE — buy on streak==1, sell when the body "
          "dips below the upper band")
    print(f"  exit={args.exit}  exec={args.exec_mode}  "
          f"cost={args.cost_bps:.0f}bps round-trip")
    print("=" * 104)
    print("  Excess = trade return MINUS the equal-weight market over THE "
          "SAME dates.")
    print("  t is DATE-CLUSTERED (trades on one day are one observation). "
          "Naive per-trade t shown below.")
    print()
    print(f"  {'arm':<22}{'trades':>8}{'mean ex':>10}{'median':>10}"
          f"{'win%':>7}{'payoff':>8}{'hold':>7}{'ex/day':>10}{'t':>7}"
          f"{'':<2}{'vs sig':>9}")
    print("  " + "-" * 100)
    st_real = describe(real, "SIGNAL (streak==1)")
    base = st_real["mean"] if st_real else 0.0
    describe(ctl_rand, "ctl:random-entry", base)
    describe(ctl_hold, f"ctl:matched-hold({med_hold}d)", base)

    # buy-and-hold reference over the same span
    print()
    print("  ctl:buy-and-hold — by construction excess = 0.00% "
          "(it IS the benchmark)")

    # ---- the decisive comparison -------------------------------------
    print()
    print("  " + "-" * 100)
    print("  THE COMPARISON THAT DECIDES IT")
    if st_real and ctl_rand:
        st_c = _clustered(ctl_rand)
        diff = st_real["mean"] - st_c["mean"]
        # difference-in-means across the shared date clusters
        print(f"    SIGNAL          {st_real['mean']:+.2f}% "
              f"(t {st_real['t_clustered']:+.1f} clustered, "
              f"{st_real['t_naive']:+.1f} naive)")
        print(f"    random entry    {st_c['mean']:+.2f}% "
              f"(t {st_c['t_clustered']:+.1f} clustered)")
        print(f"    DIFFERENCE      {diff:+.2f}%")
        print()
        if abs(st_real["t_clustered"]) <= 2:
            print("    -> the signal arm itself does not clear |t|>2 on "
                  "date-clustered errors.")
        if abs(diff) < 0.10:
            print("    -> the band-cross entry adds ~NOTHING over a RANDOM "
                  "entry run through the")
            print("       same exit rule. Any headline return is the EXIT "
                  "RULE's mechanical bias")
            print("       (hold up-moves, cut down-moves), not a predictive "
                  "entry signal.")
        else:
            print("    -> the entry signal separates from random. This is "
                  "the result that would")
            print("       justify building on it — check it survives costs "
                  "and next-open fills.")

    # ---- naive-vs-clustered inflation --------------------------------
    if st_real:
        print()
        print(f"  CLUSTERING CHECK: naive t {st_real['t_naive']:+.1f} vs "
              f"clustered t {st_real['t_clustered']:+.1f} "
              f"({st_real['n_trades']} trades on "
              f"{st_real['n_dates']} dates)")
        print("    Band crosses cluster on strong days; the naive t treats "
              "correlated trades as")
        print("    independent and overstates significance. Only the "
              "clustered t is evidence.")

    # ---- tail structure ----------------------------------------------
    ex = sorted(t["excess"] for t in real)
    n = len(ex)
    d = max(1, n // 10)
    top_sum = sum(ex[-d:])
    tot = sum(ex)
    print()
    print("  TAIL STRUCTURE (is this a few big rides carrying it?)")
    # NB: a share-of-total is only meaningful when the total is positive.
    # With a negative total the ratio is misleading (a big positive decile
    # over a negative total prints a nonsense negative "share"), so say it
    # plainly instead.
    share = (f"  ({100.0 * top_sum / tot:.0f}% of it)" if tot > 0
             else "  — total is NEGATIVE: the tail is carrying a losing book")
    print(f"    best decile contributes {top_sum:+.0f} of {tot:+.0f} total "
          f"excess points{share}")
    print(f"    worst decile          {sum(ex[:d]):+.0f}")
    print(f"    holding period: median {statistics.median(holds):.0f}d  "
          f"p90 {sorted(holds)[int(0.9 * len(holds))]:.0f}d  "
          f"max {max(holds)}d")
    cens = sum(1 for t in real if t["censored"])
    print(f"    still-open at data end: {cens} trades (marked to last bar, "
          f"not dropped)")
    mae = statistics.median(t["mae"] for t in real)
    mfe = statistics.median(t["mfe"] for t in real)
    print(f"    median MAE {mae:+.2f}%   median MFE {mfe:+.2f}%  "
          f"(heat taken vs best unrealised)")

    print()
    print("  HOW TO READ THIS")
    print("  * The SIGNAL row's absolute return is NOT the finding. 'Hold "
          "while above the band'")
    print("    mechanically captures up-moves — it is positive on drift "
          "alone.")
    print("  * ctl:random-entry is the finding. Same exit rule, no entry "
          "signal. If SIGNAL does")
    print("    not beat it, the cross tells you nothing.")
    print("  * ctl:matched-hold removes the exit rule. If it matches SIGNAL, "
          "the exit rule is")
    print("    contributing nothing either and this is just market exposure.")
    print("  * Use the CLUSTERED t. Always.")
    print("  * Re-run with --cost-bps 40 and --exec next-open before "
          "believing anything.")
    print()

    if args.csv:
        pd.DataFrame(real).to_csv(args.csv, index=False)
        print(f"wrote {args.csv}", file=sys.stderr)
    return 0


# --------------------------------------------------------------------------
# self-test: the harness must show ZERO edge on a random walk
# --------------------------------------------------------------------------
def _selftest(args):
    """The canary. On a driftless RANDOM WALK the band rule must produce
    ~0 excess and the signal arm must not beat the random-entry control.

    If it does show an edge here, the instrument is broken — most likely
    lookahead in the fill or a benchmark misalignment. This is the same
    canary discipline as ctl:random in the other probes.
    """
    import numpy as np
    import pandas as pd

    rng = np.random.default_rng(5)
    dates = pd.bdate_range("2020-01-01", periods=900)
    panel = {}
    for i in range(60):
        r = rng.normal(0, 0.015, len(dates))       # driftless
        close = 500 * np.exp(np.cumsum(r))
        openp = close * (1 + rng.normal(0, 0.002, len(dates)))
        s = pd.Series(close)
        mid = s.rolling(20).mean()
        sd = s.rolling(20).std()
        df = pd.DataFrame({
            "Open": openp, "Close": close,
            "Volume": rng.integers(1e5, 5e5, len(dates)).astype(float),
            MID: mid.to_numpy(),
            UPPER: (mid + sd).to_numpy(),
            LOWER: (mid - sd).to_numpy(),
        }, index=dates).dropna()
        panel[f"S{i}"] = df

    mkt = build_market(panel)
    real = simulate(panel, mkt, "below-upper", args.exec_mode, 0.0)
    ctl = simulate(panel, mkt, "below-upper", args.exec_mode, 0.0,
                   rng=np.random.default_rng(9), random_entry=True)
    if not real or not ctl:
        print("selftest: no trades generated"); return 1
    a, b = _clustered(real), _clustered(ctl)
    print("strategy_probe self-test — driftless random walk, 60 symbols")
    print(f"  SIGNAL        n={a['n_trades']:<6} mean excess "
          f"{a['mean']:+.3f}%  clustered t {a['t_clustered']:+.2f}")
    print(f"  random-entry  n={b['n_trades']:<6} mean excess "
          f"{b['mean']:+.3f}%  clustered t {b['t_clustered']:+.2f}")
    print(f"  difference    {a['mean'] - b['mean']:+.3f}%")
    med = statistics.median(t["held"] for t in real)
    print(f"  median hold   {med:.0f} bars")
    ok = abs(a["t_clustered"]) < 3.5 and abs(a["mean"] - b["mean"]) < 0.75
    print()
    if ok:
        print("  PASS: no manufactured edge on a random walk — the trade")
        print("  accounting, the same-dates benchmark and the fills are not")
        print("  leaking. A real result must beat THIS baseline, not zero.")
        return 0
    print("  FAIL: harness shows an edge where none can exist. Suspect")
    print("  lookahead in the fill or benchmark misalignment.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
