"""
modules/signal_tracker.py
──────────────────────────
Forward validation system for NIMBUS dual-mode signals.

Auto-logs every dual-mode signal when entry_triggered=True.
Resolves outcomes after 10 trading days by fetching the actual price.
Monitors live performance vs backtest expectations and flags regime drift.

DB: data/signal_tracker.db
Tables:
  signals     — every logged signal with full state snapshot
  outcomes    — resolved P&L after hold period

Workflow:
  1. DataManager calls log_signal() on every entry trigger  (auto)
  2. run_resolve.py fetches close prices for mature signals  (daily cron / manual)
  3. run_resolve.py --export produces a report for analysis  (weekly)
  4. Drift alerts surface in the dashboard status bar        (auto)
"""

from __future__ import annotations

import datetime
import logging
import os
import sqlite3


logger = logging.getLogger(__name__)

# Persistent DB location — outside project folder so it survives reinstalls.
# Falls back to project-local path if NIMBUS_HOME isn't set or ~/.nimbus
# can't be created (e.g. read-only home).
def _resolve_db_path(filename: str) -> str:
    """
    Resolution order:
      1. $NIMBUS_HOME/<filename>          (explicit override)
      2. ~/.nimbus/<filename>             (default persistent location)
      3. <project>/data/<filename>        (legacy fallback)

    Migrates legacy DB to ~/.nimbus on first run if found.
    """
    # 1. Explicit env var
    nimbus_home = os.environ.get("NIMBUS_HOME")
    if nimbus_home:
        try:
            os.makedirs(nimbus_home, exist_ok=True)
            return os.path.join(nimbus_home, filename)
        except Exception:
            pass

    # 2. ~/.nimbus default
    user_dir = os.path.expanduser("~/.nimbus")
    try:
        os.makedirs(user_dir, exist_ok=True)
        persistent = os.path.join(user_dir, filename)
        # Auto-migrate legacy DB on first run
        legacy = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "data", filename
        )
        legacy = os.path.abspath(legacy)
        if not os.path.exists(persistent) and os.path.exists(legacy):
            try:
                import shutil
                shutil.copy2(legacy, persistent)
                logger.info("Migrated %s → %s", legacy, persistent)
            except Exception as exc:
                logger.warning("DB migration failed: %s", exc)
        return persistent
    except Exception:
        pass

    # 3. Legacy project-local fallback
    return os.path.abspath(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", filename
    ))


_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
_DB_PATH = _resolve_db_path("signal_tracker.db")

# ── Backtest expectations (live MR params, walkforward + recent validated) ─
# Used for drift detection: if rolling 20-signal performance drops below
# the lower bound, something has changed and the system should alert.
#
# IMPORTANT: There are two valid baselines and they differ meaningfully.
# The CURRENT EXPECTED below uses the recent ex-March measurement as the
# realistic live forecast — NOT the walkforward best-case — because drift
# detection compares against "what we expect to see now," not "what we saw
# in the most favorable historical regime."
#
# ── Realistic live baseline (current EXPECTED) ─────────────────────────────
#   Source: scripts/run_recent_period_test.py --end 2026-02-28
#   Window: Nov 2024 → Feb 2026 (16 months, excluding the March 2026
#           geopolitical anomaly which was an identifiable event-driven
#           outlier — the Mar 2026 month had Sh=-5.62 on FII selling
#           pressure that broke MR-style strategies industry-wide).
#   Universe: 174 NIFTY 200 symbols
#   N: 206 trades (~13/month with strict filter)
#   PRIMARY: Sharpe=0.43  Win=51.0%  Avg=+0.471%  PF=1.25
#
#   This is what production should expect to see in normal market regimes.
#   It's the conservative-but-honest forecast.
#
# ── Best-case historical reference (walkforward, NOT used as EXPECTED) ─────
#   Source: scripts/run_walkforward.py --lock-live-params --years 6
#   Window: Oct 2021 → May 2024 (5-fold OOS, 31 months)
#   N: 329 trades
#   PRIMARY: Sharpe=1.13  Win=53.6%  Avg=+1.66%  PF=1.84  (5/5 positive folds)
#
#   This is what the strategy CAN produce in favorable regimes (cyclical
#   pullbacks that revert cleanly). It's not what to expect day-to-day.
#   Kept here for reference but NOT used as the drift baseline because
#   it would generate constant false-alarms — live will rarely match it.
#
# ── March 2026 anomaly (excluded from baseline, for context only) ──────────
#   Source: scripts/run_recent_period_test.py (full window including March)
#   Single month: N=20  Win=15%  Avg=-4.36%  Sh=-5.62
#   Driver: geopolitical tensions, sustained net FII selling, sector-wide
#           breakdown of mean-reversion entries. Not a structural strategy
#           failure — an identifiable macro event that the regime detector
#           is designed to catch and pause around.
#
#   When the regime detector flips MR to dormant (Q < 0 over the rolling
#   90-day window), do not take new MR signals until it returns to working.
#   See modules/strategy_regime.py for the detector logic.
#
# ── Drift floors ───────────────────────────────────────────────────────────
#   min_win_rate = 45 — well below the recent baseline (51%) and below
#   the worst non-anomaly month (39.3% in Feb 2025 with 28 trades).
#   Below 45% sustained means something fundamentally broken, not noise.
#
#   min_avg_return = 0.0 — alert when rolling average pnl goes negative.
#   This will fire during normal losing streaks, which is intentional.
#   The recent baseline is +0.47% so there's headroom before it fires,
#   but if the rolling window goes red the user should know.
EXPECTED = {
    "PRIMARY": {
        # Realistic live forecast from recent ex-March measurement
        "win_rate": 51.0,
        "avg_return": 0.471,
        "sharpe": 0.43,
        "min_win_rate": 45.0,
        "min_avg_return": 0.0,
    },
    "SECONDARY": {
        # DEPRECATED — see ENABLE_SECONDARY_TIER in dual_mode.py.
        # Historical values from 2026-04-08 lock-live walkforward.
        "win_rate": 53.7,
        "avg_return": 0.418,
        "sharpe": 0.34,
        "min_win_rate": 45.0,
        "min_avg_return": 0.0,
    },
}

from modules.dual_mode import MAX_HOLD as HOLD_DAYS  # keep alias for compat

_CREATE_SIGNALS = """
CREATE TABLE IF NOT EXISTS signals (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol          TEXT NOT NULL,
    signal_date     TEXT NOT NULL,
    signal_ts       TEXT NOT NULL,
    mode            TEXT NOT NULL,
    segment         TEXT NOT NULL,
    entry_price     REAL NOT NULL,
    sma_20          REAL,
    pct_from_sma    REAL,
    wr_value        REAL,
    adx_14          REAL,
    base_score      INTEGER,
    options_overlay INTEGER DEFAULT 0,
    filing_overlay  INTEGER DEFAULT 0,
    is_trap         INTEGER DEFAULT 0,
    dual_score      INTEGER,
    dual_label      TEXT,
    dual_sizing     TEXT,
    entry_reason    TEXT,
    input_interval  TEXT,
    daily_bars      INTEGER,
    -- Outcome fields (filled by resolver)
    resolved        INTEGER DEFAULT 0,
    resolve_date    TEXT,
    exit_price      REAL,
    pnl_pct         REAL,
    peak_price      REAL,
    max_drawdown    REAL,
    exit_reason     TEXT,
    -- Unique key includes mode so MR and Ride can both log the same
    -- symbol on the same day without one silently dropping the other.
    UNIQUE(symbol, signal_date, mode)
)
"""

_CREATE_INDEX = """
CREATE INDEX IF NOT EXISTS idx_signals_unresolved
ON signals(resolved, signal_date)
"""


def _migrate_unique_constraint_v2(conn: sqlite3.Connection) -> None:
    """
    One-time migration: rebuild the signals table with the corrected unique
    constraint UNIQUE(symbol, signal_date, mode). Earlier schema used
    UNIQUE(symbol, signal_date) which silently dropped Ride entries when
    MR fired on the same symbol/day (and vice versa).

    Detection: query sqlite_master for the CREATE TABLE statement and
    check whether 'mode' is in the UNIQUE clause. If not, migrate.
    Migration: rename old table → create new → copy → drop old.
    Idempotent: subsequent runs detect the already-migrated schema and skip.
    """
    try:
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='signals'"
        ).fetchone()
        if row is None:
            return  # Fresh DB, _CREATE_SIGNALS will be applied

        existing_sql = (row[0] or "").upper()
        if "UNIQUE(SYMBOL, SIGNAL_DATE, MODE)" in existing_sql.replace(" ", " "):
            return  # Already migrated

        # Need to migrate. Be defensive — wrap in a transaction.
        logger.info("Migrating signals table to UNIQUE(symbol, signal_date, mode)")
        conn.execute("BEGIN")
        try:
            conn.execute("ALTER TABLE signals RENAME TO signals_old_v1")
            conn.execute(_CREATE_SIGNALS)
            conn.execute(_CREATE_INDEX)
            # Copy data — column order matches between old and new
            conn.execute("""
                INSERT INTO signals
                SELECT * FROM signals_old_v1
            """)
            conn.execute("DROP TABLE signals_old_v1")
            conn.execute("COMMIT")
            logger.info("Schema migration complete")
        except Exception as exc:
            conn.execute("ROLLBACK")
            logger.error("Schema migration failed, rolling back: %s", exc)
            raise
    except Exception as exc:
        logger.warning("Migration check failed (non-fatal): %s", exc)


# ══════════════════════════════════════════════════════════════════════════════
# DB INIT
# ══════════════════════════════════════════════════════════════════════════════


def _ensure_db() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(_CREATE_SIGNALS)
    conn.execute(_CREATE_INDEX)
    _migrate_unique_constraint_v2(conn)
    conn.commit()
    return conn


def init_tracker():
    """Called once at startup."""
    _ensure_db().close()
    logger.info("Signal tracker DB ready: %s", _DB_PATH)


# ══════════════════════════════════════════════════════════════════════════════
# SIGNAL LOGGING (called from DataManager)
# ══════════════════════════════════════════════════════════════════════════════


def log_signal(dm_sig) -> bool:
    """
    Log a dual-mode entry signal to the tracker DB.

    Called by DataManager when dm_sig.entry_triggered is True.
    Deduplicates by (symbol, signal_date) — one entry per symbol per day.

    Returns True if logged (new), False if duplicate or error.
    """
    if not getattr(dm_sig, "entry_triggered", False):
        return False

    try:
        conn = _ensure_db()
        today = datetime.date.today().isoformat()
        ts = datetime.datetime.now().isoformat(timespec="seconds")

        conn.execute(
            """INSERT OR IGNORE INTO signals
               (symbol, signal_date, signal_ts, mode, segment,
                entry_price, sma_20, pct_from_sma,
                wr_value, adx_14,
                base_score, options_overlay, filing_overlay, is_trap,
                dual_score, dual_label, dual_sizing,
                entry_reason, input_interval, daily_bars)
               VALUES (?,?,?,?,?, ?,?,?, ?,?, ?,?,?,?, ?,?,?, ?,?,?)""",
            (
                dm_sig.symbol,
                today,
                ts,
                dm_sig.tier,
                "UNIFIED",
                dm_sig.close,
                dm_sig.sma_20,
                dm_sig.pct_from_sma,
                dm_sig.wr_30,
                dm_sig.adx_14,
                dm_sig.base_score,
                dm_sig.options_overlay,
                dm_sig.filing_overlay,
                1 if dm_sig.is_trap else 0,
                dm_sig.dual_score,
                dm_sig.dual_label,
                dm_sig.dual_sizing,
                dm_sig.entry_reason,
                dm_sig.input_interval,
                dm_sig.daily_bars_used,
            ),
        )
        inserted = conn.total_changes
        conn.commit()
        conn.close()

        if inserted:
            logger.info(
                "Signal logged: %s %s mode=%s score=%d",
                dm_sig.symbol, today, dm_sig.tier, dm_sig.dual_score,
            )
            return True
        return False

    except Exception as exc:
        logger.warning("Signal log failed: %s", exc)
        return False


def log_ride_signal(ride_result) -> bool:
    """
    Log a BB Ride entry signal to the tracker DB.

    Called by DataManager when ride_result.entry_triggered is True.
    Same DB and table as log_signal() — distinguished by mode='RIDE'.
    Deduplicates by (symbol, signal_date) — one entry per symbol per day.

    The Ride strategy uses different field names than DualModeSignal but
    populates the same tracker schema. Fields not relevant to Ride (e.g.
    options_overlay, filing_overlay, is_trap) are stored as 0 / empty.

    Returns True if logged (new), False if duplicate or error.
    """
    if not getattr(ride_result, "entry_triggered", False):
        return False

    try:
        conn = _ensure_db()
        today = datetime.date.today().isoformat()
        ts = datetime.datetime.now().isoformat(timespec="seconds")

        # Map Ride fields → tracker schema. Grade letter goes into dual_label,
        # sizing into dual_sizing. Score is grade_pts (0-6 range, smaller than
        # MR's 0-100 but interpretable in context).
        conn.execute(
            """INSERT OR IGNORE INTO signals
               (symbol, signal_date, signal_ts, mode, segment,
                entry_price, sma_20, pct_from_sma,
                wr_value, adx_14,
                base_score, options_overlay, filing_overlay, is_trap,
                dual_score, dual_label, dual_sizing,
                entry_reason, input_interval, daily_bars)
               VALUES (?,?,?,?,?, ?,?,?, ?,?, ?,?,?,?, ?,?,?, ?,?,?)""",
            (
                ride_result.symbol,
                today,
                ts,
                "RIDE",                              # distinguishes from PRIMARY (MR)
                "BB_RIDE",
                ride_result.close,
                0.0,                                  # sma_20 — not tracked by Ride
                ride_result.pct_from_sma50,           # closest analog: % from 50d SMA
                0.0,                                  # wr_value — not used by Ride
                ride_result.adx,
                ride_result.grade_pts,                # base_score column reused
                0,                                    # options_overlay — N/A for Ride
                0,                                    # filing_overlay — N/A for Ride
                0,                                    # is_trap — N/A for Ride
                ride_result.grade_pts,                # dual_score — same as base_score
                ride_result.grade,                    # dual_label = grade letter
                ride_result.sizing,
                ride_result.entry_reason,
                "1D",
                0,
            ),
        )
        inserted = conn.total_changes
        conn.commit()
        conn.close()

        if inserted:
            logger.info(
                "Ride signal logged: %s %s grade=%s sizing=%s",
                ride_result.symbol, today, ride_result.grade, ride_result.sizing,
            )
            return True
        return False

    except Exception as exc:
        logger.warning("Ride signal log failed: %s", exc)
        return False


# ══════════════════════════════════════════════════════════════════════════════
# OUTCOME RESOLUTION
# ══════════════════════════════════════════════════════════════════════════════


def get_unresolved(max_age_days: int = 30) -> list[dict]:
    """Get signals that need outcome resolution."""
    try:
        conn = _ensure_db()
        cutoff = (
            datetime.date.today() - datetime.timedelta(days=max_age_days)
        ).isoformat()
        cursor = conn.execute(
            """SELECT * FROM signals
               WHERE resolved = 0 AND signal_date >= ?
               ORDER BY signal_date ASC""",
            (cutoff,),
        )
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows
    except Exception as exc:
        logger.warning("get_unresolved failed: %s", exc)
        return []


def resolve_signal(
    signal_id: int,
    exit_price: float,
    peak_price: float = 0.0,
    exit_reason: str = "HOLD_COMPLETE",
) -> bool:
    """
    Mark a signal as resolved with its outcome.

    Called by run_resolve.py after fetching the close price
    HOLD_DAYS trading days after signal_date.
    """
    try:
        conn = _ensure_db()
        row = conn.execute(
            "SELECT entry_price FROM signals WHERE id = ?", (signal_id,)
        ).fetchone()
        if not row:
            conn.close()
            return False

        entry_price = row["entry_price"]
        pnl_pct = (exit_price / entry_price - 1) * 100 if entry_price > 0 else 0.0
        max_dd = (
            (min(exit_price, peak_price) / entry_price - 1) * 100
            if peak_price > 0 and entry_price > 0
            else 0.0
        )

        conn.execute(
            """UPDATE signals SET
                 resolved = 1,
                 resolve_date = ?,
                 exit_price = ?,
                 pnl_pct = ?,
                 peak_price = ?,
                 max_drawdown = ?,
                 exit_reason = ?
               WHERE id = ?""",
            (
                datetime.date.today().isoformat(),
                exit_price,
                round(pnl_pct, 4),
                peak_price,
                round(max_dd, 4),
                exit_reason,
                signal_id,
            ),
        )
        conn.commit()
        conn.close()

        logger.info(
            "Signal %d resolved: P&L=%+.2f%% exit_reason=%s",
            signal_id, pnl_pct, exit_reason,
        )
        return True

    except Exception as exc:
        logger.warning("resolve_signal failed: %s", exc)
        return False


# ══════════════════════════════════════════════════════════════════════════════
# PERFORMANCE TRACKING
# ══════════════════════════════════════════════════════════════════════════════


def get_performance(mode: str = None, last_n: int = None) -> dict:
    """
    Compute live performance stats from resolved signals.

    Args:
        mode: "A" or "B" or None for all
        last_n: only consider last N resolved signals (rolling window)

    Returns dict with win_rate, avg_pnl, n_signals, sharpe, etc.
    """
    try:
        conn = _ensure_db()
        query = "SELECT * FROM signals WHERE resolved = 1"
        params = []
        if mode:
            query += " AND mode = ?"
            params.append(mode)
        query += " ORDER BY signal_date DESC"
        if last_n:
            query += " LIMIT ?"
            params.append(last_n)

        cursor = conn.execute(query, params)
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()

        if not rows:
            return {"n_signals": 0, "status": "NO_DATA"}

        pnls = [r["pnl_pct"] for r in rows if r["pnl_pct"] is not None]
        if not pnls:
            return {"n_signals": len(rows), "status": "NO_OUTCOMES"}

        import numpy as np
        pnls = np.array(pnls)
        wins = pnls[pnls > 0]
        losses = pnls[pnls <= 0]

        avg = float(pnls.mean())
        std = float(pnls.std()) if len(pnls) > 1 else 0.0

        return {
            "n_signals": len(pnls),
            "win_rate": round(len(wins) / len(pnls) * 100, 1),
            "avg_pnl": round(avg, 3),
            "med_pnl": round(float(np.median(pnls)), 3),
            "total_pnl": round(float(pnls.sum()), 2),
            "avg_win": round(float(wins.mean()), 3) if len(wins) > 0 else 0,
            "avg_loss": round(float(losses.mean()), 3) if len(losses) > 0 else 0,
            "sharpe": round(avg / std * 7.1, 2) if std > 0 else 0,
            "profit_factor": round(
                float(wins.sum()) / abs(float(losses.sum())), 2
            ) if len(losses) > 0 and losses.sum() != 0 else 999,
            "status": "OK",
        }

    except Exception as exc:
        logger.warning("get_performance failed: %s", exc)
        return {"n_signals": 0, "status": f"ERROR: {exc}"}


# ══════════════════════════════════════════════════════════════════════════════
# DRIFT DETECTION
# ══════════════════════════════════════════════════════════════════════════════


def check_drift(window: int = 20) -> dict:
    """
    Check if live performance has drifted from backtest expectations.

    Looks at the last `window` resolved signals per mode.
    Returns drift status per mode.

    Drift levels:
      OK        — within expectations
      WARNING   — win rate below expected but above threshold
      ALERT     — win rate or avg return below minimum threshold
      NO_DATA   — insufficient resolved signals

    SECONDARY tier is skipped entirely when ENABLE_SECONDARY_TIER=False
    in dual_mode.py — no new SECONDARY signals are emitted in production
    so checking drift on it would show "Need 10 more signals" forever
    once historical SECONDARY entries age out of the rolling window.
    """
    from modules.dual_mode import ENABLE_SECONDARY_TIER
    result = {}

    modes_to_check = ["PRIMARY"]
    if ENABLE_SECONDARY_TIER:
        modes_to_check.append("SECONDARY")

    for mode_key in modes_to_check:
        perf = get_performance(mode=mode_key, last_n=window)
        exp = EXPECTED[mode_key]

        if perf["n_signals"] < 10:
            result[mode_key] = {
                "status": "NO_DATA",
                "n": perf["n_signals"],
                "message": f"Need {10 - perf['n_signals']} more signals for Tier {mode_key}",
            }
            continue

        wr = perf["win_rate"]
        avg = perf["avg_pnl"]

        if wr < exp["min_win_rate"] or avg < exp["min_avg_return"]:
            status = "ALERT"
            message = (
                f"Tier {mode_key} DRIFT ALERT: "
                f"win={wr:.1f}% (expect ≥{exp['min_win_rate']:.0f}%), "
                f"avg={avg:+.2f}% (expect ≥{exp['min_avg_return']:.1f}%) "
                f"over last {perf['n_signals']} signals"
            )
        elif wr < exp["win_rate"] * 0.85:
            status = "WARNING"
            message = (
                f"Tier {mode_key} below expectation: "
                f"win={wr:.1f}% vs expected {exp['win_rate']:.0f}% "
                f"({perf['n_signals']} signals)"
            )
        else:
            status = "OK"
            message = (
                f"Tier {mode_key} on track: "
                f"win={wr:.1f}% avg={avg:+.2f}% "
                f"({perf['n_signals']} signals)"
            )

        result[mode_key] = {
            "status": status,
            "n": perf["n_signals"],
            "win_rate": wr,
            "avg_pnl": avg,
            "expected_wr": exp["win_rate"],
            "message": message,
            **perf,
        }

    return result


# ══════════════════════════════════════════════════════════════════════════════
# EXPORT (for upload to Claude)
# ══════════════════════════════════════════════════════════════════════════════


def export_report() -> str:
    """
    Generate a text report of all tracked signals and outcomes.
    Designed to be uploaded to Claude for validation.
    """
    lines = []
    lines.append("NIMBUS FORWARD VALIDATION REPORT")
    lines.append(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("")

    # Summary
    for mode_key in ("PRIMARY", "SECONDARY"):
        mode_name = "Primary" if mode_key == "PRIMARY" else "Secondary"
        perf = get_performance(mode=mode_key)
        exp = EXPECTED[mode_key]

        lines.append(f"═══ TIER {mode_key}: {mode_name} ═══")
        if perf["n_signals"] == 0:
            lines.append("  No resolved signals yet.")
        else:
            lines.append(f"  Resolved signals: {perf['n_signals']}")
            lines.append(f"  Win rate:   {perf['win_rate']:5.1f}%  (expected: {exp['win_rate']:.0f}%)")
            lines.append(f"  Avg P&L:    {perf['avg_pnl']:+.3f}%  (expected: {exp['avg_return']:+.2f}%)")
            lines.append(f"  Median P&L: {perf['med_pnl']:+.3f}%")
            lines.append(f"  Profit fac: {perf['profit_factor']:.2f}")
            lines.append(f"  Sharpe:     {perf['sharpe']:.2f}  (expected: {exp['sharpe']:.2f})")
        lines.append("")

    # Drift
    drift = check_drift()
    lines.append("═══ DRIFT STATUS ═══")
    for mode_key, d in drift.items():
        lines.append(f"  Mode {mode_key}: {d['status']} — {d['message']}")
    lines.append("")

    # Signal log
    try:
        conn = _ensure_db()
        cursor = conn.execute(
            "SELECT * FROM signals ORDER BY signal_date DESC LIMIT 100"
        )
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
    except Exception:
        rows = []

    lines.append("═══ SIGNAL LOG (last 100) ═══")
    lines.append(
        f"{'Date':12s} {'Symbol':10s} {'Mode':4s} {'Score':5s} {'Label':8s} "
        f"{'Size':5s} {'Entry':>8s} {'Exit':>8s} {'P&L':>7s} {'Reason':15s}"
    )
    lines.append("-" * 95)

    for r in rows:
        pnl = f"{r['pnl_pct']:+.2f}%" if r["pnl_pct"] is not None else "—"
        exit_p = f"{r['exit_price']:.2f}" if r["exit_price"] else "—"
        reason = r.get("exit_reason", "") or ("pending" if not r["resolved"] else "")
        lines.append(
            f"{r['signal_date']:12s} {r['symbol']:10s} {r['mode']:4s} "
            f"{r['dual_score']:5d} {r['dual_label']:8s} {r['dual_sizing']:5s} "
            f"{r['entry_price']:8.2f} {exit_p:>8s} {pnl:>7s} {reason:15s}"
        )

    lines.append("")
    lines.append("── END OF REPORT ──")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# EOD SNAPSHOT SCHEDULING
# ══════════════════════════════════════════════════════════════════════════════
#
# The EOD snapshot is a once-per-trading-day operation that:
#   1. Runs the scanner over NIFTY 200 with EOD data
#   2. Logs all qualifying entries (S/A+/A/B+) for both MR and Ride
#   3. Resolves any prior unresolved signals
#
# It must NOT run during market hours (data is mid-day, would corrupt the
# tracker's "snapshot at close" semantics). It must NOT run twice for the
# same trading day. The scheduling logic enforces both.
#
# Marker file: ~/.nimbus/last_snapshot.txt — single line, ISO date of the
# trading day we last successfully snapshotted (e.g., "2026-04-08").

import zoneinfo

# NSE market close: 3:30pm IST. Wait until 4:30pm IST for yfinance to settle.
_NSE_CLOSE_HOUR_IST = 16
_NSE_CLOSE_MINUTE_IST = 30


def _snapshot_marker_path() -> str:
    """Path to the snapshot marker file. Lives next to signal_tracker.db."""
    db_dir = os.path.dirname(_resolve_db_path("signal_tracker.db"))
    return os.path.join(db_dir, "last_snapshot.txt")


def get_last_snapshot_date() -> str | None:
    """Read the marker file. Returns ISO date string or None if not set."""
    path = _snapshot_marker_path()
    if not os.path.exists(path):
        return None
    try:
        with open(path) as f:
            return f.read().strip() or None
    except Exception:
        return None


def mark_snapshot_done(trading_day_iso: str) -> bool:
    """Write the marker file with the trading day we just snapshotted."""
    path = _snapshot_marker_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(trading_day_iso)
        logger.info("Snapshot marker updated: %s", trading_day_iso)
        return True
    except Exception as exc:
        logger.warning("Failed to write snapshot marker: %s", exc)
        return False


def get_most_recent_nse_trading_day() -> str | None:
    """
    Fetch the most recent NSE trading day with available data.

    Uses ^NSEI (NIFTY 50 index) as the source of truth. If today is a
    trading day and yfinance has today's bar, returns today's date. If
    today is a holiday/weekend or yfinance hasn't updated yet, returns
    the most recent prior trading day.

    Returns ISO date string or None on failure.
    """
    try:
        import yfinance as yf
        import datetime as _dt
        # Pull last 10 calendar days — enough buffer for long weekends
        df = yf.download(
            tickers="^NSEI",
            start=(_dt.date.today() - _dt.timedelta(days=10)).isoformat(),
            interval="1d",
            auto_adjust=True,
            progress=False,
        )
        if hasattr(df.columns, "levels"):
            df.columns = df.columns.get_level_values(0)
        if df.empty:
            return None
        last_idx = df.index[-1]
        if hasattr(last_idx, "date"):
            return last_idx.date().isoformat()
        return str(last_idx)[:10]
    except Exception as exc:
        logger.debug("get_most_recent_nse_trading_day failed: %s", exc)
        return None


def should_run_snapshot_now() -> tuple[bool, str]:
    """
    Decide whether the EOD snapshot should run right now.

    Returns (should_run, reason). reason is a human-readable message
    suitable for logging — useful for explaining why a launch did or
    didn't trigger a snapshot.

    Rules:
      1. Fetch the most recent NSE trading day from ^NSEI
      2. If marker file already records that day → skip ("already done")
      3. If today's IST time is BEFORE 4:30pm AND today equals that
         trading day → skip ("market still in session")
      4. Otherwise → run

    The 4:30pm gate gives yfinance ~1 hour after the 3:30pm NSE close
    to update its EOD bars. Earlier launches risk getting stale data.
    """
    last_trading_day = get_most_recent_nse_trading_day()
    if last_trading_day is None:
        return (False, "could not determine most recent NSE trading day")

    last_done = get_last_snapshot_date()
    if last_done and last_done >= last_trading_day:
        return (False, f"snapshot already done for {last_trading_day}")

    # Check if we're still in market hours on the most recent trading day
    try:
        ist = zoneinfo.ZoneInfo("Asia/Kolkata")
        now_ist = datetime.datetime.now(ist)
        today_ist = now_ist.date().isoformat()

        # If yfinance's "latest day" is today AND we're before 4:30pm IST,
        # the data is intraday and not yet final. Wait.
        if today_ist == last_trading_day:
            close_time = datetime.time(_NSE_CLOSE_HOUR_IST, _NSE_CLOSE_MINUTE_IST)
            if now_ist.time() < close_time:
                return (
                    False,
                    f"market still in session "
                    f"(now {now_ist.strftime('%H:%M IST')}, waiting until 16:30)",
                )
    except Exception as exc:
        logger.debug("IST time check failed (proceeding anyway): %s", exc)

    return (True, f"ready to snapshot {last_trading_day}")
