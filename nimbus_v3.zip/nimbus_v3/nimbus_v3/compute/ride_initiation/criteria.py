"""Pure per-criterion functions used by the ride engine.

Each function takes raw OHLC + indicator series and returns a
boolean ``pd.Series`` aligned to the input. No state, no I/O.

These functions are the **single source of truth** for criterion
semantics. The engine, the debug utility, and the score module all
call into them, ensuring no drift between fire detection and debug
output (a real bug we hit in the previous monolithic implementation).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .constants import (
    BBW_FLOOR_PERCENTILE,
    BBW_FLOOR_WINDOW,
    BBW_LOOKBACK,
    BODY_STRENGTH_MIN,
    CONT_DETACHED_PCTB_MAX,
    CONT_RIDE_BARS_MIN,
    CONT_RIDE_LOOKBACK,
    CONT_TREND_BUFFER,
    CONT_VOL_DECAY_FLOOR,
    CROSS_LOOKBACK,
    DETACHED_PCTB_MAX,
    DETACHED_PCTB_MAX_COMPRESSED,
    OPEN_PCTB_MAX,
    OPEN_PCTB_MIN,
    RETEST_PULLBACK_MAX_BARS,
    RETEST_PULLBACK_PCTB_MAX,
    RETEST_PULLBACK_PCTB_MIN,
    RETEST_RIDE_BARS_MIN,
    RETEST_RIDE_LOOKBACK,
    SMA_SLOPE_WINDOW,
    VOL_PERCENTILE_FLOOR,
    VOL_PERCENTILE_WINDOW,
    VOL_SURGE_RATIO,
    VOL_SURGE_WINDOW,
)


# ══════════════════════════════════════════════════════════════════════
# Derived series (used by multiple criteria)
# ══════════════════════════════════════════════════════════════════════


def pct_b_close(df: pd.DataFrame) -> pd.Series:
    """%B(close) — (close - lower) / (upper - lower)."""
    bw = (df["bb_20_1s_upper"] - df["bb_20_1s_lower"]).replace(0.0, np.nan)
    return (df["Close"] - df["bb_20_1s_lower"]) / bw


def pct_b_open(df: pd.DataFrame) -> pd.Series:
    """%B(open)."""
    bw = (df["bb_20_1s_upper"] - df["bb_20_1s_lower"]).replace(0.0, np.nan)
    return (df["Open"] - df["bb_20_1s_lower"]) / bw


def body_above_band(df: pd.DataFrame) -> pd.Series:
    """True where BOTH Open and Close exceed the upper BB."""
    return (df["Open"] > df["bb_20_1s_upper"]) & (df["Close"] > df["bb_20_1s_upper"])


def sma_slope(df: pd.DataFrame) -> pd.Series:
    """SMA20 slope per bar over SMA_SLOPE_WINDOW."""
    sma = df["sma_20"]
    return (sma - sma.shift(SMA_SLOPE_WINDOW)) / SMA_SLOPE_WINDOW


def adaptive_detached_ceiling(df: pd.DataFrame) -> pd.Series:
    """Per-bar detachment ceiling for %B(close).

    Compressed bands (BBW < 60-bar median) → relaxed ceiling.
    Anchored at T-1 to avoid circularity (fire bar's own expansion
    inflating its own ceiling).
    """
    bbw = df["bbw_20_1s"]
    bbw_median = bbw.rolling(
        BBW_FLOOR_WINDOW, min_periods=BBW_FLOOR_WINDOW // 2
    ).quantile(0.5)
    bands_compressed = bbw.shift(1) < bbw_median.shift(1)
    return bands_compressed.map(
        {True: DETACHED_PCTB_MAX_COMPRESSED, False: DETACHED_PCTB_MAX}
    ).fillna(DETACHED_PCTB_MAX)


# ══════════════════════════════════════════════════════════════════════
# Shared filters (used by multiple phases)
# ══════════════════════════════════════════════════════════════════════


def crit_hold_ok(df: pd.DataFrame) -> pd.Series:
    """Body-above today AND yesterday."""
    body = body_above_band(df)
    return body & body.shift(1, fill_value=False)


def crit_not_detached_today(df: pd.DataFrame) -> pd.Series:
    """%B(close) at T ≤ adaptive ceiling."""
    return (pct_b_close(df) <= adaptive_detached_ceiling(df)).fillna(False)


def crit_not_detached_yesterday(df: pd.DataFrame) -> pd.Series:
    """%B(close) at T-1 ≤ ceiling at T-1."""
    return (pct_b_close(df).shift(1) <= adaptive_detached_ceiling(df).shift(1)).fillna(
        False
    )


def crit_not_gap_through(df: pd.DataFrame) -> pd.Series:
    """Open at T-1 ≥ SMA20 at T-1 (suppress gap-through pattern)."""
    return (df["Open"].shift(1) >= df["sma_20"].shift(1)).fillna(False).astype(bool)


def crit_slope_ok(df: pd.DataFrame) -> pd.Series:
    """SMA20 slope positive at T."""
    return (sma_slope(df) > 0).fillna(False)


def crit_body_strength(df: pd.DataFrame) -> pd.Series:
    """|close-open| / (high-low) ≥ BODY_STRENGTH_MIN at T."""
    rng = (df["High"] - df["Low"]).replace(0.0, np.nan)
    body = (df["Close"] - df["Open"]).abs()
    return (body / rng >= BODY_STRENGTH_MIN).fillna(False)


# ══════════════════════════════════════════════════════════════════════
# INITIATION-specific
# ══════════════════════════════════════════════════════════════════════


def crit_fresh_cross(df: pd.DataFrame) -> pd.Series:
    """T-1 is the FIRST body-above bar in the last CROSS_LOOKBACK bars."""
    body = body_above_band(df)
    prior_above_count = body.shift(2).rolling(CROSS_LOOKBACK, min_periods=1).sum()
    body_t1 = body.shift(1, fill_value=False)
    return body_t1 & (prior_above_count == 0)


def crit_open_in_zone(df: pd.DataFrame) -> pd.Series:
    """%B(open) at T in [OPEN_PCTB_MIN, OPEN_PCTB_MAX]."""
    pbo = pct_b_open(df)
    return ((pbo >= OPEN_PCTB_MIN) & (pbo <= OPEN_PCTB_MAX)).fillna(False)


def crit_bbw_ok(df: pd.DataFrame) -> pd.Series:
    """BBW expanding (T > T-2) AND ≥ BBW_FLOOR_PERCENTILE of recent."""
    bbw = df["bbw_20_1s"]
    expanding = bbw > bbw.shift(BBW_LOOKBACK)
    floor = bbw.rolling(BBW_FLOOR_WINDOW, min_periods=BBW_FLOOR_WINDOW // 2).quantile(
        BBW_FLOOR_PERCENTILE
    )
    return (expanding & (bbw >= floor)).fillna(False)


def crit_vol_surge(df: pd.DataFrame) -> pd.Series:
    """Vol ≥ VOL_SURGE_RATIO × 20-bar avg AND ≥ percentile floor."""
    vol = df["Volume"]
    vol_sma = vol.rolling(VOL_SURGE_WINDOW, min_periods=10).mean()
    vol_pct = vol.rolling(
        VOL_PERCENTILE_WINDOW, min_periods=VOL_PERCENTILE_WINDOW // 2
    ).quantile(VOL_PERCENTILE_FLOOR)
    return ((vol >= vol_sma * VOL_SURGE_RATIO) & (vol >= vol_pct)).fillna(False)


# ══════════════════════════════════════════════════════════════════════
# CONTINUATION-specific
# ══════════════════════════════════════════════════════════════════════


def crit_cont_established_ride(df: pd.DataFrame) -> pd.Series:
    """At least CONT_RIDE_BARS_MIN of last CONT_RIDE_LOOKBACK bars
    had %B(close) ≥ 1.0."""
    pbc_above = (pct_b_close(df) >= 1.0).fillna(False).astype(int)
    rolling = pbc_above.rolling(CONT_RIDE_LOOKBACK, min_periods=CONT_RIDE_LOOKBACK).sum()
    return (rolling >= CONT_RIDE_BARS_MIN).fillna(False)


def crit_cont_not_extended(df: pd.DataFrame) -> pd.Series:
    """%B(close) at T ≤ CONT_DETACHED_PCTB_MAX (tighter than INIT)."""
    return (pct_b_close(df) <= CONT_DETACHED_PCTB_MAX).fillna(False)


def crit_cont_above_trend(df: pd.DataFrame) -> pd.Series:
    """Close ≥ SMA20 × CONT_TREND_BUFFER at T."""
    return (df["Close"] >= df["sma_20"] * CONT_TREND_BUFFER).fillna(False)


def crit_cont_vol_not_decayed(df: pd.DataFrame) -> pd.Series:
    """Recent 20-bar vol avg ≥ CONT_VOL_DECAY_FLOOR × older 20-bar avg
    (10 bars earlier). Filters rides where volume has collapsed.
    """
    vol_sma = df["Volume"].rolling(VOL_SURGE_WINDOW, min_periods=10).mean()
    older = vol_sma.shift(10)
    ratio = vol_sma / older
    return (ratio >= CONT_VOL_DECAY_FLOOR).fillna(False)


# ══════════════════════════════════════════════════════════════════════
# RETEST-specific
# ══════════════════════════════════════════════════════════════════════


def crit_retest_qualified_base(df: pd.DataFrame) -> pd.Series:
    """At least ``RETEST_RIDE_BARS_MIN`` body-above bars in a
    ``RETEST_RIDE_LOOKBACK``-bar window ending immediately before the
    pullback window — i.e. ending at ``T - RETEST_PULLBACK_MAX_BARS``.

    Establishes "this was a real ride before the pullback." The
    aligning shift here is ``RETEST_PULLBACK_MAX_BARS`` (not +1) so
    the prior-ride window ends on the bar just before the pullback
    window's first bar — keeps the two adjacent without gap.
    """
    body = body_above_band(df).astype(int)
    # Window ends at T-RETEST_PULLBACK_MAX_BARS, which is one bar
    # before the first bar of the pullback window. So shift by
    # PULLBACK_MAX_BARS and roll over the lookback.
    shift_amount = RETEST_PULLBACK_MAX_BARS
    rolling = body.shift(shift_amount).rolling(
        RETEST_RIDE_LOOKBACK, min_periods=RETEST_RIDE_LOOKBACK
    ).sum()
    return (rolling >= RETEST_RIDE_BARS_MIN).fillna(False)


def crit_retest_pullback_occurred(df: pd.DataFrame) -> pd.Series:
    """Within the last ``RETEST_PULLBACK_MAX_BARS`` bars ending at
    ``T-1`` (i.e. excluding today, the resumption bar), at least one
    bar had %B(close) in [``RETEST_PULLBACK_PCTB_MIN``,
    ``RETEST_PULLBACK_PCTB_MAX``].

    The window is ``[T-PULLBACK_MAX_BARS .. T-1]`` — so a 5-bar window
    on a daily chart means yesterday + the four bars before. Including
    yesterday is critical: the cleanest possible RETEST is a 1-bar
    dip yesterday into the band followed by today's body-above
    resumption. (Previous implementation used ``.shift(2)`` which
    skipped yesterday entirely, making 1-day-pullback patterns
    impossible to fire — fixed.)
    """
    pbc = pct_b_close(df)
    in_pullback_zone = (
        (pbc >= RETEST_PULLBACK_PCTB_MIN) & (pbc <= RETEST_PULLBACK_PCTB_MAX)
    ).fillna(False).astype(int)
    # Window of bars [T-RETEST_PULLBACK_MAX_BARS .. T-1]
    rolling = in_pullback_zone.shift(1).rolling(
        RETEST_PULLBACK_MAX_BARS, min_periods=1
    ).sum()
    return (rolling >= 1).fillna(False)


def crit_retest_held_sma(df: pd.DataFrame) -> pd.Series:
    """During the pullback window ``[T-PULLBACK_MAX_BARS .. T-1]``,
    close ≥ SMA20 on every bar.

    Quality discriminator: a retest that broke SMA20 even briefly is
    a failed rally, not a healthy retest. Window is now aligned with
    :func:`crit_retest_pullback_occurred` to include yesterday — same
    off-by-one fix.
    """
    held = (df["Close"] >= df["sma_20"]).fillna(False).astype(int)
    rolling = held.shift(1).rolling(
        RETEST_PULLBACK_MAX_BARS, min_periods=1
    ).sum()
    return (rolling >= RETEST_PULLBACK_MAX_BARS).fillna(False)


def crit_retest_resumption(df: pd.DataFrame) -> pd.Series:
    """Body above band at T (resumption of the ride)."""
    return body_above_band(df)
