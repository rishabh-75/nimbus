"""nimbus_v3.strategies.registry — strategy registration and dispatch.

The scan engine does not hard-code its strategy list. Instead it
constructs a ``StrategyRegistry`` at startup, ``register()``s every
active strategy, and uses ``evaluate_all()`` to run them against a
``(symbol, state, contexts)`` triple.

This is a pure dispatch layer — no business logic. The order in which
signals are returned is governed by ``Strategy.priority`` (desc),
not by registration order.

The ``build_registry(mode)`` factory below provides the canonical
production and aggressive registrations. Scripts/tests that need a
custom set can still roll their own ``StrategyRegistry()`` and
register individual strategies.
"""
from __future__ import annotations

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import StrategyMode
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import Strategy, StrategySignal


class StrategyRegistry:
    """Holds a sequence of ``Strategy`` instances and evaluates them all."""

    def __init__(self) -> None:
        self._strategies: list[Strategy] = []

    def register(self, strategy: Strategy) -> None:
        """Add ``strategy`` to the registry.

        Registration order does not affect evaluation order —
        ``evaluate_all`` sorts by priority.
        """
        self._strategies.append(strategy)

    def __iter__(self):
        return iter(self._strategies)

    def __len__(self) -> int:
        return len(self._strategies)

    def evaluate_all(
        self,
        *,
        symbol: str,
        symbol_meta: SymbolMeta,
        state: SignalState,
        contexts: ContextBundle,
    ) -> list[StrategySignal]:
        """Evaluate every eligible strategy; return every firing signal.

        Eligibility is determined by ``Strategy.accepts(symbol_meta)``.
        Returned signals are sorted by priority descending then by
        ``setup_type.value`` ascending for stable ordering on ties.
        """
        results: list[StrategySignal] = []
        for strat in self._strategies:
            if not strat.accepts(symbol_meta):
                continue
            signal = strat.evaluate(symbol=symbol, state=state, contexts=contexts)
            if signal is not None:
                results.append(signal)
        results.sort(
            key=lambda s: (-s.priority, s.setup_type.value, s.strategy_name),
        )
        return results


# ══════════════════════════════════════════════════════════════════════════════
# Canonical registry builders
# ══════════════════════════════════════════════════════════════════════════════

def build_registry(mode: StrategyMode) -> StrategyRegistry:
    """Build the canonical strategy registry for a given mode.

    CONSERVATIVE — v3's OOS-validated production strategies plus the
    research-tier strategies (weight 0, emit-only for tracking).
    Default mode shipped to operators.

    AGGRESSIVE — oracle's legacy strategies (``AggressiveMeanReversion``,
    ``AggressiveRide``) with production weight 1.0. TRAP is included
    in both modes because it's a filing-driven hard-skip override
    independent of the entry-gate philosophy.

    Research-tier strategies (Breakout, PullbackUptrend,
    DrawdownReversal, ETFMomentum) ship only in CONSERVATIVE mode
    because oracle didn't have equivalents — AGGRESSIVE mode is a
    faithful port of oracle's two-strategy production set. Operators
    who want to see research tier should use CONSERVATIVE.
    """
    # Local imports keep the registry module free of per-strategy
    # circular-import risk and reduce startup cost when a caller
    # only needs the class for typing.
    from nimbus_v3.strategies.aggressive_mean_reversion import (
        AggressiveMeanReversionStrategy,
    )
    from nimbus_v3.strategies.aggressive_mean_reversion_tracking import (
        AggressiveMeanReversionTrackingStrategy,
    )
    from nimbus_v3.strategies.aggressive_ride import AggressiveRideStrategy
    from nimbus_v3.strategies.aggressive_ride_tracking import (
        AggressiveRideTrackingStrategy,
    )
    from nimbus_v3.strategies.breakout import BreakoutStrategy
    from nimbus_v3.strategies.drawdown_reversal import DrawdownReversalStrategy
    from nimbus_v3.strategies.etf_momentum import ETFMomentumStrategy
    from nimbus_v3.strategies.mean_reversion import MeanReversionStrategy
    from nimbus_v3.strategies.mean_reversion_tracking import (
        MeanReversionTrackingStrategy,
    )
    from nimbus_v3.strategies.pullback_uptrend import PullbackUptrendStrategy
    from nimbus_v3.strategies.ride import RideStrategy
    from nimbus_v3.strategies.ride_tracking import RideTrackingStrategy
    from nimbus_v3.strategies.trap import TrapStrategy

    reg = StrategyRegistry()
    if mode == StrategyMode.CONSERVATIVE:
        # Production — OOS-validated (weight 1.0 or 0.5).
        reg.register(MeanReversionStrategy())
        reg.register(RideStrategy())
        reg.register(TrapStrategy())
        # Tracking tier — weight 0, routes to MR / RIDE buckets via
        # shared setup_type. Surfaces the broader
        # "developing oversold" / "ride in play" population that
        # doesn't meet the strict production gates. Previously
        # conservative MR/Ride tables sat empty outside narrow
        # regime windows (VIX high-streak, industry whitelist); the
        # tracking tier makes the broader candidate population
        # visible as ungraded (D/WATCH/SKIP) rows alongside any
        # real graded entries.
        reg.register(MeanReversionTrackingStrategy())
        reg.register(RideTrackingStrategy())
        # Research tier — weight 0, emit-only for tracking. Routed
        # to the Research Monitor section in the scanner tab via
        # their non-MR / non-RIDE setup_types.
        reg.register(BreakoutStrategy())
        reg.register(PullbackUptrendStrategy())
        reg.register(DrawdownReversalStrategy())
        reg.register(ETFMomentumStrategy())
    elif mode == StrategyMode.AGGRESSIVE:
        # Two-tier oracle-parity. The production tier grades fresh
        # entries (weight 1.0). The tracking tier (weight 0.0) emits
        # ungraded "ride in play" / "developing oversold" signals so
        # the MR and Ride tables show every viable setup, not just
        # the narrow population that passes all primary-tier gates.
        # Mirrors oracle's ``bb_ride.py`` design where every symbol
        # gets a verdict — graded when ``entry_triggered``,
        # ungraded "△ RIDING — at upper band" otherwise.
        reg.register(AggressiveMeanReversionStrategy())
        reg.register(AggressiveRideStrategy())
        reg.register(AggressiveMeanReversionTrackingStrategy())
        reg.register(AggressiveRideTrackingStrategy())
        reg.register(TrapStrategy())
    else:
        raise ValueError(f"build_registry: unknown mode {mode!r}")
    return reg
