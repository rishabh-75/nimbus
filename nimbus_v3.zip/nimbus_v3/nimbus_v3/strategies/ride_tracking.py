"""nimbus_v3.strategies.ride_tracking — conservative-tier Ride tracking.

Companion to :class:`RideStrategy` (conservative production). Where
the production strategy requires:
  - ``symbol_meta.industry in _RIDE_EDGE_INDUSTRIES`` (narrow whitelist)
  - ``close`` in the 1σ–2σ upper band
  - ``green_streak >= 3``
  - ``ADX > 25``

…this tracking tier requires only:
  - ``close >= bb_20_1s_upper``  (at or above upper 1σ)
  - ``ADX >= 20``                (trending, not chop)

No industry gate, no streak requirement. Surfaces rides in
industries that the production strategy rejects because the OOS
study didn't validate an edge there — still worth watching, still
an informed entry candidate if the trader has conviction.

Matches :mod:`.aggressive_ride_tracking` in design: shared
``setup_type = SetupType.RIDE`` routes to the Ride bucket,
``production_weight = 0.0`` triggers the research-override
(grade=D / verdict=WATCH / sizing=SKIP).

De-duplication
──────────────

When the production Ride's gates would ALL fire, this tracking
strategy returns None. Prevents two Ride rows for the same symbol.
The production strategy's ``accepts`` filter is checked here too —
if the symbol is in the ride-edge whitelist AND satisfies the band
+ streak + ADX gates, production takes the slot.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class RideTrackingParams:
    adx_14_min: float = 20.0


#: Production-tier gates (from RideStrategy) — all four must fire
#: for the production strategy to emit. If they do, this tracking
#: strategy stands down.
_PRIMARY_GREEN_STREAK_MIN: int = 3
_PRIMARY_ADX_MIN: float = 25.0


class RideTrackingStrategy:
    """At-upper-band Ride tracking (conservative-tier). Rejects ETFs.

    Routes to the same RIDE bucket as :class:`RideStrategy`, but
    weight=0 → research-override → grade=D / verdict=WATCH /
    sizing=SKIP. Appears in the Scanner Ride table as ungraded
    tracking rows.

    Accepts every non-ETF symbol regardless of industry — that's
    the whole point. The production strategy's industry whitelist
    encodes the OOS-validated edge; tracking mirrors operator
    awareness, which should be industry-agnostic.
    """

    name: str = "RideTracking"
    setup_type: SetupType = SetupType.RIDE
    priority: int = 35          # below Ride's 40 — sorts after entries
    production_weight: float = 0.0

    def __init__(
        self,
        params: RideTrackingParams = RideTrackingParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        # No industry filter — tracking is deliberately broader than
        # the production whitelist.
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — state-only gates
    ) -> StrategySignal | None:
        # Core: close at or above the upper 1σ band.
        if state.bb_20_1s_upper <= 0:
            return None
        if state.close < state.bb_20_1s_upper:
            return None
        # Trending, not chop.
        if state.adx_14 < self._p.adx_14_min:
            return None

        # De-dupe: if this symbol's industry IS whitelisted AND the
        # production Ride's remaining gates fire, production emits.
        # We need symbol_meta to check the industry, but ``evaluate``
        # only receives state + contexts. The scanner invokes
        # ``accepts`` before ``evaluate`` for ``accepts`` gating, but
        # the industry-specific de-dupe requires a second lookup.
        # Conservatively: if state satisfies production's state-only
        # gates (band + streak + ADX), stand down regardless of
        # industry. The cost is that a whitelisted symbol might get
        # TWO Ride rows (production + tracking) if we were too loose;
        # this check prevents that.
        production_state_gates = (
            state.bb_20_2s_upper >= state.close           # close ≤ 2σ upper (ride zone)
            and state.green_streak >= _PRIMARY_GREEN_STREAK_MIN
            and state.adx_14 > _PRIMARY_ADX_MIN
        )
        if production_state_gates:
            return None

        # Compute %B for metadata.
        band_width = state.bb_20_1s_upper - state.bb_20_1s_lower
        bb_pct = (
            (state.close - state.bb_20_1s_lower) / band_width
            if band_width > 0 else 1.0
        )

        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "close": state.close,
                "bb_1s_upper": state.bb_20_1s_upper,
                "bb_1s_lower": state.bb_20_1s_lower,
                "bb_pct": bb_pct,
                "adx_14": state.adx_14,
                "green_streak": state.green_streak,
                "kind": "tracking",
            },
        )
