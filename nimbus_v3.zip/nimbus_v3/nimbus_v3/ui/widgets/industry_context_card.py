"""nimbus_v3.ui.widgets.industry_context_card — INDUSTRY CONTEXT card.

A compact card that renders the synthetic-index ride classification
for the active symbol's industry. The operator's read is meant to be
"what industry is this stock in, and is the *industry* in a ride
phase right now?".

Contents (top to bottom)
────────────────────────
- Title header: "INDUSTRY CONTEXT" (provided by PanelFrame)
- Industry name (small muted label, can be long)
- Phase badge — colour-coded by the synthetic's ride phase
- Score — the composite from compute.ride_initiation
- Member count — n peers in panel (with thin-peer caveat when low)
- Accent top-border reflects the phase colour.

Empty / thin-peer states
────────────────────────
``set_state(None)`` → muted "Industry context unavailable" line,
neutral border. Same treatment for symbols whose industry has fewer
peers in the loaded panel than ``min_members`` (default 3).

Public API
──────────
    :meth:`set_state(industry, ride_result, member_count, *, min_members=3)`
    :meth:`clear()`
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget

from nimbus_v3.compute.ride_initiation import RidePhase, RideResult
from nimbus_v3.ui.theme import (
    BLUE, BORDER, EM, FONT_MONO, FONT_UI, MUTED, WHITE,
)
from nimbus_v3.ui.widgets.components import PanelFrame


# ══════════════════════════════════════════════════════════════════════════════
# Phase → accent colour mapping. INIT lights up emerald (the most
# salient cue), RETEST blue, CONTINUATION muted (active but not new),
# NONE neutral.
# ══════════════════════════════════════════════════════════════════════════════

_PHASE_ACCENTS: Final[dict[str, str]] = {
    RidePhase.INITIATION.value:   EM,
    RidePhase.RETEST.value:       BLUE,
    RidePhase.CONTINUATION.value: MUTED,
    RidePhase.NONE.value:         BORDER,
}


@dataclass(frozen=True)
class IndustryContextState:
    """Frozen view of the synthetic-index ride state for one industry.

    Built by ``MainWindow`` from the panel + the active symbol's
    industry classification. Passed to :meth:`set_state` for render.
    """

    industry: str
    phase: RidePhase
    score: float          # NaN when no fire active
    member_count: int     # peers in the loaded panel
    is_thin: bool         # True when peer count < min for synthetic build


# ══════════════════════════════════════════════════════════════════════════════
# Internal row helper
# ══════════════════════════════════════════════════════════════════════════════


def _row(label: str, value: str, value_color: str = WHITE) -> QWidget:
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(8)
    k = QLabel(label.upper())
    k.setFont(QFont(FONT_UI, 7))
    k.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
    k.setFixedWidth(90)
    lay.addWidget(k)
    v = QLabel(value)
    v.setFont(QFont(FONT_MONO, 9, QFont.Weight.Bold))
    v.setStyleSheet(f"color: {value_color};")
    v.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    lay.addWidget(v, stretch=1)
    return w


# ══════════════════════════════════════════════════════════════════════════════
# IndustryContextCard
# ══════════════════════════════════════════════════════════════════════════════


class IndustryContextCard(QWidget):
    """Renders the synthetic-index ride state for the active symbol's
    industry.

    The card is embedded inside the Dashboard's Workflow Analysis
    column. State is set via :meth:`set_state`; the empty state shows
    a muted "unavailable" line and a neutral accent.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._build_ui()
        self.clear()

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def set_state(
        self,
        industry: str | None,
        ride_result: RideResult | None,
        member_count: int = 0,
        *,
        min_members: int = 3,
    ) -> None:
        """Render the card from the synthetic-index ride state.

        Args:
            industry: human-readable industry name. ``None`` or empty
                renders the empty-state.
            ride_result: ``RideEngine.classify_industry`` output, or
                ``None`` when peer count is below ``min_members`` (the
                synthetic can't be meaningfully built from fewer
                members).
            member_count: number of peers contributing to the
                synthetic. Used to surface the thin-peer caveat.
            min_members: floor below which the card switches to the
                thin-peer message.
        """
        if not industry or ride_result is None or ride_result.phase.empty:
            self._render_unavailable(industry, member_count, min_members)
            return

        is_thin = member_count < min_members
        if is_thin:
            self._render_thin(industry, member_count, min_members)
            return

        self._render_active(
            IndustryContextState(
                industry=industry,
                phase=ride_result.latest_phase,
                score=ride_result.latest_score,
                member_count=member_count,
                is_thin=False,
            )
        )

    def clear(self) -> None:
        """Reset to the empty-state placeholder."""
        self._render_unavailable(None, 0, 3)

    # ══════════════════════════════════════════════════════════════════════
    # Build
    # ══════════════════════════════════════════════════════════════════════

    def _build_ui(self) -> None:
        self._panel = PanelFrame(title="INDUSTRY CONTEXT")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self._panel)

        body = self._panel.content_layout()
        body.setSpacing(6)

        self._industry_lbl = QLabel("—")
        self._industry_lbl.setFont(QFont(FONT_UI, 9))
        self._industry_lbl.setWordWrap(True)
        self._industry_lbl.setStyleSheet(f"color: {WHITE};")
        body.addWidget(self._industry_lbl)

        self._rows_host = QWidget()
        self._rows_layout = QVBoxLayout(self._rows_host)
        self._rows_layout.setContentsMargins(0, 6, 0, 0)
        self._rows_layout.setSpacing(4)
        body.addWidget(self._rows_host)

        self._note_lbl = QLabel("")
        self._note_lbl.setFont(QFont(FONT_UI, 8))
        self._note_lbl.setWordWrap(True)
        self._note_lbl.setStyleSheet(f"color: {MUTED};")
        body.addWidget(self._note_lbl)

    # ══════════════════════════════════════════════════════════════════════
    # Render branches
    # ══════════════════════════════════════════════════════════════════════

    def _clear_rows(self) -> None:
        while self._rows_layout.count():
            item = self._rows_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _render_unavailable(
        self,
        industry: str | None,
        member_count: int,
        min_members: int,
    ) -> None:
        self._panel.set_accent(BORDER)
        self._industry_lbl.setText(industry or "—")
        self._clear_rows()
        if industry and member_count and member_count < min_members:
            self._note_lbl.setText(
                f"Only {member_count} peer(s) in panel — peer "
                f"analytics require ≥{min_members} members."
            )
        else:
            self._note_lbl.setText("Industry context unavailable.")

    def _render_thin(
        self,
        industry: str,
        member_count: int,
        min_members: int,
    ) -> None:
        self._panel.set_accent(BORDER)
        self._industry_lbl.setText(industry)
        self._clear_rows()
        self._rows_layout.addWidget(
            _row("Members", str(member_count), MUTED)
        )
        self._note_lbl.setText(
            f"Only {member_count} peer(s) — peer analytics require "
            f"≥{min_members} members."
        )

    def _render_active(self, st: IndustryContextState) -> None:
        accent = _PHASE_ACCENTS.get(st.phase.value, BORDER)
        self._panel.set_accent(accent)
        self._industry_lbl.setText(st.industry)

        self._clear_rows()
        self._rows_layout.addWidget(
            _row("Phase", st.phase.value, accent)
        )
        score_txt = "—" if not (st.score == st.score) else f"{st.score:.0f}"
        score_color = WHITE if score_txt != "—" else MUTED
        self._rows_layout.addWidget(_row("Score", score_txt, score_color))
        self._rows_layout.addWidget(
            _row("Members", str(st.member_count), WHITE)
        )

        if st.phase is RidePhase.INITIATION:
            self._note_lbl.setText("Industry just initiated a ride.")
        elif st.phase is RidePhase.RETEST:
            self._note_lbl.setText("Industry resuming after a pullback.")
        elif st.phase is RidePhase.CONTINUATION:
            self._note_lbl.setText("Industry in established continuation.")
        else:
            self._note_lbl.setText("Industry not riding right now.")
