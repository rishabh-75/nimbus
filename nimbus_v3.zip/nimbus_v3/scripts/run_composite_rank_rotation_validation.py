"""Research: does composite-rank rotation predict forward returns?

Question: an industry whose composite *rank* (1=highest among 50
industries) has improved over the past N days — does that rank-Δ
predict above-baseline forward returns for its member symbols? And
symmetrically: does deteriorating rank predict below-baseline
returns?

Hypothesis: capital cycle rotation (Marathon/Chancellor) is
observable in price+volume by tracking which industries are
gaining vs. losing relative position across the universe. The
composite score (trend + momentum + inflow) is the rank metric.

Methodology:
  1. Build composite per (industry, bar) using the exact UI formula.
  2. Rank cross-sectionally per bar (1 = highest composite).
  3. Compute Δrank over 5 / 10 / 20 day lookbacks.
  4. Stratify into 5 bands (big climb / mild climb / flat / mild
     fall / big fall).
  5. Pool member symbols per (window, band, fold) and measure
     mean fwd_10d vs universe baseline.
  6. Walk-forward 4 expanding folds, 10-bar purge.

Ship rule (decided BEFORE seeing data):
  - Cell ships if sign agrees in ≥ 3 of 4 folds AND
    mean test-fold lift exceeds ±0.5 pp.
  - Don't ship if no cell clears both bars.

Output: ``scripts/output/composite_rank_rotation_validation.txt``
"""
from __future__ import annotations

import logging
import sys
from dataclasses import dataclass
from pathlib import Path

# Add project root to path so we can import nimbus_v3 modules
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.data.industry_db import load_industry_db
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("composite_rank_rotation")


_EQ_CACHE_DIR: Path = _ROOT / "data" / "cache" / "enriched"
_OUT_PATH: Path = _ROOT / "scripts" / "output" / "composite_rank_rotation_validation.txt"


def _prepare_equity_only() -> dict:
    """Equity-only data prep — skips VIX (not needed for rank rotation
    research). Reuses the enriched cache for speed.

    Returns: {"panel_w_fwd": {sym: df}, "industry_map": {sym: ind}}
    """
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    log.info("Equity panel: %d symbols", len(raw_panel))
    if not raw_panel:
        raise RuntimeError("Equity panel empty — no cached data available")

    log.info("Enriching (cache-first)...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    hits = misses = 0
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
            hits += 1
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
                misses += 1
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched panel: %d symbols (cache: %d hits, %d misses)",
             len(enriched_panel), hits, misses)

    log.info("Attaching forward returns...")
    panel_w_fwd: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        panel_w_fwd[sym] = add_forward_returns(df)

    log.info("Loading industry DB...")
    ind_db = load_industry_db()
    industry_map: dict[str, str] = {
        sym: rec.industry for sym, rec in ind_db.items()
    }
    log.info("Industry map: %d symbols across %d industries",
             len(industry_map), len(set(industry_map.values())))

    return {"panel_w_fwd": panel_w_fwd, "industry_map": industry_map}


# ══════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════

#: Rank-change windows to test. We expect a "sweet spot" where the
#: rank change is meaningful but not so noisy / so slow that the
#: predictive value decays. Test 5d / 10d / 20d.
_WINDOWS: tuple[int, ...] = (5, 10, 20)

#: Asymmetric bands. The middle band is intentionally wider
#: ("flat") because rank changes of ±1-2 places are noise on a
#: 50-industry universe. Edge bands are narrow to capture the
#: meaningful tail.
@dataclass(frozen=True)
class Band:
    name: str
    lo: int    # inclusive
    hi: int    # inclusive
    direction: str    # "climb" | "flat" | "fall"


_BANDS: tuple[Band, ...] = (
    Band("BIG_CLIMB",   10,  100,  "climb"),    # ≥+10
    Band("MILD_CLIMB",   3,    9,  "climb"),    # +3..+9
    Band("FLAT",        -2,    2,  "flat"),     # -2..+2
    Band("MILD_FALL",   -9,   -3,  "fall"),     # -3..-9
    Band("BIG_FALL",  -100,  -10,  "fall"),     # ≤-10
)

#: Number of expanding-window walk-forward folds. Same as VIX research.
_N_FOLDS: int = 4

#: Bars to drop at train/test boundary to prevent fwd_10d leakage.
_PURGE_BARS: int = 10

#: Minimum bars in a fold for the analysis to be meaningful.
_MIN_FOLD_BARS: int = 60

#: Minimum industries needed to form a cross-sectional ranking on a
#: given bar. Below this we can't meaningfully rank.
_MIN_INDUSTRIES_PER_BAR: int = 20

#: SHIP CRITERIA — decided up front so we don't fit them post-hoc.
_SHIP_FOLD_AGREEMENT_THRESHOLD: float = 0.75    # ≥3/4 folds
_SHIP_MIN_LIFT_PP: float = 0.5

#: Cosmetic: output divider widths.
_DIV_WIDE: str = "═" * 78
_DIV_THIN: str = "─" * 78


# ══════════════════════════════════════════════════════════════════════
# Composite computation — mirrors UI formula exactly
# ══════════════════════════════════════════════════════════════════════

def _compute_composite_series(
    close: pd.Series, volume: pd.Series,
) -> pd.Series:
    """Return composite series at each bar.

    Mirrors _compute_metrics_from_series in market_context_tab.py.
    Composite = trend + momentum * 0.5 + inflow, where:
      trend    = (above_sma20 ? +1 : -1) + (above_sma50 ? +1 : -1)
                 + clamped(sma20_slope, -3, 3) / 3
      momentum = (roc5 + roc10 + roc20) / 3
      inflow   = clamped(vol_chg_20, -50, 50) / 50

    Returns a series aligned to the input index. Values before
    bar 50 are NaN (not enough history for SMA50 / ROC 20d).
    """
    n = len(close)
    if n < 50:
        return pd.Series(np.nan, index=close.index)

    sma20 = close.rolling(20).mean()
    sma50 = close.rolling(50).mean()

    # SMA20 slope: 5-bar diff in normalized SMA20 (matches UI logic).
    sma20_slope = sma20.pct_change(5) * 100

    above_20 = (close > sma20).astype(float) * 2 - 1    # +1 / -1
    above_50 = (close > sma50).astype(float) * 2 - 1

    trend = above_20 + above_50 + sma20_slope.clip(-3, 3) / 3.0

    roc5 = close.pct_change(5) * 100
    roc10 = close.pct_change(10) * 100
    roc20 = close.pct_change(20) * 100
    momentum = (roc5 + roc10 + roc20) / 3.0

    # Volume change: last 20 vs prior 20 mean.
    vol_chg = (
        volume.rolling(20).mean()
        / volume.shift(20).rolling(20).mean()
        - 1
    ) * 100
    inflow = vol_chg.clip(-50, 50) / 50.0

    composite = trend + momentum * 0.5 + inflow
    return composite


# ══════════════════════════════════════════════════════════════════════
# Industry-level composite + ranking
# ══════════════════════════════════════════════════════════════════════

def _build_industry_composites(
    panel_w_fwd: dict[str, pd.DataFrame],
    industry_map: dict[str, str],
) -> dict[str, pd.Series]:
    """For each industry, build its EW-composite series across time.

    Returns: {industry: composite_series}. Series indexed by
    trading dates, value = composite at that bar for the EW
    aggregate of in-industry symbols.
    """
    # Group symbols by industry
    inds: dict[str, list[str]] = {}
    for sym, ind in industry_map.items():
        if sym in panel_w_fwd:
            inds.setdefault(ind, []).append(sym)

    out: dict[str, pd.Series] = {}
    for ind, members in inds.items():
        if len(members) < 3:
            continue    # too few members for a meaningful EW

        # Build EW-aggregate close + volume across members
        close_df = pd.DataFrame({
            sym: panel_w_fwd[sym]["Close"]
            for sym in members
            if "Close" in panel_w_fwd[sym].columns
        })
        vol_df = pd.DataFrame({
            sym: panel_w_fwd[sym]["Volume"]
            for sym in members
            if "Volume" in panel_w_fwd[sym].columns
        })
        if close_df.empty:
            continue

        # EW return → cumulative index
        ew_ret = close_df.pct_change().mean(axis=1)
        ew_idx = (1 + ew_ret).cumprod() * 100
        # Total industry volume (proxy)
        total_vol = (
            vol_df.sum(axis=1).reindex(ew_idx.index)
            if not vol_df.empty
            else pd.Series(1.0, index=ew_idx.index)
        )

        comp = _compute_composite_series(ew_idx, total_vol)
        out[ind] = comp

    log.info("Built composite series for %d industries", len(out))
    return out


def _rank_per_bar(
    industry_composites: dict[str, pd.Series],
) -> pd.DataFrame:
    """Cross-sectional rank per (industry, bar). 1 = highest composite.

    Returns a wide DataFrame with industries as columns, dates as
    index. Cells are ranks (1..N). NaN where the industry didn't
    have a composite that day or there were too few industries
    with composites that day for ranking.
    """
    # Wide composite frame (industries × dates)
    comp_df = pd.DataFrame(industry_composites)

    # Rank cross-sectionally per row (per bar). method='min' so
    # ties get the same rank. ascending=False so 1 = highest.
    ranks = comp_df.rank(axis=1, method="min", ascending=False)

    # Mask bars with too few non-NaN industries
    n_per_bar = comp_df.notna().sum(axis=1)
    ranks = ranks.where(n_per_bar >= _MIN_INDUSTRIES_PER_BAR, other=np.nan)

    return ranks


# ══════════════════════════════════════════════════════════════════════
# Δrank computation + banding
# ══════════════════════════════════════════════════════════════════════

def _delta_ranks(rank_df: pd.DataFrame, window: int) -> pd.DataFrame:
    """Δrank(W) = rank[t-W] - rank[t]. Positive = climbed up
    (rank number got smaller, position improved)."""
    return rank_df.shift(window) - rank_df


def _band_for(delta: float) -> str | None:
    """Return the band name a Δrank value falls into, or None if NaN."""
    if pd.isna(delta):
        return None
    d = int(round(delta))
    for band in _BANDS:
        if band.lo <= d <= band.hi:
            return band.name
    return None


# ══════════════════════════════════════════════════════════════════════
# Forward-return aggregation per (band, fold)
# ══════════════════════════════════════════════════════════════════════

def _aggregate_band_lift(
    panel_w_fwd: dict[str, pd.DataFrame],
    industry_map: dict[str, str],
    delta_rank: pd.DataFrame,
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
) -> tuple[dict[str, dict], float]:
    """For each band, pool member-symbol fwd_10d returns across
    industries that fall into that band on each bar in
    [date_start, date_end].

    Returns:
      band_stats: {band_name: {n_obs, mean_pp, lift_pp}}
      universe_baseline_pp: mean fwd_10d across the entire pooled
        sample in this date range (used as the lift reference)
    """
    # Reverse industry_map for fast lookup
    ind_to_syms: dict[str, list[str]] = {}
    for sym, ind in industry_map.items():
        ind_to_syms.setdefault(ind, []).append(sym)

    # Date-bound the delta_rank frame
    in_range = (delta_rank.index >= date_start) & (delta_rank.index <= date_end)
    delta_window = delta_rank.loc[in_range]

    # Collector: for each band, list of fwd_10d observations
    by_band: dict[str, list[float]] = {b.name: [] for b in _BANDS}
    all_returns: list[float] = []

    for date, row in delta_window.iterrows():
        # Each industry's Δrank on this date
        for ind, drank in row.items():
            band = _band_for(drank)
            if band is None:
                continue
            # Pull fwd_10d for every in-industry symbol on this date
            for sym in ind_to_syms.get(ind, []):
                if sym not in panel_w_fwd:
                    continue
                df = panel_w_fwd[sym]
                if "fwd_ret_10d" not in df.columns:
                    continue
                if date not in df.index:
                    continue
                fwd = df.at[date, "fwd_ret_10d"]
                if pd.isna(fwd):
                    continue
                fwd_pp = float(fwd) * 100
                by_band[band].append(fwd_pp)
                all_returns.append(fwd_pp)

    universe_baseline = (
        float(np.mean(all_returns)) if all_returns else 0.0
    )

    band_stats: dict[str, dict] = {}
    for band in _BANDS:
        obs = by_band[band.name]
        if not obs:
            band_stats[band.name] = {
                "n_obs": 0, "mean_pp": 0.0, "lift_pp": 0.0,
            }
            continue
        mean_pp = float(np.mean(obs))
        band_stats[band.name] = {
            "n_obs":   len(obs),
            "mean_pp": mean_pp,
            "lift_pp": mean_pp - universe_baseline,
        }

    return band_stats, universe_baseline


# ══════════════════════════════════════════════════════════════════════
# Walk-forward fold construction (matches VIX research)
# ══════════════════════════════════════════════════════════════════════

def _make_expanding_folds(
    dates: pd.DatetimeIndex, n_folds: int,
) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    """Return list of (train_end, test_start, test_end). Same logic
    as VIX research: total range split into (n+1) chunks, fold i
    trains on first (i+1), tests on chunk (i+2)."""
    start = dates.min()
    end = dates.max()
    total = end - start
    chunk = total / (n_folds + 1)

    folds: list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]] = []
    for i in range(n_folds):
        train_end = start + chunk * (i + 1)
        test_start = train_end + pd.Timedelta(days=_PURGE_BARS)
        test_end = start + chunk * (i + 2)
        folds.append((train_end, test_start, test_end))
    return folds


# ══════════════════════════════════════════════════════════════════════
# Per-window analysis
# ══════════════════════════════════════════════════════════════════════

def _run_window(
    window: int,
    rank_df: pd.DataFrame,
    panel_w_fwd: dict,
    industry_map: dict,
    folds: list,
    emit,
) -> dict[str, dict]:
    """Run all folds for one window. Returns the verdict structure
    used by the summary.

    verdict[band_name] = {
      "fold_lifts_pp":    [fold-1 test lift, fold-2, fold-3, fold-4],
      "n_test_obs":        [n in each test fold],
      "sign_agree":        bool — sign agrees in ≥75% of folds with
                                  abs(lift) ≥ MIN_LIFT_PP
      "mean_test_lift_pp": float
      "ship":              bool — sign_agree AND |mean_test_lift| ≥ MIN
    }
    """
    delta_rank = _delta_ranks(rank_df, window)

    emit(_DIV_WIDE)
    emit(f"WINDOW = {window}d Δrank")
    emit(_DIV_WIDE)
    emit(f"Bands (Δrank ranges): {', '.join(b.name + f' [{b.lo}..{b.hi}]' for b in _BANDS)}")
    emit("")

    # Run each fold
    fold_results: list[dict[str, dict]] = []
    for fi, (train_end, test_start, test_end) in enumerate(folds):
        # Train half: all data up to train_end
        train_start = rank_df.index.min()
        train_stats, train_baseline = _aggregate_band_lift(
            panel_w_fwd, industry_map, delta_rank,
            train_start, train_end,
        )
        # Test half: test_start to test_end
        test_stats, test_baseline = _aggregate_band_lift(
            panel_w_fwd, industry_map, delta_rank,
            test_start, test_end,
        )
        fold_results.append({
            "train_stats":    train_stats,
            "train_baseline": train_baseline,
            "test_stats":     test_stats,
            "test_baseline":  test_baseline,
        })

        emit(f"FOLD {fi + 1}: train → {train_end.date()} | "
             f"test {test_start.date()} → {test_end.date()}")
        emit(f"  Train baseline: {train_baseline:+.2f}pp  |  "
             f"Test baseline: {test_baseline:+.2f}pp")
        emit(f"  {'BAND':<14} {'TRAIN_LIFT':>11} {'TRAIN_N':>9} "
             f"{'TEST_LIFT':>11} {'TEST_N':>9}  SIGN")
        for band in _BANDS:
            tr = train_stats[band.name]
            te = test_stats[band.name]
            sign = "—"
            if tr["n_obs"] and te["n_obs"]:
                if (tr["lift_pp"] >= 0) == (te["lift_pp"] >= 0):
                    sign = "✓"
                else:
                    sign = "✗"
            emit(f"  {band.name:<14} "
                 f"{tr['lift_pp']:>+10.2f}pp {tr['n_obs']:>9d} "
                 f"{te['lift_pp']:>+10.2f}pp {te['n_obs']:>9d}  {sign}")
        emit("")

    # Aggregate across folds → ship verdict per band
    verdict: dict[str, dict] = {}
    for band in _BANDS:
        fold_test_lifts = [
            f["test_stats"][band.name]["lift_pp"] for f in fold_results
        ]
        fold_test_n = [
            f["test_stats"][band.name]["n_obs"] for f in fold_results
        ]
        # Only count folds with non-trivial n
        valid = [
            (lift, n) for lift, n in zip(fold_test_lifts, fold_test_n)
            if n >= 50
        ]
        if not valid:
            verdict[band.name] = {
                "fold_lifts_pp":    fold_test_lifts,
                "n_test_obs":       fold_test_n,
                "sign_agree":       False,
                "mean_test_lift_pp": 0.0,
                "ship":             False,
                "ship_reason":      "no folds with n ≥ 50 test obs",
            }
            continue
        lifts_only = [v[0] for v in valid]
        mean_lift = float(np.mean(lifts_only))
        # Sign agreement: how many folds match the sign of the mean?
        same_sign = sum(
            1 for li in lifts_only
            if (li >= 0) == (mean_lift >= 0)
        )
        agreement = same_sign / len(lifts_only)
        sign_agree = agreement >= _SHIP_FOLD_AGREEMENT_THRESHOLD
        big_enough = abs(mean_lift) >= _SHIP_MIN_LIFT_PP
        ship = sign_agree and big_enough
        verdict[band.name] = {
            "fold_lifts_pp":     fold_test_lifts,
            "n_test_obs":        fold_test_n,
            "agreement":         agreement,
            "sign_agree":        sign_agree,
            "mean_test_lift_pp": mean_lift,
            "ship":              ship,
            "ship_reason": (
                "" if ship else
                f"agreement {agreement:.0%}, lift {mean_lift:+.2f}pp"
            ),
        }

    # Per-window summary table
    emit(f"WINDOW {window}d SUMMARY")
    emit(_DIV_THIN)
    emit(f"  {'BAND':<14} {'AGREE':>6} {'MEAN_LIFT':>12} {'SHIP':>6}  {'NOTE'}")
    for band in _BANDS:
        v = verdict[band.name]
        agreement_pct = (
            f"{v.get('agreement', 0) * 100:.0f}%" if "agreement" in v else "—"
        )
        ship_str = "YES" if v["ship"] else "—"
        emit(f"  {band.name:<14} {agreement_pct:>6} "
             f"{v['mean_test_lift_pp']:>+11.2f}pp {ship_str:>6}  "
             f"{v.get('ship_reason', '')}")
    emit("")

    return verdict


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data (equity-only — skipping VIX)...")
    try:
        prepared = _prepare_equity_only()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    panel_w_fwd = prepared["panel_w_fwd"]
    industry_map = prepared["industry_map"]

    log.info("Building industry composites...")
    industry_composites = _build_industry_composites(panel_w_fwd, industry_map)

    log.info("Ranking cross-sectionally...")
    rank_df = _rank_per_bar(industry_composites)

    # Date range for folds = the bars we have ranks for
    valid_dates = rank_df.dropna(how="all").index
    folds = _make_expanding_folds(valid_dates, _N_FOLDS)

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("COMPOSITE RANK ROTATION — WALK-FORWARD VALIDATION")
        emit(_DIV_WIDE)
        emit("Hypothesis: industries climbing the cross-sectional")
        emit("composite-rank ladder over the past N days deliver")
        emit("above-baseline forward returns; falling industries")
        emit("deliver below-baseline returns.")
        emit("")
        emit(f"Validation: expanding-window walk-forward, {_N_FOLDS} folds, "
             f"purged ±{_PURGE_BARS} bars at boundary")
        emit(f"Ship rule: ≥{_SHIP_FOLD_AGREEMENT_THRESHOLD:.0%} fold sign-agreement "
             f"AND |mean test-fold lift| ≥ {_SHIP_MIN_LIFT_PP}pp")
        emit("")
        emit(f"Industries with composites: {len(industry_composites)}")
        emit(f"Bars with valid rankings: {len(valid_dates)} "
             f"({valid_dates.min().date()} → {valid_dates.max().date()})")
        emit("")
        emit("Fold boundaries:")
        for i, (train_end, test_start, test_end) in enumerate(folds):
            emit(f"  Fold {i + 1}: train → {train_end.date()}, "
                 f"test {test_start.date()} → {test_end.date()}")
        emit("")

        all_verdicts: dict[int, dict] = {}
        for win in _WINDOWS:
            verdict = _run_window(
                win, rank_df, panel_w_fwd, industry_map, folds, emit,
            )
            all_verdicts[win] = verdict

        # ── FINAL SUMMARY ──────────────────────────────────────────
        emit(_DIV_WIDE)
        emit("FINAL SUMMARY — SHIP/NO-SHIP MATRIX")
        emit(_DIV_WIDE)
        emit(f"  {'WINDOW':<8} | {'BAND':<14} | "
             f"{'AGREE':>6} | {'LIFT':>8} | SHIP")
        emit(_DIV_THIN)
        any_ship = False
        for win in _WINDOWS:
            for band in _BANDS:
                v = all_verdicts[win][band.name]
                ship_str = "YES" if v["ship"] else "—"
                if v["ship"]:
                    any_ship = True
                agreement_pct = (
                    f"{v.get('agreement', 0) * 100:.0f}%"
                    if "agreement" in v else "—"
                )
                emit(f"  {win:>3}d     | {band.name:<14} | "
                     f"{agreement_pct:>6} | "
                     f"{v['mean_test_lift_pp']:>+7.2f}pp | {ship_str}")
        emit("")

        emit(_DIV_WIDE)
        if any_ship:
            emit("VERDICT: SHIP candidate cells exist (see SHIP=YES rows)")
            emit("Recommendation: surface as a 'Rank Δ' column in Market")
            emit("Pulse, color-coded by band. Validated bands carry signal;")
            emit("non-validated bands display the value but with neutral")
            emit("styling (no positive/negative implication).")
        else:
            emit("VERDICT: DO NOT SHIP")
            emit("No (window, band) cell cleared the ship criteria")
            emit(f"  (≥{_SHIP_FOLD_AGREEMENT_THRESHOLD:.0%} sign agreement AND "
                 f"|lift| ≥ {_SHIP_MIN_LIFT_PP}pp).")
            emit("")
            emit("Composite-rank rotation may correlate with returns")
            emit("but the signal is too noisy / unstable across time")
            emit("periods to ship as a validated indicator.")
        emit(_DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
