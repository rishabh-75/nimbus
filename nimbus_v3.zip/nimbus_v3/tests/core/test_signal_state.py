"""Tests for nimbus_v3.core.signal_state.SignalState."""
from __future__ import annotations

import dataclasses

import pandas as pd
import pytest

from nimbus_v3.core.signal_state import SignalState


def _minimal_kwargs() -> dict:
    """A valid fully-populated argument set for SignalState construction."""
    return {
        "symbol": "RELIANCE",
        "bar_date": pd.Timestamp("2024-01-15"),
        "bar_index": 250,
        "open": 2450.0,
        "high": 2475.0,
        "low": 2440.0,
        "close": 2470.0,
        "volume": 1_200_000.0,
        "sma_10": 2460.0,
        "sma_20": 2440.0,
        "sma_50": 2400.0,
        "sma_200": 2350.0,
        "wr_14": -25.0,
        "wr_20": -30.0,
        "wr_30": -20.0,
        "wr_50": -15.0,
        "rsi_14": 58.0,
        "mfi_14": 62.0,
        "mfi_slope_3": 2.0,
        "adx_14": 22.0,
        "atr_14": 35.0,
        "atr_14_pct": 1.4,
        "bb_20_1s_upper": 2480.0,
        "bb_20_1s_mid": 2440.0,
        "bb_20_1s_lower": 2400.0,
        "bb_20_1s_pct": 0.875,
        "bb_20_2s_upper": 2520.0,
        "bb_20_2s_lower": 2360.0,
        "bbw_20_2s": 6.56,
        "bbw_20_2s_slope": -0.1,
        "bbw_20_2s_pctl": 35.0,
        "pct_from_sma_20": 1.23,
        "pct_from_sma_50": 2.92,
        "pct_from_sma_200": 5.11,
        "above_sma_20": True,
        "above_sma_50": True,
        "above_sma_200": True,
        "dd_from_high_20": -0.5,
        "dd_from_high_50": -1.2,
        "red_streak": 0,
        "green_streak": 2,
        "vol_ratio_20": 1.15,
        "roc_5": 1.2,
        "roc_10": 3.5,
        "roc_20": 5.8,
        "data_sufficient": True,
    }


def test_construction_with_full_kwargs() -> None:
    state = SignalState(**_minimal_kwargs())
    assert state.symbol == "RELIANCE"
    assert state.close == 2470.0
    assert state.data_sufficient is True


def test_is_frozen() -> None:
    """SignalState is a frozen dataclass; any mutation attempt must raise."""
    state = SignalState(**_minimal_kwargs())
    with pytest.raises(dataclasses.FrozenInstanceError):
        state.close = 9999.0  # type: ignore[misc]


def test_is_hashable() -> None:
    """Frozen + all-immutable-fields ⇒ hashable. Must be usable as a dict key."""
    state_a = SignalState(**_minimal_kwargs())
    state_b = SignalState(**_minimal_kwargs())
    # Two states with identical data hash equally and compare equal.
    assert hash(state_a) == hash(state_b)
    assert state_a == state_b
    d = {state_a: "first"}
    assert d[state_b] == "first"


def test_bar_date_is_timestamp() -> None:
    state = SignalState(**_minimal_kwargs())
    assert isinstance(state.bar_date, pd.Timestamp)


def test_field_count_matches_architecture() -> None:
    """Pin the SignalState field count so accidental drift shows up in CI
    rather than silently.

    v3's SignalState has 46 fields: v2's inventory plus ``dd_from_high_20``
    (v2 had only the 50-bar variant). Adjust this count deliberately when
    the architecture evolves, and update docs/ARCHITECTURE.md alongside.
    """
    expected_count = 46
    actual_count = len(dataclasses.fields(SignalState))
    assert actual_count == expected_count, (
        f"SignalState has {actual_count} fields; expected {expected_count}. "
        f"If intentional, update this test and docs/ARCHITECTURE.md."
    )


def test_all_fields_have_type_hints() -> None:
    """Every field must carry a type annotation. Untyped fields are a
    regression."""
    for field in dataclasses.fields(SignalState):
        assert field.type is not None, f"field {field.name!r} lacks a type hint"
