"""Smoke tests for run_vix_corr_joint_regime_validation.py.

Tests:
  - _vix_regime_series math
  - End-to-end _aggregate_joint_lift label routing — catches the
    kind of label-mismatch bug that snuck through the first run
    (production module uses "HIGH"/"NORMAL"/"LOW", research
    script uses "HIGH_CORR"/"NORMAL"/"LOW_CORR" — the two sets
    must NOT be confused).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from scripts.run_vix_corr_joint_regime_validation import (    # noqa: E402
    _aggregate_joint_lift,
    _CORR_HIGH_LABEL,
    _CORR_LOW_LABEL,
    _CORR_NORMAL_LABEL,
    _vix_regime_series,
    _VIX_REGIMES,
    _CORR_REGIMES,
)
from nimbus_v3.compute.vix_pace import (
    REGIME_FALLING as VIX_FALLING,
    REGIME_RISING as VIX_RISING,
    REGIME_STABLE as VIX_STABLE,
)


class TestVixRegimeSeries:

    def _vix_with_pattern(self, pattern_func, n_bars: int = 400):
        """Build a VIX series via pattern_func(t) -> level."""
        idx = pd.bdate_range("2020-01-01", periods=n_bars)
        values = [pattern_func(t) for t in range(n_bars)]
        return pd.Series(values, index=idx)

    def test_steady_vix_classifies_stable_at_end(self):
        """VIX hovering around 16 — slope ≈ 0, z ≈ 0, STABLE."""
        rng = np.random.default_rng(1)
        idx = pd.bdate_range("2020-01-01", periods=400)
        # Mean-reverting around 16 with tiny noise
        vix = pd.Series(
            16 + rng.normal(0, 0.3, 400), index=idx,
        )
        regimes = _vix_regime_series(vix)
        # Last bar should classify (post-warmup)
        assert regimes.iloc[-1] == "STABLE"

    def test_rapidly_rising_vix_classifies_rising(self):
        """VIX climbing fast — slope >> baseline, z > +1."""
        idx = pd.bdate_range("2020-01-01", periods=400)
        # Steady around 14 for 350 bars, then ramp up to 28 over 50 bars
        vix = np.concatenate([
            np.full(350, 14.0) + np.random.default_rng(1).normal(0, 0.2, 350),
            np.linspace(14.0, 28.0, 50),
        ])
        vix = pd.Series(vix, index=idx)
        regimes = _vix_regime_series(vix)
        # Last bar should be RISING (slope is highly elevated vs baseline)
        assert regimes.iloc[-1] == "RISING"

    def test_warmup_period_returns_unknown_or_na(self):
        """First 252 bars don't have full Z baseline — should be
        NA or UNKNOWN."""
        idx = pd.bdate_range("2020-01-01", periods=400)
        vix = pd.Series(np.full(400, 16.0), index=idx)
        regimes = _vix_regime_series(vix)
        # Bar 100 is well within warmup
        assert pd.isna(regimes.iloc[100]) or regimes.iloc[100] == "UNKNOWN"


# ══════════════════════════════════════════════════════════════════════
# Label-mismatch regression: ensure joint aggregation routes
# observations correctly when given the actual labels the research
# script's _classify_regimes function produces.
# ══════════════════════════════════════════════════════════════════════

class TestAggregateJointLiftLabelRouting:

    def _setup(self):
        """Build a tiny synthetic panel + regime series with KNOWN
        joint-cell membership so we can verify routing."""
        idx = pd.bdate_range("2024-01-01", periods=20)

        # 4 symbols, all with positive forward returns
        panel = {}
        for sym in ("A", "B", "C", "D"):
            df = pd.DataFrame({
                "fwd_ret_10d": np.full(20, 0.05),    # +5pp every day
            }, index=idx)
            panel[sym] = df

        # VIX regime: 10 days RISING, 10 days STABLE
        vix_regime = pd.Series(
            [VIX_RISING] * 10 + [VIX_STABLE] * 10,
            index=idx,
        )
        # CORR regime: 5 HIGH, 5 NORMAL, 5 LOW, 5 NORMAL
        # Using the SUFFIXED labels the research script produces.
        corr_regime = pd.Series(
            [_CORR_HIGH_LABEL] * 5
            + [_CORR_NORMAL_LABEL] * 5
            + [_CORR_LOW_LABEL] * 5
            + [_CORR_NORMAL_LABEL] * 5,
            index=idx,
        )
        return panel, vix_regime, corr_regime, idx

    def test_high_corr_observations_route_to_high_cell(self):
        """With suffixed CORR labels, HIGH_CORR bars must populate
        the (VIX, HIGH_CORR) joint cell — not get filtered out as
        non-matching."""
        panel, vix_regime, corr_regime, idx = self._setup()
        joint_stats, _, vix_marg, corr_marg = _aggregate_joint_lift(
            panel, vix_regime, corr_regime, idx[0], idx[-1],
        )
        # 5 HIGH_CORR bars × 4 symbols = 20 observations expected
        # for CORR HIGH marginal
        assert corr_marg[_CORR_HIGH_LABEL]["n_obs"] == 20, (
            f"Expected 20 HIGH_CORR observations, got "
            f"{corr_marg[_CORR_HIGH_LABEL]['n_obs']}. This means "
            f"the CORR labels aren't being matched."
        )
        # All 5 HIGH_CORR bars happen during RISING vix → joint
        # cell (RISING, HIGH_CORR) gets 20 observations
        assert joint_stats[(VIX_RISING, _CORR_HIGH_LABEL)]["n_obs"] == 20

    def test_low_corr_observations_route_to_low_cell(self):
        panel, vix_regime, corr_regime, idx = self._setup()
        joint_stats, _, _, corr_marg = _aggregate_joint_lift(
            panel, vix_regime, corr_regime, idx[0], idx[-1],
        )
        # 5 LOW_CORR bars × 4 symbols = 20 obs
        assert corr_marg[_CORR_LOW_LABEL]["n_obs"] == 20

    def test_all_three_corr_regimes_have_observations(self):
        """The smoking-gun assertion: if HIGH_CORR or LOW_CORR has
        zero observations across all valid bars, the labels are
        being mis-matched."""
        panel, vix_regime, corr_regime, idx = self._setup()
        _, _, _, corr_marg = _aggregate_joint_lift(
            panel, vix_regime, corr_regime, idx[0], idx[-1],
        )
        for regime in _CORR_REGIMES:
            assert corr_marg[regime]["n_obs"] > 0, (
                f"{regime} has zero observations — label mismatch "
                f"bug regressed. Marginal counts: "
                f"{[(r, corr_marg[r]['n_obs']) for r in _CORR_REGIMES]}"
            )
