"""nimbus_v3.research.etf_universe — curated Indian ETF universe.

Used by the ETF validation script. List is intentionally conservative:
liquid ETFs only, mostly broad-market and sector-themed, with at least
3 years of trading history as of mid-2024.

If you're running the validation, you may want to extend this list with
your own holdings or watchlist. Just append symbols (without the ``.NS``
suffix — the loader appends it).
"""
from __future__ import annotations

from typing import Final


#: Broad-market ETFs (NIFTY 50, NEXT 50, Midcap, Smallcap, etc.)
BROAD_MARKET_ETFS: Final[tuple[str, ...]] = (
    "NIFTYBEES",       # Nippon NIFTY 50
    "JUNIORBEES",      # Nippon NIFTY Next 50
    "MID150BEES",      # Nippon NIFTY Midcap 150
    "SMALLCAP",        # Mirae NIFTY Smallcap 250 (verify ticker on your end)
    "MOM100",          # Motilal Oswal NIFTY Midcap 100 (verify)
    "ITBEES",          # Nippon NIFTY IT
    "BANKBEES",        # Nippon NIFTY Bank
    "PSUBNKBEES",      # Nippon NIFTY PSU Bank
)

#: Sector-themed ETFs.
SECTOR_ETFS: Final[tuple[str, ...]] = (
    "PHARMABEES",      # Nippon NIFTY Pharma  ⚠ this is the one v2 had 404s on
    "AUTOBEES",        # Nippon NIFTY Auto (verify)
    "FMCGBEES",        # Nippon NIFTY FMCG (verify)
    "CONSUMBEES",      # Nippon NIFTY Consumer Durables (verify)
    "INFRABEES",       # Nippon NIFTY Infrastructure (verify)
)

#: Commodity / international ETFs.
COMMODITY_ETFS: Final[tuple[str, ...]] = (
    "GOLDBEES",        # Nippon Gold ETF
    "SILVERBEES",      # Nippon Silver ETF (verify)
    "MAFANG",          # Mirae Asset NYSE FANG+ (verify)
)

#: Smart-beta / strategic ETFs.
SMART_BETA_ETFS: Final[tuple[str, ...]] = (
    "MOMENTUM",        # NIFTY 200 Momentum 30 ETF (verify ticker)
    "QUALITY30",       # NIFTY 200 Quality 30 ETF (verify ticker)
    "ALPHA",           # NIFTY 100 Alpha 30 ETF (verify ticker)
)


def all_etfs() -> tuple[str, ...]:
    """Return the full ETF universe across all categories."""
    return (
        BROAD_MARKET_ETFS
        + SECTOR_ETFS
        + COMMODITY_ETFS
        + SMART_BETA_ETFS
    )
