"""Tests for nimbus_v3.data.watchlist."""
from __future__ import annotations

import os

import pytest

from nimbus_v3.data.watchlist import Watchlist, load_watchlist, save_watchlist


@pytest.fixture(autouse=True)
def _isolated_state(tmp_path, monkeypatch):
    """Point NIMBUS_DATA_DIR at a temp dir so each test is isolated."""
    monkeypatch.setenv("NIMBUS_DATA_DIR", str(tmp_path))
    yield


def test_empty_when_no_file():
    assert load_watchlist() == []
    assert Watchlist().symbols() == []


def test_add_persists_and_reloads():
    w = Watchlist()
    assert w.add("CIPLA") is True
    assert w.add("TCS") is True
    assert Watchlist().symbols() == ["CIPLA", "TCS"]


def test_add_dedup_case_insensitive():
    w = Watchlist()
    assert w.add("CIPLA") is True
    assert w.add("cipla") is False
    assert w.symbols() == ["CIPLA"]


def test_remove_persists():
    w = Watchlist()
    w.add("CIPLA")
    w.add("TCS")
    assert w.remove("CIPLA") is True
    assert w.remove("CIPLA") is False
    assert Watchlist().symbols() == ["TCS"]


def test_order_preserved():
    w = Watchlist()
    for s in ["B", "A", "C"]:
        w.add(s)
    assert w.symbols() == ["B", "A", "C"]


def test_contains():
    w = Watchlist()
    w.add("CIPLA")
    assert "CIPLA" in w
    assert "cipla" in w
    assert "TCS" not in w


def test_save_load_roundtrip():
    save_watchlist(["X", "Y", "Z"])
    assert load_watchlist() == ["X", "Y", "Z"]
