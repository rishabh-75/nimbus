"""scripts._composition — shared wiring for scan.py and run_ui.py.

Pulls the composition-root plumbing (universe, providers, strategy
registry, market-context construction) out of the individual entry
scripts so both can reuse it. As more ContextProviders come online
(Phase 8), they register here in one place.

No argparse / CLI logic lives here — that stays in the entry scripts.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import timedelta
from pathlib import Path

import pandas as pd

from nimbus_v3.context.filing_context import FilingContextProvider
from nimbus_v3.context.market_context import MarketContextProvider
from nimbus_v3.context.options_context import OptionsContextProvider
from nimbus_v3.context.sector_context import SectorContextProvider
from nimbus_v3.core.context import MarketContext
from nimbus_v3.core.types import VIXRegime
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.filings_loader import FilingsLoader
from nimbus_v3.data.nse_client import get_shared_client
from nimbus_v3.data.options_loader import OptionsLoader
from nimbus_v3.data.price_loader import PriceLoader
from nimbus_v3.data.universe import UniverseBuildError, UniverseBuilder
from nimbus_v3.data.vix_loader import VIXLoader
from nimbus_v3.research.harness import build_vix_proxy, compute_vix_streaks
from nimbus_v3.scanner.engine import ContextProviders


logger = logging.getLogger(__name__)


def _cache_path(*subdirs: str) -> Path:
    """Resolve a cache subdirectory under the active data root.

    Indirected through :func:`nimbus_v3.data.paths.cache_dir` so the
    location tracks the ``NIMBUS_DATA_DIR`` env override. Wrapping
    here keeps the call sites in this module compact.
    """
    from nimbus_v3.data.paths import cache_dir as _cache_dir
    return _cache_dir(*subdirs)


# ── Cache locations ─────────────────────────────────────────────────
# Each accessor resolves at call time so a late-set ``NIMBUS_DATA_DIR``
# (e.g. set in main.py before composition runs) takes effect.

def VIX_CACHE_DIR() -> Path:        return _cache_path("vix")
def INDEX_CACHE_DIR() -> Path:      return _cache_path("index_price")
def FILINGS_CACHE_DIR() -> Path:    return _cache_path("filings")
def OPTIONS_CACHE_DIR() -> Path:    return _cache_path("options_chain")
def COMMODITY_CACHE_DIR() -> Path:  return _cache_path("commodity_price")
def UNIVERSE_CACHE_PATH() -> Path:  return _cache_path("universe", "symbol_sectors.json")

UNIVERSE_CACHE_TTL = timedelta(hours=24)


# ══════════════════════════════════════════════════════════════════════════════
# Proxy fallback provider
# ══════════════════════════════════════════════════════════════════════════════

class ProxyMarketProvider:
    """Fallback MarketContextProvider using the cross-sectional VIX proxy.

    Used when the real VIXLoader returns no usable value. The proxy is
    built from the same equity panel the scanner consumes.
    """

    def __init__(self, vix_df: pd.DataFrame, streak: pd.Series) -> None:
        self._vix_df = vix_df
        self._streak = streak

    def build(self, *, symbol, asof_date):    # noqa: ARG002
        idx = self._vix_df.index
        if idx.tz is not None:
            idx = idx.tz_localize(None)
        mask = idx <= asof_date
        if not mask.any():
            return MarketContext(
                asof_date=pd.Timestamp(asof_date), vix_value=None,
                vix_regime=VIXRegime.NORMAL, vix_high_streak=0,
            )
        last = int(mask.sum()) - 1
        vix_value = float(self._vix_df["Close"].iloc[last])
        streak = int(self._streak.iloc[last]) if last < len(self._streak) else 0
        regime = (
            VIXRegime.HIGH if vix_value >= 19.39
            else VIXRegime.ELEVATED if vix_value >= 16.0
            else VIXRegime.NORMAL
        )
        return MarketContext(
            asof_date=pd.Timestamp(asof_date), vix_value=vix_value,
            vix_regime=regime, vix_high_streak=streak,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Chained provider — real VIX with proxy fallback
# ══════════════════════════════════════════════════════════════════════════════

class ChainedMarketProvider:
    """Tries ``primary`` first; on exception or unusable output, falls back
    to ``fallback``. Logs which tier served each call.

    "Unusable" means a ``MarketContext`` whose ``vix_regime is None`` —
    the downstream formula cannot grade without a regime, so we prefer
    the proxy's best-effort regime over a missing one.
    """

    def __init__(
        self,
        primary,    # ContextProvider[MarketContext]
        fallback,   # ContextProvider[MarketContext]
    ) -> None:
        self._primary = primary
        self._fallback = fallback
        #: Public observability — how many times each tier served.
        self.primary_hits = 0
        self.fallback_hits = 0

    def build(self, *, symbol, asof_date):
        try:
            ctx = self._primary.build(symbol=symbol, asof_date=asof_date)
            if ctx is not None and ctx.vix_regime is not None:
                self.primary_hits += 1
                return ctx
            logger.info(
                "ChainedMarketProvider: primary returned unusable context "
                "(regime=None) at %s; falling back.", asof_date,
            )
        except Exception:     # noqa: BLE001
            logger.exception(
                "ChainedMarketProvider: primary raised at %s; falling back.",
                asof_date,
            )
        self.fallback_hits += 1
        return self._fallback.build(symbol=symbol, asof_date=asof_date)


# ══════════════════════════════════════════════════════════════════════════════
# Public: build the live market provider
# ══════════════════════════════════════════════════════════════════════════════

def build_market_provider(
    enriched_panel: dict[str, pd.DataFrame],
    *,
    use_live_vix: bool = True,
) -> ChainedMarketProvider | ProxyMarketProvider:
    """Construct the market-context provider for a scan session.

    When ``use_live_vix`` is True (default), returns a
    ``ChainedMarketProvider`` that tries the real VIXLoader first and
    falls back to a synthetic proxy derived from the panel. When
    False, returns the proxy directly — useful for offline testing
    and deterministic replays.
    """
    # Always build the proxy — it's cheap, and it becomes the fallback.
    vix_df = build_vix_proxy(enriched_panel, smoothing=5)
    high_threshold = (
        float(vix_df["Close"].quantile(0.65)) if not vix_df.empty else 20.0
    )
    streak = (
        compute_vix_streaks(vix_df, high_threshold=high_threshold)
        if not vix_df.empty else pd.Series(dtype=int)
    )
    proxy = ProxyMarketProvider(vix_df, streak)

    if not use_live_vix:
        return proxy

    # Build the real provider.
    try:
        nse = get_shared_client()
        cache = ParquetCache(base_dir=VIX_CACHE_DIR())
        vix_loader = VIXLoader(nse, cache)
        real = MarketContextProvider(vix_loader)
    except Exception as exc:     # noqa: BLE001
        logger.warning(
            "Could not construct live VIXLoader (%s); using proxy only.", exc,
        )
        return proxy

    return ChainedMarketProvider(primary=real, fallback=proxy)


def universe_from_panel(panel: dict[str, pd.DataFrame]) -> Universe:
    """Build a minimal Universe from the loaded symbols.

    Every symbol's sector is tagged ``"Unknown"`` — this is the
    fallback used when neither the NSE universe builder nor its cache
    is available. Sector contributions in the grade formula degrade
    to 0 for every symbol in this mode.
    """
    return Universe(
        symbols={
            sym: SymbolMeta(symbol=sym, sector="Unknown") for sym in panel
        },
        built_at=pd.Timestamp.now().normalize(),
    )


# ══════════════════════════════════════════════════════════════════════════════
# Cached universe with sectors
# ══════════════════════════════════════════════════════════════════════════════

def _load_cached_sectors(cache_path: Path) -> dict[str, dict] | None:
    """Read the cached symbol → (sector, industry) map if fresh.

    Returns ``None`` on cache miss or when the file is older than
    ``UNIVERSE_CACHE_TTL``.
    """
    if not cache_path.exists():
        return None
    age = time.time() - cache_path.stat().st_mtime
    if age > UNIVERSE_CACHE_TTL.total_seconds():
        logger.info(
            "Universe cache stale (age %.1fh, ttl %.1fh); refetching.",
            age / 3600.0, UNIVERSE_CACHE_TTL.total_seconds() / 3600.0,
        )
        return None
    try:
        with cache_path.open() as f:
            payload = json.load(f)
        if not isinstance(payload, dict) or "sectors" not in payload:
            return None
        return payload["sectors"]
    except Exception:     # noqa: BLE001
        logger.exception("Failed to read universe cache %s", cache_path)
        return None


def _save_sectors_cache(
    cache_path: Path, sectors: dict[str, dict],
) -> None:
    """Persist symbol → (sector, industry) to disk."""
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 1, "sectors": sectors}
    tmp = cache_path.with_suffix(cache_path.suffix + ".tmp")
    with tmp.open("w") as f:
        json.dump(payload, f, indent=2)
    tmp.replace(cache_path)


def _sectors_from_universe(uni: Universe) -> dict[str, dict]:
    """Extract the symbol → sector/industry map from a Universe."""
    return {
        sym: {"sector": meta.sector, "industry": meta.industry}
        for sym, meta in uni.symbols.items()
    }


def build_universe_with_sectors(
    panel: dict[str, pd.DataFrame],
    *,
    use_live_nse: bool = True,
    cache_path: Path | None = None,
) -> Universe:
    """Build a Universe annotated with real sector labels.

    Lookup order:
      1. On-disk cache (24h TTL).
      2. NSE ``UniverseBuilder`` (when ``use_live_nse=True``).
      3. Fallback: every symbol tagged ``sector="Unknown"``.

    Only symbols that appear in ``panel`` are included in the returned
    Universe — this keeps the scanner's symbol-lookup gate honest.

    Args:
        cache_path: Where the symbol→sector map is cached. ``None``
            (default) → resolves under ``NIMBUS_DATA_DIR``.
    """
    if cache_path is None:
        cache_path = UNIVERSE_CACHE_PATH()
    sectors_map: dict[str, dict] | None = None

    cached = _load_cached_sectors(cache_path)
    if cached is not None:
        logger.info("Universe cache hit (%d symbols)", len(cached))
        sectors_map = cached

    if sectors_map is None and use_live_nse:
        try:
            nse = get_shared_client()
            builder = UniverseBuilder(nse)
            uni = builder.build()
            sectors_map = _sectors_from_universe(uni)
            _save_sectors_cache(cache_path, sectors_map)
            logger.info(
                "Universe rebuilt from NSE (%d symbols) and cached.",
                len(sectors_map),
            )
        except UniverseBuildError as exc:
            logger.warning(
                "UniverseBuilder failed (%s); falling back to Unknown sectors.",
                exc,
            )
        except Exception:     # noqa: BLE001
            logger.exception(
                "UniverseBuilder raised unexpectedly; falling back to Unknown sectors."
            )

    # ── Industry DB (four-level NSE classification) ────────────────────
    # Load once; used to populate SymbolMeta with macro/sector/industry/
    # basicIndustry from the DB built by scripts/build_industry_db.py.
    from nimbus_v3.data.industry_db import load_industry_db
    industry_db = load_industry_db()

    symbols: dict[str, SymbolMeta] = {}
    for sym in panel:
        info = (sectors_map or {}).get(sym, {})
        ic = industry_db.get(sym.upper())
        symbols[sym] = SymbolMeta(
            symbol=sym,
            macro_sector=ic.macro_sector if ic else "Unknown",
            sector=ic.sector if ic else info.get("sector", "Unknown"),
            industry=ic.industry if ic else info.get("industry", "Unknown"),
            basic_industry=ic.basic_industry if ic else "Unknown",
        )
    return Universe(symbols=symbols, built_at=pd.Timestamp.now().normalize())


# ══════════════════════════════════════════════════════════════════════════════
# Sector context provider
# ══════════════════════════════════════════════════════════════════════════════

def build_sector_provider(
    universe: Universe,
    *,
    cache_dir: Path | None = None,
) -> SectorContextProvider | None:
    """Construct a ``SectorContextProvider`` backed by a PriceLoader
    configured for index tickers.

    Always builds the provider — even with an empty universe — because
    the index path (NIFTY / BANKNIFTY / FINNIFTY) works without any
    known sectors. When the universe is populated, the equity path
    lights up as well. Only returns ``None`` when the PriceLoader
    itself can't be constructed (I/O failure, bad cache config).

    Args:
        cache_dir: Index-price parquet cache. ``None`` (default) →
            resolves under ``NIMBUS_DATA_DIR``.
    """
    if cache_dir is None:
        cache_dir = INDEX_CACHE_DIR()
    known = sum(
        1 for m in universe.symbols.values() if m.sector != "Unknown"
    )
    if known == 0:
        logger.info(
            "build_sector_provider: no known sectors in universe; "
            "index path (NIFTY / BANKNIFTY) will still work."
        )

    try:
        index_loader = PriceLoader(
            cache=ParquetCache(base_dir=cache_dir),
            yfinance_suffix="",   # index tickers like ^NSEBANK pass through
        )
    except Exception:     # noqa: BLE001
        logger.exception("Failed to construct index PriceLoader; skipping sector provider.")
        return None

    return SectorContextProvider(
        index_price_loader=index_loader, universe=universe,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Filing context provider
# ══════════════════════════════════════════════════════════════════════════════

def build_filing_provider(
    *,
    cache_dir: Path | None = None,
    lookback_days: int = 7,
) -> FilingContextProvider | None:
    """Construct a ``FilingContextProvider`` backed by an NSEClient
    and a per-symbol parquet cache.

    Returns ``None`` when the NSE client can't be constructed (no
    network, bad config). The scanner's missing-context handling
    ensures filing contributions degrade to 0 cleanly.

    The classifier is the default; Phase-7 research can swap the
    ``FilingClassifierConfig`` if the patterns need tuning.

    Args:
        cache_dir: Filings parquet cache. ``None`` (default) →
            resolves under ``NIMBUS_DATA_DIR``.
    """
    if cache_dir is None:
        cache_dir = FILINGS_CACHE_DIR()
    try:
        nse = get_shared_client()
        cache = ParquetCache(base_dir=cache_dir)
        loader = FilingsLoader(nse, cache)
    except Exception:     # noqa: BLE001
        logger.exception(
            "Failed to construct FilingsLoader; skipping filing provider."
        )
        return None

    return FilingContextProvider(
        filings_loader=loader, lookback_days=lookback_days,
    )


def build_options_provider(
    *,
    cache_dir: Path | None = None,
) -> OptionsContextProvider | None:
    """Construct an ``OptionsContextProvider`` backed by an NSEClient
    and a per-symbol parquet cache.

    Returns ``None`` when the NSE client / loader can't be constructed
    (no network, bad config). The scanner's missing-context handling
    ensures options-derived conviction contributions degrade to 0
    cleanly when the slot is None.

    Cache TTL (30 minutes) is governed by ``OptionsLoader``'s default.
    Heavy intraday consumers can construct their own loader with a
    shorter TTL and pass the resulting provider in directly.

    Args:
        cache_dir: Options parquet cache. ``None`` (default) →
            resolves under ``NIMBUS_DATA_DIR``.
    """
    if cache_dir is None:
        cache_dir = OPTIONS_CACHE_DIR()
    logger.info("build_options_provider: starting (cache_dir=%s)", cache_dir)
    try:
        logger.info("  step 1/3: get_shared_client()")
        nse = get_shared_client()
        logger.info("  step 2/3: ParquetCache(base_dir=%s)", cache_dir)
        cache = ParquetCache(base_dir=cache_dir)
        logger.info("  step 3/3: OptionsLoader(nse, cache)")
        loader = OptionsLoader(nse, cache)
    except Exception:     # noqa: BLE001
        logger.exception(
            "build_options_provider: FAILED to construct OptionsLoader — "
            "options slot will be None; dashboard options fields will "
            "show '—' until the underlying error is resolved."
        )
        return None

    provider = OptionsContextProvider(options_loader=loader)
    logger.info("build_options_provider: OK — provider built successfully")
    return provider


def build_context_providers(
    enriched_panel: dict[str, pd.DataFrame],
    universe: Universe | None = None,
    *,
    use_live_vix: bool = True,
    use_live_sector: bool = True,
    use_live_filing: bool = True,
    use_live_options: bool = True,
) -> ContextProviders:
    """Assemble a ``ContextProviders`` bundle for the scanner.

    Args:
        enriched_panel: Dict of symbol → enriched OHLCV DataFrame.
            Used to build the synthetic VIX proxy (market fallback).
        universe: If provided and sector labels are populated, a real
            ``SectorContextProvider`` is wired in. If ``None`` (legacy
            callers), the sector slot stays ``None``.
        use_live_vix: Toggle the live VIXLoader (default True).
        use_live_sector: Toggle the live SectorContextProvider
            (default True). When False, sector slot stays ``None``
            even if ``universe`` has sector labels.
        use_live_filing: Toggle the live FilingContextProvider
            (default True). When False, filing slot stays ``None``.
        use_live_options: Toggle the live OptionsContextProvider
            (default True). When False, options slot stays ``None``;
            scanner runs without options-derived conviction inputs.
    """
    market = build_market_provider(enriched_panel, use_live_vix=use_live_vix)

    sector = None
    if universe is not None and use_live_sector:
        sector = build_sector_provider(universe)

    filing = build_filing_provider() if use_live_filing else None
    options = build_options_provider() if use_live_options else None

    return ContextProviders(
        market=market, sector=sector,
        filing=filing, options=options,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Macro panel commodity loader (Phase 9a)
# ══════════════════════════════════════════════════════════════════════════════

def build_macro_panel_loader(
    *,
    cache_dir: Path | None = None,
):
    """Return a callable that loads commodity OHLCV for the macro panel.

    The loader fetches every ticker in ``COMMODITY_UNIVERSE`` via the
    same ``PriceLoader`` used for equities, but with no yfinance
    suffix (commodity tickers like ``GC=F`` are passed through
    unchanged) and a dedicated cache directory.

    Args:
        cache_dir: Commodity parquet cache. ``None`` (default) →
            resolves under ``NIMBUS_DATA_DIR``.

    Failures per-ticker are logged and the ticker is omitted from the
    returned panel — the detector handles missing instruments
    gracefully.
    """
    if cache_dir is None:
        cache_dir = COMMODITY_CACHE_DIR()

    from nimbus_v3.macro.universe import all_tickers

    try:
        loader = PriceLoader(
            cache=ParquetCache(base_dir=cache_dir),
            yfinance_suffix="",
        )
    except Exception:    # noqa: BLE001
        logger.exception(
            "build_macro_panel_loader: PriceLoader construction failed"
        )
        return None

    def load_panel() -> dict[str, pd.DataFrame]:
        panel: dict[str, pd.DataFrame] = {}
        for ticker in all_tickers():
            try:
                df = loader.load(ticker)
                if df is not None and not df.empty:
                    panel[ticker] = df
            except Exception:    # noqa: BLE001
                logger.exception(
                    "build_macro_panel_loader: load failed for %s", ticker,
                )
        return panel

    return load_panel
