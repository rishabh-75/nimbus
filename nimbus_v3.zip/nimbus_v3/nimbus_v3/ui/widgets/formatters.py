"""nimbus_v3.ui.widgets.formatters — shared presentation formatters.

Pure display helpers used by more than one widget. These belong in the
UI layer (they're about how a number reads on screen, not what it
means), but must be defined once so the Dashboard header, the
Constituents/Industries tables, and Market Pulse all speak the same
numeric language.
"""
from __future__ import annotations


def format_adtv_m(value_inr: float) -> str:
    """Format Average Daily Traded Value (₹) as straight Millions with
    a thousands separator, e.g. ``13,076 M``. ``—`` for NaN / non-positive.
    """
    if value_inr != value_inr or value_inr <= 0:    # NaN or non-positive
        return "—"
    return f"{value_inr / 1_000_000:,.0f} M"
