"""Tests for the shared industry-composite builder."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.industry_composite import build_industry_composite


def _panel(n=6, start="2025-01-01", periods=80, drift=0.001, vol=1e6):
    idx = pd.date_range(start, periods=periods, freq="B")
    panel, syms = {}, []
    for j in range(n):
        close = 100 * (1 + drift) ** np.arange(periods)
        panel[f"S{j}"] = pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(periods, vol * (j + 1))}, index=idx)
        syms.append(f"S{j}")
    return panel, syms


def test_returns_none_below_min_members():
    panel, syms = _panel(n=3)
    comp, w = build_industry_composite(
        panel=panel, members=syms, min_members=5, min_bars=5)
    assert comp is None
    assert w == []


def test_builds_100_based_index():
    panel, syms = _panel(n=6)
    comp, w = build_industry_composite(
        panel=panel, members=syms, min_members=5, min_bars=5)
    assert comp is not None
    assert abs(comp.iloc[0] - 100.0) < 1e-6    # starts at 100
    assert comp.iloc[-1] > 100.0               # drifts up
    assert len(w) == 6
    assert abs(sum(wt for _, wt in w) - 1.0) < 1e-6


def test_lookback_truncates():
    panel, syms = _panel(n=6, periods=200)
    comp, _ = build_industry_composite(
        panel=panel, members=syms, min_members=5, min_bars=5, lookback=60)
    assert comp is not None
    assert len(comp) <= 60


def test_adtv_weighting_favours_liquid_member():
    # one member rises faster AND has the largest volume → pulls composite
    idx = pd.date_range("2025-01-01", periods=80, freq="B")
    panel, syms = {}, []
    for j in range(6):
        d = 0.004 if j == 0 else 0.0005
        close = 100 * (1 + d) ** np.arange(80)
        vol = 1e8 if j == 0 else 1e6
        panel[f"S{j}"] = pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(80, vol)}, index=idx)
        syms.append(f"S{j}")
    comp, w = build_industry_composite(
        panel=panel, members=syms, min_members=5, min_bars=5)
    wd = dict(w)
    assert wd["S0"] > 0.5    # liquid member dominates the weight
