"""nimbus_v3.compute.band_ride — Bollinger-band ride geometry primitives.

Stateless. The canonical "is the candle body above the upper band"
definition and its derivatives (last-bar flag, trailing streak). These
are the band-geometry survivors of the retired phase/score system (see
docs/retired/002): the Early-Entry score, the Above/Streak table
columns, and the industry "Riding" count all depend on them, so they
live in one shared home with a single definition.

Canonical rule: a bar is "body-above" when BOTH its Open and Close
exceed the upper Bollinger band (bb_20_1s_upper). Using both (not just
Close) means a bar that opened inside the band and closed just above it
doesn't count — the whole real body must clear the band.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

_UPPER = "bb_20_1s_upper"


def body_above_band(df: pd.DataFrame) -> pd.Series:
    """Boolean Series: True where BOTH Open and Close exceed the upper BB."""
    return (df["Open"] > df[_UPPER]) & (df["Close"] > df[_UPPER])


def last_body_above(df: pd.DataFrame) -> bool:
    """True if the LAST bar's body is above the upper band.

    Phase-independent — purely the last bar's geometry. Fail-soft:
    False on empty / missing-band frames.
    """
    if df is None or df.empty or _UPPER not in df.columns:
        return False
    try:
        return bool(body_above_band(df).iloc[-1])
    except Exception:    # noqa: BLE001
        return False


def body_above_streak(df: pd.DataFrame) -> int:
    """Count of consecutive most-recent bars with the body above the
    upper band, ending at the last bar.

    Returns 0 when the last bar isn't body-above. Counts the trailing
    run only (flags ...T,F,T,T,T → streak 3). Fail-soft: 0 on empty /
    missing-band frames.
    """
    if df is None or df.empty or _UPPER not in df.columns:
        return 0
    try:
        flags = body_above_band(df).to_numpy(dtype=bool)
    except Exception:    # noqa: BLE001
        return 0
    streak = 0
    for v in reversed(flags):
        if v:
            streak += 1
        else:
            break
    return streak
