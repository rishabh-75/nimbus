"""Aggregate per-symbol-per-phase historical win rates with
Beta-binomial smoothing, under three parallel "win" definitions.

The "win" definitions
─────────────────────
1. **Relative** — fire's return > symbol's own historical mean
   for this phase. By construction this hovers near 0.50; useful
   for asking "is this fire above-typical for this symbol".
2. **Profit** — fire's return > 0%. Absolute threshold; most
   operationally meaningful single number.
3. **Meaningful** — fire's return > :data:`MEANINGFUL_RETURN_PCT`
   (1.0%). Filters out the tiny-positive returns that pad the
   profit fraction.

Each definition gets its own Beta-binomial smoothing pipeline
with a universe-rate prior. Three priors → three smoothed
estimates. Same events feed all three; the only difference is
the "did this win" check.

Smoothing
─────────
With ``n_resolved`` ≤ ~20 per (symbol, phase), raw fractions
are noisy. We apply a Beta-binomial update with prior
``Beta(α, β)`` where:
    α = prior_strength × universe_p_win
    β = prior_strength × (1 − universe_p_win)
    posterior_mean = (α + n_wins) / (α + β + n_resolved)

``prior_strength=5`` — small-N symbols pulled toward universe
rate; n=20 barely affected.
"""
from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Iterable

import pandas as pd

from .schema import (
    ACTIVE_PHASES,
    FireEvent,
    MEANINGFUL_RETURN_PCT,
    PhaseWinRateStats,
)


logger = logging.getLogger(__name__)


#: Default prior strength for the Beta-binomial update.
DEFAULT_PRIOR_STRENGTH: float = 5.0


# ══════════════════════════════════════════════════════════════════════════════
# Win definitions
# ══════════════════════════════════════════════════════════════════════════════


def _is_win_relative(ret: float, symbol_mean: float) -> bool:
    """Above the symbol's own mean for this phase."""
    return ret > symbol_mean


def _is_win_profit(ret: float, _symbol_mean: float) -> bool:
    """Strictly positive return."""
    return ret > 0.0


def _is_win_meaningful(ret: float, _symbol_mean: float) -> bool:
    """Above the meaningful-return threshold."""
    return ret > MEANINGFUL_RETURN_PCT


# ══════════════════════════════════════════════════════════════════════════════
# Universe rates — pooled across all symbols, per definition
# ══════════════════════════════════════════════════════════════════════════════


def universe_win_rates(
    events: Iterable[FireEvent],
) -> dict[str, dict[str, float]]:
    """Pool win rates across the universe under each definition.

    Returns:
        Nested ``{phase: {definition: rate}}``. Definitions are
        ``"relative"`` / ``"profit"`` / ``"meaningful"``. A phase
        with zero resolved events gets neutral 0.5 rates under
        every definition.
    """
    by_sym_phase: dict[tuple[str, str], list[FireEvent]] = {}
    for ev in events:
        if not ev.is_resolved or ev.return_pct is None:
            continue
        by_sym_phase.setdefault((ev.symbol, ev.phase), []).append(ev)

    flags_by_phase_def: dict[str, dict[str, list[bool]]] = {
        phase: {"relative": [], "profit": [], "meaningful": []}
        for phase in ACTIVE_PHASES
    }

    for (sym, phase), evs in by_sym_phase.items():
        if not evs:
            continue
        sym_mean = sum(e.return_pct for e in evs) / len(evs)
        bucket = flags_by_phase_def[phase]
        for e in evs:
            r = e.return_pct
            bucket["relative"].append(_is_win_relative(r, sym_mean))
            bucket["profit"].append(_is_win_profit(r, sym_mean))
            bucket["meaningful"].append(_is_win_meaningful(r, sym_mean))

    out: dict[str, dict[str, float]] = {}
    for phase, defs in flags_by_phase_def.items():
        out[phase] = {}
        for definition, flags in defs.items():
            out[phase][definition] = (
                sum(flags) / len(flags) if flags else 0.5
            )
    return out


# ══════════════════════════════════════════════════════════════════════════════
# Per-symbol aggregation
# ══════════════════════════════════════════════════════════════════════════════


def aggregate_per_symbol(
    events: Iterable[FireEvent],
    *,
    universe_rates: dict[str, dict[str, float]] | None = None,
    prior_strength: float = DEFAULT_PRIOR_STRENGTH,
) -> list[PhaseWinRateStats]:
    """Beta-smoothed per-symbol-per-phase stats under three win
    definitions in parallel.
    """
    events = list(events)
    if universe_rates is None:
        universe_rates = universe_win_rates(events)

    by_sym_phase: dict[tuple[str, str], list[FireEvent]] = {}
    for ev in events:
        by_sym_phase.setdefault((ev.symbol, ev.phase), []).append(ev)

    stats: list[PhaseWinRateStats] = []
    for (sym, phase), evs in by_sym_phase.items():
        resolved = [
            e for e in evs
            if e.is_resolved and e.return_pct is not None
        ]
        n_resolved = len(resolved)
        n_open = len(evs) - n_resolved

        u = universe_rates.get(phase, {
            "relative": 0.5, "profit": 0.5, "meaningful": 0.5,
        })

        # Three priors — one per win definition.
        a_rel,  b_rel  = (
            prior_strength * u["relative"],
            prior_strength * (1.0 - u["relative"]),
        )
        a_prof, b_prof = (
            prior_strength * u["profit"],
            prior_strength * (1.0 - u["profit"]),
        )
        a_meaning, b_meaning = (
            prior_strength * u["meaningful"],
            prior_strength * (1.0 - u["meaningful"]),
        )

        if n_resolved == 0:
            stats.append(PhaseWinRateStats(
                symbol=sym, phase=phase,
                n_resolved=0, n_open=n_open,
                avg_return_pct=float("nan"),
                median_hold_bars=0,
                n_wins_relative=0,
                p_win_relative_raw=float("nan"),
                p_win_relative_smoothed=u["relative"],
                n_wins_profit=0,
                p_win_profit_raw=float("nan"),
                p_win_profit_smoothed=u["profit"],
                n_wins_meaningful=0,
                p_win_meaningful_raw=float("nan"),
                p_win_meaningful_smoothed=u["meaningful"],
                prior_alpha_relative=a_rel,
                prior_beta_relative=b_rel,
                prior_alpha_profit=a_prof,
                prior_beta_profit=b_prof,
                prior_alpha_meaningful=a_meaning,
                prior_beta_meaningful=b_meaning,
            ))
            continue

        mean_ret = sum(e.return_pct for e in resolved) / n_resolved

        n_rel  = sum(
            1 for e in resolved if _is_win_relative(e.return_pct, mean_ret)
        )
        n_prof = sum(
            1 for e in resolved if _is_win_profit(e.return_pct, mean_ret)
        )
        n_meaning = sum(
            1 for e in resolved if _is_win_meaningful(e.return_pct, mean_ret)
        )

        p_rel_raw  = n_rel / n_resolved
        p_prof_raw = n_prof / n_resolved
        p_meaning_raw = n_meaning / n_resolved

        p_rel_smoothed = (a_rel + n_rel) / (a_rel + b_rel + n_resolved)
        p_prof_smoothed = (a_prof + n_prof) / (a_prof + b_prof + n_resolved)
        p_meaning_smoothed = (
            (a_meaning + n_meaning)
            / (a_meaning + b_meaning + n_resolved)
        )

        sorted_holds = sorted(e.hold_bars for e in resolved)
        median_hold = sorted_holds[len(sorted_holds) // 2]

        stats.append(PhaseWinRateStats(
            symbol=sym, phase=phase,
            n_resolved=n_resolved, n_open=n_open,
            avg_return_pct=mean_ret,
            median_hold_bars=int(median_hold),
            n_wins_relative=n_rel,
            p_win_relative_raw=p_rel_raw,
            p_win_relative_smoothed=p_rel_smoothed,
            n_wins_profit=n_prof,
            p_win_profit_raw=p_prof_raw,
            p_win_profit_smoothed=p_prof_smoothed,
            n_wins_meaningful=n_meaning,
            p_win_meaningful_raw=p_meaning_raw,
            p_win_meaningful_smoothed=p_meaning_smoothed,
            prior_alpha_relative=a_rel,
            prior_beta_relative=b_rel,
            prior_alpha_profit=a_prof,
            prior_beta_profit=b_prof,
            prior_alpha_meaningful=a_meaning,
            prior_beta_meaningful=b_meaning,
        ))

    return stats


def stats_to_dataframe(
    stats: Iterable[PhaseWinRateStats],
) -> pd.DataFrame:
    """Flatten stats list to a parquet-friendly dataframe."""
    return pd.DataFrame([asdict(s) for s in stats])
