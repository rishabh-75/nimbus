"""tests.ui.test_main_window_thin_peer — focused tests for the
MainWindow._thin_peer_for helper.

Tests the helper in isolation by constructing a cockpit MainWindow
and directly manipulating _panel + _industry_map. Avoids the heavier
setup used by test_main_window.py because the logic under test
(member counting) doesn't depend on panel-load or render state.
"""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pandas as pd
import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.industry_analytics import IndustryAnalyticsEngine
from nimbus_v3.core.industry_relative_state import ThinPeerContext
from nimbus_v3.ui.main_window import MainWindow


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture
def mw(qapp):
    """A cockpit MainWindow — tests populate panel + industry_map
    directly on the instance. _thin_peer_for is pure member-counting
    over those two fields, so no panel-load infra is needed."""
    win = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=lambda: ({}, None),
        data_manager=None,
    )
    # Reset the fields _thin_peer_for reads to known-empty values
    win._panel = {}
    win._industry_map = {}
    yield win
    win.close()


def _empty_df():
    """Minimal DataFrame placeholder — _thin_peer_for only counts
    keys; the value doesn't need to be a real enriched panel."""
    return pd.DataFrame({"Close": [100.0]})


# ══════════════════════════════════════════════════════════════════════
# _thin_peer_for
# ══════════════════════════════════════════════════════════════════════

class TestThinPeerFor:

    def test_returns_context_when_industry_has_one_member(self, mw):
        """POLYMED case: Healthcare Equipment & Supplies has just 1
        symbol in the loaded panel. _thin_peer_for should return a
        ThinPeerContext with n_members=1."""
        mw._panel = {"POLYMED": _empty_df()}
        mw._industry_map = {"POLYMED": "Healthcare Equipment & Supplies"}
        ctx = mw._thin_peer_for("POLYMED")
        assert isinstance(ctx, ThinPeerContext)
        assert ctx.industry == "Healthcare Equipment & Supplies"
        assert ctx.n_members == 1
        assert ctx.min_required == IndustryAnalyticsEngine.MIN_INDUSTRY_SIZE

    def test_returns_none_when_industry_at_threshold(self, mw):
        """Banks with exactly MIN_INDUSTRY_SIZE members — peer
        analytics can compute, so thin-peer should NOT fire (caller
        already got a real state)."""
        min_size = IndustryAnalyticsEngine.MIN_INDUSTRY_SIZE
        symbols = [f"BANK{i}" for i in range(min_size)]
        mw._panel = {s: _empty_df() for s in symbols}
        mw._industry_map = {s: "Banks" for s in symbols}
        ctx = mw._thin_peer_for(symbols[0])
        assert ctx is None

    def test_returns_none_when_industry_has_many_members(self, mw):
        """25-member Banks industry — thin-peer doesn't fire."""
        symbols = [f"BANK{i}" for i in range(25)]
        mw._panel = {s: _empty_df() for s in symbols}
        mw._industry_map = {s: "Banks" for s in symbols}
        ctx = mw._thin_peer_for(symbols[0])
        assert ctx is None

    def test_returns_none_when_panel_empty(self, mw):
        """Before any data has loaded — gracefully returns None
        rather than trying to classify."""
        mw._panel = {}
        mw._industry_map = {"POLYMED": "Healthcare Equipment & Supplies"}
        ctx = mw._thin_peer_for("POLYMED")
        assert ctx is None

    def test_returns_none_when_industry_map_empty(self, mw):
        """Symbol with no industry classification (not in the
        industry DB) — thin-peer returns None because we don't know
        WHICH industry to diagnose."""
        mw._panel = {"UNKNOWN_TICKER": _empty_df()}
        mw._industry_map = {}
        ctx = mw._thin_peer_for("UNKNOWN_TICKER")
        assert ctx is None

    def test_returns_none_when_symbol_not_in_map(self, mw):
        """Symbol is in panel but not in industry_map — same
        failure mode as empty map."""
        mw._panel = {"FOO": _empty_df()}
        mw._industry_map = {"BAR": "Banks"}
        ctx = mw._thin_peer_for("FOO")
        assert ctx is None

    def test_counts_only_in_panel_members(self, mw):
        """The industry_map may list symbols we don't have bars for
        (universe trim). Only in-panel members count toward the
        peer threshold."""
        # 10 symbols in the industry_map, but only 2 in _current_panel
        mw._industry_map = {
            f"SYM{i}": "Healthcare Equipment & Supplies"
            for i in range(10)
        }
        mw._panel = {
            "SYM0": _empty_df(),
            "SYM1": _empty_df(),
        }
        ctx = mw._thin_peer_for("SYM0")
        assert ctx is not None
        # Should count 2, not 10
        assert ctx.n_members == 2
