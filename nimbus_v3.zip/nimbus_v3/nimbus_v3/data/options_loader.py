"""nimbus_v3.data.options_loader — NSE option chain loader.

Fetches option chains for equities and indices. Returns a normalised
DataFrame with one row per ``(strike, expiry)`` pair. Downstream
computation (GEX, walls, max-pain, PCR, IVR, HVL) lives in
``context/options_context.py`` — this loader only fetches and parses.

DataFrame schema (returned by :meth:`OptionsLoader.load`)
────────────────────────────────────────────────────────
Column               | Type     | Notes
-------------------- | -------- | ------------------------------------
``strike``           | float    | Strike price.
``expiry``           | Timestamp| Expiry date, tz-naive at midnight.
``dte``              | int      | Trading days-ish to expiry (calendar).
``spot``             | float    | Underlying last price, repeated per row.
``ce_oi``            | float    | Call open interest.
``ce_oi_change``     | float    | Change in call OI.
``ce_volume``        | float    | Call volume.
``ce_iv``            | float    | Call implied volatility (%).
``ce_last``          | float    | Call last price.
``pe_oi``            | float    | Put open interest.
``pe_oi_change``     | float    | Change in put OI.
``pe_volume``        | float    | Put volume.
``pe_iv``            | float    | Put implied volatility (%).
``pe_last``          | float    | Put last price.

Missing values are ``NaN``; callers decide how to treat them.

Cache
─────
Per-symbol parquet, keyed by symbol. Short TTL (30 minutes) since chain
state moves intraday. Cache can be bypassed with ``force_refresh``.
"""
from __future__ import annotations

import logging
import time
from datetime import timedelta
from typing import Final

import pandas as pd

from nimbus_v3.data.base import CacheStore
from nimbus_v3.data.nse_client import NSEClient


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Endpoints
# ══════════════════════════════════════════════════════════════════════════════
#
# NSE deprecated the single-call ``option-chain-indices`` /
# ``option-chain-equities`` endpoints sometime in 2024. The current
# working flow (verified against oracle's production code) is:
#
#     1. GET /api/option-chain-contract-info?symbol=NIFTY
#        → list of expiry dates
#     2. For each expiry:
#        GET /api/option-chain-v3?type=Indices&symbol=NIFTY&expiry=16-May-2024
#        → rows for that expiry only
#     3. Combine per-expiry DataFrames into one.
#
# ``type`` is ``"Indices"`` for NIFTY/BANKNIFTY/FINNIFTY/MIDCPNIFTY and
# ``"Equities"`` for stock options. Referer stays ``/option-chain``.
# ─────────────────────────────────────────────────────────────────────

_EXPIRIES_ENDPOINT: Final[str] = (
    "https://www.nseindia.com/api/option-chain-contract-info"
)
_CHAIN_ENDPOINT: Final[str] = (
    "https://www.nseindia.com/api/option-chain-v3"
)
_OPTIONS_REFERER: Final[str] = "https://www.nseindia.com/option-chain"

#: Number of expiries fetched per symbol. Oracle fetches 3 — one is too
#: thin for max-pain / wall calcs, five is overkill and triggers rate
#: limiting when scanning many symbols.
_MAX_EXPIRIES: Final[int] = 3

#: Sleep between per-expiry requests. Oracle uses 0.4s — enough to
#: avoid NSE's rate limiter on sequential chain fetches.
_EXPIRY_FETCH_DELAY_S: Final[float] = 0.4

_DEFAULT_TTL: Final[timedelta] = timedelta(minutes=30)


# ══════════════════════════════════════════════════════════════════════════════
# Loader
# ══════════════════════════════════════════════════════════════════════════════

class OptionsLoader:
    """Option chain loader with parquet cache.

    Distinguishes equity and index symbols (they hit different NSE
    endpoints) via an explicit constructor knob or a per-call override.
    """

    def __init__(
        self,
        nse_client: NSEClient,
        cache: CacheStore,
        *,
        default_cache_ttl: timedelta = _DEFAULT_TTL,
    ) -> None:
        self._nse = nse_client
        self._cache = cache
        self._ttl = default_cache_ttl

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def load(
        self,
        symbol: str,
        *,
        is_index: bool = False,
        force_refresh: bool = False,
    ) -> pd.DataFrame:
        """Return a normalised option chain for ``symbol``.

        Args:
            symbol: NSE equity or index symbol (uppercase).
            is_index: True for index options (NIFTY, BANKNIFTY, ...).
                False for equity options (RELIANCE, TCS, ...).
            force_refresh: Bypass cache.

        Returns:
            DataFrame in the schema documented at the module level.
            Empty DataFrame if fetch fails and no cache is available.
        """
        if not symbol:
            raise ValueError("symbol must be non-empty")

        cache_key = f"{'index' if is_index else 'equity'}/{symbol.upper()}"

        if not force_refresh and self._cache_is_fresh(cache_key):
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached

        fetched = self._download(symbol, is_index=is_index)
        if fetched.empty:
            cached = self._cache.get(cache_key)
            if cached is not None:
                logger.info(
                    "options_loader: fresh fetch empty for %r; serving stale cache", symbol,
                )
                return cached
            logger.warning(
                "options_loader: no chain data for %r (fetch empty, no cache)", symbol,
            )
            return fetched

        self._cache.set(cache_key, fetched)
        return fetched

    def get_expiries(self, df: pd.DataFrame) -> list[pd.Timestamp]:
        """Return the sorted list of expiries present in a chain frame."""
        if df.empty or "expiry" not in df.columns:
            return []
        return sorted(df["expiry"].dropna().unique())

    # ══════════════════════════════════════════════════════════════════════
    # Private
    # ══════════════════════════════════════════════════════════════════════

    def _cache_is_fresh(self, key: str) -> bool:
        age = self._cache.age(key)
        return age is not None and age < self._ttl

    def _download(self, symbol: str, *, is_index: bool) -> pd.DataFrame:
        """Fetch + combine the first ``_MAX_EXPIRIES`` option chain
        frames from NSE's v3 API.

        Flow (matches oracle's production implementation):

            1. GET ``option-chain-contract-info`` → expiry date list.
            2. For each expiry, GET ``option-chain-v3`` with
               ``type={Indices|Equities}&symbol&expiry``.
            3. Parse each payload via :func:`parse_option_chain` (which
               accepts both the v3 ``data`` list and the legacy
               ``records.data`` nesting).
            4. Concatenate frames.

        Returns an empty DataFrame on any failure path; downstream
        :class:`OptionsContextProvider` treats that as "no chain
        available" and returns a None context.
        """
        sym_upper = symbol.upper()
        chain_type = "Indices" if is_index else "Equities"

        # ── Stage 1: expiries ───────────────────────────────────────────
        info = self._nse.fetch(
            _EXPIRIES_ENDPOINT,
            referer=_OPTIONS_REFERER,
            params={"symbol": sym_upper},
        )
        if not isinstance(info, dict):
            logger.warning(
                "options_loader: contract-info for %r returned %s (expected dict) — "
                "likely cookie/session issue or NSE returning HTML error page",
                sym_upper, type(info).__name__,
            )
            return pd.DataFrame()

        # NSE has used ``expiryDates`` historically; newer payloads have
        # been seen to use ``expiryDatesByInstrument`` or nest the list
        # under ``records``. Try each in priority order.
        expiries = (
            info.get("expiryDates")
            or info.get("expiry_dates")
            or (info.get("records") or {}).get("expiryDates")
            or []
        )
        # Defensive: if it's a dict (index-by-instrument variant), pull
        # the first instrument's list.
        if isinstance(expiries, dict):
            for v in expiries.values():
                if isinstance(v, list) and v:
                    expiries = v
                    break
            else:
                expiries = []
        if not expiries:
            logger.warning(
                "options_loader: contract-info for %r returned NO expiry list. "
                "Payload top-level keys: %s. Dashboard options fields will "
                "show '—' until this is resolved.",
                sym_upper, list(info.keys())[:10],
            )
            return pd.DataFrame()

        # Fetch the nearest N expiries — deeper ones add latency without
        # improving max-pain / wall calculations.
        expiries = expiries[:_MAX_EXPIRIES]
        logger.info(
            "options_loader: %s (type=%s) fetching %d expiries: %s",
            sym_upper, chain_type, len(expiries), expiries,
        )

        # ── Stage 2: per-expiry chain fetches ──────────────────────────
        frames: list[pd.DataFrame] = []
        for i, expiry in enumerate(expiries):
            try:
                payload = self._nse.fetch(
                    _CHAIN_ENDPOINT,
                    referer=_OPTIONS_REFERER,
                    params={
                        "type": chain_type,
                        "symbol": sym_upper,
                        "expiry": expiry,
                    },
                )
            except Exception:    # noqa: BLE001
                logger.exception(
                    "options_loader: chain fetch failed for %s @ %s",
                    sym_upper, expiry,
                )
                continue

            if not payload:
                logger.warning(
                    "options_loader: empty chain payload for %s @ %s",
                    sym_upper, expiry,
                )
                continue

            # Diagnostic — on the first expiry only, log the top-level
            # keys + row-list lengths so payload shape drift is
            # immediately visible in the log without shipping debug
            # builds. The INFO log-level fits because this is a
            # one-off per symbol per scan.
            if i == 0 and isinstance(payload, dict):
                row_lens = {}
                for k in ("data", "records", "filtered"):
                    v = payload.get(k)
                    if isinstance(v, list):
                        row_lens[k] = len(v)
                    elif isinstance(v, dict) and isinstance(v.get("data"), list):
                        row_lens[f"{k}.data"] = len(v["data"])
                logger.info(
                    "options_loader: %s chain payload shape — "
                    "keys=%s  row-list-lengths=%s",
                    sym_upper, list(payload.keys())[:10], row_lens,
                )

            df_expiry = parse_option_chain(payload, expected_expiry=expiry)
            if not df_expiry.empty:
                frames.append(df_expiry)

            # Throttle between expiries — same cadence oracle uses.
            if i + 1 < len(expiries):
                time.sleep(_EXPIRY_FETCH_DELAY_S)

        if not frames:
            logger.warning(
                "options_loader: all %d expiry fetches empty for %s",
                len(expiries), sym_upper,
            )
            return pd.DataFrame()

        combined = pd.concat(frames, ignore_index=True)
        logger.info(
            "options_loader: %s combined %d expiries → %d rows",
            sym_upper, len(frames), len(combined),
        )
        return combined


# ══════════════════════════════════════════════════════════════════════════════
# Parsing
# ══════════════════════════════════════════════════════════════════════════════

def parse_option_chain(
    payload: dict | list,
    *,
    expected_expiry: str | pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Flatten NSE's option-chain payload into the project's schema.

    Accepts every shape seen in the wild, in priority order:

        * **v3 flat** (current ``option-chain-v3`` response)::

              { "data": [...], "records": {"underlyingValue": ...} }

        * **v3 flat with underlyingValue at top level** (seen on some
          equity responses)::

              { "data": [...], "underlyingValue": ... }

        * **Legacy nested** (older single-call endpoints)::

              { "records": { "data": [...], "underlyingValue": ... } }

    ``expected_expiry`` is the expiry string/timestamp used as the
    query parameter for ``option-chain-v3``. The v3 endpoint's
    response rows typically OMIT the ``expiryDate`` field — because
    the whole response is already scoped to a single expiry — so
    without this hint every row would be silently dropped. When a
    row *does* carry ``expiryDate`` we prefer that value (legacy
    shape support).

    Returns an empty DataFrame on any shape mismatch, logging the
    payload's top-level keys at WARN so the operator can diagnose
    drift by tailing ``data/nimbus.log``.
    """
    if not isinstance(payload, dict):
        logger.warning(
            "parse_option_chain: payload is %s, expected dict",
            type(payload).__name__,
        )
        return pd.DataFrame()

    # Find the row list. NSE has been observed returning chains under
    # any of these keys, and — critically — can return an empty list at
    # one location while the real rows live at another. We try all
    # candidates and take the first non-empty one (oracle's or-chain
    # pattern). If every candidate is empty, we log ALL of them so
    # drift is visible at the next failure.
    candidates: list[tuple[str, list]] = []
    for path, val in (
        ("data",           payload.get("data")),
        ("records.data",   (payload.get("records") or {}).get("data")
                           if isinstance(payload.get("records"), dict) else None),
        ("filtered.data",  (payload.get("filtered") or {}).get("data")
                           if isinstance(payload.get("filtered"), dict) else None),
    ):
        if isinstance(val, list):
            candidates.append((path, val))

    if not candidates:
        logger.warning(
            "parse_option_chain: no row-list candidate found — "
            "top-level keys: %s (types: %s)",
            list(payload.keys())[:10],
            {k: type(v).__name__ for k, v in list(payload.items())[:10]},
        )
        return pd.DataFrame()

    # Pick the first non-empty candidate. The or-chain is the key
    # insight: NSE's v3 responses sometimes have an empty ``data`` at
    # the top and the real rows one level deeper under ``records``.
    rows: list = []
    for _path, val in candidates:
        if val:
            rows = val
            break

    if not rows:
        # Every candidate list was empty. Two very different cases
        # share this path:
        #
        #   - **Drift** (rare, real bug): NSE's payload shape moved
        #     the rows somewhere we don't probe. This is what the
        #     warning historically guarded against.
        #
        #   - **Empty expiry** (common, benign): the per-symbol fetch
        #     loop in :class:`OptionsLoader` walks every expiry in
        #     order; for far-out expiries NSE sometimes responds with
        #     the right shape but no rows. Logging this as a WARNING
        #     produced noise on every options refresh.
        #
        # Distinguishing the two is straightforward: in the drift
        # case the candidate-list shape is unexpected too (we'd often
        # see no candidates at all, handled above). When the
        # candidate paths exist but every list is empty, that's the
        # benign case — drop to DEBUG.
        logger.debug(
            "parse_option_chain: candidate row-lists are present but "
            "all empty — expected for far-out expiries. "
            "Paths checked: %s. Top-level keys: %s.",
            [p for p, _ in candidates],
            list(payload.keys())[:10],
        )
        return pd.DataFrame()

    # Spot sources — order matters; NSE nests ``underlyingValue`` under
    # ``records``, sometimes ``filtered``, and occasionally at the top.
    spot_sources: list = [
        payload,
        payload.get("records") or {},
        payload.get("filtered") or {},
    ]

    spot: float | None = None
    for src in spot_sources:
        if not isinstance(src, dict):
            continue
        spot = _safe_float(src.get("underlyingValue"))
        if spot is None:
            spot = _safe_float(src.get("last"))    # some payloads use 'last'
        if spot is not None:
            break
    if spot is None:
        logger.warning(
            "parse_option_chain: spot (underlyingValue) missing from "
            "all %d sources; downstream context will be None",
            len(spot_sources),
        )

    parsed: list[dict] = []

    # Pre-normalise the fallback expiry once. Supports both the
    # string form NSE uses ("21-Apr-2026") and a pandas Timestamp.
    fallback_expiry = None
    if expected_expiry is not None:
        if isinstance(expected_expiry, pd.Timestamp):
            fallback_expiry = expected_expiry.normalize()
        else:
            fallback_expiry = _parse_date(str(expected_expiry))

    today = pd.Timestamp.now().normalize()
    # Diagnostic counters — if all rows get filtered out, we log
    # WHY, so silent filter failures can't hide again.
    dropped_type = 0
    dropped_strike = 0
    dropped_expiry = 0
    for row in rows:
        if not isinstance(row, dict):
            dropped_type += 1
            continue
        strike = _safe_float(row.get("strikePrice"))
        if strike is None:
            dropped_strike += 1
            continue
        # NSE's option-chain-v3 rows typically OMIT expiryDate
        # (the response is scoped to one expiry via query). Fall
        # back to expected_expiry when the row doesn't carry it.
        expiry = _parse_date(row.get("expiryDate")) or fallback_expiry
        if expiry is None:
            dropped_expiry += 1
            continue
        dte = (expiry - today).days

        ce = row.get("CE") or {}
        pe = row.get("PE") or {}
        if not isinstance(ce, dict):
            ce = {}
        if not isinstance(pe, dict):
            pe = {}

        parsed.append({
            "strike": strike,
            "expiry": expiry,
            "dte": int(max(dte, 0)),
            "spot": spot if spot is not None else float("nan"),
            "ce_oi": _safe_float(ce.get("openInterest")) or 0.0,
            "ce_oi_change": _safe_float(ce.get("changeinOpenInterest")) or 0.0,
            "ce_volume": _safe_float(ce.get("totalTradedVolume")) or 0.0,
            "ce_iv": _safe_float(ce.get("impliedVolatility")),
            "ce_last": _safe_float(ce.get("lastPrice")),
            "pe_oi": _safe_float(pe.get("openInterest")) or 0.0,
            "pe_oi_change": _safe_float(pe.get("changeinOpenInterest")) or 0.0,
            "pe_volume": _safe_float(pe.get("totalTradedVolume")) or 0.0,
            "pe_iv": _safe_float(pe.get("impliedVolatility")),
            "pe_last": _safe_float(pe.get("lastPrice")),
        })

    if not parsed:
        logger.warning(
            "parse_option_chain: %d rows present but ALL dropped during "
            "parse — not-dict=%d, no-strikePrice=%d, no-valid-expiry=%d. "
            "If no-valid-expiry dominates and expected_expiry was %r, "
            "the row format has drifted.",
            len(rows), dropped_type, dropped_strike, dropped_expiry,
            expected_expiry,
        )
        return pd.DataFrame()

    df = pd.DataFrame(parsed)
    df = df.sort_values(["expiry", "strike"]).reset_index(drop=True)
    return df


def _parse_date(value: object) -> pd.Timestamp | None:
    if value is None or value == "":
        return None
    try:
        ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
    except (TypeError, ValueError):
        return None
    if ts is pd.NaT or pd.isna(ts):
        return None
    ts = pd.Timestamp(ts)
    if ts.tz is not None:
        ts = ts.tz_localize(None)
    return ts.normalize()


def _safe_float(value: object) -> float | None:
    if value is None:
        return None
    try:
        if isinstance(value, str):
            value = value.replace(",", "").strip()
            if not value or value == "-":
                return None
        f = float(value)
        return f if not pd.isna(f) else None
    except (TypeError, ValueError):
        return None
