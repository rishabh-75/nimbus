#!/usr/bin/env python3
"""
scripts/run_fold5_forensics.py — Characterize what broke in the most recent
walk-forward fold.

CONTEXT:
  Fold comparison (run_fold_comparison.py) revealed the system is bipolar
  across folds:
    fold=2:  Win 84.1%   Avg +2.31%   Sh +3.08    bars 9.3   ← excellent
    fold=3:  Win 72.8%   Avg +1.76%   Sh +2.06    bars 8.9   ← good
    fold=4:  Win 79.4%   Avg +2.52%   Sh +2.88    bars 9.3   ← excellent
    fold=5:  Win 60.9%   Avg -0.13%   Sh -0.09    bars 12.7  ← BROKEN

  Fold 5 is the most recent (Oct 2024 → Nov 2025). It's the third independent
  confirmation of the 2024+ regime change we already documented in BB Ride
  decay analysis and MR year-over-year. We need to characterize the failure
  mode in detail before deciding what to do about it.

GOAL:
  Compare fold 5 against fold 4 (the immediately preceding fold, working) to
  isolate WHAT specifically changed. Both folds use the same backtest engine
  and same parameter calibration approach — the only difference is the
  market period.

DESIGN — uses ONLY wf_oos_trades.csv columns:
  1. Side-by-side basic stats (already done in fold_comparison)
  2. Tier-specific breakdown (does both PRIMARY and SECONDARY fail equally?)
  3. PnL distribution shape (skew, kurtosis, percentiles — has the
     distribution shifted from "small wins + occasional losses" to "small
     wins + ruinous losses"?)
  4. Exit reason cascade (where do trades end? did winners turn into BBW
     exits, did MAX_HOLD increase, did SL hits change?)
  5. Bars-held distribution by exit reason (are PT trades taking longer
     to hit, signaling weaker momentum?)
  6. Per-symbol breakdown (is the failure broad or concentrated in a
     few symbols?)
  7. Time-within-fold breakdown (did fold 5 break early, gradually, or
     all at once?)

OUTPUT:
  Plain text comparison + a clear summary of what changed at the bottom.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd


CSV_PATH = "data/backtest_results/wf_oos_trades.csv"
GOOD_FOLD = 4   # working baseline
BAD_FOLD = 5    # broken fold to investigate


def header(text: str, char: str = "="):
    print("\n" + char * 78)
    print(f"  {text}")
    print(char * 78)


def section(text: str):
    print("\n" + "─" * 78)
    print(f"  {text}")
    print("─" * 78)


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS BLOCKS
# ══════════════════════════════════════════════════════════════════════════════

def basic_stats(df: pd.DataFrame, label: str) -> dict:
    pnl = df["pnl_pct"]
    wins = df[pnl > 0]
    losses = df[pnl <= 0]
    return {
        "label": label,
        "n": len(df),
        "win_pct": float((pnl > 0).mean() * 100) if len(df) else 0,
        "avg_pnl": float(pnl.mean()) if len(df) else 0,
        "med_pnl": float(pnl.median()) if len(df) else 0,
        "std_pnl": float(pnl.std()) if len(df) > 1 else 0,
        "win_avg": float(wins["pnl_pct"].mean()) if len(wins) else 0,
        "loss_avg": float(losses["pnl_pct"].mean()) if len(losses) else 0,
        "p10": float(pnl.quantile(0.10)) if len(df) else 0,
        "p90": float(pnl.quantile(0.90)) if len(df) else 0,
        "max_loss": float(pnl.min()) if len(df) else 0,
        "max_win": float(pnl.max()) if len(df) else 0,
        "bars_avg": float(df["bars_held"].mean()) if len(df) else 0,
    }


def print_side_by_side(good: dict, bad: dict):
    print(f"\n  {'Metric':<18s}  {'fold ' + str(GOOD_FOLD):>10s}  "
          f"{'fold ' + str(BAD_FOLD):>10s}  {'Δ':>10s}")
    print(f"  {'-'*18}  {'-'*10}  {'-'*10}  {'-'*10}")

    rows = [
        ("N",            f"{good['n']:>10d}",          f"{bad['n']:>10d}",          f"{bad['n']-good['n']:+d}"),
        ("Win rate",     f"{good['win_pct']:>9.1f}%",  f"{bad['win_pct']:>9.1f}%",  f"{bad['win_pct']-good['win_pct']:+8.1f}pp"),
        ("Avg PnL",      f"{good['avg_pnl']:>+8.2f}%", f"{bad['avg_pnl']:>+8.2f}%", f"{bad['avg_pnl']-good['avg_pnl']:+8.2f}%"),
        ("Med PnL",      f"{good['med_pnl']:>+8.2f}%", f"{bad['med_pnl']:>+8.2f}%", f"{bad['med_pnl']-good['med_pnl']:+8.2f}%"),
        ("Std PnL",      f"{good['std_pnl']:>9.2f}%",  f"{bad['std_pnl']:>9.2f}%",  f"{bad['std_pnl']-good['std_pnl']:+8.2f}%"),
        ("Avg winner",   f"{good['win_avg']:>+8.2f}%", f"{bad['win_avg']:>+8.2f}%", f"{bad['win_avg']-good['win_avg']:+8.2f}%"),
        ("Avg loser",    f"{good['loss_avg']:>+8.2f}%",f"{bad['loss_avg']:>+8.2f}%",f"{bad['loss_avg']-good['loss_avg']:+8.2f}%"),
        ("P10",          f"{good['p10']:>+8.2f}%",     f"{bad['p10']:>+8.2f}%",     f"{bad['p10']-good['p10']:+8.2f}%"),
        ("P90",          f"{good['p90']:>+8.2f}%",     f"{bad['p90']:>+8.2f}%",     f"{bad['p90']-good['p90']:+8.2f}%"),
        ("Max loss",     f"{good['max_loss']:>+8.2f}%",f"{bad['max_loss']:>+8.2f}%",f"{bad['max_loss']-good['max_loss']:+8.2f}%"),
        ("Max win",      f"{good['max_win']:>+8.2f}%", f"{bad['max_win']:>+8.2f}%", f"{bad['max_win']-good['max_win']:+8.2f}%"),
        ("Bars held avg",f"{good['bars_avg']:>9.2f}",  f"{bad['bars_avg']:>9.2f}",  f"{bad['bars_avg']-good['bars_avg']:+8.2f}"),
    ]
    for name, a, b, d in rows:
        print(f"  {name:<18s}  {a:>10s}  {b:>10s}  {d:>10s}")


def tier_breakdown(df: pd.DataFrame, fold: int):
    """Per-tier basic stats for one fold."""
    f = df[df["fold"] == fold]
    print(f"\n  fold={fold}")
    print(f"  {'Tier':<12s}  {'N':>6s}  {'Win%':>6s}  {'Avg':>8s}  {'Med':>8s}  {'Bars':>6s}")
    for tier in sorted(f["tier"].unique()):
        sub = f[f["tier"] == tier]
        s = basic_stats(sub, tier)
        print(f"  {tier:<12s}  {s['n']:>6d}  {s['win_pct']:>5.1f}%  "
              f"{s['avg_pnl']:>+7.2f}%  {s['med_pnl']:>+7.2f}%  {s['bars_avg']:>5.1f}")


def exit_reason_compare(df: pd.DataFrame):
    """Exit reason distribution + avg PnL per reason, side by side."""
    good = df[df["fold"] == GOOD_FOLD]
    bad = df[df["fold"] == BAD_FOLD]
    reasons = sorted(df["exit_reason"].unique())

    print(f"\n  {'Reason':<10s}  {'fold ' + str(GOOD_FOLD) + ' %':>10s}  {'avg PnL':>10s}  "
          f"{'fold ' + str(BAD_FOLD) + ' %':>10s}  {'avg PnL':>10s}  {'Δ %':>8s}  {'Δ avg':>8s}")
    print(f"  {'-'*10}  {'-'*10}  {'-'*10}  {'-'*10}  {'-'*10}  {'-'*8}  {'-'*8}")

    for r in reasons:
        g_sub = good[good["exit_reason"] == r]
        b_sub = bad[bad["exit_reason"] == r]
        g_pct = len(g_sub) / len(good) * 100 if len(good) else 0
        b_pct = len(b_sub) / len(bad) * 100 if len(bad) else 0
        g_avg = g_sub["pnl_pct"].mean() if len(g_sub) else 0
        b_avg = b_sub["pnl_pct"].mean() if len(b_sub) else 0
        print(f"  {r:<10s}  {g_pct:>9.1f}%  {g_avg:>+9.2f}%  "
              f"{b_pct:>9.1f}%  {b_avg:>+9.2f}%  "
              f"{b_pct-g_pct:>+7.1f}pp  {b_avg-g_avg:>+7.2f}%")


def pnl_distribution_shape(df: pd.DataFrame):
    """Compare the shape of PnL distributions across folds."""
    good = df[df["fold"] == GOOD_FOLD]["pnl_pct"]
    bad = df[df["fold"] == BAD_FOLD]["pnl_pct"]

    quantiles = [0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95]
    print(f"\n  Quantile  {'fold ' + str(GOOD_FOLD):>10s}  {'fold ' + str(BAD_FOLD):>10s}  {'Δ':>10s}")
    print(f"  {'-'*8}  {'-'*10}  {'-'*10}  {'-'*10}")
    for q in quantiles:
        g = good.quantile(q)
        b = bad.quantile(q)
        print(f"  P{int(q*100):>3d}     {g:>+9.2f}%  {b:>+9.2f}%  {b-g:>+9.2f}%")


def time_within_fold(df: pd.DataFrame):
    """Did fold 5 break early, gradually, or only at the end?"""
    bad = df[df["fold"] == BAD_FOLD].sort_values("entry_date")
    if len(bad) == 0:
        return

    n = len(bad)
    chunk_size = max(50, n // 6)
    chunks = []
    for start in range(0, n, chunk_size):
        chunk = bad.iloc[start:start + chunk_size]
        if len(chunk) < 20:
            continue
        chunks.append(chunk)

    print(f"\n  Fold {BAD_FOLD} timeline (chunks of ~{chunk_size} trades):")
    print(f"  {'Period':<24s}  {'N':>5s}  {'Win%':>6s}  {'Avg':>8s}  {'Med':>8s}")
    for chunk in chunks:
        d_min = chunk["entry_date"].min().date()
        d_max = chunk["entry_date"].max().date()
        s = basic_stats(chunk, "")
        period = f"{d_min} → {d_max}"
        print(f"  {period:<24s}  {s['n']:>5d}  {s['win_pct']:>5.1f}%  "
              f"{s['avg_pnl']:>+7.2f}%  {s['med_pnl']:>+7.2f}%")


def per_symbol_breakdown(df: pd.DataFrame):
    """Is the failure broad or concentrated?"""
    bad = df[df["fold"] == BAD_FOLD]
    by_symbol = bad.groupby("symbol").agg(
        n=("pnl_pct", "size"),
        win_pct=("pnl_pct", lambda x: (x > 0).mean() * 100),
        avg_pnl=("pnl_pct", "mean"),
    ).reset_index()
    by_symbol = by_symbol[by_symbol["n"] >= 3].sort_values("avg_pnl")

    print(f"\n  Worst 10 symbols in fold {BAD_FOLD} (≥3 trades):")
    print(f"  {'Symbol':<14s}  {'N':>4s}  {'Win%':>6s}  {'Avg PnL':>10s}")
    for _, r in by_symbol.head(10).iterrows():
        print(f"  {r['symbol']:<14s}  {int(r['n']):>4d}  {r['win_pct']:>5.1f}%  {r['avg_pnl']:>+9.2f}%")

    print(f"\n  Best 10 symbols in fold {BAD_FOLD} (≥3 trades):")
    print(f"  {'Symbol':<14s}  {'N':>4s}  {'Win%':>6s}  {'Avg PnL':>10s}")
    for _, r in by_symbol.tail(10).iloc[::-1].iterrows():
        print(f"  {r['symbol']:<14s}  {int(r['n']):>4d}  {r['win_pct']:>5.1f}%  {r['avg_pnl']:>+9.2f}%")

    # Concentration check
    n_neg = (by_symbol["avg_pnl"] < 0).sum()
    n_total = len(by_symbol)
    print(f"\n  Symbols with negative avg PnL: {n_neg}/{n_total} ({n_neg/n_total*100:.0f}%)")


def bars_by_exit(df: pd.DataFrame):
    """How long does each exit type take in each fold?"""
    print(f"\n  {'Reason':<10s}  {'fold ' + str(GOOD_FOLD) + ' bars':>14s}  "
          f"{'fold ' + str(BAD_FOLD) + ' bars':>14s}  {'Δ':>8s}")
    for r in sorted(df["exit_reason"].unique()):
        g = df[(df["fold"] == GOOD_FOLD) & (df["exit_reason"] == r)]
        b = df[(df["fold"] == BAD_FOLD) & (df["exit_reason"] == r)]
        if len(g) < 5 or len(b) < 5:
            continue
        g_b = g["bars_held"].mean()
        b_b = b["bars_held"].mean()
        print(f"  {r:<10s}  {g_b:>13.2f}   {b_b:>13.2f}   {b_b-g_b:>+7.2f}")


# ══════════════════════════════════════════════════════════════════════════════
# INTERPRETATION
# ══════════════════════════════════════════════════════════════════════════════

def interpret(df: pd.DataFrame):
    header("INTERPRETATION — WHAT BROKE IN FOLD 5")

    good = df[df["fold"] == GOOD_FOLD]
    bad = df[df["fold"] == BAD_FOLD]
    g_stats = basic_stats(good, str(GOOD_FOLD))
    b_stats = basic_stats(bad, str(BAD_FOLD))

    findings = []

    # Win rate collapse
    win_drop = g_stats["win_pct"] - b_stats["win_pct"]
    if win_drop > 10:
        findings.append(f"Win rate dropped sharply ({win_drop:.1f}pp): trades that "
                       f"should bounce simply aren't bouncing.")

    # Loser severity
    loss_widening = g_stats["loss_avg"] - b_stats["loss_avg"]
    if loss_widening > 0.3:
        findings.append(f"Losers got worse (avg loss {b_stats['loss_avg']:+.2f}% vs "
                       f"{g_stats['loss_avg']:+.2f}%): when trades fail, they fail by more.")

    # Winner shrinkage
    win_shrink = g_stats["win_avg"] - b_stats["win_avg"]
    if win_shrink > 0.3:
        findings.append(f"Winners got smaller (avg winner {b_stats['win_avg']:+.2f}% vs "
                       f"{g_stats['win_avg']:+.2f}%): even when right, the move is smaller.")

    # Holding time
    bars_diff = b_stats["bars_avg"] - g_stats["bars_avg"]
    if bars_diff > 1.5:
        findings.append(f"Holds extended by {bars_diff:.1f} bars: positions are drifting "
                       f"toward MAX_HOLD/BBW exits instead of hitting profit target.")

    # Exit reason mix
    g_pt_pct = (good["exit_reason"] == "PT").mean() * 100
    b_pt_pct = (bad["exit_reason"] == "PT").mean() * 100
    pt_drop = g_pt_pct - b_pt_pct
    if pt_drop > 5:
        findings.append(f"PT hit rate fell {pt_drop:.1f}pp ({g_pt_pct:.0f}% → {b_pt_pct:.0f}%): "
                       f"momentum carrying trades to target has weakened materially.")

    g_max_pct = (good["exit_reason"] == "MAX_HOLD").mean() * 100
    b_max_pct = (bad["exit_reason"] == "MAX_HOLD").mean() * 100
    if b_max_pct - g_max_pct > 2:
        findings.append(f"MAX_HOLD exits up {b_max_pct - g_max_pct:.1f}pp: "
                       f"more positions running out of clock without resolving.")

    if not findings:
        print("\n  No clear failure mode detected — fold 5 is broadly similar to fold 4.")
        return

    print("\n  Key findings:")
    for i, f in enumerate(findings, 1):
        print(f"    {i}. {f}")

    print()
    print("  Diagnosis pattern:")
    if pt_drop > 5 and bars_diff > 1.5:
        print("  → Classic 'mean reversion stops working' signature: trades take longer")
        print("    to resolve and fewer reach profit targets. Stocks that pierce oversold")
        print("    levels just hover instead of bouncing.")
        print()
        print("  → Consistent with the BB Ride decay analysis (Sharpe 1.24 → 0.15) and")
        print("    MR year-over-year mild degradation. Fold 5 is the third independent")
        print("    confirmation of the 2024+ regime change.")

    print()
    print("  Implications for production:")
    print("    1. The strategy regime detector (modules/strategy_regime.py) should flag")
    print("       this once enough resolved trades accumulate. Q score will go negative")
    print("       and the [DORMANT] tag will appear in the status bar.")
    print("    2. No code changes needed to the grade formula — the system is correctly")
    print("       grading setups; the market just isn't rewarding them right now.")
    print("    3. Watch the regime detector. If it flips to ACTIVE, conditions have")
    print("       improved. If it stays DORMANT for 2+ months, the regime change is")
    print("       persistent and we should think about strategy modifications.")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    if not os.path.exists(CSV_PATH):
        print(f"ERROR: {CSV_PATH} not found")
        sys.exit(1)

    df = pd.read_csv(CSV_PATH)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    print(f"\nLoaded {len(df):,} trades from {CSV_PATH}")
    print(f"Comparing fold {BAD_FOLD} (broken) vs fold {GOOD_FOLD} (working)")

    header("HEADLINE COMPARISON")
    good = basic_stats(df[df["fold"] == GOOD_FOLD], f"fold {GOOD_FOLD}")
    bad = basic_stats(df[df["fold"] == BAD_FOLD], f"fold {BAD_FOLD}")
    print_side_by_side(good, bad)

    section("TIER BREAKDOWN PER FOLD")
    tier_breakdown(df, GOOD_FOLD)
    tier_breakdown(df, BAD_FOLD)

    section("EXIT REASON DISTRIBUTION COMPARISON")
    exit_reason_compare(df)

    section("PNL DISTRIBUTION SHAPE")
    pnl_distribution_shape(df)

    section("BARS HELD BY EXIT REASON")
    bars_by_exit(df)

    section(f"FOLD {BAD_FOLD} TIMELINE — DID IT BREAK GRADUALLY OR ALL AT ONCE?")
    time_within_fold(df)

    section(f"PER-SYMBOL BREAKDOWN — IS THE FAILURE BROAD OR CONCENTRATED?")
    per_symbol_breakdown(df)

    interpret(df)


if __name__ == "__main__":
    main()
