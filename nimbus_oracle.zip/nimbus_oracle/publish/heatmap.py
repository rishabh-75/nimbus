#!/usr/bin/env python3
"""
publish/heatmap.py — NIFTY 100 Breadth Heatmap.

100-stock grid colored by drawdown from 52-week high, grouped by sector.
Instantly shows which sectors are under pressure and which are holding.
No jargon — just "how far is each stock from its peak."

Usage:
    python3 publish/heatmap.py
    python3 publish/heatmap.py --index nifty50
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

from publish.common import (
    nimbus_style, export_figure, add_title, add_timestamp, COLORS,
)
from modules.index_constituents import get_nifty50, get_nifty100, get_sector

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("publish_heatmap")


def scan_universe(symbols):
    """Scan symbols for heatmap data."""
    from modules.data import get_price_daily
    results = []
    for i, sym in enumerate(symbols):
        try:
            df, _ = get_price_daily(sym, days=365)
            if df is None or df.empty or len(df) < 40:
                continue
            c = df["Close"]
            h = df["High"]
            last_close = float(c.iloc[-1])
            high_52w = float(h.max())
            dd = (last_close / high_52w - 1) * 100 if high_52w > 0 else 0
            results.append({
                "symbol": sym,
                "sector": get_sector(sym),
                "close": last_close,
                "dd": dd,
            })
        except Exception as e:
            logger.debug("Skipped %s: %s", sym, e)
        if (i + 1) % 10 == 0:
            logger.info("  %d/%d scanned", i + 1, len(symbols))

    logger.info("Got %d/%d stocks", len(results), len(symbols))
    return results


def render_heatmap(results, index_name="NIFTY 100"):
    """Render sector-grouped heatmap grid colored by drawdown."""

    # Group by sector, sort sectors by avg drawdown
    sector_groups = {}
    for r in results:
        s = r["sector"]
        if s not in sector_groups:
            sector_groups[s] = []
        sector_groups[s].append(r)

    sorted_sectors = sorted(sector_groups.items(), key=lambda x: np.mean([r["dd"] for r in x[1]]))

    # Colormap: green (near peak) → gold (moderate DD) → red (deep DD)
    dd_cmap = LinearSegmentedColormap.from_list("dd", [
        (0.0, "#EF4444"),   # DD = -50% (deep crash)
        (0.3, "#F59E0B"),   # DD = -25%
        (0.6, "#64748B"),   # DD = -10%
        (0.8, "#34D399"),   # DD = -5%
        (1.0, "#10B981"),   # DD = 0% (at peak)
    ])

    with nimbus_style():
        n_sectors = len(sorted_sectors)
        max_per_sector = max(len(stocks) for _, stocks in sorted_sectors)

        # Tighter layout — reduce empty space
        rows_needed = sum(1 for _, stocks in sorted_sectors)
        fig_height = max(8, rows_needed * 0.7 + 2.5)

        fig, ax = plt.subplots(figsize=(14, fig_height))
        fig.subplots_adjust(top=0.93, bottom=0.06, left=0.12, right=0.88)

        now_str = datetime.datetime.now().strftime("%d %b %Y")
        add_title(fig, f"{index_name} DRAWDOWN HEATMAP",
                  f"Drawdown from 52-week high by sector · {now_str} · Green = near peak · Red = deep drawdown")
        add_timestamp(fig)

        ax.set_facecolor(COLORS["bg"])
        ax.axis("off")

        y_pos = 0
        cell_w = 0.85 / max(max_per_sector, 10)
        cell_h = 0.85 / max(rows_needed, 8)
        x_start = 0.13

        for sector_name, stocks in sorted_sectors:
            # Sort stocks within sector by drawdown
            stocks.sort(key=lambda r: r["dd"])
            avg_dd = np.mean([r["dd"] for r in stocks])

            # Sector label
            ax.text(0.01, 1.0 - y_pos - cell_h / 2, f"{sector_name}",
                   fontsize=8, fontweight=500, color=COLORS["white"],
                   transform=ax.transAxes, va="center", ha="left")
            ax.text(0.10, 1.0 - y_pos - cell_h / 2, f"({avg_dd:.0f}%)",
                   fontsize=7, color=COLORS["muted"],
                   transform=ax.transAxes, va="center", ha="left")

            for j, stock in enumerate(stocks):
                x = x_start + j * cell_w
                y = 1.0 - y_pos - cell_h

                # Color by drawdown: 0% (at peak) = 1.0, -50% = 0.0
                dd_norm = max(0, min(1, (stock["dd"] + 50) / 50))
                color = dd_cmap(dd_norm)

                rect = plt.Rectangle((x, y), cell_w * 0.92, cell_h * 0.85,
                                    transform=ax.transAxes, facecolor=color,
                                    edgecolor=COLORS["bg"], linewidth=0.5,
                                    clip_on=False)
                ax.add_patch(rect)

                # Text: dark on bright tiles, light on dark
                text_color = "#0D1117" if dd_norm > 0.55 else "#E6EDF3"
                sym = stock["symbol"]
                sym_fs = 5.5 if len(sym) <= 6 else (4.5 if len(sym) <= 8 else 4.0)
                ax.text(x + cell_w * 0.46, y + cell_h * 0.55, sym,
                       fontsize=sym_fs, color=text_color, fontweight=500,
                       transform=ax.transAxes, ha="center", va="center")
                ax.text(x + cell_w * 0.46, y + cell_h * 0.22, f"{stock['dd']:.0f}%",
                       fontsize=5, color=text_color, alpha=0.8,
                       transform=ax.transAxes, ha="center", va="center",
                       fontfamily="monospace")

            y_pos += cell_h + 0.008

        # ── Legend ──────────────────────────────────────────────────────
        legend_y = 0.02
        legend_x = 0.13
        legend_items = [
            (0, "At 52w peak"), (-10, "Near peak (< 10%)"),
            (-20, "Moderate (10-20%)"), (-35, "Deep (> 20%)"),
        ]
        for dd_val, label in legend_items:
            dd_n = max(0, min(1, (dd_val + 50) / 50))
            c = dd_cmap(dd_n)
            rect = plt.Rectangle((legend_x, legend_y), 0.015, 0.015,
                                transform=ax.transAxes, facecolor=c,
                                edgecolor="none", clip_on=False)
            ax.add_patch(rect)
            ax.text(legend_x + 0.02, legend_y + 0.007, f"{label} ({dd_val}%)",
                   fontsize=6.5, color=COLORS["muted"],
                   transform=ax.transAxes, va="center")
            legend_x += 0.20

    return fig


def main():
    parser = argparse.ArgumentParser(description="NIMBUS Breadth Heatmap")
    parser.add_argument("--index", default="nifty100", choices=["nifty50", "nifty100"])
    parser.add_argument("--no-export", action="store_true")
    args = parser.parse_args()

    if args.index == "nifty100":
        symbols = get_nifty100()
        index_name = "NIFTY 100"
    else:
        symbols = get_nifty50()
        index_name = "NIFTY 50"

    logger.info("Scanning %s (%d stocks)...", index_name, len(symbols))
    results = scan_universe(symbols)

    if len(results) < 10:
        logger.error("Too few results (%d)", len(results))
        return

    fig = render_heatmap(results, index_name)

    if fig and not args.no_export:
        slug = f"{args.index}_heatmap"
        export_figure(fig, slug)
    else:
        logger.info("Preview mode — not exported")

    plt.close(fig)
    logger.info("Done.")


if __name__ == "__main__":
    main()
