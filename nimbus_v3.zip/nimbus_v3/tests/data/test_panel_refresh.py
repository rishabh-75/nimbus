"""Tests for nimbus_v3.data.panel_refresh.

Covers ``panel_age``, ``panel_needs_refresh``, and
``mark_panel_refreshed``. Each test isolates the marker file
to a tmp data root so concurrent tests don't share state.
"""
from __future__ import annotations

import time
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

import pytest

from nimbus_v3.data import panel_refresh as pr


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════════════


@pytest.fixture
def isolated_marker(tmp_path: Path):
    """Patch ``data_root`` so the marker writes/reads a tmp dir.

    Each test gets a fresh empty marker location — no test-order
    coupling. Yields the tmp path so tests can assert on the
    marker file directly.
    """
    with patch("nimbus_v3.data.panel_refresh.data_root", return_value=tmp_path):
        yield tmp_path


# ══════════════════════════════════════════════════════════════════════════════
# panel_age
# ══════════════════════════════════════════════════════════════════════════════


class TestPanelAge:
    def test_returns_none_when_marker_absent(self, isolated_marker):
        assert pr.panel_age() is None

    def test_returns_timedelta_when_marker_present(self, isolated_marker):
        marker = isolated_marker / ".panel_last_refresh"
        marker.touch()
        time.sleep(0.05)
        age = pr.panel_age()
        assert age is not None
        # Marker was just touched, so age is small but positive.
        assert age.total_seconds() >= 0.04
        assert age.total_seconds() < 5    # generous upper bound


# ══════════════════════════════════════════════════════════════════════════════
# panel_needs_refresh
# ══════════════════════════════════════════════════════════════════════════════


class TestPanelNeedsRefresh:
    def test_no_marker_means_refresh_needed(self, isolated_marker):
        assert pr.panel_needs_refresh(timedelta(hours=12)) is True

    def test_fresh_marker_means_no_refresh(self, isolated_marker):
        marker = isolated_marker / ".panel_last_refresh"
        marker.touch()
        # A marker just touched is "0 seconds old" — younger than
        # any positive threshold, so no refresh needed.
        assert pr.panel_needs_refresh(timedelta(hours=12)) is False

    def test_stale_marker_means_refresh_needed(self, isolated_marker):
        marker = isolated_marker / ".panel_last_refresh"
        marker.touch()
        # Backdate the marker by 13h via os.utime.
        import os
        old = time.time() - (13 * 3600)
        os.utime(marker, (old, old))
        assert pr.panel_needs_refresh(timedelta(hours=12)) is True

    def test_threshold_at_zero_always_refreshes(self, isolated_marker):
        """With threshold=0, even a just-touched marker is "stale"
        on the next read (age >= 0 == threshold)."""
        marker = isolated_marker / ".panel_last_refresh"
        marker.touch()
        # Sleep a hair so age > 0 strictly.
        time.sleep(0.01)
        assert pr.panel_needs_refresh(timedelta(0)) is True


# ══════════════════════════════════════════════════════════════════════════════
# mark_panel_refreshed
# ══════════════════════════════════════════════════════════════════════════════


class TestMarkPanelRefreshed:
    def test_creates_marker_when_absent(self, isolated_marker):
        marker = isolated_marker / ".panel_last_refresh"
        assert not marker.is_file()
        pr.mark_panel_refreshed()
        assert marker.is_file()

    def test_updates_mtime_when_marker_present(self, isolated_marker):
        marker = isolated_marker / ".panel_last_refresh"
        marker.touch()
        # Backdate to verify mark_panel_refreshed actually updates.
        import os
        old = time.time() - 3600
        os.utime(marker, (old, old))
        old_mtime = marker.stat().st_mtime

        pr.mark_panel_refreshed()
        new_mtime = marker.stat().st_mtime
        assert new_mtime > old_mtime

    def test_marker_lives_under_data_root(self, isolated_marker):
        """The marker filename is ``.panel_last_refresh`` directly
        under data_root — that location is documented behaviour
        callers may rely on (e.g. operators rm-ing it to force a
        refresh)."""
        pr.mark_panel_refreshed()
        assert (isolated_marker / ".panel_last_refresh").is_file()


# ══════════════════════════════════════════════════════════════════════════════
# Integration: full mark → age → needs_refresh roundtrip
# ══════════════════════════════════════════════════════════════════════════════


class TestRoundtrip:
    def test_mark_then_age_is_small(self, isolated_marker):
        pr.mark_panel_refreshed()
        age = pr.panel_age()
        assert age is not None
        assert age.total_seconds() < 1

    def test_mark_then_needs_refresh_within_window_is_false(
        self, isolated_marker,
    ):
        pr.mark_panel_refreshed()
        # Within a 12h window, just-marked is fresh.
        assert pr.panel_needs_refresh(timedelta(hours=12)) is False

    def test_default_interval_is_twelve_hours(self):
        """Locks in the documented default. Bulk-refresh is gated
        by this constant in the panel loader; a change here is a
        behaviour change worth being explicit about."""
        assert pr.DEFAULT_PANEL_REFRESH_INTERVAL == timedelta(hours=12)
