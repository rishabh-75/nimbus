"""nimbus_v3.ui.widgets.watchlist_tab — the Watchlist tab.

Renders the operator's persisted watchlist symbols using the SAME
columns as the dashboard Constituents table (it embeds a
:class:`ConstituentsTable`, so the column set, formatting, and
body-above/streak logic stay identical and single-sourced).

Each row's Symbol cell carries a checkbox; the "DELETE SELECTED" button
removes every checked symbol from the watchlist in one action.
Double-clicking a row emits :attr:`symbol_activated` so MainWindow can
load that symbol into the Dashboard.
"""
from __future__ import annotations

import pandas as pd
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from nimbus_v3.core.universe import Universe
from nimbus_v3.ui.theme import FONT_UI
from nimbus_v3.ui.widgets.industry_tables import ConstituentsTable


class WatchlistTab(QWidget):
    """Tab showing the persisted watchlist with constituent columns,
    per-row checkboxes, and a bulk delete-selected action."""

    symbol_activated = pyqtSignal(str)        # double-click → load
    remove_requested = pyqtSignal(list)       # delete selected → [symbols]

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        # ── Action row: delete-selected ────────────────────────────
        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        self._delete_btn = QPushButton("DELETE SELECTED")
        self._delete_btn.setFont(QFont(FONT_UI, 9))
        self._delete_btn.setFixedHeight(26)
        self._delete_btn.clicked.connect(self._on_delete_selected)
        actions.addWidget(self._delete_btn)
        actions.addStretch(1)
        layout.addLayout(actions)

        self._table = ConstituentsTable()
        self._table.set_title("WATCHLIST")
        layout.addWidget(self._table)

        inner = self._table._table    # the QTableWidget inside
        inner.cellDoubleClicked.connect(self._on_double_click)

        self._symbols: list[str] = []

    # ── public API ────────────────────────────────────────────────────────

    def set_data(
        self,
        symbols: list[str],
        panel: dict[str, pd.DataFrame],
        universe: Universe | None = None,
        industry_riding=None,
    ) -> None:
        """Render the watchlist ``symbols`` using the constituent table,
        then make each Symbol cell checkable."""
        self._symbols = list(symbols)
        self._table.set_industry("", symbols, panel, universe,
                                 industry_riding=industry_riding)
        self._table.set_title(
            f"WATCHLIST \u00b7 {len(symbols)} symbols" if symbols
            else "WATCHLIST"
        )
        self._add_checkboxes()

    # ── internals ─────────────────────────────────────────────────────────

    def _add_checkboxes(self) -> None:
        """Turn each row's Symbol cell into a checkable item."""
        inner = self._table._table
        for row in range(inner.rowCount()):
            item = inner.item(row, 0)
            if item is None:
                continue
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)

    def _symbol_at_row(self, row: int) -> str | None:
        item = self._table._table.item(row, 0)
        return item.text() if item is not None else None

    def _checked_symbols(self) -> list[str]:
        inner = self._table._table
        out: list[str] = []
        for row in range(inner.rowCount()):
            item = inner.item(row, 0)
            if item is not None and item.checkState() == Qt.CheckState.Checked:
                out.append(item.text())
        return out

    def _on_double_click(self, row: int, _col: int) -> None:
        sym = self._symbol_at_row(row)
        if sym:
            self.symbol_activated.emit(sym)

    def _on_delete_selected(self) -> None:
        checked = self._checked_symbols()
        if checked:
            self.remove_requested.emit(checked)
