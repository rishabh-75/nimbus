#!/usr/bin/env python3
"""
scripts/run_tier_analysis.py — Does tier add anything on top of grade?

Tests whether PRIMARY vs SECONDARY matters within each grade band.
If A+ PRIMARY performs identically to A+ SECONDARY, tier is redundant
for conviction — it only controls position sizing as risk management.

Usage:
    python3 scripts/run_tier_analysis.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("tier_analysis")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="tier_analysis_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    from modules.dual_mode import compute_dual_mode
    from modules.conviction import ConvictionEngine
    engine = ConvictionEngine()

    price_cache = {}
    for sym in trades_df["symbol"].unique():
        f = f"data/backtest_cache/{sym}_1d.parquet"
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except: pass

    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    rows = []
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in price_cache: continue
        pdf = price_cache[sym]
        mask = pdf.index <= trade["entry_date"]
        if mask.sum() < 40: continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient: continue
            vmask = vix_series.index <= trade["entry_date"]
            vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0
            conv = engine.compute(sig, vix=vix)
            rows.append({
                "pnl_pct": trade["pnl_pct"], "win": int(trade["pnl_pct"] > 0),
                "tier": trade["tier"], "grade": conv.grade,
                "exit_reason": trade["exit_reason"],
                "effective_sizing": conv.effective_sizing,
                "mfi": sig.mfi, "rsi": sig.rsi, "vol_ratio": sig.vol_ratio,
                "wr": sig.wr_30, "dd": sig.dd_from_high,
            })
        except: pass
        if len(rows) % 500 == 0:
            logger.info("  %d processed", len(rows))

    df = pd.DataFrame(rows)
    logger.info("Features: %d trades", len(df))

    report = []
    report.append("=" * 70)
    report.append("TIER × GRADE ANALYSIS")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)}")
    report.append("=" * 70)

    # ── TEST 1: Overall tier comparison ──────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 1: OVERALL TIER COMPARISON")
    report.append("=" * 70)

    from scipy import stats
    for tier in ["PRIMARY", "SECONDARY"]:
        t = df[df["tier"] == tier]
        sh = t["pnl_pct"].mean() / t["pnl_pct"].std() * np.sqrt(252/10) if t["pnl_pct"].std() > 0 else 0
        pt = (t["exit_reason"] == "PT").mean() * 100
        report.append(f"  {tier:10s}: N={len(t):4d}  Win={t['win'].mean()*100:.1f}%  "
                      f"Avg={t['pnl_pct'].mean():+.3f}%  Sh={sh:.2f}  PT={pt:.0f}%")

    pri = df[df["tier"] == "PRIMARY"]["pnl_pct"]
    sec = df[df["tier"] == "SECONDARY"]["pnl_pct"]
    t_stat, p_val = stats.ttest_ind(pri, sec, equal_var=False)
    report.append(f"\n  t={t_stat:.3f}  p={p_val:.4f}")
    if p_val < 0.05:
        report.append("  ✓ SIGNIFICANT — tiers produce different outcomes")
    else:
        report.append("  ○ NOT significant — tiers perform similarly")

    # ── TEST 2: Tier within each grade ──────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 2: TIER WITHIN EACH GRADE")
    report.append("=" * 70)
    report.append("  Does PRIMARY outperform SECONDARY at the same grade?")
    report.append("")
    report.append(f"  {'Grade':5s} {'PRI N':>6s} {'PRI Win':>8s} {'PRI Avg':>8s}  "
                  f"{'SEC N':>6s} {'SEC Win':>8s} {'SEC Avg':>8s}  {'Diff':>6s}")

    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        pri_g = df[(df["grade"] == g) & (df["tier"] == "PRIMARY")]
        sec_g = df[(df["grade"] == g) & (df["tier"] == "SECONDARY")]
        if len(pri_g) < 5 and len(sec_g) < 5: continue
        pw = pri_g["win"].mean()*100 if len(pri_g) >= 5 else float("nan")
        sw = sec_g["win"].mean()*100 if len(sec_g) >= 5 else float("nan")
        pa = pri_g["pnl_pct"].mean() if len(pri_g) >= 5 else float("nan")
        sa = sec_g["pnl_pct"].mean() if len(sec_g) >= 5 else float("nan")
        diff = (pw - sw) if not (np.isnan(pw) or np.isnan(sw)) else float("nan")
        pw_s = f"{pw:.1f}%" if not np.isnan(pw) else "—"
        sw_s = f"{sw:.1f}%" if not np.isnan(sw) else "—"
        pa_s = f"{pa:+.3f}%" if not np.isnan(pa) else "—"
        sa_s = f"{sa:+.3f}%" if not np.isnan(sa) else "—"
        diff_s = f"{diff:+.1f}pp" if not np.isnan(diff) else "—"
        report.append(f"  {g:5s} {len(pri_g):6d} {pw_s:>8s} {pa_s:>8s}  "
                      f"{len(sec_g):6d} {sw_s:>8s} {sa_s:>8s}  {diff_s:>6s}")

    # ── TEST 3: PT hit rate by tier × grade ─────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 3: PT HIT RATE BY TIER × GRADE")
    report.append("=" * 70)

    report.append(f"\n  {'Grade':5s} {'PRI PT%':>8s} {'PRI N':>6s}  {'SEC PT%':>8s} {'SEC N':>6s}")
    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        pri_g = df[(df["grade"] == g) & (df["tier"] == "PRIMARY")]
        sec_g = df[(df["grade"] == g) & (df["tier"] == "SECONDARY")]
        if len(pri_g) < 5 and len(sec_g) < 5: continue
        p_pt = f"{(pri_g['exit_reason']=='PT').mean()*100:.0f}%" if len(pri_g) >= 5 else "—"
        s_pt = f"{(sec_g['exit_reason']=='PT').mean()*100:.0f}%" if len(sec_g) >= 5 else "—"
        report.append(f"  {g:5s} {p_pt:>8s} {len(pri_g):6d}  {s_pt:>8s} {len(sec_g):6d}")

    # ── TEST 4: Factor profile PRIMARY vs SECONDARY ─────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 4: WHAT DIFFERENTIATES PRIMARY FROM SECONDARY?")
    report.append("=" * 70)

    pri_df = df[df["tier"] == "PRIMARY"]
    sec_df = df[df["tier"] == "SECONDARY"]
    report.append(f"\n  {'Factor':12s} {'PRIMARY':>10s} {'SECONDARY':>12s} {'Diff':>8s}")
    for col, label in [("mfi", "MFI"), ("rsi", "RSI"), ("vol_ratio", "Vol ratio"),
                        ("wr", "WR"), ("dd", "DD%")]:
        p_avg = pri_df[col].mean()
        s_avg = sec_df[col].mean()
        report.append(f"  {label:12s} {p_avg:+10.1f} {s_avg:+12.1f} {p_avg-s_avg:+8.1f}")

    # ── TEST 5: Should sizing use tier, grade, or both? ─────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 5: SIZING STRATEGY COMPARISON")
    report.append("=" * 70)
    report.append("  Which sizing rule maximizes risk-adjusted returns?")
    report.append("")

    def wtd_sharpe(subset, weights):
        s = subset.copy()
        s["wt"] = s["grade"].map(weights).fillna(0)
        if "tier_wt" in s.columns:
            s["wt"] = s["wt"] * s["tier_wt"]
        s = s[s["wt"] > 0]
        if len(s) < 20: return 0, 0, 0
        wtd = (s["pnl_pct"] * s["wt"]).sum() / s["wt"].sum()
        std = np.sqrt(((s["pnl_pct"] * s["wt"])**2).sum() / s["wt"].sum())
        sh = wtd / std * np.sqrt(252/10) if std > 0 else 0
        return wtd, sh, len(s)

    grade_wt = {"A+": 1.5, "A": 1.5, "B+": 1.0, "B": 1.0, "C+": 0.5, "C": 0, "D": 0}

    # Strategy A: tier only (current)
    df_a = df.copy()
    df_a["tier_wt"] = df_a["tier"].map({"PRIMARY": 1.0, "SECONDARY": 0.5})
    tier_wt = {"A+": 1, "A": 1, "B+": 1, "B": 1, "C+": 1, "C": 1, "D": 1}
    a_avg, a_sh, a_n = wtd_sharpe(df_a, tier_wt)

    # Strategy B: grade only
    b_avg, b_sh, b_n = wtd_sharpe(df, grade_wt)

    # Strategy C: grade × tier combined
    df_c = df.copy()
    df_c["tier_wt"] = df_c["tier"].map({"PRIMARY": 1.0, "SECONDARY": 0.75})
    c_avg, c_sh, c_n = wtd_sharpe(df_c, grade_wt)

    report.append(f"  {'Strategy':35s} {'Wtd Avg':>8s} {'Sh':>6s} {'N':>5s}")
    report.append(f"  {'A. Tier only (PRI=1x, SEC=0.5x)':35s} {a_avg:+7.3f}% {a_sh:5.2f} {a_n:5d}")
    report.append(f"  {'B. Grade only (A=1.5x, B=1x, skip C/D)':35s} {b_avg:+7.3f}% {b_sh:5.2f} {b_n:5d}")
    report.append(f"  {'C. Grade×Tier (grade wt × tier 0.75)':35s} {c_avg:+7.3f}% {c_sh:5.2f} {c_n:5d}")

    report.append("\n" + "=" * 70)
    report.append("RECOMMENDATION")
    report.append("=" * 70)

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
