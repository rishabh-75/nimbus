"""nimbus_v3.compute.ride_initiation.cache — pre-classified panel cache.

``RideClassificationCache`` runs ``RideEngine.classify`` once per
panel symbol and ``RideEngine.classify_industry`` /
``classify_universe`` once per group, then exposes the cached
:class:`RideResult` objects via lookup.

Why this exists
───────────────
The Industries + Constituents tables in the cockpit need ride
phase + score for every visible row. Calling the engine inline at
render time produced two architectural problems:

  1. **Multiple sources of truth.** MainWindow already classified
     the chart symbol once (for the sidebar's KEY LEVELS & STATS
     panel). The constituents table re-classified the same symbol
     when its row was rendered — same input, same output, different
     code path. A future change to one path would silently disagree
     with the other.

  2. **Recomputation on every render.** With ~470 NSE symbols and
     ~50 industries, a fresh panel push triggered ~470 per-symbol
     classifications + ~50 industry roll-ups *every time the
     dashboard repopulated* — including click-to-pivot industry
     selections. Each ``RideEngine.classify`` is cheap on a single
     dataframe, but together they dominated the render cost.

The cache fixes both: classify once when the panel arrives, hand
the cache to consumers, who treat it as lookup tables.

Lifecycle
─────────
1. Built by :func:`RideClassificationCache.build` immediately after
   the panel loads.
2. Refreshed in-place by :meth:`update_symbol` whenever the panel's
   per-symbol dataframe changes (e.g. user loads a fresh chart and
   the data manager fetches updated bars). The chart-symbol's
   industry roll-up is also refreshed so the Industries table
   reflects the new data.
3. Consumed by:
     - ``MainWindow`` for the chart symbol's ``RideResult`` (drives
       the sidebar's KEY LEVELS & STATS panel)
     - ``IndustriesTable`` for per-industry phase + score rows
     - ``ConstituentsTable`` for per-symbol phase + score rows

Cache invariant: every ``RideResult`` returned was produced by the
same ``RideEngine`` instance with the same constants / schema_hash.
That's the single source of truth.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

import pandas as pd

from .engine import RideEngine
from .types import RideResult


logger = logging.getLogger(__name__)


@dataclass
class RideClassificationCache:
    """Per-panel classification cache.

    Treated as a lookup table by consumers — they read via
    :meth:`for_symbol` / :meth:`for_industry` and never mutate. The
    only mutator is :meth:`update_symbol`, called by the owning
    component (MainWindow) when a fresh symbol fetch lands and the
    underlying panel dataframe changes.

    Attributes:
        symbol_results: ``{symbol: RideResult}``. One entry per panel
            symbol with sufficient history to classify. Symbols that
            failed classification (insufficient bars, missing
            indicators) are omitted — callers should treat absence
            as no-fire.
        industry_results: ``{industry_name: RideResult}``. The
            roll-up classification for every industry whose
            ``classify_industry`` call returned a non-empty result.
            The special key ``"ALL"`` holds the universe-wide
            roll-up from ``classify_universe``.
    """

    symbol_results: dict[str, RideResult] = field(default_factory=dict)
    industry_results: dict[str, RideResult] = field(default_factory=dict)

    @classmethod
    def build(
        cls,
        panel: dict[str, pd.DataFrame],
        members_by_industry: dict[str, list[str]],
        engine: RideEngine | None = None,
    ) -> "RideClassificationCache":
        """Classify every panel symbol + industry roll-up exactly once.

        Args:
            panel: ``{symbol: enriched_df}`` — the same panel the
                tables will read from. Symbols whose dataframes are
                empty / too short are skipped silently.
            members_by_industry: ``{industry_name: [symbols]}`` —
                grouping used to drive ``classify_industry`` calls.
                The roll-up uses whichever members actually appear
                in ``panel`` (graceful when the universe lists more
                symbols than the panel ended up loading).
            engine: optional pre-built ``RideEngine``. The engine is
                stateless so a fresh instance is fine; accepting one
                lets tests inject a deterministic stub.

        Returns:
            A populated cache. Empty panel → empty cache (both
            dicts empty); callers must handle that.
        """
        if engine is None:
            engine = RideEngine()
        if not panel:
            return cls()

        # 1. Per-symbol classification — single pass over the panel.
        symbol_results: dict[str, RideResult] = {}
        for sym, df in panel.items():
            if df is None or df.empty:
                continue
            try:
                res = engine.classify(df)
            except Exception:    # noqa: BLE001
                logger.exception(
                    "RideClassificationCache: classify(%s) failed", sym,
                )
                continue
            if not res.phase.empty:
                symbol_results[sym] = res

        # 2. Per-industry roll-up.
        industry_results: dict[str, RideResult] = {}
        for industry, members in members_by_industry.items():
            members_panel = {
                s: panel[s] for s in members if s in panel
            }
            if not members_panel:
                continue
            try:
                res = engine.classify_industry(members_panel)
            except Exception:    # noqa: BLE001
                logger.exception(
                    "RideClassificationCache: classify_industry(%s) failed",
                    industry,
                )
                continue
            if not res.phase.empty:
                industry_results[industry] = res

        # 3. Universe roll-up — the special "ALL" row in the
        #    Industries table. Built over the entire panel so the
        #    ALL row's phase/score reflects the broadest aggregate.
        try:
            all_res = engine.classify_universe(panel)
            if not all_res.phase.empty:
                industry_results["ALL"] = all_res
        except Exception:    # noqa: BLE001
            logger.exception(
                "RideClassificationCache: classify_universe(panel) failed",
            )

        return cls(
            symbol_results=symbol_results,
            industry_results=industry_results,
        )

    def update_symbol(
        self,
        sym: str,
        panel: dict[str, pd.DataFrame],
        members_by_industry: dict[str, list[str]],
        engine: RideEngine | None = None,
    ) -> None:
        """Re-classify a single symbol after its dataframe in
        ``panel`` was updated, plus the symbol's industry roll-up
        and the universe ``"ALL"`` roll-up.

        Why this is necessary
        ─────────────────────
        ``MainWindow`` mutates ``self._panel[symbol]`` whenever a
        fresh price fetch lands (the data manager updates with the
        latest bars). Without this method the cache would still
        hold the original ``RideResult`` produced from the *initial*
        panel load — leading to the staleness bug where the sidebar
        (re-classified each ``_load_symbol`` call) would show a
        different phase than the constituents table (reading the
        stale cache).

        Args:
            sym: symbol whose entry needs refresh.
            panel: the (already-mutated) panel dict — caller has
                already overwritten ``panel[sym]`` with fresh data.
            members_by_industry: same grouping passed to ``build``.
                Used to find which industry's roll-up to refresh.
            engine: optional ``RideEngine`` (stateless).

        Refreshes both the per-symbol and per-industry roll-up for
        the symbol's industry, plus the universe ``"ALL"`` roll-up.
        Other industries are untouched (their members didn't change).
        """
        if engine is None:
            engine = RideEngine()

        # 1. Per-symbol refresh.
        df = panel.get(sym)
        if df is None or df.empty:
            # Symbol was removed from the panel — drop its entry too.
            self.symbol_results.pop(sym, None)
        else:
            try:
                res = engine.classify(df)
                if not res.phase.empty:
                    self.symbol_results[sym] = res
                else:
                    self.symbol_results.pop(sym, None)
            except Exception:    # noqa: BLE001
                logger.exception(
                    "RideClassificationCache.update: classify(%s) failed", sym,
                )

        # 2. Industry roll-up refresh — only for the affected industry.
        affected_industries = [
            ind for ind, members in members_by_industry.items()
            if sym in members
        ]
        for industry in affected_industries:
            members_panel = {
                s: panel[s] for s in members_by_industry[industry] if s in panel
            }
            if not members_panel:
                self.industry_results.pop(industry, None)
                continue
            try:
                res = engine.classify_industry(members_panel)
                if not res.phase.empty:
                    self.industry_results[industry] = res
                else:
                    self.industry_results.pop(industry, None)
            except Exception:    # noqa: BLE001
                logger.exception(
                    "RideClassificationCache.update: classify_industry(%s) failed",
                    industry,
                )

        # 3. Universe ``"ALL"`` roll-up — always refresh, since any
        #    symbol change affects the universe-wide aggregate.
        try:
            all_res = engine.classify_universe(panel)
            if not all_res.phase.empty:
                self.industry_results["ALL"] = all_res
            else:
                self.industry_results.pop("ALL", None)
        except Exception:    # noqa: BLE001
            logger.exception(
                "RideClassificationCache.update: classify_universe failed",
            )

    def for_symbol(self, sym: str) -> RideResult | None:
        """Return the cached result for ``sym`` or ``None`` when the
        symbol wasn't in the panel at build time."""
        return self.symbol_results.get(sym)

    def for_industry(self, industry: str) -> RideResult | None:
        """Return the cached roll-up for ``industry``. Pass
        ``"ALL"`` for the universe roll-up. ``None`` when the
        industry wasn't in the panel at build time."""
        return self.industry_results.get(industry)
