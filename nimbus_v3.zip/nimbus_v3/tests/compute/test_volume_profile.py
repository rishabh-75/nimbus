"""Tests for the reconstructed volume profile.

These pin the MECHANICS — volume conservation, the shape of the triangular
kernel, value-area construction, degenerate inputs. They do NOT claim the
profile is predictive; it is a reconstruction from daily bars and inherits
every limitation of that (see the module docstring).
"""
import numpy as np
import pandas as pd

from nimbus_v3.compute.volume_profile import (
    DEFAULT_VALUE_AREA_PCT,
    _triangular_weights,
    _value_area,
    compute_volume_profile,
)


def _frame(highs, lows, closes, vols):
    n = len(closes)
    return pd.DataFrame({
        "High": highs, "Low": lows, "Close": closes, "Volume": vols,
    }, index=pd.date_range("2025-01-01", periods=n, freq="B"))


# ── Triangular kernel ───────────────────────────────────────────────────

def test_weights_conserve_volume():
    """A bar's volume must land in the profile exactly once — no creation,
    no destruction. This is the single most important invariant: if the
    weights don't sum to 1, the whole profile is silently mis-scaled."""
    edges = np.linspace(100.0, 110.0, 51)
    w = _triangular_weights(edges, 102.0, 108.0, 105.0)
    assert abs(w.sum() - 1.0) < 1e-12


def test_weights_peak_at_typical_price():
    """The kernel is peaked at the typical price — that IS the model."""
    edges = np.linspace(100.0, 110.0, 51)
    w = _triangular_weights(edges, 102.0, 108.0, 105.0)
    centres = 0.5 * (edges[:-1] + edges[1:])
    assert abs(centres[int(np.argmax(w))] - 105.0) < 0.5


def test_weights_stay_inside_the_bar_range():
    """No volume may leak to prices the bar never traded at."""
    edges = np.linspace(100.0, 110.0, 51)
    w = _triangular_weights(edges, 102.0, 108.0, 105.0)
    outside = (edges[1:] <= 102.0) | (edges[:-1] >= 108.0)
    assert w[outside].sum() < 1e-12


def test_zero_range_bar_does_not_explode():
    """A limit-locked session (High == Low) has no range to spread across.
    It must land wholly in one bin, not produce NaN or lose its volume."""
    edges = np.linspace(100.0, 110.0, 51)
    w = _triangular_weights(edges, 105.0, 105.0, 105.0)
    assert abs(w.sum() - 1.0) < 1e-12
    assert int((w > 0).sum()) == 1
    assert np.isfinite(w).all()


# ── Value area ──────────────────────────────────────────────────────────

def test_value_area_reaches_its_target_and_is_contiguous():
    """The value area accretes outward from the POC until it holds the
    target share. It must be a contiguous BAND (a region of acceptance),
    and must actually reach the target."""
    prices = np.arange(10, dtype=float)
    volumes = np.array([1, 1, 2, 5, 20, 8, 3, 1, 1, 1], dtype=float)
    poc = int(np.argmax(volumes))          # index 4
    val, vah = _value_area(prices, volumes, poc, 0.70)
    assert val <= prices[poc] <= vah
    lo, hi = int(val), int(vah)
    share = volumes[lo:hi + 1].sum() / volumes.sum()
    assert share >= 0.70 - 1e-9


def test_value_area_grows_toward_the_denser_side():
    """At each step the band extends to whichever adjacent side holds more
    volume — so it accretes the densest available price next."""
    prices = np.arange(5, dtype=float)
    # Heavy on the RIGHT of the POC: the band should extend right first.
    volumes = np.array([1.0, 1.0, 10.0, 9.0, 1.0])
    val, vah = _value_area(prices, volumes, 2, 0.70)
    assert vah >= 3.0        # reached the dense right neighbour
    assert val >= 1.0        # did not need to go far left


# ── End to end ──────────────────────────────────────────────────────────

def test_profile_conserves_total_volume():
    """Every bar's volume must appear in the profile, summed exactly."""
    rng = np.random.default_rng(0)
    n = 80
    c = 100 * np.cumprod(1 + rng.normal(0.001, 0.015, n))
    h = c * (1 + abs(rng.normal(0, 0.01, n)))
    lo = c * (1 - abs(rng.normal(0, 0.01, n)))
    v = abs(rng.normal(1e6, 2e5, n))
    df = _frame(h, lo, c, v)

    p = compute_volume_profile(df, lookback=60)
    assert p is not None
    expected = df.tail(60)["Volume"].sum()
    assert abs(sum(p.volumes) - expected) / expected < 1e-9


def test_profile_levels_are_ordered_and_in_range():
    rng = np.random.default_rng(1)
    n = 90
    c = 100 + rng.normal(0, 2, n)
    h = c + abs(rng.normal(0, 1, n))
    lo = c - abs(rng.normal(0, 1, n))
    v = abs(rng.normal(1e6, 1e5, n))
    df = _frame(h, lo, c, v)

    p = compute_volume_profile(df, lookback=60)
    assert p is not None
    assert p.val <= p.poc <= p.vah
    assert min(lo[-60:]) <= p.val
    assert p.vah <= max(h[-60:])
    assert p.n_bars == 60
    assert p.value_area_pct == DEFAULT_VALUE_AREA_PCT


def test_poc_lands_where_the_volume_is():
    """Concentrate volume in a narrow price band and the POC must find it —
    the profile's whole job."""
    n = 60
    # 50 quiet bars near 100, then 10 heavy bars near 120.
    c = np.concatenate([np.full(50, 100.0), np.full(10, 120.0)])
    h = c + 0.5
    lo = c - 0.5
    v = np.concatenate([np.full(50, 1e5), np.full(10, 5e7)])
    df = _frame(h, lo, c, v)

    p = compute_volume_profile(df, lookback=60)
    assert p is not None
    # The POC must sit with the heavy volume, not with the many quiet bars.
    assert abs(p.poc - 120.0) < 2.0


# ── Degenerate inputs — must return None, not a misleading profile ──────

def test_none_and_empty_return_none():
    assert compute_volume_profile(None) is None
    assert compute_volume_profile(pd.DataFrame()) is None


def test_missing_columns_return_none():
    df = pd.DataFrame({"Close": [1.0, 2.0]})
    assert compute_volume_profile(df) is None


def test_zero_volume_returns_none():
    """A profile of no volume is not a profile. Better to draw nothing than
    a flat line implying structure that isn't there."""
    df = _frame([1.1, 1.2], [0.9, 1.0], [1.0, 1.1], [0.0, 0.0])
    assert compute_volume_profile(df) is None


def test_flat_price_returns_none():
    """Zero range across the whole window: no price axis to profile."""
    df = _frame([1.0] * 5, [1.0] * 5, [1.0] * 5, [1e6] * 5)
    assert compute_volume_profile(df) is None
