#!/usr/bin/env python3
"""rs_reversion_validation_probe.py — the final gate for price_over_rs, the
lone survivor of the self-referential valuation search.

WHAT SURVIVED, AND WHY IT NEEDS THIS
────────────────────────────────────
self_valuation_separation_probe cleaned three ratios; two died (price_over_
median = buy-the-dip + %B; price_over_seasonal = market-timing) and ONE
survived every cleaning: price_over_rs — price low vs the name's OWN recent
relative-strength norm, i.e. a name that has lagged its own RS trend and tends
to catch back up. It even STRENGTHENED under cleaning (raw t+1.49 → demeaned
t+3.25 → +%B-orthogonalised t+3.66), the fingerprint of real signal that was
being suppressed by the market-timing tide.

But t+3.66 is a POST-HOC survivor of a long multi-column search, and it has
never faced the one test every other finalist faced: an out-of-sample split.
This probe is that gate. Nothing here is exploratory — it is pass/fail on
pre-registered criteria, and the verdict is the HELD-OUT TEST half.

FOUR GATES (all must pass, or do not build)
───────────────────────────────────────────
  1. OUT-OF-SAMPLE SPLIT. Decile edges + the demean/%B-orthogonalise fit are
     learned on the FIRST half of dates (train); applied UNCHANGED to the
     SECOND half (test). Verdict = TEST D1−D10, date-clustered, t > 2.
     (Higher-than-usual bar acknowledged in the notes given multiple-testing;
     t > 2 is the minimum, t > 3 is 'confident'.)

  2. SUBPERIOD STABILITY. Split the panel into thirds by date; the sign must
     hold (positive D1−D10) in at least 2 of 3, and not strongly reverse in
     the third. Reversion signals are regime-dependent — a signal that only
     works in one third is a regime bet, not an edge.

  3. SEED STABILITY. The per-date-demean + orthogonalise pipeline has no RNG
     in the signal itself, but the random-key control is reseeded 8× — it
     must stay dead (|t|<2) every time. A single dead draw is not proof.

  4. COSTED EFFECT SIZE. The tradeable thing is not the D1−D10 spread — it is
     the D1 (cheap) basket's excess alone, net of a round-trip cost. Report
     gross D1 excess (per 20d, date-clustered), then haircut by COST_BPS
     round-trip and annualise. If the after-cost D1 excess is not clearly
     positive, the signal is real but not worth trading.

DISCIPLINE: date-clustered t; no lookahead (RS z uses only each name's history
before the entry bar; forward return date-grid sliced); the demean uses only
the cross-section AS OF each date; %B fit learned on train only.

Run from the dir with ./data:
    cd /Users/srishabh/Monarch/nimbus
    python nimbus_v3/rs_reversion_validation_probe.py
    python nimbus_v3/rs_reversion_validation_probe.py --selftest
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

FWD = 20
SAMPLE_EVERY = 5
ZWIN = 504
RS_WIN = 120
PCTB = "bb_20_1s_pct"
COST_BPS = 40          # round-trip cost assumption (bps) — NSE cash, incl.
                       # brokerage+STT+slippage on a liquid-ish laggard basket.
TRADES_PER_YEAR = 252 / FWD    # ~12.6 non-overlapping 20d holds/yr


def ratio_price_over_rs(df, market_close, *, win=RS_WIN):
    import numpy as np
    c = df["Close"].astype(float)
    m = market_close.reindex(c.index).ffill()
    rs = c / m.replace(0.0, np.nan)
    return rs / rs.rolling(win, min_periods=win // 2).mean()


def zscore_at(vals, i, *, win=ZWIN):
    import numpy as np
    lo = max(0, i - win)
    h = vals[lo:i]
    h = h[np.isfinite(h)]
    if len(h) < win // 3:
        return float("nan")
    mu, sd = h.mean(), h.std(ddof=1)
    return (vals[i] - mu) / sd if sd > 0 else float("nan")


def forward_excess(df, i, market_cum, *, fwd=FWD):
    import numpy as np
    if i + fwd >= len(df):
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    r = c[i + fwd] / c[i] - 1.0
    d0, d1 = df.index[i], df.index[i + fwd]
    m0, m1 = market_cum.get(d0), market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan")
    rm = m1 / m0 - 1.0
    return (r - rm) if (np.isfinite(r) and np.isfinite(rm)) else float("nan")


def clustered_mean(pairs):
    import numpy as np
    by = defaultdict(list)
    for k, x in pairs:
        if x == x:
            by[k].append(x)
    dm = [np.mean(v) for v in by.values()]
    return (float(np.mean(dm)), len(dm)) if len(dm) >= 3 else (float("nan"), len(dm))


def clustered_t(pairs):
    import numpy as np
    by = defaultdict(list)
    for k, x in pairs:
        if x == x:
            by[k].append(x)
    dm = [np.mean(v) for v in by.values()]
    if len(dm) < 3:
        return float("nan"), float("nan")
    a = np.array(dm)
    se = a.std(ddof=1)/np.sqrt(len(a))
    return float(a.mean()), (float(a.mean()/se) if se > 0 else float("nan"))


def welch(a, b):
    import numpy as np
    def dm(p):
        d = defaultdict(list)
        for k, x in p:
            if x == x:
                d[k].append(x)
        return np.array([np.mean(v) for v in d.values()])
    x, y = dm(a), dm(b)
    if len(x) < 3 or len(y) < 3:
        return float("nan")
    se = np.sqrt(x.var(ddof=1)/len(x) + y.var(ddof=1)/len(y))
    return (x.mean()-y.mean())/se if se > 0 else float("nan")


# ── signal pipeline: per-date demean, %B-orthogonalise (fit on train) ───────
def per_date_demean(rows, key_i, out_i):
    import numpy as np
    by = defaultdict(list)
    for r in rows:
        if r[key_i] == r[key_i]:
            by[r[0]].append(r[key_i])
    mean = {d: float(np.mean(v)) for d, v in by.items() if v}
    for r in rows:
        r[out_i] = (r[key_i] - mean[r[0]]) if (r[key_i] == r[key_i]
                                               and r[0] in mean) else float("nan")


def fit_pctb(rows, sig_i, pctb_i):
    import numpy as np
    xs = np.array([r[pctb_i] for r in rows])
    ys = np.array([r[sig_i] for r in rows])
    ok = np.isfinite(xs) & np.isfinite(ys)
    if ok.sum() < 50:
        return 0.0, 0.0
    x, y = xs[ok], ys[ok]
    b = np.cov(x, y, ddof=1)[0, 1] / (x.var(ddof=1) or 1.0)
    return (y.mean() - b*x.mean()), b


def apply_pctb(rows, sig_i, pctb_i, out_i, a, b):
    import numpy as np
    for r in rows:
        r[out_i] = (r[sig_i] - (a + b*r[pctb_i])) if (
            np.isfinite(r[pctb_i]) and np.isfinite(r[sig_i])) else float("nan")


def spread_and_d1(rows, key_i, edges):
    """Return (D1−D10 spread, welch_t, D1 mean, D1 clustered-t) using SUPPLIED
    decile edges (learned on train)."""
    e1, e9 = edges
    cheap = [(r[0], r[1]) for r in rows if r[key_i] == r[key_i] and r[key_i] <= e1]
    rich = [(r[0], r[1]) for r in rows if r[key_i] == r[key_i] and r[key_i] >= e9]
    cm, _ = clustered_mean(cheap)
    rm, _ = clustered_mean(rich)
    d1m, d1t = clustered_t(cheap)
    sp = (cm - rm) if (cm == cm and rm == rm) else float("nan")
    return sp, welch(cheap, rich), d1m, d1t


def learn_edges(rows, key_i):
    import numpy as np
    v = np.array([r[key_i] for r in rows if r[key_i] == r[key_i]])
    if len(v) < 20:
        return None
    return (float(np.quantile(v, 0.1)), float(np.quantile(v, 0.9)))


# row: 0 date 1 fwd 2 z_rs 3 pctb 4 demeaned 5 final
def build_rows(panel, sym_to_industry, market_close, market_cum):
    import numpy as np
    rows = []
    for sym, df in panel.items():
        if "Close" not in df.columns or len(df) < ZWIN + FWD + 30:
            continue
        rrs = ratio_price_over_rs(df, market_close).to_numpy(dtype=float)
        pctb = (df[PCTB].to_numpy(dtype=float) if PCTB in df.columns
                else np.full(len(df), np.nan))
        for i in range(ZWIN, len(df) - FWD - 1, SAMPLE_EVERY):
            fx = forward_excess(df, i, market_cum)
            if fx != fx:
                continue
            zr = zscore_at(rrs, i)
            if zr != zr:
                continue
            rows.append([df.index[i], fx, zr, pctb[i],
                         float("nan"), float("nan")])
    return rows


def pipeline(rows):
    """Demean (in place) → returns nothing; caller fits %B and applies."""
    per_date_demean(rows, 2, 4)


def build_market(panel, *, min_count=20):
    import numpy as np
    import pandas as pd
    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                sums[idx[i]] += c[i]/c[i-1] - 1.0
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    cum, acc, lvl = {}, 1.0, {}
    for d in sorted(daily):
        acc *= 1.0 + daily[d]
        cum[d] = acc
        lvl[d] = acc
    return cum, pd.Series(lvl).sort_index()


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db
    from strategy_probe import load_panel

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — run from dir with ./data", file=sys.stderr)
        return 1
    print("market + rows...", file=sys.stderr)
    market_cum, market_close = build_market(panel)
    rows = build_rows(panel, sym_to_industry, market_close, market_cum)
    per_date_demean(rows, 2, 4)     # demean uses full-date cross-sections (ok)
    print(f"rows: {len(rows)}", file=sys.stderr)

    verdict = run_all_gates(rows, seed=args.seed, verbose=True)
    print("\n" + "=" * 68)
    print("VERDICT (decided on TEST half)")
    g = verdict
    lines = [
        (f"1 out-of-sample TEST D1−D10 = {g['test_sp']*100:+.2f}%, "
         f"t = {g['test_t']:+.2f}", g["gate_oos"]),
        (f"2 subperiod signs {g['sub_signs']} "
         f"({g['sub_pos']}/3 positive)", g["gate_sub"]),
        (f"3 random-key dead all seeds (max |t| {g['rk_max']:.2f})",
         g["gate_seed"]),
        (f"4 D1 excess after {COST_BPS}bps ≈ {g['net_ann']*100:+.1f}%/yr",
         g["gate_cost"]),
    ]
    for txt, ok in lines:
        print(f"  [{'PASS' if ok else 'FAIL'}] {txt}")
    allpass = all(ok for _, ok in lines)
    print()
    if allpass:
        conf = "confident" if g["test_t"] > 3 else "marginal (t just over 2)"
        print(f"  ALL GATES PASS ({conf}). price_over_rs is a validated, out-of-")
        print("  sample, name-level RS-reversion edge, net of costs. Build the")
        print("  bounded oscillator: sign = cheap-for-its-own-RS → long bias.")
        print("  Wire it as a TIMING overlay/column on Edge, not a new ranker,")
        print("  and re-run this gate quarterly to catch regime decay.")
    else:
        print("  NOT all gates pass. Despite surviving the separation probe,")
        print("  price_over_rs does not clear out-of-sample / cost / stability.")
        print("  The t+3.66 was a post-hoc survivor that does not generalise.")
        print("  Honest end of the valuation thread: build nothing. The volume")
        print("  blow-off remains the one validated edge.")
    return 0


def run_all_gates(rows, *, seed, verbose=False):
    import numpy as np

    rng = np.random.default_rng(seed)
    dates = sorted({r[0] for r in rows})
    cut = dates[len(dates)//2]
    train = [r for r in rows if r[0] < cut]
    test = [r for r in rows if r[0] >= cut]

    # fit %B orthogonalisation on TRAIN demeaned signal, apply to both
    a, b = fit_pctb(train, 4, 3)
    apply_pctb(train, 4, 3, 5, a, b)
    apply_pctb(test, 4, 3, 5, a, b)
    edges = learn_edges(train, 5)

    tr_sp, tr_t, _, _ = spread_and_d1(train, 5, edges)
    te_sp, te_t, d1m, d1t = spread_and_d1(test, 5, edges)
    if verbose:
        print(f"\n─── GATE 1: out-of-sample split ───")
        print(f"  TRAIN  D1−D10 {tr_sp*100:+.2f}%  t {tr_t:+.2f}  (in-sample)")
        print(f"  TEST   D1−D10 {te_sp*100:+.2f}%  t {te_t:+.2f}  (VERDICT)")

    # GATE 2: thirds
    n = len(dates)
    t1, t2 = dates[n//3], dates[2*n//3]
    signs, pos = [], 0
    if verbose:
        print(f"\n─── GATE 2: subperiod stability (thirds) ───")
    for lab, lo, hi in [("early", dates[0], t1), ("mid", t1, t2),
                        ("late", t2, dates[-1])]:
        sub = [r for r in rows if lo <= r[0] <= hi]
        e = learn_edges(sub, 5) if any(r[5] == r[5] for r in sub) else None
        # signal already computed on full set via train fit; reuse col 5
        sp, t, _, _ = spread_and_d1(sub, 5, edges) if edges else (float("nan"),)*4
        signs.append(1 if sp > 0 else (-1 if sp < 0 else 0))
        if sp > 0:
            pos += 1
        if verbose:
            print(f"  {lab:5}: D1−D10 {sp*100:+.2f}%  t {t:+.2f}")

    # GATE 3: random-key across seeds
    rk_max = 0.0
    for s in range(8):
        r2 = np.random.default_rng(2000+s)
        rk = [r[:] for r in test]
        ks = [r[5] for r in rk]
        r2.shuffle(ks)
        for r, k in zip(rk, ks):
            r[5] = k
        _, t, _, _ = spread_and_d1(rk, 5, edges)
        if t == t:
            rk_max = max(rk_max, abs(t))
    if verbose:
        print(f"\n─── GATE 3: random-key dead across 8 seeds ───")
        print(f"  max |t| over seeds = {rk_max:.2f} (must be < 2)")

    # GATE 4: costed D1 excess (test)
    cost = COST_BPS / 1e4
    net_per_trade = d1m - cost
    net_ann = net_per_trade * TRADES_PER_YEAR
    if verbose:
        print(f"\n─── GATE 4: costed effect size (TEST D1 basket) ───")
        print(f"  gross D1 excess/20d  {d1m*100:+.2f}%  (t {d1t:+.2f})")
        print(f"  − round-trip {COST_BPS}bps → net/20d {net_per_trade*100:+.2f}%"
              f"  → ~{net_ann*100:+.1f}%/yr over ~{TRADES_PER_YEAR:.0f} holds")

    return {
        "test_sp": te_sp, "test_t": te_t,
        "gate_oos": (te_sp > 0 and te_t > 2),
        "sub_signs": signs, "sub_pos": pos,
        "gate_sub": (pos >= 2 and min(signs) >= 0 if signs else False)
                    or (pos >= 2 and signs.count(-1) == 0),
        "rk_max": rk_max, "gate_seed": rk_max < 2,
        "d1_gross": d1m, "net_ann": net_ann,
        "gate_cost": net_per_trade > 0 and d1t > 2,
    }


def _selftest(args):
    """Two worlds:
      A) STABLE edge present in BOTH halves and all thirds, %B-independent,
         net-positive after cost → ALL gates pass.
      B) IN-SAMPLE-ONLY edge (train half only) → GATE 1 fails on test.
    """
    import numpy as np
    import pandas as pd

    dates = pd.bdate_range("2015-01-01", periods=1600)
    cut = dates[len(dates)//2]

    def synth(stable):
        rng = np.random.default_rng(args.seed)
        edates = dates[::4]
        tide = {d: rng.normal(0, 1) for d in edates}
        rows = []
        for d in edates:
            for s in range(80):
                name_z = rng.normal(0, 1)
                z = tide[d] + name_z
                pctb = 0.5 + rng.normal(0, 0.15)
                if stable or d < cut:
                    fwd = -0.010 * name_z + rng.normal(0, 0.04)
                else:
                    fwd = rng.normal(0, 0.04)
                rows.append([d, fwd, z, pctb, float("nan"), float("nan")])
        return rows

    print("### A: stable edge (should PASS all gates) ###")
    A = synth(True)
    per_date_demean(A, 2, 4)
    ga = run_all_gates(A, seed=args.seed, verbose=True)

    print("\n### B: train-only edge (GATE 1 should FAIL on test) ###")
    B = synth(False)
    per_date_demean(B, 2, 4)
    gb = run_all_gates(B, seed=args.seed, verbose=True)

    A_all = (ga["gate_oos"] and ga["gate_sub"] and ga["gate_seed"]
             and ga["gate_cost"])
    B_fail = not gb["gate_oos"]
    print("\n" + "=" * 68)
    print(f"A stable passes ALL four gates:     {A_all}  "
          f"(oos {ga['gate_oos']} sub {ga['gate_sub']} "
          f"seed {ga['gate_seed']} cost {ga['gate_cost']})")
    print(f"B train-only fails OOS gate:        {B_fail}")
    ok = A_all and B_fail
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
