"""Tests for the Market Pulse research-report generator."""
from nimbus_v3.compute import market_pulse_config as cfg
from nimbus_v3.compute.confluence import (
    ConfluenceResult,
    ConfluenceRow,
    FactorRead,
)
from nimbus_v3.compute.equity_edge import EdgeResult, SymbolEdge
from nimbus_v3.compute.industry_rotation import (
    IndustryRotation,
    RotationResult,
)
from nimbus_v3.compute.industry_seasonality import (
    IndustrySeasonality,
    SeasonalityGrid,
)
from nimbus_v3.compute.market_pulse_report import generate_report


def _conf():
    row = ConfluenceRow(
        industry="Pharmaceuticals", score=48.4, confidence=0.54,
        strength=FactorRead(13.4, 88.0, 1.0, ""),
        direction=FactorRead(0.0, 90.0, 1.0, "Leading · Fresh"),
        seasonal=FactorRead(6.5, 84.0, 0.50, ""),
        n_members=32, breadth=0.72, breadth_gate=1.0)
    return ConfluenceResult(
        rows=(row,), month=7, regime_label="NEUTRAL",
        regime_signals_on=3, regime_n_signals=5)


def _rot():
    return RotationResult(
        industries=(IndustryRotation("Pharmaceuticals", (), (), 13.4, 32),),
        lookback=20)


def _edge():
    e = SymbolEdge(
        symbol="CIPLA", industry="Pharmaceuticals",
        expected_edge=1.2, reward_to_risk=0.55,
        industry_rs_excess=8.0, trust=0.54, member_shift=0.3,
        atr_pct=2.1, adtv=5e10, liquidity_gate=1.0,
        chg_1d=0.9, chg_5d=3.2, chg_10d=6.5)
    return EdgeResult(rows=(e,), horizon_days=20, kappa=0.30)


def _seas():
    nan = float("nan")
    avg = [nan] * 12; avg[6] = 6.5
    hit = [nan] * 12; hit[6] = 70.0
    std = [nan] * 12; std[6] = 3.0
    qual = [nan] * 12; qual[6] = 0.6
    cnm = [0] * 12; cnm[6] = 30
    row = IndustrySeasonality(
        "Pharmaceuticals", tuple(avg), tuple(hit), tuple(std),
        (nan,) * 12, (0.0,) * 12, tuple(cnm), tuple(qual), 5, 32, True)
    return SeasonalityGrid(rows=(row,))


def test_report_is_wellformed_markdown():
    rep = generate_report(
        _conf(), _rot(), _edge(), _seas(), month=7,
        universe_size=571, market_breadth=0.61, data_asof="2025-07-08")
    # Has all the major sections.
    assert "# Nimbus · Market Pulse Research Report" in rep
    assert "## 1 · Market regime" in rep
    assert "## 2 · Confluence" in rep
    assert "## 3 · Edge" in rep
    assert "## 4 · Seasonality" in rep
    assert "## 5 · Parameters appendix" in rep
    # Header facts present.
    assert "571 symbols" in rep
    assert "NEUTRAL" in rep
    # The data rows made it in.
    assert "Pharmaceuticals" in rep
    assert "CIPLA" in rep
    # Honest labelling present.
    assert "NOT a valuation risk premium" in rep


def test_report_parameters_reflect_config():
    """The appendix must echo the LIVE config constants, so the report is
    reproducible and the numbers auditable against what generated them."""
    rep = generate_report(
        _conf(), _rot(), _edge(), _seas(), month=7,
        universe_size=100)
    assert f"{cfg.STRENGTH_LOOKBACK}d" in rep
    assert f"{cfg.RRG_LOOKBACK}d" in rep
    assert f"{cfg.EDGE_PERSISTENCE_KAPPA:.2f}" in rep
    assert f"{cfg.EDGE_LIQUIDITY_FLOOR:.2f}" in rep
    # ADTV bounds rendered in crore.
    assert f"₹{cfg.EDGE_ADTV_FLOOR / 1e7:.0f}cr" in rep


def test_report_handles_empty_gracefully():
    """A confluence/edge with no rows still yields a valid document."""
    empty_conf = ConfluenceResult(
        rows=(), month=7, regime_label="—",
        regime_signals_on=0, regime_n_signals=0)
    empty_edge = EdgeResult(rows=(), horizon_days=20, kappa=0.30)
    empty_rot = RotationResult(industries=(), lookback=20)
    rep = generate_report(
        empty_conf, empty_rot, empty_edge, SeasonalityGrid(rows=()),
        month=7, universe_size=0)
    assert "# Nimbus · Market Pulse Research Report" in rep
    assert "## 5 · Parameters appendix" in rep


def test_report_hit_rate_not_double_scaled():
    """hit_rates are stored 0..100; the report must NOT multiply by 100
    again (the '10000' bug). July hit for the test row is 70."""
    rep = generate_report(
        _conf(), _rot(), _edge(), _seas(), month=7, universe_size=10)
    seas = rep.split("## 4")[1].split("## 5")[0]
    assert "70" in seas          # the stored hit rate, shown as-is
    assert "7000" not in seas    # not double-scaled


def test_report_seasonality_only_confluence_industries():
    """The seasonality section must not list industries absent from the
    confluence ranking (e.g. sub-MIN_MEMBERS industries) — the two
    sections describe the same board."""
    nan = float("nan")

    def seas_row(name):
        avg = [nan] * 12; avg[6] = 4.0
        hit = [nan] * 12; hit[6] = 60.0
        std = [nan] * 12; std[6] = 3.0
        qual = [nan] * 12; qual[6] = 0.4
        cnm = [0] * 12; cnm[6] = 8
        return IndustrySeasonality(
            name, tuple(avg), tuple(hit), tuple(std), (nan,) * 12,
            (0.0,) * 12, tuple(cnm), tuple(qual), 5, 8, True)

    # Confluence has only "Ranked"; seasonality grid also carries "Orphan".
    grid = SeasonalityGrid(rows=(seas_row("Pharmaceuticals"),
                                 seas_row("Orphan")))
    rep = generate_report(
        _conf(), _rot(), _edge(), grid, month=7, universe_size=10)
    seas = rep.split("## 4")[1].split("## 5")[0]
    assert "Pharmaceuticals" in seas
    assert "Orphan" not in seas
