"""Single source of truth for the Market Pulse / Confluence horizons.

The whole Market Pulse tab — the ROC (strength) view, the RRG (direction)
view, and the Confluence read that gates one against the other — must agree
on *what horizon* each factor is measured over. If the ROC sub-tab showed a
60-day trend while Confluence ranked on a 20-day one, clicking from the
ranked list into the breakdown would show inconsistent numbers, and the
"strength" being gated wouldn't be the "strength" on screen.

So every consumer imports these constants rather than hard-coding its own
default. Strength and direction are decoupled on purpose — they measure
different things and want different horizons:

* **STRENGTH** (the ROC ranking window) is the rotation-speed dial. A short
  window (20d ≈ a month) catches emerging leaders quickly, at the cost of
  more whipsaw than a full-quarter trend. This is the knob to turn when you
  want faster or slower rotation.

* **DIRECTION** (the RRG RS-series window) is held longer (50d) so the RS
  series has enough runway for a stable momentum + tail-slope fit. Note the
  direction *signal* itself is governed by the RRG momentum / slope
  constants in :mod:`nimbus_v3.compute.rrg` (``MOM_LOOKBACK``, tail length),
  not this window — this only decides how much RS history feeds them, so
  direction stays responsive regardless of how the strength dial is set.

Changing rotation speed is therefore a one-line edit here that the entire
Market Pulse tab and the Confluence engine pick up together.
"""
from __future__ import annotations

#: ROC window (trading days) for the STRENGTH factor — the rotation-speed
#: dial. Shorter = faster/twitchier, longer = established-trend.
STRENGTH_LOOKBACK: int = 20

#: RS-series window (trading days) for the DIRECTION (RRG) factor. Held
#: long enough for a stable slope fit; the direction signal's actual
#: horizon is set by the RRG momentum/slope constants, not this.
RRG_LOOKBACK: int = 50

#: Selectable horizons (trading days) for the Edge view's expected-edge
#: window. Each is a full recompute — the industry composite ROC and the
#: benchmark return are both measured over the SAME window — so switching
#: changes the reading rather than merely relabelling it.
#: Lives here, beside the other lookbacks, so the engine and the view share
#: one definition and cannot drift.
#: 5d was dropped: the ride-length work showed median hold ~3 days, so a
#: 5-day edge sat inside the typical trade rather than describing its
#: outcome, and it added noise without a distinct read. 10 and 20 bracket
#: the useful range.
EDGE_HORIZONS: tuple[int, ...] = (10, 20)

#: The horizon shown first, and the one the Market Pulse report pins to.
#: 10d is the default: the faster of the two, matched to the timescale the
#: names on the board actually move on. Deliberately DECOUPLED from
#: STRENGTH_LOOKBACK (20) — that constant still drives the ROC breakdown
#: tab and the report's rotation-speed label, which are a separate, slower
#: read from the edge horizon the operator rotates on.
DEFAULT_EDGE_HORIZON: int = 10

# ── Momentum-implied edge model ─────────────────────────────────────────
# The edge engine turns confluence into a per-symbol EXPECTED EXCESS EDGE
# (in horizon-period %) and a reward-to-risk rank. See
# nimbus_v3.compute.equity_edge for the full derivation. These are the
# tunables.

#: Persistence haircut κ ∈ (0,1]. Trailing relative strength massively
#: OVERSTATES expected forward return — momentum mean-reverts. κ shrinks
#: the measured RS toward zero so "expected" is a defensible label rather
#: than an extrapolation of the past. Empirical momentum persistence is
#: low, so κ is small: only ~30% of the trailing relative move is assumed
#: to carry forward. RAISE toward 1 to trust momentum more; LOWER to assume
#: more reversion. This is the single biggest dial on the edge magnitude.
EDGE_PERSISTENCE_KAPPA: float = 0.30

#: How strongly a member's own relative strength (vs its industry
#: composite) tilts its share of the industry edge. 0 = every member gets
#: the plain industry edge; 1 = full tilt (a leader gets much more, a
#: laggard much less). Kept modest — within-industry RS is noisier than the
#: industry signal, so we don't want member noise to dominate.
EDGE_MEMBER_TILT: float = 0.5

#: Floor on ATR% used as the reward-to-risk denominator, so a freakishly
#: low-vol symbol can't produce a divide-by-near-zero blow-up in the ratio.
EDGE_MIN_ATR_PCT: float = 0.5

#: Liquidity gate — an EXECUTABILITY haircut on the edge. An edge you can't
#: trade at size is a phantom: a thin name may show a huge reward-to-risk
#: that's fiction because you'd move the price entering, or couldn't exit.
#: So a thin name's edge is shrunk toward zero — the same "we don't trust
#: you can realise this" logic as the confluence trust gate, kept SEPARATE
#: from the ATR% risk denominator (ATR% is price risk; liquidity is
#: executability — conflating them would double-count).
#:
#: Unlike breadth, this reference is ABSOLUTE, not market-relative:
#: tradeability is a hard fact about rupees/day, not a ranking. A name
#: trading ₹2cr/day is thin whether or not the rest of the universe is
#: thinner. The floor/ceiling are set to discriminate ACROSS the tradeable
#: NSE mid-cap range: at ₹15cr the gate begins to bite and it reaches full
#: credit at ₹200cr. (An earlier ₹100cr floor floored most of the mid-cap
#: universe at one value, letting liquidity substitute for edge in the
#: ranking — these lower bounds keep the gate discriminating instead of
#: acting as a blanket mid-cap penalty.)
#:
#:     x    = clamp((log ADTV − log FLOOR) / (log CEIL − log FLOOR), 0, 1)
#:     gate = LIQ_FLOOR + (1 − LIQ_FLOOR) · x
#:
#: at/above the ADTV ceiling → gate 1.0 (fully tradeable, no discount);
#: at/below the floor → gate = LIQ_FLOOR (edge crushed); log-scaled between.
#: LIQ_FLOOR is harder than the breadth floor (a narrow move might broaden,
#: but an untradeable name is untradeable *now*): a fully-thin name loses
#: ~65% of its edge.
EDGE_ADTV_FLOOR: float = 1.5e8   # ₹15cr — below this, fully "thin"
EDGE_ADTV_CEILING: float = 2e9   # ₹200cr — at/above this, no discount
EDGE_LIQUIDITY_FLOOR: float = 0.35

# ── Member-confirmation gate ────────────────────────────────────────────
# WHAT IT DOES. Discounts the edge of a member showing no sign of actually
# PARTICIPATING in its industry's move:
#
#     confirmation = FLOOR + (1-FLOOR) · max(streak_sc, vol_sc, thrust_sc)
#     μ̂ ← μ̂ · confirmation
#
# ``max(...)`` is deliberate — a name qualifies by being EITHER a sustained
# rider (long band-ride streak) OR a fresh explosive move (volume surge /
# short-term thrust). Both are genuine participation and they look nothing
# alike. The name that is NEITHER is the one being demoted.
#
# WHY IT EXISTS. ``industry_edge = κ·RS_excess·trust`` is IDENTICAL for
# every member of an industry; only the small member_shift varies. So
# within an industry the reward-to-risk ranking collapses to roughly
# ``1/ATR%`` — it promotes the QUIETEST name in a hot sector. Observed
# live: PGEL ranked #2 on the board at 0.40× volume, streak 1, going
# sideways in a range.
#
# ─────────────────────────────────────────────────────────────────────────
# EMPIRICAL STATUS — READ THIS BEFORE TRUSTING THE RANKING
#
# This gate is NOT VALIDATED. It makes the board *look* more sensible; it
# has NO demonstrated ability to predict forward returns.
#
# Two independent walk-forward tests (10 and 15 as-of dates, 20d and 10d
# horizons, scored against forward EXCESS return over ^CRSLDX):
#
#   * The gate moved rank-correlation vs forward excess return by ~0.002
#     (e.g. -0.020 → -0.018). Statistically indistinguishable from zero.
#   * NO variant of the edge model — any tilt, any ranking denominator,
#     gate on or off — achieved positive rank-correlation.
#   * Every raw ingredient (rs_excess, streak, vol_ratio, chg_5d, chg_10d,
#     1/ATR) scored at or BELOW a random-number control.
#
# The single-date result that originally motivated this (rho 0.04 → 0.66)
# did not replicate; it was over-fitted to one snapshot.
#
# WHAT IT IS THEREFORE FOR: making the Edge tab a more honest DESCRIPTIVE
# surface — surfacing the names that are actually moving rather than the
# quietest name in a hot sector. Treat the ordering as rotation CONTEXT for
# a discretionary decision, NOT as an alpha signal for sizing or selection.
#
# Set EDGE_CONFIRMATION_ENABLED = False to restore the pre-gate ranking.
# See scripts edge_rerank.py / edge_experiment.py to re-run the evidence.
# ─────────────────────────────────────────────────────────────────────────

#: Master switch. False restores the exact pre-gate ranking.
EDGE_CONFIRMATION_ENABLED: bool = True

#: Edge retained by a wholly unconfirmed name (no ride, no volume, no
#: thrust). Well below 1 so non-participants are genuinely demoted, but not
#: 0 — the industry signal is still real, we just can't see the stock
#: acting on it yet.
EDGE_CONFIRM_FLOOR: float = 0.40

#: Band-ride streak (bars) at which the persistence component saturates.
EDGE_CONFIRM_STREAK_FULL: float = 10.0

#: Volume ratio (latest / 20-bar mean) below which volume contributes
#: nothing, and the span over which it then saturates.
EDGE_CONFIRM_VOL_BASE: float = 0.70
EDGE_CONFIRM_VOL_SPAN: float = 1.50

#: 5-day move measured in ATR units; this many ATRs = full thrust score.
EDGE_CONFIRM_THRUST_FULL: float = 4.0

#: Volume ratio at which CONFIRMATION stops accruing. Above this the volume
#: term no longer counts as evidence the name is participating — it is
#: measured separately as a blowoff (see EDGE_BLOWOFF_* below).
#:
#: Measured, not guessed. A disjoint-band sweep over 1,242 trading days /
#: 481 symbols (~87k observations) gives 5-day forward EXCESS return by
#: vol_ratio band:
#:
#:     1.00-1.25x   +0.09%  (t  2.0)
#:     1.25-1.50x   +0.13%  (t  2.2 *)   <- confirmation is REAL here
#:     1.50-2.00x   +0.02%  (t  0.3)
#:     2.00-3.00x   -0.03%  (t -0.4)     <- the sign turns over
#:     3.00-5.00x   -0.27%  (t -2.3 *)   <- distribution
#:     >= 5.00x     -0.85%  (t -5.1 *)   <- heavy distribution
#:
#: So a MILD pickup is confirmation; a BLOWOFF is the opposite. The old gate
#: treated every level as confirmation, which actively rewarded the worst
#: cohort on the board.
EDGE_CONFIRM_VOL_CAP: float = 3.0

# ── Volume-blowoff penalty ──────────────────────────────────────────────
# A SEPARATE haircut, not merely a truncated confirmation. It has to be
# separate because a blowoff name may ALSO have a long streak or strong
# thrust — and ``max(streak, vol, thrust)`` would then keep its confirmation
# high regardless. The penalty must bite the edge independently of what the
# other tells are saying.
#
#     blowoff = 1 - (1 - FLOOR) * clamp((vol_ratio - START) / SPAN, 0, 1)
#     mu_hat <- mu_hat * blowoff
#
# STATUS — the empirical basis is the strongest we have found in this app.
# It is the ONE signal that cleared the noise floor: t = -5.1 at >=5x, with a
# clean monotonic dose-response (mild positive -> flat -> negative -> heavily
# negative). A data-mined artefact has no reason to line up in order of
# intensity like that.
#
# BUT THE MAGNITUDE IS SMALL: -0.85% over 5 days at >=5x. After brokerage,
# STT and slippage — on a name that just traded 5x normal volume, i.e. wide
# spreads and adverse fills — that edge is largely gone. Treat this as a
# CAUTION FLAG that stops the board promoting blowoffs, NOT as a tradeable
# short signal. It is here to prevent a bad ranking, not to create a good one.

#: Set False to disable the penalty (restores the pre-penalty ranking).
EDGE_BLOWOFF_ENABLED: bool = True

#: vol_ratio at which the penalty starts biting. Below this, nothing.
EDGE_BLOWOFF_START: float = 3.0

#: vol_ratio span over which the penalty ramps to its floor. START + SPAN
#: = 6.0x, a little past the >=5x band where the effect is strongest.
EDGE_BLOWOFF_SPAN: float = 3.0

#: Edge retained by a full blowoff. Not 0 — the effect is real but SMALL
#: (-0.85% over 5d), so a total wipe-out would overstate it. 0.55 keeps the
#: name on the board while pushing it well down the ranking.
EDGE_BLOWOFF_FLOOR: float = 0.55

