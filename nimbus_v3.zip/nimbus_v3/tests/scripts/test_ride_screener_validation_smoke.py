"""Smoke test for run_ride_screener_validation.py.

Limited to import-check + helper sanity. Full run requires a
populated equity cache (sandbox doesn't have one).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


class TestImports:

    def test_script_imports_cleanly(self):
        """Just importing the script catches column-name typos,
        missing imports, etc."""
        from scripts import run_ride_screener_validation
        # Validate key public symbols exist
        assert hasattr(run_ride_screener_validation, "main")
        assert hasattr(run_ride_screener_validation, "_check_positive_example")
        assert hasattr(run_ride_screener_validation, "_check_failure_example")

    def test_calibration_set_well_formed(self):
        """Confirm the example sets are non-empty and properly typed."""
        from scripts.run_ride_screener_validation import (
            _POSITIVE_EXAMPLES, _FAILURE_EXAMPLES,
        )
        assert len(_POSITIVE_EXAMPLES) >= 4
        assert len(_FAILURE_EXAMPLES) >= 4
        # Each positive: (sym, date_str)
        for sym, date_str in _POSITIVE_EXAMPLES:
            assert isinstance(sym, str) and len(sym) > 0
            # Date parses
            pd.Timestamp(date_str)
        # Each failure: (sym, date_str, mode)
        for sym, date_str, mode in _FAILURE_EXAMPLES:
            assert isinstance(sym, str) and len(sym) > 0
            pd.Timestamp(date_str)
            assert isinstance(mode, str) and len(mode) > 0

    def test_no_undefined_uppercase_names(self):
        """AST-based scan: every UPPERCASE identifier loaded must
        be imported, defined locally, or be a builtin. Catches
        stale references from renamed constants that import smoke
        tests miss (since Python only resolves function-body
        names at call time)."""
        import ast

        script_path = _ROOT / "scripts" / "run_ride_screener_validation.py"
        with open(script_path) as f:
            tree = ast.parse(f.read())

        module_names: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    module_names.add(alias.asname or alias.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    module_names.add(alias.asname or alias.name.split(".")[0])

        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                module_names.add(node.name)
            elif isinstance(node, ast.ClassDef):
                module_names.add(node.name)
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        module_names.add(target.id)
            elif isinstance(node, ast.AnnAssign) and isinstance(
                node.target, ast.Name,
            ):
                module_names.add(node.target.id)

        referenced: set[str] = set()
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Name)
                and isinstance(node.ctx, ast.Load)
                and node.id.isupper()
                and not node.id.startswith("_")
            ):
                referenced.add(node.id)

        builtins = {"True", "False", "None"}
        unresolved = referenced - module_names - builtins
        assert not unresolved, (
            f"Validation script references UPPERCASE names that "
            f"aren't imported or defined: {sorted(unresolved)}. "
            f"Likely a stale reference from a renamed constant."
        )
