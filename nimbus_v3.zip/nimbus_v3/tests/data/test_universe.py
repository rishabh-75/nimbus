"""Tests for nimbus_v3.data.universe.UniverseBuilder.

All NSE I/O is mocked via a stand-in client that returns prepared payloads
keyed by (url, referer, params). The goal is to prove the builder
composes, deduplicates, and attributes correctly — not to test NSE
itself.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pytest

from nimbus_v3.core.universe import ETFMeta, Universe
from nimbus_v3.data.universe import (
    UniverseBuildError,
    UniverseBuilder,
    UniverseConfig,
    _extract_etfs,
    _extract_fno_symbols,
    _extract_index_constituents,
)


# ══════════════════════════════════════════════════════════════════════════════
# Minimal mock NSE client
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class _MockNSE:
    """Stand-in for NSEClient. Returns payloads by key; otherwise returns
    ``None`` so the builder's failure path is exercised."""
    payloads: dict[tuple[str, str | None], object] = field(default_factory=dict)
    calls: list[tuple[str, str, dict | None]] = field(default_factory=list)

    def fetch(self, url, *, referer, params=None, extra_headers=None):  # noqa: ANN001, ARG002
        self.calls.append((url, referer, params))
        # Key: (url, index-name from params) or (url, None).
        idx = params.get("index") if params else None
        return self.payloads.get((url, idx))


def _index_payload(rows: list[tuple[str, str]]) -> dict:
    """Synthesise a minimal stockIndices response matching real NSE shape."""
    return {"data": [
        {"symbol": sym, "meta": {"symbol": sym, "industry": ind}}
        for sym, ind in rows
    ]}


def _fno_payload(symbols: list[str]) -> dict:
    return {"data": [{"symbol": s} for s in symbols]}


def _etf_payload(rows: list[dict]) -> dict:
    return {"data": rows}


# ══════════════════════════════════════════════════════════════════════════════
# Parser unit tests
# ══════════════════════════════════════════════════════════════════════════════

def test_extract_index_constituents_filters_synthetic_index_row() -> None:
    payload = {"data": [
        {"symbol": "NIFTY 50", "meta": {}},                           # synthetic, skipped
        {"symbol": "RELIANCE", "meta": {"symbol": "RELIANCE",
                                         "industry": "Refineries"}},
        {"symbol": "tcs", "meta": {"symbol": "tcs",
                                    "industry": "Computers - Software"}},
        {"meta": {"industry": "Banks"}},                               # missing symbol, skipped
        "not a dict",                                                   # skipped
    ]}
    out = _extract_index_constituents(payload)
    assert out == [("RELIANCE", "Refineries"), ("TCS", "Computers - Software")]


def test_extract_fno_symbols_both_payload_shapes() -> None:
    dict_shape = {"data": [{"symbol": "RELIANCE"}, {"symbol": "TCS"}]}
    list_shape = [{"symbol": "HDFC"}]
    assert _extract_fno_symbols(dict_shape) == ["RELIANCE", "TCS"]
    assert _extract_fno_symbols(list_shape) == ["HDFC"]
    assert _extract_fno_symbols("garbage") == []


def test_extract_etfs_parses_and_handles_missing_fields() -> None:
    payload = {"data": [
        {
            "symbol": "NIFTYBEES",
            "underlying": "Nifty 50",
            "assetsUnderManagement": "12,345.67",
        },
        {
            "symbol": "BANKBEES",
            # no AUM / underlying
        },
        {"not_a_symbol": "skip me"},   # row without symbol → skipped
    ]}
    out = _extract_etfs(payload)
    assert len(out) == 2
    nb_sym, nb_meta = out[0]
    assert nb_sym == "NIFTYBEES"
    assert nb_meta.underlying_asset == "Nifty 50"
    assert nb_meta.aum_crore == pytest.approx(12345.67)
    bb_sym, bb_meta = out[1]
    assert bb_sym == "BANKBEES"
    assert bb_meta.aum_crore is None
    assert bb_meta.underlying_asset is None


# ══════════════════════════════════════════════════════════════════════════════
# Builder end-to-end (mocked NSE)
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def minimal_config() -> UniverseConfig:
    return UniverseConfig(
        broad_indices=("NIFTY 50", "NIFTY 500"),
        sectoral_indices=(
            ("NIFTY BANK", "Banking"),
            ("NIFTY IT", "Information Technology"),
        ),
        include_fno=True,
        include_etfs=True,
        index_endpoint="https://test/api/idx",
        index_referer="https://test/ref-idx",
        fno_endpoint="https://test/api/fno",
        fno_referer="https://test/ref-fno",
        etf_endpoint="https://test/api/etf",
        etf_referer="https://test/ref-etf",
    )


def test_build_composes_indices_and_dedupes(minimal_config: UniverseConfig) -> None:
    nse = _MockNSE(payloads={
        ("https://test/api/idx", "NIFTY 50"): _index_payload([
            ("RELIANCE", "Refineries"),
            ("TCS", "Computers - Software"),
            ("HDFCBANK", "Banks"),
        ]),
        ("https://test/api/idx", "NIFTY 500"): _index_payload([
            ("RELIANCE", "Refineries"),
            ("IDEA", "Telecom - Services"),
        ]),
        ("https://test/api/idx", "NIFTY BANK"): _index_payload([
            ("HDFCBANK", "Banks"),
        ]),
        ("https://test/api/idx", "NIFTY IT"): _index_payload([
            ("TCS", "Computers - Software"),
        ]),
        ("https://test/api/fno", None): _fno_payload(
            ["RELIANCE", "TCS", "HDFCBANK"]
        ),
        ("https://test/api/etf", None): _etf_payload([
            {"symbol": "NIFTYBEES", "underlying": "Nifty 50"},
        ]),
    })

    builder = UniverseBuilder(nse, minimal_config)  # type: ignore[arg-type]
    universe = builder.build()

    assert isinstance(universe, Universe)
    # 4 equities + 1 ETF.
    assert len(universe) == 5

    r = universe.symbols["RELIANCE"]
    assert r.indices == frozenset({"NIFTY 50", "NIFTY 500"})
    assert r.industry == "Refineries"
    assert r.is_fno is True
    assert r.is_etf is False
    # RELIANCE was in no sectoral index → sector stays Unknown.
    assert r.sector == "Unknown"

    hb = universe.symbols["HDFCBANK"]
    assert "NIFTY BANK" in hb.indices
    assert hb.sector == "Banking"
    assert hb.is_fno is True

    tcs = universe.symbols["TCS"]
    assert tcs.sector == "Information Technology"

    idea = universe.symbols["IDEA"]
    assert idea.indices == frozenset({"NIFTY 500"})
    assert idea.is_fno is False
    assert idea.sector == "Unknown"

    etf = universe.symbols["NIFTYBEES"]
    assert etf.is_etf is True
    assert etf.is_fno is False
    assert etf.etf_meta is not None
    assert etf.etf_meta.underlying_asset == "Nifty 50"


def test_build_raises_when_every_fetch_fails(minimal_config: UniverseConfig) -> None:
    """Zero successful endpoints → UniverseBuildError."""
    nse = _MockNSE(payloads={})  # nothing registered → every fetch returns None
    builder = UniverseBuilder(nse, minimal_config)  # type: ignore[arg-type]
    with pytest.raises(UniverseBuildError):
        builder.build()


def test_build_tolerates_partial_failure(minimal_config: UniverseConfig) -> None:
    """If only a subset of endpoints respond, the builder continues and
    emits a partial universe rather than raising."""
    nse = _MockNSE(payloads={
        ("https://test/api/idx", "NIFTY 50"): _index_payload([
            ("RELIANCE", "Refineries"),
        ]),
        # Every other endpoint returns None.
    })
    builder = UniverseBuilder(nse, minimal_config)  # type: ignore[arg-type]
    universe = builder.build()
    assert len(universe) == 1
    assert "RELIANCE" in universe


def test_builder_honors_disable_fno_and_etf(minimal_config: UniverseConfig) -> None:
    """When ``include_fno`` or ``include_etfs`` is False, those endpoints
    must not be called even if they would succeed."""
    cfg = UniverseConfig(
        broad_indices=minimal_config.broad_indices,
        sectoral_indices=minimal_config.sectoral_indices,
        include_fno=False,
        include_etfs=False,
        index_endpoint=minimal_config.index_endpoint,
        index_referer=minimal_config.index_referer,
        fno_endpoint=minimal_config.fno_endpoint,
        fno_referer=minimal_config.fno_referer,
        etf_endpoint=minimal_config.etf_endpoint,
        etf_referer=minimal_config.etf_referer,
    )
    nse = _MockNSE(payloads={
        ("https://test/api/idx", "NIFTY 50"): _index_payload([("RELIANCE", "Refineries")]),
    })
    builder = UniverseBuilder(nse, cfg)  # type: ignore[arg-type]
    _ = builder.build()
    fetched_urls = {c[0] for c in nse.calls}
    assert "https://test/api/fno" not in fetched_urls
    assert "https://test/api/etf" not in fetched_urls


def test_narrower_sectoral_wins_over_broader(minimal_config: UniverseConfig) -> None:
    """Listing narrower sectors first is documented behaviour. Verify a
    symbol in both NIFTY PSU BANK and NIFTY BANK is classified as PSU
    Banking.

    We override the config to list PSU BANK first (which is the default
    production order per universe.py::_DEFAULT_SECTORAL_INDICES).
    """
    cfg = UniverseConfig(
        broad_indices=(),
        sectoral_indices=(
            ("NIFTY PSU BANK", "PSU Banking"),
            ("NIFTY BANK", "Banking"),
        ),
        include_fno=False,
        include_etfs=False,
        index_endpoint="https://test/api/idx",
        index_referer="https://test/ref",
        fno_endpoint="https://test/api/fno",
        fno_referer="https://test/ref-fno",
        etf_endpoint="https://test/api/etf",
        etf_referer="https://test/ref-etf",
    )
    nse = _MockNSE(payloads={
        ("https://test/api/idx", "NIFTY PSU BANK"): _index_payload(
            [("SBIN", "Banks")]
        ),
        ("https://test/api/idx", "NIFTY BANK"): _index_payload(
            [("SBIN", "Banks")]
        ),
    })
    builder = UniverseBuilder(nse, cfg)  # type: ignore[arg-type]
    universe = builder.build()
    sbin = universe.symbols["SBIN"]
    assert sbin.sector == "PSU Banking"
    assert sbin.indices == frozenset({"NIFTY PSU BANK", "NIFTY BANK"})
