"""Extract fire events from one symbol's enriched panel + RideResult.

Each fire produces a :class:`FireEvent` carrying (a) outcome —
how long the ride held above the upper band, what the realised
return was, and (b) a feature snapshot at trigger time.

Look-ahead-safety
─────────────────
Two distinct directions:

  - **Outcome** (return_pct, hold_bars, exit_idx) is computed
    looking forward from the trigger bar. That's allowed because
    we're measuring history, not predicting forward — we know
    the future relative to past trigger bars.
  - **Features** (slopes, percentiles, vol ratios) are computed
    using only data up to and including the trigger bar.
    Specifically, "slope" features use a window ending at the
    trigger bar; percentile features use a rolling window over
    bars ≤ trigger. No leakage of future bars.

Trigger bar = the bar where the phase first appears (transition
from a different phase or NONE). Subsequent CONT bars in the
same ride are counted as separate triggers because the operator
would be evaluating each one independently.

Exit definition
───────────────
Per the operator spec: the ride exits at the first bar after the
trigger where Close drops below the upper Bollinger band. Note
the asymmetry: trigger is body-above (open AND close above), but
exit is just close below. This matches operator practice — the
moment the close falls inside the band, the ride is "over"
regardless of intra-bar wick action.

If no exit occurs within the available history, the fire is
flagged ``is_resolved=False`` and outcome fields are ``None``.
Such open rides are excluded from the per-symbol p_win
aggregation but are still included in the events.parquet for
inspection.
"""
from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Iterable

import numpy as np
import pandas as pd

from nimbus_v3.compute.ride_initiation import RideResult

from .schema import (
    ACTIVE_PHASES,
    FireEvent,
    MIN_HISTORY_BARS,
    REQUIRED_ENRICHED_COLUMNS,
)


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════


def extract_fire_events(
    symbol: str,
    df: pd.DataFrame,
    ride_result: RideResult,
) -> list[FireEvent]:
    """Walk ``ride_result.phase`` and emit one :class:`FireEvent`
    per active-phase bar.

    Args:
        symbol: NSE ticker.
        df: enriched OHLCV dataframe (output of
            :class:`StrategyComputeEngine.enrich`).
        ride_result: classification result from :class:`RideEngine`.

    Returns:
        List of fire events. May be empty if the symbol has no
        fires in its history.

    Raises:
        ValueError if ``df`` is missing required columns or has
            fewer than :data:`MIN_HISTORY_BARS` rows.
    """
    missing = [c for c in REQUIRED_ENRICHED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"{symbol}: enriched df missing columns {missing}"
        )
    if len(df) < MIN_HISTORY_BARS:
        raise ValueError(
            f"{symbol}: only {len(df)} bars (need {MIN_HISTORY_BARS}+)"
        )
    if len(df) != len(ride_result.phase):
        raise ValueError(
            f"{symbol}: df has {len(df)} rows but ride_result has "
            f"{len(ride_result.phase)} — must match index-for-index"
        )

    # Pre-compute look-ahead-safe feature series once over the
    # whole frame. We then index into them at each trigger bar.
    feature_frame = _build_feature_frame(df)

    phase_arr = ride_result.phase.values
    events: list[FireEvent] = []

    for i in range(len(phase_arr)):
        phase = str(phase_arr[i])
        if phase not in ACTIVE_PHASES:
            continue

        # Outcome — exit at first close-below-band bar after trigger.
        outcome = _compute_outcome(df, trigger_idx=i)

        # Features at trigger — read from the precomputed frame.
        try:
            feats = _read_features(feature_frame, i)
        except (IndexError, KeyError):
            # Trigger is in the warm-up window (e.g. SMA50 not yet
            # formed). Skip — can't form a meaningful feature row.
            continue

        events.append(FireEvent(
            symbol=symbol,
            phase=phase,
            trigger_idx=i,
            trigger_date=df.index[i].strftime("%Y-%m-%d"),
            **outcome,
            **feats,
        ))

    return events


def events_to_dataframe(events: Iterable[FireEvent]) -> pd.DataFrame:
    """Flatten a list of FireEvent into a parquet-friendly
    dataframe. Each row = one event."""
    return pd.DataFrame([asdict(e) for e in events])


# ══════════════════════════════════════════════════════════════════════════════
# Outcome computation — look-back from trigger
# ══════════════════════════════════════════════════════════════════════════════


def _compute_outcome(df: pd.DataFrame, trigger_idx: int) -> dict:
    """Find the exit bar and compute hold_bars + return_pct.

    Exit = first bar at index > trigger_idx where Close <
    bb_20_1s_upper. Strict less-than: equality stays in the ride.
    If no such bar exists, the ride is open and is_resolved=False.
    """
    n = len(df)
    if trigger_idx >= n - 1:
        # Trigger is the very last bar — no forward data.
        return {
            "hold_bars":    None,
            "exit_idx":     None,
            "return_pct":   None,
            "is_resolved":  False,
        }

    closes = df["Close"].values
    bb_upper = df["bb_20_1s_upper"].values
    trigger_close = float(closes[trigger_idx])

    exit_idx: int | None = None
    for j in range(trigger_idx + 1, n):
        c = closes[j]
        u = bb_upper[j]
        if not np.isfinite(c) or not np.isfinite(u):
            continue
        if c < u:
            exit_idx = j
            break

    if exit_idx is None:
        return {
            "hold_bars":    None,
            "exit_idx":     None,
            "return_pct":   None,
            "is_resolved":  False,
        }

    hold_bars = exit_idx - trigger_idx
    exit_close = float(closes[exit_idx])
    return_pct = 100.0 * (exit_close - trigger_close) / trigger_close

    return {
        "hold_bars":    int(hold_bars),
        "exit_idx":     int(exit_idx),
        "return_pct":   float(return_pct),
        "is_resolved":  True,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Feature engineering — look-ahead-safe (uses only bars ≤ trigger)
# ══════════════════════════════════════════════════════════════════════════════


def _build_feature_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Compute all per-bar features once. Each column at index i
    only depends on df rows ≤ i.

    Produced columns:
      - pct_b_at_trigger:  bb_20_1s_pct (already lookback-safe).
      - sma20_slope_pct:   5-bar slope of sma_20 in %/bar.
      - sma50_slope_pct:   5-bar slope of sma_50 in %/bar.
      - bb_width_pctile:   rank of bbw_20_1s within the prior
                           120-bar window (0..1).
      - vol_ratio_20:      Volume / 20-bar mean volume.
      - atr_14_pct:        atr_14 / Close × 100 (already in df,
                           but normalised here for clarity).
      - bars_since_sma20_above_sma50: count of consecutive prior
                           bars where sma_20 > sma_50, capped.
    """
    out = pd.DataFrame(index=df.index)
    closes = df["Close"]

    # pct_b — already lookback-safe, just rename/copy.
    out["pct_b_at_trigger"] = df["bb_20_1s_pct"]

    # SMA50 — not in standard enrichment, compute locally.
    sma_50 = closes.rolling(50, min_periods=50).mean()

    # Slopes: linear regression slope over a 5-bar window, then
    # divided by current SMA value to get %/bar. We use a simple
    # central-difference proxy for speed since true OLS slope is
    # overkill for a feature.
    sma_20 = df["sma_20"]
    out["sma20_slope_pct"] = _slope_pct(sma_20, window=5)
    out["sma50_slope_pct"] = _slope_pct(sma_50, window=5)

    # BB-width percentile — rank within trailing 120-bar window
    # (~6 months). Uses pandas' rolling rank; lookback-safe by
    # construction (rolling only sees past).
    bbw = df["bbw_20_1s"]
    out["bb_width_pctile"] = bbw.rolling(
        120, min_periods=60,
    ).rank(pct=True)

    # Volume ratio — today vs trailing 20-bar mean.
    vol = df["Volume"]
    vol_mean = vol.rolling(20, min_periods=10).mean()
    out["vol_ratio_20"] = (vol / vol_mean.replace(0.0, np.nan)).clip(
        lower=0.0, upper=10.0,
    )

    # ATR-14 percent — already in enriched df under atr_14_pct,
    # but be tolerant of older panels that don't carry it.
    if "atr_14_pct" in df.columns:
        out["atr_14_pct"] = df["atr_14_pct"]
    elif "atr_14" in df.columns:
        out["atr_14_pct"] = (df["atr_14"] / closes.replace(0.0, np.nan)) * 100.0
    else:
        out["atr_14_pct"] = np.nan

    # Bars since SMA20 above SMA50 — count of consecutive prior
    # bars where the cross has held. Capped at 200 to keep the
    # feature distribution compact.
    above = (sma_20 > sma_50).astype(int)
    out["bars_since_sma20_above_sma50"] = (
        above
        * (above.groupby((above != above.shift()).cumsum()).cumcount() + 1)
    ).clip(upper=200).astype("Int64")

    # Body-above count in the last 5 bars (T-5..T-1, excluding
    # today). Differentiates "fresh CONT just starting" from
    # "CONT deep into a 10-day ride". Lookback-safe — uses .shift
    # to exclude the current bar before the rolling count.
    body_above = (
        (df["Open"] > df["bb_20_1s_upper"])
        & (df["Close"] > df["bb_20_1s_upper"])
    ).astype(int)
    out["body_above_count_prior_5"] = body_above.shift(1).rolling(
        5, min_periods=5,
    ).sum().astype("Int64")

    return out


def _slope_pct(series: pd.Series, *, window: int) -> pd.Series:
    """Slope of `series` over the trailing `window` bars,
    expressed as % of the current value per bar.

    Lookback-safe: the rolling window at index i covers bars
    [i-window+1, i]. The denominator is the current value, so
    slope=0.5/100=0.5% per bar means the line has been rising
    half a percent per bar over the window.
    """
    diff = series.diff(window)
    per_bar = diff / window
    pct = per_bar / series.replace(0.0, np.nan) * 100.0
    return pct


def _read_features(feature_frame: pd.DataFrame, idx: int) -> dict:
    """Pull the feature row at ``idx`` and convert to the
    FireEvent feature kwargs.

    Raises KeyError / IndexError if the row contains NaN-only
    feature values — caller should skip the trigger.
    """
    row = feature_frame.iloc[idx]
    # If any feature is NaN, the trigger is in a warm-up region;
    # the model can't use it. Surface as a key error so the
    # caller skips.
    if row.isna().any():
        raise KeyError(f"feature row {idx} has NaN values: {dict(row)}")

    return {
        "pct_b_at_trigger":             float(row["pct_b_at_trigger"]),
        "sma20_slope_pct":              float(row["sma20_slope_pct"]),
        "sma50_slope_pct":              float(row["sma50_slope_pct"]),
        "bb_width_pctile":              float(row["bb_width_pctile"]),
        "vol_ratio_20":                 float(row["vol_ratio_20"]),
        "atr_14_pct":                   float(row["atr_14_pct"]),
        "bars_since_sma20_above_sma50": int(row["bars_since_sma20_above_sma50"]),
        "body_above_count_prior_5":     int(row["body_above_count_prior_5"]),
    }
