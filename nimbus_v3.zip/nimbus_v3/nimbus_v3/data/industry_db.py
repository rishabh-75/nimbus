"""nimbus_v3.data.industry_db — NSE four-level industry classification loader.

Reads ``data/nifty500_industry_db.json`` (built once by
``scripts/build_industry_db.py``) and returns a dict mapping each
symbol to its four classification levels:

    macro_sector   → "Commodities"          (coarsest, ~12 groups)
    sector         → "Metals & Mining"       (~20 groups)
    industry       → "Non - Ferrous Metals"  (~40 groups, used for RS)
    basic_industry → "Zinc"                  (finest, ~120 groups)

This is the single source of truth for symbol → sector/industry
mapping in the entire system. The ``SectorContextProvider`` and the
``UniverseBuilder`` both read from it.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class IndustryClassification:
    """Four-level industry classification for one symbol."""
    symbol: str
    company_name: str
    macro_sector: str       # "Commodities"
    sector: str             # "Metals & Mining"
    industry: str           # "Non - Ferrous Metals"  (industryInfo in NSE)
    basic_industry: str     # "Zinc"


def _default_db_path() -> Path:
    """Default DB path — resolves under :func:`paths.data_root` so a
    user can park the DB anywhere on disk via the ``NIMBUS_DATA_DIR``
    env var. Falls back to ``./data/nifty500_industry_db.json`` for
    legacy in-tree installs."""
    from nimbus_v3.data.paths import data_root
    return data_root() / "nifty500_industry_db.json"


def load_industry_db(
    path: Path | None = None,
) -> dict[str, IndustryClassification]:
    """Load the industry DB from disk.

    Returns ``{symbol: IndustryClassification}`` for every entry in
    the DB. Returns an empty dict (with a warning) if the file doesn't
    exist or can't be parsed.
    """
    db_path = path or _default_db_path()
    if not db_path.exists():
        logger.warning(
            "industry_db: file not found at %s — run "
            "scripts/build_industry_db.py first",
            db_path,
        )
        return {}

    try:
        raw = json.loads(db_path.read_text())
    except Exception:    # noqa: BLE001
        logger.exception("industry_db: failed to parse %s", db_path)
        return {}

    db: dict[str, IndustryClassification] = {}
    for sym, entry in raw.items():
        db[sym.upper()] = IndustryClassification(
            symbol=sym.upper(),
            company_name=entry.get("companyName", ""),
            macro_sector=entry.get("macro", "Unknown") or "Unknown",
            sector=entry.get("sector", "Unknown") or "Unknown",
            industry=entry.get("industryInfo", "Unknown") or "Unknown",
            basic_industry=entry.get("basicIndustry", "Unknown") or "Unknown",
        )

    logger.info("industry_db: loaded %d symbols from %s", len(db), db_path)
    return db
