"""nimbus_v3.ui.presenters.sidebar_presenter — ViewModel builders for
the sidebar's per-strategy signal panels.

Design
──────

Two frozen :class:`dataclass` view models — :class:`MRSignalView` and
:class:`RideSignalView` — each one a pre-formatted bundle of ``(text,
color_hex)`` pairs keyed by panel slot. The sidebar widget calls
``apply_mr_view(view) / apply_ride_view(view)`` and does nothing
beyond ``setText`` / ``setStyleSheet``.

The two builders (``build_mr_view``, ``build_ride_view``) are pure
functions over ``(SignalState | None, ScanResult | None)``. They
depend on :mod:`nimbus_v3.ui.theme` for every color — the same
helpers the scan-results table uses — so there's exactly one place
to change when the palette evolves.

Strategy matching uses ``result.strategy.setup_type`` — the enum
declared on each :class:`Strategy` — not name strings. New strategies
are picked up automatically so long as they declare the correct
``setup_type``.

The ``RidePosition`` enum makes the W%B bucketing explicit: it's a
presentation concept (four bands used only to color the "Status"
line), not a strategy-engine concept, so it belongs here rather than
in ``SignalState`` or any strategy module.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable

from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.ui.theme import (
    EM, GOLD, GREEN, MUTED, RED, grade_fg, sizing_fg, verdict_fg,
)


# ══════════════════════════════════════════════════════════════════════════════
# Threshold constants — named at module top so they're discoverable
# and easy to tune. Each constant has a one-line rationale.
# ══════════════════════════════════════════════════════════════════════════════

#: W%R(30) bands. Below −80 is oversold and colored emerald; −50 to
#: −80 is "approaching oversold" and colored green; −20 to −50 is
#: neutral (muted); above −20 is overbought and colored red.
_WR_OVERSOLD = -80
_WR_APPROACH_OVERSOLD = -50
_WR_OVERBOUGHT = -20

#: MFI(14) bands. Above 70 is overbought; 50–70 bullish; 30–50
#: neutral; below 30 oversold. Wider palette than W%R because MFI
#: trends inside its 0–100 range whereas W%R pins.
_MFI_OVERBOUGHT = 70
_MFI_BULLISH = 50
_MFI_OVERSOLD = 30

#: ADX(14) bands for the Ride panel's trend line. ADX ≥ 25 is a
#: strong trend (emerald); 18–25 is developing (muted); below 18 is
#: choppy and read as risk (red).
_ADX_STRONG = 25
_ADX_DEVELOPING = 18

#: BB %B position-state bands for the Ride panel. These match
#: ``RidePosition`` below. Upper-band riding starts at 1.0; "near"
#: captures 0.85–1.0; mid-band is 0.5–0.85; anything below 0.5
#: means the ride has broken.
_BB_RIDE_UB = 1.00
_BB_NEAR_UB = 0.85
_BB_MID = 0.50


# ══════════════════════════════════════════════════════════════════════════════
# BB %B position state — explicit enum instead of inline string magic
# ══════════════════════════════════════════════════════════════════════════════

class RidePosition(str, Enum):
    """Categorization of where the last close sits relative to the
    BB(20,1σ) upper band. Purely a presentation bucketing — not a
    strategy-engine concept."""

    RIDING_UB = "RIDING UB"
    NEAR_UB = "NEAR UB"
    MID_BAND = "MID-BAND"
    LOWER_HALF = "LOWER HALF"
    UNKNOWN = "—"


_RIDE_POSITION_COLORS: dict[RidePosition, str] = {
    RidePosition.RIDING_UB: EM,
    RidePosition.NEAR_UB: GOLD,
    RidePosition.MID_BAND: MUTED,
    RidePosition.LOWER_HALF: RED,
    RidePosition.UNKNOWN: MUTED,
}


def _classify_ride_position(bb_pct: float) -> RidePosition:
    """Bucket a BB %B value into a :class:`RidePosition`. Values are
    open at the upper bound so 0.85 classifies as NEAR_UB not MID_BAND."""
    if bb_pct >= _BB_RIDE_UB:
        return RidePosition.RIDING_UB
    if bb_pct >= _BB_NEAR_UB:
        return RidePosition.NEAR_UB
    if bb_pct >= _BB_MID:
        return RidePosition.MID_BAND
    return RidePosition.LOWER_HALF


# ══════════════════════════════════════════════════════════════════════════════
# Indicator-row color helpers — named so the builder stays readable
# ══════════════════════════════════════════════════════════════════════════════

def _wr_color(wr: float) -> str:
    """Color a W%R(30) value by band (oversold → overbought)."""
    if wr < _WR_OVERSOLD:
        return EM
    if wr < _WR_APPROACH_OVERSOLD:
        return GREEN
    if wr > _WR_OVERBOUGHT:
        return RED
    return MUTED


def _mfi_color(mfi: float) -> str:
    """Color an MFI(14) value by band."""
    if mfi >= _MFI_OVERBOUGHT:
        return EM
    if mfi >= _MFI_BULLISH:
        return GREEN
    if mfi >= _MFI_OVERSOLD:
        return MUTED
    return RED


def _adx_color(adx: float) -> str:
    """Color an ADX(14) value by trend-strength band."""
    if adx >= _ADX_STRONG:
        return EM
    if adx >= _ADX_DEVELOPING:
        return MUTED
    return RED


def _pct_b_color(bb_pct: float) -> str:
    """Color a BB %B value — same cutoffs as ``_classify_ride_position``
    but palette emphasizes riding vs. not."""
    if bb_pct >= _BB_RIDE_UB:
        return GREEN
    if bb_pct >= 0.75:
        return GOLD
    return MUTED


# ══════════════════════════════════════════════════════════════════════════════
# ViewModels — everything UI-ready, zero logic
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class _TextPair:
    """A ``(text, color_hex)`` pair. Renders as one label."""
    text: str
    color: str


#: Sentinel "—" pair. Used when a source field is absent so the
#: sidebar renders a consistent visual placeholder.
_EMPTY = _TextPair("—", MUTED)


@dataclass(frozen=True)
class MRSignalView:
    """Pre-formatted view model for the Mean Reversion panel."""

    # Top-row tiles — from the conviction result when present.
    grade: _TextPair                  # "Grade: A+"  |  MUTED if no result
    sizing: _TextPair                 # "Size: FULL" |  MUTED if no result

    # Indicator rows — from SignalState.
    wr_row: _TextPair                 # "WR(30): -62"
    mfi_row: _TextPair                 # "MFI: 42"
    sma_row: _TextPair                 # "SMA: -2.3% | DD: 3.1% | 2d red"

    # Summary + detail.
    verdict_line: _TextPair           # "TAKE [A+] FULL"  |  "—"
    breakdown: str                    # "vix=+0.20 | wr=+0.15"  (single color: MUTED)
    data_status: _TextPair            # "" | "✓ data OK" | "⚠ insufficient data"


@dataclass(frozen=True)
class RideSignalView:
    """Pre-formatted view model for the BB Ride panel."""

    grade_line: _TextPair             # "Grade: B+  |  Size: HALF"  |  "Grade: —"
    status_line: _TextPair            # "Status: RIDING UB"
    pctb_row: _TextPair               # "%B: 0.92 | Vol: 1.3x"
    trend_row: _TextPair              # "ADX: 28 | 3g/1r"
    verdict_line: _TextPair           # "RIDE [B+] HALF"


#: Empty-state defaults — every field set to the "—" sentinel. Used
#: when the sidebar is cleared or opens before any symbol is loaded.
EMPTY_MR_VIEW: MRSignalView = MRSignalView(
    grade=_EMPTY, sizing=_EMPTY, wr_row=_EMPTY, mfi_row=_EMPTY,
    sma_row=_EMPTY, verdict_line=_EMPTY, breakdown="",
    data_status=_TextPair("", MUTED),
)

EMPTY_RIDE_VIEW: RideSignalView = RideSignalView(
    grade_line=_EMPTY, status_line=_EMPTY, pctb_row=_EMPTY,
    trend_row=_EMPTY, verdict_line=_EMPTY,
)


# ══════════════════════════════════════════════════════════════════════════════
# Builders
# ══════════════════════════════════════════════════════════════════════════════

def select_result_by_setup(
    results: Iterable[ScanResult], setup: SetupType,
) -> ScanResult | None:
    """Return the first ``ScanResult`` whose strategy's ``setup_type``
    matches ``setup``. Matching on the enum (not on a name string) is
    safe under strategy renames and keeps the UI LSP-clean."""
    for r in results:
        st = getattr(r.strategy, "setup_type", None)
        if st == setup:
            return r
    return None


def build_mr_view(
    state: SignalState | None,
    result: ScanResult | None,
) -> MRSignalView:
    """Build the MR panel view model from a state + optional result."""
    # ── Grade / sizing / verdict from the conviction if we have one ─
    if result is not None:
        conv = result.conviction
        g = conv.grade.value
        s = conv.sizing.value
        v = conv.verdict.value
        grade = _TextPair(f"Grade: {g}", grade_fg(g))
        sizing = _TextPair(f"Size: {s}", sizing_fg(s))
        verdict_line = _TextPair(f"{v}  [{g}]  {s}", verdict_fg(v))
        try:
            top = sorted(
                conv.contributions, key=lambda c: abs(c.weighted), reverse=True,
            )[:2]
            breakdown = " | ".join(
                f"{c.name}={c.weighted:+.2f}" for c in top if c.weighted
            )
        except Exception:    # noqa: BLE001
            breakdown = ""
    else:
        grade = _EMPTY
        sizing = _EMPTY
        verdict_line = _EMPTY
        breakdown = ""

    # ── Indicator rows from SignalState ─────────────────────────────
    if state is not None:
        wr_row = _TextPair(f"WR(30): {state.wr_30:.0f}", _wr_color(state.wr_30))
        mfi_row = _TextPair(f"MFI: {state.mfi_14:.0f}", _mfi_color(state.mfi_14))
        sma_color = EM if state.above_sma_20 else RED
        sma_row = _TextPair(
            f"SMA: {state.pct_from_sma_20:+.1f}% | "
            f"DD: {state.dd_from_high_50:.1f}% | "
            f"{state.red_streak}d red",
            sma_color,
        )
        if state.data_sufficient:
            data_status = _TextPair("✓ data OK", MUTED)
        else:
            data_status = _TextPair("⚠ insufficient data", RED)
    else:
        wr_row = _EMPTY
        mfi_row = _EMPTY
        sma_row = _EMPTY
        data_status = _TextPair("", MUTED)

    return MRSignalView(
        grade=grade, sizing=sizing, wr_row=wr_row, mfi_row=mfi_row,
        sma_row=sma_row, verdict_line=verdict_line,
        breakdown=breakdown, data_status=data_status,
    )


def build_ride_view(
    state: SignalState | None,
    result: ScanResult | None,
) -> RideSignalView:
    """Build the Ride panel view model from a state + optional result."""
    # ── Grade + sizing + verdict from conviction ────────────────────
    if result is not None:
        conv = result.conviction
        g = conv.grade.value
        s = conv.sizing.value
        v = conv.verdict.value
        grade_line = _TextPair(f"Grade: {g}  |  Size: {s}", grade_fg(g))
        verdict_line = _TextPair(f"{v}  [{g}]  {s}", verdict_fg(v))
    else:
        grade_line = _EMPTY
        verdict_line = _EMPTY

    # ── Position state derived from state.bb_20_1s_pct ──────────────
    # Independent of whether the Ride strategy fired — useful context
    # even when we're not in a formal ride setup.
    if state is not None:
        pos = _classify_ride_position(state.bb_20_1s_pct)
        status_line = _TextPair(
            f"Status: {pos.value}", _RIDE_POSITION_COLORS[pos],
        )
        pctb_row = _TextPair(
            f"%B: {state.bb_20_1s_pct:.2f} | Vol: {state.vol_ratio_20:.1f}x",
            _pct_b_color(state.bb_20_1s_pct),
        )
        trend_row = _TextPair(
            f"ADX: {state.adx_14:.0f} | "
            f"{state.green_streak}g/{state.red_streak}r",
            _adx_color(state.adx_14),
        )
    else:
        status_line = _EMPTY
        pctb_row = _EMPTY
        trend_row = _EMPTY

    return RideSignalView(
        grade_line=grade_line, status_line=status_line,
        pctb_row=pctb_row, trend_row=trend_row,
        verdict_line=verdict_line,
    )
