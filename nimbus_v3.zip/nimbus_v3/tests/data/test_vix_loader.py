"""Tests for nimbus_v3.data.vix_loader.VIXLoader.

Tests mock both the injected ``NSEClient.fetch`` and ``yf.download`` so
the three-tier fallback is exercised without network.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

import pandas as pd
import pytest

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.vix_loader import (
    VIXLoader,
    _extract_nse_vix_value,
    _last_close,
    _normalize_history,
)


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class _MockNSE:
    """Matches NSEClient.fetch signature but returns a preset value."""
    response: object = None
    calls: list[dict] = field(default_factory=list)

    def fetch(self, url, *, referer, params=None, extra_headers=None):  # noqa: ANN001, ARG002
        self.calls.append({"url": url, "referer": referer, "params": params})
        return self.response


def _nse_payload(value: float) -> dict:
    return {"data": [
        {"index": "NIFTY 50", "last": 22000.0},
        {"index": "INDIA VIX", "last": value},
    ]}


def _yf_intraday(close_values: list[float]) -> pd.DataFrame:
    idx = pd.date_range("2024-01-15 09:15", periods=len(close_values), freq="5min")
    return pd.DataFrame({
        "Open": close_values,
        "High": close_values,
        "Low": close_values,
        "Close": close_values,
        "Volume": [0] * len(close_values),
    }, index=idx)


def _yf_daily_history(n: int = 300, start_val: float = 15.0) -> pd.DataFrame:
    idx = pd.bdate_range(start="2023-01-02", periods=n)
    closes = [start_val + i * 0.01 for i in range(n)]
    return pd.DataFrame({
        "Open": closes,
        "High": closes,
        "Low": closes,
        "Close": closes,
        "Volume": [0] * n,
    }, index=idx)


@pytest.fixture
def cache(tmp_path: Path) -> ParquetCache:
    return ParquetCache(base_dir=tmp_path / "vix")


@pytest.fixture
def loader(cache: ParquetCache) -> VIXLoader:
    return VIXLoader(
        nse_client=_MockNSE(),  # type: ignore[arg-type]
        cache=cache,
        default_history_years=1,
        default_history_ttl=timedelta(hours=24),
    )


# ══════════════════════════════════════════════════════════════════════════════
# Parser units
# ══════════════════════════════════════════════════════════════════════════════

def test_extract_nse_vix_finds_india_vix_row() -> None:
    assert _extract_nse_vix_value(_nse_payload(14.5)) == pytest.approx(14.5)


def test_extract_nse_vix_handles_lastPrice_alias() -> None:
    payload = {"data": [
        {"indexSymbol": "INDIA VIX", "lastPrice": "18.20"},
    ]}
    assert _extract_nse_vix_value(payload) == pytest.approx(18.20)


def test_extract_nse_vix_returns_none_when_absent() -> None:
    payload = {"data": [{"index": "NIFTY BANK", "last": 50000.0}]}
    assert _extract_nse_vix_value(payload) is None


def test_extract_nse_vix_tolerates_garbage_shapes() -> None:
    assert _extract_nse_vix_value("nope") is None
    assert _extract_nse_vix_value({}) is None
    assert _extract_nse_vix_value({"data": "also not a list"}) is None
    assert _extract_nse_vix_value({"data": [None, 42, "string"]}) is None


def test_last_close_picks_last_non_nan() -> None:
    df = _yf_intraday([14.0, 14.2, float("nan"), 14.5])
    assert _last_close(df) == pytest.approx(14.5)


def test_last_close_handles_multi_index() -> None:
    df = _yf_intraday([14.0, 14.2])
    df.columns = pd.MultiIndex.from_product([df.columns, ["^INDIAVIX"]])
    assert _last_close(df) == pytest.approx(14.2)


def test_last_close_returns_none_on_empty_or_missing_close() -> None:
    assert _last_close(pd.DataFrame()) is None
    assert _last_close(pd.DataFrame({"Open": [1.0]})) is None


def test_normalize_history_inserts_volume_when_missing() -> None:
    raw = pd.DataFrame({
        "Open":  [14.0, 14.5],
        "High":  [14.2, 14.8],
        "Low":   [13.9, 14.3],
        "Close": [14.1, 14.6],
    }, index=pd.bdate_range("2024-01-01", periods=2))
    out = _normalize_history(raw)
    assert "Volume" in out.columns
    assert (out["Volume"] == 0.0).all()


# ══════════════════════════════════════════════════════════════════════════════
# Three-tier fallback — tier 1 (NSE live)
# ══════════════════════════════════════════════════════════════════════════════

def test_tier1_nse_live_succeeds(cache: ParquetCache) -> None:
    nse = _MockNSE(response=_nse_payload(17.5))
    loader = VIXLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    with patch("nimbus_v3.data.vix_loader.yf.download") as mock_yf:
        value = loader.load_current()
        assert value == pytest.approx(17.5)
        mock_yf.assert_not_called()  # never reached


def test_tier2_used_when_tier1_returns_none(cache: ParquetCache) -> None:
    nse = _MockNSE(response=None)  # tier 1 fails
    loader = VIXLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=_yf_intraday([16.0, 16.5, 16.8])) as mock_yf:
        value = loader.load_current()
        assert value == pytest.approx(16.8)
        assert mock_yf.call_count == 1  # intraday only, daily not reached


def test_tier3_used_when_both_upper_tiers_fail(cache: ParquetCache) -> None:
    nse = _MockNSE(response=None)
    loader = VIXLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    # Tier 2 yields empty, tier 3 yields a real value.
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 side_effect=[pd.DataFrame(), _yf_intraday([19.0])]):
        value = loader.load_current()
        assert value == pytest.approx(19.0)


def test_all_tiers_fail_returns_none(cache: ParquetCache) -> None:
    nse = _MockNSE(response=None)
    loader = VIXLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=pd.DataFrame()):
        assert loader.load_current() is None


def test_tier_ordering_nse_first_when_nonzero(cache: ParquetCache) -> None:
    """Even if yfinance would also succeed, NSE's value must be used."""
    nse = _MockNSE(response=_nse_payload(12.3))
    loader = VIXLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=_yf_intraday([99.0])) as mock_yf:
        value = loader.load_current()
        assert value == pytest.approx(12.3)
        mock_yf.assert_not_called()


# ══════════════════════════════════════════════════════════════════════════════
# History cache
# ══════════════════════════════════════════════════════════════════════════════

def test_load_history_caches_result(loader: VIXLoader) -> None:
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=_yf_daily_history(10)) as mock_yf:
        df1 = loader.load_history()
        df2 = loader.load_history()
    assert mock_yf.call_count == 1
    pd.testing.assert_frame_equal(df1, df2, check_freq=False)


def test_load_history_force_refresh(loader: VIXLoader) -> None:
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 side_effect=[_yf_daily_history(5), _yf_daily_history(8)]) as mock_yf:
        loader.load_history()
        loader.load_history(force_refresh=True)
    assert mock_yf.call_count == 2


def test_load_history_stale_falls_back_to_cache(loader: VIXLoader) -> None:
    """If yfinance returns empty but we have a cached history, return the
    cached one."""
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=_yf_daily_history(5)):
        loader.load_history()
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=pd.DataFrame()):
        df = loader.load_history(force_refresh=True)
    assert not df.empty


# ══════════════════════════════════════════════════════════════════════════════
# asof_date lookup
# ══════════════════════════════════════════════════════════════════════════════

def test_load_value_on_returns_close_at_or_before_date(loader: VIXLoader) -> None:
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=_yf_daily_history(20)):
        loader.load_history()  # populate cache
        # History starts 2023-01-02; closes increase by 0.01 per bar.
        value_day0 = loader.load_value_on(pd.Timestamp("2023-01-02"))
        value_day5 = loader.load_value_on(pd.Timestamp("2023-01-09"))
    assert value_day0 == pytest.approx(15.0)
    assert value_day5 == pytest.approx(15.05)


def test_load_value_on_returns_none_before_history_starts(loader: VIXLoader) -> None:
    with patch("nimbus_v3.data.vix_loader.yf.download",
                 return_value=_yf_daily_history(10)):
        loader.load_history()
        value = loader.load_value_on(pd.Timestamp("2000-01-01"))
    assert value is None


# ══════════════════════════════════════════════════════════════════════════════
# Regression: _download_history end param is IST-today + 1 day
#
# Same bug as price_loader._download_from_yfinance: UTC-today +
# end-exclusive = we miss today's VIX close. For the pace
# classifier this meant today's slope was computed from
# yesterday's close, which lags the actual regime by one bar.
# ══════════════════════════════════════════════════════════════════════════════

class TestHistoryEndParam:

    def test_end_is_today_plus_one(self, loader: VIXLoader) -> None:
        from datetime import date, datetime, timedelta, timezone
        with patch(
            "nimbus_v3.data.vix_loader.yf.download",
            return_value=_yf_daily_history(30),
        ) as mock_dl:
            loader.load_history(force_refresh=True)

        assert mock_dl.called
        end_date = date.fromisoformat(mock_dl.call_args.kwargs["end"])
        today_ist = datetime.now(
            tz=timezone(timedelta(hours=5, minutes=30)),
        ).date()
        assert end_date >= today_ist

    def test_end_uses_ist_not_utc(self, loader: VIXLoader) -> None:
        """Mirrors the price_loader test: a UTC moment that's
        already tomorrow in IST should produce an IST-based end."""
        from datetime import datetime, timedelta, timezone

        class _FakeDT(datetime):
            @classmethod
            def now(cls, tz=None):
                fixed_utc = datetime(2026, 4, 22, 20, 0, tzinfo=timezone.utc)
                return fixed_utc.astimezone(tz) if tz else fixed_utc

        with patch("nimbus_v3.data.vix_loader.datetime", _FakeDT):
            with patch(
                "nimbus_v3.data.vix_loader.yf.download",
                return_value=_yf_daily_history(30),
            ) as mock_dl:
                loader.load_history(force_refresh=True)

        end_date = datetime.fromisoformat(
            mock_dl.call_args.kwargs["end"],
        ).date()
        # IST-today at the fake moment is 2026-04-23; +1 = 2026-04-24.
        assert end_date == datetime(2026, 4, 24).date()
