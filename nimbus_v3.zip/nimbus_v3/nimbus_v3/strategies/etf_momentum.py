"""nimbus_v3.strategies.etf_momentum — ETF momentum continuation setup.

Consolidates the five ETF files from nimbus_oracle into a single
strategy. ETFs can't short and have different volatility behaviour than
individual equities, so the parameters differ:

- Williams %R uses a 20-bar window (vs 30 for equities). This is
  intentional per the v3 architecture note §18.4 — documented because
  it is a common mistake to unify these.

Entry gates
───────────
- ``state.roc_20 > 3.0``           — 20-bar uptrend (lower than equity BO)
- ``state.close > state.sma_50``   — medium-term trend confirmation
- ``state.wr_20 > -50.0``          — not oversold (20-bar WR, not 30)
- ``state.data_sufficient``
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class ETFMomentumParams:
    roc_20_min: float = 3.0
    wr_20_min: float = -50.0


class ETFMomentumStrategy:
    """ETF momentum continuation setup. Rejects non-ETF symbols."""

    name: str = "ETFMomentum"
    setup_type: SetupType = SetupType.ETF_MOMENTUM
    priority: int = 45
    production_weight: float = 0.0   # current form fails OOS on limited ETF data — research-only

    def __init__(self, params: ETFMomentumParams = ETFMomentumParams()) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — ETFs don't use VIX gate
    ) -> StrategySignal | None:
        if state.roc_20 <= self._p.roc_20_min:
            return None
        if state.close <= state.sma_50:
            return None
        if state.wr_20 <= self._p.wr_20_min:
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "roc_20": state.roc_20,
                "sma_50": state.sma_50,
                "wr_20": state.wr_20,
            },
        )
