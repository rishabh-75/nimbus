"""nimbus_v3.data.cache — parquet-backed ``CacheStore`` implementation.

One file per key. Keys may contain forward slashes to create nested
directories. Atomic writes via write-to-temp-then-rename so partial writes
are impossible to observe.

Namespace isolation
───────────────────
Each loader gets its own cache with its own base directory::

    price_cache   = ParquetCache(base_dir=Path("data/cache/price"))
    options_cache = ParquetCache(base_dir=Path("data/cache/options"))

Two loaders cannot collide on a key because their base directories are
distinct. Key collisions within a namespace are the caller's problem — the
cache faithfully overwrites.

Why parquet
───────────
- Fast columnar read/write for tabular OHLCV and chain snapshots.
- Preserves dtypes, timezone-awareness, and index metadata.
- Native to pandas via pyarrow.
- Single file per key — no row-group management.
"""
from __future__ import annotations

import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd


class ParquetCache:
    """File-based DataFrame cache using parquet.

    Thread-safe for reads and for writes to different keys. Concurrent
    writes to the **same** key are undefined — callers must serialize if
    that's a risk.
    """

    _SUFFIX = ".parquet"

    def __init__(self, base_dir: Path) -> None:
        """Args:
            base_dir: Directory where parquet files land. Created if
                missing. The caller owns this directory — the cache never
                creates siblings or writes outside it.
        """
        self.base_dir: Path = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    # ══════════════════════════════════════════════════════════════════════
    # CacheStore protocol
    # ══════════════════════════════════════════════════════════════════════

    def get(self, key: str) -> pd.DataFrame | None:
        """Return the DataFrame for ``key``, or ``None`` if absent or
        unreadable."""
        path = self._path(key)
        if not path.is_file():
            return None
        return pd.read_parquet(path)

    def set(self, key: str, df: pd.DataFrame) -> None:
        """Persist ``df`` under ``key`` atomically.

        Writes to a sibling temp file then renames. On POSIX, rename is
        atomic within the same filesystem. On Windows, ``os.replace`` is
        equivalently atomic.
        """
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        # tempfile in the same directory guarantees same-filesystem rename.
        with tempfile.NamedTemporaryFile(
            mode="wb",
            suffix=self._SUFFIX,
            dir=path.parent,
            delete=False,
        ) as tmp:
            tmp_path = Path(tmp.name)
        try:
            df.to_parquet(tmp_path, engine="pyarrow", index=True)
            os.replace(tmp_path, path)
        except Exception:
            # Best-effort cleanup. Failing to delete the temp is not fatal.
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass
            raise

    def exists(self, key: str) -> bool:
        return self._path(key).is_file()

    def age(self, key: str) -> timedelta | None:
        path = self._path(key)
        if not path.is_file():
            return None
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return datetime.now(tz=timezone.utc) - mtime

    def clear(self, prefix: str | None = None) -> int:
        """Remove every cached key starting with ``prefix`` (or all if None).

        Returns the number of files removed. Empty directories are left in
        place — the caller can prune if desired.
        """
        removed = 0
        target_prefix = self._path(prefix) if prefix else self.base_dir
        if prefix is None:
            # Walk the whole tree.
            for path in self.base_dir.rglob(f"*{self._SUFFIX}"):
                path.unlink()
                removed += 1
        else:
            # Prefix may address either a file or a subdirectory.
            if target_prefix.is_file():
                target_prefix.unlink()
                removed = 1
            else:
                # Treat prefix as a directory / partial key.
                for path in self.base_dir.rglob(f"*{self._SUFFIX}"):
                    # Compute the key from the path and filter by prefix.
                    key = self._key_from_path(path)
                    if key.startswith(prefix):
                        path.unlink()
                        removed += 1
        return removed

    # ══════════════════════════════════════════════════════════════════════
    # Private helpers
    # ══════════════════════════════════════════════════════════════════════

    def _path(self, key: str) -> Path:
        """Resolve ``key`` to an absolute path under ``base_dir``.

        Keys may contain ``/`` to create nested directories. Raises
        ``ValueError`` if the resolved path escapes ``base_dir`` (guarding
        against ``..`` traversal even though we don't expect untrusted
        keys).
        """
        if not key:
            raise ValueError("cache key must be non-empty")
        candidate = (self.base_dir / (key + self._SUFFIX)).resolve()
        base_resolved = self.base_dir.resolve()
        try:
            candidate.relative_to(base_resolved)
        except ValueError as exc:
            raise ValueError(
                f"cache key {key!r} resolves outside base_dir {base_resolved}"
            ) from exc
        return candidate

    def _key_from_path(self, path: Path) -> str:
        """Inverse of :meth:`_path` — strip base_dir and suffix."""
        rel = path.resolve().relative_to(self.base_dir.resolve())
        name = str(rel)
        if name.endswith(self._SUFFIX):
            name = name[: -len(self._SUFFIX)]
        return name.replace(os.sep, "/")
