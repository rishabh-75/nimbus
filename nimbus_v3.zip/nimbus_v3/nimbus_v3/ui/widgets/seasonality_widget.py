"""nimbus_v3.ui.widgets.seasonality_widget — seasonality panel.

Reusable presentation of a :class:`SeasonalityResult`: four metric cards
(strongest / weakest month by average return, best / worst hit rate)
above a cumulative average 12-month path line chart (Jan→Dec).

Pure renderer — it computes nothing. Feed it a result via
:meth:`set_result`. Used by both the Market Pulse tab (market = CNX500)
and the Dashboard (per selected symbol), so the look stays identical and
single-sourced. Mirrors the reference "Gold Seasonality" layout.
"""
from __future__ import annotations

from datetime import datetime

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout,
    QWidget,
)

from nimbus_v3.compute.seasonality import MonthStat, SeasonalityResult, month_stat
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, FONT_MONO, FONT_UI, MUTED, RED, S2, WHITE,
)

_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


class _Card(QFrame):
    """A single metric tile: label, big value, sub-text."""

    def __init__(self, caption: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("seasonCard")
        self.setFixedHeight(52)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed,
        )
        self.setStyleSheet(
            f"QFrame#seasonCard {{ background: {S2}; border: 1px solid "
            f"{BORDER}; border-radius: 4px; }}"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 5, 10, 5)
        lay.setSpacing(0)

        self._caption = QLabel(caption)
        self._caption.setFont(QFont(FONT_UI, 6, QFont.Weight.Bold))
        self._caption.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        lay.addWidget(self._caption)

        # Value + sub on one line to keep the card short.
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        self._value = QLabel("—")
        self._value.setFont(QFont(FONT_MONO, 13, QFont.Weight.Bold))
        self._value.setStyleSheet(f"color: {WHITE};")
        row.addWidget(self._value)
        self._sub = QLabel("")
        self._sub.setFont(QFont(FONT_MONO, 7))
        self._sub.setStyleSheet(f"color: {MUTED};")
        self._sub.setAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom
        )
        row.addWidget(self._sub, stretch=1)
        lay.addLayout(row)

    def set(self, value: str, sub: str, color: str) -> None:
        self._value.setText(value)
        self._value.setStyleSheet(f"color: {color};")
        self._sub.setText(sub)


class SeasonalityWidget(QWidget):
    """Four metric cards + cumulative 12-month path chart."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)

        # ── Metric cards row ────────────────────────────────────────
        cards = QHBoxLayout()
        cards.setSpacing(8)
        self._strongest = _Card("STRONGEST MONTH")
        self._weakest = _Card("WEAKEST MONTH")
        self._best_hit = _Card("BEST HIT RATE")
        self._worst_hit = _Card("WORST HIT RATE")
        self._this_month = _Card("THIS MONTH")
        for c in (self._strongest, self._weakest, self._best_hit,
                  self._worst_hit, self._this_month):
            cards.addWidget(c)
        root.addLayout(cards)

        # ── Cumulative path chart ───────────────────────────────────
        title = QLabel("AVERAGE 12-MONTH PATH")
        title.setFont(QFont(FONT_UI, 7, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        root.addWidget(title)

        self._plot_widget = pg.PlotWidget()
        self._plot_widget.setBackground(BG)
        self._plot = self._plot_widget.getPlotItem()
        self._plot.showGrid(x=False, y=True, alpha=0.12)
        self._plot.getAxis("left").setTextPen(MUTED)
        self._plot.getAxis("bottom").setTextPen(MUTED)
        self._plot.getAxis("left").setPen(BORDER)
        self._plot.getAxis("bottom").setPen(BORDER)
        # Month ticks on the x-axis.
        self._plot.getAxis("bottom").setTicks(
            [[(i, _MONTHS[i]) for i in range(12)]]
        )
        self._plot.setMouseEnabled(x=False, y=False)
        self._plot.hideButtons()
        root.addWidget(self._plot_widget, stretch=1)

        self._empty = QLabel("Need ≥3 years of data for seasonality")
        self._empty.setFont(QFont(FONT_MONO, 9))
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setVisible(False)
        root.addWidget(self._empty)

    # ── public API ──────────────────────────────────────────────────────────

    def set_result(self, result: SeasonalityResult) -> None:
        """Render a seasonality result. Shows an empty-state hint when
        there isn't enough history."""
        self._plot.clear()
        if result is None or not result.has_data:
            self._set_cards_empty()
            self._plot_widget.setVisible(False)
            self._empty.setVisible(True)
            return
        self._empty.setVisible(False)
        self._plot_widget.setVisible(True)

        self._set_card(self._strongest, result.strongest, kind="return")
        self._set_card(self._weakest, result.weakest, kind="return")
        self._set_card(self._best_hit, result.best_hit, kind="hit")
        self._set_card(self._worst_hit, result.worst_hit, kind="hit")

        # Current-month card: this calendar month's historical hit rate.
        cur = month_stat(result, datetime.now().month)
        self._set_card(self._this_month, cur, kind="hit")

        self._draw_path(result)

    # ── internals ─────────────────────────────────────────────────────────

    def _set_card(self, card: _Card, stat: MonthStat | None, *, kind: str) -> None:
        if stat is None or stat.n_years == 0:
            card.set("—", "", MUTED)
            return
        if kind == "return":
            color = BLUE if stat.avg_return >= 0 else RED
            card.set(stat.label, f"avg {stat.avg_return:+.2f}%", color)
        else:    # hit rate
            color = BLUE if stat.hit_rate >= 50 else RED
            card.set(
                stat.label, f"{stat.hit_rate:.0f}% of years positive", color,
            )

    def _set_cards_empty(self) -> None:
        for c in (self._strongest, self._weakest, self._best_hit,
                  self._worst_hit, self._this_month):
            c.set("—", "", MUTED)

    def _draw_path(self, result: SeasonalityResult) -> None:
        x = np.arange(12)
        y = np.array(result.cumulative_path, dtype=float)
        # Area fill under the curve + line + markers, matching the
        # reference's filled cumulative path.
        self._plot.plot(
            x, y,
            pen=pg.mkPen(BLUE, width=2),
            fillLevel=float(np.nanmin(y)) if np.isfinite(y).any() else 0.0,
            brush=pg.mkBrush(96, 165, 250, 40),
            symbol="o", symbolSize=6,
            symbolBrush=BLUE, symbolPen=pg.mkPen(BG, width=1),
        )
        self._plot.getAxis("left").setLabel("")
        # Pad the y-range generously so the path + markers have
        # breathing room above and below rather than hugging the edges.
        if np.isfinite(y).any():
            lo, hi = float(np.nanmin(y)), float(np.nanmax(y))
            span = hi - lo
            pad = max(1.5, span * 0.22)
            self._plot.setYRange(lo - pad, hi + pad)
        self._plot.setXRange(-0.3, 11.3, padding=0)
