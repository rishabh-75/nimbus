"""nimbus_v3.data.nse_client — HTTP client for NSE endpoints.

Cookie handshake protocol (ported from nimbus_v2 — do not change
without testing against live NSE):

1. ``_warm()`` hits the NSE homepage via ``self._session.get()``.
   The Session accumulates base cookies (nsit, nseappid, bm_sv, etc.)
   in its cookie jar automatically. No ``raise_for_status`` — NSE may
   return 302 or even 403 while still setting cookies. Failures are
   logged but never raised.

2. ``_seed(referer)`` hits the referer page. The Session sends the
   accumulated warm cookies automatically. The response sets
   additional endpoint-scoped cookies, which are also accumulated in
   the Session jar AND cached per-referer for reuse.

3. ``fetch(url, referer=..., cookies=seed_cookies)`` merges the
   cached seed cookies with the Session's jar and hits the JSON
   endpoint. The Session's TLS connection pool ensures cookie-to-TLS
   continuity that NSE's WAF (Akamai) requires.

Why a ``requests.Session`` is mandatory:
  NSE's WAF ties cookies to the underlying TLS session. Plain
  ``requests.get()`` creates a new TCP/TLS connection per call, so
  cookies from ``_warm()`` are invalid on the next call. The Session
  maintains a connection pool — same TLS session across warm → seed →
  fetch. v2 proved this works; v3's attempt to replace Session with
  bare ``requests.get()`` caused persistent 403 errors.

Why the Session's cookie jar is NOT cleared:
  v2 lets cookies accumulate naturally. Extra cookies from one
  endpoint group don't interfere with another — NSE's WAF cares about
  the *presence* of required cookies, not the *absence* of extras.
  Clearing the jar after each call (as the earlier v3 attempted) broke
  the accumulation NSE expects.

Thread safety:
  RLock guards cookie state. Session connection pooling is thread-safe
  in ``requests``.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any

import requests


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════════════

_NSE_BASE = "https://www.nseindia.com"

_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:82.0) "
    "Gecko/20100101 Firefox/82.0"
)

_DEFAULT_HEADERS: dict[str, str] = {
    "Host": "www.nseindia.com",
    "User-Agent": _USER_AGENT,
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;"
        "q=0.9,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
}

_SEED_TTL: float = 300.0         # 5 min
_DEFAULT_TIMEOUT: float = 15.0
_COOLDOWN_SECONDS: float = 300.0  # 5 min
_MIN_SPACING: float = 1.2        # seconds between calls to same referer


# ══════════════════════════════════════════════════════════════════════════════
# Per-referer state
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class _RefererState:
    seed_cookies: dict[str, str] = field(default_factory=dict)
    seed_ts: float = 0.0
    last_request_ts: float = 0.0
    cooldown_until: float = 0.0

    def seed_fresh(self) -> bool:
        return (time.time() - self.seed_ts) < _SEED_TTL

    def in_cooldown(self) -> bool:
        return time.time() < self.cooldown_until


# ══════════════════════════════════════════════════════════════════════════════
# Client
# ══════════════════════════════════════════════════════════════════════════════

class NSEClient:
    """NSE HTTP client with two-step cookie handshake.

    Ported from ``nimbus_v2.nse.client.NSEClient`` — the cookie
    handshake, Session usage, header construction, and fault-tolerance
    patterns are matched exactly. Additional v3 features (cooldown per
    referer, rate-limit spacing) are layered on top without changing
    the core HTTP flow.

    Usage::

        client = NSEClient()
        data = client.fetch(
            "https://www.nseindia.com/api/equity-stockIndices",
            referer="https://www.nseindia.com/market-data/live-equity-market",
            params={"index": "NIFTY 200"},
        )
    """

    def __init__(
        self,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = 2,
        warm_on_init: bool = True,
    ) -> None:
        self._timeout = timeout
        self._max_retries = max_retries
        self._lock = threading.RLock()
        self._session = requests.Session()
        self._referer_states: dict[str, _RefererState] = {}
        if warm_on_init:
            self._warm()

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def fetch(
        self,
        url: str,
        *,
        referer: str,
        params: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict | list | None:
        """Fetch a JSON endpoint from NSE.

        Handles cookie seeding, retries, and 401/403 reset.

        Returns parsed JSON on success, ``None`` on any failure.
        """
        if not url.startswith("http"):
            url = _NSE_BASE + url

        with self._lock:
            state = self._referer_states.setdefault(referer, _RefererState())

            if state.in_cooldown():
                logger.debug(
                    "nse_client: referer %r in cooldown — skipping %s",
                    referer, url,
                )
                return None

            self._respect_spacing(state)
            cookies = self._seed(referer)

        last_error = ""
        for attempt in range(1, self._max_retries + 1):
            try:
                resp = self._session.get(
                    url,
                    headers=self._api_headers(referer, extra_headers),
                    cookies=cookies,
                    params=params,
                    allow_redirects=False,
                    timeout=self._timeout,
                )
                if resp.status_code == 200:
                    ct = resp.headers.get("Content-Type", "")
                    if "json" in ct or "javascript" in ct:
                        with self._lock:
                            state.last_request_ts = time.time()
                            state.cooldown_until = 0.0
                        return resp.json()
                    last_error = f"non-JSON content-type: {ct[:60]}"
                else:
                    last_error = f"HTTP {resp.status_code}"

                if resp.status_code in (401, 403) and attempt < self._max_retries:
                    logger.info(
                        "nse_client: %d on %s — resetting session",
                        resp.status_code, url,
                    )
                    self.reset()
                    cookies = self._seed(referer)

            except requests.RequestException as exc:
                last_error = repr(exc)
                logger.warning(
                    "nse_client: request error %s (attempt %d/%d)",
                    exc, attempt, self._max_retries,
                )

            if attempt < self._max_retries:
                time.sleep(1.0 * attempt)

        logger.warning(
            "nse_client: fetch failed for referer=%r url=%s: %s",
            referer, url, last_error,
        )
        with self._lock:
            state.last_request_ts = time.time()
            state.cooldown_until = time.time() + _COOLDOWN_SECONDS
        return None

    def is_in_cooldown(self, referer: str) -> bool:
        with self._lock:
            state = self._referer_states.get(referer)
            return state.in_cooldown() if state else False

    def invalidate_cookies(self) -> None:
        """Drop all cookies and rebuild the session."""
        self.reset()

    def reset(self) -> None:
        """Full session rebuild — new TCP connections, new cookies."""
        with self._lock:
            self._session = requests.Session()
            self._referer_states.clear()
        self._warm()

    # ══════════════════════════════════════════════════════════════════════
    # Cookie handshake (matches v2 exactly)
    # ══════════════════════════════════════════════════════════════════════

    def _warm(self) -> None:
        """Hit the NSE homepage to seed base session cookies.

        Failures are logged but NOT raised — the next fetch() will
        retry if needed. This keeps construction non-failing in test
        environments without network.

        No ``raise_for_status()`` — NSE may return 302 or 403 while
        still setting cookies via Set-Cookie headers. The Session
        accumulates these automatically in its cookie jar.
        """
        with self._lock:
            try:
                self._session.get(
                    _NSE_BASE,
                    headers={**_DEFAULT_HEADERS},
                    allow_redirects=False,
                    timeout=self._timeout,
                )
                logger.debug("nse_client: homepage warm OK")
            except Exception as exc:    # noqa: BLE001
                logger.warning("nse_client: homepage warm failed: %s", exc)

    def _seed(self, referer: str) -> dict[str, str]:
        """Hit the referer page to get endpoint-scoped cookies.

        Returns the cookies from the referer response (cached per
        referer for ``_SEED_TTL``). The Session also accumulates
        them in its jar automatically — belt and suspenders.

        On a transient connection drop (``RemoteDisconnected``,
        ``ConnectionError``), retries once after a short backoff
        before giving up — NSE's TLS stack occasionally closes a
        connection mid-handshake but almost always accepts the
        immediate retry. Prevents the per-referer cookie cache from
        silently staying empty after one blip.
        """
        state = self._referer_states.setdefault(referer, _RefererState())
        if state.seed_fresh():
            return state.seed_cookies

        def _attempt() -> dict[str, str] | None:
            try:
                resp = self._session.get(
                    referer,
                    headers={**_DEFAULT_HEADERS, "Referer": _NSE_BASE},
                    allow_redirects=False,
                    timeout=self._timeout,
                )
                return dict(resp.cookies)
            except Exception as exc:    # noqa: BLE001
                return exc    # sentinel — caller checks isinstance

        result = _attempt()
        if isinstance(result, Exception):
            logger.info(
                "nse_client: seed transient failure for %s (%s) — retrying once",
                referer, type(result).__name__,
            )
            time.sleep(0.5)
            result = _attempt()

        if isinstance(result, Exception):
            logger.warning("nse_client: seed failed for %s: %s", referer, result)
            return state.seed_cookies
        cookies = result or {}
        with self._lock:
            state.seed_cookies = cookies
            state.seed_ts = time.time()
        return cookies

    # ══════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════

    def _api_headers(
        self,
        referer: str,
        extra: dict[str, str] | None = None,
    ) -> dict[str, str]:
        """Headers for the JSON endpoint call. XHR-style."""
        h = {
            "Host": "www.nseindia.com",
            "User-Agent": _USER_AGENT,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.5",
            "Referer": referer,
            "Connection": "keep-alive",
            "X-Requested-With": "XMLHttpRequest",
        }
        if extra:
            h.update(extra)
        return h

    def _respect_spacing(self, state: _RefererState) -> None:
        """Enforce minimum spacing between calls to the same referer."""
        if state.last_request_ts <= 0:
            return
        elapsed = time.time() - state.last_request_ts
        if elapsed < _MIN_SPACING:
            time.sleep(_MIN_SPACING - elapsed)

# ══════════════════════════════════════════════════════════════════════════════
# Shared singleton (matches nimbus_oracle pattern)
# ══════════════════════════════════════════════════════════════════════════════
# All code should use get_shared_client() instead of NSEClient().
# Initialized once at startup (main.py), shared across all threads.

_shared: NSEClient | None = None
_shared_lock = threading.Lock()


def init_shared_client(**kwargs) -> NSEClient:
    """Initialize the shared NSEClient. Called ONCE at app startup."""
    global _shared
    with _shared_lock:
        _shared = NSEClient(**kwargs)
        logger.info("nse_client: shared instance initialized")
    return _shared


def get_shared_client() -> NSEClient:
    """Get the shared NSEClient singleton.

    Creates one (with warm) if not yet initialized — lazy fallback
    for scripts/tests that don't call init_shared_client().
    """
    global _shared
    if _shared is None:
        with _shared_lock:
            if _shared is None:
                _shared = NSEClient()
                logger.info("nse_client: shared instance created (lazy)")
    return _shared
