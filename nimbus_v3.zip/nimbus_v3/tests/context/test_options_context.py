"""Tests for OptionsContextProvider and its pure math helpers."""
from __future__ import annotations

from unittest.mock import MagicMock

import pandas as pd
import pytest

from nimbus_v3.context.options_context import (
    OptionsAnalysisParams,
    OptionsContextProvider,
    _classify_expiry_risk,
    _classify_gex_regime,
    _hvl,
    _iv_atm,
    _ivr_proxy,
    _max_pain,
    _net_gex,
    _pcr_oi,
    _walls,
)
from nimbus_v3.core.types import ExpiryRisk, GEXRegime


# ══════════════════════════════════════════════════════════════════════════════
# Constructing test chains
# ══════════════════════════════════════════════════════════════════════════════

def _chain(
    strikes: list[float],
    *,
    spot: float = 2500.0,
    expiry: str = "2024-05-30",
    dte: int = 10,
    ce_oi: list[float] | None = None,
    pe_oi: list[float] | None = None,
    ce_iv: list[float] | None = None,
    pe_iv: list[float] | None = None,
) -> pd.DataFrame:
    n = len(strikes)
    rows = []
    for i, k in enumerate(strikes):
        rows.append({
            "strike": k,
            "expiry": pd.Timestamp(expiry),
            "dte": dte,
            "spot": spot,
            "ce_oi": (ce_oi or [1000] * n)[i],
            "ce_oi_change": 0.0,
            "ce_volume": 0.0,
            "ce_iv": (ce_iv or [20.0] * n)[i],
            "ce_last": 0.0,
            "pe_oi": (pe_oi or [1000] * n)[i],
            "pe_oi_change": 0.0,
            "pe_volume": 0.0,
            "pe_iv": (pe_iv or [20.0] * n)[i],
            "pe_last": 0.0,
        })
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# _max_pain
# ══════════════════════════════════════════════════════════════════════════════

def test_max_pain_at_middle_when_oi_symmetric() -> None:
    strikes = [2400, 2450, 2500, 2550, 2600]
    df = _chain(strikes, ce_oi=[1000] * 5, pe_oi=[1000] * 5)
    assert _max_pain(df) == 2500


def test_max_pain_shifted_when_oi_asymmetric() -> None:
    strikes = [2400, 2450, 2500, 2550, 2600]
    # Massive CE OI at 2600: call writers are short calls at 2600 strike.
    # Their pain is zero if spot finishes at 2600 (calls expire ATM), and
    # grows linearly as spot moves below 2600 (calls expire ITM to the
    # buyer, costing the writer). With symmetric put OI and no
    # counter-pressure on puts below, max pain collapses to 2600.
    df = _chain(strikes,
                 ce_oi=[100, 100, 100, 100, 50_000],
                 pe_oi=[100, 100, 100, 100, 100])
    assert _max_pain(df) == 2600

    # Conversely, massive PE OI at 2400 pulls max pain down to 2400 —
    # put writers want spot at or above 2400 so the puts expire OTM.
    df2 = _chain(strikes,
                  ce_oi=[100, 100, 100, 100, 100],
                  pe_oi=[50_000, 100, 100, 100, 100])
    assert _max_pain(df2) == 2400


# ══════════════════════════════════════════════════════════════════════════════
# _walls
# ══════════════════════════════════════════════════════════════════════════════

def test_walls_pick_largest_oi_within_scan() -> None:
    strikes = [2400, 2450, 2500, 2550, 2600]
    df = _chain(strikes, spot=2500,
                 ce_oi=[100, 100, 100, 5_000, 9_000],
                 pe_oi=[8_000, 4_000, 100, 100, 100])
    support, resistance = _walls(df, spot=2500, scan_pct=0.10)
    assert support == 2400
    assert resistance == 2600


def test_walls_none_when_no_oi_on_side() -> None:
    strikes = [2400, 2500, 2600]
    df = _chain(strikes, spot=2500,
                 ce_oi=[0, 0, 0], pe_oi=[0, 0, 0])
    support, resistance = _walls(df, spot=2500, scan_pct=0.10)
    assert support is None
    assert resistance is None


def test_walls_respect_scan_window() -> None:
    strikes = [2000, 2500, 3000]
    # Huge OI at 2000 but that's outside 10% of 2500 (= 2250).
    df = _chain(strikes, spot=2500,
                 ce_oi=[0, 0, 0],
                 pe_oi=[100_000, 100, 0])
    support, _ = _walls(df, spot=2500, scan_pct=0.05)
    assert support is None  # 2000 is outside the ±5% window


# ══════════════════════════════════════════════════════════════════════════════
# _net_gex
# ══════════════════════════════════════════════════════════════════════════════

def test_net_gex_positive_when_calls_dominate_at_atm() -> None:
    strikes = [2450, 2500, 2550]
    # Heavy CE OI at ATM, minimal PE → dealer-short-calls dominates → positive GEX.
    df = _chain(strikes, spot=2500, ce_oi=[10_000] * 3, pe_oi=[100] * 3)
    gex = _net_gex(df, spot=2500, dte=10, params=OptionsAnalysisParams())
    assert gex is not None and gex > 0


def test_net_gex_negative_when_puts_dominate() -> None:
    strikes = [2450, 2500, 2550]
    df = _chain(strikes, spot=2500, ce_oi=[100] * 3, pe_oi=[10_000] * 3)
    gex = _net_gex(df, spot=2500, dte=10, params=OptionsAnalysisParams())
    assert gex is not None and gex < 0


def test_net_gex_none_on_empty_chain() -> None:
    assert _net_gex(pd.DataFrame(), spot=2500, dte=10, params=OptionsAnalysisParams()) is None


# ══════════════════════════════════════════════════════════════════════════════
# _hvl, _pcr_oi, _iv_atm, _ivr_proxy
# ══════════════════════════════════════════════════════════════════════════════

def test_hvl_at_largest_combined_oi() -> None:
    strikes = [2400, 2450, 2500, 2550, 2600]
    df = _chain(strikes, ce_oi=[100, 100, 5_000, 100, 100],
                 pe_oi=[100, 100, 5_000, 100, 100])
    assert _hvl(df) == 2500


def test_pcr_oi_computes_ratio() -> None:
    df = _chain([2500], ce_oi=[1000], pe_oi=[1400])
    assert _pcr_oi(df) == pytest.approx(1.4)


def test_iv_atm_picks_nearest_strike() -> None:
    df = _chain([2400, 2500, 2600], spot=2475,
                 ce_iv=[18.0, 20.0, 22.0], pe_iv=[18.5, 20.5, 22.5])
    iv = _iv_atm(df, spot=2475)
    # Nearest strike is 2500; avg of 20.0 and 20.5.
    assert iv == pytest.approx(20.25)


def test_ivr_proxy_returns_mid_when_atm_is_median() -> None:
    strikes = list(range(2300, 2700, 50))
    ce_iv = list(range(15, 15 + len(strikes)))  # increasing
    df = _chain(strikes, ce_iv=ce_iv, pe_iv=ce_iv)
    # ATM (strike 2500) falls around mid of the IV distribution.
    ivr = _ivr_proxy(df, iv_atm=float(ce_iv[len(strikes) // 2]))
    assert ivr is not None and 40 <= ivr <= 60


def test_ivr_proxy_none_when_atm_missing() -> None:
    df = _chain([2500], ce_iv=[20.0])
    assert _ivr_proxy(df, iv_atm=None) is None


# ══════════════════════════════════════════════════════════════════════════════
# GEX regime / expiry risk classification
# ══════════════════════════════════════════════════════════════════════════════

def test_gex_regime_negative_is_trend_friendly() -> None:
    assert _classify_gex_regime(-1.0, None, OptionsAnalysisParams()) is GEXRegime.TREND_FRIENDLY


def test_gex_regime_positive_with_close_resistance_is_pinning() -> None:
    assert _classify_gex_regime(1.0, 1.0, OptionsAnalysisParams()) is GEXRegime.PINNING


def test_gex_regime_positive_with_far_resistance_is_trend_friendly() -> None:
    params = OptionsAnalysisParams(trend_min_resistance_pct=1.5)
    assert _classify_gex_regime(1.0, 3.0, params) is GEXRegime.TREND_FRIENDLY


def test_gex_regime_none_when_gex_none() -> None:
    assert _classify_gex_regime(None, 3.0, OptionsAnalysisParams()) is None


@pytest.mark.parametrize(("dte", "pin_close", "expected"), [
    (0, False, ExpiryRisk.HIGH),
    (2, False, ExpiryRisk.HIGH),
    (3, True,  ExpiryRisk.HIGH),
    (4, False, ExpiryRisk.ELEVATED),
    (4, True,  ExpiryRisk.HIGH),
    (10, False, ExpiryRisk.LOW),
    (10, True, ExpiryRisk.ELEVATED),
])
def test_expiry_risk_matrix(dte, pin_close, expected) -> None:
    spot = 2500.0
    max_pain = 2500.0 if pin_close else 2700.0
    risk = _classify_expiry_risk(
        dte=dte, spot=spot, max_pain=max_pain,
        params=OptionsAnalysisParams(),
    )
    assert risk is expected


# ══════════════════════════════════════════════════════════════════════════════
# Provider end-to-end
# ══════════════════════════════════════════════════════════════════════════════

def test_provider_returns_none_when_loader_empty() -> None:
    loader = MagicMock()
    loader.load.return_value = pd.DataFrame()
    provider = OptionsContextProvider(loader)
    assert provider.build(symbol="RELIANCE", asof_date=pd.Timestamp("2024-05-15")) is None


def test_provider_uses_index_endpoint_for_known_indices() -> None:
    loader = MagicMock()
    loader.load.return_value = _chain([22000, 22500], spot=22250, expiry="2024-05-30", dte=10)
    loader.get_expiries.side_effect = lambda df: sorted(df["expiry"].unique())
    provider = OptionsContextProvider(loader)
    _ = provider.build(symbol="NIFTY", asof_date=pd.Timestamp("2024-05-15"))
    # ``is_index=True`` is passed through.
    assert loader.load.call_args.kwargs.get("is_index") is True


def test_provider_uses_equity_endpoint_for_stocks() -> None:
    loader = MagicMock()
    loader.load.return_value = _chain([2400, 2500, 2600], spot=2500, expiry="2024-05-30", dte=10)
    loader.get_expiries.side_effect = lambda df: sorted(df["expiry"].unique())
    provider = OptionsContextProvider(loader)
    ctx = provider.build(symbol="RELIANCE", asof_date=pd.Timestamp("2024-05-15"))
    assert loader.load.call_args.kwargs.get("is_index") is False
    assert ctx is not None
    assert ctx.spot == pytest.approx(2500.0)
    assert ctx.pcr_oi is not None
    assert ctx.max_pain is not None
