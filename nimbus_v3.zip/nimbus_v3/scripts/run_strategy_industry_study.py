"""scripts/run_strategy_industry_study.py — OOS lift by industry for any strategy.

Runs a vectorised backtest for a named strategy gate set, computes
forward returns, and segments results by the four-level NSE industry
classification. Shows which industries are adding or subtracting
from the aggregate edge.

Usage:
    python scripts/run_strategy_industry_study.py --strategy ride
    python scripts/run_strategy_industry_study.py --strategy mr --fwd-days 10
    python scripts/run_strategy_industry_study.py --strategy ride --group-by sector
    python scripts/run_strategy_industry_study.py --strategy mr --group-by basicIndustry
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_PROJECT_ROOT = _HERE.parent
sys.path.insert(0, str(_PROJECT_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.data.industry_db import load_industry_db
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns


# ══════════════════════════════════════════════════════════════════════════════
# Strategy gate sets — vectorised per-bar predicates
# ══════════════════════════════════════════════════════════════════════════════

def _ride_fires(df: pd.DataFrame) -> pd.Series:
    """BB ride: close in 1–2σ zone, green_streak ≥ 3, ADX > 25."""
    return (
        df["data_sufficient"].fillna(False)
        & (df["Close"] >= df["bb_20_1s_upper"])
        & (df["Close"] <= df["bb_20_2s_upper"])
        & (df["green_streak"] >= 3)
        & (df["adx_14"] > 25)
    )


def _mr_fires(df: pd.DataFrame) -> pd.Series:
    """Mean Reversion: WR30 ≤ −80, MFI < 30, close < bb_20_1s_lower."""
    return (
        df["data_sufficient"].fillna(False)
        & (df["wr_30"] <= -80)
        & (df["mfi_14"] < 30)
        & (df["Close"] < df["bb_20_1s_lower"])
    )


def _breakout_fires(df: pd.DataFrame) -> pd.Series:
    """Breakout: close > bb_20_2s_upper, ADX > 25, volume ratio > 1.5."""
    return (
        df["data_sufficient"].fillna(False)
        & (df["Close"] > df["bb_20_2s_upper"])
        & (df["adx_14"] > 25)
        & (df["vol_ratio_20"] > 1.5)
    )


def _pullback_fires(df: pd.DataFrame) -> pd.Series:
    """Pullback in uptrend: above SMA50, close < SMA20, RSI < 40."""
    return (
        df["data_sufficient"].fillna(False)
        & (df["Close"] > df["sma_50"])
        & (df["Close"] < df["sma_20"])
        & (df["rsi_14"] < 40)
    )


_STRATEGY_GATES = {
    "ride": _ride_fires,
    "mr": _mr_fires,
    "breakout": _breakout_fires,
    "pullback": _pullback_fires,
}


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Strategy OOS lift segmented by NSE industry classification.",
    )
    parser.add_argument(
        "--strategy", type=str, required=True,
        choices=list(_STRATEGY_GATES),
        help="Strategy gate set to test.",
    )
    parser.add_argument(
        "--fwd-days", type=int, default=5,
        help="Forward return horizon (default 5).",
    )
    parser.add_argument(
        "--split-date", type=str, default="2025-01-01",
        help="Train/test split (default 2025-01-01).",
    )
    parser.add_argument(
        "--group-by", type=str, default="industry",
        choices=["macro_sector", "sector", "industry", "basic_industry"],
        help="Classification level for grouping (default: industry = industryInfo).",
    )
    parser.add_argument(
        "--min-fires", type=int, default=5,
        help="Minimum test-period fires to show an industry (default 5).",
    )
    args = parser.parse_args()

    gate_fn = _STRATEGY_GATES[args.strategy]
    fwd_days = args.fwd_days
    split = pd.Timestamp(args.split_date)
    group_key = args.group_by
    min_fires = args.min_fires

    # 1. Industry DB.
    industry_db = load_industry_db()
    if not industry_db:
        print("ERROR: Industry DB not found. Run scripts/build_industry_db.py first.")
        return 1

    # 2. Equity panel for all DB symbols.
    db_symbols = tuple(sorted(industry_db.keys()))
    print(f"Loading equity panel for {len(db_symbols)} symbols…")
    panel = load_equity_panel(symbols=db_symbols)
    if not panel:
        print("No panel loaded.")
        return 1

    # 3. Enrich.
    print("Enriching…")
    compute = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            enriched[sym] = compute.enrich(df, sym)
        except Exception:    # noqa: BLE001
            continue
    print(f"  → {len(enriched)} symbols enriched")

    # 4. Scan + forward returns.
    print(f"Scanning {args.strategy.upper()} fires + {fwd_days}d returns…")
    records: list[dict] = []
    baseline_parts: list[pd.Series] = []

    for sym, df in enriched.items():
        ic = industry_db.get(sym.upper())
        if ic is None:
            continue

        df = add_forward_returns(df, horizons=(fwd_days,))
        fwd_col = f"fwd_ret_{fwd_days}d"
        if fwd_col not in df.columns:
            continue

        baseline_parts.append(df[fwd_col].dropna())

        try:
            fires = gate_fn(df)
        except (KeyError, TypeError):
            continue
        if fires.sum() == 0:
            continue

        for idx in df.index[fires]:
            fwd = df.loc[idx, fwd_col]
            if pd.isna(fwd):
                continue
            records.append({
                "symbol": sym,
                "date": idx,
                "fwd_return": float(fwd),
                "macro_sector": ic.macro_sector,
                "sector": ic.sector,
                "industry": ic.industry,
                "basic_industry": ic.basic_industry,
            })

    if not records:
        print("No fires found.")
        return 1

    all_fires = pd.DataFrame(records)
    baseline = float(pd.concat(baseline_parts).mean()) if baseline_parts else 0.0

    train = all_fires[all_fires["date"] < split]
    test = all_fires[all_fires["date"] >= split]

    print(f"  → {len(all_fires)} fires, {all_fires['symbol'].nunique()} symbols")
    print(f"  → Train: {len(train)}  Test: {len(test)}")
    print(f"  → Baseline {fwd_days}d: {baseline:+.4f}%")

    # 5. Per-group stats.
    print(f"\n{'═' * 120}")
    print(
        f"  {args.strategy.upper()} — {fwd_days}d FWD RETURN BY "
        f"{group_key.upper()} | split {split.date()}"
    )
    print(f"{'═' * 120}")

    rows = []
    for group, grp in all_fires.groupby(group_key):
        tr = grp[grp["date"] < split]
        te = grp[grp["date"] >= split]
        if len(te) < min_fires:
            continue
        tr_mean = float(tr["fwd_return"].mean()) if len(tr) else 0.0
        te_mean = float(te["fwd_return"].mean()) if len(te) else 0.0
        tr_wr = float((tr["fwd_return"] > 0).mean() * 100) if len(tr) else 0.0
        te_wr = float((te["fwd_return"] > 0).mean() * 100) if len(te) else 0.0

        rows.append({
            "Group": group,
            "Train_N": len(tr),
            "Train_Mean%": round(tr_mean, 3),
            "Train_WR%": round(tr_wr, 1),
            "Train_Lift": round(tr_mean - baseline, 3),
            "Test_N": len(te),
            "Test_Mean%": round(te_mean, 3),
            "Test_WR%": round(te_wr, 1),
            "Test_Lift": round(te_mean - baseline, 3),
            "Decay": round((te_mean - baseline) - (tr_mean - baseline), 3),
        })

    result = pd.DataFrame(rows).sort_values("Test_Lift", ascending=False)
    print(result.to_string(index=False))

    # Summary.
    pos = result[result["Test_Lift"] > 0]
    neg = result[result["Test_Lift"] < 0]
    print(f"\n  Positive test lift: {len(pos)} / {len(result)} groups")
    print(f"  Negative test lift: {len(neg)} / {len(result)} groups")

    if not pos.empty:
        print(f"\n  EDGE CONFIRMED ({group_key}):")
        for _, r in pos.head(10).iterrows():
            print(
                f"    {r['Group']:<40s}  lift {r['Test_Lift']:+.3f}%  "
                f"WR {r['Test_WR%']:.0f}%  n={r['Test_N']}"
            )

    # Aggregate positive-edge bucket.
    if not pos.empty:
        pos_fires = test[test[group_key].isin(pos["Group"])]
        if len(pos_fires) >= 20:
            agg = float(pos_fires["fwd_return"].mean())
            wr = float((pos_fires["fwd_return"] > 0).mean() * 100)
            print(f"\n  AGGREGATE (positive-lift groups only):")
            print(f"    fires: {len(pos_fires)}  mean: {agg:+.3f}%  "
                  f"WR: {wr:.0f}%  lift: {agg - baseline:+.3f}%")

    # Export.
    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("data/research")
    out_dir.mkdir(parents=True, exist_ok=True)

    summary_path = out_dir / f"{args.strategy}_by_{group_key}_{fwd_days}d_{ts}.csv"
    result.to_csv(summary_path, index=False)
    print(f"\n  Exported summary  → {summary_path}")

    fires_path = out_dir / f"{args.strategy}_fires_{fwd_days}d_{ts}.csv"
    all_fires.to_csv(fires_path, index=False)
    print(f"  Exported fires    → {fires_path}")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
