"""nimbus_v3.strategies.trap — filing-driven TRAP override.

Highest priority strategy. Fires on any symbol whose most recent filing
within the lookback window classifies as ``FilingImpact.TRAP``. The
conviction engine recognises the TRAP setup type and forces a
downgrade (typically to F) so position sizing zeroes out.

Entry gates
───────────
- ``contexts.filing`` is not ``None``
- ``contexts.filing.is_trap`` is True

No technical gates — the filing alone justifies the override.
"""
from __future__ import annotations

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


class TrapStrategy:
    """Filing-driven TRAP override. Accepts every symbol that could
    have filings (equities and ETFs both — though ETFs rarely do)."""

    name: str = "Trap"
    setup_type: SetupType = SetupType.TRAP
    priority: int = 100          # highest — overrides everything
    #: TRAP is a verdict override, not a score contributor — the
    #: grade engine forces ``Sizing.SKIP`` on any TRAP signal regardless
    #: of score. This weight is 1.0 for protocol-conformance but
    #: never actually scales a contribution in practice.
    production_weight: float = 1.0

    def accepts(self, symbol_meta: SymbolMeta) -> bool:     # noqa: ARG002
        return True

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,       # noqa: ARG002 — no technical gates
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        filing = contexts.filing
        if filing is None or not filing.is_trap:
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(contexts.asof_date),
            priority=self.priority,
            metadata={
                "filing_headline": filing.latest_headline,
                "days_since_filing": filing.days_since_latest,
            },
        )
