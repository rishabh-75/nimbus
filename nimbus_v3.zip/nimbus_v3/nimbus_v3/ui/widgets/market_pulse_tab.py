"""nimbus_v3.ui.widgets.market_pulse_tab — universe breadth charts.

A stacked, date-aligned multi-panel chart that plots market-breadth
series against the CNX500 (NIFTY 500) index, so the operator can read
the broad market's internal strength at a glance:

    ┌───────────────────────────────────────┐
    │ CNX500 close                          │
    ├───────────────────────────────────────┤
    │ % above SMA50  /  % above SMA200      │
    ├───────────────────────────────────────┤
    │ Advance / Decline line                │
    ├───────────────────────────────────────┤
    │ New highs − new lows                  │
    └───────────────────────────────────────┘

Pure view: it receives a breadth DataFrame (from
``compute.market_breadth.compute_breadth``) and an optional CNX500
Close series, and renders. No computation here.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pyqtgraph as pg
from PyQt6.QtGui import QFont
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QLabel, QSplitter, QVBoxLayout, QWidget

from nimbus_v3.compute.seasonality import compute_seasonality
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, EM, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED,
    VIOLET, WHITE,
)
from nimbus_v3.ui.widgets.seasonality_widget import SeasonalityWidget


class _DateAxisItem(pg.AxisItem):
    """Bottom axis that renders integer x positions as dates."""

    def __init__(self, timestamps=None, *a, **kw):    # noqa: ANN001
        super().__init__(*a, **kw)
        self._ts = timestamps
        self.setStyle(tickFont=QFont(FONT_MONO, 9))

    def set_timestamps(self, ts) -> None:    # noqa: ANN001
        self._ts = ts

    def tickStrings(self, values, scale, spacing):    # noqa: ANN001, N802
        if self._ts is None or len(self._ts) == 0:
            return [""] * len(values)
        out = []
        n = len(self._ts)
        for v in values:
            i = int(round(v))
            if 0 <= i < n:
                out.append(pd.Timestamp(self._ts[i]).strftime("%b '%y"))
            else:
                out.append("")
        return out


class MarketPulseTab(QWidget):
    """Stacked breadth panels vs CNX500. Call :meth:`set_data`."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        # Breadth panels (top) and market seasonality (bottom) share the
        # tab via a vertical splitter so the operator can rebalance them.
        self._split = QSplitter(Qt.Orientation.Vertical)
        layout.addWidget(self._split)

        self._glw = pg.GraphicsLayoutWidget()
        self._glw.setBackground(BG)
        self._split.addWidget(self._glw)

        self._date_axis = _DateAxisItem(orientation="bottom")

        # Four stacked plots sharing the x-axis.
        self._p_index = self._glw.addPlot(row=0, col=0)
        self._p_ma = self._glw.addPlot(row=1, col=0)
        self._p_ad = self._glw.addPlot(row=2, col=0)
        self._p_nhnl = self._glw.addPlot(
            row=3, col=0, axisItems={"bottom": self._date_axis},
        )
        self._plots = [self._p_index, self._p_ma, self._p_ad, self._p_nhnl]

        titles = ["CNX500", "% ABOVE SMA  (50 green · 200 violet)",
                  "ADVANCE / DECLINE LINE", "NEW HIGHS − NEW LOWS"]
        for plot, title in zip(self._plots, titles):
            plot.showGrid(x=True, y=True, alpha=0.08)
            plot.setMenuEnabled(False)
            plot.hideButtons()
            # Y-axis on the RIGHT: show the right axis with values, hide
            # the left so the scale sits beside the latest (right-most)
            # data rather than the far edge.
            plot.showAxis("right")
            plot.hideAxis("left")
            for side in ("left", "right", "top", "bottom"):
                ax = plot.getAxis(side)
                ax.setPen(pg.mkPen(BORDER, width=0.5))
                ax.setTextPen(pg.mkPen(MUTED))
                ax.setStyle(tickFont=QFont(FONT_MONO, 9))
            plot.setTitle(title, color=MUTED, size="9pt")
        # Stretch the index panel taller; link x across all panels.
        self._glw.ci.layout.setRowStretchFactor(0, 3)
        for plot in self._plots[1:]:
            plot.setXLink(self._p_index)
        # Hide x ticks on all but the bottom panel.
        for plot in self._plots[:-1]:
            plot.getAxis("bottom").setStyle(showValues=False)

        # Crosshair (same pattern as the dashboard price chart): one
        # shared vertical line tracked across all panels, a horizontal
        # line per panel, and a date+value readout label that follows
        # the cursor. _series holds the plotted arrays for value lookup.
        self._ts: list = []
        self._series: dict = {}
        self._install_crosshair()
        self._glw.scene().sigMouseMoved.connect(self._on_mouse_moved)

        # ── Market seasonality (bottom of splitter) ─────────────────
        # Fixed height so the path chart always has room — without this
        # the splitter's stretch math crushed it to a sliver. The
        # breadth panels above take all remaining vertical space.
        season_panel = QWidget()
        season_panel.setFixedHeight(248)
        sp_lay = QVBoxLayout(season_panel)
        sp_lay.setContentsMargins(0, 8, 0, 0)
        sp_lay.setSpacing(4)
        season_title = QLabel("MARKET SEASONALITY  (CNX500)")
        season_title.setFont(QFont(FONT_UI, 8, QFont.Weight.Bold))
        season_title.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        sp_lay.addWidget(season_title)
        self._seasonality = SeasonalityWidget()
        sp_lay.addWidget(self._seasonality)
        self._split.addWidget(season_panel)

        # Breadth gets all stretch; seasonality holds its fixed height.
        self._split.setStretchFactor(0, 1)
        self._split.setStretchFactor(1, 0)
        self._split.setCollapsible(1, False)
        self._split_sized = False

        self._placeholder_shown = False
        self._show_placeholder()

    def showEvent(self, event):    # noqa: ANN001, N802
        """Size the splitter on first show so the breadth panels get all
        the space above the fixed-height seasonality strip. Without this,
        the GraphicsLayoutWidget's small initial size hint wins and the
        breadth panels start squeezed until the operator drags the
        handle (which forces a re-layout). Done once."""
        super().showEvent(event)
        if not self._split_sized:
            total = self._split.height()
            season_h = 248
            if total > season_h:
                self._split.setSizes([total - season_h, season_h])
                self._split_sized = True

    # ── crosshair ───────────────────────────────────────────────────────────

    def _install_crosshair(self) -> None:
        _pen = pg.mkPen(BORDER, width=0.6, style=pg.QtCore.Qt.PenStyle.DashLine)
        self._cross_v = pg.InfiniteLine(angle=90, movable=False, pen=_pen)
        self._cross_v.setVisible(False)
        # Vertical line lives on the top plot but is drawn across all via
        # the shared x-link; add one per panel so it spans the full stack.
        self._cross_v_lines = []
        self._cross_h = []
        for plot in self._plots:
            v = pg.InfiniteLine(angle=90, movable=False, pen=_pen)
            v.setVisible(False)
            plot.addItem(v, ignoreBounds=True)
            self._cross_v_lines.append(v)
            h = pg.InfiniteLine(angle=0, movable=False, pen=_pen)
            h.setVisible(False)
            plot.addItem(h, ignoreBounds=True)
            self._cross_h.append(h)
        # Readout label, anchored top-left of the index panel.
        self._readout = pg.TextItem(color=WHITE, anchor=(0, 0))
        self._readout.setFont(QFont(FONT_MONO, 9))
        self._readout.setVisible(False)
        self._p_index.addItem(self._readout, ignoreBounds=True)

    def _on_mouse_moved(self, pos) -> None:
        if not self._ts:
            return
        for i, plot in enumerate(self._plots):
            if plot.sceneBoundingRect().contains(pos):
                mp = plot.vb.mapSceneToView(pos)
                xi = int(round(mp.x()))
                # vertical line on every panel at the same x
                for v in self._cross_v_lines:
                    v.setPos(mp.x())
                    v.setVisible(True)
                # horizontal line only on the hovered panel
                for j, h in enumerate(self._cross_h):
                    if j == i:
                        h.setPos(mp.y())
                        h.setVisible(True)
                    else:
                        h.setVisible(False)
                self._update_readout(xi)
                return
        self._hide_crosshair()

    def _update_readout(self, xi: int) -> None:
        if not self._ts or xi < 0 or xi >= len(self._ts):
            self._readout.setVisible(False)
            return
        date_str = pd.Timestamp(self._ts[xi]).strftime("%d %b %Y")
        parts = [date_str]
        labels = {
            "index": "CNX500", "pct50": "%>50", "pct200": "%>200",
            "ad": "A/D", "nhnl": "NH-NL",
        }
        for key, lbl in labels.items():
            arr = self._series.get(key)
            if arr is not None and xi < len(arr):
                v = arr[xi]
                if v == v:    # not NaN
                    parts.append(f"{lbl} {v:,.0f}" if abs(v) >= 100
                                 else f"{lbl} {v:.1f}")
        self._readout.setText("  ".join(parts))
        # anchor near top-left of the index panel's current view range
        vb = self._p_index.vb.viewRange()
        self._readout.setPos(vb[0][0], vb[1][1])
        self._readout.setVisible(True)

    def _hide_crosshair(self) -> None:
        for v in self._cross_v_lines:
            v.setVisible(False)
        for h in self._cross_h:
            h.setVisible(False)
        self._readout.setVisible(False)

    # ── public API ────────────────────────────────────────────────────────

    def set_data(
        self, breadth: pd.DataFrame, index_close: pd.Series | None = None,
    ) -> None:
        """Render the breadth frame (+ optional CNX500 Close series)."""
        for plot in self._plots:
            plot.clear()

        # Market seasonality from the CNX500 series (independent of the
        # breadth panels; renders its own empty-state if too little
        # history). Done first so an early return on empty breadth
        # doesn't skip it.
        if index_close is not None and not index_close.empty:
            self._seasonality.set_result(compute_seasonality(index_close))

        if breadth is None or breadth.empty:
            self._show_placeholder()
            return

        ts = list(breadth.index)
        self._ts = ts
        self._date_axis.set_timestamps(ts)
        x = np.arange(len(breadth), dtype=float)

        # Capture plotted series for the crosshair readout.
        series: dict = {}
        idx_arr = None

        # Panel 1 — CNX500 close, reindexed onto the breadth dates.
        if index_close is not None and not index_close.empty:
            idx = index_close.reindex(breadth.index).ffill()
            idx_arr = idx.to_numpy(dtype=float)
            self._p_index.plot(x, idx_arr, pen=pg.mkPen(WHITE, width=1.2))
        else:
            txt = pg.TextItem("CNX500 unavailable", color=MUTED,
                              anchor=(0.5, 0.5))
            self._p_index.addItem(txt)
            txt.setPos(len(breadth) / 2, 0)
        if idx_arr is not None:
            series["index"] = idx_arr

        # Panel 2 — % above SMA50 / SMA200, with the 50% reference line.
        self._p_ma.addItem(pg.InfiniteLine(
            pos=50, angle=0, pen=pg.mkPen(MUTED, width=0.5,
                                          style=pg.QtCore.Qt.PenStyle.DashLine)))
        pct50 = breadth["pct_above_sma50"].to_numpy(dtype=float)
        pct200 = breadth["pct_above_sma200"].to_numpy(dtype=float)
        self._p_ma.plot(x, pct50, pen=pg.mkPen(GREEN, width=1.2))
        self._p_ma.plot(x, pct200, pen=pg.mkPen(VIOLET, width=1.2))
        self._p_ma.setYRange(0, 100)
        series["pct50"], series["pct200"] = pct50, pct200

        # Panel 3 — A/D line.
        ad = breadth["ad_line"].to_numpy(dtype=float)
        self._p_ad.plot(x, ad, pen=pg.mkPen(BLUE, width=1.2))
        self._p_ad.addItem(pg.InfiniteLine(
            pos=0, angle=0, pen=pg.mkPen(MUTED, width=0.5,
                                         style=pg.QtCore.Qt.PenStyle.DashLine)))
        series["ad"] = ad

        # Panel 4 — new highs − new lows as a zero-centered bar/line.
        nhnl = breadth["nh_nl_diff"].to_numpy(dtype=float)
        self._p_nhnl.plot(x, nhnl, pen=pg.mkPen(GOLD, width=1.0),
                          fillLevel=0, brush=pg.mkBrush(245, 158, 11, 60))
        self._p_nhnl.addItem(pg.InfiniteLine(
            pos=0, angle=0, pen=pg.mkPen(MUTED, width=0.5)))
        series["nhnl"] = nhnl

        self._series = series
        # plot.clear() above wiped the crosshair items — reinstall them.
        self._install_crosshair()
        self._placeholder_shown = False

    # ── internals ─────────────────────────────────────────────────────────

    def _show_placeholder(self) -> None:
        if self._placeholder_shown:
            return
        txt = pg.TextItem(
            "Market breadth loads with the universe panel.",
            color=MUTED, anchor=(0.5, 0.5),
        )
        self._p_index.addItem(txt)
        txt.setPos(0, 0)
        self._placeholder_shown = True
