"""nimbus_v3.tracking.schema — SQLite schema for the signal log.

Stores every signal emitted by any scan (production + research-tier)
so that realised forward returns can be backfilled and rolling lift
statistics computed.

Schema design notes
───────────────────

1. **One row per (symbol, asof_date, strategy_name) signal.** Multiple
   strategies firing on the same symbol/bar produce multiple rows.
   The unique constraint prevents duplicate recording from replayed
   scans.

2. **Conviction snapshot is stored, not recomputed.** The grade engine
   is authoritative; once a signal is recorded, its conviction stays
   frozen even if formula constants change later. Keeps the log as an
   honest record of "what did we think at the time" — essential for
   walk-forward research validation.

3. **Forward returns are nullable.** A fresh record has no forward
   returns; ``backfill_returns()`` populates them once the price
   history advances past ``asof_date + N``. ``recorded_at`` and
   ``returns_filled_at`` timestamps make it trivial to find records
   that are due for backfill.

4. **``production_weight`` stored explicitly.** Enables fast queries
   for "production-tier signals only" without joining back to the
   strategy config. Research-tier promotions in v3.1 change the
   strategy's weight, but the log row reflects the weight at scan
   time.

5. **``contributions_json`` is a compact blob.** Stored verbatim as
   a JSON string keyed by contribution name. Not queried directly;
   used for audit and for regenerating display reasons when rendering
   historical signals in the UI.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Final


#: Schema version. Bump when the DDL changes in a breaking way.
#: ``migrate_if_needed()`` handles forward-only migrations.
SCHEMA_VERSION: Final[int] = 1


_DDL: Final[list[str]] = [
    """
    CREATE TABLE IF NOT EXISTS schema_version (
        version INTEGER PRIMARY KEY
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS signals (
        -- Identifying fields.
        id                    INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol                TEXT    NOT NULL,
        asof_date             TEXT    NOT NULL,   -- ISO date (YYYY-MM-DD)
        strategy_name         TEXT    NOT NULL,
        setup_type            TEXT    NOT NULL,
        priority              INTEGER NOT NULL,

        -- Conviction snapshot (frozen at record-time).
        score                 REAL    NOT NULL,
        raw_score             REAL    NOT NULL,
        grade                 TEXT    NOT NULL,
        verdict               TEXT    NOT NULL,
        sizing                TEXT    NOT NULL,
        production_weight     REAL    NOT NULL,
        override_reason       TEXT,

        -- Contribution trail, stored as JSON for audit and display.
        contributions_json    TEXT    NOT NULL,

        -- Price captured at signal time — used to compute forward
        -- returns once N-days-later closes are available. Nullable:
        -- scanners that don't capture a close write NULL and those
        -- rows are skipped by backfill.
        close_price           REAL,

        -- Realised forward returns (NULL until backfilled).
        fwd_ret_1d            REAL,
        fwd_ret_5d            REAL,
        fwd_ret_10d           REAL,
        fwd_ret_20d           REAL,

        -- Audit timestamps (seconds since epoch, UTC).
        recorded_at           REAL    NOT NULL,
        returns_filled_at     REAL,

        UNIQUE (symbol, asof_date, strategy_name)
    );
    """,
    # Indexes for common query patterns.
    """
    CREATE INDEX IF NOT EXISTS idx_signals_strategy_date
        ON signals (strategy_name, asof_date);
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_signals_asof
        ON signals (asof_date);
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_signals_needs_backfill
        ON signals (asof_date, returns_filled_at);
    """,
]


def connect(db_path: Path) -> sqlite3.Connection:
    """Open a SQLite connection with sane defaults and ensure the schema exists.

    Creates the parent directory if missing. Uses WAL journal mode for
    concurrent readers + single-writer performance.
    """
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    _migrate_if_needed(conn)
    return conn


def _migrate_if_needed(conn: sqlite3.Connection) -> None:
    """Create schema on first connection; apply forward migrations otherwise."""
    for stmt in _DDL:
        conn.execute(stmt)
    row = conn.execute("SELECT version FROM schema_version").fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO schema_version (version) VALUES (?)", (SCHEMA_VERSION,),
        )
    # Future: if row["version"] < SCHEMA_VERSION, apply migrations.
    conn.commit()


def schema_version(conn: sqlite3.Connection) -> int:
    """Return the currently-installed schema version."""
    row = conn.execute("SELECT version FROM schema_version").fetchone()
    return int(row["version"]) if row else 0
