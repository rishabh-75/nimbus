"""nimbus_v3.core.types — shared enums used across layers.

Every enum here is a named, closed set of values. Downstream code
branches on these enums, never on raw strings. String representations
are deliberate and stable (logged, rendered in the UI), so changing
an enum value is a breaking change.

Design rules:
    - Every enum is a ``str`` subclass so equality with a raw string
      works but membership can still be checked via ``isinstance``.
    - No enum has an "UNKNOWN" value — absence is represented by
      ``None`` at the field, not by a sentinel enum member.

Slim profile (post-refactor): the surviving enums are exactly those
consumed by the four context providers (market, sector, options,
filing). Strategy / conviction / mode-toggle enums (``SetupType``,
``GradeLetter``, ``Verdict``, ``Sizing``, ``StrategyMode``) and the
commodity-flow / vol-state enums (``FlowSignal``, ``VolState``) were
deleted alongside the strategies, conviction, and macro packages.
"""
from __future__ import annotations

from enum import Enum


class VIXRegime(str, Enum):
    """India VIX regime bucketing. Carried on ``MarketContext``."""
    LOW = "LOW"
    NORMAL = "NORMAL"
    ELEVATED = "ELEVATED"
    HIGH = "HIGH"
    PANIC = "PANIC"


class SectorType(str, Enum):
    """Cyclical/defensive classification. Carried on ``SectorContext``."""
    CYCLICAL = "CYCLICAL"
    DEFENSIVE = "DEFENSIVE"


class RSRegime(str, Enum):
    """Relative-strength regime of a sector vs. the broad market.

    LEADING  = sector outperforming NIFTY on a rolling window.
    LAGGING  = sector underperforming.
    NEUTRAL  = no clear edge either way.
    """
    LEADING = "LEADING"
    NEUTRAL = "NEUTRAL"
    LAGGING = "LAGGING"


class ExpiryRisk(str, Enum):
    """Options-expiry proximity risk bucket. Carried on ``OptionsContext``."""
    LOW = "LOW"
    ELEVATED = "ELEVATED"
    HIGH = "HIGH"


class GEXRegime(str, Enum):
    """Gamma-exposure regime from options positioning.

    TREND_FRIENDLY = dealer gamma short / neutral → trending moves
    are supported.
    PINNING        = dealer gamma long → spot pinned around key strikes.
    """
    TREND_FRIENDLY = "TREND_FRIENDLY"
    PINNING = "PINNING"


class FilingImpact(str, Enum):
    """Impact classification for a corporate filing.

    Carried on ``FilingContext``.
    """
    NONE = "NONE"
    MINOR = "MINOR"
    MATERIAL = "MATERIAL"
    TRAP = "TRAP"
