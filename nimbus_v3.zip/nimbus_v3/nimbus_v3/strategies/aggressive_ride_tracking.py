"""nimbus_v3.strategies.aggressive_ride_tracking — tracking-tier BB ride.

Companion to :class:`AggressiveRideStrategy`. Where ``AggressiveRide``
emits production-grade fresh-entry signals (volume-confirmed, recent
green streak, above upper band), this tracking-tier strategy emits
**research-weight** signals for ongoing rides that aren't fresh
entries — a ride that's been in play for multiple bars, or one with
quiet volume.

Oracle parity
─────────────

Oracle's ``modules/bb_ride.py`` always produces a result for every
symbol, but only ``entry_triggered`` (fresh upper-band touch) cases
receive a numeric grade. Non-entry at-upper cases get an ungraded
``△ RIDING — at upper band`` verdict — informative but not
actionable as a fresh entry.

V3's framework is different: strategies either fire (and get graded)
or return None. To match oracle's "graded entries + ungraded
tracking, all in one Ride panel" behaviour, we split the emission
across two strategy classes:

- ``AggressiveRideStrategy`` — ``production_weight = 1.0``, narrow
  gates that mirror oracle's ``entry_triggered``. These get real
  grades from the conviction formula.
- ``AggressiveRideTrackingStrategy`` (this class) —
  ``production_weight = 0.0``, loose gates that capture all "ride
  in play" cases the production strategy wouldn't fire for. The
  conviction engine's research-only override forces grade=D,
  verdict=WATCH, sizing=SKIP — exactly the ungraded-tracking
  signature that matches oracle's ``△ RIDING`` rows.

Both emit ``setup_type = SetupType.RIDE`` so they share the RIDE
bucket in the scanner routing. The scanner's Ride table therefore
shows both graded entries (top) and ungraded tracking (below),
ordered by score then priority.

De-duplication
──────────────

When the primary AggressiveRide gates also fire for a bar, this
tracking strategy returns None — the production signal takes the
slot so we don't show the same symbol twice in the Ride panel.
Priority is also set below AggressiveRide's so sort ordering keeps
production entries above tracking rows even on boundary cases.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Gate parameters — loose by design. Tracking cares about "is the ride
# currently in play", not "is this a fresh entry with volume confirmation".
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class AggressiveRideTrackingParams:
    #: ADX floor — oracle's bb_ride treats sub-20 ADX as chop, not ride.
    #: Same threshold as the production AggressiveRide to keep the
    #: "this is actually a trending ride" semantics consistent.
    adx_14_min: float = 20.0


#: The primary-tier gates from AggressiveRide that we check to
#: DE-DUPE. If BOTH of these pass, the production strategy will
#: fire and this tracking strategy returns None. These must stay in
#: sync with :class:`AggressiveRideParams` — if the primary gates
#: change, revisit this de-dupe.
_PRIMARY_VOL_RATIO_MIN: float = 1.2
_PRIMARY_GREEN_STREAK_MIN: int = 1


class AggressiveRideTrackingStrategy:
    """Tracking-tier BB ride. Rejects ETFs.

    Routes to the same RIDE bucket as :class:`AggressiveRideStrategy`
    but with research weight so the conviction engine's override
    forces grade=D / verdict=WATCH / sizing=SKIP. Shows up in the
    Scanner's Ride table as ungraded tracking rows below the real
    graded entries.
    """

    name: str = "AggressiveRideTracking"
    setup_type: SetupType = SetupType.RIDE
    priority: int = 35          # below AggressiveRide's 40 — tracking sorts after entries
    production_weight: float = 0.0

    def __init__(
        self,
        params: AggressiveRideTrackingParams = AggressiveRideTrackingParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        # Same acceptance as AggressiveRide — no ETFs, no industry gate.
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — purely state-driven
    ) -> StrategySignal | None:
        # Core: close at or above the upper 1σ band.
        if state.bb_20_1s_upper <= 0:
            return None
        if state.close < state.bb_20_1s_upper:
            return None
        # Trending, not chop — same ADX floor as production.
        if state.adx_14 < self._p.adx_14_min:
            return None
        # De-dupe: if the primary AggressiveRide gates would fire,
        # return None and let the production signal take the slot.
        # Prevents the same symbol from appearing twice in the Ride
        # panel with conflicting grades.
        if (
            state.vol_ratio_20 >= _PRIMARY_VOL_RATIO_MIN
            and state.green_streak >= _PRIMARY_GREEN_STREAK_MIN
        ):
            return None

        # Compute %B for metadata — a convenient display value that
        # tells the operator how extended the ride is ("at UB" vs
        # "deep above UB"). Avoids a divide-by-zero on narrow bands.
        band_width = state.bb_20_1s_upper - state.bb_20_1s_lower
        bb_pct = (
            (state.close - state.bb_20_1s_lower) / band_width
            if band_width > 0 else 1.0
        )

        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "close": state.close,
                "bb_1s_upper": state.bb_20_1s_upper,
                "bb_1s_lower": state.bb_20_1s_lower,
                "bb_pct": bb_pct,
                "adx_14": state.adx_14,
                "vol_ratio_20": state.vol_ratio_20,
                "green_streak": state.green_streak,
                "kind": "tracking",
            },
        )
