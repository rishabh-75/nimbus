"""Public types for the ride classification engine.

``RidePhase`` is a string-valued enum so its value IS the display
label — UI code can use the enum value directly without a lookup
table. ``RideResult`` is the immutable return type from
``RideEngine.classify``, bundling per-bar phase, score, and bool.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Final

import numpy as np
import pandas as pd


class RidePhase(str, Enum):
    """Categorical label for each bar's ride state.

    Values are the display labels — short codes that fit a narrow UI
    column. Priority ordering (lowest → highest conviction) is encoded
    in :meth:`priority`.
    """

    NONE = "—"
    CONTINUATION = "CONT"
    RETEST = "RETEST"
    INITIATION = "INIT"

    @property
    def priority(self) -> int:
        """Sort key — higher is more conviction.

        Used for:
          - Phase resolution when multiple detectors fire on the same
            bar (highest priority wins).
          - Sort order in the UI Phase column.
        """
        return _PRIORITY[self]


_PRIORITY: Final[dict[RidePhase, int]] = {
    RidePhase.NONE: 0,
    RidePhase.CONTINUATION: 1,
    RidePhase.RETEST: 2,
    RidePhase.INITIATION: 3,
}


@dataclass(frozen=True)
class RideResult:
    """Per-bar ride classification + composite score.

    ``phase``, ``score``, and ``fire`` all share the same index
    (the input dataframe's). ``score`` is NaN where phase is NONE.

    Use ``latest_phase`` / ``latest_score`` for "what does the most
    recent bar show?" — the typical screener use case.
    """

    phase: pd.Series
    score: pd.Series
    fire: pd.Series

    @property
    def latest_phase(self) -> RidePhase:
        """Phase at the last bar. Returns ``NONE`` for empty series."""
        if self.phase.empty:
            return RidePhase.NONE
        val = self.phase.iloc[-1]
        if isinstance(val, RidePhase):
            return val
        # String value from pd.Series storage — coerce back to enum.
        return RidePhase(val)

    @property
    def latest_score(self) -> float:
        """Composite score at the last bar. NaN if no fire."""
        if self.score.empty:
            return float("nan")
        return float(self.score.iloc[-1])

    @property
    def is_active(self) -> bool:
        """True if the last bar has any phase other than NONE."""
        return self.latest_phase is not RidePhase.NONE

    @classmethod
    def empty(cls, index: pd.Index) -> RideResult:
        """All-NONE result aligned to ``index``. Used for early returns
        when input is invalid (missing columns, too short, etc).
        """
        return cls(
            phase=pd.Series(RidePhase.NONE.value, index=index, dtype=object),
            score=pd.Series(np.nan, index=index, dtype=float),
            fire=pd.Series(False, index=index, dtype=bool),
        )
