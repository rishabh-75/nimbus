"""nimbus_v3.core.universe — cross-layer universe dataclasses.

These are the shapes every layer reads when it needs to ask:

- "Is this symbol tradeable?"
- "What sector is it in?"
- "Is it F&O-eligible?"
- "Is it an ETF, and if so what does it track?"
- "Which NSE indices contain it?"

The **builder** that produces a ``Universe`` lives in ``data/universe.py``
and hits NSE endpoints. These dataclasses are frozen and have no behaviour —
just structure. They can be pickled, hashed, and passed across threads.

Per ``docs/ARCHITECTURE.md §18.1``: one coordinated NSE fetch produces both
the tradable universe and the symbol→sector mapping. No hard-coded sector
dictionary anywhere in ``nimbus_v3``.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

import pandas as pd


@dataclass(frozen=True)
class ETFMeta:
    """Metadata specific to an ETF. Attached to ``SymbolMeta.etf_meta``
    when ``SymbolMeta.is_etf`` is True.

    Fields are optional because NSE's ETF endpoint doesn't always surface
    all of them — AUM in particular is often absent for newer listings.
    """
    underlying_asset: str | None = None
    tracking_index: str | None = None
    aum_crore: float | None = None
    expense_ratio: float | None = None


@dataclass(frozen=True)
class SymbolMeta:
    """Per-symbol metadata derived from NSE.

    Industry classification uses NSE's four-level hierarchy (populated
    from ``data/nifty500_industry_db.json`` built by
    ``scripts/build_industry_db.py``):

        macro_sector   → "Commodities"          (coarsest, ~12 groups)
        sector         → "Metals & Mining"       (~20 groups)
        industry       → "Non - Ferrous Metals"  (~40 groups, used for RS)
        basic_industry → "Zinc"                  (finest, ~120 groups)

    When the DB isn't available, all four default to ``"Unknown"``.
    """
    symbol: str
    macro_sector: str = "Unknown"
    sector: str = "Unknown"
    industry: str = "Unknown"
    basic_industry: str = "Unknown"
    indices: frozenset[str] = field(default_factory=frozenset)
    is_fno: bool = False
    is_etf: bool = False
    etf_meta: ETFMeta | None = None

    def __post_init__(self) -> None:
        if self.is_etf and self.is_fno:
            raise ValueError(
                f"SymbolMeta {self.symbol!r}: is_etf and is_fno are mutually exclusive"
            )
        if self.is_etf and self.etf_meta is None:
            # Permit missing metadata — NSE often doesn't surface it — but
            # the flag must not be set without at least a stub.
            object.__setattr__(self, "etf_meta", ETFMeta())


@dataclass(frozen=True)
class Universe:
    """The complete NIMBUS v3 tradable universe at a point in time.

    Built once per trading session (or on explicit manual refresh) and
    injected into the scan orchestrator, the research harness, and the UI.
    Slicing methods return lists of symbol strings — callers look up
    full ``SymbolMeta`` via ``symbols[symbol]`` when they need more.
    """
    symbols: Mapping[str, SymbolMeta]
    built_at: pd.Timestamp

    def __post_init__(self) -> None:
        if not isinstance(self.built_at, pd.Timestamp):
            object.__setattr__(self, "built_at", pd.Timestamp(self.built_at))

    # ══════════════════════════════════════════════════════════════════════
    # Slicing helpers
    # ══════════════════════════════════════════════════════════════════════

    def slice(self, index_name: str) -> list[str]:
        """Return symbols that are members of ``index_name`` (e.g.
        ``"NIFTY 50"``, ``"NIFTY BANK"``). Sorted for determinism.
        """
        return sorted(
            sym for sym, meta in self.symbols.items()
            if index_name in meta.indices
        )

    def etfs(self) -> list[str]:
        """Return all ETF symbols, sorted."""
        return sorted(sym for sym, meta in self.symbols.items() if meta.is_etf)

    def equities(self) -> list[str]:
        """Return all non-ETF symbols, sorted."""
        return sorted(sym for sym, meta in self.symbols.items() if not meta.is_etf)

    def fno_symbols(self) -> list[str]:
        """Return all F&O-eligible symbols, sorted."""
        return sorted(sym for sym, meta in self.symbols.items() if meta.is_fno)

    def by_sector(self, sector: str) -> list[str]:
        """Return symbols whose sector matches ``sector`` (case-sensitive),
        sorted.
        """
        return sorted(
            sym for sym, meta in self.symbols.items()
            if meta.sector == sector
        )

    def sectors(self) -> list[str]:
        """Return every distinct sector name in the universe, sorted."""
        return sorted({meta.sector for meta in self.symbols.values()})

    def indices(self) -> list[str]:
        """Return every distinct index name referenced by any symbol, sorted."""
        all_idx: set[str] = set()
        for meta in self.symbols.values():
            all_idx.update(meta.indices)
        return sorted(all_idx)

    def __len__(self) -> int:
        return len(self.symbols)

    def __contains__(self, symbol: object) -> bool:
        return isinstance(symbol, str) and symbol in self.symbols
