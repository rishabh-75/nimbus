"""Tests for nimbus_v3.compute.constituent_features."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.constituent_features import (
    ConstituentFeatures,
    extract_constituent_features,
    MIN_BARS,
)

_UPLOADS = "/mnt/user-data/uploads"


def _frame(n: int = 30) -> pd.DataFrame:
    idx = pd.date_range("2025-01-01", periods=n, freq="D")
    close = np.linspace(100, 130, n)
    return pd.DataFrame(
        {
            "Open": close - 0.5,
            "High": close + 1,
            "Low": close - 1,
            "Close": close,
            "Volume": np.full(n, 1000.0),
            "bb_20_1s_pct": np.full(n, 1.1),
            "bbw_20_1s": np.full(n, 5.0),
            "bb_20_1s_upper": close - 5,    # body above
        },
        index=idx,
    )


def test_returns_none_for_short_frame():
    assert extract_constituent_features("X", _frame(MIN_BARS - 1)) is None
    assert extract_constituent_features("X", None) is None


def test_extracts_all_fields():
    f = extract_constituent_features("X", _frame(30))
    assert isinstance(f, ConstituentFeatures)
    assert f.symbol == "X"
    assert f.adtv == f.adtv          # not NaN
    assert f.chg_1d == f.chg_1d
    assert f.chg_5d == f.chg_5d
    assert f.chg_10d == f.chg_10d
    assert f.pct_b == pytest.approx(1.1)
    assert f.bbw == pytest.approx(5.0)
    assert f.above is True
    assert f.streak >= 1


def test_pct_change_signs():
    f = extract_constituent_features("X", _frame(30))
    # Monotone-rising series → positive changes.
    assert f.chg_1d > 0
    assert f.chg_5d > 0


def test_vol_ratio_unity_for_flat_volume():
    f = extract_constituent_features("X", _frame(30))
    assert f.vol_ratio == pytest.approx(1.0, abs=1e-9)


def test_missing_columns_yield_nan():
    df = _frame(30).drop(columns=["bb_20_1s_pct", "bbw_20_1s"])
    f = extract_constituent_features("X", df)
    assert np.isnan(f.pct_b)
    assert np.isnan(f.bbw)


def test_matches_reference_parquet():
    from nimbus_v3.compute.engine import StrategyComputeEngine
    eng = StrategyComputeEngine()
    df = eng.enrich(pd.read_parquet(f"{_UPLOADS}/CIPLA.parquet"), "CIPLA")
    f = extract_constituent_features("CIPLA", df)
    assert f is not None
    assert f.streak == 8           # matches the band_ride anchor
    assert f.above is True
