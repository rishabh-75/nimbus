"""Tests for the 4h body-above flag map and its band computation."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.band_ride import body_above_on_frame
from nimbus_v3.data.intraday_flags import build_above_4h_map


def _frame_above(n=30):
    """4h frame whose last bar's body is clearly above a 20-bar upper band."""
    c = np.full(n, 100.0)
    c[-1] = 130.0                      # last bar jumps well above the band
    return pd.DataFrame(
        {"Open": np.r_[np.full(n - 1, 100.0), 128.0],
         "High": c + 1, "Low": c - 1, "Close": c,
         "Volume": np.full(n, 1000.0)},
        index=pd.date_range("2026-06-01", periods=n, freq="4h"))


def _frame_below(n=30):
    c = np.full(n, 100.0)
    return pd.DataFrame(
        {"Open": c, "High": c + 1, "Low": c - 1, "Close": c,
         "Volume": np.full(n, 1000.0)},
        index=pd.date_range("2026-06-01", periods=n, freq="4h"))


def test_body_above_true_when_body_clears_band():
    assert body_above_on_frame(_frame_above()) is True


def test_body_above_false_when_flat():
    assert body_above_on_frame(_frame_below()) is False


def test_body_above_false_when_too_short_for_band():
    # fewer than 20 bars -> band is NaN -> not above (fail-soft, not crash)
    assert body_above_on_frame(_frame_above(n=10)) is False


def test_body_above_false_on_empty():
    assert body_above_on_frame(pd.DataFrame()) is False


class _FakeLoader:
    def __init__(self, frames):
        self._frames = frames

    def load(self, symbol, *, force_refresh=False, cache_only=False):
        f = self._frames.get(symbol)
        if isinstance(f, Exception):
            raise f
        return f if f is not None else pd.DataFrame()


def test_map_tri_state():
    loader = _FakeLoader({
        "UP": _frame_above(),
        "FLAT": _frame_below(),
        "MISSING": pd.DataFrame(),          # empty -> None
        "BROKEN": RuntimeError("boom"),     # raises -> None, not crash
    })
    m = build_above_4h_map(["UP", "FLAT", "MISSING", "BROKEN"], loader)
    assert m["UP"] is True
    assert m["FLAT"] is False
    assert m["MISSING"] is None
    assert m["BROKEN"] is None


def test_map_never_raises_on_loader_failure():
    class _Boom:
        def load(self, *a, **k):
            raise RuntimeError("network down")
    m = build_above_4h_map(["A", "B"], _Boom())
    assert m == {"A": None, "B": None}


def test_band_is_computed_on_the_4h_series_not_daily():
    """The Bollinger band must come from the 4h frame itself.

    Guards against ever borrowing the daily band: the mid line must equal
    the 4h Close SMA(period), and a frame whose 4h band says 'above' must
    read True even though the same prices as a DAILY series would give a
    different band.
    """
    from nimbus_v3.compute.indicators import add_bollinger
    n = 30
    close = np.full(n, 100.0)
    close[-1] = 104.0
    df = pd.DataFrame(
        {"Open": np.r_[np.full(n - 1, 100.0), 103.5],
         "High": close + 1, "Low": close - 1, "Close": close,
         "Volume": np.full(n, 1000.0)},
        index=pd.date_range("2026-06-01", periods=n, freq="4h"))
    enr = add_bollinger(df, period=20, std_dev=1.0, prefix="bb_20_1s")
    # mid line is the 4h series' own rolling mean, not anything daily.
    expected_mid = df["Close"].rolling(20).mean().iloc[-1]
    assert abs(enr["bb_20_1s_mid"].iloc[-1] - expected_mid) < 1e-9
    assert body_above_on_frame(df) is True


def test_map_cache_only_flag_passes_through():
    """cache_only must reach the loader so the GUI build never fetches."""
    seen = {}

    class _Rec:
        def load(self, symbol, *, force_refresh=False, cache_only=False):
            seen[symbol] = cache_only
            return pd.DataFrame()

    build_above_4h_map(["A", "B"], _Rec(), cache_only=True)
    assert seen == {"A": True, "B": True}
