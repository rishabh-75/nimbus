"""nimbus_v3.ui.presenters.builders — pure ViewModel builders.

No Qt dependency, no IO. Every public function is a pure mapping from
domain types (enriched dataframe, :class:`RideResult`, NSE
:class:`SymbolMeta`) to a frozen view dataclass that the rendering
widgets consume.

This module is the only place where domain-to-display interpretation
happens. Colours, threshold buckets, and label strings are decided
here so the widgets can stay purely structural.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Final

import pandas as pd

from nimbus_v3.compute.ride_initiation import RidePhase, RideResult
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.ui.theme import BLUE, EM, GOLD, GREEN, MUTED, RED, WHITE


# ══════════════════════════════════════════════════════════════════════════════
# View dataclasses — frozen, immutable, no behaviour
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class HeaderView:
    """Top-of-dashboard symbol header. Six fields, all pre-formatted."""

    symbol: str = "—"
    spot_text: str = "—"        # e.g. "₹ 2,450.30"
    change_text: str = "—"      # e.g. "+1.8%"
    change_color: str = MUTED   # GREEN if positive, RED if negative
    asof_text: str = ""         # e.g. "close 30 Apr 2026"
    asof_color: str = MUTED


@dataclass(frozen=True)
class _RideRow:
    """Single row in the ride-stats panel. Pre-coloured."""

    label: str
    value: str
    value_color: str = WHITE


@dataclass(frozen=True)
class RideView:
    """Output of the ride classifier for the active symbol.

    Carries the four headline numbers (phase, score, age in bars,
    BBW pctl) plus a colour-coded verdict line and a footer note.
    Empty when the input dataframe is too short, the classifier
    returned an empty result, or no fire is active.
    """

    phase_text: str = "—"
    phase_color: str = MUTED
    score_text: str = "—"
    score_color: str = MUTED
    rows: tuple[_RideRow, ...] = field(default_factory=tuple)
    verdict_text: str = "—"
    verdict_color: str = MUTED
    footer_text: str = ""


@dataclass(frozen=True)
class IndustryClassificationView:
    """The NSE four-level hierarchy for the active symbol."""

    macro: str = "—"
    sector: str = "—"
    industry: str = "—"
    basic: str = "—"


# ══════════════════════════════════════════════════════════════════════════════
# Empty singletons — used as initial state and as fallback on bad input
# ══════════════════════════════════════════════════════════════════════════════

EMPTY_HEADER_VIEW: Final[HeaderView] = HeaderView()
EMPTY_RIDE_VIEW: Final[RideView] = RideView()
EMPTY_INDUSTRY_VIEW: Final[IndustryClassificationView] = IndustryClassificationView()


# ══════════════════════════════════════════════════════════════════════════════
# Phase → colour mapping (single source of truth)
# ══════════════════════════════════════════════════════════════════════════════

_PHASE_COLORS: Final[dict[str, str]] = {
    RidePhase.INITIATION.value:   WHITE,
    RidePhase.RETEST.value:       BLUE,
    RidePhase.CONTINUATION.value: MUTED,
    RidePhase.NONE.value:         MUTED,
}


def _phase_color(phase_value: str) -> str:
    return _PHASE_COLORS.get(phase_value, MUTED)


# ══════════════════════════════════════════════════════════════════════════════
# Header builder
# ══════════════════════════════════════════════════════════════════════════════


def build_header_view(
    symbol: str,
    enriched_df: pd.DataFrame | None,
    asof_label: str = "",
) -> HeaderView:
    """Render the dashboard header from the most-recent bar.

    Args:
        symbol: ticker text shown on the left.
        enriched_df: indicator-enriched OHLCV. The last row is used.
            Pass ``None`` (or empty) to get the empty view.
        asof_label: free-form date label (e.g. ``"close 30 Apr 2026"``).
    """
    if enriched_df is None or enriched_df.empty:
        return HeaderView(symbol=symbol or "—", asof_text=asof_label)

    try:
        last = enriched_df.iloc[-1]
        prev = enriched_df.iloc[-2] if len(enriched_df) >= 2 else last
        spot = float(last["Close"])
        prev_close = float(prev["Close"])
    except (KeyError, IndexError, TypeError, ValueError):
        return HeaderView(symbol=symbol or "—", asof_text=asof_label)

    if not (spot == spot):    # NaN check
        return HeaderView(symbol=symbol or "—", asof_text=asof_label)

    spot_text = f"₹ {spot:,.2f}"

    if prev_close and prev_close == prev_close and prev_close != 0:
        pct = (spot / prev_close - 1.0) * 100.0
        change_text = f"{pct:+.2f}%"
        change_color = GREEN if pct >= 0 else RED
    else:
        change_text = "—"
        change_color = MUTED

    return HeaderView(
        symbol=symbol or "—",
        spot_text=spot_text,
        change_text=change_text,
        change_color=change_color,
        asof_text=asof_label,
        asof_color=MUTED,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Ride builder
# ══════════════════════════════════════════════════════════════════════════════


def _bars_since_last_fire(result: RideResult) -> int | None:
    """Distance in bars between the last fire and the latest bar.

    Returns ``None`` when no fire is in the result. Returns ``0`` when
    the latest bar is itself a fire.
    """
    fire = result.fire
    if fire.empty or not bool(fire.any()):
        return None
    fired_indices = fire.values.nonzero()[0]
    last_fire_idx = int(fired_indices[-1])
    return (len(fire) - 1) - last_fire_idx


def _ride_verdict(phase: RidePhase, score: float) -> tuple[str, str]:
    """Map a (phase, score) pair to a verdict label + colour.

    The thresholds are intentionally simple — there's no validated
    forward edge that would justify more granular bucketing here. The
    purpose is to give the operator a fast visual cue, not a sizing
    decision.
    """
    if phase is RidePhase.NONE or not (score == score):    # NaN
        return ("NO RIDE", MUTED)
    if phase is RidePhase.INITIATION:
        return (f"INIT · score {score:.0f}", EM)
    if phase is RidePhase.RETEST:
        return (f"RETEST · score {score:.0f}", BLUE)
    # CONTINUATION
    return (f"CONT · score {score:.0f}", MUTED)


def build_ride_view(
    enriched_df: pd.DataFrame | None,
    result: RideResult | None,
) -> RideView:
    """Translate a single-symbol :class:`RideResult` into rows + verdict.

    Args:
        enriched_df: the dataframe the result was computed on. Used
            for the secondary rows (BBW pctl, %B, SMA20 distance).
            Pass ``None`` to render an empty view.
        result: the classifier output for the same dataframe. Pass
            ``None`` or an empty result to render an empty view.
    """
    if result is None or result.phase.empty or enriched_df is None or enriched_df.empty:
        return EMPTY_RIDE_VIEW

    phase = result.latest_phase
    score = result.latest_score

    rows: list[_RideRow] = []

    age = _bars_since_last_fire(result)
    if age is None:
        rows.append(_RideRow("Bars since fire", "—", MUTED))
    else:
        rows.append(_RideRow("Bars since fire", str(age), WHITE))

    last = enriched_df.iloc[-1]

    pct_b = _safe_float(last.get("bb_20_1s_pct"))
    if pct_b == pct_b:
        in_zone = 1.0 <= pct_b <= 1.5
        rows.append(
            _RideRow(
                "%B",
                f"{pct_b:.2f}",
                GREEN if in_zone else WHITE,
            )
        )
    else:
        rows.append(_RideRow("%B", "—", MUTED))

    bbw_pctl = _safe_float(last.get("bbw_20_1s_pctl"))
    if bbw_pctl == bbw_pctl:
        rows.append(_RideRow("BBW pctl", f"{bbw_pctl:.0f}", WHITE))
    else:
        rows.append(_RideRow("BBW pctl", "—", MUTED))

    sma_20 = _safe_float(last.get("sma_20"))
    close = _safe_float(last.get("Close"))
    if sma_20 == sma_20 and close == close and sma_20:
        delta_pct = (close / sma_20 - 1.0) * 100.0
        rows.append(
            _RideRow(
                "vs SMA20",
                f"{delta_pct:+.2f}%",
                GREEN if delta_pct >= 0 else RED,
            )
        )
    else:
        rows.append(_RideRow("vs SMA20", "—", MUTED))

    verdict_text, verdict_color = _ride_verdict(phase, score)

    if phase is RidePhase.NONE:
        footer = "No fire on the latest bar."
    elif age == 0:
        footer = "Fire on the latest bar."
    elif age is not None:
        footer = f"Last fire {age} bar(s) ago — phase active."
    else:
        footer = ""

    return RideView(
        phase_text=phase.value,
        phase_color=_phase_color(phase.value),
        score_text=("—" if not (score == score) else f"{score:.0f}"),
        score_color=verdict_color,
        rows=tuple(rows),
        verdict_text=verdict_text,
        verdict_color=verdict_color,
        footer_text=footer,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Industry classification builder
# ══════════════════════════════════════════════════════════════════════════════


def build_industry_view(
    meta: SymbolMeta | None,
) -> IndustryClassificationView:
    """Pull the four-level NSE classification off a :class:`SymbolMeta`."""
    if meta is None:
        return EMPTY_INDUSTRY_VIEW
    return IndustryClassificationView(
        macro=meta.macro_sector or "—",
        sector=meta.sector or "—",
        industry=meta.industry or "—",
        basic=meta.basic_industry or "—",
    )


# ══════════════════════════════════════════════════════════════════════════════
# Coercion helpers
# ══════════════════════════════════════════════════════════════════════════════


def _safe_float(value) -> float:
    """Coerce to native float, returning NaN on any failure."""
    if value is None:
        return float("nan")
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")
