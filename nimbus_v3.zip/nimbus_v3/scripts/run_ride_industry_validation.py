"""scripts/run_ride_industry_validation.py — Ride edge by industry.

Hypothesis: Ride's aggregate OOS edge decayed (train +0.22pp, test
−0.12pp), but the edge might be industry-specific — concentrated in
industries where upper-band breakouts have structural follow-through
(e.g. metals during commodity cycles, capital goods during capex
booms) and absent in industries where mean-reversion dominates.

Method:
1. Load equity panel + industry DB.
2. Enrich all symbols with compute engine.
3. Scan every bar for Ride gate fires (BB %B in 1–2σ zone,
   green_streak ≥ 3, ADX > 25).
4. Compute 5-day forward returns on each fire.
5. Group fires by industryInfo (NSE's ~40-group level).
6. For each industry: count fires, mean return, lift vs baseline,
   win rate. Split train/test at 2025-01-01.

Output: console table sorted by test-period lift, flagging industries
where Ride still has edge.

Usage:
    python scripts/run_ride_industry_validation.py
    python scripts/run_ride_industry_validation.py --fwd-days 10
    python scripts/run_ride_industry_validation.py --split-date 2025-06-01
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_PROJECT_ROOT = _HERE.parent
sys.path.insert(0, str(_PROJECT_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.data.industry_db import load_industry_db
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns


# ══════════════════════════════════════════════════════════════════════════════
# Ride gates (replicated from strategies/ride.py for vectorised scanning)
# ══════════════════════════════════════════════════════════════════════════════

def ride_fires(df: pd.DataFrame) -> pd.Series:
    """Return a boolean Series where Ride gates pass on each bar.

    Gates (from strategies/ride.py):
      - close sits between bb_20_1s_upper and bb_20_2s_upper
      - green_streak >= 3
      - adx_14 > 25
    """
    required = [
        "Close", "bb_20_1s_upper", "bb_20_2s_upper",
        "green_streak", "adx_14", "data_sufficient",
    ]
    if not all(c in df.columns for c in required):
        return pd.Series(False, index=df.index)

    return (
        df["data_sufficient"].fillna(False)
        & (df["Close"] >= df["bb_20_1s_upper"])
        & (df["Close"] <= df["bb_20_2s_upper"])
        & (df["green_streak"] >= 3)
        & (df["adx_14"] > 25)
    )


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Ride strategy edge validation segmented by NSE industryInfo",
    )
    parser.add_argument(
        "--fwd-days", type=int, default=5,
        help="Forward return horizon in trading days (default 5).",
    )
    parser.add_argument(
        "--split-date", type=str, default="2025-01-01",
        help="Train/test split date (default 2025-01-01).",
    )
    parser.add_argument(
        "--min-fires", type=int, default=5,
        help="Minimum fires per industry in test period to show (default 5).",
    )
    args = parser.parse_args()

    fwd_days = args.fwd_days
    split = pd.Timestamp(args.split_date)
    min_fires = args.min_fires

    # 1. Load industry DB.
    industry_db = load_industry_db()
    if not industry_db:
        print("ERROR: Industry DB not found. Run scripts/build_industry_db.py first.")
        return 1

    # 2. Load equity panel for all DB symbols.
    db_symbols = tuple(sorted(industry_db.keys()))
    print(f"Loading equity panel for {len(db_symbols)} symbols…")
    panel = load_equity_panel(symbols=db_symbols)
    if not panel:
        print("No equity panel loaded.")
        return 1
    print(f"  → {len(panel)} symbols")

    # 3. Enrich.
    print("Enriching…")
    compute = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            enriched[sym] = compute.enrich(df, sym)
        except Exception:    # noqa: BLE001
            continue
    print(f"  → {len(enriched)} enriched")

    # 4. Scan + forward returns per symbol.
    print(f"Scanning for Ride fires + {fwd_days}d forward returns…")
    records: list[dict] = []
    for sym, df in enriched.items():
        ic = industry_db.get(sym.upper())
        if ic is None:
            continue    # skip symbols not in the DB

        # Add forward returns.
        df = add_forward_returns(df, horizons=(fwd_days,))
        fwd_col = f"fwd_ret_{fwd_days}d"
        if fwd_col not in df.columns:
            continue

        fires = ride_fires(df)
        if fires.sum() == 0:
            continue

        for idx in df.index[fires]:
            fwd = df.loc[idx, fwd_col]
            if pd.isna(fwd):
                continue
            records.append({
                "symbol": sym,
                "date": idx,
                "fwd_return": float(fwd),
                "macro": ic.macro_sector,
                "sector": ic.sector,
                "industry": ic.industry,
                "basic_industry": ic.basic_industry,
            })

    if not records:
        print("No Ride fires found in the panel.")
        return 1

    all_fires = pd.DataFrame(records)
    print(f"  → {len(all_fires)} total fires across {all_fires['symbol'].nunique()} symbols")

    # 5. Split train/test.
    train = all_fires[all_fires["date"] < split]
    test = all_fires[all_fires["date"] >= split]
    print(f"  → Train: {len(train)} fires (before {split.date()})")
    print(f"  → Test:  {len(test)} fires (from {split.date()})")

    # Baseline: unconditional mean of all forward returns in the panel
    # (not just Ride fires — need "what would random entry give you?").
    baseline_parts = []
    for sym, df in enriched.items():
        df = add_forward_returns(df, horizons=(fwd_days,))
        fwd_col = f"fwd_ret_{fwd_days}d"
        if fwd_col in df.columns:
            baseline_parts.append(df[fwd_col].dropna())
    if baseline_parts:
        baseline = float(pd.concat(baseline_parts).mean())
    else:
        baseline = 0.0
    print(f"  → Baseline {fwd_days}d return: {baseline:+.4f}%")

    # 6. Per-industry stats.
    print(f"\n{'═' * 110}")
    print(f"  RIDE STRATEGY — {fwd_days}d FORWARD RETURN BY INDUSTRY")
    print(f"  Split: train < {split.date()} | test ≥ {split.date()}")
    print(f"  Baseline unconditional {fwd_days}d return: {baseline:+.4f}%")
    print(f"{'═' * 110}")

    rows = []
    for industry, grp in all_fires.groupby("industry"):
        tr = grp[grp["date"] < split]
        te = grp[grp["date"] >= split]
        if len(te) < min_fires:
            continue

        tr_mean = float(tr["fwd_return"].mean()) if len(tr) else 0.0
        te_mean = float(te["fwd_return"].mean()) if len(te) else 0.0
        tr_wr = float((tr["fwd_return"] > 0).mean() * 100) if len(tr) else 0.0
        te_wr = float((te["fwd_return"] > 0).mean() * 100) if len(te) else 0.0
        tr_lift = tr_mean - baseline
        te_lift = te_mean - baseline

        rows.append({
            "Industry": industry,
            "Train_N": len(tr),
            "Train_Mean": round(tr_mean, 3),
            "Train_WR%": round(tr_wr, 1),
            "Train_Lift": round(tr_lift, 3),
            "Test_N": len(te),
            "Test_Mean": round(te_mean, 3),
            "Test_WR%": round(te_wr, 1),
            "Test_Lift": round(te_lift, 3),
            "Decay": round(te_lift - tr_lift, 3),
        })

    result = pd.DataFrame(rows).sort_values("Test_Lift", ascending=False)
    print(result.to_string(index=False))

    # Summary.
    positive_edge = result[result["Test_Lift"] > 0]
    negative_edge = result[result["Test_Lift"] < 0]

    print(f"\n{'─' * 60}")
    print(f"  Industries with positive test lift: {len(positive_edge)} / {len(result)}")
    print(f"  Industries with negative test lift: {len(negative_edge)} / {len(result)}")

    if not positive_edge.empty:
        print(f"\n  INDUSTRIES WHERE RIDE STILL HAS EDGE:")
        for _, r in positive_edge.head(10).iterrows():
            print(
                f"    {r['Industry']:<35s}  "
                f"test_lift {r['Test_Lift']:+.3f}%  "
                f"WR {r['Test_WR%']:.0f}%  "
                f"n={r['Test_N']}"
            )

    if not negative_edge.empty:
        print(f"\n  INDUSTRIES WHERE RIDE EDGE HAS DECAYED:")
        for _, r in negative_edge.tail(5).iterrows():
            print(
                f"    {r['Industry']:<35s}  "
                f"test_lift {r['Test_Lift']:+.3f}%  "
                f"WR {r['Test_WR%']:.0f}%  "
                f"decay {r['Decay']:+.3f}%"
            )

    # Aggregate: is the positive-edge bucket real or noise?
    if not positive_edge.empty:
        pos_fires = all_fires[
            (all_fires["date"] >= split)
            & all_fires["industry"].isin(positive_edge["Industry"])
        ]
        if len(pos_fires) >= 20:
            agg_mean = float(pos_fires["fwd_return"].mean())
            agg_wr = float((pos_fires["fwd_return"] > 0).mean() * 100)
            agg_lift = agg_mean - baseline
            print(f"\n  AGGREGATE (positive-edge industries only):")
            print(f"    fires: {len(pos_fires)}  mean: {agg_mean:+.3f}%  "
                  f"WR: {agg_wr:.0f}%  lift: {agg_lift:+.3f}%")

    # Export.
    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("data/research")
    out_dir.mkdir(parents=True, exist_ok=True)

    summary_path = out_dir / f"ride_by_industry_{fwd_days}d_{ts}.csv"
    result.to_csv(summary_path, index=False)
    print(f"\n  Exported summary  → {summary_path}")

    fires_path = out_dir / f"ride_fires_{fwd_days}d_{ts}.csv"
    all_fires.to_csv(fires_path, index=False)
    print(f"  Exported fires    → {fires_path}")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
