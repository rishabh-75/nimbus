#!/usr/bin/env python3
"""
tests/test_score_pipeline.py — End-to-end score pipeline integration tests.

Verifies:
  1. Score formula: base + options(±10) + filing(±10), NO deal component
  2. Label/sizing thresholds for PRIMARY and SECONDARY
  3. Filing TRAP overrides score to ≤30 and forces AVOID/SKIP
  4. Options + filing compound correctly
  5. Score clamping 0-100
  6. MAX_HOLD = 30
  7. No deal_overlay, deal_detail, deal_result anywhere in signal
  8. WF-validated parameters match code constants
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from types import SimpleNamespace
from modules.dual_mode import (
    compute_dual_mode, DualModeSignal, check_exit,
    _score, _options_overlay, _filing_overlay, _label_and_sizing,
    WR_PERIOD, WR_THRESH, SMA_PERIOD, MFI_MIN,
    DD_MODERATE, RED_STREAK_MIN, VOL_MIN_RATIO, PROFIT_TARGET, MAX_HOLD,
    ENABLE_SECONDARY_TIER,
)
import numpy as np
import pandas as pd

PASS = 0
FAIL = 0

def _run(name, fn):
    global PASS, FAIL
    try:
        fn()
        print(f"  ✓ {name}")
        PASS += 1
    except AssertionError as e:
        print(f"  ✗ {name}: {e}")
        FAIL += 1


def _make_price_df(n=60, close=100.0, trend="down"):
    """Generate a simple price DataFrame for testing compute_dual_mode."""
    dates = pd.bdate_range("2024-01-01", periods=n)
    if trend == "down":
        closes = np.linspace(close * 1.1, close, n)
    elif trend == "up":
        closes = np.linspace(close * 0.9, close, n)
    else:
        closes = np.full(n, close)
    highs = closes * 1.01
    lows = closes * 0.99
    opens = np.roll(closes, 1); opens[0] = closes[0]
    vols = np.full(n, 1e6)
    return pd.DataFrame({
        "Open": opens, "High": highs, "Low": lows,
        "Close": closes, "Volume": vols,
    }, index=dates)


def _mock_ctx(pcr=1.0, gex="Neutral", support_pct=None):
    return SimpleNamespace(
        walls=SimpleNamespace(pcr_oi=pcr, support_pct=support_pct),
        gex=SimpleNamespace(regime=gex, net_gex=0),
    )


def _mock_filing(badge_color="NEUTRAL", conviction=5, variance=0):
    return SimpleNamespace(
        badge_color=badge_color, conviction=conviction, variance=variance,
        badge_text="TEST", detail_line="test filing",
    )


# ══════════════════════════════════════════════════════════════════════════════
# TEST 1: No deal_overlay in signal or formula
# ══════════════════════════════════════════════════════════════════════════════

def test_no_deal_in_pipeline():
    print("\n── NO DEAL IN PIPELINE ──")

    def t_no_deal_attr():
        sig = DualModeSignal()
        assert not hasattr(sig, "deal_overlay"), "deal_overlay should not exist on DualModeSignal"
        assert not hasattr(sig, "deal_detail"), "deal_detail should not exist on DualModeSignal"
    _run("no_deal_overlay_attribute", t_no_deal_attr)

    def t_no_deal_param():
        import inspect
        params = inspect.signature(compute_dual_mode).parameters
        assert "deal_result" not in params, f"deal_result param still in compute_dual_mode: {list(params)}"
    _run("no_deal_result_param", t_no_deal_param)

    def t_compute_no_deal():
        df = _make_price_df(60, 100)
        sig = compute_dual_mode(df, symbol="TEST")
        # Score should only be base + options(0) + filing(0)
        assert sig.options_overlay == 0
        assert sig.filing_overlay == 0
        assert sig.dual_score == sig.base_score  # no overlays
    _run("compute_score_no_overlays", t_compute_no_deal)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 2: Score formula correctness
# ══════════════════════════════════════════════════════════════════════════════

def test_score_formula():
    print("\n── SCORE FORMULA ──")

    def t_base_only():
        sig = DualModeSignal(wr_30=-80, pct_from_sma=-6.0, above_sma=False,
                             mfi=55, mfi_slope=5, dd_from_high=-12,
                             red_streak=4, vol_ratio=2.0, bbw_pctl=20)
        s = _score(sig)
        # 30 + 25(WR) + 15(SMA) + 8(MFI) + 4(slope) + 8(DD) + 6(streak) + 4(vol) + 3(BBW) = 103 → clamped to 100
        assert s == 100, f"Max score should be 100, got {s}"
    _run("max_base_score_clamped_100", t_base_only)

    def t_min():
        sig = DualModeSignal(wr_30=-10, pct_from_sma=5, above_sma=True,
                             mfi=20, mfi_slope=-1, dd_from_high=-1,
                             red_streak=0, vol_ratio=0.3, bbw_pctl=80)
        s = _score(sig)
        # 30 + 0(WR) - 10(above_sma) - 5(MFI<30) + 0 + 0 + 0 - 3(vol) - 2(BBW) = 10
        assert s == 10, f"Expected 10, got {s}"
    _run("low_base_score", t_min)

    def t_formula_with_options():
        sig = DualModeSignal(wr_30=-60, pct_from_sma=-4.0, above_sma=False,
                             mfi=50, dd_from_high=-6, red_streak=2, vol_ratio=1.0, bbw_pctl=50)
        base = _score(sig)
        # PCR 0.5 is moderate bearish — zero score impact in new logic
        ov, _ = _options_overlay(_mock_ctx(pcr=0.5, gex="Negative"), sig)
        assert ov == 0, f"Moderate PCR should be 0, got {ov}"
        # Extreme complacency: PCR < 0.3 → -3
        ov2, _ = _options_overlay(_mock_ctx(pcr=0.2, gex="Negative"), sig)
        assert ov2 == -3, f"Extreme complacency should be -3, got {ov2}"
    _run("moderate_pcr_no_impact_extreme_does", t_formula_with_options)

    def t_formula_with_filing():
        sig = DualModeSignal(wr_30=-50, pct_from_sma=-2.0, above_sma=False,
                             mfi=40, dd_from_high=-3, red_streak=2, vol_ratio=1.0, bbw_pctl=50)
        base = _score(sig)
        fov, _, trap = _filing_overlay(_mock_filing("BULLISH", conviction=9), base)
        assert fov == 7, f"Expected filing +7 for high conviction bullish, got {fov}"
        assert trap is False
        final = max(0, min(100, base + 0 + fov))
        assert final == base + 7
    _run("base_plus_bullish_filing", t_formula_with_filing)

    def t_combined():
        sig = DualModeSignal(wr_30=-50, pct_from_sma=-2.0, above_sma=False,
                             mfi=40, dd_from_high=-3, red_streak=2, vol_ratio=1.0, bbw_pctl=50)
        base = _score(sig)
        # PCR 1.8 > 1.5 → capitulation bullish +3 (no GEX compound in new logic)
        oov, _ = _options_overlay(_mock_ctx(pcr=1.8, gex="Negative"), sig)
        assert oov == 3, f"Expected options +3 for capitulation, got {oov}"
        fov, _, _ = _filing_overlay(_mock_filing("BULLISH", conviction=8), base)
        assert fov == 7
        final = max(0, min(100, base + oov + fov))
        assert final == base + 10, f"Combined should be base+10, got {final} (base={base})"
    _run("capitulation_pcr_plus_bullish_filing", t_combined)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 3: Filing TRAP
# ══════════════════════════════════════════════════════════════════════════════

def test_trap():
    print("\n── FILING TRAP ──")

    def t_trap_triggers():
        # TRAP: bearish filing + high base score
        ov, detail, trap = _filing_overlay(_mock_filing("BEARISH", conviction=8), 70)
        assert trap is True, "Should be TRAP when bearish + base>=55"
        assert ov == -10, f"TRAP overlay should be -10, got {ov}"
    _run("trap_triggers_on_bearish_high_base", t_trap_triggers)

    def t_trap_no_trigger_low_base():
        ov, _, trap = _filing_overlay(_mock_filing("BEARISH", conviction=8), 40)
        assert trap is False, "Should NOT trap when base < 55"
        assert ov == -5, f"Bearish non-trap should be -5, got {ov}"
    _run("no_trap_on_low_base", t_trap_no_trigger_low_base)

    def t_trap_caps_score():
        sig = DualModeSignal(tier="PRIMARY", is_trap=True)
        label, sizing = _label_and_sizing(80, sig)
        assert label == "AVOID" and sizing == "SKIP", f"TRAP should → AVOID/SKIP, got {label}/{sizing}"
    _run("trap_forces_avoid_skip", t_trap_caps_score)

    def t_trap_score_cap():
        # Even with base=90, TRAP should cap at 30
        sig = DualModeSignal(is_trap=True)
        final = max(0, min(100, 90 + 0 + (-10)))  # base=90, filing=-10
        if sig.is_trap:
            final = min(final, 30)
        assert final == 30, f"TRAP cap should be 30, got {final}"
    _run("trap_caps_at_30", t_trap_score_cap)

    def t_bullish_filing_no_trap():
        ov, _, trap = _filing_overlay(_mock_filing("BULLISH", conviction=9), 90)
        assert trap is False
        assert ov == 7
    _run("bullish_filing_never_traps", t_bullish_filing_no_trap)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 4: Label/sizing thresholds
# ══════════════════════════════════════════════════════════════════════════════

def test_labels():
    print("\n── LABEL/SIZING THRESHOLDS ──")

    def t_primary():
        sig = DualModeSignal(tier="PRIMARY", is_trap=False)
        assert _label_and_sizing(75, sig) == ("STRONG", "FULL")
        assert _label_and_sizing(60, sig) == ("GOOD", "FULL")
        assert _label_and_sizing(45, sig) == ("WATCH", "HALF")
        assert _label_and_sizing(30, sig) == ("AVOID", "SKIP")
    _run("primary_thresholds", t_primary)

    def t_secondary():
        sig = DualModeSignal(tier="SECONDARY", is_trap=False)
        assert _label_and_sizing(75, sig) == ("STRONG", "HALF")
        assert _label_and_sizing(60, sig) == ("GOOD", "HALF")
        assert _label_and_sizing(45, sig) == ("WATCH", "SKIP")
        assert _label_and_sizing(30, sig) == ("AVOID", "SKIP")
    _run("secondary_thresholds", t_secondary)

    def t_trap_overrides_all():
        for tier in ("PRIMARY", "SECONDARY", "NONE"):
            sig = DualModeSignal(tier=tier, is_trap=True)
            label, sizing = _label_and_sizing(95, sig)
            assert label == "AVOID" and sizing == "SKIP", f"TRAP override failed for tier={tier}"
    _run("trap_overrides_all_tiers", t_trap_overrides_all)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 5: Score clamping
# ══════════════════════════════════════════════════════════════════════════════

def test_clamping():
    print("\n── SCORE CLAMPING ──")

    def t_upper():
        # base=100 + options=10 + filing=7 = 117 → clamped to 100
        final = max(0, min(100, 100 + 10 + 7))
        assert final == 100
    _run("upper_clamp_100", t_upper)

    def t_lower():
        # base=10 + options=-10 + filing=-10 = -10 → clamped to 0
        final = max(0, min(100, 10 + (-10) + (-10)))
        assert final == 0
    _run("lower_clamp_0", t_lower)

    def t_options_bounded():
        sig = DualModeSignal()
        ov1, _ = _options_overlay(_mock_ctx(pcr=0.01, gex="Negative"), sig)
        ov2, _ = _options_overlay(_mock_ctx(pcr=5.0, gex="Negative"), sig)
        assert -10 <= ov1 <= 10, f"Options should be bounded ±10, got {ov1}"
        assert -10 <= ov2 <= 10, f"Options should be bounded ±10, got {ov2}"
    _run("options_bounded_pm10", t_options_bounded)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 6: WF-validated parameter constants
# ══════════════════════════════════════════════════════════════════════════════

def test_wf_params():
    print("\n── WF-VALIDATED PARAMETERS ──")

    def t_params():
        # Locked at original WF values
        assert WR_PERIOD == 30
        assert WR_THRESH == -30
        assert SMA_PERIOD == 20
        assert MFI_MIN == 30
        assert PROFIT_TARGET == 5.0
        assert MAX_HOLD == 30, f"MAX_HOLD should be 30 (WF 5/6), got {MAX_HOLD}"
        # Updated 2026-04-08 from robust sweep #1/648
        # See modules/dual_mode.py and modules/signal_tracker.py provenance.
        assert DD_MODERATE == -8.0, f"DD_MODERATE should be -8 (robust sweep #1), got {DD_MODERATE}"
        assert RED_STREAK_MIN == 4, f"RED_STREAK_MIN should be 4 (robust sweep #1), got {RED_STREAK_MIN}"
        assert VOL_MIN_RATIO == 1.5, f"VOL_MIN_RATIO should be 1.5 (robust sweep #1), got {VOL_MIN_RATIO}"
    _run("wf_params_match", t_params)

    def t_secondary_disabled():
        # Robust sweep #1/648 used primary_only=True. Production has
        # ENABLE_SECONDARY_TIER=False so SECONDARY signals are computed
        # (sig.secondary_met is set) but never trigger entries.
        assert ENABLE_SECONDARY_TIER == False, (
            "ENABLE_SECONDARY_TIER must be False — every top-25 robust sweep "
            "config used primary_only. Re-enabling SECONDARY drops aggregate "
            "Sharpe from 1.13 to 0.40 and turns 5/5 positive folds into 2/5."
        )
    _run("secondary_tier_disabled", t_secondary_disabled)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 7: Exit logic with MAX_HOLD=30
# ══════════════════════════════════════════════════════════════════════════════

def test_exit_logic():
    print("\n── EXIT LOGIC ──")

    def t_pt():
        sig = DualModeSignal(close=1050)
        assert check_exit(sig, 1000, 5) == "PROFIT_TARGET"
    _run("profit_target_5pct", t_pt)

    def t_no_pt():
        sig = DualModeSignal(close=1040)
        assert check_exit(sig, 1000, 5) == "", "4% gain should not trigger 5% PT"
    _run("no_premature_pt", t_no_pt)

    def t_bbw():
        sig = DualModeSignal(close=1010, bbw_contracting=True, above_sma=True)
        assert check_exit(sig, 1000, 10) == "BBW_CONTRACT"
    _run("bbw_contraction_exit", t_bbw)

    def t_bbw_too_early():
        sig = DualModeSignal(close=1010, bbw_contracting=True, above_sma=True)
        assert check_exit(sig, 1000, 3) == "", "BBW exit needs bars_held >= 5"
    _run("bbw_not_before_5_bars", t_bbw_too_early)

    def t_max_hold_30():
        sig = DualModeSignal(close=990)
        assert check_exit(sig, 1000, 30) == "MAX_HOLD"
    _run("max_hold_at_30", t_max_hold_30)

    def t_no_exit_29():
        sig = DualModeSignal(close=990)
        assert check_exit(sig, 1000, 29) == "", "Should not exit at day 29"
    _run("no_exit_at_29", t_no_exit_29)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 8: End-to-end compute_dual_mode integration
# ══════════════════════════════════════════════════════════════════════════════

def test_e2e():
    print("\n── END-TO-END compute_dual_mode ──")

    def t_basic():
        df = _make_price_df(60, 100, "down")
        sig = compute_dual_mode(df, symbol="TEST")
        assert sig.data_sufficient is True
        assert isinstance(sig.dual_score, int)
        assert 0 <= sig.dual_score <= 100
        assert sig.dual_label in ("STRONG", "GOOD", "WATCH", "AVOID")
        assert sig.dual_sizing in ("FULL", "HALF", "SKIP")
    _run("basic_compute", t_basic)

    def t_with_options():
        df = _make_price_df(60, 100, "down")
        sig_no = compute_dual_mode(df, symbol="TEST")
        sig_bull = compute_dual_mode(df, symbol="TEST",
                                     options_ctx=_mock_ctx(pcr=1.5, gex="Negative"))
        sig_bear = compute_dual_mode(df, symbol="TEST",
                                     options_ctx=_mock_ctx(pcr=0.5, gex="Negative"))
        # Bullish options should raise score
        assert sig_bull.dual_score >= sig_no.dual_score, \
            f"Bullish options should help: {sig_bull.dual_score} vs {sig_no.dual_score}"
        # Bearish options should lower score
        assert sig_bear.dual_score <= sig_no.dual_score, \
            f"Bearish options should hurt: {sig_bear.dual_score} vs {sig_no.dual_score}"
    _run("options_affect_score", t_with_options)

    def t_with_filing():
        df = _make_price_df(60, 100, "down")
        sig_no = compute_dual_mode(df, symbol="TEST")
        sig_bull = compute_dual_mode(df, symbol="TEST",
                                     filing_variance=_mock_filing("BULLISH", conviction=9))
        sig_bear = compute_dual_mode(df, symbol="TEST",
                                     filing_variance=_mock_filing("BEARISH", conviction=8))
        assert sig_bull.dual_score >= sig_no.dual_score
        assert sig_bear.dual_score <= sig_no.dual_score
    _run("filing_affects_score", t_with_filing)

    def t_trap_e2e():
        df = _make_price_df(60, 100, "down")
        sig = compute_dual_mode(df, symbol="TEST",
                                filing_variance=_mock_filing("BEARISH", conviction=8))
        if sig.base_score >= 55:
            assert sig.is_trap is True, f"Should TRAP with bearish filing + high base ({sig.base_score})"
            assert sig.dual_score <= 30, f"TRAP score should be ≤30, got {sig.dual_score}"
            assert sig.dual_label == "AVOID"
            assert sig.dual_sizing == "SKIP"
    _run("trap_e2e_bearish_filing", t_trap_e2e)

    def t_no_deal_in_output():
        df = _make_price_df(60, 100, "down")
        sig = compute_dual_mode(df, symbol="TEST",
                                options_ctx=_mock_ctx(pcr=1.5),
                                filing_variance=_mock_filing("BULLISH", 7))
        assert not hasattr(sig, "deal_overlay"), "deal_overlay leaked into signal"
        assert not hasattr(sig, "deal_detail"), "deal_detail leaked into signal"
    _run("no_deal_fields_in_output", t_no_deal_in_output)

    def t_short_data():
        df = _make_price_df(15, 100)
        sig = compute_dual_mode(df, symbol="TEST")
        assert sig.data_sufficient is False
    _run("insufficient_data_handled", t_short_data)


# ══════════════════════════════════════════════════════════════════════════════
# TEST 9: Verify UI files have no deal wiring
# ══════════════════════════════════════════════════════════════════════════════

def test_ui_clean():
    print("\n── UI FILES CLEAN ──")

    ui_files = [
        "ui/workers.py", "ui/data_manager.py", "ui/dashboard_tab.py",
        "ui/chart_widget.py", "ui/main_window.py",
    ]

    def t_no_deal_worker():
        with open("ui/workers.py") as f:
            src = f.read()
        assert "DealWorker" not in src, "DealWorker class still in workers.py"
        assert "deal_ready" not in src, "deal_ready signal still in workers.py"
    _run("workers_no_deal", t_no_deal_worker)

    def t_no_deal_dm():
        with open("ui/data_manager.py") as f:
            src = f.read()
        assert "DealWorker" not in src, "DealWorker import still in data_manager.py"
        assert "deal_ready" not in src, "deal_ready signal still in data_manager.py"
        assert "_deal_worker" not in src, "_deal_worker attribute still in data_manager.py"
        assert "_deal_result" not in src, "_deal_result attribute still in data_manager.py"
        assert "_start_deal_worker" not in src
        assert "_on_deal_ready" not in src
    _run("data_manager_no_deal", t_no_deal_dm)

    def t_no_deal_dashboard():
        with open("ui/dashboard_tab.py") as f:
            src = f.read()
        assert "on_deal_updated" not in src, "on_deal_updated still in dashboard_tab.py"
        assert "deal_result" not in src, "deal_result still in dashboard_tab.py"
    _run("dashboard_no_deal", t_no_deal_dashboard)

    def t_no_deal_chart():
        with open("ui/chart_widget.py") as f:
            src = f.read()
        assert "deal_levels" not in src, "deal_levels still in chart_widget.py"
        assert "_DEAL_COLORS" not in src
    _run("chart_no_deal", t_no_deal_chart)

    def t_no_deal_mainwindow():
        with open("ui/main_window.py") as f:
            src = f.read()
        assert "deal_ready" not in src, "deal_ready connection still in main_window.py"
        assert "on_deal_updated" not in src
    _run("main_window_no_deal", t_no_deal_mainwindow)


# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    test_no_deal_in_pipeline()
    test_score_formula()
    test_trap()
    test_labels()
    test_clamping()
    test_wf_params()
    test_exit_logic()
    test_e2e()
    test_ui_clean()

    print(f"\n{'='*60}")
    print(f"RESULTS: {PASS} passed, {FAIL} failed")
    print(f"{'='*60}")
    sys.exit(1 if FAIL > 0 else 0)
