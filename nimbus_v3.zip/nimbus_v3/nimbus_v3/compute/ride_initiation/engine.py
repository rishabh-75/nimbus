"""Stateless ride classification engine.

``RideEngine`` is a thin namespace class — no constructor args, no
mutable state. Methods are pure: same input → same output.

Three public methods:

  - :meth:`classify` — single symbol → ``RideResult``.
  - :meth:`classify_industry` — group of symbols → ``RideResult``
    aggregated from per-constituent classifications.
  - :meth:`classify_universe` — full universe → ``RideResult``
    aggregated the same way.

Phase resolution priority: INITIATION > RETEST > CONTINUATION.
When multiple detectors fire on the same bar, the highest-priority
phase wins.

Industry / universe classification — roll-up approach
─────────────────────────────────────────────────────
The strategy is per-symbol; the industry/group is a strict
aggregation of per-constituent results, NOT an independent
classifier on a synthetic OHLCV stream. For each bar:

  - **Phase** = highest-priority phase appearing in any
    constituent (priority: INIT > RETEST > CONT > NONE).
  - **Score** = ADTV-weighted mean of constituent scores at the
    group's resolved phase. Heavyweights by liquidity dominate
    the aggregate score the same way they would a synthetic
    index — but the *phase* is anchored to what's actually
    happening at the constituent level.
  - **Fire** = True iff any constituent fired on that bar.

This means: if the group shows CONT, at least one constituent
is currently classified INIT/RETEST/CONT. If the group shows
NONE, no constituent is riding. The synthetic-OHLCV approach
used previously could produce a group fire while every
constituent showed NONE — a confusing outcome the roll-up
prevents.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import criteria as cr
from .constants import (
    ACTIVE_WINDOW,
    CONT_ACTIVE_WINDOW,
    CROSS_LOOKBACK,
    INDUSTRY_MIN_MEMBERS,
    REQUIRED_COLS,
    RETEST_ACTIVE_WINDOW,
    RETEST_PULLBACK_MAX_BARS,
    RETEST_RIDE_LOOKBACK,
    SMA_SLOPE_WINDOW,
)
from .score import compute_composite_score
from .types import RidePhase, RideResult


# ══════════════════════════════════════════════════════════════════════
# Phase priority — used by the industry / universe roll-up to resolve
# the highest-priority phase appearing across constituents on each bar.
# ══════════════════════════════════════════════════════════════════════

#: Phase string → priority integer. Mirrors ``types._PRIORITY`` but
#: keyed by the string value (which is what gets stored in
#: ``RideResult.phase`` series after RidePhase enum construction).
_PHASE_PRIORITY_LOOKUP: dict[str, int] = {
    RidePhase.INITIATION.value:   3,
    RidePhase.RETEST.value:       2,
    RidePhase.CONTINUATION.value: 1,
    RidePhase.NONE.value:         0,
}

#: Inverse: priority integer → phase value string. Used to decode the
#: per-bar max priority back into a RidePhase value for the group
#: phase Series.
_PRIORITY_TO_PHASE_VALUE: dict[int, str] = {
    3: RidePhase.INITIATION.value,
    2: RidePhase.RETEST.value,
    1: RidePhase.CONTINUATION.value,
    0: RidePhase.NONE.value,
}


# ══════════════════════════════════════════════════════════════════════
# Phase fire detectors — one per phase, all stateless module functions
# ══════════════════════════════════════════════════════════════════════


def _initiation_fire(df: pd.DataFrame) -> pd.Series:
    """All INITIATION criteria combined."""
    return (
        cr.crit_hold_ok(df)
        & cr.crit_fresh_cross(df)
        & cr.crit_not_detached_today(df)
        & cr.crit_not_detached_yesterday(df)
        & cr.crit_open_in_zone(df)
        & cr.crit_not_gap_through(df)
        & cr.crit_slope_ok(df)
        & cr.crit_bbw_ok(df)
        & cr.crit_vol_surge(df)
        & cr.crit_body_strength(df)
    ).fillna(False).astype(bool)


def _retest_fire(df: pd.DataFrame) -> pd.Series:
    """All RETEST criteria combined.

    No vol_surge (retests typically have lower volume than initiations
    because supply has been absorbed). No bbw_ok (bands are likely
    already wide post-initiation). No open_in_zone (open can be
    anywhere reasonable above the band).
    """
    return (
        cr.crit_retest_qualified_base(df)
        & cr.crit_retest_pullback_occurred(df)
        & cr.crit_retest_held_sma(df)
        & cr.crit_retest_resumption(df)
        & cr.crit_hold_ok(df)
        & cr.crit_not_detached_today(df)
        & cr.crit_not_detached_yesterday(df)
        & cr.crit_body_strength(df)
        & cr.crit_not_gap_through(df)
        & cr.crit_slope_ok(df)
    ).fillna(False).astype(bool)


def _continuation_fire(df: pd.DataFrame) -> pd.Series:
    """All CONTINUATION criteria combined.

    No fresh_cross (always false for continuations by definition).
    No bbw_ok (bands wide post-initiation by definition).
    No open_in_zone (open anywhere above SMA acceptable).
    No vol_surge (replaced by softer vol_not_decayed).
    No body_strength: CONT is a continuation of an already-
    established ride. A single doji bar mid-band-walk is normal
    market noise, not a reason to flicker the phase off and on. The
    body-strength check stays on INIT (entries should be decisive)
    and RETEST (resumption bar quality matters), but here would
    just produce gaps in CONT classification on quiet bars even
    when the underlying ride is intact.
    """
    return (
        cr.crit_cont_established_ride(df)
        & cr.crit_hold_ok(df)
        & cr.crit_slope_ok(df)
        & cr.crit_cont_not_extended(df)
        & cr.crit_cont_above_trend(df)
        & cr.crit_cont_vol_not_decayed(df)
    ).fillna(False).astype(bool)


# ══════════════════════════════════════════════════════════════════════
# Active-window expansion with kill switches
# ══════════════════════════════════════════════════════════════════════


def _expand_active(
    fire: pd.Series,
    df: pd.DataFrame,
    active_window: int,
) -> pd.Series:
    """Expand fire bars forward by ``active_window``, applying:
        Kill 1: close drops below SMA20.
        Kill 2: body retreats inside band.

    A bar is "active" if a fire happened within the last
    ``active_window`` bars (inclusive of the fire bar itself) AND no
    kill condition has triggered since.
    """
    if not fire.any():
        return pd.Series(False, index=fire.index, dtype=bool)

    close = df["Close"].values
    sma = df["sma_20"].values
    body_above = cr.body_above_band(df).values

    fire_arr = fire.values
    active_arr = np.zeros(len(fire_arr), dtype=bool)
    n = len(fire_arr)

    for t in range(n):
        if not fire_arr[t]:
            continue
        for k in range(active_window):
            idx = t + k
            if idx >= n:
                break
            # Kill 1: close < SMA20
            if not (np.isnan(close[idx]) or np.isnan(sma[idx])):
                if close[idx] < sma[idx]:
                    break
            # Kill 2: body retreated inside band
            if not body_above[idx]:
                break
            active_arr[idx] = True

    return pd.Series(active_arr, index=fire.index, dtype=bool)


# ══════════════════════════════════════════════════════════════════════
# RideEngine — stateless class
# ══════════════════════════════════════════════════════════════════════


class RideEngine:
    """Stateless engine that classifies each bar as
    INITIATION / RETEST / CONTINUATION / NONE and computes a
    conviction composite score.

    No constructor arguments. All tuning lives in
    :mod:`nimbus_v3.compute.ride_initiation.constants`.

    Two-step classification:

    1. Run the three phase detectors independently on the same df.
    2. Expand each detector's fire bars forward by its own active
       window (with kill switches), then resolve overlaps by phase
       priority (INIT > RETEST > CONT).

    Then compute the composite score on bars that fire any phase.
    """

    def classify(self, df: pd.DataFrame) -> RideResult:
        """Classify every bar of ``df``.

        Returns ``RideResult.empty(df.index)`` if input is invalid
        (missing columns or insufficient history).
        """
        if not self._is_valid_input(df):
            return RideResult.empty(df.index)

        init_fire = _initiation_fire(df)
        retest_fire = _retest_fire(df)
        cont_fire = _continuation_fire(df)

        init_active = _expand_active(init_fire, df, ACTIVE_WINDOW)
        retest_active = _expand_active(retest_fire, df, RETEST_ACTIVE_WINDOW)
        cont_active = _expand_active(cont_fire, df, CONT_ACTIVE_WINDOW)

        # Phase resolution by priority — INIT > RETEST > CONT > NONE
        # Use boolean indexing rather than .mask() because pd.Series.mask
        # invokes str() on enum replacements and truncates the result.
        # Storing the str value directly keeps the column object-dtype-clean
        # and equality-comparable both as `phase == RidePhase.X` and as
        # `phase == "INIT"` (since RidePhase is a str-enum).
        phase = pd.Series(
            RidePhase.NONE.value, index=df.index, dtype=object
        )
        phase[cont_active.values] = RidePhase.CONTINUATION.value
        phase[retest_active.values] = RidePhase.RETEST.value
        phase[init_active.values] = RidePhase.INITIATION.value

        fire = init_active | retest_active | cont_active
        score = compute_composite_score(df, fire)

        return RideResult(phase=phase, score=score, fire=fire)

    def classify_industry(
        self,
        members_panel: dict[str, pd.DataFrame],
    ) -> RideResult:
        """Industry-level classification — roll-up over constituents.

        The strategy is per-symbol; the industry is a strict
        aggregation of per-constituent classifications. For each bar:

          - **Phase** = highest-priority phase appearing in any
            constituent (INIT > RETEST > CONT > NONE).
          - **Score** = ADTV-weighted mean of constituent scores
            *at that phase* (members in lower-priority phases or
            NONE don't contribute). Heavyweights by liquidity
            dominate naturally.
          - **Fire** = True iff any constituent fired.

        Args:
            members_panel: ``{symbol: enriched_df}``. Each frame must
                have ``Open/High/Low/Close/Volume`` plus the standard
                indicator columns. Members with insufficient history
                are dropped from the aggregation silently.

        Returns:
            ``RideResult.empty(...)`` when fewer than
            :data:`INDUSTRY_MIN_MEMBERS` members can contribute,
            else a full result indexed on the union of the
            contributing members' indices.
        """
        return self._aggregate_classifications(
            members_panel, min_members=INDUSTRY_MIN_MEMBERS,
        )

    def classify_universe(
        self,
        members_panel: dict[str, pd.DataFrame],
    ) -> RideResult:
        """Universe-wide ALL-row classification — same roll-up over
        every member of the panel. Becomes the universe's own
        Phase + Score (the ALL row in Market Pulse).

        Returns:
            ``RideResult.empty(...)`` when no member can contribute
            a valid classification; else a full result.
        """
        return self._aggregate_classifications(
            members_panel, min_members=1,
        )

    # ─── roll-up implementation ─────────────────────────────────

    def _aggregate_classifications(
        self,
        members_panel: dict[str, pd.DataFrame],
        *,
        min_members: int,
    ) -> RideResult:
        """Workhorse for ``classify_industry`` / ``classify_universe``.

        Per-bar:
          1. Each contributing member's phase priority [0..3].
          2. Group priority = max across members.
          3. Group phase = priority → enum reverse-map.
          4. Group score = ADTV-weighted mean of scores from members
             at the group's resolved phase priority.
          5. Group fire = group priority > 0.
        """
        if len(members_panel) < min_members:
            return RideResult.empty(pd.DatetimeIndex([]))

        # 1. Classify each member; capture ADTV weight.
        per_phase: dict[str, pd.Series] = {}
        per_score: dict[str, pd.Series] = {}
        weights: dict[str, float] = {}
        for sym, df in members_panel.items():
            if df is None or len(df) < 20:
                continue
            if "Close" not in df.columns or "Volume" not in df.columns:
                continue
            res = self.classify(df)
            if res.phase.empty:
                continue
            adtv = float((df["Close"] * df["Volume"]).tail(20).mean())
            if adtv != adtv or adtv <= 0:    # NaN or non-positive
                continue
            per_phase[sym] = res.phase
            per_score[sym] = res.score
            weights[sym] = adtv

        if len(per_phase) < min_members:
            return RideResult.empty(pd.DatetimeIndex([]))

        # 2. Stack on the union of member indices. Where a member
        #    has no value at a given bar (shorter history), fill
        #    with NONE (absence is not a fire).
        phase_df = pd.DataFrame(per_phase).fillna(RidePhase.NONE.value)
        score_df = pd.DataFrame(per_score)    # NaN-fill is preserved

        # 3. Phase → priority. Priority 0 = NONE, no fire.
        priority_df = phase_df.map(
            lambda p: _PHASE_PRIORITY_LOOKUP.get(str(p), 0)
        )

        # 4. Group priority + phase per bar.
        max_priority = priority_df.max(axis=1).fillna(0).astype(int)
        group_phase = max_priority.map(_PRIORITY_TO_PHASE_VALUE)

        # 5. Group score = ADTV-weighted mean of scores from members
        #    at the group's max-priority phase. Members below the
        #    max (e.g. CONT contributors when group is INIT) don't
        #    dilute the score — keeps Phase and Score consistent.
        weight_arr = np.array(
            [weights[s] for s in phase_df.columns], dtype=float,
        )
        # at_phase[T, M]: True iff member M's priority on bar T equals
        # the group's max priority on bar T.
        at_phase = priority_df.eq(max_priority, axis=0).values
        # Weight matrix: only members at the resolved phase contribute.
        weight_mat = at_phase.astype(float) * weight_arr
        score_mat = score_df.fillna(0.0).values

        weighted_scores = (score_mat * weight_mat).sum(axis=1)
        total_weights = weight_mat.sum(axis=1)
        with np.errstate(divide="ignore", invalid="ignore"):
            group_score_vals = np.where(
                (total_weights > 0) & (max_priority.values > 0),
                weighted_scores / np.where(total_weights > 0, total_weights, 1),
                np.nan,
            )
        group_score = pd.Series(
            group_score_vals, index=phase_df.index, dtype=float,
        )

        # 6. Fire when any member fired (group priority > 0).
        group_fire = (max_priority > 0).astype(bool)

        return RideResult(
            phase=group_phase,
            score=group_score,
            fire=group_fire,
        )

    # ─── internals ──────────────────────────────────────────────

    def _is_valid_input(self, df: pd.DataFrame) -> bool:
        if not all(c in df.columns for c in REQUIRED_COLS):
            return False
        # CONTINUATION's rolling looks back CONT_RIDE_LOOKBACK + 10 (vol decay shift)
        # RETEST needs RETEST_PULLBACK_MAX_BARS + RETEST_RIDE_LOOKBACK
        # INIT needs CROSS_LOOKBACK + SMA_SLOPE_WINDOW
        # Take the max + safety margin
        min_bars = max(
            CROSS_LOOKBACK + SMA_SLOPE_WINDOW + 5,
            RETEST_PULLBACK_MAX_BARS + RETEST_RIDE_LOOKBACK + 5,
            30,  # CONT_RIDE_LOOKBACK + 10 + buffer
        )
        return len(df) >= min_bars
