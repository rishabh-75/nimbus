"""nimbus_v3.data.intraday_flags — build the 4h body-above map.

Orchestration glue between the secondary 4h cache
(:class:`nimbus_v3.data.intraday_loader.IntradayLoader`) and the pure edge
engine, which consumes a plain ``{symbol: bool | None}`` map and copies the
flag onto each row. Kept in the DATA layer because it performs IO; the
compute engines stay stateless and never fetch.

The map is BEST-EFFORT by design. A symbol whose 4h data can't be loaded
maps to ``None`` ("unknown"), never to a guessed ``False`` — the Edge tab
renders unknown distinctly from a real "not above", so a data gap can't
masquerade as a signal.
"""
from __future__ import annotations

import logging

from nimbus_v3.compute.band_ride import body_above_on_frame
from nimbus_v3.data.intraday_loader import IntradayLoader

logger = logging.getLogger(__name__)


def build_above_4h_map(
    symbols: list[str],
    loader: IntradayLoader,
    *,
    force_refresh: bool = False,
    cache_only: bool = False,
) -> dict[str, bool | None]:
    """Return ``{symbol: body-above-upper-BB-on-4h}`` for ``symbols``.

    ``True``/``False`` when the 4h frame loads and the flag is computable;
    ``None`` when the symbol's 4h data is unavailable or too short for the
    band. Never raises — a slow or missing intraday feed degrades the flag
    to "unknown" rather than blocking the daily board.

    Args:
        symbols: symbols to flag.
        loader: the 4h loader (injected, so tests pass a fake).
        force_refresh: bypass the 4h cache TTL for every symbol.
        cache_only: read only the cache, never fetch. This is the path the
            GUI thread uses — a parquet read can't hang the window, a
            network fetch could. Uncached symbols come back ``None``.
    """
    out: dict[str, bool | None] = {}
    for sym in symbols:
        try:
            df = loader.load(sym, force_refresh=force_refresh,
                             cache_only=cache_only)
        except Exception:            # noqa: BLE001
            logger.debug("intraday_flags: load failed for %s", sym)
            out[sym] = None
            continue
        if df is None or df.empty:
            out[sym] = None
            continue
        out[sym] = body_above_on_frame(df)
    return out
