"""Tests for FilingImpactClassifier and FilingContextProvider."""
from __future__ import annotations

from unittest.mock import MagicMock

import pandas as pd
import pytest

from nimbus_v3.context.filing_context import (
    FilingContextProvider,
    FilingImpactClassifier,
)
from nimbus_v3.core.types import FilingImpact
from nimbus_v3.data.filings_loader import Filing


def _filing(headline: str, *, category: str = "", details: str = "",
             date: str = "2024-05-15") -> Filing:
    return Filing(
        symbol="X",
        filing_date=pd.Timestamp(date),
        category=category,
        headline=headline,
        details=details,
        attachment_url=None,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Classifier — TRAP patterns
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("headline", [
    "SEBI issues Show Cause Notice to the Company",
    "Receipt of SEBI order imposing penalty",
    "Resignation of Auditor M/s XYZ & Co.",
    "Resignation of CFO / Chief Financial Officer",
    "Auditors Report contains qualified opinion",
    "Going concern doubt expressed by auditors",
    "Default in payment of interest on NCDs",
    "Restatement of Financial Statements for FY23",
    "Admission of NCLT petition against the Company",
    "Forensic audit ordered by audit committee",
    "Allegations of Fraud involving senior management",
    "Material misstatement disclosed",
])
def test_classifier_flags_trap(headline: str) -> None:
    clf = FilingImpactClassifier()
    assert clf.classify(_filing(headline)) is FilingImpact.TRAP


# ══════════════════════════════════════════════════════════════════════════════
# Classifier — MATERIAL
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("headline", [
    "Board approves acquisition of ABC Pvt Ltd",
    "Merger with XYZ Limited approved",
    "Scheme of arrangement for demerger filed",
    "Quarterly Results for Q4 FY24",
    "Financial Results - Audited",
    "Capex plan of Rs. 500 Cr announced",
    "Appointment of new CEO Mr. John Doe",
    "Managing Director change announced",
    "Board recommends bonus issue 1:1",
    "Preferential allotment to promoters approved",
    "Buyback of shares approved by Board",
    "Interim Dividend of Rs. 5 per share",
])
def test_classifier_flags_material(headline: str) -> None:
    clf = FilingImpactClassifier()
    assert clf.classify(_filing(headline)) is FilingImpact.MATERIAL


# ══════════════════════════════════════════════════════════════════════════════
# Classifier — MINOR
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("headline", [
    "Closure of Trading Window",
    "Disclosure under Regulation 30 of SEBI LODR",
    "Notice of Board Meeting",
    "Record Date for Dividend Payment",
    "Annual General Meeting Notice",
    "Compliance Certificate for Q4",
    "Postal Ballot intimation",
])
def test_classifier_flags_minor(headline: str) -> None:
    clf = FilingImpactClassifier()
    assert clf.classify(_filing(headline)) is FilingImpact.MINOR


# ══════════════════════════════════════════════════════════════════════════════
# Classifier — NONE and priority ordering
# ══════════════════════════════════════════════════════════════════════════════

def test_classifier_returns_none_when_nothing_matches() -> None:
    clf = FilingImpactClassifier()
    assert clf.classify(_filing("Random announcement text")) is FilingImpact.NONE


def test_classifier_priority_trap_over_material() -> None:
    """A filing that triggers BOTH a TRAP pattern and a MATERIAL pattern
    must classify as TRAP (highest priority wins)."""
    clf = FilingImpactClassifier()
    f = _filing(
        "Quarterly Results with SEBI investigation pending",
        details="Auditor has expressed qualified opinion",
    )
    assert clf.classify(f) is FilingImpact.TRAP


def test_classifier_priority_material_over_minor() -> None:
    clf = FilingImpactClassifier()
    f = _filing(
        "Notice of Board Meeting to consider Quarterly Results",
    )
    assert clf.classify(f) is FilingImpact.MATERIAL


def test_classifier_searches_category_and_details_not_just_headline() -> None:
    clf = FilingImpactClassifier()
    f = _filing(
        headline="Regulatory announcement",
        details="SEBI has issued an investigation order against the Company",
    )
    assert clf.classify(f) is FilingImpact.TRAP


# ══════════════════════════════════════════════════════════════════════════════
# Provider
# ══════════════════════════════════════════════════════════════════════════════

def _loader_returning(filings: list[Filing]) -> MagicMock:
    loader = MagicMock()
    loader.load_since.return_value = filings
    return loader


def test_provider_returns_none_impact_when_no_filings() -> None:
    provider = FilingContextProvider(_loader_returning([]))
    ctx = provider.build(symbol="X", asof_date=pd.Timestamp("2024-05-15"))
    assert ctx is not None
    assert ctx.latest_impact is FilingImpact.NONE
    assert ctx.is_trap is False
    assert ctx.days_since_latest is None
    assert ctx.latest_headline is None


def test_provider_picks_highest_priority_not_most_recent() -> None:
    """A TRAP filing from 4 days ago should beat a MATERIAL filing from yesterday."""
    filings = [
        _filing("Board meeting minutes published", date="2024-05-14"),       # minor
        _filing("Quarterly Results approved", date="2024-05-13"),             # material
        _filing("SEBI enforcement action notice", date="2024-05-11"),        # trap
    ]
    provider = FilingContextProvider(_loader_returning(filings))
    ctx = provider.build(symbol="X", asof_date=pd.Timestamp("2024-05-15"))
    assert ctx is not None
    assert ctx.latest_impact is FilingImpact.TRAP
    assert ctx.is_trap is True
    assert ctx.days_since_latest == 4
    assert ctx.latest_headline == "SEBI enforcement action notice"


def test_provider_ties_broken_by_recency() -> None:
    filings = [
        _filing("SEBI investigation notice", date="2024-05-11"),
        _filing("Auditor resignation intimation", date="2024-05-14"),
    ]
    provider = FilingContextProvider(_loader_returning(filings))
    ctx = provider.build(symbol="X", asof_date=pd.Timestamp("2024-05-15"))
    assert ctx is not None
    assert ctx.latest_impact is FilingImpact.TRAP
    # The more recent TRAP wins the tiebreak.
    assert ctx.latest_headline == "Auditor resignation intimation"


def test_provider_returns_none_for_missing_symbol() -> None:
    provider = FilingContextProvider(_loader_returning([]))
    assert provider.build(symbol=None, asof_date=pd.Timestamp("2024-05-15")) is None
    assert provider.build(symbol="", asof_date=pd.Timestamp("2024-05-15")) is None
