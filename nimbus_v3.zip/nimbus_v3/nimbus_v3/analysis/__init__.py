"""nimbus_v3.analysis — derived analytical classifiers.

Pure numeric classifiers that turn raw indicator values into human-
readable diagnostic labels. No Qt, no IO, no side-effects — all
functions here are reusable across the dashboard, scanner, and
research scripts.
"""
