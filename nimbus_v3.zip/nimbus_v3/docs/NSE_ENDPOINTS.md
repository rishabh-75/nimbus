# NSE_ENDPOINTS

**Status:** Placeholder. Populated incrementally as endpoints are hardened in Phases 1-2.

## Purpose

Single living reference for every NSE endpoint `nimbus_v3` consumes. Each entry
documents what's needed to integrate without guesswork:

- URL pattern
- HTTP method + required headers
- Required cookies (base vs. endpoint-scoped per `data/nse_client.py`)
- Query parameters
- Response schema (typed where possible)
- Observed rate limit + empirically chosen spacing
- Failure modes and retry behaviour
- Provenance: where the contract came from (NSE docs, v2 experience, oracle
  experience, live probing)

## Client invariants (validated by `nimbus_v2`)

Carried forward as design constraints for `nimbus_v3/data/nse_client.py`:

1. **No `requests.Session`**. Sessions cause cookie cross-contamination between
   endpoint groups. Plain `requests` calls with manually-managed cookies per
   endpoint group.
2. **Base cookies** come from a `_warm()` call to `https://www.nseindia.com/`
   at session start. Re-warmed if missing.
3. **Endpoint-scoped cookies** come from a `_seed(referer)` call per endpoint
   group, cached 5 minutes per referer.
4. **Cooldown on failure**: a failed fetch sets `_last_fetch_ts` to now and
   honours a 5-minute cooldown before retry. This is the fix for v2's ETF
   universe infinite retry loop.
5. **Rate limit spacing**: configurable per endpoint; default 1.2s between
   calls in the same group.
6. **Single shared instance per process**: constructed once at startup and
   dependency-injected. Not a singleton class — a composition concern.

## Endpoints (to be populated)

### Universe

- NSE index constituents (sectoral + broad-market)
- NSE ETF list

### Options

- Option chain (equity)
- Option chain (index)

### Corporate

- Announcements / filings
- Corporate actions (earnings, dividends, splits)

### Flow

- FII/DII daily cash flow
- Block deals
- Bulk deals
- SAST disclosures
- Insider trading disclosures

### Market data

- India VIX (historical + live)
- Index snapshot (fallback for quote data)
