"""nimbus_v3.compute.vix_pace — VIX pace regime classifier.

Classifies daily VIX history into {RISING, STABLE, FALLING, UNKNOWN}
regimes based on the *pace* of VIX change, not its level. Mirrors
the self-normalizing design of ``FlowAnalyticsEngine.compute_vol_regime``
on the commodity side:

  1. slope_20d(t) = (VIX_t - VIX_{t-20}) / 20       # daily avg Δ
  2. z(t) = (slope - slope.rolling(252).mean())
                / slope.rolling(252).std()          # z vs baseline
  3. regime(t) =
       RISING  if z >  +1.0
       FALLING if z <  -1.0
       STABLE  otherwise
       UNKNOWN during baseline warmup (first ~272 bars)

The choice of 20d slope window is validated by walk-forward testing
(see docs/research/vix_pace/). Four windows (5/10/20/60) were tested;
the 20d window produced 31 industry × regime cells with 100%
sign-agreement across 3 walk-forward folds, with a coherent economic
interpretation (cyclicals lead in RISING, same cyclicals lag in
STABLE). Shorter windows showed spurious pairwise agreement; longer
windows had fewer independent observations.

Consumed by:
  - ``nimbus_v3.compute.vix_regime_industry_directions`` — static
    config keying per-industry direction tables to the regime labels.
  - No UI surface currently — the previous Market Pulse header
    badge was dropped during the Dashboard / Market Pulse
    unification. The classifier is preserved as a research artefact.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd


# ══════════════════════════════════════════════════════════════════════
# Regime labels — exposed as module constants for downstream consumers
# ══════════════════════════════════════════════════════════════════════

#: Label for "VIX slope z > +cutoff" — fear building unusually fast
REGIME_RISING: Final[str] = "RISING"

#: Label for "VIX slope z < -cutoff" — fear dissipating unusually fast
REGIME_FALLING: Final[str] = "FALLING"

#: Label for "|z| ≤ cutoff" — normal VIX behavior
REGIME_STABLE: Final[str] = "STABLE"

#: Label for bars before the baseline warmup window has enough
#: history. Consumers should treat UNKNOWN as "no regime signal
#: available" and degrade gracefully.
REGIME_UNKNOWN: Final[str] = "UNKNOWN"

#: Tuple of classifiable (non-UNKNOWN) regimes in canonical order.
#: UI rendering, stat tables, and config keys should use this order.
REGIMES: Final[tuple[str, ...]] = (
    REGIME_RISING, REGIME_STABLE, REGIME_FALLING,
)


@dataclass(frozen=True)
class VIXPaceState:
    """Point-in-time snapshot of VIX pace regime.

    Produced by :meth:`VIXPaceClassifier.classify_current`. The
    ``slope_z`` value is exposed so UI consumers can show a bar or
    dial indicating how far into a regime we currently are (e.g.
    "RISING at z=+1.8" vs "RISING at z=+1.05 — just across
    threshold").
    """

    #: One of REGIME_RISING / REGIME_STABLE / REGIME_FALLING /
    #: REGIME_UNKNOWN.
    regime: str

    #: The current z-score. Positive = rising faster than baseline;
    #: negative = falling faster. NaN during warmup or when inputs
    #: insufficient.
    slope_z: float

    #: Number of consecutive bars (including current) the regime has
    #: been active. 1 on the first bar of a new regime. Useful for
    #: detecting regime persistence.
    run_length: int

    #: The current VIX close. Preserved for display ("VIX 16.3,
    #: RISING, z+1.4").
    vix_close: float


class VIXPaceClassifier:
    """Stateless classifier for VIX pace regime.

    No constructor arguments — the engine is a fixed recipe. To
    experiment with alternate windows, construct a new classifier
    via ``VIXPaceClassifier.with_overrides(slope_window=10)`` which
    returns a new class with adjusted constants. The default
    classifier uses the production-calibrated 20d window.

    Usage::

        classifier = VIXPaceClassifier()
        regime_df = classifier.classify_history(vix_close_series)
        state = classifier.classify_current(vix_close_series)
    """

    #: Window for slope computation (in trading days). 20d is the
    #: production-calibrated choice. See module docstring for why.
    SLOPE_WINDOW: Final[int] = 20

    #: Window for z-score baseline. 252 ≈ 1 trading year. Fixed
    #: across all slope windows per the research design — letting
    #: the baseline scale with slope produces inconsistent regime
    #: thresholds across windows.
    Z_BASELINE_WINDOW: Final[int] = 252

    #: Threshold beyond which we flag RISING / FALLING. 1.0 standard
    #: deviations is the research-calibrated choice — stricter (1.5+)
    #: produces too few classified days, looser (<0.75) dilutes the
    #: regime distinction.
    Z_CUTOFF: Final[float] = 1.0

    def __init__(self) -> None:
        """Stateless — no constructor arguments."""

    @classmethod
    def schema_hash(cls) -> str:
        """Stable hash of the classifier's constants. Namespaces any
        cached regime computations so a parameter change produces a
        fresh cache path (old cached series become unreachable).

        Changes to ``SLOPE_WINDOW``, ``Z_BASELINE_WINDOW``, or
        ``Z_CUTOFF`` invalidate the hash. Consumers that key caches
        on regime output should include this hash in their
        namespace.
        """
        payload = repr((
            cls.SLOPE_WINDOW,
            cls.Z_BASELINE_WINDOW,
            cls.Z_CUTOFF,
        )).encode("utf-8")
        return hashlib.md5(payload).hexdigest()[:8]

    # ══════════════════════════════════════════════════════════════════
    # Public API — history (batch)
    # ══════════════════════════════════════════════════════════════════

    def classify_history(self, vix_close: pd.Series) -> pd.DataFrame:
        """Classify an entire VIX close series into per-bar regimes.

        Args:
            vix_close: Daily VIX close values indexed by date
                (tz-naive or tz-aware, ascending).

        Returns:
            DataFrame indexed identically to input, with columns
            ``['vix', 'slope', 'z', 'regime']``. The ``regime``
            column contains REGIME_RISING / REGIME_STABLE /
            REGIME_FALLING / REGIME_UNKNOWN strings.

            For the first ``SLOPE_WINDOW + Z_BASELINE_WINDOW`` bars
            the z-score is NaN and the regime is UNKNOWN. Downstream
            consumers should treat UNKNOWN as "no signal available".
        """
        slope = vix_close.diff(self.SLOPE_WINDOW) / self.SLOPE_WINDOW
        mu = slope.rolling(self.Z_BASELINE_WINDOW).mean()
        sd = slope.rolling(self.Z_BASELINE_WINDOW).std()
        z = (slope - mu) / sd

        regime = pd.Series(REGIME_UNKNOWN, index=vix_close.index)
        regime[z > +self.Z_CUTOFF] = REGIME_RISING
        regime[z < -self.Z_CUTOFF] = REGIME_FALLING
        stable_mask = (z >= -self.Z_CUTOFF) & (z <= +self.Z_CUTOFF)
        regime[stable_mask] = REGIME_STABLE

        return pd.DataFrame({
            "vix":    vix_close,
            "slope":  slope,
            "z":      z,
            "regime": regime,
        })

    # ══════════════════════════════════════════════════════════════════
    # Public API — current bar (single snapshot)
    # ══════════════════════════════════════════════════════════════════

    def classify_current(self, vix_close: pd.Series) -> VIXPaceState:
        """Classify the most recent bar and return a VIXPaceState
        with run-length information.

        Args:
            vix_close: VIX close series. Must be long enough to
                compute the z-score baseline; otherwise the returned
                state has ``regime=UNKNOWN`` and ``slope_z=NaN``.

        Returns:
            VIXPaceState snapshot. Always safe to call — returns an
            UNKNOWN state rather than raising on insufficient data.
        """
        if len(vix_close) == 0:
            return VIXPaceState(
                regime=REGIME_UNKNOWN,
                slope_z=float("nan"),
                run_length=0,
                vix_close=float("nan"),
            )

        history = self.classify_history(vix_close)
        last_regime = str(history["regime"].iloc[-1])
        last_z = float(history["z"].iloc[-1])
        last_vix = float(history["vix"].iloc[-1])

        # Count consecutive bars backward from the end with the same
        # regime label. A regime change terminates the run.
        run_length = 0
        for regime_val in history["regime"].iloc[::-1]:
            if regime_val == last_regime:
                run_length += 1
            else:
                break

        return VIXPaceState(
            regime=last_regime,
            slope_z=last_z if not np.isnan(last_z) else float("nan"),
            run_length=run_length,
            vix_close=last_vix,
        )

    # ══════════════════════════════════════════════════════════════════
    # Diagnostic helpers
    # ══════════════════════════════════════════════════════════════════

    def regime_distribution(self, vix_close: pd.Series) -> pd.Series:
        """Return count per regime label across the full history.
        Useful for diagnostics and for verifying a regime
        classification matches the research data distribution."""
        return self.classify_history(vix_close)["regime"].value_counts()
