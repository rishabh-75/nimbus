"""nimbus_v3.macro.universe — commodity instrument registry.

Hardcoded list of the commodities the Macro Flow Panel tracks. Edit
this file to add or remove instruments — there is no config layer.

Each ``CommodityInstrument`` carries the yfinance front-month ticker,
display name, category (precious/industrial/energy/ag/livestock), and
optional metadata for downstream turns:

- ``root`` and ``exchange``: used by Phase 9c (term structure) to
  resolve deferred contracts via CME month codes.
- ``listing_cycle``: which CME month codes actually have listed
  contracts. Some commodities trade every month (gold), others on
  a fixed cycle (corn: H/K/N/U/Z).
- ``leader_ticker``: cross-commodity precursor for Phase 9e.

Liquidity caveat
────────────────
Several CME industrial-metal contracts (zinc, lead, tin) have no
liquid free-tier feed. They're omitted rather than faked with ETF
proxies. Aluminium (``ALI=F``) is included despite thin volume because
its price tracks LME aluminium tightly via arb — the price signal is
useful even when the volume signal isn't.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Final


class CommodityCategory(str, Enum):
    """High-level category — drives panel grouping and color coding."""
    PRECIOUS = "Precious"
    INDUSTRIAL = "Industrial"
    ENERGY = "Energy"
    AGRICULTURAL = "Agricultural"
    LIVESTOCK = "Livestock"


@dataclass(frozen=True)
class CommodityInstrument:
    """One commodity tracked by the macro flow detector.

    ``ticker`` is the front-month/continuous yfinance symbol used for
    the primary signal calculations. ``root``, ``exchange``, and
    ``listing_cycle`` are reserved for Phase 9c term-structure work
    where deferred contracts are loaded explicitly.
    """
    ticker: str
    name: str
    category: CommodityCategory
    root: str
    exchange: str
    listing_cycle: tuple[str, ...]
    leader_ticker: str | None = None


#: CME month codes — January through December.
MONTH_CODES: Final[tuple[str, ...]] = (
    "F", "G", "H", "J", "K", "M", "N", "Q", "U", "V", "X", "Z",
)

# Listing cycles encountered:
ALL_MONTHS: Final[tuple[str, ...]] = MONTH_CODES
GRAINS_CYCLE: Final[tuple[str, ...]] = ("H", "K", "N", "U", "Z")           # Mar/May/Jul/Sep/Dec
SOYBEAN_CYCLE: Final[tuple[str, ...]] = ("F", "H", "K", "N", "Q", "U", "X")  # Jan/Mar/May/Jul/Aug/Sep/Nov
COFFEE_SUGAR_CYCLE: Final[tuple[str, ...]] = ("H", "K", "N", "U", "Z")
COCOA_CYCLE: Final[tuple[str, ...]] = ("H", "K", "N", "U", "Z")
COTTON_CYCLE: Final[tuple[str, ...]] = ("H", "K", "N", "V", "Z")
LIVE_CATTLE_CYCLE: Final[tuple[str, ...]] = ("G", "J", "M", "Q", "V", "Z")
LEAN_HOG_CYCLE: Final[tuple[str, ...]] = ("G", "J", "K", "M", "N", "Q", "V", "Z")
FEEDER_CATTLE_CYCLE: Final[tuple[str, ...]] = ("F", "H", "J", "K", "Q", "U", "V", "X")


# ══════════════════════════════════════════════════════════════════════════════
# Universe
# ══════════════════════════════════════════════════════════════════════════════

#: The verified commodity universe — 23 instruments across 5 categories.
#: Liquidity verified against Yahoo's commodities table, April 2026.
COMMODITY_UNIVERSE: Final[tuple[CommodityInstrument, ...]] = (
    # ── Precious metals ─────────────────────────────────────────────────
    CommodityInstrument(
        ticker="GC=F", name="Gold", category=CommodityCategory.PRECIOUS,
        root="GC", exchange="CMX", listing_cycle=ALL_MONTHS,
        leader_ticker=None,    # Gold IS the precious leader.
    ),
    CommodityInstrument(
        ticker="SI=F", name="Silver", category=CommodityCategory.PRECIOUS,
        root="SI", exchange="CMX",
        listing_cycle=("F", "H", "K", "N", "U", "Z"),
        leader_ticker="GC=F",
    ),
    CommodityInstrument(
        ticker="PL=F", name="Platinum", category=CommodityCategory.PRECIOUS,
        root="PL", exchange="NYM",
        listing_cycle=("F", "J", "N", "V"),
        leader_ticker="GC=F",
    ),
    CommodityInstrument(
        ticker="PA=F", name="Palladium", category=CommodityCategory.PRECIOUS,
        root="PA", exchange="NYM",
        listing_cycle=("H", "M", "U", "Z"),
        leader_ticker="GC=F",
    ),

    # ── Industrial metals ────────────────────────────────────────────────
    CommodityInstrument(
        ticker="HG=F", name="Copper", category=CommodityCategory.INDUSTRIAL,
        root="HG", exchange="CMX", listing_cycle=ALL_MONTHS,
        leader_ticker=None,    # Copper IS the industrial leader.
    ),
    CommodityInstrument(
        ticker="ALI=F", name="Aluminium", category=CommodityCategory.INDUSTRIAL,
        root="ALI", exchange="CMX", listing_cycle=ALL_MONTHS,
        leader_ticker="HG=F",
    ),

    # ── Energy ──────────────────────────────────────────────────────────
    CommodityInstrument(
        ticker="CL=F", name="WTI Crude", category=CommodityCategory.ENERGY,
        root="CL", exchange="NYM", listing_cycle=ALL_MONTHS,
        leader_ticker=None,    # WTI IS the energy leader.
    ),
    CommodityInstrument(
        ticker="BZ=F", name="Brent Crude", category=CommodityCategory.ENERGY,
        root="BZ", exchange="NYM", listing_cycle=ALL_MONTHS,
        leader_ticker="CL=F",
    ),
    CommodityInstrument(
        ticker="NG=F", name="Natural Gas", category=CommodityCategory.ENERGY,
        root="NG", exchange="NYM", listing_cycle=ALL_MONTHS,
        leader_ticker="CL=F",
    ),
    CommodityInstrument(
        ticker="HO=F", name="Heating Oil", category=CommodityCategory.ENERGY,
        root="HO", exchange="NYM", listing_cycle=ALL_MONTHS,
        leader_ticker="CL=F",
    ),
    CommodityInstrument(
        ticker="RB=F", name="RBOB Gasoline", category=CommodityCategory.ENERGY,
        root="RB", exchange="NYM", listing_cycle=ALL_MONTHS,
        leader_ticker="CL=F",
    ),

    # ── Agricultural ────────────────────────────────────────────────────
    CommodityInstrument(
        ticker="ZC=F", name="Corn", category=CommodityCategory.AGRICULTURAL,
        root="ZC", exchange="CBT", listing_cycle=GRAINS_CYCLE,
        leader_ticker=None,
    ),
    CommodityInstrument(
        ticker="ZS=F", name="Soybeans", category=CommodityCategory.AGRICULTURAL,
        root="ZS", exchange="CBT", listing_cycle=SOYBEAN_CYCLE,
        leader_ticker="ZC=F",
    ),
    CommodityInstrument(
        ticker="ZW=F", name="Wheat", category=CommodityCategory.AGRICULTURAL,
        root="ZW", exchange="CBT", listing_cycle=GRAINS_CYCLE,
        leader_ticker="ZC=F",
    ),
    CommodityInstrument(
        ticker="ZL=F", name="Soybean Oil", category=CommodityCategory.AGRICULTURAL,
        root="ZL", exchange="CBT", listing_cycle=SOYBEAN_CYCLE,
        leader_ticker="ZS=F",
    ),
    CommodityInstrument(
        ticker="ZM=F", name="Soybean Meal", category=CommodityCategory.AGRICULTURAL,
        root="ZM", exchange="CBT", listing_cycle=SOYBEAN_CYCLE,
        leader_ticker="ZS=F",
    ),
    CommodityInstrument(
        ticker="KC=F", name="Coffee", category=CommodityCategory.AGRICULTURAL,
        root="KC", exchange="NYB", listing_cycle=COFFEE_SUGAR_CYCLE,
        leader_ticker=None,
    ),
    CommodityInstrument(
        ticker="SB=F", name="Sugar", category=CommodityCategory.AGRICULTURAL,
        root="SB", exchange="NYB", listing_cycle=COFFEE_SUGAR_CYCLE,
        leader_ticker=None,
    ),
    CommodityInstrument(
        ticker="CT=F", name="Cotton", category=CommodityCategory.AGRICULTURAL,
        root="CT", exchange="NYB", listing_cycle=COTTON_CYCLE,
        leader_ticker=None,
    ),
    CommodityInstrument(
        ticker="CC=F", name="Cocoa", category=CommodityCategory.AGRICULTURAL,
        root="CC", exchange="NYB", listing_cycle=COCOA_CYCLE,
        leader_ticker=None,
    ),

    # ── Livestock ───────────────────────────────────────────────────────
    CommodityInstrument(
        ticker="LE=F", name="Live Cattle", category=CommodityCategory.LIVESTOCK,
        root="LE", exchange="CME", listing_cycle=LIVE_CATTLE_CYCLE,
        leader_ticker=None,
    ),
    CommodityInstrument(
        ticker="HE=F", name="Lean Hogs", category=CommodityCategory.LIVESTOCK,
        root="HE", exchange="CME", listing_cycle=LEAN_HOG_CYCLE,
        leader_ticker="LE=F",
    ),
    CommodityInstrument(
        ticker="GF=F", name="Feeder Cattle", category=CommodityCategory.LIVESTOCK,
        root="GF", exchange="CME", listing_cycle=FEEDER_CATTLE_CYCLE,
        leader_ticker="LE=F",
    ),
)


def by_ticker(ticker: str) -> CommodityInstrument | None:
    """Lookup helper. None if not in the universe."""
    for instr in COMMODITY_UNIVERSE:
        if instr.ticker == ticker:
            return instr
    return None


def by_category(category: CommodityCategory) -> tuple[CommodityInstrument, ...]:
    """Return all instruments in a category, in declared order."""
    return tuple(i for i in COMMODITY_UNIVERSE if i.category == category)


def all_tickers() -> tuple[str, ...]:
    """All commodity tickers — used by the loader to fetch the panel."""
    return tuple(i.ticker for i in COMMODITY_UNIVERSE)
