#!/usr/bin/env python3
"""
scripts/run_bb_ride_backtest.py — BB Upper Band Ride Momentum Backtest

Walk-forward validated backtest for BB(1σ) upper band momentum continuation.
Entry: First touch of BB upper band with quality filters.
Exit: Parameterized (drop below upper, mid-band break, trailing stop, PT).

Includes:
  - Parameter sweep: BB period, std dev, exit rules, hold limits
  - VIX regime segmentation (from H1: VIX dominates everything)
  - Sector RS enrichment (from H2: CYCLICAL + LEADING = best momentum)
  - Walk-forward: 18mo train / 6mo test, rolling

Usage:
    python3 scripts/run_bb_ride_backtest.py --years 7 --stocks 50
    python3 scripts/run_bb_ride_backtest.py --years 5 --stocks 30 --sweep
"""
import argparse, logging, os, sys, time, itertools
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()
import numpy as np, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("bb_ride_bt")

# ══════════════════════════════════════════════════════════════════════════════
# STOCK UNIVERSE
# ══════════════════════════════════════════════════════════════════════════════

def get_stock_list(n=50):
    try:
        from modules.index_constituents import get_nifty100
        stocks = get_nifty100()
        if stocks and len(stocks) >= 20:
            return stocks[:n]
    except Exception:
        pass
    return [
        "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "BHARTIARTL",
        "SBIN", "ITC", "HINDUNILVR", "LT", "KOTAKBANK", "HCLTECH",
        "AXISBANK", "ASIANPAINT", "MARUTI", "BAJFINANCE", "TATAMOTORS",
        "SUNPHARMA", "TITAN", "ULTRACEMCO", "WIPRO", "NESTLEIND",
        "POWERGRID", "NTPC", "M&M", "TATASTEEL", "JSWSTEEL", "ADANIPORTS",
        "BAJAJFINSV", "TECHM", "INDUSINDBK", "DIVISLAB", "DRREDDY",
        "ONGC", "COALINDIA", "GRASIM", "CIPLA", "APOLLOHOSP",
        "EICHERMOT", "HINDALCO", "BPCL", "TATACONSUM", "HEROMOTOCO",
        "PIDILITIND", "BRITANNIA", "GODREJCP", "DABUR", "BERGEPAINT",
        "ABB", "BOSCHLTD",
    ][:n]

# Sector type mapping for RS enrichment
_SECTOR_TYPE = {
    "RELIANCE": "CYCLICAL", "TCS": "DEFENSIVE", "HDFCBANK": "CYCLICAL",
    "INFY": "DEFENSIVE", "ICICIBANK": "CYCLICAL", "BHARTIARTL": "DEFENSIVE",
    "SBIN": "CYCLICAL", "ITC": "DEFENSIVE", "HINDUNILVR": "DEFENSIVE",
    "LT": "CYCLICAL", "KOTAKBANK": "CYCLICAL", "HCLTECH": "DEFENSIVE",
    "AXISBANK": "CYCLICAL", "ASIANPAINT": "DEFENSIVE", "MARUTI": "CYCLICAL",
    "BAJFINANCE": "CYCLICAL", "TATAMOTORS": "CYCLICAL", "SUNPHARMA": "DEFENSIVE",
    "TITAN": "CYCLICAL", "ULTRACEMCO": "CYCLICAL", "WIPRO": "DEFENSIVE",
    "NESTLEIND": "DEFENSIVE", "POWERGRID": "DEFENSIVE", "NTPC": "CYCLICAL",
    "M&M": "CYCLICAL", "TATASTEEL": "CYCLICAL", "JSWSTEEL": "CYCLICAL",
    "ADANIPORTS": "CYCLICAL", "BAJAJFINSV": "CYCLICAL", "TECHM": "DEFENSIVE",
    "INDUSINDBK": "CYCLICAL", "DIVISLAB": "DEFENSIVE", "DRREDDY": "DEFENSIVE",
    "ONGC": "CYCLICAL", "COALINDIA": "CYCLICAL", "GRASIM": "CYCLICAL",
    "CIPLA": "DEFENSIVE", "APOLLOHOSP": "DEFENSIVE", "EICHERMOT": "CYCLICAL",
    "HINDALCO": "CYCLICAL", "BPCL": "CYCLICAL", "TATACONSUM": "DEFENSIVE",
    "HEROMOTOCO": "CYCLICAL", "PIDILITIND": "DEFENSIVE", "BRITANNIA": "DEFENSIVE",
    "GODREJCP": "DEFENSIVE", "DABUR": "DEFENSIVE", "BERGEPAINT": "DEFENSIVE",
    "ABB": "CYCLICAL", "BOSCHLTD": "CYCLICAL",
    # extras
    "BEL": "CYCLICAL", "HAL": "CYCLICAL", "BANKBARODA": "CYCLICAL",
    "IOC": "CYCLICAL", "CGPOWER": "CYCLICAL", "AMBUJACEM": "CYCLICAL",
    "INDIGO": "CYCLICAL", "CUMMINSIND": "CYCLICAL",
}


def fetch_daily(symbol, years=7):
    import yfinance as yf
    try:
        ticker = symbol if symbol.startswith("^") else f"{symbol}.NS"
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", symbol, exc)
        return pd.DataFrame()


# ══════════════════════════════════════════════════════════════════════════════
# INDICATOR COMPUTATION
# ══════════════════════════════════════════════════════════════════════════════

def compute_indicators(df, bb_period=20, bb_std=1.0):
    """Compute all indicators needed for the BB ride strategy."""
    c = df["Close"]; h = df["High"]; l = df["Low"]
    v = df["Volume"] if "Volume" in df.columns else pd.Series(0, index=df.index)

    d = df.copy()

    # BB bands
    mid = c.rolling(bb_period).mean()
    std = c.rolling(bb_period).std()
    d["BB_Mid"] = mid
    d["BB_Upper"] = mid + bb_std * std
    d["BB_Lower"] = mid - bb_std * std
    band = (d["BB_Upper"] - d["BB_Lower"]).replace(0, np.nan)
    d["BB_Pct"] = (c - d["BB_Lower"]) / band
    d["BBW"] = band / mid.replace(0, np.nan) * 100
    d["BBW_slope"] = d["BBW"].diff(5)

    # SMA variants for exit testing
    d["SMA_10"] = c.rolling(10).mean()
    d["SMA_20"] = mid  # same as BB mid for period=20
    d["SMA_50"] = c.rolling(50, min_periods=30).mean()

    # ATR for trailing stop
    tr = pd.concat([h-l, (h-c.shift(1)).abs(), (l-c.shift(1)).abs()], axis=1).max(axis=1)
    d["ATR"] = tr.rolling(14).mean()

    # Volume ratio
    vol_avg = v.rolling(20).mean().replace(0, np.nan)
    d["VOL_RATIO"] = v / vol_avg

    # RSI
    delta = c.diff()
    gain = delta.clip(lower=0); loss = -delta.clip(upper=0)
    ag = gain.rolling(14).mean(); al = loss.rolling(14).mean()
    with np.errstate(divide='ignore', invalid='ignore'):
        rs = np.where(al > 0, ag / al, 0)
        d["RSI"] = 100 - (100 / (1 + rs))

    # MFI
    tp = (h+l+c)/3; mf = tp*v
    pmf = pd.Series(np.where(tp>tp.shift(1), mf, 0), index=df.index)
    nmf = pd.Series(np.where(tp<tp.shift(1), mf, 0), index=df.index)
    with np.errstate(divide='ignore', invalid='ignore'):
        mfr = np.where(nmf.rolling(14).sum() > 0,
                       pmf.rolling(14).sum() / nmf.rolling(14).sum(), 0)
        d["MFI"] = 100 - (100 / (1 + mfr))

    # ADX
    up = h.diff(); dn = -l.diff()
    pdm = pd.Series(np.where((up>dn)&(up>0), up, 0), index=df.index)
    mdm = pd.Series(np.where((dn>up)&(dn>0), dn, 0), index=df.index)
    atr14 = d["ATR"]
    pdi = 100 * pdm.rolling(14).mean() / atr14.replace(0, np.nan)
    mdi = 100 * mdm.rolling(14).mean() / atr14.replace(0, np.nan)
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    d["ADX"] = dx.rolling(14).mean()

    # ROC
    d["ROC_10"] = c.pct_change(10) * 100

    # Relative strength vs Nifty (computed per-stock later if nifty available)
    d["RS_20d"] = c.pct_change(20) * 100

    return d


# ══════════════════════════════════════════════════════════════════════════════
# TRADE SIMULATION
# ══════════════════════════════════════════════════════════════════════════════

def simulate_trades(df, symbol, vix_series=None, nifty_rets=None, params=None):
    """
    Simulate BB ride trades with given parameters.

    Entry: Close >= BB_Upper (first touch after being below)
    Optional entry filters: min_vol, min_pctb, min_adx, vix_max, above_sma50
    Exit: Configurable — see params

    Returns list of trade dicts.
    """
    if params is None:
        params = {}

    # Extract parameters with defaults
    bb_period = params.get("bb_period", 20)
    bb_std = params.get("bb_std", 1.0)

    # Entry filters
    min_vol = params.get("min_vol", 0.0)        # minimum vol_ratio
    min_pctb = params.get("min_pctb", 1.0)      # minimum %B at entry
    min_adx = params.get("min_adx", 0)           # minimum ADX
    require_sma50 = params.get("require_sma50", False)  # must be above SMA50
    vix_max = params.get("vix_max", 999)         # max VIX for entry

    # Exit rules
    exit_rule = params.get("exit_rule", "mid_break")  # mid_break, upper_break, trailing, fixed
    trailing_atr = params.get("trailing_atr", 2.0)    # ATR multiplier for trailing stop
    profit_target = params.get("profit_target", 10.0)  # % profit target
    max_hold = params.get("max_hold", 30)              # max bars to hold
    stop_loss = params.get("stop_loss", -5.0)          # % stop loss

    # Compute indicators
    d = compute_indicators(df, bb_period, bb_std)

    c = d["Close"].values.astype(float)
    upper = d["BB_Upper"].values.astype(float)
    mid = d["BB_Mid"].values.astype(float)
    sma50 = d["SMA_50"].values.astype(float)
    atr = d["ATR"].values.astype(float)
    vol_ratio = d["VOL_RATIO"].values.astype(float)
    pctb = d["BB_Pct"].values.astype(float)
    adx = d["ADX"].values.astype(float)
    mfi = d["MFI"].values.astype(float)
    rsi = d["RSI"].values.astype(float)
    bbw = d["BBW"].values.astype(float)
    bbw_slope = d["BBW_slope"].values.astype(float)
    roc = d["ROC_10"].values.astype(float)
    rs_20d = d["RS_20d"].values.astype(float)
    dates = d.index

    trades = []
    was_below = True
    in_trade = False
    cooldown = 0

    for i in range(bb_period + 15, len(c) - 1):
        if np.isnan(upper[i]) or np.isnan(mid[i]):
            continue

        if cooldown > 0:
            cooldown -= 1
            continue

        at_upper = c[i] >= upper[i]

        # ── EXIT CHECK (if in trade) ──────────────────────────────
        if in_trade:
            pnl = (c[i] / entry_price - 1) * 100
            bars_held = i - entry_bar

            exited = False
            exit_reason = ""

            # Profit target
            if pnl >= profit_target:
                exited = True; exit_reason = "PT"

            # Stop loss
            elif pnl <= stop_loss:
                exited = True; exit_reason = "SL"

            # Max hold
            elif bars_held >= max_hold:
                exited = True; exit_reason = "MAX_HOLD"

            # Exit rules
            elif exit_rule == "mid_break" and c[i] < mid[i]:
                exited = True; exit_reason = "MID_BREAK"

            elif exit_rule == "upper_break" and c[i] < upper[i]:
                exited = True; exit_reason = "UPPER_BREAK"

            elif exit_rule == "trailing":
                peak = max(c[entry_bar:i+1])
                trail_stop = peak - trailing_atr * atr[i]
                if c[i] < trail_stop:
                    exited = True; exit_reason = "TRAIL_STOP"

            elif exit_rule == "sma10_break":
                sma10 = d["SMA_10"].values[i]
                if not np.isnan(sma10) and c[i] < sma10:
                    exited = True; exit_reason = "SMA10_BREAK"

            if exited:
                exit_price = c[i]
                final_pnl = (exit_price / entry_price - 1) * 100
                peak_price = max(c[entry_bar:i+1])
                max_gain = (peak_price / entry_price - 1) * 100

                # VIX at entry
                entry_vix = None
                if vix_series is not None:
                    vix_idx = vix_series.index.get_indexer([dates[entry_bar]], method="ffill")
                    if vix_idx[0] >= 0:
                        entry_vix = float(vix_series.iloc[vix_idx[0]])

                # Nifty relative return
                nifty_ret = None
                if nifty_rets is not None:
                    try:
                        nr = nifty_rets.loc[dates[entry_bar]:dates[i]]
                        if len(nr) > 0:
                            nifty_ret = float(nr.sum())
                    except:
                        pass

                # Sector type
                sec_type = _SECTOR_TYPE.get(symbol, "UNKNOWN")

                # RS at entry (20d return vs nifty)
                rs_val = rs_20d[entry_bar] if not np.isnan(rs_20d[entry_bar]) else 0

                trades.append({
                    "symbol": symbol,
                    "entry_date": str(dates[entry_bar].date()),
                    "exit_date": str(dates[i].date()),
                    "entry_price": round(entry_price, 2),
                    "exit_price": round(exit_price, 2),
                    "pnl_pct": round(final_pnl, 3),
                    "max_gain": round(max_gain, 2),
                    "bars_held": bars_held,
                    "exit_reason": exit_reason,
                    "win": final_pnl > 0,
                    # Entry conditions
                    "entry_pctb": round(entry_pctb, 3),
                    "entry_vol": round(entry_vol, 2),
                    "entry_mfi": round(entry_mfi, 1),
                    "entry_rsi": round(entry_rsi, 1),
                    "entry_adx": round(entry_adx, 1),
                    "entry_bbw": round(entry_bbw, 2),
                    "entry_bbw_slope": round(entry_bbw_slope, 2),
                    "entry_roc": round(entry_roc, 1),
                    # Context
                    "vix": round(entry_vix, 1) if entry_vix else None,
                    "vix_regime": _vix_regime(entry_vix) if entry_vix else "UNKNOWN",
                    "sector_type": sec_type,
                    "rs_20d": round(rs_val, 2),
                    "rs_bucket": "LEADING" if rs_val > 2 else ("LAGGING" if rs_val < -2 else "INLINE"),
                    "nifty_ret": round(nifty_ret, 2) if nifty_ret else None,
                })

                in_trade = False
                was_below = c[i] < upper[i]
                cooldown = 2  # avoid re-entry on same bar
                continue

        # ── ENTRY CHECK ───────────────────────────────────────────
        if not in_trade and was_below and at_upper:
            # Apply entry filters
            if vol_ratio[i] < min_vol:
                was_below = False; continue
            if pctb[i] < min_pctb:
                was_below = False; continue
            if adx[i] < min_adx:
                was_below = False; continue
            if require_sma50 and (np.isnan(sma50[i]) or c[i] < sma50[i]):
                was_below = False; continue

            # VIX filter
            if vix_series is not None:
                vix_idx = vix_series.index.get_indexer([dates[i]], method="ffill")
                if vix_idx[0] >= 0:
                    v_val = float(vix_series.iloc[vix_idx[0]])
                    if v_val > vix_max:
                        was_below = False; continue

            # ENTRY
            entry_price = c[i]
            entry_bar = i
            entry_pctb = pctb[i] if not np.isnan(pctb[i]) else 1.0
            entry_vol = vol_ratio[i] if not np.isnan(vol_ratio[i]) else 1.0
            entry_mfi = mfi[i] if not np.isnan(mfi[i]) else 50
            entry_rsi = rsi[i] if not np.isnan(rsi[i]) else 50
            entry_adx = adx[i] if not np.isnan(adx[i]) else 20
            entry_bbw = bbw[i] if not np.isnan(bbw[i]) else 5
            entry_bbw_slope = bbw_slope[i] if not np.isnan(bbw_slope[i]) else 0
            entry_roc = roc[i] if not np.isnan(roc[i]) else 0
            in_trade = True
            was_below = False

        elif not at_upper:
            was_below = True

    return trades


def _vix_regime(v):
    if v is None: return "UNKNOWN"
    if v > 25: return "PANIC"
    if v >= 20: return "ELEVATED"
    if v >= 13: return "NORMAL"
    return "LOW"


# ══════════════════════════════════════════════════════════════════════════════
# PARAMETER SWEEP
# ══════════════════════════════════════════════════════════════════════════════

def default_params():
    return {
        "bb_period": 20, "bb_std": 1.0,
        "min_vol": 0.0, "min_pctb": 1.0, "min_adx": 0,
        "require_sma50": False, "vix_max": 999,
        "exit_rule": "mid_break",
        "trailing_atr": 2.0, "profit_target": 10.0,
        "max_hold": 30, "stop_loss": -5.0,
    }


def sweep_configs():
    """Generate parameter combinations for sweep."""
    configs = []

    # Base: vary exit rule (most impactful)
    for exit_rule in ["mid_break", "upper_break", "trailing", "sma10_break"]:
        p = default_params()
        p["exit_rule"] = exit_rule
        configs.append(("exit_" + exit_rule, p))

    # PT sweep
    for pt in [5, 8, 10, 15]:
        p = default_params()
        p["profit_target"] = pt
        configs.append((f"pt_{pt}", p))

    # SL sweep
    for sl in [-3, -5, -8, -10]:
        p = default_params()
        p["stop_loss"] = sl
        configs.append((f"sl_{sl}", p))

    # Max hold sweep
    for mh in [10, 15, 20, 30, 45]:
        p = default_params()
        p["max_hold"] = mh
        configs.append((f"hold_{mh}", p))

    # Entry filter combos
    for mv in [0, 1.0, 1.3]:
        for mpb in [1.0, 1.05, 1.1]:
            p = default_params()
            p["min_vol"] = mv; p["min_pctb"] = mpb
            configs.append((f"vol{mv}_pctb{mpb}", p))

    # SMA50 filter
    p = default_params()
    p["require_sma50"] = True
    configs.append(("sma50_required", p))

    # VIX ceiling
    for vm in [15, 18, 25]:
        p = default_params()
        p["vix_max"] = vm
        configs.append((f"vix_max_{vm}", p))

    # Trailing stop ATR multipliers
    for ta in [1.5, 2.0, 2.5, 3.0]:
        p = default_params()
        p["exit_rule"] = "trailing"; p["trailing_atr"] = ta
        configs.append((f"trail_{ta}atr", p))

    # BB period/std variations
    for bp in [15, 20, 25]:
        for bs in [0.8, 1.0, 1.2]:
            p = default_params()
            p["bb_period"] = bp; p["bb_std"] = bs
            configs.append((f"bb{bp}_{bs}s", p))

    return configs


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def analyze_trades(trades_df, label=""):
    """Compute performance metrics for a set of trades."""
    if len(trades_df) == 0:
        return {"label": label, "n": 0}

    pnl = trades_df["pnl_pct"]
    wins = pnl > 0
    n = len(pnl)
    wr = wins.mean() * 100
    avg = pnl.mean()
    med = pnl.median()
    std = pnl.std()
    sharpe = avg / std * np.sqrt(252 / 15) if std > 0 else 0
    pf = pnl[wins].sum() / abs(pnl[~wins].sum()) if (~wins).any() and pnl[~wins].sum() != 0 else 99

    return {
        "label": label, "n": n, "win_rate": round(wr, 1),
        "avg_pnl": round(avg, 3), "med_pnl": round(med, 3),
        "sharpe": round(sharpe, 2), "profit_factor": round(pf, 2),
        "avg_bars": round(trades_df["bars_held"].mean(), 1),
    }


def full_analysis(trades_df):
    """Run comprehensive analysis on trade results."""
    N = len(trades_df)
    if N == 0:
        print("  No trades to analyze.")
        return

    # ── Overall ───────────────────────────────────────────────────
    print(f"\n  Total trades: {N}")
    stats = analyze_trades(trades_df, "Overall")
    print(f"  Win rate: {stats['win_rate']:.1f}%  Avg: {stats['avg_pnl']:+.3f}%  "
          f"Med: {stats['med_pnl']:+.3f}%  Sharpe: {stats['sharpe']:.2f}  "
          f"PF: {stats['profit_factor']:.2f}  Avg bars: {stats['avg_bars']:.1f}")

    # ── Exit reason breakdown ─────────────────────────────────────
    print(f"\n  Exit reason breakdown:")
    for er in trades_df["exit_reason"].unique():
        sub = trades_df[trades_df["exit_reason"]==er]
        s = analyze_trades(sub, er)
        print(f"    {er:15s}: N={s['n']:5d}  W={s['win_rate']:5.1f}%  Avg={s['avg_pnl']:+.3f}%")

    # ── VIX regime ────────────────────────────────────────────────
    print(f"\n  VIX regime:")
    for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC", "UNKNOWN"]:
        sub = trades_df[trades_df["vix_regime"]==vr]
        if len(sub) < 10: continue
        s = analyze_trades(sub, vr)
        print(f"    {vr:10s}: N={s['n']:5d}  W={s['win_rate']:5.1f}%  Avg={s['avg_pnl']:+.3f}%  Sh={s['sharpe']:+.2f}")

    # ── Sector type ───────────────────────────────────────────────
    print(f"\n  Sector type:")
    for st in ["CYCLICAL", "DEFENSIVE", "UNKNOWN"]:
        sub = trades_df[trades_df["sector_type"]==st]
        if len(sub) < 10: continue
        s = analyze_trades(sub, st)
        print(f"    {st:10s}: N={s['n']:5d}  W={s['win_rate']:5.1f}%  Avg={s['avg_pnl']:+.3f}%  Sh={s['sharpe']:+.2f}")

    # ── RS bucket ─────────────────────────────────────────────────
    print(f"\n  Relative Strength (20d vs self):")
    for rs in ["LEADING", "INLINE", "LAGGING"]:
        sub = trades_df[trades_df["rs_bucket"]==rs]
        if len(sub) < 10: continue
        s = analyze_trades(sub, rs)
        print(f"    {rs:10s}: N={s['n']:5d}  W={s['win_rate']:5.1f}%  Avg={s['avg_pnl']:+.3f}%  Sh={s['sharpe']:+.2f}")

    # ── VIX × Sector type ────────────────────────────────────────
    print(f"\n  VIX × Sector (the money table):")
    for st in ["CYCLICAL", "DEFENSIVE"]:
        for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            sub = trades_df[(trades_df["sector_type"]==st) & (trades_df["vix_regime"]==vr)]
            if len(sub) < 15: continue
            s = analyze_trades(sub)
            tag = "★" if s["win_rate"] >= 60 and s["sharpe"] >= 1.0 else ""
            print(f"    {st:10s} {vr:10s}: N={s['n']:5d}  W={s['win_rate']:5.1f}%  "
                  f"Avg={s['avg_pnl']:+.3f}%  Sh={s['sharpe']:+.2f}  {tag}")

    # ── Factor correlations ──────────────────────────────────────
    print(f"\n  Factor correlations with PnL:")
    for f in ["entry_pctb", "entry_vol", "entry_mfi", "entry_rsi",
              "entry_adx", "entry_bbw", "entry_bbw_slope", "entry_roc"]:
        valid = trades_df[[f, "pnl_pct"]].dropna()
        if len(valid) < 30: continue
        r = valid[f].corr(valid["pnl_pct"])
        print(f"    {f:>18s}: r = {r:+.4f}  (N={len(valid)})")

    # ── Yearly breakdown ─────────────────────────────────────────
    trades_df = trades_df.copy()
    trades_df["year"] = pd.to_datetime(trades_df["entry_date"]).dt.year
    print(f"\n  Yearly breakdown:")
    print(f"  {'Year':>6s} {'N':>6s} {'Win%':>6s} {'Avg':>8s} {'Sharpe':>7s}")
    for yr in sorted(trades_df["year"].unique()):
        sub = trades_df[trades_df["year"]==yr]
        s = analyze_trades(sub)
        print(f"  {yr:6d} {s['n']:6d} {s['win_rate']:5.1f}% {s['avg_pnl']:+7.3f}% {s['sharpe']:+6.2f}")


def run_sweep(all_data, vix_series, nifty_rets, configs):
    """Run parameter sweep across all configs."""
    results = []

    for name, params in configs:
        all_trades = []
        for sym, df in all_data.items():
            trades = simulate_trades(df, sym, vix_series, nifty_rets, params)
            all_trades.extend(trades)

        if not all_trades:
            continue

        tdf = pd.DataFrame(all_trades)
        s = analyze_trades(tdf, name)
        s["params"] = str(params)
        results.append(s)

    return pd.DataFrame(results)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="BB Ride Momentum Backtest")
    parser.add_argument("--years", type=int, default=7, help="Years of data")
    parser.add_argument("--stocks", type=int, default=50, help="Number of stocks")
    parser.add_argument("--sweep", action="store_true", help="Run parameter sweep")
    parser.add_argument("--export", action="store_true", help="Export trades CSV")
    args = parser.parse_args()

    stocks = get_stock_list(args.stocks)
    logger.info("BB Ride Backtest: %d stocks, %d years", len(stocks), args.years)

    # Fetch VIX (3-tier fallback — ^INDIAVIX is unreliable on yfinance)
    logger.info("Fetching India VIX...")
    vix_series = pd.Series(dtype=float)
    for vix_ticker in ["^INDIAVIX", "INDIAVIX", "^NSEIVX"]:
        try:
            vix_df = fetch_daily(vix_ticker, args.years)
            if vix_df is not None and not vix_df.empty and "Close" in vix_df.columns:
                vs = vix_df["Close"].dropna()
                if len(vs) >= 50:
                    vix_series = vs
                    logger.info("VIX: %d bars from %s", len(vix_series), vix_ticker)
                    break
        except Exception as exc:
            logger.debug("VIX ticker %s failed: %s", vix_ticker, exc)
    if vix_series.empty:
        logger.warning("VIX unavailable — proceeding without VIX segmentation")

    # Fetch Nifty for relative strength
    logger.info("Fetching Nifty 50...")
    nifty_rets = pd.Series(dtype=float)
    for nifty_ticker in ["^NSEI", "^NIFTY", "NIFTYBEES"]:
        try:
            nifty_df = fetch_daily(nifty_ticker, args.years)
            if nifty_df is not None and not nifty_df.empty and "Close" in nifty_df.columns:
                nr = nifty_df["Close"].pct_change() * 100
                if len(nr.dropna()) >= 50:
                    nifty_rets = nr
                    logger.info("Nifty: %d bars from %s", len(nr.dropna()), nifty_ticker)
                    break
        except Exception as exc:
            logger.debug("Nifty ticker %s failed: %s", nifty_ticker, exc)
    if nifty_rets.empty:
        logger.warning("Nifty unavailable — RS will use stock-only 20d return")

    # Fetch all stocks
    all_data = {}
    failed = 0
    for i, sym in enumerate(stocks):
        logger.info("  [%d/%d] %s", i+1, len(stocks), sym)
        df = fetch_daily(sym, args.years)
        if df is None or len(df) < 100:
            failed += 1
            continue
        all_data[sym] = df
        time.sleep(0.3)

    logger.info("\nLoaded %d stocks (%d failed)", len(all_data), failed)

    if not all_data:
        logger.error("No data loaded")
        return

    # ── Default run ───────────────────────────────────────────────
    logger.info("\n" + "="*70)
    logger.info("DEFAULT PARAMETERS — BB(20,1σ) mid-break exit")
    logger.info("="*70)

    params = default_params()
    all_trades = []
    for sym, df in all_data.items():
        trades = simulate_trades(df, sym, vix_series, nifty_rets, params)
        all_trades.extend(trades)

    if all_trades:
        tdf = pd.DataFrame(all_trades)
        full_analysis(tdf)

        if args.export:
            out = os.path.join("data", "backtest_results")
            os.makedirs(out, exist_ok=True)
            path = os.path.join(out, "bb_ride_trades.csv")
            tdf.to_csv(path, index=False)
            logger.info("Exported %d trades to %s", len(tdf), path)

    # ── Parameter sweep ──────────────────────────────────────────
    if args.sweep:
        logger.info("\n" + "="*70)
        logger.info("PARAMETER SWEEP")
        logger.info("="*70)

        configs = sweep_configs()
        logger.info("Testing %d configurations...", len(configs))

        sweep_df = run_sweep(all_data, vix_series, nifty_rets, configs)

        if not sweep_df.empty:
            # Sort by Sharpe
            sweep_df = sweep_df.sort_values("sharpe", ascending=False)
            print(f"\n  TOP 20 CONFIGURATIONS BY SHARPE:")
            print(f"  {'Config':>25s} {'N':>6s} {'Win%':>6s} {'Avg':>8s} {'Sharpe':>7s} {'PF':>5s} {'Bars':>5s}")
            for _, r in sweep_df.head(20).iterrows():
                print(f"  {r['label']:>25s} {r['n']:6.0f} {r['win_rate']:5.1f}% "
                      f"{r['avg_pnl']:+7.3f}% {r['sharpe']:+6.2f} {r['profit_factor']:4.2f} {r['avg_bars']:4.1f}")

            # Export sweep results
            if args.export:
                path = os.path.join("data", "backtest_results", "bb_ride_sweep.csv")
                sweep_df.to_csv(path, index=False)
                logger.info("Sweep results exported to %s", path)

    logger.info("\nDone.")


if __name__ == "__main__":
    main()
