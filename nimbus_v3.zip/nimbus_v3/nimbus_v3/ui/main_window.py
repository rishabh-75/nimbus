"""nimbus_v3.ui.main_window — top-level NIMBUS window (slim profile).

Layout
──────

    ┌────────────┬──────────────────────────────────────────────────┐
    │ Sidebar    │  QTabWidget                                       │
    │ (280 px)   │    Tab 0: Dashboard      (single-symbol cockpit)  │
    │            │    Tab 1: Market Pulse   (industry-wide context)  │
    └────────────┴──────────────────────────────────────────────────┘
    │ Status bar                                                     │
    └────────────────────────────────────────────────────────────────┘

Selection model
───────────────
- Sidebar drives the Dashboard tab only.
- Market Pulse runs independently — its own data loader is wired
  by ``main.py`` and triggered by ``showEvent``. Sidebar selection
  does not affect it.

Lazy providers
──────────────
The Options / Sector / VIX / Filing / NSE-client surfaces are
constructed on first need rather than at startup. ``main.py`` now
just hands MainWindow:
    - a ``DataManager`` (price + options workers)
    - a ``panel_loader`` callable that returns ``(panel, universe)``
      on demand
    - a ``compute_engine`` for per-symbol enrichment

MainWindow holds builders for the lazy pieces (``_OptionsBuilder``,
``_SectorBuilder``) and instantiates them on first hit.
"""
from __future__ import annotations

import logging
from typing import Callable, TYPE_CHECKING

import pandas as pd
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QHBoxLayout, QLabel, QMainWindow, QPushButton, QSizePolicy, QStatusBar,
    QTabWidget, QWidget,
)

from nimbus_v3.core.market_session import is_market_open
from nimbus_v3.core.universe import Universe
from nimbus_v3.data.data_manager import (
    DataManager, OptionsResult, PriceResult,
)
from nimbus_v3.ui.presenters import (
    build_industry_view,
)
from nimbus_v3.ui.sidebar import Sidebar
from nimbus_v3.ui.theme import (
    BORDER, EM, FONT_MONO, GOLD, GREEN, MUTED, QSS, S2, WHITE,
)
from nimbus_v3.ui.widgets.dashboard_tab import DashboardTab
from nimbus_v3.ui.widgets.market_pulse_tab import MarketPulseTab
from nimbus_v3.ui.widgets.rotation_tab import RotationTab
from nimbus_v3.data.watchlist import Watchlist


if TYPE_CHECKING:
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.context.options_context import OptionsContextProvider
    from nimbus_v3.core.context import OptionsContext


logger = logging.getLogger(__name__)


# Type aliases
PanelLoader = Callable[[], tuple[dict[str, pd.DataFrame], Universe | None]]
OptionsBuilder = Callable[[], "OptionsContextProvider | None"]


class MainWindow(QMainWindow):
    """NIMBUS main application window — Sidebar + 2-tab cockpit."""

    def __init__(
        self,
        *,
        compute_engine: "StrategyComputeEngine",
        panel_loader: PanelLoader,
        data_manager: DataManager | None = None,
        options_builder: OptionsBuilder | None = None,
        industry_map: dict[str, str] | None = None,
        company_map: dict[str, str] | None = None,
        auto_refresh_interval_sec: int = 0,
        parent=None,
    ) -> None:
        super().__init__(parent)

        self._compute = compute_engine
        self._panel_loader = panel_loader
        self._data_manager = data_manager
        self._options_builder = options_builder
        self._industry_map: dict[str, str] = industry_map or {}
        self._company_map: dict[str, str] = company_map or {}

        # Lazy state — populated on first ensure-loaded call.
        self._panel: dict[str, pd.DataFrame] = {}
        self._universe: Universe | None = None
        self._panel_loaded: bool = False
        #: Lazily built on first Market Pulse compute; caches 4h OHLCV for
        #: the Edge tab's 4h body-above flag. See _build_above_4h_map.
        self._intraday_loader = None
        #: True while the background 4h cache warmer is running (guards
        #: against launching more than one).
        self._warming_4h = False
        self._options_provider: "OptionsContextProvider | None" = None
        self._options_provider_built: bool = False

        # Single-symbol render state.
        self._current_symbol: str = ""
        self._current_enriched: pd.DataFrame | None = None
        self._current_options: "OptionsContext | None" = None
        self._last_price_fetched_at: pd.Timestamp | None = None
        self._last_options_fetched_at: pd.Timestamp | None = None
        self._last_eod_date: pd.Timestamp | None = None

        # Pre-classified ride cache — single source of truth shared
        # across the chart symbol's sidebar panel + the bottom-strip
        # tables. Built once in ``_ensure_panel`` after the panel
        # loads; refreshed in-place via ``update_symbol`` whenever
        # ``self._panel[sym]`` is replaced by a fresh fetch. Without
        # the in-place refresh the tables would show stale phases
        # for any symbol the user has loaded on the chart since the
        # initial panel snapshot.
        # ``industry_name → [member_symbols]`` derived from the
        # universe at panel-load time. Used to drive cache rebuilds.
        self._members_by_industry: dict[str, list[str]] = {}

        # Auto-refresh — 0 disables; positive value spins a QTimer.
        self._auto_refresh_interval_sec = max(0, int(auto_refresh_interval_sec))

        self.setWindowTitle("NIMBUS · Emerald Slate")
        # Size to a sensible default, but never exceed the available screen
        # (a child widget's sizeHint growing on tab-switch / sidebar-open was
        # pushing the window taller than the display, forcing a manual
        # resize). Clamp both the initial size and the maximum.
        self._fit_to_screen(1480, 900)
        self.setStyleSheet(QSS)

        # ── Build widgets ─────────────────────────────────────────────────
        # Sidebar's default symbol list comes from the industry DB —
        # NSE-equity universe only, no indices. The list is replaced
        # by the live universe once the panel loads.
        self._sidebar = Sidebar(
            default_symbols=sorted(self._industry_map.keys()),
        )
        self._dashboard_tab = DashboardTab()
        self._market_pulse_tab = MarketPulseTab()
        # Merged Market Pulse: Breadth (the MarketPulseTab widget) + ROC
        # + RRG + Seasonality sub-tabs, all under one top-level tab.
        self._rotation_tab = RotationTab(breadth_widget=self._market_pulse_tab)
        self._watchlist = Watchlist()

        # ── Sidebar | Tabs root layout ───────────────────────────────────
        # Tab 1: Dashboard (chart + industry/constituent strip).
        # Tab 2: Market Pulse (Breadth · ROC · RRG · Seasonality sub-tabs).
        # Tab 3: Watchlist (persisted symbols, constituent columns).
        self._tabs = QTabWidget()
        self._tabs.setTabPosition(QTabWidget.TabPosition.North)
        self._tabs.addTab(self._dashboard_tab, "Dashboard")
        self._tabs.addTab(self._rotation_tab, "Market Pulse")

        # ── Stop page content from dictating the WINDOW's minimum height ──
        # A QTabWidget's minimumSizeHint is the MAXIMUM over its pages, so
        # the tallest page pins the whole window — even while you're looking
        # at a different tab. Measured: the ROC sub-view accumulated a 784px
        # minimum hint from its stacked children, which pushed Market Pulse
        # to 844 and the window to a 931px FLOOR. On a laptop (~800-900px of
        # usable height) the window then physically cannot fit, and no amount
        # of dragging will make it.
        #
        # The fix is to give every page an explicit, small minimum height.
        # An explicit minimum OVERRIDES the accumulated hint, so a page's
        # internal content can no longer propagate a floor upward; it just
        # scrolls or compresses instead. This is applied at the page level
        # (rather than capping the window with setMaximumSize) because
        # capping the window fights the user — it left a dead gap at the
        # side and blocked maximising.
        for _i in range(self._tabs.count()):
            _page = self._tabs.widget(_i)
            _page.setMinimumHeight(0)
            _page.setSizePolicy(
                QSizePolicy.Policy.Expanding,
                QSizePolicy.Policy.Ignored,
            )
        # The sidebar collapse/expand chevron lives in the tab bar's left
        # corner, so there's no separate strip taking up space — the button
        # is always reachable but costs nothing when the sidebar is closed.
        self._sidebar_toggle = self._build_sidebar_toggle()
        self._tabs.setCornerWidget(
            self._sidebar_toggle, Qt.Corner.TopLeftCorner)

        central = QWidget()
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        # Sidebar sits directly beside the tabs; it starts COLLAPSED
        # (hidden) so the cockpit opens with maximum room for the tabs, and
        # the corner chevron brings it back when the symbol picker / breadth
        # panel is needed.
        layout.addWidget(self._sidebar)
        layout.addWidget(self._tabs, stretch=1)
        self.setCentralWidget(central)

        self._sidebar_collapsed = True
        self._sidebar.setVisible(False)
        self._sync_sidebar_toggle()

        # ── Status bar ────────────────────────────────────────────────────
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage("Ready. Pick a symbol from the sidebar.")
        self._freshness_label = QLabel("data: —")
        self._freshness_label.setStyleSheet(
            f"color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 9pt;"
            f" padding-right: 8px;"
        )
        self._status.addPermanentWidget(self._freshness_label)
        self._eod_label = QLabel("")
        self._eod_label.setStyleSheet(
            f"color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 9pt;"
            f" padding-right: 8px;"
        )
        self._status.addPermanentWidget(self._eod_label)

        # ── Signal wiring ─────────────────────────────────────────────────
        self._sidebar.symbol_changed.connect(self._on_sidebar_symbol_changed)
        self._sidebar.refresh_clicked.connect(self._on_sidebar_refresh)
        self._sidebar.generate_report_clicked.connect(
            self._on_generate_report)
        # Add-to-watchlist and the options-overlay toggle now live in the
        # DASHBOARD's chart toolbar (they are chart-level concerns), not the
        # sidebar. MainWindow still owns the persistence and the options
        # fetch — the toolbar only emits intent.
        self._dashboard_tab.add_to_watchlist.connect(
            self._on_add_to_watchlist)
        self._dashboard_tab.options_overlay_toggled.connect(
            self._on_options_overlay_toggled,
        )
        # The watchlist now lives as a collapsible panel beside the
        # Dashboard chart (TradingView-style) rather than in a tab of its
        # own. Persistence and add/remove decisions stay here; the panel is
        # pure display.
        self._dashboard_tab.watchlist_panel.symbol_activated.connect(
            self._on_watchlist_symbol_activated,
        )
        self._dashboard_tab.watchlist_panel.remove_requested.connect(
            self._on_watchlist_remove,
        )

        # Double-click on a Constituents row inside the Dashboard's
        # bottom strip → load that symbol on the chart. The Dashboard
        # bubbles the constituents-table activation up as its own
        # ``symbol_activated`` signal; we mirror it back to the
        # sidebar selection so combo + chart stay in sync.
        self._dashboard_tab.symbol_activated.connect(
            self._on_dashboard_symbol_activated,
        )

        # Double-click a constituent in the Seasonality contribution
        # table (inside Market Pulse) → open that symbol on the Dashboard.
        self._rotation_tab.symbol_activated.connect(
            self._on_rotation_symbol_activated,
        )

        if self._data_manager is not None:
            self._data_manager.price_ready.connect(self._on_price_ready)
            self._data_manager.options_ready.connect(self._on_options_ready)
            self._data_manager.load_failed.connect(self._on_load_failed)

        # Build menu (File → Quit).
        self._build_menu()

        # ── Freshness ticker ──────────────────────────────────────────────
        self._freshness_timer = QTimer(self)
        self._freshness_timer.setInterval(3000)
        self._freshness_timer.timeout.connect(self._tick_freshness_display)
        self._freshness_timer.start()

        # ── Auto-refresh ──────────────────────────────────────────────────
        if self._auto_refresh_interval_sec > 0:
            self._auto_refresh_timer = QTimer(self)
            self._auto_refresh_timer.setInterval(
                self._auto_refresh_interval_sec * 1000
            )
            self._auto_refresh_timer.timeout.connect(self._try_auto_refresh)
            self._auto_refresh_timer.start()
            logger.info(
                "Auto-refresh enabled: every %ds during NSE market hours",
                self._auto_refresh_interval_sec,
            )
        else:
            self._auto_refresh_timer = None

    # ══════════════════════════════════════════════════════════════════════
    # Collapsible sidebar
    # ══════════════════════════════════════════════════════════════════════

    def _build_sidebar_toggle(self) -> QPushButton:
        """The collapse/expand button, mounted in the tab bar's left corner
        so it costs no dedicated space. Sized to match the tab-bar height
        and labelled with a </> glyph."""
        btn = QPushButton("</>")
        btn.setFixedWidth(52)
        btn.setMinimumHeight(40)     # match the ~40px tab-bar height
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setToolTip("Show sidebar")
        btn.setStyleSheet(
            f"QPushButton {{ background: {S2}; color: {MUTED}; "
            f"border: 1px solid {BORDER}; border-radius: 4px; "
            f"margin: 3px 12px 3px 6px; padding: 0; "
            f"font-family: '{FONT_MONO}'; font-size: 13pt; "
            f"font-weight: bold; }}"
            f"QPushButton:hover {{ color: {WHITE}; border-color: {EM}; }}")
        btn.clicked.connect(self._toggle_sidebar)
        return btn

    def _toggle_sidebar(self) -> None:
        """Flip the sidebar between collapsed (hidden) and expanded."""
        self._sidebar_collapsed = not self._sidebar_collapsed
        self._sidebar.setVisible(not self._sidebar_collapsed)
        self._sync_sidebar_toggle()

    def _sync_sidebar_toggle(self) -> None:
        """Keep the </> glyph constant; only the tooltip reflects whether
        the next click shows or hides the sidebar."""
        collapsed = self._sidebar_collapsed
        self._sidebar_toggle.setToolTip(
            "Show sidebar" if collapsed else "Hide sidebar")

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def auto_load_initial(self, symbol: str = "RELIANCE") -> None:
        """Schedule the initial symbol load (default ``RELIANCE``).

        Default chosen because yfinance fetches it cleanly under
        ``.NS`` suffix; NSE indices like NIFTY don't (404) and are
        no longer in the tradeable universe.

        Also kicks off the panel load (idempotent — if main.py
        prewarmed the closure cache, this is a fast hit). The panel
        feeds the Industries / Constituents tables in the
        Dashboard's bottom strip, so we want it populated as soon
        as the operator first lays eyes on the screen, not lazily
        on first click.

        Deferred via ``QTimer.singleShot(0, ...)`` so the window has a
        chance to show before any blocking work begins. Called by
        ``main.py`` after :meth:`show`.
        """
        if not symbol:
            return
        self._sidebar.set_selected_symbol(symbol)

        def _kickoff() -> None:
            self._ensure_panel()    # populates dashboard tables
            self._load_symbol(symbol)
        QTimer.singleShot(0, _kickoff)

    # ══════════════════════════════════════════════════════════════════════
    # Lazy panel + provider getters
    # ══════════════════════════════════════════════════════════════════════

    def _ensure_panel(self) -> None:
        """Load the panel + universe on first need."""
        if self._panel_loaded:
            return
        try:
            panel, universe = self._panel_loader()
            self._panel = panel or {}
            self._universe = universe
            self._panel_loaded = True
            if universe is not None:
                self._sidebar.set_universe(universe)

            # Build the industry → members grouping from the universe.
            # Used both for the cache build and for incremental
            # ``update_symbol`` calls when fresh data lands. We group
            # at the third NSE classification level ("industry"),
            # matching what the Industries table renders.
            self._members_by_industry = {}
            if universe is not None:
                for sym, meta in universe.symbols.items():
                    if sym not in self._panel:
                        continue
                    ind = (
                        getattr(meta, "industry", None) or "Unknown"
                    ).strip() or "Unknown"
                    self._members_by_industry.setdefault(ind, []).append(sym)

            # Push the loaded panel + universe down to the Dashboard's
            # embedded tables. They compute Early-Entry scores
            # from the panel directly — no pre-built
            # classification pass needed.
            self._dashboard_tab.set_panel(self._panel, self._universe)
            self._push_breadth()
            self._refresh_watchlist_tab()
            logger.info(
                "panel loaded: %d symbols, universe=%s",
                len(self._panel),
                len(universe.symbols) if universe is not None else "none",
            )
            # The Market Pulse (rotation / RRG / seasonality / confluence)
            # compute is by far the heaviest startup work and would freeze
            # the window if run inline. The Dashboard is the default tab and
            # is already painted above, so defer the Market Pulse build to a
            # later event-loop tick: the window becomes interactive first,
            # and the rotation work finishes in the background before the
            # user is likely to switch to that tab.
            QTimer.singleShot(0, self._build_rotation_view)
        except Exception:    # noqa: BLE001
            logger.exception("panel_loader failed; continuing with empty panel")
            self._panel = {}
            self._universe = None
            self._members_by_industry = {}
            self._panel_loaded = True    # don't retry on every click

    def _build_rotation_view(self) -> None:
        """Build the Market Pulse (rotation / RRG / seasonality / confluence)
        view. Deferred from :meth:`_ensure_panel` to a later event-loop tick
        so the Dashboard paints and the window becomes interactive before
        this heavier compute runs. Idempotent-safe: does nothing without a
        loaded panel."""
        if not self._panel:
            return
        try:
            # CNX500 benchmark for the RRG sub-view (None-safe; the RRG
            # engine falls back to a synthetic mean benchmark if absent).
            benchmark_close = (
                self._data_manager.load_index("^CRSLDX")
                if self._data_manager is not None else None
            )
            self._rotation_tab.set_data(
                self._members_by_industry, self._panel,
                benchmark_close,
                regime=getattr(self, "_regime", None),
                market_breadth=getattr(self, "_market_breadth", None),
                above_4h_by_symbol=self._build_above_4h_map(cache_only=True),
            )
            # The build above used cache only (never blocks the GUI). Kick
            # off the actual 4h fetches on a worker thread; the Edge column
            # fills in when they land.
            self._warm_4h_cache_async()
        except Exception:    # noqa: BLE001
            logger.exception("rotation view build failed")

    def _build_above_4h_map(self, *, cache_only: bool = True) -> dict | None:
        """Best-effort 4h body-above flags for the panel's symbols.

        By default reads the SECONDARY 4h cache ONLY — never fetches — so it
        is safe to call on the GUI thread: a parquet read is fast and cannot
        hang the window, whereas 481 vendor fetches would freeze it. Returns
        ``{symbol: bool | None}``; symbols not yet cached come back ``None``
        and the Edge tab shows "?" for them until the background warmer fills
        the cache (see :meth:`_warm_4h_cache_async`).

        Entirely fail-soft: any problem returns ``None`` for the whole map
        rather than blocking or breaking the Market Pulse build. The daily
        board never depends on the 4h feed.
        """
        symbols = list(self._panel.keys())
        if not symbols:
            return None
        try:
            from nimbus_v3.data.intraday_flags import build_above_4h_map
            loader = self._ensure_intraday_loader()
            if loader is None:
                return None
            return build_above_4h_map(symbols, loader, cache_only=cache_only)
        except Exception:    # noqa: BLE001
            logger.exception("4h flag map build failed; column will be blank")
            return None

    def _ensure_intraday_loader(self):
        """Lazily construct the 4h loader (separate cache namespace)."""
        if getattr(self, "_intraday_loader", None) is None:
            try:
                from nimbus_v3.data.cache import ParquetCache
                from nimbus_v3.data.intraday_loader import IntradayLoader
                from nimbus_v3.data.paths import cache_dir
                self._intraday_loader = IntradayLoader(
                    ParquetCache(base_dir=cache_dir("equity_price_4h")))
            except Exception:    # noqa: BLE001
                logger.exception("could not construct 4h loader")
                return None
        return self._intraday_loader

    def _warm_4h_cache_async(self) -> None:
        """Populate the 4h cache OFF the GUI thread, then refresh the flags.

        The GUI-thread build is cache-only, so on a cold cache the 4h column
        is all "?" at first. This runs the actual vendor fetches on a worker
        thread; when done it re-emits the (now cache-warm) flag map back onto
        the GUI thread via a queued signal, and only the Edge tab's flags are
        updated — no recompute, since the flag is display-only.

        Idempotent: at most one warmer runs at a time.
        """
        if getattr(self, "_warming_4h", False):
            return
        symbols = list(self._panel.keys())
        loader = self._ensure_intraday_loader()
        if not symbols or loader is None:
            return
        self._warming_4h = True

        def _work():
            try:
                from nimbus_v3.data.intraday_flags import build_above_4h_map
                # Real fetches happen here, on the worker thread.
                build_above_4h_map(symbols, loader)
            except Exception:    # noqa: BLE001
                logger.exception("4h cache warm failed")
            finally:
                # Hand the refresh back to the GUI thread. QTimer.singleShot
                # with a 0 interval, posted from another thread, is delivered
                # on the GUI thread's event loop.
                QTimer.singleShot(0, self._on_4h_cache_warmed)

        import threading
        threading.Thread(target=_work, name="warm-4h-cache",
                         daemon=True).start()

    def _on_4h_cache_warmed(self) -> None:
        """GUI-thread callback: cache is warm, refresh the Edge 4h flags."""
        self._warming_4h = False
        if not self._panel:
            return
        try:
            flags = self._build_above_4h_map(cache_only=True)
            self._rotation_tab.update_above_4h(flags)
        except Exception:    # noqa: BLE001
            logger.exception("4h flag refresh after warm failed")

    def _ensure_options_provider(self) -> "OptionsContextProvider | None":
        """Build the options provider on first need."""
        if self._options_provider_built:
            return self._options_provider
        self._options_provider_built = True
        if self._options_builder is None:
            return None
        try:
            self._options_provider = self._options_builder()
        except Exception:    # noqa: BLE001
            logger.exception("options_builder failed; options will be unavailable")
            self._options_provider = None
        return self._options_provider

    def _push_breadth(self) -> None:
        """Compute universe-wide market breadth from the loaded panel
        and push the snapshot to the sidebar's MARKET BREADTH panel.

        Symbol-independent — called once when the panel loads (not per
        symbol). Cheap relative to the panel build; fail-soft so a
        breadth error never blocks the rest of the render.
        """
        if not self._panel:
            return
        try:
            from nimbus_v3.compute.breadth_regime import classify_regime
            from nimbus_v3.compute.market_breadth import (
                breadth_snapshot,
                compute_breadth,
            )
            self._breadth = compute_breadth(self._panel)
            index_close = (
                self._data_manager.load_index("^CRSLDX")
                if self._data_manager is not None else None
            )
            regime = classify_regime(self._breadth, index_close)
            self._regime = regime
            snap = breadth_snapshot(self._breadth)
            # Universe-wide breadth (fraction above SMA50) — the reference
            # the confluence breadth gate judges each industry against.
            self._market_breadth = (
                snap.pct_above_sma50 / 100.0
                if snap is not None and snap.pct_above_sma50 == snap.pct_above_sma50
                else None)
            self._sidebar.set_breadth(snap, regime)
            # Feed the Market Pulse tab: breadth panels + CNX500 overlay.
            self._market_pulse_tab.set_data(self._breadth, index_close)
        except Exception:    # noqa: BLE001
            logger.exception("breadth computation failed")
            self._sidebar.set_breadth(None)

    # ══════════════════════════════════════════════════════════════════════
    # Symbol load — async via DataManager when available, sync otherwise
    # ══════════════════════════════════════════════════════════════════════

    def _on_sidebar_symbol_changed(self, symbol: str) -> None:
        logger.debug("sidebar selection: %s", symbol)
        self._load_symbol(symbol)

    def _fit_to_screen(self, want_w: int, want_h: int) -> None:
        """Set the initial window size, clamped so it fits within the
        available screen area on launch (a large default like 1480×900
        would otherwise open taller than a laptop screen). Does NOT cap the
        maximum size — the user is free to widen, maximise, or move the
        window across monitors; we only pick a sane starting size."""
        from PyQt6.QtGui import QGuiApplication
        screen = self.screen() or QGuiApplication.primaryScreen()
        if screen is None:
            self.resize(want_w, want_h)
            return
        avail = screen.availableGeometry()
        margin = 60   # leave room for title bar / taskbar / dock
        w = min(want_w, max(800, avail.width() - margin))
        h = min(want_h, max(600, avail.height() - margin))
        self.resize(w, h)

    def _on_sidebar_refresh(self) -> None:
        sym = self._sidebar.current_symbol() or self._current_symbol
        if not sym:
            return
        self._load_symbol(sym, force_refresh=True)

    def _on_generate_report(self) -> None:
        """Build the Market Pulse research report and save it to disk."""
        from PyQt6.QtWidgets import QFileDialog, QMessageBox
        from datetime import datetime
        # Derive data freshness from the panel's most recent bar so the
        # report records when the underlying data was current.
        data_asof = None
        try:
            panel = getattr(self, "_panel", None)
            if panel:
                last_dates = [df.index[-1] for df in panel.values()
                              if df is not None and not df.empty]
                if last_dates:
                    data_asof = max(last_dates).strftime("%Y-%m-%d")
        except Exception:    # noqa: BLE001
            data_asof = None
        report = self._rotation_tab.build_report(data_asof=data_asof)
        if not report:
            QMessageBox.information(
                self, "Generate report",
                "No Market Pulse data yet — load a panel first (the report "
                "needs the rotation / confluence / edge results).")
            return
        default = datetime.now().strftime("nimbus_market_pulse_%Y%m%d_%H%M.md")
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Market Pulse report", default,
            "Markdown (*.md);;All files (*)")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(report)
            self.statusBar().showMessage(f"Report saved: {path}", 6000)
        except OSError as exc:
            QMessageBox.warning(
                self, "Generate report", f"Could not save report:\n{exc}")

    def _on_options_overlay_toggled(self, enabled: bool) -> None:
        """React to the sidebar options-overlay toggle.

        Turning it OFF immediately clears the current overlay so the
        display matches the no-options state. Turning it back ON
        reloads the current symbol so options fetch on the next pass.
        """
        if not enabled:
            self._current_options = None
            self._sidebar.set_options_context(None)
            self._render_current()
        elif self._current_symbol:
            self._load_symbol(self._current_symbol)

    # ── watchlist ───────────────────────────────────────────────────────────

    def _on_add_to_watchlist(self, symbol: str) -> None:
        if self._watchlist.add(symbol):
            self._status.showMessage(f"Added {symbol} to watchlist")
            self._refresh_watchlist_tab()
        else:
            self._status.showMessage(f"{symbol} already in watchlist")

    def _on_watchlist_remove(self, symbols: list) -> None:
        removed = [s for s in symbols if self._watchlist.remove(s)]
        if removed:
            self._status.showMessage(
                f"Removed {len(removed)} from watchlist: {', '.join(removed)}"
            )
            self._refresh_watchlist_tab()

    def _on_watchlist_symbol_activated(self, symbol: str) -> None:
        """Double-click in the watchlist → load that symbol into the
        Dashboard and switch focus to the Dashboard tab."""
        self._tabs.setCurrentWidget(self._dashboard_tab)
        self._sidebar.set_selected_symbol(symbol)
        self._load_symbol(symbol)

    def _on_rotation_symbol_activated(self, symbol: str) -> None:
        """Double-click a constituent in the Seasonality contribution
        table → load it on the Dashboard and switch focus there, same as
        the watchlist / scanner cross-tab behaviour."""
        self._tabs.setCurrentWidget(self._dashboard_tab)
        self._sidebar.set_selected_symbol(symbol)
        self._load_symbol(symbol)

    def _refresh_watchlist_tab(self) -> None:
        """Re-render the watchlist panel from the current panel.

        The panel shows only Symbol / Chg / Vol, so it needs nothing beyond
        the enriched frames — no universe, no riding map (those were fed to
        the old tab's full constituent table, which carried eleven columns).
        """
        self._dashboard_tab.watchlist_panel.set_data(
            self._watchlist.symbols(),
            self._panel,
        )

    def _on_dashboard_symbol_activated(self, symbol: str) -> None:
        """Double-click on a Constituents-table row → load that symbol.

        The Dashboard's bottom strip emits ``symbol_activated`` when
        the operator double-clicks a constituent row. We mirror it
        back to the sidebar so the combo agrees with what's loaded,
        then drive the standard load pathway. Same UX as a sidebar
        pick.
        """
        if not symbol:
            return
        logger.debug("dashboard activation: %s", symbol)
        self._sidebar.set_selected_symbol(symbol)
        self._load_symbol(symbol)

    def _load_symbol(self, symbol: str, *, force_refresh: bool = False) -> None:
        sym = (symbol or "").strip().upper()
        if not sym:
            return
        self._current_symbol = sym
        self._current_options = None
        self._current_enriched = None    # stale-mix guard: a failing
        # price feed on the new symbol would otherwise leave the
        # previous symbol's enriched frame visible behind fresh
        # options data.
        self._status.showMessage(f"Loading {sym}…")
        logger.info(
            "_load_symbol: %s (force_refresh=%s, dm=%s)",
            sym, force_refresh, self._data_manager is not None,
        )

        if self._data_manager is not None:
            self._data_manager.cancel_symbol(sym)
            cached_df = self._panel.get(sym)
            have_cache = cached_df is not None and not cached_df.empty

            # Stale-while-revalidate: if the panel already holds this
            # symbol's (enriched) data, render it IMMEDIATELY so the
            # chart + tables paint in ~100ms instead of waiting on a
            # yfinance round-trip.
            if have_cache:
                self._render_from_panel(sym, cached_df)

            # When to actually (re)fetch price:
            #   • force_refresh (sidebar REFRESH) — always.
            #   • no usable cache for this symbol — must fetch.
            #   • market is OPEN — fetch in the background to pick up
            #     intraday/post-close bar updates (non-blocking; the
            #     instant render above already happened).
            # When the market is CLOSED and we already have the
            # symbol cached, the panel built at startup is authoritative
            # for the whole session — there is nothing newer to get, so
            # we skip the fetch entirely. This avoids the redundant
            # PriceWorker → cache-hit → re-enrich → re-classify cycle on
            # every symbol click during off-hours.
            should_fetch = (
                force_refresh or not have_cache or is_market_open()
            )
            if should_fetch:
                self._data_manager.request_price(
                    sym, force_refresh=force_refresh,
                )
            # Options overlay is opt-in via the sidebar toggle. When
            # disabled we skip the options fetch entirely.
            if self._dashboard_tab.options_overlay_enabled():
                is_index = self._is_index_symbol(sym)
                self._data_manager.request_options(sym, is_index=is_index)
        else:
            # Pure-sync fallback: pull straight from the panel cache
            # (no live fetch, no options).
            self._ensure_panel()
            df = self._panel.get(sym)
            if df is None:
                self._status.showMessage(f"{sym}: not in loaded panel")
                self._dashboard_tab.clear()
                self._sidebar.clear()
                return
            self._render_from_panel(sym, df)

    def _on_price_ready(self, symbol: str, result: PriceResult) -> None:
        if symbol != self._current_symbol:
            return    # stale — operator moved on
        df = result.df
        if df is None or df.empty:
            self._status.showMessage(f"{symbol}: empty price result")
            # Still re-render so any previously-arrived options
            # context surfaces on screen rather than waiting for the
            # next event.
            self._render_current()
            return

        try:
            enriched = self._compute.enrich(df, symbol)
        except Exception as exc:    # noqa: BLE001
            logger.warning("enrich failed for %s: %s", symbol, exc)
            self._status.showMessage(f"{symbol}: enrichment failed ({exc})")
            self._render_current()
            return

        self._current_enriched = enriched
        self._last_price_fetched_at = result.fetched_at
        self._last_eod_date = (
            enriched.index[-1] if len(enriched) else None
        )
        # Slot the freshly enriched dataframe into the panel cache so
        # the Industries / Constituents tables read updated data on
        # their next render (without re-hitting yfinance).
        self._panel[symbol] = enriched

        # Re-push the panel to the dashboard so the bottom-strip tables
        # re-score with the updated bar. Cohort scoring is cheap and
        # stateless — no classification cache to refresh.
        self._dashboard_tab.set_panel(self._panel, self._universe)

        self._render_current()
        self._update_eod_label()

    def _on_options_ready(self, symbol: str, result: OptionsResult) -> None:
        if symbol != self._current_symbol:
            return
        provider = self._ensure_options_provider()
        if provider is None or result.chain is None or result.chain.empty:
            return
        try:
            ctx = provider.build(
                symbol=symbol, asof_date=pd.Timestamp.now().normalize(),
            )
        except Exception:    # noqa: BLE001
            logger.exception("options provider failed for %s", symbol)
            return
        self._current_options = ctx
        self._last_options_fetched_at = result.fetched_at
        self._render_current()

    def _on_load_failed(self, symbol: str, kind: str, error: str) -> None:
        if symbol != self._current_symbol:
            return
        logger.warning("load failed [%s] %s: %s", kind, symbol, error)
        self._status.showMessage(f"{symbol}: {kind} load failed — {error}")

    def _render_from_panel(self, symbol: str, df: pd.DataFrame) -> None:
        """Sync render path used when no DataManager is wired."""
        try:
            enriched = (
                df if self._is_already_enriched(df)
                else self._compute.enrich(df, symbol)
            )
        except Exception as exc:    # noqa: BLE001
            logger.warning("enrich failed for %s: %s", symbol, exc)
            self._status.showMessage(f"{symbol}: enrichment failed ({exc})")
            return
        self._current_enriched = enriched
        self._last_eod_date = enriched.index[-1] if len(enriched) else None
        self._render_current()
        self._update_eod_label()

    @staticmethod
    def _is_already_enriched(df: pd.DataFrame) -> bool:
        return "bb_20_1s_upper" in df.columns and "sma_20" in df.columns

    @staticmethod
    def _is_index_symbol(sym: str) -> bool:
        return sym in {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"}

    # ══════════════════════════════════════════════════════════════════════
    # Render
    # ══════════════════════════════════════════════════════════════════════

    def _render_current(self) -> None:
        """Render the dashboard from whatever artefacts are currently
        available.

        Partial-state safe: when a price feed fails (yfinance 404 on
        an index, network blip on a fresh symbol) but options have
        arrived, we still render the symbol header + Options Overlay
        panel + Industry Context. Operators see what works rather
        than a blank canvas, and a follow-up REFRESH can pick up the
        missing piece independently.
        """
        sym = self._current_symbol
        if not sym:
            self._dashboard_tab.clear()
            self._sidebar.clear()
            return

        enriched = self._current_enriched
        has_enriched = enriched is not None and not enriched.empty

        # Single-symbol ride classification — read from the cache
        # (single source of truth shared with the bottom-strip
        # tables). The cache was built in ``_ensure_panel`` and is
        # incrementally refreshed in ``_on_price_ready`` whenever
        # this symbol's data changes, so the lookup here always
        # reflects the latest enrichment.
        #
        # Classify from the ride cache — single source of truth.
        # The cache is built in ``_ensure_panel`` and refreshed in
        # ``_on_price_ready`` via ``update_symbol``. Any read for a
        # symbol whose price has been loaded MUST find a result here;
        # if it doesn't, that indicates a code-path bug (e.g. render
        # firing before panel build) and the right response is to
        # surface it via the em-dashed empty-state rather than silently
        # re-classify with a possibly-different enriched snapshot
        # (which is how the sidebar / constituents-table phase
        # mismatch was creeping in).
        # Industry membership for the Constituents auto-select.
        industry = self._industry_map.get(sym)
        member_count = 0
        if industry:
            self._ensure_panel()
            members_panel = self._collect_industry_panel(industry)
            member_count = len(members_panel)

        # Asof label. Empty when no enriched data — the dashboard
        # header shows the symbol with em-dashed spot/Δ.
        bar_dt = (
            enriched.index[-1] if has_enriched and len(enriched) else None
        )
        asof_label = self._format_asof_label(bar_dt)

        # Push view models to widgets.
        self._dashboard_tab.set_symbol(
            sym,
            enriched_df=enriched,
            options_ctx=self._current_options,
            industry=industry,
            company=self._company_map.get(sym, ""),
            member_count=member_count,
            asof_label=asof_label,
        )
        # The sidebar's former per-symbol KEY LEVELS panel is now the
        # universe-wide MARKET BREADTH panel — driven once at panel load
        # via _push_breadth(), not per symbol. So we no longer push a
        # per-symbol ride view here; the symbol's bands remain visible on
        # the chart.
        meta = (
            self._universe.symbols.get(sym)
            if self._universe is not None else None
        )
        self._sidebar.apply_industry_view(build_industry_view(meta))
        # Options Overlay panel was relocated from the (deleted)
        # Dashboard right-rail to the sidebar. Push the same context
        # down here — sidebar handles the empty-state path internally.
        self._sidebar.set_options_context(self._current_options)

        # Status: distinguish full vs partial render.
        if has_enriched:
            self._status.showMessage(f"{sym} loaded.")
        else:
            self._status.showMessage(
                f"{sym}: no price data — showing options + industry only."
            )

    def _collect_industry_panel(
        self, industry: str,
    ) -> dict[str, pd.DataFrame]:
        """Return ``{symbol: enriched_df}`` for every panel member in
        the same industry. Members without an enriched dataframe are
        skipped silently.
        """
        out: dict[str, pd.DataFrame] = {}
        for peer, peer_industry in self._industry_map.items():
            if peer_industry != industry:
                continue
            df = self._panel.get(peer)
            if df is None or df.empty:
                continue
            if not self._is_already_enriched(df):
                continue
            out[peer] = df
        return out

    @staticmethod
    def _format_asof_label(bar_dt: pd.Timestamp | None) -> str:
        """Describe the bar the analysis is standing on.

        The label used to read "live <date>" whenever the market happened
        to be open. That was already loose, and it became wrong once the
        loader started dropping the in-progress session bar: the panel now
        always holds the last COMPLETE session, so during Wednesday's
        session every number on screen is Tuesday's close.

        So the label describes the BAR, which is always a finished
        session, and separately notes when a session is currently running.
        An operator glancing at the header should never have to wonder
        whether a half-formed bar is feeding the ranking — it never is.
        """
        if bar_dt is None:
            return ""
        # e.g. "close Friday 19 Jun 2026" — weekday helps the operator
        # place the bar in the trading week at a glance.
        date_str = pd.Timestamp(bar_dt).strftime("%A %d %b %Y")
        label = f"close {date_str}"
        if is_market_open():
            label += " · session live"
        return label

    # ══════════════════════════════════════════════════════════════════════
    # Status-bar helpers
    # ══════════════════════════════════════════════════════════════════════

    def _tick_freshness_display(self) -> None:
        ages = []
        if self._last_price_fetched_at is not None:
            ages.append(("px", self._format_age(self._last_price_fetched_at)))
        if self._last_options_fetched_at is not None:
            ages.append(("opt", self._format_age(self._last_options_fetched_at)))
        self._freshness_label.setText(
            "data: " + (
                "  ".join(f"{k}={v}" for k, v in ages)
                if ages else "—"
            )
        )

    @staticmethod
    def _format_age(ts: pd.Timestamp | None) -> str:
        if ts is None:
            return "—"
        try:
            now = pd.Timestamp.now(tz=ts.tz) if ts.tz is not None else pd.Timestamp.now()
            age_s = max(0, int((now - ts).total_seconds()))
        except Exception:    # noqa: BLE001
            return "—"
        if age_s < 60:
            return f"{age_s}s"
        if age_s < 3600:
            return f"{age_s // 60}m"
        return f"{age_s // 3600}h"

    def _update_eod_label(self) -> None:
        if self._last_eod_date is None:
            self._eod_label.setText("")
            return
        dt = pd.Timestamp(self._last_eod_date)
        date_str = dt.strftime("%d %b %Y")
        if is_market_open():
            self._eod_label.setText(f"live {date_str}")
            self._eod_label.setStyleSheet(
                f"color: {GREEN}; font-family: '{FONT_MONO}'; font-size: 9pt;"
                f" padding-right: 8px;"
            )
            return
        # Stale-tier colouring.
        try:
            age_days = (pd.Timestamp.now().normalize() - dt.normalize()).days
        except Exception:    # noqa: BLE001
            age_days = 0
        color = WHITE if age_days <= 1 else (GOLD if age_days <= 7 else MUTED)
        self._eod_label.setText(f"close {date_str}")
        self._eod_label.setStyleSheet(
            f"color: {color}; font-family: '{FONT_MONO}'; font-size: 9pt;"
            f" padding-right: 8px;"
        )

    # ══════════════════════════════════════════════════════════════════════
    # Auto-refresh
    # ══════════════════════════════════════════════════════════════════════

    def _try_auto_refresh(self) -> None:
        if not is_market_open():
            return
        sym = self._current_symbol
        if not sym:
            return
        logger.debug("auto-refresh: re-requesting %s", sym)
        if self._data_manager is not None:
            self._data_manager.request_price(sym)
            self._data_manager.request_options(
                sym, is_index=self._is_index_symbol(sym),
            )

    # ══════════════════════════════════════════════════════════════════════
    # Menu / lifecycle
    # ══════════════════════════════════════════════════════════════════════

    def _build_menu(self) -> None:
        bar = self.menuBar()
        m_file = bar.addMenu("&File")
        a_quit = QAction("&Quit", self)
        a_quit.setShortcut("Ctrl+Q")
        a_quit.triggered.connect(self.close)
        m_file.addAction(a_quit)

    def closeEvent(self, event) -> None:    # noqa: N802 — Qt override
        if self._data_manager is not None:
            try:
                self._data_manager.cancel_all()
                self._data_manager.shutdown(timeout_ms=2000)
            except Exception:    # noqa: BLE001
                logger.exception("DataManager shutdown raised during close")
        super().closeEvent(event)
