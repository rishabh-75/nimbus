"""nimbus_v3.compute.early_entry — cohort-relative early-entry score.

Stateless. Replaces the retired phase/composite-score system (see
docs/retired/002). Encodes the desk's thesis: **enter as early as
possible in a fresh band-ride, prioritise the just-starting names over
the already-extended ones, while staying liquid enough to exit.**

Two layers:

1. :func:`extract_features` — per-symbol enrichment. Turns an enriched
   OHLCV frame into a flat :class:`EarlyEntryFeatures` (streak, recent
   return, ADTV, BBW). Pure per-symbol; no cohort needed.

2. :func:`score_cohort` — cohort-relative ranking. Min-max normalises
   each axis WITHIN the displayed cohort and combines them with fixed
   weights into a 0–100 score. The score is therefore relative to the
   scan: a symbol's number shifts as the cohort changes (by design —
   the question is "which of *these* are the earliest, healthiest
   entries", not an absolute rating).

Five axes:
  freshness 35%   inverted decaying streak (1/streak); fresh = high
  extension 25%   recent return inverted; already-run = low
  liquidity 15%   log ADTV with a floor; trap-thin = low
  coil 10%        inverted BBW; tight band = room to expand
  participation 15%   riders/members of the symbol's own industry, with
                      a size floor. ONLY meaningful in the ALL cohort
                      (in a single-industry view every row shares it, so
                      it's a constant and contributes nothing after
                      normalisation).

Nothing here is validated against forward returns — it is a thesis-based
ranking, not a backtested edge. Treat the score as "ranked by the
operator's entry philosophy", not "ranked by what historically paid".
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from nimbus_v3.compute.band_ride import body_above_streak
from nimbus_v3.compute.indicators import adtv_latest

# ── weights (sum to 1.0) ──────────────────────────────────────────────────────
# Freshness stays dominant (the "enter early" thesis), but liquidity is
# raised from 15 → 22 so genuinely thin names (clamped to the ADTV floor)
# are demoted harder, not just measured. The 7 points come from freshness
# (35→30, still the top axis) and coil (10→8, the lowest-conviction axis).
# Note: weight alone can't make "thin always ranks below liquid" — a thin
# name with strong freshness/extension still earns those points. This
# rebalance demotes thin names without distorting the multi-factor design;
# the ADTV column remains the operator's final eyeball gate.
W_FRESHNESS = 0.30
W_EXTENSION = 0.25
W_LIQUIDITY = 0.22
W_COIL = 0.08
W_PARTICIPATION = 0.15

#: Recent-return lookback (trading days) for the extension axis.
RETURN_LOOKBACK = 5

#: Industries with fewer than this many members get their participation
#: fraction damped toward neutral (0.5) — a 2/2 micro-industry shouldn't
#: read as max sector confirmation. Damping is linear in member count up
#: to the floor.
PARTICIPATION_SIZE_FLOOR = 5

#: ADTV (₹) clamp band for the liquidity axis. ADTV is clamped to
#: [floor, ceiling] BEFORE the log+min-max, so:
#:   - everything at/below the floor bottoms out together (thin names
#:     are simply "thin"; they take the same liquidity hit and are
#:     differentiated by the other axes, not by how thin they are);
#:   - everything at/above the ceiling tops out together (mega-cap
#:     outliers don't stretch the scale and swamp the tradeable-vs-
#:     comfortable distinction);
#:   - the resolution lives in the floor..ceiling band, where the
#:     meaningful liquidity differences actually sit.
#: Without the ceiling, min-max over the full universe stretches the
#: scale against ₹20,000M+ mega-caps, collapsing the thin-vs-tradeable
#: distinction into noise (the bug that let ₹164M names score alongside
#: ₹3,000M ones).
_ADTV_FLOOR = 1e9       # ₹1,000M
_ADTV_CEILING = 15e9    # ₹15,000M


@dataclass(frozen=True)
class EarlyEntryFeatures:
    """Per-symbol entry-time features (cohort-independent)."""

    symbol: str
    streak: int                 # trailing body-above-band bars
    recent_return: float        # RETURN_LOOKBACK-day % return
    adtv: float                 # ₹ average daily traded value (NaN ok)
    bbw: float                  # latest Bollinger band width (NaN ok)
    industry: str | None = None


def extract_features(
    symbol: str,
    df: pd.DataFrame,
    *,
    industry: str | None = None,
    lookback: int = RETURN_LOOKBACK,
) -> EarlyEntryFeatures:
    """Extract entry-time features from an enriched OHLCV frame.

    Fail-soft: missing columns / short frames yield neutral-ish values
    (streak 0, NaN return/adtv/bbw) rather than raising, so a thin
    symbol simply ranks low instead of breaking the cohort.
    """
    streak = body_above_streak(df)
    adtv = adtv_latest(df)

    recent_return = float("nan")
    if df is not None and not df.empty and "Close" in df.columns \
            and len(df) > lookback:
        c = df["Close"]
        prev = c.iloc[-1 - lookback]
        if prev and prev == prev and prev != 0:
            recent_return = float((c.iloc[-1] / prev - 1.0) * 100.0)

    bbw = float("nan")
    if df is not None and not df.empty and "bbw_20_1s" in df.columns:
        v = df["bbw_20_1s"].iloc[-1]
        if v == v:
            bbw = float(v)

    return EarlyEntryFeatures(
        symbol=symbol, streak=streak, recent_return=recent_return,
        adtv=adtv, bbw=bbw, industry=industry,
    )


def _minmax(vals: np.ndarray, *, invert: bool = False) -> np.ndarray:
    """Min-max to 0..1 across the cohort. NaN → 0.5 (neutral). A flat
    cohort (all equal) → 0.5 everywhere (no spurious separation)."""
    v = vals.astype(float)
    finite = v[np.isfinite(v)]
    if finite.size == 0:
        return np.full_like(v, 0.5)
    lo, hi = float(finite.min()), float(finite.max())
    if hi - lo < 1e-12:
        out = np.full_like(v, 0.5)
    else:
        out = (v - lo) / (hi - lo)
        out = np.where(np.isfinite(v), out, 0.5)
    return 1.0 - out if invert else out


def _participation(
    feats: list[EarlyEntryFeatures],
    industry_riding: dict[str, tuple[int, int]] | None,
) -> np.ndarray:
    """Per-symbol industry participation fraction (riders/members) with
    a size floor, returned as a 0..1 array aligned to ``feats``.

    ``industry_riding`` maps industry → (riders, members). When absent
    (single-industry cohort, or not supplied) every symbol gets 0.5 —
    neutral — so the axis contributes nothing after weighting.
    """
    if not industry_riding:
        return np.full(len(feats), 0.5)
    out = np.empty(len(feats), dtype=float)
    for i, f in enumerate(feats):
        rc = industry_riding.get(f.industry or "")
        if not rc or rc[1] <= 0:
            out[i] = 0.5
            continue
        riders, members = rc
        frac = riders / members
        # Damp toward neutral for sub-floor industries: a 2/2 (frac 1.0,
        # members 2) shouldn't read as full confirmation.
        if members < PARTICIPATION_SIZE_FLOOR:
            w = members / PARTICIPATION_SIZE_FLOOR
            frac = 0.5 + (frac - 0.5) * w
        out[i] = frac
    return out


def score_cohort(
    feats: list[EarlyEntryFeatures],
    *,
    industry_riding: dict[str, tuple[int, int]] | None = None,
) -> dict[str, float]:
    """Score the riders in the cohort 0–100, relative to the riders.

    Only symbols actually in a band-ride (``streak >= 1``) are scored —
    a symbol that isn't above the band has no early-entry to rank, so it
    is omitted from the result entirely (the table renders it blank).
    Normalisation is over the riders only, so the relative ranking isn't
    distorted by non-riders' returns/ADTV/BBW polluting the min-max
    scale.

    Args:
        feats: the displayed cohort's features (riders + non-riders).
        industry_riding: industry → (riders, members) for the
            participation axis. Supply ONLY in the ALL cohort; omit (or
            pass None) for a single-industry view, where participation
            is a constant and should stay dormant.

    Returns:
        ``{symbol: score}`` for the RIDERS only. Non-riders are absent
        from the dict. Empty dict when no symbol is riding.
    """
    riders = [f for f in feats if f.streak >= 1]
    if not riders:
        return {}

    streak = np.array([f.streak for f in riders], dtype=float)
    # Freshness: invert+decay via 1/streak. All riders have streak >= 1,
    # so streak 1 → freshness 1.0 (freshest), higher streaks decay.
    inv_streak = 1.0 / streak
    f_fresh = _minmax(inv_streak)

    ret = np.array([f.recent_return for f in riders], dtype=float)
    f_ext = _minmax(ret, invert=True)    # less recent run = better

    adtv = np.array([f.adtv for f in riders], dtype=float)
    log_adtv = np.log(np.clip(adtv, _ADTV_FLOOR, _ADTV_CEILING))
    f_liq = _minmax(log_adtv)

    bbw = np.array([f.bbw for f in riders], dtype=float)
    f_coil = _minmax(bbw, invert=True)   # tighter band = better

    f_part = _participation(riders, industry_riding)
    # Normalise participation across the riders too, so it's on the same
    # 0..1 footing as the other axes (a cohort where everyone rides
    # equally → flat → 0.5, contributing nothing).
    f_part = _minmax(f_part)

    total = (
        f_fresh * W_FRESHNESS
        + f_ext * W_EXTENSION
        + f_liq * W_LIQUIDITY
        + f_coil * W_COIL
        + f_part * W_PARTICIPATION
    ) * 100.0

    return {f.symbol: float(s) for f, s in zip(riders, total)}
