"""scripts/run_commodity_flow_research_v2.py — stratified follow-up.

The base research (``run_commodity_flow_research.py``) established
that commodity z-scores are mean-reverting on average: high z predicts
fade, low z predicts rebound. Best single signal was
``z_10d < -2 → +0.90pp @ 5d, t=+5.02``.

Before shipping that as a universal tag, we need to know WHO earns
that edge. This script runs three stratification passes on the same
feature table:

1. **By category** (Precious / Industrial / Energy / Agricultural /
   Livestock) — is the mean-reversion uniform across categories or
   driven by one?

2. **By instrument** (the 23 individual tickers) — is one ticker
   dominating the average?

3. **By volatility regime** — split the panel into high-vol and
   low-vol periods (via the panel-wide 60d realized vol tercile).
   Does the mean-reversion hold across both regimes, or only in
   calm conditions?

If the pattern is uniform, we ship one tag that applies to all 23
instruments. If it's category-dominated, we ship tags only on the
dominating category. If it's regime-dependent, we gate the tag on
the current regime (or don't ship).

Methodology: identical to base script. Same feature table, same
ablation function, same verdict rules. Just more subsetting.

Run::

    python scripts/run_commodity_flow_research_v2.py

Writes:
  - data/commodity_flow_research_v2.csv
  - stdout report
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts._composition import build_macro_panel_loader             # noqa: E402
from scripts.run_commodity_flow_research import (                     # noqa: E402
    ablate_signature,
    build_commodity_feature_table,
    print_signature_table,
    verdict,
)

from nimbus_v3.macro.universe import CommodityCategory                # noqa: E402


logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("commodity_flow_research_v2")


# ══════════════════════════════════════════════════════════════════════
# Stratified ablation helpers
# ══════════════════════════════════════════════════════════════════════

def run_on_subset(
    sub: pd.DataFrame, subset_label: str,
) -> list[dict]:
    """Run the four key signature ablations on a subset of the
    feature table. Returns the rows — caller aggregates + prints."""
    if len(sub) < 500:
        log.warning(
            "subset %s has only %d rows; skipping (min 500 for stable stats)",
            subset_label, len(sub),
        )
        return []

    z10 = sub["z_10d"].to_numpy()
    z60 = sub["z_60d"].to_numpy()

    # The four signals with clearest edge on the full panel.
    # Prefixing each signature name with the subset label so tables
    # stay readable when rows are interleaved.
    tests = [
        (f"[{subset_label}] z10 > +2", (z10 > 2.0)),
        (f"[{subset_label}] z10 < -2", (z10 < -2.0)),
        (f"[{subset_label}] z60 > +2", (z60 > 2.0)),
        (f"[{subset_label}] z60 < -2", (z60 < -2.0)),
    ]
    rows: list[dict] = []
    for name, mask in tests:
        mask = np.asarray(mask, dtype=bool)
        for horizon in ("fwd_5d", "fwd_20d"):
            rows.append(ablate_signature(sub, mask, horizon, name))
    return rows


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Building commodity panel loader …")
    loader = build_macro_panel_loader()
    if loader is None:
        log.error("Loader build failed — can't proceed")
        sys.exit(1)

    log.info("Loading commodity panel …")
    panel = loader()
    log.info("Panel: %d tickers", len(panel))

    log.info("Building feature table (reusing base script helper) …")
    feats = build_commodity_feature_table(panel)
    if feats.empty:
        log.error("Empty feature table; can't proceed")
        sys.exit(1)
    log.info(
        "Feature table: %d rows × %d cols, %d tickers, %d categories",
        len(feats), len(feats.columns),
        feats["ticker"].nunique(), feats["category"].nunique(),
    )

    all_rows: list[dict] = []

    # ────────────────────────────────────────────────────────────────
    # 1. Per-category ablation
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("PER-CATEGORY ABLATION")
    print("═" * 72)
    print("Same z>+2 / z<-2 signals, measured separately on each")
    print("commodity category. If mean-reversion is a universal")
    print("phenomenon, every category's rows have the same sign.")
    print("If one category is carrying the average, other categories")
    print("will be flat or opposite.")
    print()

    for cat in CommodityCategory:
        sub = feats[feats["category"] == cat.value]
        sub_label = cat.value[:8]    # trim for table width
        rows = run_on_subset(sub, f"cat={sub_label}")
        if rows:
            print(f"\n── Category: {cat.value} (n={len(sub):,} bars,"
                  f" {sub['ticker'].nunique()} tickers) ──")
            print_signature_table(rows)
            all_rows.extend(rows)

    # ────────────────────────────────────────────────────────────────
    # 2. Per-instrument ablation (high-n only)
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("PER-INSTRUMENT ABLATION")
    print("═" * 72)
    print("Same signals, per instrument. Asks whether one or two")
    print("tickers are producing all the edge — which would make a")
    print("blanket tag across the universe misleading.")
    print()

    per_instr_rows: list[dict] = []
    for ticker in sorted(feats["ticker"].unique()):
        sub = feats[feats["ticker"] == ticker]
        if len(sub) < 1500:
            # Need enough bars PER instrument for the per-instrument
            # signal counts to be meaningful. Skip thin-history
            # instruments — they'll show up in the category pass
            # anyway.
            continue
        rows = run_on_subset(sub, ticker)
        per_instr_rows.extend(rows)

    # Only print the signatures with meaningful n (some per-instrument
    # fires will be very few — filter to keep the table readable).
    notable_per_instr = [
        r for r in per_instr_rows if r["n_fired"] >= 50
    ]
    if notable_per_instr:
        print_signature_table(notable_per_instr)
    all_rows.extend(per_instr_rows)

    # ────────────────────────────────────────────────────────────────
    # 3. Volatility-regime ablation
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("VOLATILITY-REGIME ABLATION")
    print("═" * 72)
    print("Split the panel into vol terciles (calm / normal / volatile)")
    print("using the panel-wide 60d realized volatility of the commodity")
    print("universe's equal-weight return series. Re-run the same")
    print("signals on each tercile. Tests whether the mean-reversion")
    print("pattern is regime-dependent.")
    print()

    # Compute panel-wide realized vol at every bar. Use the EW mean of
    # per-instrument log returns, then rolling 60d std on that series.
    #
    # We already have `close` per (ticker, bar); reconstruct returns
    # and equal-weight them.
    feats_dt = feats.copy()
    # Group by bar_date (the index is the date), compute cross-ticker
    # mean of per-bar log returns.
    feats_dt["log_ret_1d"] = (
        feats_dt.groupby("ticker")["close"].pct_change()
        .pipe(lambda s: np.log(1 + s))
    )
    ew_ret = feats_dt.groupby(feats_dt.index)["log_ret_1d"].mean()
    panel_vol_60 = ew_ret.rolling(60).std()
    # Tercile thresholds over the full available history
    vol_valid = panel_vol_60.dropna()
    if len(vol_valid) < 300:
        log.warning(
            "Too few vol observations (%d); skipping regime pass",
            len(vol_valid),
        )
    else:
        q33 = vol_valid.quantile(0.33)
        q67 = vol_valid.quantile(0.67)
        log.info(
            "Vol tercile thresholds: calm<%.4f, normal 33%%-67%%, "
            "volatile>%.4f", q33, q67,
        )

        # Attach vol regime label per bar
        regime = pd.Series(
            index=panel_vol_60.index, dtype=object,
        )
        regime[panel_vol_60 < q33] = "calm"
        regime[
            (panel_vol_60 >= q33) & (panel_vol_60 <= q67)
        ] = "normal"
        regime[panel_vol_60 > q67] = "volatile"
        # Merge regime back to feats by bar_date (feats index is dates)
        feats_dt["_regime"] = regime.reindex(feats_dt.index)

        for reg in ("calm", "normal", "volatile"):
            sub = feats_dt[feats_dt["_regime"] == reg]
            rows = run_on_subset(sub, f"regime={reg}")
            if rows:
                print(f"\n── Regime: {reg} (n={len(sub):,} bars) ──")
                print_signature_table(rows)
                all_rows.extend(rows)

    # ────────────────────────────────────────────────────────────────
    # Persist + summary
    # ────────────────────────────────────────────────────────────────
    out_path = Path("data/commodity_flow_research_v2.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(all_rows).to_csv(out_path, index=False)
    log.info("\nFull results written to %s", out_path)

    # ── Interpretation helpers ─────────────────────────────────────
    print("\n" + "═" * 72)
    print("INTERPRETATION — which subsets earned production-quality edge?")
    print("═" * 72)

    # A row earns edge if n >= 200 AND |delta| >= 1.0 AND |t| >= 2.5.
    # We DON'T use the verdict() function directly here because it was
    # miscalibrated in the base script (treated z<-2 as bearish when
    # commodities mean-revert). Instead: any signal with n≥200, |Δ|≥1,
    # |t|≥2.5 counts as "earned edge" regardless of sign.
    def earns_edge(r: dict) -> bool:
        if r["n_fired"] < 200:
            return False
        d = r["delta_pp"]
        t = r["t_stat"]
        if not (np.isfinite(d) and np.isfinite(t)):
            return False
        return abs(d) >= 1.0 and abs(t) >= 2.5

    winners = [r for r in all_rows if earns_edge(r)]
    if not winners:
        print("No stratified subset earned production-quality edge at")
        print("|Δ|≥1.0pp + |t|≥2.5. The base-script finding (panel-wide")
        print("z<-2 → rebound) may be an aggregation effect that doesn't")
        print("hold robustly in subgroups.")
        print()
        print("Conservative recommendation: keep the commodity tab as")
        print("descriptive context (Option C from prior analysis) rather")
        print("than adding predictive tags. The data doesn't support")
        print("subset-robust signal.")
    else:
        # Group winners by signature-without-subset-prefix to see which
        # signals work across multiple subsets.
        by_sig: dict[str, list[dict]] = {}
        for r in winners:
            # Signature format is "[subset] signal_name"; split it back.
            sig = r["signature"]
            if "] " in sig:
                subset, clean_sig = sig.split("] ", 1)
                subset = subset.strip("[")
            else:
                subset, clean_sig = "unknown", sig
            by_sig.setdefault(clean_sig, []).append({
                **r, "subset": subset,
            })

        print(f"{len(winners)} subset × signature × horizon combos earned edge.")
        print()
        for sig_name, subset_rows in sorted(by_sig.items()):
            print(f"Signal: {sig_name}")
            print(f"  Wins in {len(subset_rows)} subsets:")
            for r in subset_rows:
                print(
                    f"    • {r['subset']:20s} {r['horizon']:8s}  "
                    f"Δ {r['delta_pp']:>+6.2f}pp  "
                    f"t={r['t_stat']:>+5.2f}  "
                    f"n_fire={r['n_fired']:>5,d}"
                )
            print()

        print("Shipping rule: a signal is robust enough to ship as a tag")
        print("if it wins in MULTIPLE subsets (e.g. 3+ categories OR")
        print("across all vol regimes). Winning in only 1 subset is a")
        print("hint, not a validation.")


if __name__ == "__main__":
    main()
