# NIMBUS v3 — Recovery Manifest

Reconstructed from session transcripts after the working tree was lost.
This document is an honest accounting of what is verified-correct, what was
reconstructed, and what could not be recovered.

## Method

The May-5 slim-refactor snapshot was used as the base. Every `create_file`
and `str_replace` operation from the saved session transcripts (May-6, May-9,
May-10, May-14, plus the current session) was parsed and replayed in
chronological order onto that base. ~85% of operations applied cleanly; the
remainder either targeted file states that no saved transcript produced
(uncaptured sessions) or were cosmetic docstring edits.

## VERIFIED CORRECT (highest confidence)

### Ride strategy — byte-exact
The strategy core is fully recovered and validated against the four reference
parquets. All values match the documented targets exactly:

| Symbol    | Phase  | Score |
|-----------|--------|-------|
| AWL       | RETEST | 40.9  |
| CLEAN     | CONT   | 26.9  |
| CIPLA     | CONT   | 36.3  |
| SUNPHARMA | CONT   | 36.7  |

- All tuning constants correct: `CONT_RIDE_LOOKBACK=3`, `CONT_RIDE_BARS_MIN=3`,
  `RETEST_PULLBACK_MAX_BARS=5`, `RETEST_ACTIVE_WINDOW=2`, `BODY_STRENGTH_MIN=0.25`,
  `CONT_DETACHED_PCTB_MAX=1.7`.
- All 70 ride-strategy contract tests pass.
- 5-component conviction score + extension/liquidity penalties intact.

### Compute engine
- `enrichment_schema_hash() = 3eb7942e` — matches recorded final state.
- Enrichment produces the expected 16-column output.

### Verified-passing test suite: 903 tests
Covering: compute (indicators, engine, ride strategy, correlation, vix pace,
industry analytics), data layer (cache, price loader, panel refresh, nse
client, options loader, industry db), presenters, sidebar (incl. earnings
caution), industry context card, market session, core types/context/universe.

### App launches
`main.py --no-panel-prewarm --initial-symbol RELIANCE` builds the full window:
sidebar, single-tab dashboard cockpit, bottom-strip Industries + Constituents
tables. Returns cleanly.

## RECONSTRUCTED THIS SESSION (from precise contracts, not guesses)

- `sidebar._kv_row()` helper — reconstructed from its exact call signature
  `row, v = _kv_row(label)` and the established inline row pattern in the
  same file. Drives the OPTIONS OVERLAY and KEY LEVELS panels.
- `sidebar.set_earnings_caution()` + `_earnings_caution_lbl` + `clear_signals()`
  — reconstructed verbatim from the test contract in
  `tests/ui/test_sidebar_earnings_caution.py` (all 8 tests pass).
- `dashboard_tab.py` missing imports (`PanelFrame`, `ExpiryRisk`, `GEXRegime`,
  `IndustryContextCard`, `VIOLET`) — re-added; these were dropped by failed
  import-line hunks. Names proven necessary by usage.

## NOT RECOVERED — defining code absent from all saved transcripts

These features' implementations were authored in sessions whose transcripts
were not saved. They cannot be reconstructed without inventing code:

1. **Market Pulse VIX/CORR badges** (`market_context_tab.py`):
   `set_vix_state()`, `set_correlation_state()`, `_vix_regime_label`,
   `_corr_regime_label`, `_vix_arrow_for_group()`. ~26 failing tests.
   The methods are never defined in any transcript.

2. **Thin-peer industry context** (`industry_context_card.py` /
   `main_window.py`): the `thin_peer=` / `ThinPeerContext` /
   `MIN_INDUSTRY_SIZE` signature extension. ~16 failing tests/errors.

3. **Price-chart option walls** (`price_chart.py`): `_level_lines` and the
   right-margin wall labels. 5 failing tests.

4. **Earnings MainWindow wiring**: `_push_earnings_caution()` + the three
   call sites. The sidebar half is recovered (above); the MainWindow half
   was in-progress when the loss occurred. `earnings_calendar.py` module
   is present.

5. **Misc**: `MainWindow(scanner=...)` test kwarg, `SLOPE_LOOKBACK` export,
   `main_entrypoint` arg parsing details. Mostly test-only.

## EXCLUDED STALE TESTS (pre-existing drift, not caused by recovery)

These reference modules deleted during the May-5 slim refactor and were
already failing before the loss: `test_widgets.py`, `test_context.py`,
`test_engine.py` (old engine API), `conviction/*`, `scanner/*`,
`strategies/*`, `tracking/*`, `test_scan_results_model.py`,
`test_tracker_stats_panel.py`, `test_market_context_tab_adtv_bb.py`,
several `scripts/*` vix-validation tests.

## POST-RECOVERY FIXES (this session, in response to screenshot)

1. **Crash fixed** — `NameError: _fmt_price` in `sidebar.set_options_context`.
   Root cause: a failed import/definition hunk left the options formatters
   (`_fmt_price`, `_fmt_ratio`, `_fmt_signed`, `_fmt_pct`, `_fmt_gex_regime`,
   `_fmt_expiry_risk`, `_gex_color`, `_expiry_color`) used but undefined, plus
   a duplicated `set_options_context`/`_set_opt` method pair. Formatters added
   verbatim from their definitions in `dashboard_tab.py` (same codebase);
   duplicate method block removed.

2. **Right rail removed** (issue #1) — the WORKFLOW ANALYSIS column (OPTIONS
   OVERLAY + INDUSTRY CONTEXT) was deleted from `dashboard_tab._build_ui`. The
   chart + bottom tables strip now span the full content width. This matches
   the documented final design ("right-rail deleted, chart full-width"); the
   options overlay + industry classification live in the sidebar.

3. **Chart/tables ratio rebalanced** (issue #2) — vertical splitter changed
   from 70/30 to 60/40, and the bottom tables strip given a 240px minimum
   height so the chart can no longer squeeze the Industries / Constituents
   tables down to a sliver.

Obsolete tests after these changes: `test_dashboard_tab.py` cases that probe
the removed `_industry_card` / `_options_panel` (right-rail) now fail — they
test functionality intentionally removed and should be deleted or rewritten
against the sidebar.
