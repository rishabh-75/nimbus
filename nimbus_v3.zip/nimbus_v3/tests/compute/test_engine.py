"""Tests for nimbus_v3.compute.engine.StrategyComputeEngine."""
from __future__ import annotations

import dataclasses

import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine, _EXPECTED_COLUMNS
from nimbus_v3.core.signal_state import SignalState


@pytest.fixture
def engine() -> StrategyComputeEngine:
    return StrategyComputeEngine()


def test_enrich_produces_every_expected_column(engine, ohlcv_300) -> None:
    enriched = engine.enrich(ohlcv_300, symbol="TEST")
    missing = _EXPECTED_COLUMNS - set(enriched.columns)
    assert not missing, f"enriched frame missing columns: {missing}"


def test_enrich_does_not_mutate_input(engine, ohlcv_300) -> None:
    before_cols = list(ohlcv_300.columns)
    before_len = len(ohlcv_300)
    _ = engine.enrich(ohlcv_300, symbol="TEST")
    assert list(ohlcv_300.columns) == before_cols
    assert len(ohlcv_300) == before_len


def test_enrich_preserves_index(engine, ohlcv_300) -> None:
    enriched = engine.enrich(ohlcv_300, symbol="TEST")
    assert (enriched.index == ohlcv_300.index).all()


def test_enrich_rejects_missing_ohlcv(engine) -> None:
    bad = pd.DataFrame({"Close": [1.0] * 300}, index=pd.bdate_range("2020-01-01", periods=300))
    with pytest.raises(ValueError, match="OHLCV"):
        engine.enrich(bad, symbol="TEST")


def test_enrich_rejects_short_frame(engine, ohlcv_100) -> None:
    with pytest.raises(ValueError, match="bars"):
        engine.enrich(ohlcv_100, symbol="TEST")


def test_enrich_rejects_non_datetime_index(engine) -> None:
    df = pd.DataFrame({
        "Open": [1.0] * 300,
        "High": [1.0] * 300,
        "Low": [1.0] * 300,
        "Close": [1.0] * 300,
        "Volume": [1.0] * 300,
    })  # default RangeIndex
    with pytest.raises(ValueError, match="DatetimeIndex"):
        engine.enrich(df, symbol="TEST")


def test_extract_state_returns_populated_signal_state(engine, ohlcv_300) -> None:
    enriched = engine.enrich(ohlcv_300, symbol="RELIANCE")
    state = engine.extract_state(enriched, bar_index=-1, symbol="RELIANCE")
    assert isinstance(state, SignalState)
    assert state.symbol == "RELIANCE"
    assert state.bar_index == len(enriched) - 1
    assert state.close == pytest.approx(float(ohlcv_300["Close"].iloc[-1]))
    assert state.data_sufficient is True


def test_extract_state_bar_index_negative(engine, ohlcv_300) -> None:
    enriched = engine.enrich(ohlcv_300, symbol="RELIANCE")
    state_neg = engine.extract_state(enriched, bar_index=-1, symbol="RELIANCE")
    state_pos = engine.extract_state(enriched, bar_index=len(enriched) - 1, symbol="RELIANCE")
    assert state_neg == state_pos


def test_extract_state_out_of_range_raises(engine, ohlcv_300) -> None:
    enriched = engine.enrich(ohlcv_300, symbol="T")
    with pytest.raises(IndexError):
        engine.extract_state(enriched, bar_index=10_000, symbol="T")
    with pytest.raises(IndexError):
        engine.extract_state(enriched, bar_index=-10_000, symbol="T")


def test_extract_state_rejects_unenriched_frame(engine, ohlcv_300) -> None:
    with pytest.raises(ValueError, match="enrich"):
        engine.extract_state(ohlcv_300, bar_index=-1, symbol="T")


def test_validate_enriched(engine, ohlcv_300) -> None:
    assert engine.validate_enriched(ohlcv_300) is False
    enriched = engine.enrich(ohlcv_300, symbol="T")
    assert engine.validate_enriched(enriched) is True


def test_data_sufficient_flag_on_warmup_bar(engine, ohlcv_300) -> None:
    enriched = engine.enrich(ohlcv_300, symbol="T")
    # Bar 50 is well before the 200-bar warmup; must be insufficient.
    state_early = engine.extract_state(enriched, bar_index=50, symbol="T")
    assert state_early.data_sufficient is False
    # Bar 250 is past the warmup; must be sufficient.
    state_late = engine.extract_state(enriched, bar_index=250, symbol="T")
    assert state_late.data_sufficient is True


def test_extract_state_returns_native_python_floats(engine, ohlcv_300) -> None:
    """Per SignalState contract, numeric fields are native floats, not
    np.float64. This prevents subtle bugs in fixture JSON serialisation
    and dict-key hashing."""
    enriched = engine.enrich(ohlcv_300, symbol="T")
    state = engine.extract_state(enriched, bar_index=-1, symbol="T")
    for field in dataclasses.fields(state):
        if field.name in ("symbol", "bar_date", "bar_index", "red_streak",
                           "green_streak", "above_sma_20", "above_sma_50",
                           "above_sma_200", "data_sufficient"):
            continue
        value = getattr(state, field.name)
        # Native float (or NaN-float). Never numpy scalar.
        assert type(value) is float, (
            f"field {field.name!r} is {type(value).__name__}, expected float"
        )


def test_engine_is_stateless(engine, ohlcv_300) -> None:
    """Two consecutive enrich calls on the same input produce identical
    DataFrames. This is the property downstream consumers rely on."""
    a = engine.enrich(ohlcv_300, symbol="T")
    b = engine.enrich(ohlcv_300, symbol="T")
    pd.testing.assert_frame_equal(a, b)
