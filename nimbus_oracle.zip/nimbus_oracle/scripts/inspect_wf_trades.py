#!/usr/bin/env python3
"""
scripts/inspect_wf_trades.py — Audit walk-forward OOS trades file structure.

Tells us exactly what we have to work with for research:
  - Which CSVs exist and how many trades they contain
  - Which columns they have (and which are populated)
  - Whether fold values are real multi-fold or single-fold artifact
  - Date coverage and continuity
  - How (symbol, entry_date) joins between files would behave

Run before any new factor research to know the limits of the data.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import pandas as pd

CANDIDATE_FILES = [
    "data/backtest_results/wf_oos_trades.csv",
    "data/backtest_results/sector_regime_trades.csv",
    "data/oos_trades.csv",
    "/mnt/user-data/uploads/sector_regime_trades.csv",
    "/mnt/user-data/uploads/wf_oos_trades.csv",
]


def header(text: str, char: str = "="):
    print("\n" + char * 78)
    print(f"  {text}")
    print(char * 78)


def inspect_file(path: str) -> dict | None:
    if not os.path.exists(path):
        return None

    size = os.path.getsize(path)
    df = pd.read_csv(path)
    if "entry_date" in df.columns:
        df["entry_date"] = pd.to_datetime(df["entry_date"], errors="coerce")

    info = {
        "path": path,
        "size_kb": size / 1024,
        "n_rows": len(df),
        "n_cols": len(df.columns),
        "columns": df.columns.tolist(),
        "df": df,
    }
    return info


def print_file_summary(info: dict):
    print(f"\n  Path:    {info['path']}")
    print(f"  Size:    {info['size_kb']:.1f} KB")
    print(f"  Rows:    {info['n_rows']:,}")
    print(f"  Cols:    {info['n_cols']}")

    df = info["df"]
    if "entry_date" in df.columns:
        valid = df["entry_date"].dropna()
        if len(valid):
            print(f"  Dates:   {valid.min().date()} → {valid.max().date()}")
            print(f"           ({(valid.max() - valid.min()).days} day span)")

    if "symbol" in df.columns:
        print(f"  Symbols: {df['symbol'].nunique():,} unique")


def column_population_table(df: pd.DataFrame, label: str):
    """Show which columns are populated and how."""
    print(f"\n  {label} — column population:")
    print(f"  {'Column':<25s}  {'Type':<10s}  {'Non-null':>10s}  {'%':>6s}  {'Unique':>8s}")
    print(f"  {'-'*25}  {'-'*10}  {'-'*10}  {'-'*6}  {'-'*8}")
    n = len(df)
    for col in df.columns:
        non_null = df[col].notna().sum()
        pct = non_null / n * 100 if n else 0
        try:
            uniq = df[col].nunique(dropna=True)
        except Exception:
            uniq = "?"
        dtype = str(df[col].dtype)[:10]
        flag = ""
        if pct == 100:
            flag = " ✓"
        elif pct < 10:
            flag = " ✗ (mostly empty)"
        elif pct < 50:
            flag = " ⚠ (sparse)"
        print(f"  {col:<25s}  {dtype:<10s}  {non_null:>10,}  {pct:>5.1f}%  {str(uniq):>8s}{flag}")


def fold_audit(df: pd.DataFrame, label: str):
    """Specifically audit fold column — the thing that broke our last analysis."""
    if "fold" not in df.columns:
        print(f"\n  {label}: NO FOLD COLUMN")
        return

    fold_col = df["fold"]
    n_total = len(df)
    n_with_fold = fold_col.notna().sum()

    print(f"\n  {label} — FOLD column audit:")
    print(f"    Trades with fold value:    {n_with_fold:,} / {n_total:,} ({n_with_fold/n_total*100:.1f}%)")
    print(f"    Trades with NaN fold:      {n_total - n_with_fold:,}")

    if n_with_fold > 0:
        fold_dist = fold_col.value_counts(dropna=True).sort_index()
        print(f"    Distinct fold values:      {len(fold_dist)}")
        print(f"\n    Distribution:")
        for fv, count in fold_dist.items():
            bar = "█" * int(count / fold_dist.max() * 40)
            pct = count / n_with_fold * 100
            print(f"      fold={str(fv):<6s} {count:5,d} ({pct:4.1f}%)  {bar}")

        # Date coverage by fold
        if "entry_date" in df.columns:
            print(f"\n    Date coverage by fold:")
            for fv in sorted(fold_dist.index):
                sub = df[df["fold"] == fv]
                dates = sub["entry_date"].dropna()
                if len(dates):
                    print(f"      fold={str(fv):<6s} {dates.min().date()} → {dates.max().date()} ({len(sub)} trades)")

    if n_with_fold < n_total * 0.9:
        print(f"\n  ⚠ MOST TRADES HAVE NO FOLD VALUE")
        print(f"  This means walk-forward fold metadata was not preserved when this CSV was exported.")
        print(f"  Implications: cannot do per-fold robustness checks on the bulk of the data.")
    elif fold_col.dropna().nunique() == 1:
        print(f"\n  ⚠ ONLY ONE FOLD VALUE PRESENT")
        print(f"  This is effectively a single OOS period, not a multi-fold walk-forward.")
        print(f"  Implications: any 'OOS' result is one continuous period — no time-segmented validation.")
    else:
        print(f"\n  ✓ Multi-fold structure intact")


def join_audit(left: dict, right: dict):
    """Test how a (symbol, entry_date) join between two files would behave."""
    if left is None or right is None:
        return

    left_df = left["df"]
    right_df = right["df"]
    if not all(c in left_df.columns for c in ["symbol", "entry_date"]):
        return
    if not all(c in right_df.columns for c in ["symbol", "entry_date"]):
        return

    print(f"\n  {os.path.basename(left['path'])} ⟕ {os.path.basename(right['path'])}")

    # Build join keys
    left_keys = set(zip(left_df["symbol"].astype(str), left_df["entry_date"]))
    right_keys = set(zip(right_df["symbol"].astype(str), right_df["entry_date"]))

    matched = left_keys & right_keys
    left_only = left_keys - right_keys
    right_only = right_keys - left_keys

    print(f"    Left rows:        {len(left_df):,}  ({len(left_keys):,} unique keys)")
    print(f"    Right rows:       {len(right_df):,}  ({len(right_keys):,} unique keys)")
    print(f"    Matched keys:     {len(matched):,}")
    print(f"    Left only:        {len(left_only):,}")
    print(f"    Right only:       {len(right_only):,}")

    if len(left_keys):
        coverage = len(matched) / len(left_keys) * 100
        print(f"    Match rate:       {coverage:.1f}% of left keys found in right")
        if coverage < 50:
            print(f"    ⚠ Low overlap — these files are NOT the same trade universe")
        elif coverage < 95:
            print(f"    ⚠ Partial overlap — joining will lose data")
        else:
            print(f"    ✓ Good overlap — safe to join")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    header("WALK-FORWARD OOS TRADES — DIAGNOSTIC AUDIT")

    # ── Phase 1: Find what exists ───────────────────────────────────────────
    header("PHASE 1: FILE DISCOVERY", "─")
    found = []
    for path in CANDIDATE_FILES:
        info = inspect_file(path)
        if info:
            found.append(info)
            print_file_summary(info)
        else:
            print(f"\n  ✗ NOT FOUND: {path}")

    if not found:
        print("\n  ERROR: No OOS trade files found anywhere.")
        print("  Cannot proceed with audit.")
        sys.exit(1)

    # ── Phase 2: Column population for each file ────────────────────────────
    for info in found:
        header(f"PHASE 2: COLUMN AUDIT — {os.path.basename(info['path'])}", "─")
        column_population_table(info["df"], os.path.basename(info["path"]))

    # ── Phase 3: Fold audit (the thing that broke us) ───────────────────────
    header("PHASE 3: FOLD STRUCTURE AUDIT")
    for info in found:
        fold_audit(info["df"], os.path.basename(info["path"]))

    # ── Phase 4: Join feasibility ───────────────────────────────────────────
    if len(found) >= 2:
        header("PHASE 4: JOIN FEASIBILITY")
        # Test all pairs
        for i, left in enumerate(found):
            for right in found[i+1:]:
                join_audit(left, right)

    # ── Phase 5: Recommendations ────────────────────────────────────────────
    header("PHASE 5: RECOMMENDATIONS FOR RESEARCH")

    has_real_folds = False
    has_metadata = False

    for info in found:
        df = info["df"]
        if "fold" in df.columns and df["fold"].dropna().nunique() > 1 and df["fold"].notna().mean() > 0.9:
            has_real_folds = True
        if "vix_regime" in df.columns and df["vix_regime"].nunique() > 1:
            has_metadata = True
        elif "sector_type" in df.columns and df["sector_type"].notna().any():
            has_metadata = True

    print()
    if has_real_folds and has_metadata:
        print("  ✓ Data is research-ready with proper fold + metadata structure")
        print("  → Per-fold robustness checks are valid")
        print("  → Sector/VIX slicing is valid")
    elif has_real_folds:
        print("  ⚠ Has fold structure but no metadata")
        print("  → Per-fold checks valid")
        print("  → Cannot slice by VIX or sector — those columns are empty/missing")
    elif has_metadata:
        print("  ⚠ Has metadata but no real fold structure")
        print("  → Sector/VIX slicing valid")
        print("  → Cannot do per-fold robustness checks — treat ALL findings with extra skepticism")
        print("  → Recommend: regenerate walk-forward backtest with fold export")
    else:
        print("  ✗ Neither folds nor metadata are usable")
        print("  → Cannot do meaningful robustness slicing")
        print("  → Recommend: regenerate walk-forward backtest with full column export")

    print()
    print("  Suggested next step depending on findings:")
    print("    - If sector_regime_trades.csv has BOTH fold and metadata, use it as the canonical source")
    print("    - If they're split across files but joinable cleanly, build a one-time merge utility")
    print("    - If neither is sufficient, regenerate the walk-forward export with both columns")


if __name__ == "__main__":
    main()
