#!/usr/bin/env python3
"""
scripts/run_sector_correlation.py — Sector cross-correlation study.

Analyses:
  1. Static correlation matrix (2yr daily returns)
  2. Cluster analysis (which sectors move together?)
  3. Lead-lag: does sector X predict sector Y at lag 1-5 days?
  4. VIX-regime-dependent correlations (do clusters break under stress?)
  5. Rotation divergence: when correlated sectors diverge, does the laggard catch up?
  6. MR edge by sector pair: does a pullback in a LEADING sector predict
     mean reversion in its correlated LAGGING pair?

Usage:
    python3 scripts/run_sector_correlation.py
    python3 scripts/run_sector_correlation.py --years 3
    python3 scripts/run_sector_correlation.py --export  # save CSV outputs
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scripts.output import enable_export; enable_export()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# SECTOR INDEX TICKERS
# ══════════════════════════════════════════════════════════════════════════════

EQUITY_SECTORS = {
    "^NSEBANK": "Bank",
    "^CNXPSUBANK": "PSU Bank",
    "PVTBANIETF.NS": "Pvt Bank",
    "FINIETF.NS": "Fin Svc",
    "^CNXIT": "IT",
    "^CNXPHARMA": "Pharma",
    "HEALTHIETF.NS": "Healthcare",
    "^CNXMETAL": "Metal",
    "^CNXFMCG": "FMCG",
    "^CNXAUTO": "Auto",
    "^CNXENERGY": "Energy",
    "^CNXINFRA": "Infra",
    "^CNXREALTY": "Realty",
    "^CNXMEDIA": "Media",
    "OILIETF.NS": "Oil&Gas",
    "CPSEETF.NS": "CPSE",
    "^CNXPSE": "PSE",
    "MODEFENCE.NS": "Defence",
    "CONSUMBEES.NS": "Consumption",
}

BENCH = "^NSEI"
VIX_TICKER = "^INDIAVIX"


def fetch_daily(ticker: str, years: int) -> pd.DataFrame:
    """Fetch daily OHLCV from yfinance."""
    import yfinance as yf
    try:
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", ticker, exc)
        return pd.DataFrame()


def fetch_all(years: int) -> tuple[pd.DataFrame, pd.Series, pd.Series]:
    """Fetch all sector close prices, NIFTY benchmark, and VIX."""
    import yfinance as yf

    all_tickers = list(EQUITY_SECTORS.keys()) + [BENCH, VIX_TICKER]
    logger.info("Downloading %d tickers (%dyr daily)...", len(all_tickers), years)

    raw = yf.download(all_tickers, period=f"{years}y", interval="1d",
                      auto_adjust=True, progress=False, threads=True,
                      group_by="column")

    if isinstance(raw.columns, pd.MultiIndex):
        close = raw["Close"]
    else:
        close = raw[["Close"]]
    if isinstance(close.columns, pd.MultiIndex):
        close.columns = close.columns.get_level_values(0)

    # Rename to display names
    rename = {**EQUITY_SECTORS, BENCH: "NIFTY", VIX_TICKER: "VIX"}
    close = close.rename(columns=rename)

    if hasattr(close.index, "tz") and close.index.tz is not None:
        close.index = close.index.tz_localize(None)

    # Extract VIX series before filtering
    vix = close["VIX"].dropna() if "VIX" in close.columns else pd.Series(dtype=float)

    # Extract NIFTY
    nifty = close["NIFTY"].dropna() if "NIFTY" in close.columns else pd.Series(dtype=float)

    # Keep only sectors with >200 bars
    sectors = [c for c in close.columns if c not in ("NIFTY", "VIX")]
    valid = [c for c in sectors if close[c].dropna().shape[0] > 200]
    close = close[valid + ["NIFTY"]].dropna()

    logger.info("Clean: %d bars × %d sectors + NIFTY", len(close), len(valid))
    logger.info("Date range: %s → %s", close.index[0].date(), close.index[-1].date())
    logger.info("Sectors: %s", list(close.columns))

    return close, nifty, vix


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 1: STATIC CORRELATION
# ══════════════════════════════════════════════════════════════════════════════

def analysis_correlation(rets: pd.DataFrame):
    """Full-period correlation matrix."""
    logger.info("\n" + "=" * 70)
    logger.info("1. CORRELATION MATRIX (daily returns, full period)")
    logger.info("=" * 70)

    corr = rets.corr()
    sectors = [c for c in corr.columns if c != "NIFTY"]

    # Compact print
    header = f"{'':12s}" + "".join(f"{s:>9s}" for s in sectors)
    print(header)
    for s in sectors:
        row = f"{s:12s}" + "".join(f"{corr.loc[s, t]:9.2f}" for t in sectors)
        print(row)

    return corr


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 2: CLUSTERS
# ══════════════════════════════════════════════════════════════════════════════

def analysis_clusters(corr: pd.DataFrame):
    """Identify high and low correlation pairs."""
    logger.info("\n" + "=" * 70)
    logger.info("2. SECTOR CLUSTERS")
    logger.info("=" * 70)

    sectors = [c for c in corr.columns if c != "NIFTY"]
    pairs = []
    for i, s1 in enumerate(sectors):
        for j, s2 in enumerate(sectors):
            if j <= i:
                continue
            pairs.append((s1, s2, corr.loc[s1, s2]))

    pairs.sort(key=lambda x: -x[2])

    print("\n  HIGH correlation (> 0.70) — move together:")
    for s1, s2, c in pairs:
        if c > 0.70:
            print(f"    {s1:12s} ↔ {s2:12s}: {c:.3f}")

    print("\n  MODERATE correlation (0.50-0.70) — related but not locked:")
    for s1, s2, c in pairs:
        if 0.50 <= c <= 0.70:
            print(f"    {s1:12s} ↔ {s2:12s}: {c:.3f}")

    print("\n  LOW correlation (< 0.30) — diversification candidates:")
    for s1, s2, c in pairs:
        if c < 0.30:
            print(f"    {s1:12s} ↔ {s2:12s}: {c:.3f}")

    return pairs


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 3: LEAD-LAG
# ══════════════════════════════════════════════════════════════════════════════

def analysis_lead_lag(rets: pd.DataFrame):
    """Cross-correlation at lags 1-5d. Does sector X predict sector Y?"""
    logger.info("\n" + "=" * 70)
    logger.info("3. LEAD-LAG ANALYSIS (which sector leads which?)")
    logger.info("=" * 70)

    sectors = [c for c in rets.columns if c != "NIFTY"]
    results = []

    for leader in sectors:
        for follower in sectors:
            if leader == follower:
                continue
            for lag in [1, 2, 3, 5]:
                shifted = rets[leader].shift(lag)
                valid = pd.concat([shifted, rets[follower]], axis=1).dropna()
                if len(valid) < 100:
                    continue
                c = valid.iloc[:, 0].corr(valid.iloc[:, 1])
                if abs(c) > 0.08:  # threshold for meaningful lead
                    results.append({
                        "leader": leader, "follower": follower,
                        "lag": lag, "corr": c,
                    })

    if results:
        df = pd.DataFrame(results).sort_values("corr", ascending=False)
        print("\n  LEADING SIGNALS (lag-N corr > 0.08 — sector X today predicts Y in N days):")
        for _, r in df.head(20).iterrows():
            print(f"    {r['leader']:12s} → {r['follower']:12s} (lag {r['lag']:d}d): r={r['corr']:+.3f}")

        print("\n  INVERSE LEADS (lag-N corr < -0.08 — sector X up today → Y down in N days):")
        inv = df[df["corr"] < -0.08].sort_values("corr")
        for _, r in inv.head(10).iterrows():
            print(f"    {r['leader']:12s} → {r['follower']:12s} (lag {r['lag']:d}d): r={r['corr']:+.3f}")
    else:
        print("  No significant lead-lag relationships found (threshold: |r| > 0.08)")

    return results


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 4: VIX-REGIME-DEPENDENT CORRELATION
# ══════════════════════════════════════════════════════════════════════════════

def analysis_regime_corr(rets: pd.DataFrame, vix: pd.Series):
    """Do sector correlations change under VIX stress?"""
    logger.info("\n" + "=" * 70)
    logger.info("4. VIX-REGIME CORRELATION SHIFTS")
    logger.info("=" * 70)

    if vix.empty:
        print("  No VIX data — skipping")
        return

    # Align VIX with returns
    common = rets.index.intersection(vix.index)
    if len(common) < 100:
        print("  Insufficient overlap between returns and VIX — skipping")
        return

    vix_aligned = vix.reindex(common)
    rets_aligned = rets.reindex(common)

    # VIX regimes
    regimes = {
        "LOW (<13)": vix_aligned < 13,
        "NORMAL (13-18)": (vix_aligned >= 13) & (vix_aligned < 18),
        "ELEVATED (18-25)": (vix_aligned >= 18) & (vix_aligned < 25),
        "PANIC (>25)": vix_aligned >= 25,
    }

    sectors = [c for c in rets.columns if c != "NIFTY"]

    # For each regime, compute avg pairwise correlation
    for regime_name, mask in regimes.items():
        sub = rets_aligned[mask]
        if len(sub) < 30:
            print(f"\n  {regime_name}: N={len(sub)} (too few)")
            continue
        corr = sub[sectors].corr()
        # Average off-diagonal
        n = len(sectors)
        avg_corr = (corr.values.sum() - n) / (n * (n - 1))
        print(f"\n  {regime_name}: N={len(sub)}  Avg pairwise corr={avg_corr:.3f}")

    # Find pairs whose correlation changes most across regimes
    print("\n  BIGGEST CORRELATION SHIFTS (Low VIX vs Panic):")
    low_mask = regimes["LOW (<13)"]
    panic_mask = regimes["PANIC (>25)"]
    low_sub = rets_aligned[low_mask]
    panic_sub = rets_aligned[panic_mask]

    if len(low_sub) > 30 and len(panic_sub) > 30:
        low_corr = low_sub[sectors].corr()
        panic_corr = panic_sub[sectors].corr()
        shifts = []
        for i, s1 in enumerate(sectors):
            for j, s2 in enumerate(sectors):
                if j <= i:
                    continue
                lc = low_corr.loc[s1, s2]
                pc = panic_corr.loc[s1, s2]
                shifts.append((s1, s2, lc, pc, pc - lc))
        shifts.sort(key=lambda x: -abs(x[4]))
        for s1, s2, lc, pc, delta in shifts[:10]:
            direction = "CONVERGE" if delta > 0 else "DIVERGE"
            print(f"    {s1:12s} ↔ {s2:12s}: Low={lc:.2f} → Panic={pc:.2f}  Δ={delta:+.2f}  ({direction})")
    else:
        print("    Insufficient data in LOW or PANIC regimes")


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 5: ROTATION DIVERGENCE — MEAN REVERSION SIGNAL?
# ══════════════════════════════════════════════════════════════════════════════

def analysis_divergence(close: pd.DataFrame, rets: pd.DataFrame):
    """When correlated sectors diverge, does the laggard catch up?"""
    logger.info("\n" + "=" * 70)
    logger.info("5. ROTATION DIVERGENCE — Does the laggard catch up?")
    logger.info("=" * 70)

    sectors = [c for c in close.columns if c != "NIFTY"]

    # Compute 20d rolling returns for each sector
    ret_20d = close[sectors].pct_change(20)

    # Find highly correlated pairs
    corr = rets[sectors].corr()
    pairs = []
    for i, s1 in enumerate(sectors):
        for j, s2 in enumerate(sectors):
            if j <= i:
                continue
            if corr.loc[s1, s2] > 0.60:
                pairs.append((s1, s2, corr.loc[s1, s2]))

    print(f"\n  Testing {len(pairs)} correlated pairs (r > 0.60):")
    print(f"  Divergence = one sector 20d return > 5pp above the other")
    print(f"  Question: does the laggard outperform over the next 10d and 21d?\n")

    results = []
    for s1, s2, base_corr in pairs:
        spread = ret_20d[s1] - ret_20d[s2]
        fwd_s1_10 = close[s1].pct_change(10).shift(-10)
        fwd_s2_10 = close[s2].pct_change(10).shift(-10)
        fwd_s1_21 = close[s1].pct_change(21).shift(-21)
        fwd_s2_21 = close[s2].pct_change(21).shift(-21)

        # When s1 leads by >5pp → does s2 catch up?
        mask_s1_leads = spread > 0.05
        # When s2 leads by >5pp → does s1 catch up?
        mask_s2_leads = spread < -0.05

        for mask, leader, laggard in [
            (mask_s1_leads, s1, s2),
            (mask_s2_leads, s2, s1),
        ]:
            valid = mask & fwd_s1_10.notna() & fwd_s2_10.notna()
            n = valid.sum()
            if n < 20:
                continue

            if laggard == s2:
                lag_fwd_10 = fwd_s2_10[valid].mean() * 100
                lead_fwd_10 = fwd_s1_10[valid].mean() * 100
                lag_fwd_21 = fwd_s2_21[valid].mean() * 100
                lead_fwd_21 = fwd_s1_21[valid].mean() * 100
            else:
                lag_fwd_10 = fwd_s1_10[valid].mean() * 100
                lead_fwd_10 = fwd_s2_10[valid].mean() * 100
                lag_fwd_21 = fwd_s1_21[valid].mean() * 100
                lead_fwd_21 = fwd_s2_21[valid].mean() * 100

            catch_up_10 = lag_fwd_10 - lead_fwd_10
            catch_up_21 = lag_fwd_21 - lead_fwd_21

            results.append({
                "leader": leader, "laggard": laggard,
                "base_corr": base_corr, "n": n,
                "lag_10d": lag_fwd_10, "lead_10d": lead_fwd_10,
                "catchup_10d": catch_up_10,
                "lag_21d": lag_fwd_21, "lead_21d": lead_fwd_21,
                "catchup_21d": catch_up_21,
            })

    if results:
        df = pd.DataFrame(results).sort_values("catchup_21d", ascending=False)
        print(f"  {'Leader':12s} {'Laggard':12s} {'N':>5s}  {'Lag 10d':>8s} {'Lead 10d':>9s} {'CU 10d':>7s}  {'Lag 21d':>8s} {'Lead 21d':>9s} {'CU 21d':>7s}")
        print(f"  {'-'*12} {'-'*12} {'-'*5}  {'-'*8} {'-'*9} {'-'*7}  {'-'*8} {'-'*9} {'-'*7}")
        for _, r in df.iterrows():
            cu10 = f"{r['catchup_10d']:+.2f}%"
            cu21 = f"{r['catchup_21d']:+.2f}%"
            tag = "★" if r["catchup_21d"] > 1.0 and r["n"] >= 30 else ""
            print(f"  {r['leader']:12s} {r['laggard']:12s} {r['n']:5.0f}  {r['lag_10d']:+7.2f}% {r['lead_10d']:+8.2f}% {cu10:>7s}  {r['lag_21d']:+7.2f}% {r['lead_21d']:+8.2f}% {cu21:>7s}  {tag}")
    else:
        print("  No divergence events found with sufficient data")

    return results


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 6: SECTOR BETA TO NIFTY — WHO AMPLIFIES?
# ══════════════════════════════════════════════════════════════════════════════

def analysis_beta(rets: pd.DataFrame, vix: pd.Series):
    """Sector beta to NIFTY, split by VIX regime."""
    logger.info("\n" + "=" * 70)
    logger.info("6. SECTOR BETA TO NIFTY (regime-dependent)")
    logger.info("=" * 70)

    if "NIFTY" not in rets.columns:
        print("  No NIFTY data — skipping")
        return

    sectors = [c for c in rets.columns if c != "NIFTY"]
    nifty_ret = rets["NIFTY"]

    # Full period beta
    print(f"\n  {'Sector':12s}  {'Beta':>6s}  {'Corr':>6s}  {'Alpha/day':>10s}")
    betas = {}
    for s in sectors:
        valid = pd.concat([nifty_ret, rets[s]], axis=1).dropna()
        if len(valid) < 100:
            continue
        cov = valid.iloc[:, 0].cov(valid.iloc[:, 1])
        var = valid.iloc[:, 0].var()
        beta = cov / var if var > 0 else 0
        corr = valid.iloc[:, 0].corr(valid.iloc[:, 1])
        alpha = (valid.iloc[:, 1].mean() - beta * valid.iloc[:, 0].mean()) * 100
        betas[s] = beta
        print(f"  {s:12s}  {beta:6.2f}  {corr:6.2f}  {alpha:+9.4f}%")

    # Regime-split beta
    if not vix.empty:
        common = rets.index.intersection(vix.index)
        vix_al = vix.reindex(common)
        rets_al = rets.reindex(common)

        print(f"\n  Regime-split beta (interesting = beta changes > 0.3 across regimes):")
        print(f"  {'Sector':12s}  {'Low':>6s}  {'Normal':>6s}  {'Elev':>6s}  {'Panic':>6s}  {'Shift':>7s}")

        masks = {
            "Low": vix_al < 13,
            "Normal": (vix_al >= 13) & (vix_al < 18),
            "Elev": (vix_al >= 18) & (vix_al < 25),
            "Panic": vix_al >= 25,
        }

        for s in sectors:
            row_betas = {}
            for rname, mask in masks.items():
                sub = rets_al[mask]
                if len(sub) < 20:
                    row_betas[rname] = None
                    continue
                valid = pd.concat([sub["NIFTY"], sub[s]], axis=1).dropna()
                if len(valid) < 20:
                    row_betas[rname] = None
                    continue
                cov = valid.iloc[:, 0].cov(valid.iloc[:, 1])
                var = valid.iloc[:, 0].var()
                row_betas[rname] = cov / var if var > 0 else 0

            vals = [v for v in row_betas.values() if v is not None]
            shift = max(vals) - min(vals) if len(vals) >= 2 else 0
            parts = []
            for rname in ["Low", "Normal", "Elev", "Panic"]:
                b = row_betas[rname]
                parts.append(f"{b:6.2f}" if b is not None else "    —")
            print(f"  {s:12s}  {'  '.join(parts)}  {shift:+6.2f}{'  ★' if shift > 0.3 else ''}")


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS 7: SECTOR BREADTH — CONCENTRATION RISK
# ══════════════════════════════════════════════════════════════════════════════

def analysis_breadth(rets: pd.DataFrame):
    """How many sectors are positive on a given day? Breadth extremes."""
    logger.info("\n" + "=" * 70)
    logger.info("7. SECTOR BREADTH — Concentration and extremes")
    logger.info("=" * 70)

    sectors = [c for c in rets.columns if c != "NIFTY"]
    pos_count = (rets[sectors] > 0).sum(axis=1)
    total = len(sectors)

    print(f"\n  Breadth distribution ({total} sectors tracked):")
    for n in range(0, total + 1):
        days = (pos_count == n).sum()
        if days > 0:
            nifty_ret = rets["NIFTY"][pos_count == n].mean() * 100 if "NIFTY" in rets.columns else 0
            fwd_5d = rets["NIFTY"].shift(-5)[pos_count == n].mean() * 100 * 5 if "NIFTY" in rets.columns else 0
            print(f"    {n:2d}/{total} positive: {days:4d} days  NIFTY avg={nifty_ret:+.3f}%  fwd 5d={fwd_5d:+.2f}%")

    # Extremes: < 3 or > total-3
    print(f"\n  Extreme breadth events (≤2 or ≥{total-2} sectors positive):")
    low_mask = pos_count <= 2
    high_mask = pos_count >= total - 2
    if low_mask.sum() > 5 and "NIFTY" in rets.columns:
        fwd = rets["NIFTY"].shift(-10)[low_mask].mean() * 100 * 10
        print(f"    Ultra-low (≤2): {low_mask.sum()} days, NIFTY fwd 10d avg = {fwd:+.2f}%")
    if high_mask.sum() > 5 and "NIFTY" in rets.columns:
        fwd = rets["NIFTY"].shift(-10)[high_mask].mean() * 100 * 10
        print(f"    Ultra-high (≥{total-2}): {high_mask.sum()} days, NIFTY fwd 10d avg = {fwd:+.2f}%")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Sector cross-correlation study")
    parser.add_argument("--years", type=int, default=2, help="Years of data")
    parser.add_argument("--export", action="store_true", help="Export CSVs")
    args = parser.parse_args()

    close, nifty, vix = fetch_all(args.years)
    rets = close.pct_change().dropna()

    logger.info("Sectors: %d, Bars: %d", len(close.columns) - 1, len(rets))

    # Run all analyses
    corr = analysis_correlation(rets)
    pairs = analysis_clusters(corr)
    lead_lag = analysis_lead_lag(rets)
    analysis_regime_corr(rets, vix)
    analysis_divergence(close, rets)
    analysis_beta(rets, vix)
    analysis_breadth(rets)

    # Export
    if args.export:
        out = Path(__file__).parent.parent / "data" / "backtest_results"
        out.mkdir(parents=True, exist_ok=True)
        corr.to_csv(out / "sector_correlation_matrix.csv")
        rets.to_csv(out / "sector_daily_returns.csv")
        if lead_lag:
            pd.DataFrame(lead_lag).to_csv(out / "sector_lead_lag.csv", index=False)
        logger.info("Exported to %s", out)

    logger.info("\nDone.")


if __name__ == "__main__":
    main()
