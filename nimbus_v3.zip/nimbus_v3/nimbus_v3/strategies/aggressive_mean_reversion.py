"""nimbus_v3.strategies.aggressive_mean_reversion — oracle's MR gates
ported onto v3's ``SignalState`` infrastructure.

This is the AGGRESSIVE-mode mean reversion strategy. It reuses v3's
enriched SignalState (same indicators as oracle's ``compute_dual_mode``)
but applies oracle's looser entry gates:

    - WR(30) < -30            (oracle: WR_THRESH)
    - close < SMA(20)         (below trend — pullback confirmed)
    - MFI(14) >= 30           (not under extreme outflow)
    - drawdown from 50d high <= -8%  (primary tier)
    - red_streak >= 4          (primary tier: real capitulation)
    - vol_ratio_20 >= 1.5      (primary tier: volume confirmation)

Oracle splits into PRIMARY (all gates met) and SECONDARY (core gates
only). Secondary tier was disabled by default in oracle's final config
(``ENABLE_SECONDARY_TIER = False``) because OOS validation showed it
diluted the edge. We follow that decision here — primary-only.

Contrast with the conservative ``MeanReversionStrategy`` which requires
``vix_high_streak >= 6`` and ``bbw_20_2s_pctl < 40``. Those gates are
strict OOS-validated by ``scripts/run_strategy_validation.py`` with a
tighter edge (fewer false positives, lower trade count). Aggressive
mode gives the operator oracle's legacy firing frequency for discretion-
ary use when they want to see the broader picture.

Production weight is 1.0 because oracle treated these as tradable
signals. No research-tier override applies.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Gate parameters — ported verbatim from oracle's dual_mode.py constants.
# Changing these requires re-running the oracle walk-forward harness.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class AggressiveMeanReversionParams:
    wr_30_max: float = -30.0
    mfi_14_min: float = 30.0
    dd_from_high_max: float = -8.0    # negative: at least 8% off the 50d high
    red_streak_min: int = 4
    vol_ratio_min: float = 1.5


class AggressiveMeanReversionStrategy:
    """Aggressive-mode MR. Rejects ETFs. No VIX-streak requirement."""

    name: str = "AggressiveMeanReversion"
    setup_type: SetupType = SetupType.MEAN_REVERSION
    priority: int = 50
    production_weight: float = 1.0   # oracle treated this as tradable

    def __init__(
        self,
        params: AggressiveMeanReversionParams = AggressiveMeanReversionParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        # Core (all primary-tier) gates.
        if state.wr_30 >= self._p.wr_30_max:
            return None
        # ``above_sma_20 is False`` is the "below trend" check. Using
        # the bool field from SignalState instead of recomputing.
        if state.above_sma_20:
            return None
        if state.sma_20 <= 0:
            return None
        if state.mfi_14 < self._p.mfi_14_min:
            return None
        # Primary-tier additional gates (oracle's PRIMARY classification).
        # Drawdown field is signed negative: DD = (close / high - 1) * 100,
        # so "at least 8% off high" means ``dd_from_high <= -8``.
        if state.dd_from_high_50 > self._p.dd_from_high_max:
            return None
        if state.red_streak < self._p.red_streak_min:
            return None
        if state.vol_ratio_20 < self._p.vol_ratio_min:
            return None

        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "wr_30": state.wr_30,
                "mfi_14": state.mfi_14,
                "pct_from_sma_20": state.pct_from_sma_20,
                "dd_from_high_50": state.dd_from_high_50,
                "red_streak": state.red_streak,
                "vol_ratio_20": state.vol_ratio_20,
                "tier": "PRIMARY",
            },
        )
