"""nimbus_v3.conviction.grade_engine — grading composition layer.

Takes a ``(SignalState, ContextBundle, StrategySignal, Strategy)``
tuple and produces a ``Conviction`` — the single piece of output the
rest of the system grades trades on. Defined here rather than in
``core/types.py`` because the grade engine is the authoritative owner.

Architecture invariant (per ARCHITECTURE.md §18.3)
───────────────────────────────────────────────────
**Grading is computed exactly once per signal, by the engine.**
No other module (UI, scanner, risk layer, signal tracker) may
recompute conviction from state+contexts. Those consumers READ the
``Conviction`` object — they never produce their own.

Weight composition
──────────────────
Final score = ``strategy.production_weight × sum(weighted_contribs)``.

A research-only strategy (weight 0) produces a score of exactly 0
regardless of contribution values. This is intentional: the grade
engine still computes all contributions (so they appear in the
conviction record for diagnostics / research logging), but the
resulting score, letter, and verdict reflect "no production grade."

TRAP override
─────────────
A TRAP ``setup_type`` forces ``Verdict.SKIP`` and ``Sizing.SKIP``
regardless of the computed score. The contribution pipeline still
runs for record-keeping.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import pandas as pd

from nimbus_v3.conviction.formula import Contribution, compute_contributions
from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import (
    GradeLetter, SetupType, Sizing, Verdict,
)
from nimbus_v3.strategies.base import Strategy, StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Thresholds
# ══════════════════════════════════════════════════════════════════════════════

#: Numeric score → GradeLetter boundaries. Inclusive lower bounds.
#: A score of exactly 3.0 is grade A; 2.9 is B; etc.
#:
#: Scale assumption: a "typical MR signal in a HIGH-VIX regime with
#: mild oversold setup" should land around 4-5. Pure noise signals
#: land around 0. Strong contraindications (overbought, bad sector
#: RS) go negative.
GRADE_THRESHOLDS: Final[list[tuple[float, GradeLetter]]] = [
    (3.0, GradeLetter.A),
    (1.5, GradeLetter.B),
    (0.0, GradeLetter.C),
]

#: Score threshold above which ``Verdict.TAKE`` is permitted. Below
#: this we emit ``Verdict.WATCH`` (visible, but not actionable).
TAKE_SCORE_MIN: Final[float] = 1.5


# ══════════════════════════════════════════════════════════════════════════════
# Output record
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class Conviction:
    """Authoritative grading output for one signal.

    Frozen so downstream consumers cannot mutate. Everything the UI,
    risk layer, and signal tracker need lives here.
    """
    symbol: str
    asof_date: pd.Timestamp
    strategy_name: str
    setup_type: SetupType

    # Core score and classification.
    raw_score: float           # sum of weighted contributions, pre-strategy-weight
    score: float               # final: raw_score × production_weight
    grade: GradeLetter         # bucketed from score
    verdict: Verdict
    sizing: Sizing

    # Full contribution trail for audit/display.
    contributions: tuple[Contribution, ...]

    # Strategy metadata for tracking.
    production_weight: float

    # Optional override reason — populated when a hard gate fired
    # (e.g. TRAP). None when score-driven grading applied normally.
    override_reason: str | None = None


# ══════════════════════════════════════════════════════════════════════════════
# Engine
# ══════════════════════════════════════════════════════════════════════════════

class ConvictionEngine:
    """Stateless composer of ``Conviction`` records.

    A single instance is shared across all scans. No configuration,
    no per-call state — the scoring rules all live in
    ``nimbus_v3.conviction.formula``.
    """

    def grade(
        self,
        *,
        state: SignalState,
        contexts: ContextBundle,
        signal: StrategySignal,
        strategy: Strategy,
    ) -> Conviction:
        """Produce a ``Conviction`` from a (state, contexts, signal, strategy) tuple."""
        contributions = tuple(compute_contributions(state, contexts, signal))
        raw_score = sum(c.weighted for c in contributions)
        weight = float(strategy.production_weight)
        final_score = raw_score * weight

        def _build(
            *, grade: GradeLetter, verdict: Verdict, sizing: Sizing,
            override_reason: str | None,
        ) -> Conviction:
            # Shared construction path — ensures grade/verdict/sizing
            # are the only fields that vary across the four branches
            # below, and prevents drift if new fields are added to
            # ``Conviction`` later.
            return Conviction(
                symbol=signal.symbol,
                asof_date=signal.asof_date,
                strategy_name=signal.strategy_name,
                setup_type=signal.setup_type,
                raw_score=raw_score,
                score=final_score,
                grade=grade,
                verdict=verdict,
                sizing=sizing,
                contributions=contributions,
                production_weight=weight,
                override_reason=override_reason,
            )

        # TRAP hard-skip — either an explicit TRAP strategy fire or a
        # filing flagged as TRAP in the recent-event window. Same
        # verdict in both cases; the override_reason preserves which
        # trigger fired for downstream display / tracking.
        if signal.setup_type == SetupType.TRAP:
            return _build(
                grade=GradeLetter.D, verdict=Verdict.SKIP, sizing=Sizing.SKIP,
                override_reason="TRAP filing — hard SKIP",
            )
        if contexts.filing is not None and contexts.filing.is_trap:
            return _build(
                grade=GradeLetter.D, verdict=Verdict.SKIP, sizing=Sizing.SKIP,
                override_reason="TRAP filing in recent window — hard SKIP",
            )

        # Research-only (weight 0) → grade D, verdict WATCH, sizing SKIP.
        if weight == 0.0:
            return _build(
                grade=GradeLetter.D, verdict=Verdict.WATCH, sizing=Sizing.SKIP,
                override_reason="research-only strategy (production_weight=0)",
            )

        grade = self._score_to_grade(final_score)
        verdict = self._score_to_verdict(final_score, contexts)
        sizing = self._verdict_to_sizing(verdict, grade)
        return _build(
            grade=grade, verdict=verdict, sizing=sizing, override_reason=None,
        )

    # ══════════════════════════════════════════════════════════════════════
    # Private decision pieces — kept small + testable
    # ══════════════════════════════════════════════════════════════════════

    @staticmethod
    def _score_to_grade(score: float) -> GradeLetter:
        for min_score, letter in GRADE_THRESHOLDS:
            if score >= min_score:
                return letter
        return GradeLetter.D

    @staticmethod
    def _score_to_verdict(score: float, contexts: ContextBundle) -> Verdict:
        # Hard-gate SKIP: score too low.
        if score < 0.0:
            return Verdict.SKIP
        # MATERIAL filing softens but doesn't SKIP; the contribution
        # has already penalised the score. Stay with score-driven.
        if score >= TAKE_SCORE_MIN:
            return Verdict.TAKE
        return Verdict.WATCH

    @staticmethod
    def _verdict_to_sizing(verdict: Verdict, grade: GradeLetter) -> Sizing:
        if verdict == Verdict.SKIP:
            return Sizing.SKIP
        if verdict == Verdict.WATCH:
            return Sizing.SKIP
        # TAKE — grade decides FULL vs HALF.
        if grade == GradeLetter.A:
            return Sizing.FULL
        if grade == GradeLetter.B:
            return Sizing.HALF
        # Grade C/D with TAKE verdict is inconsistent but possible at
        # boundary. Defensive default: HALF.
        return Sizing.HALF
