"""scripts/run_phase_calibration.py — OOS threshold calibration.

Calibrates ``PhaseThresholds`` in ``nimbus_v3.analysis.trend_phase``
against actual forward-return outcomes from the equity panel.
Produces three diagnostic outputs:

1. **Bucket statistics** — for each decile of extension,
   acceleration, and BB %B, the mean forward return (5d, 10d, 20d)
   and the mean max drawdown in the next 20 bars. If the classifier
   is meaningful, higher-decile buckets on "risk" features should
   underperform lower deciles.

2. **Phase statistics** — for each phase label (EARLY / MID / LATE /
   EUPHORIA), the same forward-return + drawdown metrics. A
   well-calibrated classifier will show a monotonic return drop and
   drawdown increase going from EARLY → EUPHORIA.

3. **Threshold sweep** — grid search over the three extension
   cutoffs (healthy, mature, euphoric) to find the set that
   maximizes the 20d return spread between EARLY and EUPHORIA
   buckets. Prints the winning combination.

Run from repo root with the equity panel cached::

    python scripts/run_phase_calibration.py

Outputs to ``data/phase_calibration.csv`` and stdout.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# Make the repo root importable when run directly.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nimbus_v3.analysis.trend_phase import (   # noqa: E402
    PhaseThresholds, TrendPhase,
)
from nimbus_v3.research.equity_universe import load_equity_panel   # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════
# Feature extraction
# ══════════════════════════════════════════════════════════════════════

#: Horizons swept for return/drawdown calibration. Extended to 60
#: bars (≈3 months) so we can see where each phase's edge plateaus
#: or decays. User trades at most 10 bars; the longer horizons are
#: diagnostic only ("how long does the edge persist if held longer").
HORIZONS: tuple[int, ...] = tuple(range(1, 61))

#: Columns displayed in the horizon tables. Subset of HORIZONS —
#: printing all 60 columns is unreadable; these cover daily, weekly,
#: and monthly reference points with emphasis on the user's actual
#: holding window plus the long-tail horizons needed to spot phase
#: momentum decay.
_DISPLAY_HORIZONS: tuple[int, ...] = (1, 2, 3, 5, 7, 10, 15, 20, 30, 45, 60)


def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    """Compute classifier inputs + forward returns + max drawdowns
    at every horizon in :data:`HORIZONS`. The bar count expands
    (~40 forward columns at H=1..20) but downstream reports can now
    find the optimal holding window empirically instead of being
    anchored on an arbitrary 5/10/20 day choice.

    Features include ``roc_10`` and ``vol_chg_20`` which the
    classifier's quality gates consume (deceleration / distribution
    / V-recovery checks). Must match the formulas in Market Pulse's
    ``_compute_metrics_from_series`` so calibration aligns with UI.
    """
    close = df["Close"].astype(float)
    volume = df["Volume"].astype(float) if "Volume" in df.columns else None
    out = pd.DataFrame(index=df.index)
    out["close"] = close
    out["sma_20"] = close.rolling(20).mean()
    out["sma_50"] = close.rolling(50).mean()
    # BB bands — 1σ upper/lower, matching the system's "ride zone"
    # convention. %B = (close - lower) / (upper - lower).
    std20 = close.rolling(20).std()
    bb_upper = out["sma_20"] + std20
    bb_lower = out["sma_20"] - std20
    out["bb_pct"] = (close - bb_lower) / (bb_upper - bb_lower).replace(0, np.nan)
    # ROC windows for the classifier.
    out["roc_5"] = close.pct_change(5) * 100
    out["roc_10"] = close.pct_change(10) * 100
    out["roc_20"] = close.pct_change(20) * 100

    # Volume regime — multiple candidate windows for ablation testing.
    # The 20d-vs-prior-20d signal is the one currently used in the
    # classifier; the 30/45/60 variants are candidates for replacing
    # or augmenting it. ``vol_ratio_60`` probes a different topology:
    # is THIS WEEK's volume unusual compared to the last quarter's
    # average? That pattern (quiet base → ramping week) is the exact
    # signature of early accumulation off a bottom.
    #
    # See scripts/run_gate_ablation.py for the ablation that decides
    # which (if any) of these earn forward-return edge over the
    # existing vol_chg_20.
    if volume is not None:
        v20 = volume.rolling(20).mean()
        v_prior_20 = volume.shift(20).rolling(20).mean()
        out["vol_chg_20"] = (v20 / v_prior_20 - 1) * 100

        v30 = volume.rolling(30).mean()
        v_prior_30 = volume.shift(30).rolling(30).mean()
        out["vol_chg_30"] = (v30 / v_prior_30 - 1) * 100

        v45 = volume.rolling(45).mean()
        v_prior_45 = volume.shift(45).rolling(45).mean()
        out["vol_chg_45"] = (v45 / v_prior_45 - 1) * 100

        v60 = volume.rolling(60).mean()
        v_prior_60 = volume.shift(60).rolling(60).mean()
        out["vol_chg_60"] = (v60 / v_prior_60 - 1) * 100

        # Cross-window ratio: last 5d mean over last 60d mean.
        # Captures "this week's volume vs the last quarter's" — a
        # different signature than N-vs-prior-N. For AWL-style
        # accumulation-after-capitulation, this spikes positively
        # the moment the volume base rebuilds, without needing the
        # full 60d to have elapsed since the capitulation event.
        v5 = volume.rolling(5).mean()
        out["vol_ratio_60"] = (v5 / v60 - 1) * 100
    else:
        out["vol_chg_20"] = 0.0
        out["vol_chg_30"] = 0.0
        out["vol_chg_45"] = 0.0
        out["vol_chg_60"] = 0.0
        out["vol_ratio_60"] = 0.0

    # Forward returns + max drawdowns for every horizon in HORIZONS.
    # fwd_Hd  = return from t to t+H (H-day hold outcome)
    # fwd_dd_Hd = max drawdown within the H-bar forward window
    #             relative to entry at t (intra-hold pain). Clamped
    #             at 0 — if every forward close was above entry, the
    #             "min" is above entry and the raw (min/close - 1)
    #             would be positive, which is nonsensical for a
    #             drawdown measure.
    # Build all forward columns in a single pd.concat rather than
    # iterative assignment — avoids the 120-way DataFrame
    # fragmentation and shaves seconds off each symbol.
    fwd_cols: dict[str, pd.Series] = {}
    for h in HORIZONS:
        fwd_cols[f"fwd_{h}d"] = close.shift(-h) / close - 1
        fwd_window_min = close.rolling(h, min_periods=1).min().shift(-h)
        fwd_cols[f"fwd_dd_{h}d"] = np.minimum(
            0.0, fwd_window_min / close - 1,
        )

    out = pd.concat(
        [out, pd.DataFrame(fwd_cols, index=close.index)], axis=1,
    )
    return out.dropna()


def classify_rows(
    feats: pd.DataFrame, thresh: PhaseThresholds,
) -> pd.Series:
    """Vectorised phase classification — same logic as
    :func:`classify_phase` but over a full feature table.

    Why vectorised: the per-row version uses ``df.iterrows()``, which
    costs ~10µs per row in Python. On a 500-symbol × 6-year panel
    that's ~750k rows → ~7.5s per threshold triple, and the sweep
    evaluates ~50 triples → multiple minutes for the sweep alone.
    The vectorised form is pure numpy boolean masking so it's bound
    by memory bandwidth rather than interpreter overhead — typically
    500-1000x faster.

    Quality gates (above_20, ROC floors, deceleration, distribution,
    V-recovery) are applied AFTER the base phase assignment, then
    qualifying rows get demoted to NEUTRAL. This mirrors the order
    in classify_phase so the output label distribution matches the
    scalar function on every row.
    """
    close = feats["close"].to_numpy()
    sma_20 = feats["sma_20"].to_numpy()
    sma_50 = feats["sma_50"].to_numpy()
    roc_5 = feats["roc_5"].to_numpy()
    roc_10 = feats["roc_10"].to_numpy() if "roc_10" in feats.columns else np.zeros(len(feats))
    roc_20 = feats["roc_20"].to_numpy()
    bb_pct = feats["bb_pct"].to_numpy()
    vol_chg_20 = (
        feats["vol_chg_20"].to_numpy()
        if "vol_chg_20" in feats.columns
        else np.zeros(len(feats))
    )
    # Prefer vol_chg_60 when the column is present (stronger empirical
    # edge at the 20d horizon per volume research). Fall back to
    # vol_chg_20 when the 60d window isn't in the table — keeps legacy
    # panels and minimal-feature tests working.
    vol_chg_signal = (
        feats["vol_chg_60"].to_numpy()
        if "vol_chg_60" in feats.columns
        else vol_chg_20
    )

    # Guard against degenerate SMA_50 — keep the same handling as
    # the scalar classifier (treat as NEUTRAL).
    with np.errstate(divide="ignore", invalid="ignore"):
        ext_pct = np.where(
            sma_50 > 0, (close - sma_50) / sma_50 * 100.0, 0.0,
        )
    roc_accel = roc_5 - roc_20
    above_20 = close > sma_20
    above_50 = close > sma_50

    # Start everyone at NEUTRAL, then override with more specific
    # labels. Order matters: later overrides win, but the masks are
    # mutually exclusive by construction so the order is just for
    # readability.
    phases = np.full(len(feats), TrendPhase.NEUTRAL.value, dtype=object)

    # Below SMA_50 → DECLINE when also below SMA_20, else NEUTRAL.
    phases[(~above_50) & (~above_20)] = TrendPhase.DECLINE.value

    # Above SMA_50 → base phase by extension + BB + acceleration.
    # These are the "what phase would this stock be in ignoring all
    # the quality gates" labels — then the quality-gate masks below
    # demote qualifying rows to NEUTRAL.
    in_uptrend = above_50 & (sma_50 > 0)

    euphoria = (
        in_uptrend
        & (ext_pct >= thresh.ext_euphoric)
        & ((roc_accel > 0) | (bb_pct >= thresh.bb_parabolic))
    )
    late = (
        in_uptrend & ~euphoria
        & ((ext_pct >= thresh.ext_mature) | (bb_pct >= thresh.bb_stretched))
    )
    mid = (
        in_uptrend & ~euphoria & ~late
        & (ext_pct >= thresh.ext_healthy)
    )
    early = in_uptrend & ~euphoria & ~late & ~mid

    # ── Quality gates (ablation-validated) ─────────────────────────────
    # Only gates that earned empirical forward-return edge in the 569k-
    # row ablation are applied. See scripts/run_gate_ablation.py and
    # data/gate_ablation.csv for the numbers. Summary:
    #
    #   Gate                 Phase      Δ fwd10    t-stat     Kept?
    #   ────────────────────────────────────────────────────────────
    #   roc_20 < -3%         EUPHORIA   -1.60pp    -1.68      yes (conservative, weak)
    #   distribution         EUPHORIA   -2.03pp    -2.14      yes (small-n but strong direction)
    #   roc_20 < -2%         LATE       -1.22pp    -5.84      yes (strongest gate)
    #   v_recovery           LATE       -0.38pp    -2.14      yes (weak but real)
    #   every MID gate       MID        +0.03-0.55pp +0.27-+10.33  NO (harmful or noise)
    #   every EARLY gate     EARLY      +0.04-+0.26pp +0.39-+4.40  NO (noise or weakly harmful)
    #   distribution         LATE       +0.29pp    +1.31      NO (inconclusive, wrong direction)
    #   v_recovery           EUPHORIA   +0.14pp    +0.13      NO (noise, tiny n)
    #
    # MID and EARLY therefore get NO quality gates — base phase wins.
    v_recovery = (
        (roc_20 > 0) & (roc_20 < 8.0)
        & (roc_10 > 10.0)
        & (roc_10 > 2.5 * roc_20)
    )
    distribution = (roc_5 < 0) & (vol_chg_signal < -40.0)

    # EUPHORIA: ROC_20 < -3% OR distribution.
    euphoria_fail = euphoria & ((roc_20 < -3.0) | distribution)
    # LATE: ROC_20 < -2% OR V-recovery.
    late_fail = late & ((roc_20 < -2.0) | v_recovery)
    # MID and EARLY: no gates.

    # Apply base labels.
    phases[euphoria] = TrendPhase.EUPHORIA.value
    phases[late] = TrendPhase.LATE.value
    phases[mid] = TrendPhase.MID.value
    phases[early] = TrendPhase.EARLY.value
    # Apply quality-gate demotions. Failed rows land in NEUTRAL.
    phases[euphoria_fail | late_fail] = TrendPhase.NEUTRAL.value

    return pd.Series(phases, index=feats.index, name="phase")


# ══════════════════════════════════════════════════════════════════════
# Reports
# ══════════════════════════════════════════════════════════════════════

def report_buckets(feats: pd.DataFrame, col: str, label: str) -> None:
    """Decile-bucket by one feature and report forward-return stats."""
    print(f"\n── Buckets by {label} ──────────────────────────────")
    print(f"{'decile':>8s}  {'range':>18s}  {'n':>6s}  "
          f"{'fwd_5d':>9s}  {'fwd_10d':>9s}  {'dd_10d':>9s}")
    try:
        feats["_bucket"] = pd.qcut(feats[col], 10, duplicates="drop")
    except ValueError:
        print(f"  (insufficient spread in {col} to bucket)")
        return
    for i, (bkt, sub) in enumerate(feats.groupby("_bucket", observed=True)):
        print(
            f"{i+1:>8d}  {str(bkt):>18s}  {len(sub):>6d}  "
            f"{sub['fwd_5d'].mean()*100:>8.2f}%  "
            f"{sub['fwd_10d'].mean()*100:>8.2f}%  "
            f"{sub['fwd_dd_10d'].mean()*100:>8.2f}%"
        )
    feats.drop(columns="_bucket", inplace=True)


def report_horizon_returns(feats: pd.DataFrame) -> None:
    """Full forward-return curve per phase.

    One row per phase, one column per display horizon. This is what
    the user called "consecutive returns" — how the cumulative
    holding-period return evolves as you hold for longer. Plateau or
    rollover points are visible directly in the numbers.
    """
    print("\n── Forward RETURN by phase × horizon (%) ────────────")
    header = f"{'phase':>10s} {'n':>6s}" + "".join(
        f"{'H='+str(h):>9s}" for h in _DISPLAY_HORIZONS
    )
    print(header)
    for phase in (TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE,
                  TrendPhase.EUPHORIA, TrendPhase.NEUTRAL, TrendPhase.DECLINE):
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        cells = "".join(
            f"{sub[f'fwd_{h}d'].mean()*100:>8.2f}%" for h in _DISPLAY_HORIZONS
        )
        print(f"{phase.value:>10s} {len(sub):>6d}{cells}")

    print("\n── Forward MAX-DD by phase × horizon (%) ────────────")
    print(header)
    for phase in (TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE,
                  TrendPhase.EUPHORIA, TrendPhase.NEUTRAL, TrendPhase.DECLINE):
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        cells = "".join(
            f"{sub[f'fwd_dd_{h}d'].mean()*100:>8.2f}%" for h in _DISPLAY_HORIZONS
        )
        print(f"{phase.value:>10s} {len(sub):>6d}{cells}")


def report_steam_curve(feats: pd.DataFrame) -> None:
    """Phase momentum decay analysis.

    Answers "at what horizon does each phase's edge stop earning
    its keep?". Two complementary views:

    - **Per-day return rate** (``ret(H) / H``): average daily return
      if held for exactly H days. A phase at peak momentum shows a
      high, stable rate; decay shows up as the rate falling toward
      the all-population baseline.
    - **Marginal return** (``ret(H) - ret(H-1)``): the incremental
      return from holding one more day at horizon H. This is the
      day-by-day return contribution. When marginal return drops
      below the baseline daily return, that day added nothing above
      average — the edge is gone.

    For each phase we then report the horizon where the per-day
    rate peaks, and — for phases with a clear decay pattern — the
    horizon where marginal return crosses below the all-population
    baseline ("steam lost at H=X").
    """
    # Baseline = expected daily return across ALL observations,
    # regardless of phase. If a phase's marginal return at day H
    # falls below this baseline, that day was "average"; below it
    # means holding that extra day is a drag relative to rolling
    # over to a fresh signal.
    baseline_per_day = feats["fwd_1d"].mean()
    print("\n── Per-day return rate by phase × horizon (%) ───────")
    print(f"  baseline (all obs, H=1 mean): {baseline_per_day*100:.3f}%/day")
    header = f"{'phase':>10s} {'n':>6s}" + "".join(
        f"{'H='+str(h):>9s}" for h in _DISPLAY_HORIZONS
    )
    print(header)
    for phase in (TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE,
                  TrendPhase.EUPHORIA, TrendPhase.NEUTRAL, TrendPhase.DECLINE):
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        cells = "".join(
            f"{sub[f'fwd_{h}d'].mean()/h*100:>8.3f}%"
            for h in _DISPLAY_HORIZONS
        )
        print(f"{phase.value:>10s} {len(sub):>6d}{cells}")

    print("\n── Marginal return per added day (%) ────────────────")
    print("  = ret(H) - ret(H-1): the return from the H-th day specifically")
    print(header)
    for phase in (TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE,
                  TrendPhase.EUPHORIA, TrendPhase.NEUTRAL, TrendPhase.DECLINE):
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        cells = ""
        for h in _DISPLAY_HORIZONS:
            if h == 1:
                marg = sub[f"fwd_1d"].mean()
            else:
                marg = sub[f"fwd_{h}d"].mean() - sub[f"fwd_{h-1}d"].mean()
            cells += f"{marg*100:>8.3f}%"
        print(f"{phase.value:>10s} {len(sub):>6d}{cells}")

    # Per-phase steam-loss point: the horizon where the phase's
    # per-day rate falls below baseline + 50% (soft decay line). If
    # this never happens within HORIZONS, note it explicitly.
    print("\n── Momentum decay points ────────────────────────────")
    print("  peak     = horizon where per-day rate is highest")
    print("  plateau  = horizon where per-day rate first dips below "
          "peak × 0.85")
    print("  exhausted= horizon where per-day rate first dips below "
          "all-obs baseline")
    print(f"{'phase':>10s}  {'n':>7s}  {'peak H':>6s}  "
          f"{'peak %/d':>9s}  {'plateau':>8s}  {'exhausted':>9s}")
    for phase in (TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE,
                  TrendPhase.EUPHORIA, TrendPhase.NEUTRAL, TrendPhase.DECLINE):
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        rates = [
            (h, sub[f"fwd_{h}d"].mean() / h) for h in HORIZONS
        ]
        # Skip H=1 for peak-finding — it's a 1-bar outcome and the
        # noise dominates; peak typically shows up between H=2..10.
        peak_h, peak_rate = max(rates[1:], key=lambda x: x[1])
        plateau_threshold = peak_rate * 0.85
        plateau_h = next(
            (h for h, r in rates if h > peak_h and r < plateau_threshold),
            None,
        )
        exhausted_h = next(
            (h for h, r in rates if h > peak_h and r < baseline_per_day),
            None,
        )
        plateau_s = f"H={plateau_h}" if plateau_h else "—"
        exhausted_s = f"H={exhausted_h}" if exhausted_h else "—"
        print(f"{phase.value:>10s}  {len(sub):>7d}  H={peak_h:<4d}  "
              f"{peak_rate*100:>8.3f}%  {plateau_s:>8s}  {exhausted_s:>9s}")


def report_best_horizon(
    feats: pd.DataFrame, max_horizon: int, label: str,
) -> None:
    """For each phase, find the holding horizon H ∈ [1, max_horizon]
    that maximises the return/|drawdown| ratio.

    This is the "best holding period" answer. Each phase gets its
    own optimum because the shape of the return curve differs: some
    phases front-load gains (short horizon wins), others compound
    steadily (longer horizon wins).
    """
    print(f"\n── Optimal horizon per phase (H ≤ {max_horizon}) "
          f"— {label} ──")
    print(f"{'phase':>10s}  {'n':>7s}  {'H*':>3s}  "
          f"{'ret(%)':>8s}  {'dd(%)':>8s}  {'ret/|dd|':>9s}")
    rows = []
    for phase in (TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE,
                  TrendPhase.EUPHORIA, TrendPhase.NEUTRAL, TrendPhase.DECLINE):
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        best_h, best_ratio = 0, -1e9
        for h in range(1, max_horizon + 1):
            r = sub[f"fwd_{h}d"].mean()
            dd = sub[f"fwd_dd_{h}d"].mean()
            if dd >= 0:
                continue
            ratio = r / abs(dd)
            if ratio > best_ratio:
                best_ratio = ratio
                best_h = h
        if best_h == 0:
            continue
        r = sub[f"fwd_{best_h}d"].mean() * 100
        dd = sub[f"fwd_dd_{best_h}d"].mean() * 100
        rows.append({
            "phase": phase.value, "n": len(sub), "best_h": best_h,
            "ret_pct": r, "dd_pct": dd, "ratio": best_ratio,
        })
        print(f"{phase.value:>10s}  {len(sub):>7d}  {best_h:>3d}  "
              f"{r:>7.2f}%  {dd:>7.2f}%  {best_ratio:>9.3f}")
    return rows


def report_best_horizon_overall(
    feats: pd.DataFrame, max_horizon: int,
) -> None:
    """Find the single best horizon across the whole population
    (ignoring phase) — the generic "if I had to pick one holding
    period for everything, what would it be?" answer."""
    print(f"\n── Optimal horizon overall (H ≤ {max_horizon}) ──────")
    print(f"{'H':>3s}  {'ret(%)':>8s}  {'dd(%)':>8s}  {'ret/|dd|':>9s}")
    best_h, best_ratio = 0, -1e9
    for h in range(1, max_horizon + 1):
        r = feats[f"fwd_{h}d"].mean()
        dd = feats[f"fwd_dd_{h}d"].mean()
        if dd >= 0:
            continue
        ratio = r / abs(dd)
        star = "  ← best" if ratio > best_ratio else ""
        if ratio > best_ratio:
            best_ratio = ratio
            best_h = h
        print(f"{h:>3d}  {r*100:>7.2f}%  {dd*100:>7.2f}%  {ratio:>9.3f}{star}")
    print(f"\n  Best overall: H={best_h}")


# ══════════════════════════════════════════════════════════════════════
# Feature screening — 80/20 filter on candidate classifier inputs
# ══════════════════════════════════════════════════════════════════════

#: Candidate features currently being screened. Empty post-
#: screening — the initial four candidates (vol_ratio_20, vol_trend,
#: trend_age, rs_vs_market) all failed the 80/20 test on NIFTY 500
#: 2020-2026 data: none produced ≥0.8% forward-return spread in ≥2
#: trending phases. Feature computation + screen report are kept so
#: future candidate batches can be added, screened, and integrated
#: without rewriting infrastructure. To screen new features:
#:   1. Compute them in ``compute_features``.
#:   2. Add their names to this tuple.
#:   3. Re-run the calibration.
#:   4. Promote survivors to the classifier; delete the rest.
_CANDIDATE_FEATURES: tuple[str, ...] = ()

#: Spread thresholds at the 10-day horizon. Tune these to shift the
#: verdict strictness. 0.8% is deliberately high — the phase labels
#: already produce ~2% spreads between EARLY and EUPHORIA, so a
#: candidate needs material independent signal to add value.
_THRESHOLD_HARD_HIT: float = 0.8    # %
_THRESHOLD_MODEST: float = 0.3      # %

#: Phases where discrimination matters most. Adding signal inside
#: NEUTRAL/DECLINE is low-leverage — we don't trade those states.
_TRENDING_PHASES: tuple[TrendPhase, ...] = (
    TrendPhase.EARLY, TrendPhase.MID, TrendPhase.LATE, TrendPhase.EUPHORIA,
)


def report_feature_screen(feats: pd.DataFrame) -> None:
    """Median-split analysis per (phase, feature).

    For each candidate feature F, within each phase:
      1. Split the phase's observations by F's median.
      2. Compare mean fwd_5d and fwd_10d across the two halves.
      3. The spread = F's extra discriminating power *beyond* what
         the phase label already captures.

    Output groups features by overall verdict so you can skim for
    keepers.
    """
    if not _CANDIDATE_FEATURES:
        print("\n── Feature screen — no candidates pending ──────")
        print("  The previous screening round found no survivors on the")
        print("  NIFTY 500 2020-2026 panel. To screen new candidates, add")
        print("  them to ``compute_features`` and ``_CANDIDATE_FEATURES``.")
        return

    print("\n── Feature screen — within-phase median split ──────")
    print("  spread = high-feature-half return minus low-feature-half return")
    print(f"  HARD-HIT threshold at H=10:  |spread| ≥ {_THRESHOLD_HARD_HIT}%")
    print(f"  modest threshold at H=10:    |spread| ≥ {_THRESHOLD_MODEST}%\n")

    # Aggregate per-phase results per feature for the summary.
    summary: dict[str, list[str]] = {f: [] for f in _CANDIDATE_FEATURES}

    for feat in _CANDIDATE_FEATURES:
        if feat not in feats.columns:
            print(f"  (skipping {feat} — not in feature table)")
            continue
        print(f"── {feat} ─────────────────────────────────────────")
        print(f"{'phase':>10s}  {'n':>6s}  {'median':>10s}  "
              f"{'spread_5d':>10s}  {'spread_10d':>11s}  verdict")
        for phase in _TRENDING_PHASES + (TrendPhase.NEUTRAL, TrendPhase.DECLINE):
            sub = feats[feats["phase"] == phase.value].dropna(subset=[feat])
            if len(sub) < 200:
                continue
            median = sub[feat].median()
            low = sub[sub[feat] < median]
            high = sub[sub[feat] >= median]
            if len(low) < 100 or len(high) < 100:
                continue
            spread_5d = (high["fwd_5d"].mean() - low["fwd_5d"].mean()) * 100
            spread_10d = (high["fwd_10d"].mean() - low["fwd_10d"].mean()) * 100
            abs_s = abs(spread_10d)
            if abs_s >= _THRESHOLD_HARD_HIT:
                verdict = "HARD-HIT"
                if phase in _TRENDING_PHASES:
                    summary[feat].append(phase.value)
            elif abs_s >= _THRESHOLD_MODEST:
                verdict = "modest"
            else:
                verdict = "noise"
            print(f"{phase.value:>10s}  {len(sub):>6d}  {median:>10.3f}  "
                  f"{spread_5d:>+9.2f}%  {spread_10d:>+10.2f}%  {verdict}")
        print()

    # Summary verdict.
    print("── Overall verdict ─────────────────────────────────")
    print("  KEEP: hard-hit in ≥2 trending phases (real signal)")
    print("  discard: hard-hit in 0 or 1 trending phases (noise or phase-specific)\n")
    print(f"{'feature':>18s}  {'hard-hit phases':>24s}  verdict")
    keepers: list[str] = []
    for feat, hit_phases in summary.items():
        verdict = "KEEP" if len(hit_phases) >= 2 else "discard"
        if verdict == "KEEP":
            keepers.append(feat)
        phases_str = ", ".join(hit_phases) if hit_phases else "—"
        print(f"{feat:>18s}  {phases_str:>24s}  {verdict}")

    print()
    if keepers:
        print(f"  Survivors ({len(keepers)}): {', '.join(keepers)}")
        print(f"  → integrate these into the classifier + drop the rest from compute_features")
    else:
        print("  No survivors. The phase labels are already capturing the")
        print("  signal; none of the candidate features add material")
        print("  independent discrimination at the 10-day horizon.")


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def _verify_classifier_consistency(feats: pd.DataFrame) -> None:
    """Cross-check: run the scalar ``classify_phase`` on a sample and
    compare to the vectorised ``classify_rows``. They must agree.

    Raises AssertionError with a diff if they don't. This is the
    guardrail that prevents silent drift between the two classifier
    paths — the exact failure mode this calibration script had until
    the quality-gate sync in April 2026 (gates existed in the scalar
    function but not the vectorised mirror, so calibration was
    measuring forward returns against a classifier that no longer
    matched the UI).
    """
    from nimbus_v3.analysis.trend_phase import classify_phase

    # Sample 500 random rows — enough to catch logic bugs but fast
    # enough to not delay the calibration noticeably.
    sample = feats.dropna(subset=["sma_50", "roc_5", "roc_10", "roc_20", "bb_pct"]).sample(
        n=min(500, len(feats)), random_state=42,
    )
    vec_labels = classify_rows(sample, PhaseThresholds())
    mismatches: list[tuple[int, str, str]] = []
    for idx, row in sample.iterrows():
        scalar = classify_phase(
            close=float(row["close"]),
            sma_20=float(row["sma_20"]),
            sma_50=float(row["sma_50"]),
            roc_5=float(row["roc_5"]),
            roc_20=float(row["roc_20"]),
            bb_pct=float(row["bb_pct"]),
            roc_10=float(row.get("roc_10", 0.0)),
            vol_chg_20=float(row.get("vol_chg_20", 0.0)),
        ).phase.value
        vec = vec_labels.loc[idx]
        if scalar != vec:
            mismatches.append((idx, scalar, vec))

    if mismatches:
        msg = [f"classify_rows / classify_phase disagree on {len(mismatches)}/{len(sample)} rows"]
        for idx, scalar, vec in mismatches[:10]:
            msg.append(f"  row {idx}: scalar={scalar} vectorised={vec}")
        if len(mismatches) > 10:
            msg.append(f"  ... and {len(mismatches) - 10} more")
        raise AssertionError("\n".join(msg))

    log.info("Classifier consistency verified (%d rows sampled, 0 mismatches)", len(sample))


def main() -> None:
    log.info("Loading equity panel...")
    panel = load_equity_panel(verbose=False)
    log.info("Panel loaded: %d symbols", len(panel))

    all_rows: list[pd.DataFrame] = []
    for sym, df in panel.items():
        feats = compute_features(df)
        if len(feats) < 100:
            continue
        feats["symbol"] = sym
        all_rows.append(feats)

    feats = pd.concat(all_rows, ignore_index=True)
    log.info("Feature table: %d rows across %d symbols",
             len(feats), feats["symbol"].nunique())

    # Guardrail: confirm the scalar and vectorised classifiers agree
    # on a 500-row sample before running 700k rows through the fast
    # path. Fails loud if they've drifted.
    _verify_classifier_consistency(feats)

    # Feature distributions — bucket by each classifier input, using
    # 5d and 10d forward returns (the user's actual horizon).
    feats["ext_pct"] = (feats["close"] - feats["sma_50"]) / feats["sma_50"] * 100
    feats["roc_accel"] = feats["roc_5"] - feats["roc_20"]
    report_buckets(feats, "ext_pct", "Extension above SMA_50 (%)")
    report_buckets(feats, "roc_accel", "ROC acceleration (ROC_5 - ROC_20)")
    report_buckets(feats, "bb_pct", "Bollinger %B")

    # Phase statistics at default thresholds.
    feats["phase"] = classify_rows(feats, PhaseThresholds())

    # Full return + DD curves per phase across horizons 1..60.
    report_horizon_returns(feats)

    # Momentum decay analysis — finds the peak per-day rate and the
    # horizon where each phase loses its edge. This is how you answer
    # "when does EUPHORIA lose steam".
    report_steam_curve(feats)

    # Best holding horizon — two caps to give context on both sides
    # of the stated 10-day ceiling.
    report_best_horizon(feats, max_horizon=10,
                        label="user's max holding")
    report_best_horizon(feats, max_horizon=20,
                        label="extended context")
    report_best_horizon_overall(feats, max_horizon=10)

    # Candidate feature screen — 80/20 filter. Only features that
    # produce a meaningful forward-return spread within trending
    # phases get flagged as keepers for integration into the
    # classifier.
    report_feature_screen(feats)

    # Persist the full horizon × phase matrix for downstream analysis.
    rows: list[dict] = []
    for phase in TrendPhase:
        sub = feats[feats["phase"] == phase.value]
        if len(sub) < 50:
            continue
        row = {"phase": phase.value, "n": len(sub)}
        for h in HORIZONS:
            row[f"ret_{h}d"] = sub[f"fwd_{h}d"].mean()
            row[f"dd_{h}d"] = sub[f"fwd_dd_{h}d"].mean()
        rows.append(row)

    out_df = pd.DataFrame(rows)
    out_path = Path("data/phase_calibration.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    log.info("\nFull horizon matrix written to %s", out_path)
    log.info("\nPhase summary written to %s", out_path)


if __name__ == "__main__":
    main()
