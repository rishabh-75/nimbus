# Retired: Ride Phase Classification + Composite Conviction Score

**Retired:** 2026-06-18
**Reason:** Replaced by the cohort-relative Early-Entry score (see
`compute/early_entry.py`). The operator's thesis shifted to "enter as
early as possible in a fresh band-ride, prioritise the just-starting
names over the already-extended ones" — a ranking problem, not a
phase-classification one. The 3-phase model + 5-factor composite score
encoded a different (entry-quality-at-any-stage) philosophy that no
longer matched how the desk wanted to trade.
**Restorable:** yes — formulas + design preserved below.

## What this was

Two coupled pieces inside `compute/ride_initiation/`:

### 1. Phase classifier (3 phases)
Per-bar classification of where a symbol sits in a Bollinger-band ride,
resolved by priority **INITIATION > RETEST > CONTINUATION > NONE**:

- **INITIATION** — fresh break: body clears the upper BB after a base.
- **RETEST** — pulled back toward the band then resumed (within
  `RETEST_PULLBACK_MAX_BARS` / `RETEST_ACTIVE_WINDOW`).
- **CONTINUATION** — sustained ride above the band.

Each phase had a stateless "fire" detector; the bar's phase was the
highest-priority detector that fired. An industry/group variant
classified a synthetic equal-weight index the same way.

### 2. Composite conviction score (0–100)
Computed only where a phase fired. Weighted sum of five sub-scores,
each normalised 0–100:

| Component | Weight | Definition |
|-----------|--------|------------|
| FRESHNESS | 30% | `100 − 25 × bars_since_base`, clipped 0–100 |
| VOLUME | 25% | `(Volume / vol_sma_20) × (100/3)`, capped at 3× |
| BBW_QUALITY | 20% | base-was-tight (50pts) + BBW-expanding-now (50pts) |
| MOMENTUM | 15% | `sma20_slope / sma_20 × 100000`, clipped 0–100 |
| BODY_CLEANNESS | 10% | `(body/range − 0.35) / 0.65 × 100` |

Two post-multipliers applied to the weighted sum:
- **Over-extension factor**: 1.0 below %B 1.4, ramping down to a 0.55
  floor at %B ≥ 1.7 (penalise chasing a stretched break).
- **Liquidity factor**: 1.0 at ADTV ≥ ₹1B down to a 0.6 floor at
  ADTV ≤ ₹50M.

### Reference classifications (old regression anchors)
On the 4 reference parquets (now superseded as anchors):
`AWL=RETEST 40.9, CLEAN=CONT 26.9, CIPLA=CONT 36.3, SUNPHARMA=CONT 36.7`.
Enrichment `schema_hash=3eb7942e` is **unaffected** — enrichment
(BB/ATR/BBW columns) is unchanged; only the phase/score *consumers* of
it were removed.

## What was KEPT (not retired)

The band-geometry primitives moved to `compute/band_ride.py`, because
the new score + the Above/Streak columns + industry "Riding" count all
depend on them:
- `body_above_band(df)` — BOTH Open and Close > upper BB (canonical).
- `last_body_above(df)` — is the last bar body-above.
- `body_above_streak(df)` — trailing consecutive body-above bars.

## What was DISCARDED outright

`research/phase_p_win/` (RT-002 exploratory phase P(win) study, ~5
modules) — judged irrelevant by the operator, not preserved in detail.
It studied forward win-rate conditioned on phase; superseded by the
early-entry direction. RT-002's log entry is marked superseded.

## If restoring

The phase model is reconstructable from the priority resolution + the
five fire detectors (criteria in the old `constants.py`: BB break,
retest pullback windows, continuation lookback). The score is the table
above. But note: the new direction deliberately rejects phase-based
entry-quality in favour of cohort-relative freshness ranking — restoring
this would be a philosophy reversal, not a bug fix.
