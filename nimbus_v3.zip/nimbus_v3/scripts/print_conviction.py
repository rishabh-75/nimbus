"""scripts.print_conviction — placeholder. Implemented in a later phase."""
from __future__ import annotations

import sys


def main() -> int:
    print(
        "scripts.print_conviction is not yet implemented. "
        "See docs/ARCHITECTURE.md §16 for the phase plan.",
        file=sys.stderr,
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
