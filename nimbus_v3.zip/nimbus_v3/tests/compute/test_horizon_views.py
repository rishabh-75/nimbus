"""Tests for the shared strength-horizon engine.

The property under test is COHERENCE: within one horizon, Confluence
Strength and Edge RS Excess must be the same number, because they are the
same quantity. That is the whole reason the two tabs share one control.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.horizon_views import (
    HorizonSet,
    compute_horizon_views,
)
from nimbus_v3.compute.industry_rotation import compute_industry_rotation
from nimbus_v3.compute.industry_seasonality import (
    compute_industry_seasonality,
)
from nimbus_v3.compute.market_pulse_config import (
    DEFAULT_EDGE_HORIZON,
    EDGE_HORIZONS,
)
from nimbus_v3.compute.rrg import compute_rrg


def _fixture():
    rng = np.random.default_rng(23)
    dates = pd.bdate_range("2022-01-03", periods=500)
    panel, members = {}, {}
    for ind, drift in (("Alpha", 0.0020), ("Beta", 0.0000),
                       ("Gamma", -0.0015), ("Delta", 0.0010)):
        members[ind] = []
        for k in range(6):
            c = 1000 * np.exp(np.cumsum(rng.normal(drift, 0.011, len(dates))))
            sym = f"{ind[:2].upper()}{k}"
            panel[sym] = pd.DataFrame({
                "Open": c, "High": c * 1.01, "Low": c * 0.99, "Close": c,
                "Volume": np.full(len(dates), 250000.0),
                "atr_14_pct": np.full(len(dates), 2.0),
            }, index=dates)
            members[ind].append(sym)
    bench = pd.Series(
        1000 * np.exp(np.cumsum(rng.normal(0.0005, 0.007, len(dates)))),
        index=dates)
    return panel, members, bench


def _build(horizons=EDGE_HORIZONS):
    panel, members, bench = _fixture()
    rrg = compute_rrg(members, panel, bench, lookback=50)
    seas_all = compute_industry_seasonality(members, panel,
                                            min_member_years=0)
    seas_stable = compute_industry_seasonality(members, panel,
                                               min_member_years=3)
    hs = compute_horizon_views(
        members, panel, rrg, seas_all, seas_stable,
        benchmark_close=bench, month=6, horizons=horizons)
    return hs, panel, members, bench


def test_builds_a_view_per_horizon():
    hs, *_ = _build()
    assert isinstance(hs, HorizonSet)
    assert hs.horizons == tuple(sorted(EDGE_HORIZONS))
    for h in EDGE_HORIZONS:
        v = hs.get(h)
        assert v.horizon_days == h
        assert v.rotation.lookback == h
        assert v.edge.horizon_days == h
    assert hs.get(7) is None
    assert hs.default.horizon_days == DEFAULT_EDGE_HORIZON


def test_confluence_strength_equals_edge_rs_excess_within_a_horizon():
    """THE invariant: the two tabs render the same quantity.

    If this ever fails, Confluence and Edge are describing different
    markets and the shared horizon control is a lie.
    """
    hs, *_ = _build()
    for h in EDGE_HORIZONS:
        v = hs.get(h)
        strength = {r.industry: r.strength.value
                    for r in v.confluence_stable.rows}
        rs = {}
        for r in v.edge.rows:
            rs.setdefault(r.industry, r.industry_rs_excess)
        shared = set(strength) & set(rs)
        assert shared, f"no overlapping industries at horizon {h}"
        for ind in shared:
            assert abs(strength[ind] - rs[ind]) < 1e-9, (
                f"horizon {h}: {ind} strength {strength[ind]} "
                f"!= edge RS {rs[ind]}")


def test_horizons_actually_differ():
    """A shorter window must re-rank, not merely relabel."""
    hs, *_ = _build()
    a = {r.industry: r.strength.value
         for r in hs.get(10).confluence_stable.rows}
    b = {r.industry: r.strength.value
         for r in hs.get(20).confluence_stable.rows}
    assert a and b
    assert a != b, "horizon control is cosmetic — strength unchanged"


def test_trust_is_horizon_invariant():
    """Trust is a quality gate, not a horizon-scaled return.

    confidence = s_conf * direction * seasonal * breadth, where s_conf
    depends only on strength being PRESENT. None of those vary with the
    strength window, so trust must be identical across horizons — which is
    what makes comparing an edge across windows meaningful at all.
    """
    hs, *_ = _build()
    ref = {r.industry: r.confidence for r in hs.get(20).confluence_stable.rows}
    for h in (10,):
        got = {r.industry: r.confidence
               for r in hs.get(h).confluence_stable.rows}
        for ind in set(ref) & set(got):
            assert abs(ref[ind] - got[ind]) < 1e-9, (
                f"trust moved with horizon at {ind}: "
                f"{ref[ind]} -> {got[ind]} (h={h})")


def test_direction_and_seasonal_are_horizon_invariant():
    """RRG direction and seasonality do not depend on the strength window."""
    hs, *_ = _build()
    def _same(a: float, b: float) -> bool:
        # NaN is a legitimate value here (an industry with no seasonal read
        # shows "—"), and NaN != NaN, so compare NaN-ness explicitly rather
        # than letting a valid unchanged NaN look like a change.
        if a != a and b != b:
            return True
        return abs(a - b) < 1e-9

    ref = {r.industry: (r.direction.value, r.seasonal.value)
           for r in hs.get(20).confluence_stable.rows}
    for h in (10,):
        got = {r.industry: (r.direction.value, r.seasonal.value)
               for r in hs.get(h).confluence_stable.rows}
        for ind in set(ref) & set(got):
            assert all(_same(x, y) for x, y in zip(ref[ind], got[ind])), (
                f"{ind} direction/seasonal moved with horizon (h={h})")


def test_all_and_stable_variants_share_the_rotation():
    """Both seasonality variants sit on the SAME strength anchor."""
    hs, *_ = _build()
    for h in EDGE_HORIZONS:
        v = hs.get(h)
        a = {r.industry: r.strength.value for r in v.confluence_all.rows}
        b = {r.industry: r.strength.value for r in v.confluence_stable.rows}
        for ind in set(a) & set(b):
            assert abs(a[ind] - b[ind]) < 1e-9


def test_supplied_rotation_is_reused():
    panel, members, bench = _fixture()
    rrg = compute_rrg(members, panel, bench, lookback=50)
    seas = compute_industry_seasonality(members, panel, min_member_years=0)
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    hs = compute_horizon_views(
        members, panel, rrg, seas, seas, benchmark_close=bench, month=6,
        horizons=(20,), rotation_by_horizon={20: rot20})
    assert hs.get(20).rotation is rot20


def test_partial_horizon_set_still_has_a_default():
    # A set that deliberately EXCLUDES the configured default (10), so the
    # fallback path is exercised.
    hs, *_ = _build(horizons=(5, 20))
    assert hs.horizons == (5, 20)
    assert hs.get(DEFAULT_EDGE_HORIZON) is None
    assert hs.default.horizon_days == 5      # falls back to shortest
    assert hs.has_data
