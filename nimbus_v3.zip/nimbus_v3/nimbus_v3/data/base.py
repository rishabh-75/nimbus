"""nimbus_v3.data.base — shared protocols for the data layer.

Kept deliberately minimal. Two protocols:

- :class:`CacheStore` — key-to-DataFrame persistence with TTL-aware reads.
- :class:`Loader` — fetches data for a symbol (or market-wide entity); cache
  awareness is the loader's responsibility, not the caller's.

Concrete impls live alongside (``cache.py``, ``price_loader.py``, etc.) and
are injected into higher layers at application startup. No module-level
instances, no singletons — composition is the only integration pattern.
"""
from __future__ import annotations

from datetime import timedelta
from typing import Protocol

import pandas as pd


class CacheStore(Protocol):
    """Key-addressed persistent cache for DataFrames.

    Implementations decide where and how data lives on disk. Callers decide
    when data is stale — the cache surfaces age but never mutates on its
    own (no background eviction, no GC).

    All methods are thread-safe per key; concurrent writes to the same
    key are the caller's problem (wrapping in a lock is fine).
    """

    def get(self, key: str) -> pd.DataFrame | None:
        """Return the DataFrame for ``key``, or ``None`` if absent.

        Raises ``OSError`` only on underlying filesystem failures (disk full,
        permission denied). A missing key is a normal return value, not an
        exception.
        """
        ...

    def set(self, key: str, df: pd.DataFrame) -> None:
        """Persist ``df`` under ``key``. Overwrites any prior value.

        Implementations must write atomically — a partial write is worse
        than no write. Raises ``OSError`` on filesystem failure.
        """
        ...

    def exists(self, key: str) -> bool:
        """Return True if ``key`` has a value (regardless of age)."""
        ...

    def age(self, key: str) -> timedelta | None:
        """Return wall-clock age of the stored value, or ``None`` if absent.

        Callers use this with their own TTL policy to decide whether to
        refresh. The cache has no notion of "expired"; freshness is a
        per-caller decision.
        """
        ...

    def clear(self, prefix: str | None = None) -> int:
        """Remove every key starting with ``prefix`` (or all keys if
        ``prefix`` is ``None``). Return the number of keys removed.
        """
        ...


class Loader(Protocol):
    """A data loader for a single domain (price, options, filings, etc.).

    Loaders compose a ``CacheStore`` with a live fetcher. The default is to
    serve from cache when fresh and fetch-then-cache when stale. Callers
    can force a refresh via explicit parameters on concrete loader methods.

    This protocol is intentionally empty — each loader has domain-specific
    arguments that can't be generalized away. It exists as a type-level
    marker and a conceptual grouping.
    """
