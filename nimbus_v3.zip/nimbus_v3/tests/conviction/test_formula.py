"""Unit tests for nimbus_v3.conviction.formula."""
from __future__ import annotations

import pandas as pd
import pytest

from nimbus_v3.conviction.formula import (
    Contribution,
    WEIGHTS,
    compute_contributions,
    day_of_week_contribution,
    divergence_contribution,
    filing_contribution,
    mfi_contribution,
    rsi_contribution,
    sector_rs_contribution,
    sector_vol_contribution,
    vix_contribution,
    volume_contribution,
)
from nimbus_v3.core.context import (
    ContextBundle, FilingContext, MarketContext, SectorContext,
)
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import (
    FilingImpact, RSRegime, SetupType, VIXRegime,
)
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Fixture builders
# ══════════════════════════════════════════════════════════════════════════════

_ASOF = pd.Timestamp("2024-05-15")   # a Wednesday — day_of_week = 2


def _state(**overrides) -> SignalState:
    """Permissive default state; pass keyword overrides for specific fields."""
    defaults = dict(
        symbol="R", bar_date=_ASOF, bar_index=250,
        open=100.0, high=100.0, low=100.0, close=100.0, volume=1e6,
        sma_10=99.0, sma_20=98.0, sma_50=95.0, sma_200=90.0,
        wr_14=-50.0, wr_20=-50.0, wr_30=-50.0, wr_50=-50.0,
        rsi_14=50.0, mfi_14=50.0, mfi_slope_3=0.0,
        adx_14=25.0, atr_14=1.0, atr_14_pct=1.0,
        bb_20_1s_upper=101.0, bb_20_1s_mid=100.0,
        bb_20_1s_lower=99.0, bb_20_1s_pct=0.5,
        bb_20_2s_upper=103.0, bb_20_2s_lower=97.0,
        bbw_20_2s=6.0, bbw_20_2s_slope=0.0, bbw_20_2s_pctl=50.0,
        pct_from_sma_20=0.0, pct_from_sma_50=0.0, pct_from_sma_200=0.0,
        above_sma_20=True, above_sma_50=True, above_sma_200=True,
        dd_from_high_20=0.0, dd_from_high_50=0.0,
        red_streak=0, green_streak=0,
        vol_ratio_20=1.0, roc_5=0.0, roc_10=0.0, roc_20=0.0,
        data_sufficient=True,
    )
    defaults.update(overrides)
    return SignalState(**defaults)


def _mr_signal(**overrides) -> StrategySignal:
    defaults = dict(
        strategy_name="MeanReversion", symbol="R",
        setup_type=SetupType.MEAN_REVERSION, asof_date=_ASOF, priority=50,
    )
    defaults.update(overrides)
    return StrategySignal(**defaults)


def _bo_signal(**overrides) -> StrategySignal:
    defaults = dict(
        strategy_name="Breakout", symbol="R",
        setup_type=SetupType.BREAKOUT, asof_date=_ASOF, priority=50,
    )
    defaults.update(overrides)
    return StrategySignal(**defaults)


def _bundle(
    *,
    vix_regime=VIXRegime.NORMAL,
    vix_streak: int = 0,
    rs_regime=RSRegime.NEUTRAL,
    rs_20d: float = 0.0,
    vol_z: float | None = 0.0,
    filing_impact: FilingImpact | None = None,
    filing_days_since: int | None = None,
) -> ContextBundle:
    market = MarketContext(
        asof_date=_ASOF, vix_value=None,
        vix_regime=vix_regime, vix_high_streak=vix_streak,
    )
    sector = SectorContext(
        asof_date=_ASOF, symbol="R", sector_name="X",
        sector_type=None, rs_regime=rs_regime,
        rs_20d=rs_20d, realized_vol_20d=15.0, vol_z_score=vol_z,
    )
    filing = None
    if filing_impact is not None:
        filing = FilingContext(
            asof_date=_ASOF, symbol="R",
            latest_impact=filing_impact,
            is_trap=(filing_impact == FilingImpact.TRAP),
            days_since_latest=filing_days_since,
            latest_headline="test",
        )
    return ContextBundle(
        symbol="R", asof_date=_ASOF,
        market=market, sector=sector, filing=filing,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Contribution dataclass
# ══════════════════════════════════════════════════════════════════════════════

def test_contribution_weighted_uses_weights_dict() -> None:
    c = Contribution("mfi", 0.5, "test")
    assert c.weighted == 0.5 * WEIGHTS["mfi"]


def test_contribution_weighted_unknown_name_default_1() -> None:
    c = Contribution("unknown_name", 0.7, "test")
    assert c.weighted == 0.7 * 1.0


# ══════════════════════════════════════════════════════════════════════════════
# MFI contribution
# ══════════════════════════════════════════════════════════════════════════════

def test_mfi_deeply_oversold_boosts_reversal_setup() -> None:
    c = mfi_contribution(_state(mfi_14=15.0), _mr_signal())
    assert c.value == pytest.approx(1.0)


def test_mfi_deeply_oversold_neutral_for_continuation() -> None:
    c = mfi_contribution(_state(mfi_14=15.0), _bo_signal())
    assert c.value == pytest.approx(0.0)


def test_mfi_overbought_hurts_reversal_more_than_continuation() -> None:
    c_mr = mfi_contribution(_state(mfi_14=85.0), _mr_signal())
    c_bo = mfi_contribution(_state(mfi_14=85.0), _bo_signal())
    assert c_mr.value < c_bo.value
    assert c_mr.value < 0 and c_bo.value < 0


def test_mfi_neutral_zone() -> None:
    c = mfi_contribution(_state(mfi_14=50.0), _mr_signal())
    assert c.value == pytest.approx(0.0)


def test_mfi_strong_inflow_helps_continuation() -> None:
    c = mfi_contribution(_state(mfi_14=70.0), _bo_signal())
    assert c.value > 0


# ══════════════════════════════════════════════════════════════════════════════
# Volume contribution
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("ratio,expected_sign", [
    (0.5, -1),   # anaemic → negative
    (1.0, 0),    # normal → 0
    (1.5, +1),   # above average → positive
    (2.5, +1),   # strong → positive
    (4.0, +1),   # capped but still positive
])
def test_volume_contribution_sign(ratio: float, expected_sign: int) -> None:
    c = volume_contribution(_state(vol_ratio_20=ratio))
    if expected_sign == 0:
        assert c.value == pytest.approx(0.0)
    elif expected_sign > 0:
        assert c.value > 0
    else:
        assert c.value < 0


def test_volume_capped_above_3x() -> None:
    """Very high volume caps at +0.8, not monotonic forever."""
    c_3x = volume_contribution(_state(vol_ratio_20=2.5))
    c_5x = volume_contribution(_state(vol_ratio_20=5.0))
    assert c_3x.value > c_5x.value


# ══════════════════════════════════════════════════════════════════════════════
# RSI contribution
# ══════════════════════════════════════════════════════════════════════════════

def test_rsi_reversal_boosts_oversold() -> None:
    c = rsi_contribution(_state(rsi_14=20.0), _mr_signal())
    assert c.value == pytest.approx(1.0)


def test_rsi_reversal_penalises_overbought() -> None:
    c = rsi_contribution(_state(rsi_14=80.0), _mr_signal())
    assert c.value < 0


def test_rsi_continuation_penalises_overbought() -> None:
    c = rsi_contribution(_state(rsi_14=80.0), _bo_signal())
    assert c.value < 0


def test_rsi_continuation_boosts_momentum_zone() -> None:
    c = rsi_contribution(_state(rsi_14=65.0), _bo_signal())
    assert c.value > 0


# ══════════════════════════════════════════════════════════════════════════════
# Divergence contribution (MFI slope)
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("slope,expected_sign", [
    (5.0, +1),
    (1.0, +1),
    (0.0, 0),
    (-1.0, -1),
    (-5.0, -1),
])
def test_divergence_sign_matches_slope(slope, expected_sign) -> None:
    c = divergence_contribution(_state(mfi_slope_3=slope))
    if expected_sign > 0:
        assert c.value > 0
    elif expected_sign < 0:
        assert c.value < 0
    else:
        assert c.value == pytest.approx(0.0)


# ══════════════════════════════════════════════════════════════════════════════
# VIX contribution — crucial for MR
# ══════════════════════════════════════════════════════════════════════════════

def test_vix_mr_high_regime_streak_6_is_sweet_spot() -> None:
    c = vix_contribution(
        _bundle(vix_regime=VIXRegime.HIGH, vix_streak=8),
        _mr_signal(),
    )
    assert c.value == pytest.approx(1.0)


def test_vix_mr_high_regime_low_streak_still_helps() -> None:
    c = vix_contribution(
        _bundle(vix_regime=VIXRegime.HIGH, vix_streak=3),
        _mr_signal(),
    )
    assert 0 < c.value < 1.0


def test_vix_mr_normal_regime_penalises() -> None:
    c = vix_contribution(
        _bundle(vix_regime=VIXRegime.NORMAL, vix_streak=0),
        _mr_signal(),
    )
    assert c.value < 0


def test_vix_continuation_setup_prefers_normal() -> None:
    c = vix_contribution(
        _bundle(vix_regime=VIXRegime.NORMAL),
        _bo_signal(),
    )
    assert c.value > 0


def test_vix_continuation_setup_penalised_in_high_regime() -> None:
    c = vix_contribution(
        _bundle(vix_regime=VIXRegime.HIGH, vix_streak=6),
        _bo_signal(),
    )
    assert c.value < 0


def test_vix_drawdown_reversal_ambivalent() -> None:
    signal = StrategySignal(
        strategy_name="DR", symbol="R",
        setup_type=SetupType.DRAWDOWN_REVERSAL, asof_date=_ASOF, priority=35,
    )
    c_high = vix_contribution(_bundle(vix_regime=VIXRegime.HIGH, vix_streak=6), signal)
    c_low = vix_contribution(_bundle(vix_regime=VIXRegime.NORMAL), signal)
    assert c_high.value == pytest.approx(0.0)
    assert c_low.value == pytest.approx(0.0)


# ══════════════════════════════════════════════════════════════════════════════
# Sector RS contribution
# ══════════════════════════════════════════════════════════════════════════════

def test_sector_rs_continuation_strongly_prefers_leading() -> None:
    c = sector_rs_contribution(
        _bundle(rs_regime=RSRegime.LEADING, rs_20d=+5.0), _bo_signal(),
    )
    assert c.value > 0.5


def test_sector_rs_continuation_penalised_in_lagging() -> None:
    c = sector_rs_contribution(
        _bundle(rs_regime=RSRegime.LAGGING, rs_20d=-5.0), _bo_signal(),
    )
    assert c.value < -0.5


def test_sector_rs_reversal_mild_effects() -> None:
    """MR doesn't care strongly about RS — mild effects only."""
    c_lead = sector_rs_contribution(
        _bundle(rs_regime=RSRegime.LEADING, rs_20d=+5.0), _mr_signal(),
    )
    c_lag = sector_rs_contribution(
        _bundle(rs_regime=RSRegime.LAGGING, rs_20d=-5.0), _mr_signal(),
    )
    assert abs(c_lead.value) < 0.5 and abs(c_lag.value) < 0.5


# ══════════════════════════════════════════════════════════════════════════════
# Sector vol contribution
# ══════════════════════════════════════════════════════════════════════════════

def test_sector_vol_stressed_helps_mean_reversion() -> None:
    c = sector_vol_contribution(_bundle(vol_z=2.5))
    assert c.value > 0


def test_sector_vol_normal_neutral() -> None:
    c = sector_vol_contribution(_bundle(vol_z=0.0))
    assert c.value == pytest.approx(0.0)


def test_sector_vol_none_neutral() -> None:
    c = sector_vol_contribution(_bundle(vol_z=None))
    assert c.value == pytest.approx(0.0)


# ══════════════════════════════════════════════════════════════════════════════
# Filing contribution
# ══════════════════════════════════════════════════════════════════════════════

def test_filing_none_context_neutral() -> None:
    c = filing_contribution(_bundle(filing_impact=None))
    assert c.value == pytest.approx(0.0)


def test_filing_trap_returns_neutral_engine_handles() -> None:
    """TRAP is handled as a hard stop in the engine. The contribution
    layer must return 0 so we don't double-count."""
    c = filing_contribution(_bundle(
        filing_impact=FilingImpact.TRAP, filing_days_since=1,
    ))
    assert c.value == pytest.approx(0.0)


def test_filing_material_penalises() -> None:
    c = filing_contribution(_bundle(
        filing_impact=FilingImpact.MATERIAL, filing_days_since=1,
    ))
    assert c.value == pytest.approx(-0.5)


def test_filing_minor_small_penalty() -> None:
    c = filing_contribution(_bundle(
        filing_impact=FilingImpact.MINOR, filing_days_since=1,
    ))
    assert c.value == pytest.approx(-0.1)


# ══════════════════════════════════════════════════════════════════════════════
# Day of week
# ══════════════════════════════════════════════════════════════════════════════

def test_day_of_week_friday_penalty() -> None:
    friday = pd.Timestamp("2024-05-17")   # Friday
    sig = StrategySignal(
        strategy_name="X", symbol="R",
        setup_type=SetupType.MEAN_REVERSION, asof_date=friday, priority=50,
    )
    c = day_of_week_contribution(sig)
    # Raw value is negative (penalty), weight is positive.
    assert c.value == pytest.approx(-1.0)
    assert c.weighted < 0


def test_day_of_week_intraweek_neutral() -> None:
    wednesday = pd.Timestamp("2024-05-15")
    sig = StrategySignal(
        strategy_name="X", symbol="R",
        setup_type=SetupType.MEAN_REVERSION, asof_date=wednesday, priority=50,
    )
    c = day_of_week_contribution(sig)
    assert c.value == pytest.approx(0.0)


# ══════════════════════════════════════════════════════════════════════════════
# compute_contributions — ordering + determinism
# ══════════════════════════════════════════════════════════════════════════════

def test_compute_contributions_emits_nine_items() -> None:
    contribs = compute_contributions(
        _state(), _bundle(vix_regime=VIXRegime.HIGH, vix_streak=6), _mr_signal(),
    )
    assert len(contribs) == 9


def test_compute_contributions_fixed_order() -> None:
    contribs = compute_contributions(
        _state(), _bundle(), _mr_signal(),
    )
    names = [c.name for c in contribs]
    assert names == [
        "mfi", "volume", "rsi", "divergence",
        "vix", "sector_rs", "sector_vol",
        "filing", "day_of_week",
    ]


def test_compute_contributions_deterministic() -> None:
    """Same input → identical output every time."""
    state = _state(mfi_14=35.0, rsi_14=28.0, vol_ratio_20=1.8)
    bundle = _bundle(vix_regime=VIXRegime.HIGH, vix_streak=7,
                       rs_regime=RSRegime.LEADING, rs_20d=4.0, vol_z=1.5)
    sig = _mr_signal()
    a = compute_contributions(state, bundle, sig)
    b = compute_contributions(state, bundle, sig)
    assert [(c.name, c.value) for c in a] == [(c.name, c.value) for c in b]
