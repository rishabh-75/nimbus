"""Tests for nimbus_v3.core.universe dataclasses."""
from __future__ import annotations

import dataclasses

import pandas as pd
import pytest

from nimbus_v3.core.universe import ETFMeta, SymbolMeta, Universe


# ══════════════════════════════════════════════════════════════════════════════
# SymbolMeta
# ══════════════════════════════════════════════════════════════════════════════

def test_symbol_meta_defaults() -> None:
    m = SymbolMeta(symbol="RELIANCE")
    assert m.sector == "Unknown"
    assert m.industry == "Unknown"
    assert m.indices == frozenset()
    assert m.is_fno is False
    assert m.is_etf is False
    assert m.etf_meta is None


def test_symbol_meta_is_frozen() -> None:
    m = SymbolMeta(symbol="TCS")
    with pytest.raises(dataclasses.FrozenInstanceError):
        m.sector = "Banking"  # type: ignore[misc]


def test_symbol_meta_rejects_etf_and_fno_together() -> None:
    with pytest.raises(ValueError, match="mutually exclusive"):
        SymbolMeta(symbol="X", is_etf=True, is_fno=True)


def test_symbol_meta_etf_gets_stub_meta_if_flag_set_without_one() -> None:
    m = SymbolMeta(symbol="NIFTYBEES", is_etf=True)
    assert m.etf_meta is not None
    assert isinstance(m.etf_meta, ETFMeta)


def test_symbol_meta_is_hashable() -> None:
    """Frozen + immutable-field types ⇒ hashable — safe for dict keys."""
    a = SymbolMeta(symbol="RELIANCE", sector="Energy")
    b = SymbolMeta(symbol="RELIANCE", sector="Energy")
    assert hash(a) == hash(b)
    assert a == b


# ══════════════════════════════════════════════════════════════════════════════
# Universe
# ══════════════════════════════════════════════════════════════════════════════

def _build_sample_universe() -> Universe:
    symbols = {
        "RELIANCE": SymbolMeta(
            symbol="RELIANCE", sector="Energy", industry="Refineries",
            indices=frozenset({"NIFTY 50", "NIFTY 100", "NIFTY ENERGY"}),
            is_fno=True,
        ),
        "TCS": SymbolMeta(
            symbol="TCS", sector="Information Technology",
            industry="Computers - Software",
            indices=frozenset({"NIFTY 50", "NIFTY IT"}),
            is_fno=True,
        ),
        "HDFCBANK": SymbolMeta(
            symbol="HDFCBANK", sector="Banking",
            industry="Banks",
            indices=frozenset({"NIFTY 50", "NIFTY BANK"}),
            is_fno=True,
        ),
        "NIFTYBEES": SymbolMeta(
            symbol="NIFTYBEES", is_etf=True,
            etf_meta=ETFMeta(underlying_asset="Nifty 50"),
        ),
        "IDEA": SymbolMeta(
            symbol="IDEA", sector="Telecom",
            indices=frozenset({"NIFTY 500"}),
            is_fno=False,
        ),
    }
    return Universe(symbols=symbols, built_at=pd.Timestamp("2024-05-01"))


def test_universe_built_at_normalised_to_timestamp() -> None:
    u = Universe(symbols={}, built_at="2024-05-01")  # type: ignore[arg-type]
    assert isinstance(u.built_at, pd.Timestamp)


def test_universe_slice_by_index() -> None:
    u = _build_sample_universe()
    assert u.slice("NIFTY 50") == ["HDFCBANK", "RELIANCE", "TCS"]
    assert u.slice("NIFTY BANK") == ["HDFCBANK"]
    assert u.slice("NOT_AN_INDEX") == []


def test_universe_etfs_and_equities() -> None:
    u = _build_sample_universe()
    assert u.etfs() == ["NIFTYBEES"]
    assert u.equities() == ["HDFCBANK", "IDEA", "RELIANCE", "TCS"]


def test_universe_fno_symbols() -> None:
    u = _build_sample_universe()
    assert u.fno_symbols() == ["HDFCBANK", "RELIANCE", "TCS"]


def test_universe_by_sector() -> None:
    u = _build_sample_universe()
    assert u.by_sector("Banking") == ["HDFCBANK"]
    assert u.by_sector("Information Technology") == ["TCS"]


def test_universe_sectors_and_indices_are_sorted_unique() -> None:
    u = _build_sample_universe()
    sectors = u.sectors()
    assert sectors == sorted(set(sectors))
    indices = u.indices()
    assert indices == sorted(set(indices))


def test_universe_membership_and_length() -> None:
    u = _build_sample_universe()
    assert len(u) == 5
    assert "RELIANCE" in u
    assert "NOT_A_SYMBOL" not in u
    assert 42 not in u  # non-string input returns False, doesn't crash
