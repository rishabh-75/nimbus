"""Smoke test: the package imports, version is sane, and the expected
subpackages are reachable.

This test exists from Phase 0 onward. It has no dependencies on specific
module implementations — it asserts only the scaffolding is intact. Phase 1+
tests land in the respective tests/<subpackage>/ directories.
"""
from __future__ import annotations

import importlib

import pytest


EXPECTED_SUBPACKAGES = (
    "nimbus_v3.core",
    "nimbus_v3.data",
    "nimbus_v3.compute",
    "nimbus_v3.context",
    "nimbus_v3.research",
    "nimbus_v3.ui",
)


def test_root_package_imports() -> None:
    import nimbus_v3
    assert hasattr(nimbus_v3, "__version__")
    assert isinstance(nimbus_v3.__version__, str)
    assert nimbus_v3.__version__.startswith("0.")


@pytest.mark.parametrize("module_name", EXPECTED_SUBPACKAGES)
def test_subpackage_imports(module_name: str) -> None:
    """Every subpackage declared in ARCHITECTURE.md §5 must be importable."""
    module = importlib.import_module(module_name)
    assert module is not None


def test_root_package_exports_nothing_by_default() -> None:
    """Per ARCHITECTURE.md §5, the root package re-exports nothing. Consumers
    import explicit subpackages. This guards against accidental star-import
    pollution creeping in later.

    Runs in a subprocess so that subpackages imported by other tests in this
    session don't show up as attributes on the root module (which Python
    auto-binds after any `import x.y`). The invariant we care about is what
    ``nimbus_v3/__init__.py`` itself exposes on a cold import.
    """
    import subprocess
    import sys

    result = subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import nimbus_v3; "
                "import json; "
                "print(json.dumps(sorted("
                "n for n in dir(nimbus_v3) if not n.startswith('_')"
                ")))"
            ),
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    import json
    public_symbols = set(json.loads(result.stdout.strip()))
    unexpected = public_symbols - {"__version__"}
    assert not unexpected, f"Root package exports unexpected symbols: {unexpected}"
