"""Tests for nimbus_v3.macro.universe."""
from __future__ import annotations

from nimbus_v3.macro.universe import (
    COMMODITY_UNIVERSE, CommodityCategory, MONTH_CODES,
    all_tickers, by_category, by_ticker,
)


def test_universe_has_23_instruments() -> None:
    assert len(COMMODITY_UNIVERSE) == 23


def test_every_ticker_unique() -> None:
    tickers = [i.ticker for i in COMMODITY_UNIVERSE]
    assert len(tickers) == len(set(tickers))


def test_by_ticker_lookup() -> None:
    assert by_ticker("GC=F").name == "Gold"
    assert by_ticker("ALI=F").name == "Aluminium"
    assert by_ticker("NONEXISTENT") is None


def test_by_category_returns_only_that_category() -> None:
    precious = by_category(CommodityCategory.PRECIOUS)
    assert all(i.category == CommodityCategory.PRECIOUS for i in precious)
    assert len(precious) == 4   # GC, SI, PL, PA


def test_all_tickers_returns_every_ticker() -> None:
    assert set(all_tickers()) == {i.ticker for i in COMMODITY_UNIVERSE}


def test_month_codes_complete() -> None:
    assert len(MONTH_CODES) == 12
    assert MONTH_CODES[0] == "F"     # January
    assert MONTH_CODES[-1] == "Z"    # December


def test_listing_cycle_is_subset_of_month_codes() -> None:
    """Every listing-cycle entry must be a valid CME month code."""
    valid = set(MONTH_CODES)
    for i in COMMODITY_UNIVERSE:
        assert set(i.listing_cycle).issubset(valid), (
            f"{i.ticker} has invalid month codes"
        )


def test_leader_tickers_resolve_to_universe() -> None:
    """Every leader_ticker must point at another universe instrument."""
    valid_tickers = set(all_tickers())
    for i in COMMODITY_UNIVERSE:
        if i.leader_ticker is not None:
            assert i.leader_ticker in valid_tickers, (
                f"{i.ticker} leader {i.leader_ticker} not in universe"
            )


def test_each_category_has_a_leader() -> None:
    """Each non-singleton category must have at least one
    instrument with leader_ticker=None (the leader itself)."""
    for cat in CommodityCategory:
        members = by_category(cat)
        if len(members) <= 1:
            continue
        leaders_in_cat = [i for i in members if i.leader_ticker is None]
        assert len(leaders_in_cat) >= 1, (
            f"Category {cat.value} has no leader (leader_ticker=None)"
        )
