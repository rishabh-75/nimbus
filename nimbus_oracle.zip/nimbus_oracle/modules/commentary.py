"""
modules/commentary.py
─────────────────────
Workflow narrative: GEX → Walls → Expiry → WR → Verdict.
Now aware of PriceSignals (daily bias, vol state, WR phase, position state).
"""

from __future__ import annotations

from typing import Optional

import pandas as pd

from modules.analytics import OptionsContext
from modules.indicators import PriceSignals, bb_signal, wr_signal




def get_commentary(
    ctx: OptionsContext,
    ps: Optional[PriceSignals] = None,
    symbol: str = "NIFTY",
    price_df: Optional[pd.DataFrame] = None,
) -> dict:
    """
    Generate options workflow commentary — rule-based, deterministic.

    This provides OPTIONS CONTEXT only. Trade decisions (grade, sizing, verdict)
    are owned by ConvictionEngine. Commentary never recommends sizing.
    """
    bb = bb_signal(price_df) if price_df is not None and not price_df.empty else {}
    wr = wr_signal(price_df) if price_df is not None and not price_df.empty else {}

    # ── MFI line ──────────────────────────────────────────────────────
    if ps and ps.mfi_value is not None:
        mv = ps.mfi_value
        if not ps.mfi_reliable:
            mfi_line = f"MFI {mv:.0f} — thin volume, unreliable"
        elif ps.mfi_diverge:
            mfi_line = (
                f"MFI {mv:.0f} ⚠ BEARISH DIVERGENCE — "
                f"price near high, money leaving → bearish divergence, reduce conviction"
            )
        else:
            desc = {
                "STRONG": "strong buying pressure — volume confirming move",
                "RISING": (
                    "money flowing in — volume + price aligned"
                    if ps.wr_in_momentum
                    else "money rising but W%R not yet in zone"
                ),
                "NEUTRAL": "neutral money flow",
                "FALLING": (
                    "money softening — W%R falling too, watch closely"
                    if ps.wr_trend == "falling"
                    else "money flow softening — price still holding"
                ),
                "WEAK": "heavy selling pressure — distribution confirmed",
            }.get(ps.mfi_state, "")
            mfi_line = f"MFI {mv:.0f} {ps.mfi_state} — {desc}"
    else:
        mfi_line = "MFI — volume unavailable"

    # ── Rule-based commentary (deterministic, no API call) ────────────
    result = _rule_based(ctx, ps, bb, wr)
    result["mfi_line"] = mfi_line
    return result


def _rule_based(
    ctx: OptionsContext, ps: Optional[PriceSignals], bb: dict, wr: dict
) -> dict:
    """
    Rule-based options workflow commentary. Deterministic, no API call.

    Provides OPTIONS CONTEXT only. Never recommends sizing — that's
    owned by ConvictionEngine.
    """
    g, w, e, v, r = ctx.gex, ctx.walls, ctx.expiry, ctx.viability, ctx.regime

    # ── GEX line ──────────────────────────────────────────────────────────────
    if g.regime == "Negative":
        gex_line = (
            f"GEX Negative ({g.net_gex:,.0f}M) → Dealers amplify moves in BOTH directions "
            f"→ Stronger bounces but deeper dips too → Watch for reversal confirmation"
        )
    elif g.regime == "Positive":
        gex_line = (
            f"GEX Positive ({g.net_gex:,.0f}M) → Pins toward {w.max_pain:,.0f} "
            f"→ Momentum dampened, mean reversion favored"
        )
    else:
        gex_line = (
            "GEX Neutral → No strong dealer bias "
            "→ Trade on price action"
        )

    # ── Wall line ─────────────────────────────────────────────────────────────
    if w.resistance and w.resistance_pct >= 2.0:
        wall_line = (
            f"Resistance {w.resistance:,.0f} ({w.resistance_pct:+.1f}%) | "
            f"Support {w.support:,.0f} ({w.support_pct:+.1f}%) "
            f"→ Adequate structural room → Target resistance, stop below support"
        )
    elif w.resistance:
        wall_line = (
            f"Resistance {w.resistance:,.0f} ({w.resistance_pct:+.1f}%) — CRAMPED "
            f"→ Wall likely caps the move → Watch for break"
        )
    else:
        wall_line = "No options data → Cannot assess walls → Upload options chain"

    # ── Expiry line ───────────────────────────────────────────────────────────
    dte = e.days_remaining
    mp = f"{w.max_pain:,.0f}" if w.max_pain else "—"
    if dte <= 1:
        exp_line = (
            f"Expiry TODAY — INTRADAY ONLY → No new swing entries "
            f"→ Close any open positions or roll forward"
        )
    elif e.pin_risk == "HIGH":
        exp_line = (
            f"Expiry {dte}d → HIGH pin risk → "
            f"Market compressing toward {mp} → Wait post-expiry"
        )
    elif e.pin_risk == "MODERATE":
        exp_line = (
            f"Expiry {dte}d → Moderate pin risk → "
            f"Watch Thu/Fri compression near {mp} → Take profit before last session"
        )
    else:
        exp_line = (
            f"Expiry {dte}d → LOW pin risk → "
            f"Plenty of time → No expiry adjustment needed"
        )

    # ── WR + phase line ───────────────────────────────────────────────────────
    wr_val = (ps.wr_value if ps else None) or wr.get("wr_value")
    wr_zone = (ps.wr_in_momentum if ps else None) or wr.get("in_momentum", False)
    wr_phase = ps.wr_phase if ps else "NONE"
    bars = ps.wr_bars_since_cross50 if ps else 99

    if wr_val is not None:
        if not wr_zone:
            wr_line = (
                f"W%R {wr_val:.1f} → Below -20 → NOT in momentum zone "
                f"→ Do NOT enter until W%R reclaims -20"
            )
        elif wr_phase == "FRESH":
            wr_line = (
                f"W%R {wr_val:.1f} → FRESH momentum ({bars}b since -50 cross) "
                f"→ Early in the move — best entry window → Proceed"
            )
        elif wr_phase == "DEVELOPING":
            wr_line = (
                f"W%R {wr_val:.1f} → DEVELOPING ({bars}b since cross) "
                f"→ Mid-phase momentum — still valid → Monitor for exhaustion"
            )
        else:
            wr_line = (
                f"W%R {wr_val:.1f} → LATE phase ({bars}b since -50 cross) "
                f"→ Risk of mean reversion → Tighten stops, no new entries"
            )
    else:
        wr_line = "W%R: Load price data to confirm momentum zone"

    # ── Daily bias + vol + position state line ────────────────────────────────
    bias_str = ps.daily_bias if ps else "?"
    vs_str = ps.vol_state if ps else "?"
    pos_str = ps.position_state.replace("_", " ").title() if ps else "?"
    bias_pct = f"{ps.daily_bias_pct:+.1f}%" if ps else ""

    if ps:
        bias_line = (
            f"Daily {bias_str} ({bias_pct} vs SMA) · Vol {vs_str} "
            f"({ps.bb_width_pctl:.0f}th pctl) · State: {pos_str}"
        )
    else:
        bias_line = "Load price data for daily bias + vol state"

    # ── Verdict (options landscape — NO sizing recommendations) ───────────────
    score = v.score
    res_str = f"{w.resistance:,.0f}" if w.resistance else "—"
    sup_str = f"{w.support:,.0f}" if w.support else "—"
    mp_str = f"{w.max_pain:,.0f}" if w.max_pain else "—"
    wr_str = f"{wr_val:.1f}" if wr_val is not None else "?"

    # Position state gates
    if ps and ps.position_state == "MID_BAND_BROKEN":
        verdict = (
            f"EXIT signal. Price closed below 20-SMA — momentum leg complete. "
            f"Close all positions. Re-enter only after W%R resets below -50 and bounces."
        )
    elif ps and ps.position_state == "FIRST_DIP":
        verdict = (
            f"Partial exit. First close below upper band at {ps.last_close:,.0f}. "
            f"Scale out 50% now. Move stop to entry. Hold remainder to mid-band {ps.mid:,.1f}."
        )

    # Daily bearish — no longs
    elif ps and ps.daily_bias == "BEARISH":
        verdict = (
            f"No new longs. Daily price is BELOW 20-SMA ({ps.daily_bias_pct:+.1f}%). "
            f"Wait for daily bias to turn bullish before any fresh entries."
        )

    # WR gate — not in momentum zone
    elif wr_val is not None and not wr_zone:
        if score < 40:
            verdict = (
                f"No entry. W%R {wr_str} not in momentum zone AND conditions unfavorable. "
                f"Wait for W%R > -20. Check again next session."
            )
        elif g.regime == "Positive":
            verdict = (
                f"Wait. W%R {wr_str} needs > -20. GEX Positive also pins toward {mp_str}. "
                f"Two reasons to stay out. Alert at W%R = -20."
            )
        else:
            verdict = (
                f"Setup building but W%R {wr_str} not yet at -20. "
                f"Levels: target {res_str}, floor {sup_str}. Alert at W%R = -20. No entry yet."
            )

    # Conditions weak
    elif score < 40:
        notes = v.risk_notes[:2] if v.risk_notes else []
        note_str = " | ".join(notes)
        verdict = (
            f"Conditions weak. {note_str + '. ' if note_str else ''}"
            f"Wait for next cycle."
        )

    # Mixed signals
    elif score < 60:
        reasons = []
        if g.regime == "Positive":
            reasons.append(f"GEX Positive (→ {mp_str})")
        if e.pin_risk != "LOW":
            reasons.append(f"pin risk ({dte}d)")
        if ps and wr_phase == "LATE":
            reasons.append("late W%R phase")
        why = " + ".join(reasons) if reasons else "mixed conditions"
        verdict = (
            f"Caution: {why}. Target {res_str}, stop below {sup_str}."
        )

    # Clean setup
    else:
        phase_note = f"Fresh W%R momentum ({bars}b). " if wr_phase == "FRESH" else ""
        squeeze_note = (
            "Vol squeeze breakout in play. " if ps and ps.vol_state == "SQUEEZE" else ""
        )
        verdict = (
            f"Clean setup. {phase_note}{squeeze_note}"
            f"Room to {res_str}. Support near {sup_str}."
        )

    return dict(
        gex_line=gex_line,
        wall_line=wall_line,
        expiry_line=exp_line,
        wr_line=wr_line,
        bias_line=bias_line,
        verdict=verdict,
    )
