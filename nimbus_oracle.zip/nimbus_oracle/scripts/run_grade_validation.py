#!/usr/bin/env python3
"""
scripts/run_grade_validation.py — Validate new grade formula against OOS trades.

Compares OLD grade (score band + WR depth + DD + BBW) vs NEW grade (MFI + RSI + vol + VIX).
Tests monotonicity, separation, and correlation for both.

Usage:
    python3 scripts/run_grade_validation.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("grade_val")

GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6, "—": 7}


def grade_old(sc, wr, mfi, dd, streak, bbw_pctl, vol, tier, vr, mfi_slope):
    """OLD grade: score band + WR depth + DD + BBW + VIX flat."""
    pts = 0
    if sc >= 80: pts += 4
    elif sc >= 70: pts += 3
    elif sc >= 60: pts += 2
    elif sc >= 50: pts += 1
    if wr is not None:
        if wr < -70: pts += 3
        elif wr < -50: pts += 2
        elif wr < -30: pts += 1
    if mfi >= 55 and mfi_slope > 3: pts += 2
    elif mfi >= 45: pts += 1
    if dd < -10 and streak >= 3: pts += 2
    elif dd < -5 or streak >= 3: pts += 1
    if bbw_pctl < 25: pts += 1
    if vol >= 1.5: pts += 1
    if tier == "PRIMARY": pts += 1
    if vr == "PANIC": pts += 4
    elif vr == "ELEVATED": pts += 3
    elif vr == "LOW": pts += 2
    if pts >= 14: return "A+"
    if pts >= 12: return "A"
    if pts >= 10: return "B+"
    if pts >= 8: return "B"
    if pts >= 6: return "C+"
    if pts >= 4: return "C"
    return "D"


def grade_new(mfi, rsi, vol, vr):
    """NEW grade: MFI + RSI + vol + VIX flat (data-validated only)."""
    pts = 0
    if mfi >= 55: pts += 2
    elif mfi >= 45: pts += 1
    if rsi is not None:
        if rsi >= 50: pts += 2
        elif rsi >= 40: pts += 1
    if vol >= 1.5: pts += 1
    if vr == "PANIC": pts += 4
    elif vr == "ELEVATED": pts += 3
    elif vr == "LOW": pts += 2
    if pts >= 8: return "A+"
    if pts >= 6: return "A"
    if pts >= 5: return "B+"
    if pts >= 4: return "B"
    if pts >= 3: return "C+"
    if pts >= 2: return "C"
    return "D"


def evaluate(df, grade_col, name):
    grades = df[grade_col]
    results = []
    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        mask = grades == g
        n = mask.sum()
        if n < 5: continue
        wr = df.loc[mask, "win"].mean() * 100
        avg = df.loc[mask, "pnl_pct"].mean()
        pt = (df.loc[mask, "exit_reason"] == "PT").mean() * 100
        results.append({"grade": g, "n": n, "win": wr, "avg": avg, "pt_pct": pt})

    rdf = pd.DataFrame(results)
    grade_nums = grades.map(GRADE_ORD).fillna(7)
    corr = -np.corrcoef(grade_nums, df["pnl_pct"])[0, 1]

    # Monotonicity
    wrs = rdf["win"].values
    breaks = sum(1 for i in range(len(wrs)-1) if wrs[i] < wrs[i+1])

    # Separation
    top = df[grades.isin(["A+", "A"])]
    bot = df[grades.isin(["C", "D"])]
    sep = top["win"].mean()*100 - bot["win"].mean()*100 if len(top)>=10 and len(bot)>=10 else 0

    # PT hit rate separation
    pt_top = (top["exit_reason"] == "PT").mean()*100 if len(top) >= 10 else 0
    pt_bot = (bot["exit_reason"] == "PT").mean()*100 if len(bot) >= 10 else 0

    logger.info(f"\n  {name}:")
    logger.info(f"  {'Grade':5s} {'N':>5s} {'Win%':>6s} {'Avg':>8s} {'PT%':>6s}")
    for _, r in rdf.iterrows():
        logger.info(f"  {r['grade']:5s} {r['n']:5.0f} {r['win']:5.1f}% {r['avg']:+7.3f}% {r['pt_pct']:5.0f}%")
    logger.info(f"  Monotonic breaks: {breaks}")
    logger.info(f"  Win separation (A/A+ vs C/D): {sep:+.1f}pp")
    logger.info(f"  PT% separation (A/A+ vs C/D): {pt_top:.0f}% vs {pt_bot:.0f}%")
    logger.info(f"  Grade→PnL correlation: {corr:.4f}")

    return {"name": name, "breaks": breaks, "sep": sep, "corr": corr,
            "pt_sep": pt_top - pt_bot}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="grade_validation_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0

    logger.info("Reconstructing features for %d trades...", len(trades_df))
    from modules.dual_mode import compute_dual_mode

    price_cache = {}
    for sym in trades_df["symbol"].unique():
        f = f"data/backtest_cache/{sym}_1d.parquet"
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except: pass

    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    rows = []
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in price_cache: continue
        pdf = price_cache[sym]
        mask = pdf.index <= trade["entry_date"]
        if mask.sum() < 40: continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient: continue
            vmask = vix_series.index <= trade["entry_date"]
            vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0
            vr = "PANIC" if vix > 22 else ("ELEVATED" if vix >= 18 else ("NORMAL" if vix >= 13 else "LOW"))

            rows.append({
                "pnl_pct": trade["pnl_pct"], "win": int(trade["pnl_pct"] > 0),
                "exit_reason": trade["exit_reason"], "tier": trade["tier"],
                "vix": vix, "vr": vr,
                "score": sig.dual_score, "wr": sig.wr_30, "mfi": sig.mfi,
                "mfi_slope": sig.mfi_slope, "dd": sig.dd_from_high,
                "streak": sig.red_streak, "vol": sig.vol_ratio,
                "bbw_pctl": sig.bbw_pctl, "rsi": sig.rsi,
            })
        except: pass
        if len(rows) % 500 == 0:
            logger.info("  %d trades processed", len(rows))

    df = pd.DataFrame(rows)
    logger.info("Features: %d trades", len(df))

    df["grade_old"] = df.apply(lambda r: grade_old(
        r["score"], r["wr"], r["mfi"], r["dd"], r["streak"],
        r["bbw_pctl"], r["vol"], r["tier"], r["vr"], r["mfi_slope"]), axis=1)

    df["grade_new"] = df.apply(lambda r: grade_new(
        r["mfi"], r["rsi"], r["vol"], r["vr"]), axis=1)

    report = []
    report.append("=" * 70)
    report.append("GRADE VALIDATION: OLD vs NEW")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)}")
    report.append("=" * 70)

    import io
    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    r_old = evaluate(df, "grade_old", "OLD (score+WR+DD+BBW+VIX)")
    r_new = evaluate(df, "grade_new", "NEW (MFI+RSI+vol+VIX)")

    report.append(buf.getvalue())
    logger.removeHandler(handler)

    report.append("\n" + "=" * 70)
    report.append("COMPARISON")
    report.append("=" * 70)
    report.append(f"\n  {'System':40s} {'Breaks':>7s} {'WinSep':>8s} {'PTsep':>7s} {'Corr':>7s}")
    for r in [r_old, r_new]:
        report.append(f"  {r['name']:40s} {r['breaks']:7d} {r['sep']:+7.1f}pp {r['pt_sep']:+6.1f}pp {r['corr']:6.4f}")

    winner = r_new if r_new["corr"] > r_old["corr"] else r_old
    report.append(f"\n  WINNER: {winner['name']}")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
