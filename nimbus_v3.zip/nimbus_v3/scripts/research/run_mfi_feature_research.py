"""run_mfi_feature_research.py — does MFI level / divergence add
predictive value to the ride-strategy score?

Research question
-----------------
The composite ride score is a weighted blend of FRESHNESS / VOLUME /
BBW / MOMENTUM / BODY. This script tests whether **Money Flow Index**
— both its *level* at the trigger and *price↔MFI divergence* over a
lookback — carries information about whether a ride *continues* (the
outcome we already label in research/phase_p_win).

It does NOT modify the live scorer. It produces a verdict: keep MFI out,
or it's worth wiring in (and roughly how much it would help).

Methodology
-----------
1. Load the equity panel from the shared cache (load_equity_panel).
2. Enrich each symbol (same StrategyComputeEngine the app uses) and
   classify rides (RideEngine) — single source of truth.
3. Replay fires via the existing extract_fire_events → labeled events
   with forward outcome (return_pct, hold_bars, is_resolved).
4. At each trigger, compute look-ahead-safe MFI features:
     - mfi_level    : MFI(14) at the trigger bar
     - mfi_slope    : MFI(14) slope over the lookback (per bar)
     - mfi_diverg   : bearish divergence magnitude — price-high slope
                      minus MFI slope over the lookback, > 0 when price
                      rises while money-flow doesn't confirm.
5. Define a binary success label per resolved event:
     win = ride held >= median hold for that phase (continued well).
6. Report, for each MFI feature:
     - point-biserial correlation with `win` and Pearson with return_pct
     - win-rate / mean-return across feature quantile buckets
     - **incremental** value: AUC of a logistic model on the existing
       features, then existing + MFI, and the delta. If the delta is
       trivial (< ~0.005 AUC), MFI doesn't earn a slot.

Usage
-----
    # point at your real cache (esp. if it lives outside the project)
    # and use every symbol that's actually cached — most robust:
    python -m scripts.research.run_mfi_feature_research \
        --cache-dir /path/to/your/cache/equity_price \
        --symbols-from-cache

    # or draw the symbol list from your full industry DB:
    python -m scripts.research.run_mfi_feature_research \
        --cache-dir /path/to/cache/equity_price \
        --symbols-from /path/to/nifty500_industry_db.json

    # or an explicit subset:
    python -m scripts.research.run_mfi_feature_research \
        --cache-dir /path/to/cache/equity_price \
        --symbols RELIANCE,TCS,CIPLA

Other flags: --lookback 14 (divergence window), --mfi-period 14,
--out <path> (defaults to a timestamped CSV in data/research/).

If --cache-dir is omitted, the script uses the project's resolved
equity_price cache (``$NIMBUS_DATA_DIR/cache/equity_price`` or
``./data/cache/equity_price``). When the cache lives elsewhere, pass
--cache-dir explicitly — the script prints a coverage line up front so
a path mismatch is obvious (you'll see "0/494 present") rather than
silently running on a handful of symbols.
"""
from __future__ import annotations

import argparse
import logging
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import RideEngine
from nimbus_v3.research.equity_universe import DEFAULT_SYMBOLS, load_equity_panel
from nimbus_v3.research.phase_p_win.extract import extract_fire_events

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("mfi_research")

_OUT_DIR = Path("data/research")


# ── MFI + features ───────────────────────────────────────────────────────────

def money_flow_index(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Classic Money Flow Index (0-100).

    typical price = (H+L+C)/3 ; raw money flow = TP × Volume.
    Positive flow accumulates on up-TP bars, negative on down-TP bars.
    MFI = 100 − 100/(1 + positive_flow_sum / negative_flow_sum) over
    the rolling period. Look-ahead-safe (only past/current bars).
    """
    tp = (df["High"] + df["Low"] + df["Close"]) / 3.0
    rmf = tp * df["Volume"]
    tp_diff = tp.diff()
    pos_flow = rmf.where(tp_diff > 0, 0.0)
    neg_flow = rmf.where(tp_diff < 0, 0.0)
    pos_sum = pos_flow.rolling(period, min_periods=period).sum()
    neg_sum = neg_flow.rolling(period, min_periods=period).sum()
    # Avoid div-by-zero: when neg_sum == 0, MFI saturates to 100.
    mfr = pos_sum / neg_sum.replace(0.0, np.nan)
    mfi = 100.0 - 100.0 / (1.0 + mfr)
    mfi = mfi.where(neg_sum != 0, 100.0)
    return mfi


def _slope_per_bar(s: pd.Series) -> float:
    """OLS slope of a short series vs bar index (per-bar units)."""
    y = s.dropna().to_numpy(dtype=float)
    n = len(y)
    if n < 3:
        return float("nan")
    x = np.arange(n, dtype=float)
    x -= x.mean()
    denom = (x * x).sum()
    if denom == 0:
        return float("nan")
    return float((x * (y - y.mean())).sum() / denom)


def mfi_features_at(
    df: pd.DataFrame, mfi: pd.Series, trigger_idx: int, lookback: int,
) -> dict:
    """Look-ahead-safe MFI features at ``trigger_idx`` (uses bars
    ``[trigger_idx - lookback + 1, trigger_idx]`` only)."""
    lo = trigger_idx - lookback + 1
    if lo < 0:
        return {"mfi_level": np.nan, "mfi_slope": np.nan, "mfi_diverg": np.nan}
    win_mfi = mfi.iloc[lo:trigger_idx + 1]
    win_high = df["High"].iloc[lo:trigger_idx + 1]
    level = float(mfi.iloc[trigger_idx]) if mfi.iloc[trigger_idx] == mfi.iloc[trigger_idx] else np.nan
    mfi_slope = _slope_per_bar(win_mfi)
    price_slope = _slope_per_bar(win_high)
    # Bearish divergence: price climbing, MFI not confirming.
    # Normalise price slope to %/bar so the gap is comparable.
    last_high = float(win_high.iloc[-1]) if len(win_high) else np.nan
    price_slope_pct = (price_slope / last_high * 100.0) if (last_high and last_high == last_high) else np.nan
    diverg = (price_slope_pct - mfi_slope) if (price_slope_pct == price_slope_pct and mfi_slope == mfi_slope) else np.nan
    return {"mfi_level": level, "mfi_slope": mfi_slope, "mfi_diverg": diverg}


# ── build the labeled + MFI-augmented event table ─────────────────────────────

_EXISTING_FEATURES = [
    "pct_b_at_trigger", "sma20_slope_pct", "sma50_slope_pct",
    "bb_width_pctile", "vol_ratio_20", "atr_14_pct",
    "bars_since_sma20_above_sma50", "body_above_count_prior_5",
]
_MFI_FEATURES = ["mfi_level", "mfi_slope", "mfi_diverg"]


def build_events(
    symbols: tuple[str, ...], lookback: int, mfi_period: int,
    cache_dir: Path | None = None,
) -> pd.DataFrame:
    # Up-front coverage check — the #1 failure mode is the cache living
    # somewhere other than where load_equity_panel looks, which silently
    # yields a tiny panel. Surface it loudly before doing any work.
    if cache_dir is not None:
        cached = set(_discover_cache_symbols(cache_dir))
        want = set(symbols)
        hit = len(want & cached)
        log.info("cache coverage: %d/%d requested symbols present in %s",
                 hit, len(want), cache_dir)
        if hit == 0:
            log.error(
                "ZERO requested symbols found in --cache-dir. The cache "
                "is probably elsewhere, or uses a different layout "
                "(expected <SYMBOL>.parquet files directly under the "
                "dir). Files seen there: %s",
                sorted(cached)[:10] or "(none)",
            )
        elif hit < len(want):
            log.warning(
                "%d requested symbols are NOT in the cache and will be "
                "fetched from yfinance (slow) or skipped: e.g. %s",
                len(want) - hit, sorted(want - cached)[:10],
            )
    panel = load_equity_panel(symbols=symbols, cache_dir=cache_dir)
    engine = StrategyComputeEngine()
    ride = RideEngine()
    rows: list[dict] = []
    for sym, raw in panel.items():
        try:
            enr = engine.enrich(raw, sym)
            res = ride.classify(enr)
        except Exception:    # noqa: BLE001
            log.exception("classify failed for %s", sym)
            continue
        try:
            events = extract_fire_events(sym, enr, res)
        except Exception:    # noqa: BLE001
            log.exception("extract_fire_events failed for %s", sym)
            continue
        if not events:
            continue
        mfi = money_flow_index(enr, period=mfi_period)
        for ev in events:
            d = {
                "symbol": ev.symbol, "phase": ev.phase,
                "trigger_idx": ev.trigger_idx,
                "hold_bars": ev.hold_bars, "return_pct": ev.return_pct,
                "is_resolved": ev.is_resolved,
            }
            # existing features (attributes on the event, if present)
            for f in _EXISTING_FEATURES:
                d[f] = getattr(ev, f, np.nan)
            d.update(mfi_features_at(enr, mfi, ev.trigger_idx, lookback))
            rows.append(d)
    df = pd.DataFrame(rows)
    log.info("built %d events across %d symbols", len(df), df["symbol"].nunique() if len(df) else 0)
    return df


# ── analysis ──────────────────────────────────────────────────────────────────

def _point_biserial(x: pd.Series, y_bool: pd.Series) -> float:
    m = x.notna() & y_bool.notna()
    if m.sum() < 30 or y_bool[m].nunique() < 2:
        return float("nan")
    return float(np.corrcoef(x[m], y_bool[m].astype(float))[0, 1])


def _bucket_table(df: pd.DataFrame, feat: str, q: int = 4) -> pd.DataFrame:
    sub = df[df[feat].notna()].copy()
    if len(sub) < q * 10:
        return pd.DataFrame()
    try:
        sub["bucket"] = pd.qcut(sub[feat], q, labels=False, duplicates="drop")
    except ValueError:
        return pd.DataFrame()
    return sub.groupby("bucket").agg(
        n=("win", "size"),
        win_rate=("win", "mean"),
        mean_return=("return_pct", "mean"),
        feat_lo=(feat, "min"), feat_hi=(feat, "max"),
    ).reset_index()


def _auc(y: np.ndarray, p: np.ndarray) -> float:
    """ROC-AUC via rank statistic (no sklearn dependency)."""
    order = np.argsort(p)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(p) + 1)
    n_pos = y.sum(); n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


def _logit_auc(df: pd.DataFrame, feats: list[str]) -> float:
    """Walk-forward-free in-sample AUC of a logistic fit (sklearn if
    available, else a simple standardized-logit via numpy)."""
    sub = df.dropna(subset=feats + ["win"])
    if len(sub) < 100 or sub["win"].nunique() < 2:
        return float("nan")
    X = sub[feats].to_numpy(dtype=float)
    y = sub["win"].to_numpy(dtype=int)
    # standardize
    mu, sd = X.mean(0), X.std(0); sd[sd == 0] = 1.0
    Xs = (X - mu) / sd
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import cross_val_predict
        clf = LogisticRegression(max_iter=1000)
        p = cross_val_predict(clf, Xs, y, cv=5, method="predict_proba")[:, 1]
        return _auc(y, p)
    except Exception:    # noqa: BLE001
        # numpy fallback: gradient-descent logit, in-sample AUC
        w = np.zeros(Xs.shape[1]); b = 0.0; lr = 0.1
        for _ in range(500):
            z = Xs @ w + b
            p = 1.0 / (1.0 + np.exp(-z))
            g = p - y
            w -= lr * (Xs.T @ g) / len(y)
            b -= lr * g.mean()
        return _auc(y, 1.0 / (1.0 + np.exp(-(Xs @ w + b))))


def analyse(df: pd.DataFrame, out_csv: Path) -> None:
    res = df[df["is_resolved"] == True].copy()    # noqa: E712
    res = res[res["return_pct"].notna() & res["hold_bars"].notna()]
    if len(res) < 50:
        log.warning("only %d resolved events — too few to conclude", len(res))
    # success label: held at least the phase-median hold
    med = res.groupby("phase")["hold_bars"].transform("median")
    res["win"] = (res["hold_bars"] >= med).astype(int)

    print("\n" + "=" * 70)
    print(f"MFI FEATURE STUDY — {len(res)} resolved events, "
          f"{res['symbol'].nunique()} symbols")
    print(f"overall win-rate (held >= phase-median): {res['win'].mean():.3f}")
    print("=" * 70)

    print("\nUnivariate signal (correlation with outcome):")
    print(f"{'feature':<14}{'corr(win)':>12}{'corr(ret%)':>12}")
    for f in _MFI_FEATURES:
        c_win = _point_biserial(res[f], res["win"])
        m = res[f].notna() & res["return_pct"].notna()
        c_ret = float(np.corrcoef(res[f][m], res["return_pct"][m])[0, 1]) if m.sum() > 30 else float("nan")
        print(f"{f:<14}{c_win:>12.4f}{c_ret:>12.4f}")

    for f in _MFI_FEATURES:
        bt = _bucket_table(res, f)
        if bt.empty:
            continue
        print(f"\nQuartile buckets — {f}:")
        for _, r in bt.iterrows():
            print(f"  Q{int(r['bucket'])+1}: n={int(r['n']):5d}  "
                  f"win={r['win_rate']:.3f}  ret%={r['mean_return']:+.2f}  "
                  f"[{r['feat_lo']:.2f}, {r['feat_hi']:.2f}]")

    print("\nIncremental value (5-fold CV AUC on the `win` label):")
    base = [f for f in _EXISTING_FEATURES if f in res and res[f].notna().any()]
    auc_base = _logit_auc(res, base)
    auc_full = _logit_auc(res, base + _MFI_FEATURES)
    print(f"  existing features          : AUC = {auc_base:.4f}")
    print(f"  existing + MFI features    : AUC = {auc_full:.4f}")
    if auc_base == auc_base and auc_full == auc_full:
        delta = auc_full - auc_base
        print(f"  delta from MFI             : {delta:+.4f}")
        verdict = ("MFI adds meaningful signal — worth wiring in"
                   if delta >= 0.005 else
                   "MFI adds negligible signal — keep it out")
        print(f"  VERDICT: {verdict}")

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    res.to_csv(out_csv, index=False)
    print(f"\nfull event table written → {out_csv}")


def _discover_cache_symbols(cache_dir: Path) -> tuple[str, ...]:
    """Every symbol with a parquet in ``cache_dir`` (one file per
    symbol, ``<SYMBOL>.parquet``). This is the most robust source —
    it tests exactly what's actually cached, regardless of any DB.
    """
    if not cache_dir.is_dir():
        return ()
    return tuple(sorted(p.stem for p in cache_dir.glob("*.parquet")))


def _symbols_from_db(db_path: Path) -> tuple[str, ...]:
    """Symbol list from a nifty500_industry_db.json (keys = symbols)."""
    import json
    try:
        data = json.loads(db_path.read_text())
        return tuple(sorted(data.keys())) if isinstance(data, dict) else ()
    except Exception:    # noqa: BLE001
        log.exception("could not read symbol DB at %s", db_path)
        return ()


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Test whether MFI level/divergence adds predictive "
                    "value to the ride score. Runs against the local "
                    "price cache.",
    )
    ap.add_argument(
        "--cache-dir", type=str, default="",
        help="Directory of per-symbol OHLCV parquets "
             "(<SYMBOL>.parquet). Point this at your real cache if it "
             "lives outside the project, e.g. "
             "/Users/you/nimbus_data/cache/equity_price. "
             "Default: the project's resolved equity_price cache.",
    )
    ap.add_argument(
        "--symbols", type=str, default="",
        help="Explicit comma-separated symbols (overrides every other "
             "source).",
    )
    ap.add_argument(
        "--symbols-from", type=str, default="",
        help="Path to a nifty500_industry_db.json to draw the full "
             "symbol list from.",
    )
    ap.add_argument(
        "--symbols-from-cache", action="store_true",
        help="Use every symbol that has a parquet in --cache-dir. "
             "Most robust — tests exactly what's cached.",
    )
    ap.add_argument("--lookback", type=int, default=14)
    ap.add_argument("--mfi-period", type=int, default=14)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()

    cache_dir = Path(args.cache_dir).expanduser() if args.cache_dir else None

    # Symbol-source precedence: explicit list > DB file > cache scan >
    # the package DEFAULT_SYMBOLS.
    if args.symbols:
        symbols = tuple(s.strip().upper()
                        for s in args.symbols.split(",") if s.strip())
    elif args.symbols_from:
        symbols = _symbols_from_db(Path(args.symbols_from).expanduser())
    elif args.symbols_from_cache:
        if cache_dir is None:
            log.error("--symbols-from-cache requires --cache-dir")
            return 1
        symbols = _discover_cache_symbols(cache_dir)
    else:
        symbols = DEFAULT_SYMBOLS

    if not symbols:
        log.error("no symbols resolved — check --cache-dir / --symbols-from")
        return 1
    log.info("running over %d symbols (cache_dir=%s)",
             len(symbols), cache_dir or "<default>")

    ts = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
    out = Path(args.out) if args.out else _OUT_DIR / f"mfi_feature_{ts}.csv"

    df = build_events(symbols, args.lookback, args.mfi_period,
                      cache_dir=cache_dir)
    if df.empty:
        log.error("no events built — check the cache / symbols")
        return 1
    analyse(df, out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
