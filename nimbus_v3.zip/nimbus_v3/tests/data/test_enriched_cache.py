"""Tests for ``nimbus_v3.data.enriched_cache.EnrichedPanelCache``."""
from __future__ import annotations

import os
import time
from pathlib import Path

import pandas as pd
import pytest

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache


# ══════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════

@pytest.fixture
def raw_cache(tmp_path) -> ParquetCache:
    """Empty raw cache rooted at a per-test tmp_path."""
    return ParquetCache(base_dir=tmp_path / "raw")


@pytest.fixture
def enriched_cache(raw_cache, tmp_path) -> EnrichedPanelCache:
    """Empty enriched cache, schema_hash='abc12345', rooted under tmp."""
    return EnrichedPanelCache(
        raw_cache=raw_cache,
        schema_hash="abc12345",
        root=tmp_path / "enriched",
    )


def _small_frame(n: int = 50, seed: int = 0) -> pd.DataFrame:
    """Tiny OHLCV frame — just enough to parquet-roundtrip."""
    import numpy as np
    rng = np.random.default_rng(seed)
    closes = 100 + rng.normal(0, 1, n).cumsum()
    return pd.DataFrame({
        "Open": closes, "High": closes + 1, "Low": closes - 1,
        "Close": closes, "Volume": rng.uniform(1e5, 1e6, n),
    }, index=pd.bdate_range("2024-01-01", periods=n))


# ══════════════════════════════════════════════════════════════════════
# Basic flow
# ══════════════════════════════════════════════════════════════════════

class TestBasicGetSet:

    def test_empty_cache_returns_none(self, enriched_cache):
        assert enriched_cache.get_if_fresh("SBIN") is None

    def test_exists_false_on_empty(self, enriched_cache):
        assert enriched_cache.exists("SBIN") is False

    def test_set_then_get_roundtrip(self, raw_cache, enriched_cache):
        # Populate raw first (so get_if_fresh has a mtime to compare)
        raw_cache.set("SBIN", _small_frame())
        enriched = _small_frame(seed=99).assign(extra_col=1.0)
        enriched_cache.set("SBIN", enriched)

        hit = enriched_cache.get_if_fresh("SBIN")
        assert hit is not None
        # Column we added should be preserved
        assert "extra_col" in hit.columns
        # Parquet roundtrip drops the BusinessDay index freq metadata.
        # Compare without that detail — values are what matter.
        pd.testing.assert_frame_equal(
            hit, enriched, check_freq=False,
        )

    def test_exists_true_after_set(self, raw_cache, enriched_cache):
        raw_cache.set("SBIN", _small_frame())
        enriched_cache.set("SBIN", _small_frame(seed=1))
        assert enriched_cache.exists("SBIN") is True


# ══════════════════════════════════════════════════════════════════════
# Freshness detection
# ══════════════════════════════════════════════════════════════════════

class TestFreshness:

    def test_fresh_when_raw_older_than_enriched(
        self, raw_cache, enriched_cache,
    ):
        """Classic success path: raw written first, enriched written
        later, get_if_fresh should return the enriched frame."""
        raw_cache.set("SBIN", _small_frame())
        # Small sleep so mtimes are distinguishable on fast filesystems
        time.sleep(0.01)
        enriched = _small_frame(seed=2).assign(indicator=1.5)
        enriched_cache.set("SBIN", enriched)

        hit = enriched_cache.get_if_fresh("SBIN")
        assert hit is not None

    def test_stale_when_raw_newer_than_enriched(
        self, raw_cache, enriched_cache,
    ):
        """If the raw frame was refreshed AFTER the enriched cache,
        the enriched copy is stale and must return None."""
        enriched_cache.set("SBIN", _small_frame(seed=3))
        # Small sleep, then touch raw to give it a later mtime
        time.sleep(0.02)
        raw_cache.set("SBIN", _small_frame())

        # Force the raw file's mtime to be STRICTLY later than enriched
        raw_path = raw_cache.base_dir / "SBIN.parquet"
        enriched_path = enriched_cache._inner_path("SBIN")
        enriched_mtime = enriched_path.stat().st_mtime
        os.utime(raw_path, (enriched_mtime + 1, enriched_mtime + 1))

        hit = enriched_cache.get_if_fresh("SBIN")
        assert hit is None

    def test_returns_entry_when_raw_missing(
        self, enriched_cache,
    ):
        """Orphaned enriched entry (raw deleted) — still returns the
        cached frame. The caller decides what to do."""
        enriched_cache.set("ORPHAN", _small_frame(seed=4))
        hit = enriched_cache.get_if_fresh("ORPHAN")
        assert hit is not None


# ══════════════════════════════════════════════════════════════════════
# Schema-hash namespacing
# ══════════════════════════════════════════════════════════════════════

class TestSchemaNamespacing:

    def test_different_schema_hashes_are_isolated(
        self, raw_cache, tmp_path,
    ):
        """Two caches with different schema hashes must not share
        entries. Writing to one produces no hit in the other."""
        raw_cache.set("SBIN", _small_frame())
        root = tmp_path / "enriched"

        c1 = EnrichedPanelCache(
            raw_cache=raw_cache, schema_hash="v1hash00", root=root,
        )
        c2 = EnrichedPanelCache(
            raw_cache=raw_cache, schema_hash="v2hash00", root=root,
        )
        c1.set("SBIN", _small_frame(seed=5).assign(v1_col=True))

        # c2 must NOT see the v1 entry — different namespace
        assert c2.get_if_fresh("SBIN") is None
        assert c2.exists("SBIN") is False
        # c1 still sees its own entry
        assert c1.get_if_fresh("SBIN") is not None

    def test_schema_hash_property_exposes_value(
        self, raw_cache, tmp_path,
    ):
        c = EnrichedPanelCache(
            raw_cache=raw_cache, schema_hash="deadbeef",
            root=tmp_path / "enriched",
        )
        assert c.schema_hash == "deadbeef"


# ══════════════════════════════════════════════════════════════════════
# Corruption handling
# ══════════════════════════════════════════════════════════════════════

class TestCorruption:

    def test_corrupt_parquet_returns_none_and_removes_file(
        self, raw_cache, enriched_cache,
    ):
        raw_cache.set("SBIN", _small_frame())
        # Write garbage bytes as a "parquet" file
        corrupt_path = enriched_cache._inner_path("SBIN")
        corrupt_path.parent.mkdir(parents=True, exist_ok=True)
        corrupt_path.write_bytes(b"\x00\x01\x02garbage")

        result = enriched_cache.get_if_fresh("SBIN")
        assert result is None
        # File should have been removed for next-call determinism
        assert not corrupt_path.is_file()


# ══════════════════════════════════════════════════════════════════════
# StrategyComputeEngine schema-hash wiring
# ══════════════════════════════════════════════════════════════════════

class TestEngineSchemaHash:
    """Verify the compute engine produces a stable, short hash."""

    def test_hash_is_stable_across_calls(self):
        from nimbus_v3.compute.engine import StrategyComputeEngine
        h1 = StrategyComputeEngine.enrichment_schema_hash()
        h2 = StrategyComputeEngine.enrichment_schema_hash()
        assert h1 == h2

    def test_hash_length_and_format(self):
        from nimbus_v3.compute.engine import StrategyComputeEngine
        h = StrategyComputeEngine.enrichment_schema_hash()
        assert len(h) == 8
        # All hex chars (lowercase)
        assert all(c in "0123456789abcdef" for c in h)
