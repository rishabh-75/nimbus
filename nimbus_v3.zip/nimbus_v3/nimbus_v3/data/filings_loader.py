"""nimbus_v3.data.filings_loader — corporate announcements loader.

Fetches NSE corporate filings (announcements, intimations, disclosures)
for an individual symbol. Returns a list of typed ``Filing`` records
sorted most-recent first. Impact classification is a separate concern
handled by ``context/filing_context.py::FilingImpactClassifier`` — this
module only fetches and parses.

Cache
─────
Per-symbol parquet cache with a short TTL (1 hour). Filings land
throughout the trading day, so a fresh fetch on every scan is not the
pattern; callers refresh when they see a reason (manual UI action, or
scheduled poll).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import timedelta
from typing import Final

import pandas as pd

from nimbus_v3.data.base import CacheStore
from nimbus_v3.data.nse_client import NSEClient


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Endpoint
# ══════════════════════════════════════════════════════════════════════════════

_FILINGS_ENDPOINT: Final[str] = "https://www.nseindia.com/api/corporate-announcements"
_FILINGS_REFERER: Final[str] = (
    "https://www.nseindia.com/companies-listing/corporate-filings-announcements"
)
_DEFAULT_TTL: Final[timedelta] = timedelta(hours=1)


# ══════════════════════════════════════════════════════════════════════════════
# Data shape
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class Filing:
    """One corporate filing. Frozen for cross-thread use."""
    symbol: str
    filing_date: pd.Timestamp     # tz-naive
    category: str                 # NSE's subject/category string
    headline: str                 # short description / desc field
    details: str                  # longer body when available; "" otherwise
    attachment_url: str | None    # PDF URL when present

    def __post_init__(self) -> None:
        if not isinstance(self.filing_date, pd.Timestamp):
            object.__setattr__(self, "filing_date", pd.Timestamp(self.filing_date))
        if self.filing_date.tz is not None:
            object.__setattr__(self, "filing_date", self.filing_date.tz_localize(None))


# ══════════════════════════════════════════════════════════════════════════════
# Loader
# ══════════════════════════════════════════════════════════════════════════════

class FilingsLoader:
    """Per-symbol corporate-filing loader backed by the shared NSE client.

    Returns a list of ``Filing`` objects sorted by ``filing_date``
    descending. Empty list on fetch failure or empty payload.
    """

    def __init__(
        self,
        nse_client: NSEClient,
        cache: CacheStore,
        *,
        default_cache_ttl: timedelta = _DEFAULT_TTL,
    ) -> None:
        self._nse = nse_client
        self._cache = cache
        self._ttl = default_cache_ttl

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def load(self, symbol: str, *, force_refresh: bool = False) -> list[Filing]:
        """Return filings for ``symbol``, most-recent first."""
        if not symbol:
            raise ValueError("symbol must be non-empty")

        if not force_refresh and self._cache_is_fresh(symbol):
            cached = self._cache.get(symbol)
            if cached is not None:
                return [_row_to_filing(r) for _, r in cached.iterrows()]

        filings = self._fetch(symbol)
        if filings:
            self._cache.set(symbol, _filings_to_df(filings))
        return filings

    def load_since(
        self,
        symbol: str,
        *,
        asof_date: pd.Timestamp,
        lookback_days: int = 30,
        force_refresh: bool = False,
    ) -> list[Filing]:
        """Return filings between ``asof_date - lookback_days`` and ``asof_date``.

        Most-recent first. Useful for the context provider, which only
        cares about the recent window.
        """
        asof = _normalise(asof_date)
        window_start = asof - pd.Timedelta(days=lookback_days)
        all_filings = self.load(symbol, force_refresh=force_refresh)
        return [
            f for f in all_filings
            if window_start <= f.filing_date <= asof
        ]

    # ══════════════════════════════════════════════════════════════════════
    # Private
    # ══════════════════════════════════════════════════════════════════════

    def _cache_is_fresh(self, symbol: str) -> bool:
        age = self._cache.age(symbol)
        return age is not None and age < self._ttl

    def _fetch(self, symbol: str) -> list[Filing]:
        payload = self._nse.fetch(
            _FILINGS_ENDPOINT,
            referer=_FILINGS_REFERER,
            params={"index": "equities", "symbol": symbol.upper()},
        )
        if not payload:
            return []
        return parse_filings_payload(payload, symbol)


# ══════════════════════════════════════════════════════════════════════════════
# Parsing
# ══════════════════════════════════════════════════════════════════════════════

def parse_filings_payload(payload: object, symbol: str) -> list[Filing]:
    """Parse an NSE corporate-announcements payload into ``Filing``s.

    Accepts both list-shape and dict-shape responses. Rows without any
    usable date are skipped. Sorted newest-first.

    Field-name tolerance:
        date     → ``an_dt`` | ``broadcastDate`` | ``date`` | ``filingDate``
        category → ``desc`` | ``subject`` | ``category`` | ``broadcastMsg``
        headline → ``subject`` | ``sm_name`` | ``subjectLine`` | ``desc``
        details  → ``attchmntText`` | ``details`` | ``moreDesc`` | ""
        attach   → ``attchmntFile`` | ``fileLink`` | ``attachmentUrl``
    """
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict):
        # Common shape is {"rows": [...]} or {"data": [...]}
        rows = payload.get("rows") or payload.get("data") or []
        if not isinstance(rows, list):
            rows = []
    else:
        return []

    filings: list[Filing] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        filing_date = _parse_date(
            row.get("an_dt")
            or row.get("broadcastDate")
            or row.get("date")
            or row.get("filingDate")
        )
        if filing_date is None:
            continue

        category = str(
            row.get("desc")
            or row.get("category")
            or row.get("broadcastMsg")
            or ""
        ).strip()
        headline = str(
            row.get("subject")
            or row.get("sm_name")
            or row.get("subjectLine")
            or row.get("desc")
            or ""
        ).strip()
        details = str(
            row.get("attchmntText")
            or row.get("details")
            or row.get("moreDesc")
            or ""
        ).strip()
        attach = (
            row.get("attchmntFile")
            or row.get("fileLink")
            or row.get("attachmentUrl")
        )
        attach_url = str(attach).strip() if attach else None

        filings.append(Filing(
            symbol=symbol.upper(),
            filing_date=filing_date,
            category=category,
            headline=headline,
            details=details,
            attachment_url=attach_url if attach_url else None,
        ))

    filings.sort(key=lambda f: f.filing_date, reverse=True)
    return filings


# ══════════════════════════════════════════════════════════════════════════════
# Cache round-trip
# ══════════════════════════════════════════════════════════════════════════════

def _filings_to_df(filings: list[Filing]) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "symbol": f.symbol,
            "filing_date": f.filing_date,
            "category": f.category,
            "headline": f.headline,
            "details": f.details,
            "attachment_url": f.attachment_url if f.attachment_url else "",
        }
        for f in filings
    ])


def _row_to_filing(row: pd.Series) -> Filing:
    url = str(row.get("attachment_url", "") or "").strip() or None
    return Filing(
        symbol=str(row["symbol"]),
        filing_date=pd.Timestamp(row["filing_date"]),
        category=str(row.get("category", "")),
        headline=str(row.get("headline", "")),
        details=str(row.get("details", "")),
        attachment_url=url,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Shared helpers
# ══════════════════════════════════════════════════════════════════════════════

def _parse_date(value: object) -> pd.Timestamp | None:
    if value is None or value == "":
        return None
    try:
        ts = pd.to_datetime(value, errors="coerce", dayfirst=True)
    except (TypeError, ValueError):
        return None
    if ts is pd.NaT or pd.isna(ts):
        return None
    ts = pd.Timestamp(ts)
    if ts.tz is not None:
        ts = ts.tz_localize(None)
    return ts


def _normalise(ts: pd.Timestamp) -> pd.Timestamp:
    t = pd.Timestamp(ts)
    if t.tz is not None:
        t = t.tz_localize(None)
    return t.normalize()
