# Retired: Industry Relative-Strength Analytics Subsystem

**Retired:** 2026-06-18
**Reason:** Orphaned by the ride-only refactor. Not on any live code
path — only `MIN_INDUSTRY_SIZE` and a never-called `_thin_peer_for`
method tethered it. Removed per the architecture audit (Issue 1).
**Restorable:** yes — core algorithms preserved below.

## What this was

A peer-relative analytics stack computing, per symbol, its strength
*relative to its industry*: rolling beta, alpha (in %/day), alpha
percentile across the panel, plus an industry trend-phase label. The
intent was a "context card" showing whether a symbol was leading or
lagging its peers, and whether its industry as a whole was trending.

It was built before the strategy narrowed to the pure BB-ride
classifier + breadth regime. When the app went ride-only, this stack
stopped being wired to anything but was never removed.

## Modules removed

| Module | Lines | Role |
|--------|-------|------|
| `compute/industry_analytics.py` | 906 | `IndustryAnalyticsEngine` — beta/alpha/percentile/phase |
| `analysis/trend_phase.py` | 431 | trend-phase classifier (ADX/slope-based) consumed by the engine |
| `context/sector_context.py` | 358 | sector RS context provider (had zero importers) |
| `core/industry_state.py` | 103 | `IndustryState` frozen dataclass |
| `core/industry_relative_state.py` | 204 | `IndustryRelativeState` + `ThinPeerContext` dataclasses |

Plus tests: `tests/compute/test_industry_analytics.py`,
`tests/analysis/test_trend_phase.py`, `tests/context/test_sector_context.py`,
`tests/ui/test_main_window_thin_peer.py`.

Also removed `MainWindow._thin_peer_for` (defined, never called) and the
`MIN_INDUSTRY_SIZE = 5` constant it read.

## Preserved core logic (for reconstruction)

### Leave-one-out industry return + rolling beta/alpha

The key idea: to measure a stock vs. its industry without the stock
contaminating its own benchmark, reconstruct the industry return
*excluding* the stock (leave-one-out), then regress.

```python
# r_loo = (n * r_industry - r_stock) / (n - 1)   per bar, n = member count
stock_ret = raw_df["Close"].pct_change()
ind_ew_ret = industry_frame["ew_close"].pct_change()   # equal-weight industry
member_count = industry_frame["member_count"].astype(float)

with np.errstate(divide="ignore", invalid="ignore"):
    r_loo = np.where(
        n > 1,
        (n * ind_ew_ret - stock_ret) / (n - 1),
        np.nan,                       # alone in industry → undefined
    )

# Rolling beta = cov(stock, ind_loo) / var(ind_loo) over BETA_WINDOW (60d)
cov  = stock_ret.rolling(60).cov(r_loo)
var  = r_loo.rolling(60).var()
beta = cov / var.replace(0, np.nan)

# Alpha = mean(stock_ret - beta * r_loo) over the same window, in %/day
residual   = stock_ret - beta * r_loo
alpha_60d  = residual.rolling(60).mean() * 100
```

### Panel-wide alpha percentile

Alpha percentile was ranked across the *whole panel* at each bar (not
within industry) — the research edge (~+2pp/20d) was measured against
panel deciles:

```python
alpha_wide = pd.DataFrame({sym: f["alpha_60d"] for sym, f in frames.items()})
ranks = alpha_wide.rank(axis=1, pct=True) * 100    # 0..100 per date
# write ranks[sym] back onto each symbol's frame as `alpha_percentile`
```

### Equal-weight industry frame

`enrich_industry` built an equal-weight synthetic industry series
(`ew_close`) plus breadth (`pct_above_sma_20`), ROC, and a per-bar
`member_count` (adapts to historical listings/delistings). The LOO math
above depends on `ew_close` and `member_count`.

### ThinPeerContext

A small UI dataclass: when an industry had `< MIN_INDUSTRY_SIZE (=5)`
members, peer analytics are statistically meaningless, so the card
showed `industry · N members · peer analytics require ≥5` instead of
junk beta/alpha. Trivial to reconstruct (industry: str, n_members: int,
min_required: int).

## If restoring

1. The strategy is intentionally ride-only + display-only breadth
   (RT-004). Re-introducing RS analytics as *scoring* input would need
   validation like RT-001..004 — don't wire it into the score blind.
2. As a *display* context card (the original intent), it's low-risk:
   compute the above, render alpha_percentile + industry_phase beside
   the ride view. That was the design.
3. `git`/zip history holds the full 2,000 lines if more than these
   cores are needed.
