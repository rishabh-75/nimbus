"""
ui/etf_tab.py — ETF Momentum Scanner tab.
Scans NSE ETFs for pullback-in-trend momentum entries.
Walk-forward validated: Sharpe 2.15, Win 60%, Avg +2.91%.
"""
from __future__ import annotations
import logging, time
from PyQt6.QtCore import Qt, QAbstractTableModel, QModelIndex, QSortFilterProxyModel, pyqtSignal, QThread
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame, QPushButton,
    QLabel, QTableView, QHeaderView, QAbstractItemView, QSpinBox,
)
from PyQt6.QtGui import QFont, QColor, QBrush
from ui.theme import (
    BG, SURFACE, BORDER, EM, MUTED, RED, GOLD, GREEN, BLUE, WHITE,
    FONT_MONO, FONT_UI,
    grade_fg, grade_bg, sizing_fg, verdict_fg, ride_status_fg, nav_prem_fg,
    compute_ride_status,
)
from ui.components import Badge
logger = logging.getLogger(__name__)

# Phase logic lives in modules/ (no PyQt6 dependency → testable)
from modules.etf_phase import apply_phase_logic as _apply_phase_logic
# ETF universe — dynamic from NSE (falls back to hardcoded if NSE unreachable)
_FALLBACK_ETF_SYMBOLS = [
    "GOLDBEES", "GOLDCASE", "GOLDETF", "IVZINGOLD",
    "SILVERBEES", "SILVERIETF",
    "NIFTYBEES", "SETFNIF50", "JUNIORBEES", "NV20IETF",
    "BANKBEES", "SETFNIFBK", "PSUBNKBEES", "FINIETF",
    "ITBEES", "PHARMABEES", "INFRABEES", "CPSEETF",
    "AUTOIETF", "FMCGIETF", "HEALTHIETF",
    "COMMOIETF", "METALIETF", "OILIETF",
    "MOM100", "LOWVOLIETF", "MIDCAPIETF",
    "N100", "MON100", "MAFANG", "HNGSNGBEES",
]
def _get_etf_symbols() -> list[str]:
    """Get ETF symbols from live NSE universe, fallback to hardcoded."""
    try:
        from modules.etf_universe import get_universe
        universe = get_universe()
        symbols = universe.get_momentum_universe()
        if symbols and len(symbols) >= 10:
            # Extra filter: exclude liquid/debt/overnight ETFs by name
            return [s for s in symbols if "LIQ" not in s.upper()]
    except Exception:
        pass
    return _FALLBACK_ETF_SYMBOLS
_COLUMNS = [
    ("Symbol", "symbol", 90),
    ("Price", "last_price", 75),
    ("Chg%", "day_chg", 50),
    ("Size", "sizing", 50),
    ("WR(20)", "wr", 50),
    ("MFI", "mfi", 45),
    ("vs SMA50", "pct_sma50", 65),
    ("Dip", "dip", 50),
    ("BBW Δ", "bbw_slope", 50),
    ("Vol", "vol_ratio", 45),
    ("ADTV", "adtv", 55),
    ("#", "display_rank", 30),
    ("Grade", "grade", 45),
    ("%B", "ride_pctb", 45),
    ("Ride", "ride_status", 75),
    ("NAV%", "nav_prem", 50),
    ("Verdict", "verdict", 350),
]

_GRADE_ORD = {"S": 0, "A+": 1, "A": 2, "B+": 3, "B": 4, "C+": 5, "C": 6, "D": 7, "—": 8}


def _assign_etf_ranks(rows: list[dict]):
    """Assign display_rank 1,2,3... to entries after sort. Non-entries get 0."""
    rank = 1
    for r in rows:
        if r.get("entry"):
            r["display_rank"] = rank
            rank += 1
        else:
            r["display_rank"] = 0


class _ETFTopNProxy(QSortFilterProxyModel):
    """Proxy that filters to show only top N ranked entries."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._top_n = 0
    def set_top_n(self, n: int):
        self._top_n = n
        self.invalidateFilter()
    def filterAcceptsRow(self, source_row, source_parent):
        if self._top_n <= 0:
            return True
        model = self.sourceModel()
        if model is None:
            return True
        row_data = model.row_data(source_row) if hasattr(model, "row_data") else None
        if row_data is None:
            return True
        rank = row_data.get("display_rank", 0)
        return 0 < rank <= self._top_n
# ══════════════════════════════════════════════════════════════════════════════
# SCAN WORKER
# ══════════════════════════════════════════════════════════════════════════════
class ETFScanWorker(QThread):
    row_ready = pyqtSignal(dict)
    finished_all = pyqtSignal(list)
    def __init__(self, symbols, min_score=0):
        super().__init__()
        self.symbols = symbols
        self.min_score = min_score
        self._cancelled = False
    def cancel(self):
        self._cancelled = True
    def run(self):
        from modules.data import get_price_daily, fetch_india_vix
        from modules.etf_momentum import compute_etf
        from modules.etf_ride import compute_etf_ride
        from modules.conviction import classify_vix_regime
        # Fetch VIX once for both strategies
        vix_val = None
        vix_regime = "UNKNOWN"
        try:
            vix_val = fetch_india_vix()
            vix_regime = classify_vix_regime(vix_val)
        except Exception:
            pass
        # ETF universe for NAV premium (cached, zero network calls)
        etf_uni = None
        try:
            from modules.etf_universe import get_universe
            etf_uni = get_universe()
        except Exception:
            pass
        results = []
        for sym in self.symbols:
            if self._cancelled: break
            try:
                # ── FETCH ONCE ────────────────────────────────────
                df, msg = get_price_daily(sym, days=400)
                if df.empty or len(df) < 60:
                    continue
                # ADTV (shared)
                if "Volume" in df.columns and "Close" in df.columns:
                    traded_val = df["Close"].tail(20) * df["Volume"].tail(20)
                    adtv_cr = float(traded_val.mean()) / 1e7
                else:
                    adtv_cr = 0.0

                # Day change % (shared)
                day_chg = 0.0
                if len(df) >= 2:
                    c = float(df["Close"].iloc[-1])
                    p = float(df["Close"].iloc[-2])
                    if p > 0:
                        day_chg = round((c / p - 1) * 100, 2)

                # NAV premium — spot vs NAV (from cached ETF universe)
                nav_prem = None
                try:
                    if etf_uni:
                        spot = float(df["Close"].iloc[-1])
                        nav_prem = etf_uni.get_premium_pct(sym, spot=spot)
                except Exception:
                    pass

                # ══ ETF MOMENTUM (pullback-in-trend) ══════════════
                r = compute_etf(df, symbol=sym, vix=vix_val)
                if not r.data_sufficient:
                    continue
                qr = r.quality_rank
                if adtv_cr >= 100:   qr += 15
                elif adtv_cr >= 20:  qr += 12
                elif adtv_cr >= 5:   qr += 8
                elif adtv_cr >= 1:   qr += 4
                qr = max(0, min(100, qr))
                row = {
                    "symbol": sym,
                    "last_price": r.close,
                    "day_chg": day_chg,
                    "grade": r.grade,
                    "verdict": r.verdict,
                    "sizing": r.sizing if adtv_cr >= 1.0 else "SKIP",
                    "adtv": round(adtv_cr, 1),
                    "wr": round(r.wr_20, 1),
                    "dip": f"{r.wr_min_10:.0f}" if r.dip_detected else "—",
                    "mfi": round(r.mfi, 0),
                    "pct_sma50": round(r.pct_from_sma50, 1),
                    "bbw_slope": round(r.bbw_slope, 2),
                    "vol_ratio": round(r.vol_ratio, 1),
                    "entry": r.entry_triggered and adtv_cr >= 1.0,
                    "in_uptrend": r.in_uptrend,
                    "dip_detected": r.dip_detected,
                    "recovered": r.recovered,
                    "illiquid": adtv_cr < 1.0,
                    "vix": round(vix_val, 1) if vix_val else None,
                    "quality_rank": round(qr, 1),
                    "display_rank": 0,
                    # Ride defaults (overwritten below if computed)
                    "ride_pctb": None,
                    "ride_grade": "—",
                    "ride_verdict": "",
                    "ride_status": "—",
                    "ride_entry": False,
                    "ride_vix_gated": False,
                    "nav_prem": round(nav_prem, 2) if nav_prem is not None else None,
                }

                # ══ ETF BB RIDE — merge into same row ═════════════
                try:
                    if len(df) >= 80:
                        ride_r = compute_etf_ride(df, symbol=sym, vix_regime=vix_regime)
                        if ride_r.data_sufficient:
                            pctb = round(ride_r.bb_pct, 2)
                            row["ride_pctb"] = pctb
                            row["ride_grade"] = ride_r.grade
                            row["ride_verdict"] = ride_r.verdict
                            row["ride_entry"] = ride_r.entry_triggered and not ride_r.vix_gated
                            row["ride_vix_gated"] = ride_r.vix_gated
                            # Compact ride status for table column
                            row["ride_status"] = compute_ride_status(ride_r)
                            # Boost rank if both strategies agree
                            if row["entry"] and row["ride_entry"]:
                                row["quality_rank"] = min(100, row["quality_rank"] + 10)
                except Exception as e:
                    logger.debug("ETF ride %s failed: %s", sym, e)

                # ══ PHASE-AWARE PRIMARY GRADE/VERDICT ═════════════
                _apply_phase_logic(row, r.grade, adtv_cr, nav_prem=nav_prem)

                if r.momentum_score >= self.min_score:
                    results.append(row)
                    self.row_ready.emit(row)
            except Exception as e:
                logger.debug("ETF scan %s failed: %s", sym, e)
        self.finished_all.emit(results)
# ══════════════════════════════════════════════════════════════════════════════
# TABLE MODEL
# ══════════════════════════════════════════════════════════════════════════════
class ETFModel(QAbstractTableModel):
    def __init__(self):
        super().__init__()
        self._data: list[dict] = []
    def set_results(self, rows):
        self.beginResetModel()
        self._data = rows
        self.endResetModel()
    def clear(self):
        self.beginResetModel()
        self._data = []
        self.endResetModel()
    def row_data(self, row_idx):
        if 0 <= row_idx < len(self._data):
            return self._data[row_idx]
        return None
    def rowCount(self, parent=QModelIndex()): return len(self._data)
    def columnCount(self, parent=QModelIndex()): return len(_COLUMNS)
    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return _COLUMNS[section][0]
        return None
    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid(): return None
        row = self._data[index.row()]
        _, col_key, _ = _COLUMNS[index.column()]
        val = row.get(col_key)
        if role == Qt.ItemDataRole.DisplayRole:
            if val is None: return "—"
            if col_key == "last_price": return f"{val:,.2f}"
            if col_key == "day_chg" and isinstance(val, (int, float)): return f"{val:+.2f}%"
            if col_key == "wr" and isinstance(val, (int, float)): return f"{val:.0f}"
            if col_key == "pct_sma50" and isinstance(val, (int, float)): return f"{val:+.1f}%"
            if col_key == "mfi" and isinstance(val, (int, float)): return f"{val:.0f}"
            if col_key == "bbw_slope" and isinstance(val, (int, float)): return f"{val:+.1f}"
            if col_key == "vol_ratio" and isinstance(val, (int, float)): return f"{val:.1f}x"
            if col_key == "adtv" and isinstance(val, (int, float)):
                if val >= 10: return f"{val:.0f}"
                return f"{val:.1f}"
            if col_key == "display_rank" and isinstance(val, (int, float)):
                return f"#{int(val)}" if val > 0 else "—"
            if col_key == "ride_pctb" and isinstance(val, (int, float)):
                return f"{val:.2f}"
            if col_key == "nav_prem" and isinstance(val, (int, float)):
                return f"{val:+.2f}%"
            return str(val)
        if role == Qt.ItemDataRole.ForegroundRole:
            if col_key == "day_chg" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0 else (RED if val < 0 else MUTED)))
            if col_key == "grade":
                return QBrush(QColor(grade_fg(val)))
            if col_key == "verdict":
                return QBrush(QColor(verdict_fg(val)))
            if col_key == "sizing":
                return QBrush(QColor(sizing_fg(val)))
            if col_key == "ride_status":
                return QBrush(QColor(ride_status_fg(val)))
            if col_key == "nav_prem" and isinstance(val, (int, float)):
                return QBrush(QColor(nav_prem_fg(val)))
            if col_key == "adtv" and isinstance(val, (int, float)):
                if val >= 50: return QBrush(QColor(GREEN))
                if val >= 10: return QBrush(QColor(EM))
                if val >= 1: return QBrush(QColor(GOLD))
                return QBrush(QColor(RED))
            if col_key == "wr" and isinstance(val, (int, float)):
                return QBrush(QColor(RED if val < -60 else (GOLD if val < -30 else GREEN)))
            if col_key == "mfi" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 55 else (GREEN if val >= 40 else (MUTED if val >= 30 else RED))))
            if col_key == "pct_sma50" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0 else RED))
            if col_key == "bbw_slope" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0.5 else (MUTED if val > -0.5 else RED)))
            if col_key == "vol_ratio" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 1.5 else (GREEN if val >= 1.0 else (GOLD if val >= 0.5 else RED))))
            if col_key == "display_rank" and isinstance(val, (int, float)):
                if val <= 0: return QBrush(QColor(MUTED))
                if val <= 3: return QBrush(QColor(GREEN))
                if val <= 10: return QBrush(QColor(EM))
                if val <= 20: return QBrush(QColor(GOLD))
                return QBrush(QColor(MUTED))
            if col_key == "ride_pctb" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val >= 1.0 else (GOLD if val >= 0.75 else MUTED)))
        if role == Qt.ItemDataRole.BackgroundRole:
            if col_key == "grade":
                bg = grade_bg(val)
                if bg: return QBrush(QColor(*bg))
        if role == Qt.ItemDataRole.FontRole:
            if col_key in ("sizing", "symbol", "grade", "ride_status"):
                f = QFont(FONT_MONO, 10); f.setBold(True); return f
            if col_key in ("last_price", "wr", "mfi", "pct_sma50", "adtv",
                           "bbw_slope", "vol_ratio", "display_rank", "ride_pctb", "nav_prem",
                           "day_chg"):
                return QFont(FONT_MONO, 10)
        if role == Qt.ItemDataRole.TextAlignmentRole:
            if col_key in ("last_price", "wr", "mfi", "pct_sma50", "adtv",
                           "grade", "bbw_slope", "vol_ratio", "display_rank",
                           "ride_pctb", "ride_status", "nav_prem", "day_chg"):
                return Qt.AlignmentFlag.AlignCenter
        if role == Qt.ItemDataRole.UserRole:
            if val is None: return -9999
            if isinstance(val, (int, float)): return float(val)
            if isinstance(val, str):
                try: return float(val.replace("▶", "").replace("▷", "").strip())
                except ValueError: pass
            return str(val)
        return None
# ══════════════════════════════════════════════════════════════════════════════
# ETF TAB
# ══════════════════════════════════════════════════════════════════════════════
class ETFMomentumTab(QWidget):
    symbol_selected = pyqtSignal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker = None
        self._rerank_timer = None
        self._rerank_dirty = False
        self._build_ui()
        self._proxy.set_top_n(self._topn_spin.value())
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Control bar ───────────────────────────────────────────
        ctrl_bar = QFrame()
        ctrl_bar.setFixedHeight(32)
        ctrl_bar.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-bottom: 1px solid {BORDER}; }}"
            f"QPushButton {{ background: {EM}; color: {BG}; font-weight: bold;"
            f"  border: none; border-radius: 2px; padding: 4px 12px;"
            f"  font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QPushButton:hover {{ background: #34D399; }}"
            f"QPushButton:pressed {{ background: #059669; }}"
            f"QSpinBox {{ background: {BG}; color: {WHITE}; border: 1px solid {BORDER};"
            f"  border-radius: 2px; padding: 2px 4px; font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 9px;"
            f"  background: transparent; border: none; }}"
        )
        ctrl = QHBoxLayout(ctrl_bar)
        ctrl.setContentsMargins(8, 0, 8, 0)
        ctrl.setSpacing(8)

        self._run_btn = QPushButton("▶ SCAN")
        self._run_btn.setFixedHeight(22)
        self._run_btn.setFixedWidth(80)
        self._run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._run_btn.clicked.connect(self._on_run)
        ctrl.addWidget(self._run_btn)

        ctrl.addStretch(1)

        ctrl.addWidget(QLabel("TOP"))
        self._topn_spin = QSpinBox()
        self._topn_spin.setRange(0, 50)
        self._topn_spin.setValue(10)
        self._topn_spin.setSpecialValueText("ALL")
        self._topn_spin.setFixedWidth(50)
        self._topn_spin.setFixedHeight(22)
        self._topn_spin.setToolTip("Show top N ranked entries (0 = all)")
        self._topn_spin.valueChanged.connect(self._on_topn_changed)
        ctrl.addWidget(self._topn_spin)

        self._progress = QLabel("")
        ctrl.addWidget(self._progress)
        root.addWidget(ctrl_bar)

        # ── Strategy strip ────────────────────────────────────────
        sstrip = QFrame()
        sstrip.setFixedHeight(22)
        sstrip.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-bottom: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 7px;"
            f"  background: transparent; border: none; }}"
        )
        sl = QHBoxLayout(sstrip)
        sl.setContentsMargins(10, 0, 10, 0)
        sl.setSpacing(6)
        sl.addWidget(Badge("MOMENTUM"))
        strat = QLabel("MOMENTUM: dip-in-trend · WR(20) dip → recover  ·  RIDE: BB(1σ) upper touch · trail 3×ATR · VIX gate")
        sl.addWidget(strat, stretch=1)
        root.addWidget(sstrip)

        # ── Table header ──────────────────────────────────────────
        tbl_hdr = QFrame()
        tbl_hdr.setFixedHeight(22)
        tbl_hdr.setStyleSheet(
            f"background: {SURFACE}; border-left: 3px solid {EM};"
        )
        thl = QHBoxLayout(tbl_hdr)
        thl.setContentsMargins(10, 0, 10, 0)
        tbl_title = QLabel("ETF MOMENTUM + RIDE")
        tbl_title.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        tbl_title.setStyleSheet(f"color: {EM}; background: transparent; border: none;")
        thl.addWidget(tbl_title)
        thl.addStretch(1)
        self._count_lbl = QLabel("")
        self._count_lbl.setFont(QFont(FONT_MONO, 7))
        self._count_lbl.setStyleSheet(f"color: {MUTED}; background: transparent; border: none;")
        thl.addWidget(self._count_lbl)
        root.addWidget(tbl_hdr)

        # ── Pro terminal table styling ────────────────────────────
        _TABLE_STYLE = (
            f"QTableView {{"
            f"  background: {BG}; alternate-background-color: #0A0E14;"
            f"  gridline-color: transparent; border: none;"
            f"  selection-background-color: rgba(16,185,129,0.08);"
            f"  selection-color: {WHITE};"
            f"  font-family: '{FONT_MONO}'; font-size: 10px;"
            f"}}"
            f"QTableView::item {{"
            f"  padding: 0px 5px;"
            f"  border-bottom: 1px solid #0C1018;"
            f"}}"
            f"QTableView::item:selected {{ background: rgba(16,185,129,0.08); }}"
            f"QHeaderView::section {{"
            f"  background: {SURFACE}; color: {MUTED};"
            f"  border: none; border-bottom: 1px solid {BORDER};"
            f"  border-right: 1px solid #0C1018;"
            f"  font-family: '{FONT_MONO}'; font-size: 9px;"
            f"  font-weight: 600; padding: 3px 5px;"
            f"  text-transform: uppercase; letter-spacing: 0.5px;"
            f"}}"
            f"QScrollBar:vertical {{"
            f"  background: transparent; width: 5px; margin: 0; border: none;"
            f"}}"
            f"QScrollBar::handle:vertical {{"
            f"  background: {BORDER}; border-radius: 2px; min-height: 20px;"
            f"}}"
            f"QScrollBar::handle:vertical:hover {{ background: {MUTED}; }}"
            f"QScrollBar:horizontal {{"
            f"  background: transparent; height: 5px; margin: 0; border: none;"
            f"}}"
            f"QScrollBar::handle:horizontal {{"
            f"  background: {BORDER}; border-radius: 2px; min-width: 20px;"
            f"}}"
            f"QScrollBar::handle:horizontal:hover {{ background: {MUTED}; }}"
            f"QScrollBar::add-line, QScrollBar::sub-line,"
            f"QScrollBar::add-page, QScrollBar::sub-page {{ background: none; border: none; height: 0; width: 0; }}"
        )

        self._model = ETFModel()
        self._proxy = _ETFTopNProxy()
        self._proxy.setSourceModel(self._model)
        self._proxy.setSortRole(Qt.ItemDataRole.UserRole)
        self._table = QTableView()
        self._table.setModel(self._proxy)
        self._table.setSortingEnabled(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setAlternatingRowColors(True)
        self._table.verticalHeader().setVisible(False)
        self._table.verticalHeader().setDefaultSectionSize(24)
        self._table.setShowGrid(False)
        self._table.setMouseTracking(True)
        self._table.setStyleSheet(_TABLE_STYLE)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        hdr = self._table.horizontalHeader()
        hdr.setMouseTracking(True)
        hdr.setStretchLastSection(False)
        hdr.setMinimumSectionSize(25)
        hdr.setFixedHeight(26)
        hdr.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        for i, (_, _, w) in enumerate(_COLUMNS):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            hdr.resizeSection(i, w)
        self._table.doubleClicked.connect(self._on_row_double_click)
        root.addWidget(self._table, stretch=1)

        # ── Terminal footer ───────────────────────────────────────
        footer = QFrame()
        footer.setFixedHeight(20)
        footer.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-top: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 8px;"
            f"  background: transparent; border: none; }}"
        )
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(10, 0, 10, 0)
        fl.addStretch(1)
        self._footer_lbl = QLabel("")
        fl.addWidget(self._footer_lbl)
        root.addWidget(footer)
    # ── Actions ───────────────────────────────────────────────────────────
    def _on_topn_changed(self, value: int):
        self._proxy.set_top_n(value)

    def _on_run(self):
        if self._worker and self._worker.isRunning():
            self._worker.cancel()
            self._run_btn.setText("▶ SCAN")
            if self._rerank_timer:
                self._rerank_timer.stop()
            self._rerank_dirty = True
            self._rerank_live()
            return
        self._model.clear()
        self._run_btn.setText("■ STOP")
        self._progress.setText("Scanning...")
        self._count_lbl.setText("")
        self._worker = ETFScanWorker(
            _get_etf_symbols(),
            min_score=0,
        )
        self._worker.row_ready.connect(self._on_row)
        self._worker.finished_all.connect(self._on_done)
        self._worker.start()
        # Start live re-rank timer
        from PyQt6.QtCore import QTimer
        if self._rerank_timer is None:
            self._rerank_timer = QTimer(self)
            self._rerank_timer.timeout.connect(self._rerank_live)
        self._rerank_timer.start(500)
        self._rerank_dirty = False

    def _on_row(self, row):
        pos = len(self._model._data)
        self._model.beginInsertRows(QModelIndex(), pos, pos)
        self._model._data.append(row)
        self._model.endInsertRows()
        self._progress.setText(f"{row['symbol']}")
        self._rerank_dirty = True

    def _rerank_live(self):
        """Re-sort and assign ranks every 500ms during scan."""
        if not self._rerank_dirty:
            return
        self._rerank_dirty = False
        self._model.layoutAboutToBeChanged.emit()
        self._model._data.sort(
            key=lambda r: (
                _GRADE_ORD.get(r.get("grade", "—"), 7),
                -r.get("quality_rank", 0),
            )
        )
        _assign_etf_ranks(self._model._data)
        self._model.layoutChanged.emit()

    def _on_done(self, results):
        if self._rerank_timer:
            self._rerank_timer.stop()
        self._model.beginResetModel()
        self._model._data.sort(
            key=lambda r: (
                _GRADE_ORD.get(r.get("grade", "—"), 7),
                -r.get("quality_rank", 0),
            )
        )
        _assign_etf_ranks(self._model._data)
        self._model.endResetModel()
        self._run_btn.setText("▶ SCAN")
        self._progress.setText("")

        entries = sum(1 for r in self._model._data if r.get("entry"))
        ride_entries = sum(1 for r in self._model._data if r.get("ride_entry"))
        both = sum(1 for r in self._model._data if r.get("phase") == "BOTH")
        self._count_lbl.setText(
            f"{entries} entries / {len(self._model._data)} ETFs"
        )
        self._footer_lbl.setText(
            f"Momentum: {entries - ride_entries} · Ride: {ride_entries} · "
            f"Both: {both} · Total: {len(self._model._data)} scanned"
        )
    def _on_row_double_click(self, index):
        src = self._proxy.mapToSource(index)
        row = self._model._data[src.row()]
        sym = row.get("symbol", "")
        if sym:
            self.symbol_selected.emit(sym)
