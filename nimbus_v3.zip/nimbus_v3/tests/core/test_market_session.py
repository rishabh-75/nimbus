"""tests.core.test_market_session — IST market-session helpers."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from nimbus_v3.core.market_session import is_market_open, now_ist


_IST = timezone(timedelta(hours=5, minutes=30))


class TestIsMarketOpen:
    """Open window: Mon–Fri, 09:15–15:30 IST."""

    def test_weekday_during_session_open(self):
        # Thursday 23 April 2026 at 11:30 IST — mid-session.
        t = datetime(2026, 4, 23, 11, 30, tzinfo=_IST)
        assert is_market_open(now=t) is True

    def test_weekday_before_open(self):
        # Thursday 23 April 2026 at 09:00 IST — pre-open.
        t = datetime(2026, 4, 23, 9, 0, tzinfo=_IST)
        assert is_market_open(now=t) is False

    def test_weekday_at_open_boundary(self):
        # Exactly 09:15 — inclusive lower bound.
        t = datetime(2026, 4, 23, 9, 15, tzinfo=_IST)
        assert is_market_open(now=t) is True

    def test_weekday_at_close_boundary(self):
        # Exactly 15:30 — inclusive upper bound.
        t = datetime(2026, 4, 23, 15, 30, tzinfo=_IST)
        assert is_market_open(now=t) is True

    def test_weekday_after_close(self):
        # Thursday 16:00 IST — post-close.
        t = datetime(2026, 4, 23, 16, 0, tzinfo=_IST)
        assert is_market_open(now=t) is False

    def test_weekday_midnight(self):
        # Thursday 00:30 IST — deep night.
        t = datetime(2026, 4, 23, 0, 30, tzinfo=_IST)
        assert is_market_open(now=t) is False

    def test_saturday(self):
        # Saturday 25 April 2026 at 11:30 — weekends closed.
        t = datetime(2026, 4, 25, 11, 30, tzinfo=_IST)
        assert is_market_open(now=t) is False

    def test_sunday(self):
        t = datetime(2026, 4, 26, 11, 30, tzinfo=_IST)
        assert is_market_open(now=t) is False

    def test_no_override_uses_current_time(self):
        # Smoke test — should not raise, returns a bool.
        result = is_market_open()
        assert isinstance(result, bool)


class TestNowIst:

    def test_returns_tz_aware_datetime(self):
        t = now_ist()
        assert t.tzinfo is not None
        # Offset is +05:30
        assert t.utcoffset() == timedelta(hours=5, minutes=30)
