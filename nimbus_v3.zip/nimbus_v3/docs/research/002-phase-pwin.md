# RT-002 · Phase win-rate / CONT continuation model

| Field        | Value                                                       |
|--------------|-------------------------------------------------------------|
| Date         | 2026-05-10                                                  |
| Status       | `exploratory`                                               |
| Outcome      | Phase classification stays technical/price-action based; the P(win) model is an offline operator aid, not wired into the live classifier. |
| Baked into   | — (research-only; lives in `research/phase_p_win/`)         |
| Data window  | Full NSE panel, resolved INIT/RETEST/CONT fires             |

## Question

For a bar that fires CONT (an established ride), what is the historical
probability the ride continues for at least N more bars — and can a
model predict it well enough to gate or rank live signals?

## Hypothesis

CONT fires are not all equal; a feature model over band/momentum/volume
state at the CONT bar should separate continuations from imminent exits.

## Methodology

- **Target:** a CONT bar at index `t` is positive iff the ride is still
  active at `t + N_sym` or later, where `N_sym` is that symbol's
  historical median ride-hold duration (from resolved fires, computed in
  `aggregate`). Ride exit = `Close < bb_upper`. Bars whose outcome can't
  be observed (ride still open at end-of-history) are excluded.
- **Model:** logistic regression on the `extract` feature set, per CONT
  fire across the panel.
- **Split:** walk-forward — chronologically first 70% of each symbol's
  CONT bars train, last 30% test. Look-ahead-safe at the corpus level.
- Also computes per-symbol per-phase historical p_win for INIT/RETEST.

## Key code

```python
# cont_model.py (essence) — label construction
# positive iff ride still active N_sym bars later
exit_idx = first_index_where(close < bb_upper, after=t)
label = 1 if (exit_idx is None or exit_idx >= t + N_sym) else 0
# rows with ride still open at end-of-history are dropped (unobservable)
```

## Results

Treated as an **offline operator aid** rather than a live gate. The
continuation probability and per-phase win rates inform manual review;
they were deliberately *not* folded into `RideEngine` scoring, to keep
the live classifier purely technical and deterministic (and the
`schema_hash` stable).

## Conclusion & decision

Phase classification remains technical/price-action based. The
capital-cycle signals once considered for phase (industry share-count
growth, aggregate RoIC, capex-to-sales) require new data pipelines and
validation and are **deferred** — not in the live phase logic.

## Reproduce

The `research/phase_p_win/` package (`extract` → `aggregate` →
`cont_model`) still exists and is runnable offline against the shared
price cache. It is not imported by the live app.
