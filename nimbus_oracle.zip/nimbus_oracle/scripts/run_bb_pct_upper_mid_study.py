#!/usr/bin/env python3
"""
scripts/run_bb_pct_upper_mid_study.py — Follow-up on the upper-mid %B finding.

  ┌──────────────────────────────────────────────────────────────────────────┐
  │ STATUS: CLOSED — REJECTED                                                │
  │                                                                          │
  │ The upper-mid bucket (%B 0.6-0.8) initially showed an 80% win rate      │
  │ across 244 trades — striking. Investigation revealed:                   │
  │                                                                          │
  │   1. All 244 trades were in fold 3 of the walk-forward backtest.        │
  │   2. Fold 3 itself is only mildly better than other folds overall      │
  │      (+1.1pp win rate, +0.61% avg PnL).                                 │
  │   3. Fold 3 traded 6.8pp more SECONDARY (Ride) signals than the avg.   │
  │   4. The "upper-mid" cluster is a side effect of fold 3's strategy mix │
  │      during a Ride-favorable period — NOT a structural %B signal.      │
  │                                                                          │
  │ Settled by scripts/run_fold_comparison.py. No grade changes.            │
  │                                                                          │
  │ Preserved for reference. Not part of routine research rotation.         │
  └──────────────────────────────────────────────────────────────────────────┘

CONTEXT:
  The BB %B study (run_bb_pct_study.py) rejected %B as a grade factor (regression
  showed no incremental signal beyond WR + pct_from_sma). However, the bucket
  analysis surfaced an unexpected pattern:

      bucket            N      win%    avg_pnl
      below band      126    68.3%    +1.82%
      lower (0-0.2)   470    68.9%    +1.52%
      lower-mid       1740   72.1%    +1.21%
      mid             1931   71.9%    +1.11%
      upper-mid       244    80.3%    +2.65%   <-- 8.4pp edge, +1.5% extra PnL

  This is the OPPOSITE of the snap hypothesis. MR trades entered when the
  stock is still in the upper half of the bands (pullback in strength)
  outperform trades entered when stock is at or below the lower band
  (falling knife). We need to confirm this is structural, not noise.

DESIGN:
  Reuse the enriched bb_pct_trades CSV from the previous study. Slice the
  upper-mid bucket (0.6 <= bb_pct < 0.8) and the rest of the sample by:
    1. VIX regime — does it hold across LOW/NORMAL/ELEVATED/PANIC?
    2. Sector type — CYCLICAL vs DEFENSIVE
    3. Sector RS regime — LEADING / INLINE / LAGGING
    4. Walk-forward fold — is the edge consistent across out-of-sample folds?
    5. WR(30) and pct_from_sma distributions — where do upper-mid trades
       sit on the existing grade factors? (proxy for "are these already A+")

DECISION:
  IF upper-mid edge holds across most slices and most folds:
    → real structural finding. Recommend adding %B context to the grade
      OR a dashboard label distinguishing "pullback in strength" from
      "deep weakness reversion".

  IF upper-mid edge breaks down in slices or is fold-specific:
    → sample artifact. Close investigation, no changes.

Usage:
    python3 scripts/run_bb_pct_upper_mid_study.py
    python3 scripts/run_bb_pct_upper_mid_study.py --csv path/to/trades.csv
"""
import argparse
import glob
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("upper_mid_study")


# Bucket definition
UPPER_MID_LO = 0.6
UPPER_MID_HI = 0.8

# Significance thresholds
MIN_BUCKET_N = 20  # don't report on tiny slices
MIN_EDGE_PP = 3.0  # minimum win-rate edge to consider "real"


# ══════════════════════════════════════════════════════════════════════════════
# DATA LOADING — auto-enrich if CSV not found
# ══════════════════════════════════════════════════════════════════════════════

def find_latest_csv() -> str | None:
    """Find the most recent bb_pct_trades_*.csv file, or None."""
    candidates = sorted(glob.glob("data/bb_pct_trades_*.csv"))
    return candidates[-1] if candidates else None


def _merge_metadata(wf_df: pd.DataFrame) -> pd.DataFrame:
    """
    wf_oos_trades.csv has fold info but lacks vix_regime / sector_type metadata.
    sector_regime_trades.csv has the metadata but lacks fold info.
    Inner-join on (symbol, entry_date) to get one DataFrame with everything.
    Reports clearly on the merge so the user can see what was lost.
    """
    metadata_path = "data/backtest_results/sector_regime_trades.csv"
    upload_path = "/mnt/user-data/uploads/sector_regime_trades.csv"
    meta_path = metadata_path if os.path.exists(metadata_path) else (
        upload_path if os.path.exists(upload_path) else None
    )

    if meta_path is None:
        logger.warning("No sector_regime_trades.csv found — slices will be limited")
        return wf_df

    logger.info(f"Merging metadata from {meta_path}")
    meta_df = pd.read_csv(meta_path)
    if "entry_date" in meta_df.columns:
        meta_df["entry_date"] = pd.to_datetime(meta_df["entry_date"])

    # Columns we want from metadata file (don't clobber wf_df's existing cols)
    wanted = ["symbol", "entry_date", "vix_regime", "vix_at_entry",
              "sector_type", "sector_rs_regime", "sector_regime",
              "sector_vol_regime", "rs_bucket"]
    meta_cols = [c for c in wanted if c in meta_df.columns]
    meta_slim = meta_df[meta_cols].drop_duplicates(subset=["symbol", "entry_date"])

    # Drop overlapping cols from wf_df so the merge is clean
    wf_clean = wf_df.drop(
        columns=[c for c in meta_cols if c in wf_df.columns and c not in ("symbol", "entry_date")],
        errors="ignore",
    )

    merged = wf_clean.merge(meta_slim, on=["symbol", "entry_date"], how="left")
    matched = merged["vix_regime"].notna().sum() if "vix_regime" in merged.columns else 0
    logger.info(f"Merge: {matched}/{len(merged)} trades have metadata")
    return merged


def load_or_enrich_trades(explicit_csv: str | None) -> pd.DataFrame:
    """
    Try to load enriched trades from disk. If no CSV exists (e.g. fresh
    install after a zip replace), run the full enrichment from scratch.
    Either way, this script can run standalone with no prerequisites.
    """
    csv_path = explicit_csv or find_latest_csv()

    if csv_path and os.path.exists(csv_path):
        logger.info(f"Loading existing enriched trades: {csv_path}")
        df = pd.read_csv(csv_path)
        if "entry_date" in df.columns:
            df["entry_date"] = pd.to_datetime(df["entry_date"])
        df = _merge_metadata(df)
        return df

    # No CSV — enrich from scratch using the same logic as run_bb_pct_study
    logger.info("No enriched CSV found — running full enrichment from OOS trades")
    logger.info("(this fetches per-symbol price history; may take a few minutes)")

    from scripts.run_bbw_pctl_study import load_oos_trades
    from scripts.run_bb_pct_study import enrich_trades

    trades = load_oos_trades()
    logger.info(f"Loaded {len(trades)} OOS trades")

    enriched = enrich_trades(trades)
    if enriched.empty:
        raise RuntimeError("Enrichment produced no rows. Check data/wf_oos_trades.csv exists.")

    # Save for future runs so we don't re-enrich every time
    out_path = f"data/bb_pct_trades_{pd.Timestamp.now():%Y%m%d_%H%M}.csv"
    enriched.to_csv(out_path, index=False)
    logger.info(f"Cached enriched trades to {out_path}")

    if "entry_date" in enriched.columns:
        enriched["entry_date"] = pd.to_datetime(enriched["entry_date"])
    enriched = _merge_metadata(enriched)
    return enriched


def load_enriched_trades(df: pd.DataFrame) -> pd.DataFrame:
    """Mark the upper-mid bucket on an already-loaded DataFrame."""
    df = df.copy()
    df["is_upper_mid"] = (df["bb_pct"] >= UPPER_MID_LO) & (df["bb_pct"] < UPPER_MID_HI)
    return df


# ══════════════════════════════════════════════════════════════════════════════
# SLICE ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def stats(s: pd.DataFrame) -> tuple:
    """Return (n, win_pct, avg_pnl, sharpe-ish) tuple from a trades subset."""
    if len(s) == 0:
        return (0, 0.0, 0.0, 0.0)
    win = s["win"].mean() * 100
    avg = s["pnl_pct"].mean()
    std = s["pnl_pct"].std()
    sh = (avg / std * np.sqrt(252 / 10)) if std > 0 else 0
    return (len(s), win, avg, sh)


def compare_in_slice(df: pd.DataFrame, slice_label: str) -> dict | None:
    """Compare upper-mid vs rest within a single slice."""
    upper = df[df["is_upper_mid"]]
    rest = df[~df["is_upper_mid"]]

    if len(upper) < MIN_BUCKET_N or len(rest) < MIN_BUCKET_N:
        return None

    u = stats(upper)
    r = stats(rest)
    edge = u[1] - r[1]
    pnl_edge = u[2] - r[2]

    return {
        "slice": slice_label,
        "u_n": u[0], "u_win": u[1], "u_pnl": u[2], "u_sh": u[3],
        "r_n": r[0], "r_win": r[1], "r_pnl": r[2], "r_sh": r[3],
        "edge_pp": edge,
        "pnl_edge": pnl_edge,
        "holds": edge >= MIN_EDGE_PP,
    }


def slice_by_column(df: pd.DataFrame, col: str, label: str) -> list:
    """Slice df by a categorical column and run comparison in each slice."""
    if col not in df.columns:
        return []
    results = []
    for val in sorted(df[col].dropna().unique()):
        sub = df[df[col] == val]
        cmp = compare_in_slice(sub, f"{label}={val}")
        if cmp:
            results.append(cmp)
    return results


def factor_distribution(df: pd.DataFrame) -> dict:
    """
    Where do upper-mid trades sit on the EXISTING factors?
    If they have less extreme WR/SMA than other buckets, the existing grade
    likely UNDERWEIGHTS them — meaning %B context would unlock real edge.
    """
    upper = df[df["is_upper_mid"]]
    rest = df[~df["is_upper_mid"]]

    metrics = {}
    for col in ["wr_30", "pct_from_sma"]:
        if col not in df.columns:
            continue
        u_vals = upper[col].dropna()
        r_vals = rest[col].dropna()
        if len(u_vals) < 20 or len(r_vals) < 20:
            continue
        metrics[col] = {
            "upper_mean": float(u_vals.mean()),
            "upper_median": float(u_vals.median()),
            "rest_mean": float(r_vals.mean()),
            "rest_median": float(r_vals.median()),
            "diff": float(u_vals.mean() - r_vals.mean()),
        }
    return metrics


# ══════════════════════════════════════════════════════════════════════════════
# REPORT
# ══════════════════════════════════════════════════════════════════════════════

def print_section(title: str):
    print("\n" + "=" * 78)
    print(f"  {title}")
    print("=" * 78)


def print_slice_results(results: list, slice_name: str):
    if not results:
        print(f"\n  {slice_name}: insufficient data in slices")
        return

    print(f"\n  {slice_name}")
    print(f"  {'Slice':<28s}  {'Upper-mid':>22s}  {'Rest':>22s}  {'Edge':>8s}")
    print(f"  {'':28s}  {'N    Win%   Avg':>22s}  {'N    Win%   Avg':>22s}  {'win%':>8s}")
    holds_count = 0
    total_count = len(results)
    for r in results:
        flag = " <--" if r["holds"] else ""
        if r["holds"]:
            holds_count += 1
        print(
            f"  {r['slice']:<28s}  "
            f"{r['u_n']:4d}  {r['u_win']:5.1f}% {r['u_pnl']:+6.2f}%  "
            f"{r['r_n']:4d}  {r['r_win']:5.1f}% {r['r_pnl']:+6.2f}%  "
            f"{r['edge_pp']:+6.1f}{flag}"
        )
    print(f"\n  Edge holds in {holds_count}/{total_count} slices "
          f"(threshold: ≥{MIN_EDGE_PP}pp)")


def print_factor_dist(metrics: dict):
    if not metrics:
        print("\n  Factor distribution: missing wr_30 / pct_from_sma columns")
        return
    print(f"\n  Where do upper-mid trades sit on existing factors?")
    print(f"  (Lower magnitude = LESS extreme = currently UNDERWEIGHTED in grade)")
    print(f"  {'Factor':<20s}  {'Upper-mid mean':>16s}  {'Rest mean':>16s}  {'Diff':>10s}")
    for factor, m in metrics.items():
        print(
            f"  {factor:<20s}  "
            f"{m['upper_mean']:+15.2f}   "
            f"{m['rest_mean']:+15.2f}   "
            f"{m['diff']:+9.2f}"
        )

    # Interpretation
    if "wr_30" in metrics and "pct_from_sma" in metrics:
        wr_diff = metrics["wr_30"]["diff"]
        sma_diff = metrics["pct_from_sma"]["diff"]
        print(f"\n  Interpretation:")
        if wr_diff > 5 and sma_diff > 1:
            print(f"  Upper-mid trades have HIGHER WR (less oversold) and HIGHER pct_from_sma")
            print(f"  (less stretched). This means the current grade UNDERWEIGHTS them.")
            print(f"  → If their edge is real, %B context would unlock hidden alpha.")
        else:
            print(f"  Upper-mid trades sit similarly to rest on WR/SMA factors.")
            print(f"  → The 80% win rate may be coming from %B itself, not under-weighting.")


def fold_concentration(df: pd.DataFrame) -> dict | None:
    """
    Check whether upper-mid trades are concentrated in a single fold.
    If >60% live in one fold, the headline edge is fold-specific noise,
    not a structural pattern. This is a hard veto on the verdict.
    """
    if "fold" not in df.columns:
        return None
    upper = df[df["is_upper_mid"]]
    if len(upper) < 30:
        return None
    fold_counts = upper["fold"].value_counts(dropna=True)
    if fold_counts.empty:
        return None
    top_fold = fold_counts.index[0]
    top_n = int(fold_counts.iloc[0])
    total = int(fold_counts.sum())
    pct = top_n / total
    return {
        "top_fold": top_fold,
        "top_n": top_n,
        "total": total,
        "pct": pct,
        "is_concentrated": pct > 0.60,
        "fold_counts": fold_counts.to_dict(),
    }


def overall_verdict(slice_results: dict, factor_dist: dict, fold_conc: dict | None):
    """Final go/no-go based on slice consistency AND fold concentration."""
    print_section("VERDICT")

    # ── HARD VETO: fold concentration ───────────────────────────────────────
    if fold_conc and fold_conc["is_concentrated"]:
        print(
            f"\n  HARD VETO: {fold_conc['top_n']}/{fold_conc['total']} upper-mid trades "
            f"({fold_conc['pct']*100:.0f}%) are in a single fold (fold={fold_conc['top_fold']})."
        )
        print(f"  Fold distribution: {fold_conc['fold_counts']}")
        print()
        print("  This is the textbook sample-artifact failure mode.")
        print("  The 80% win rate is coming from one walk-forward period,")
        print("  not from a structural pattern that holds across out-of-sample folds.")
        print()
        print("  VERDICT: REJECTED — sample artifact, not a real edge.")
        print("  RECOMMENDED ACTION: Close investigation. No grade changes.")
        return

    # ── Count slices that passed (require ≥3 actual non-trivial slices) ─────
    n_slices_with_data = 0
    holds_count = 0
    for slice_name, results in slice_results.items():
        # Must have ≥2 distinct slice values to count as a real slice test
        if len(results) >= 2:
            n_slices_with_data += 1
            if all(r["holds"] for r in results):
                holds_count += 1

    if n_slices_with_data < 2:
        print(f"\n  INCONCLUSIVE — only {n_slices_with_data} slice dimension(s) had ≥2 distinct values")
        print(f"  to test. Cannot rule out sample artifact.")
        print()
        print(f"  Likely cause: source CSV is missing metadata columns")
        print(f"  (vix_regime / sector_type / sector_rs_regime).")
        print(f"  RECOMMENDED ACTION: Don't act on this finding without richer slicing.")
        return

    pct = holds_count / n_slices_with_data * 100 if n_slices_with_data else 0
    print(f"\n  {n_slices_with_data} slice dimension(s) had usable data.")
    print(f"  Edge held in all sub-slices for {holds_count}/{n_slices_with_data} ({pct:.0f}%)")

    if pct >= 80 and n_slices_with_data >= 3:
        print("\n  STRUCTURAL FINDING — upper-mid edge survives slicing across multiple dimensions")
        print("  RECOMMENDED ACTION:")
        print("    1. Add a dashboard context label distinguishing %B regimes")
        print("       'pullback in strength' (0.6-0.8) vs 'mid range' vs 'deep weakness'")
        print("    2. Consider a small grade boost (+2 pts) for upper-mid MR entries")
        print("       — small enough to not destabilize the grade formula")
        print("       — only when WR(30)<-50 still holds (not pure trend chasing)")
    elif pct >= 50:
        print("\n  MIXED — edge holds in some dimensions but not others")
        print("  RECOMMENDED ACTION:")
        print("    Look at WHICH slices it holds in. If it's a clean cut")
        print("    (e.g. only NORMAL VIX × CYCLICAL), that's the actionable subset.")
    else:
        print("\n  FRAGILE — upper-mid edge does not survive slicing")
        print("  RECOMMENDED ACTION:")
        print("    Close investigation. The N=244 result was likely sample noise.")
        print("    No changes to the grade formula.")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", type=str, default=None,
                    help="Path to enriched trades CSV (auto-discovered or built if missing)")
    args = ap.parse_args()

    raw = load_or_enrich_trades(args.csv)
    df = load_enriched_trades(raw)
    logger.info(f"Loaded {len(df)} trades")

    n_upper = df["is_upper_mid"].sum()
    n_rest = len(df) - n_upper
    logger.info(f"Upper-mid (%B 0.6-0.8): {n_upper}  |  Rest: {n_rest}")

    if n_upper < MIN_BUCKET_N:
        logger.error("Upper-mid bucket too small for analysis")
        sys.exit(1)

    # ── Headline comparison ─────────────────────────────────────────────────
    print_section("HEADLINE — UPPER-MID vs REST")
    headline = compare_in_slice(df, "OVERALL")
    if headline:
        print(f"\n  Upper-mid: N={headline['u_n']:4d}  Win={headline['u_win']:5.1f}%  "
              f"Avg PnL={headline['u_pnl']:+6.2f}%  Sharpe-ish={headline['u_sh']:+.2f}")
        print(f"  Rest:      N={headline['r_n']:4d}  Win={headline['r_win']:5.1f}%  "
              f"Avg PnL={headline['r_pnl']:+6.2f}%  Sharpe-ish={headline['r_sh']:+.2f}")
        print(f"  Edge:      {headline['edge_pp']:+.1f}pp win rate, {headline['pnl_edge']:+.2f}% PnL")

    # ── Fold concentration check (HARD VETO) ────────────────────────────────
    print_section("FOLD CONCENTRATION CHECK (sample artifact detection)")
    fold_conc = fold_concentration(df)
    if fold_conc is None:
        print("\n  No fold column in source data — cannot check concentration.")
    else:
        print(f"\n  Upper-mid trades by fold:")
        for fold, n in sorted(fold_conc["fold_counts"].items()):
            bar = "█" * int(n / max(fold_conc["fold_counts"].values()) * 30)
            print(f"    fold={fold}: {n:4d}  {bar}")
        print(f"\n  Top fold ({fold_conc['top_fold']}): "
              f"{fold_conc['top_n']}/{fold_conc['total']} ({fold_conc['pct']*100:.0f}%)")
        if fold_conc["is_concentrated"]:
            print(f"  ⚠ CONCENTRATED: >60% of upper-mid trades in one fold")
        else:
            print(f"  ✓ DIVERSIFIED: spread across folds")

    # ── Slices ──────────────────────────────────────────────────────────────
    print_section("SLICE 1 — VIX REGIME")
    if "vix_regime" in df.columns:
        n_unique = df["vix_regime"].nunique(dropna=True)
        n_unknown = (df["vix_regime"] == "UNKNOWN").sum() if "vix_regime" in df.columns else 0
        print(f"\n  vix_regime: {n_unique} unique values, {n_unknown} are 'UNKNOWN'")
    vix_results = slice_by_column(df, "vix_regime", "VIX")
    print_slice_results(vix_results, "By VIX regime")

    print_section("SLICE 2 — SECTOR TYPE")
    if "sector_type" in df.columns:
        print(f"\n  sector_type: {df['sector_type'].nunique(dropna=True)} unique values, "
              f"{df['sector_type'].notna().sum()}/{len(df)} populated")
    sector_results = slice_by_column(df, "sector_type", "Sector")
    print_slice_results(sector_results, "By sector type")

    print_section("SLICE 3 — SECTOR RS REGIME")
    if "sector_rs_regime" in df.columns:
        print(f"\n  sector_rs_regime: {df['sector_rs_regime'].nunique(dropna=True)} unique values, "
              f"{df['sector_rs_regime'].notna().sum()}/{len(df)} populated")
    rs_results = slice_by_column(df, "sector_rs_regime", "RS")
    print_slice_results(rs_results, "By sector RS regime")

    print_section("SLICE 4 — WALK-FORWARD FOLD")
    fold_results = slice_by_column(df, "fold", "Fold")
    print_slice_results(fold_results, "By WF fold (out-of-sample stability)")

    print_section("SLICE 5 — WHERE DO UPPER-MID TRADES SIT ON EXISTING FACTORS?")
    factor_dist = factor_distribution(df)
    print_factor_dist(factor_dist)

    # ── Verdict ─────────────────────────────────────────────────────────────
    all_slices = {
        "vix": vix_results,
        "sector": sector_results,
        "rs": rs_results,
        "fold": fold_results,
    }
    overall_verdict(all_slices, factor_dist, fold_conc)


if __name__ == "__main__":
    main()
