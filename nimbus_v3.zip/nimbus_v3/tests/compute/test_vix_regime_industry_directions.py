"""Tests for nimbus_v3.compute.vix_regime_industry_directions."""
from __future__ import annotations

import pytest

from nimbus_v3.compute.vix_pace import (
    REGIME_FALLING, REGIME_RISING, REGIME_STABLE, REGIME_UNKNOWN,
)
from nimbus_v3.compute.vix_regime_industry_directions import (
    DIRECTION_DOWN, DIRECTION_NEUTRAL, DIRECTION_UP,
    STABLE_INDUSTRIES, direction_for, is_stable_industry,
)


# The research-validated list, pinned here so any change to the
# config file that adds/removes/renames an industry is caught by the
# test suite. If the walk-forward validation is re-run and this list
# changes, update both the config file and this test in the same
# commit.
_EXPECTED_STABLE_INDUSTRIES: tuple[str, ...] = (
    "Aerospace & Defense",
    "Auto Components",
    "Chemicals & Petrochemicals",
    "Electrical Equipment",
    "Fertilizers & Agrochemicals",
    "IT - Services",
    "Leisure Services",
    "Power",
    "Realty",
    "Telecom - Services",
    "Transport Services",
)


# ══════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════

class TestConstants:

    def test_direction_labels_are_distinct_strings(self):
        """UI rendering compares by string equality. Pin this."""
        assert DIRECTION_UP == "UP"
        assert DIRECTION_DOWN == "DOWN"
        assert DIRECTION_NEUTRAL == "NEUTRAL"
        # No accidental aliasing
        assert len({DIRECTION_UP, DIRECTION_DOWN, DIRECTION_NEUTRAL}) == 3


# ══════════════════════════════════════════════════════════════════════
# STABLE_INDUSTRIES
# ══════════════════════════════════════════════════════════════════════

class TestStableIndustries:

    def test_count_matches_research(self):
        """The 20d walk-forward validation found 11 stable
        industries. This count is load-bearing for the UI — any
        change to it requires a re-validation."""
        assert len(STABLE_INDUSTRIES) == 11

    def test_exact_membership(self):
        """The stable-11 list must match exactly what was validated
        by the research. Changes require a re-run of
        scripts/run_vix_component_industry_validation.py."""
        assert set(STABLE_INDUSTRIES) == set(_EXPECTED_STABLE_INDUSTRIES)

    def test_alphabetical_order(self):
        """STABLE_INDUSTRIES is exposed in canonical alphabetical
        order so UI filter lists render deterministically."""
        assert list(STABLE_INDUSTRIES) == sorted(STABLE_INDUSTRIES)


# ══════════════════════════════════════════════════════════════════════
# direction_for
# ══════════════════════════════════════════════════════════════════════

class TestDirectionFor:

    def test_all_stable_industries_have_up_in_rising(self):
        """The research found that all 11 stable industries are UP
        in RISING regime. This coherent pattern is load-bearing for
        the economic interpretation."""
        for industry in _EXPECTED_STABLE_INDUSTRIES:
            assert direction_for(industry, REGIME_RISING) == DIRECTION_UP, (
                f"{industry} should be UP in RISING"
            )

    def test_all_stable_industries_have_down_in_stable(self):
        """And DOWN in STABLE — the mirror of the UP-in-RISING
        pattern. Cyclicals lead when fear inflects up, lag when
        markets are quiet."""
        for industry in _EXPECTED_STABLE_INDUSTRIES:
            assert direction_for(industry, REGIME_STABLE) == DIRECTION_DOWN, (
                f"{industry} should be DOWN in STABLE"
            )

    def test_no_falling_direction_for_stable_industries(self):
        """Research didn't find stable FALLING-regime directions at
        20d (FALLING cells appeared in only 2 folds, below the
        stability threshold). Any FALLING lookup returns NEUTRAL."""
        for industry in _EXPECTED_STABLE_INDUSTRIES:
            assert direction_for(industry, REGIME_FALLING) == DIRECTION_NEUTRAL, (
                f"{industry} should be NEUTRAL in FALLING (not validated)"
            )

    def test_non_stable_industry_returns_neutral(self):
        """An industry that's not in the stable-11 list always
        returns NEUTRAL regardless of regime."""
        non_stable = "Banks"   # was in 5d stable list but NOT 20d
        assert direction_for(non_stable, REGIME_RISING) == DIRECTION_NEUTRAL
        assert direction_for(non_stable, REGIME_STABLE) == DIRECTION_NEUTRAL
        assert direction_for(non_stable, REGIME_FALLING) == DIRECTION_NEUTRAL

    def test_unknown_regime_returns_neutral(self):
        """During VIX baseline warmup the regime is UNKNOWN. UI
        should not render a direction badge — the lookup returns
        NEUTRAL to enforce that."""
        assert direction_for("Realty", REGIME_UNKNOWN) == DIRECTION_NEUTRAL

    def test_unknown_industry_returns_neutral(self):
        """Non-matching industry string (typo, new category not yet
        in research) returns NEUTRAL — fails safe."""
        assert direction_for("Bitcoin Mining", REGIME_RISING) == DIRECTION_NEUTRAL

    def test_case_sensitive_matching(self):
        """Industry names must match exactly — case-sensitive.
        'realty' (lowercase) is not 'Realty'. Enforces that the UI
        passes canonical industry names from the DB."""
        assert direction_for("realty", REGIME_RISING) == DIRECTION_NEUTRAL
        assert direction_for("Realty", REGIME_RISING) == DIRECTION_UP


# ══════════════════════════════════════════════════════════════════════
# is_stable_industry
# ══════════════════════════════════════════════════════════════════════

class TestIsStableIndustry:

    def test_stable_industry_returns_true(self):
        for ind in _EXPECTED_STABLE_INDUSTRIES:
            assert is_stable_industry(ind)

    def test_non_stable_industry_returns_false(self):
        # Industries that exist in the DB but aren't in the stable-11
        for ind in ("Banks", "Automobiles", "Retailing", "Finance"):
            assert not is_stable_industry(ind)

    def test_unknown_industry_returns_false(self):
        assert not is_stable_industry("Nonexistent Industry")
