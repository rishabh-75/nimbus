"""scripts/build_industry_db.py — Build NIFTY 500 sector/industry database.

Two-step process:
1. Fetch NIFTY 500 constituents from /api/equity-stockIndices to get
   symbols + company names (from meta).
2. For each symbol, hit the individual quote endpoint to get the full
   four-level classification from secInfo:
     - macro        (e.g. "Commodities")
     - sector       (e.g. "Metals & Mining")
     - industryInfo (e.g. "Non - Ferrous Metals")
     - basicIndustry(e.g. "Zinc")

Output: data/nifty500_industry_db.json

Usage:
    python scripts/build_industry_db.py
    python scripts/build_industry_db.py --index "NIFTY 200"
    python scripts/build_industry_db.py --output data/custom_db.json
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent))

from nimbus_v3.data.nse_client import NSEClient


# ══════════════════════════════════════════════════════════════════════════════
# Step 1: Fetch constituent list with company names
# ══════════════════════════════════════════════════════════════════════════════

_INDEX_URL = "https://www.nseindia.com/api/equity-stockIndices"
_INDEX_REFERER = "https://www.nseindia.com/market-data/live-equity-market"


def fetch_constituents(
    nse: NSEClient, index_name: str,
) -> list[dict[str, str]]:
    """Fetch [(symbol, companyName), ...] from the index endpoint.

    Returns list of dicts with keys: symbol, companyName.
    """
    print(f"Fetching {index_name} constituents…")
    payload = nse.fetch(
        _INDEX_URL,
        referer=_INDEX_REFERER,
        params={"index": index_name},
    )
    if not payload:
        print(f"  ERROR: empty payload for {index_name}")
        return []

    data = payload.get("data", [])
    results: list[dict[str, str]] = []
    for row in data:
        if not isinstance(row, dict):
            continue
        meta = row.get("meta") or {}
        symbol = (meta.get("symbol") or row.get("symbol") or "").strip()
        company = (meta.get("companyName") or "").strip()
        if not symbol:
            continue
        # Skip the synthetic index row (first row, no company name).
        if not company and symbol.upper().startswith("NIFTY"):
            continue
        results.append({"symbol": symbol.upper(), "companyName": company})

    print(f"  → {len(results)} constituents")
    return results


# ══════════════════════════════════════════════════════════════════════════════
# Step 2: Fetch per-symbol classification from quote endpoint
# ══════════════════════════════════════════════════════════════════════════════

_QUOTE_URL = (
    "https://www.nseindia.com/api/NextApi/apiClient/GetQuoteApi"
    "?functionName=getSymbolData&marketType=N&series=EQ&symbol={symbol}"
)


def _quote_referer(symbol: str, company_name: str) -> str:
    """Build the referer URL for the symbol quote endpoint.

    NSE expects a referer like:
      https://www.nseindia.com/get-quote/equity/HINDZINC/Hindustan-Zinc-Limited
    """
    # Clean company name for URL: replace spaces with hyphens, strip special chars.
    slug = company_name.replace(" ", "-").replace(".", "").replace(",", "")
    slug = slug.replace("&", "-").replace("(", "").replace(")", "")
    slug = "-".join(part for part in slug.split("-") if part)  # collapse double hyphens
    return f"https://www.nseindia.com/get-quote/equity/{symbol}/{slug}"


def fetch_symbol_classification(
    nse: NSEClient,
    symbol: str,
    company_name: str,
) -> dict[str, str] | None:
    """Fetch the four-level classification for one symbol.

    Returns dict with keys: macro, sector, industryInfo, basicIndustry.
    None on failure.
    """
    url = _QUOTE_URL.format(symbol=symbol)
    referer = _quote_referer(symbol, company_name)

    payload = nse.fetch(url, referer=referer)
    if not payload:
        return None

    # Navigate: equityResponse[0].secInfo
    equity_resp = payload.get("equityResponse")
    if not isinstance(equity_resp, list) or not equity_resp:
        return None

    sec_info = equity_resp[0].get("secInfo") or {}

    return {
        "macro": (sec_info.get("macro") or "").strip(),
        "sector": (sec_info.get("sector") or "").strip(),
        "industryInfo": (sec_info.get("industryInfo") or "").strip(),
        "basicIndustry": (sec_info.get("basicIndustry") or "").strip(),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Main: compose steps, write output
# ══════════════════════════════════════════════════════════════════════════════

def build_db(
    *,
    index_name: str = "NIFTY 500",
    output_path: Path = Path("data/nifty500_industry_db.json"),
    delay: float = 0.5,
) -> dict[str, dict]:
    """Build the full database. Returns the mapping dict."""
    nse = NSEClient()

    # Step 1: get symbol list.
    constituents = fetch_constituents(nse, index_name)
    if not constituents:
        print("No constituents fetched. Aborting.")
        return {}

    # Step 2: hit each symbol's quote endpoint.
    db: dict[str, dict] = {}
    total = len(constituents)
    failed: list[str] = []

    print(f"\nFetching per-symbol classification for {total} symbols…")
    print(f"  (delay {delay}s between calls to avoid rate-limiting)\n")

    for i, entry in enumerate(constituents, 1):
        sym = entry["symbol"]
        company = entry["companyName"]

        classification = fetch_symbol_classification(nse, sym, company)

        if classification is None:
            failed.append(sym)
            print(f"  [{i:3d}/{total}] {sym:15s}  FAILED")
        else:
            db[sym] = {
                "symbol": sym,
                "companyName": company,
                **classification,
            }
            sector = classification["sector"] or "—"
            industry = classification["industryInfo"] or "—"
            print(
                f"  [{i:3d}/{total}] {sym:15s}  "
                f"{sector:30s}  {industry}"
            )

        # Rate limit — NSE will block at ~3 req/s sustained.
        if i < total:
            time.sleep(delay)

    # Summary.
    print(f"\n{'═' * 60}")
    print(f"  Fetched: {len(db)} / {total}")
    if failed:
        print(f"  Failed:  {len(failed)} — {', '.join(failed[:10])}")
        if len(failed) > 10:
            print(f"           … and {len(failed) - 10} more")
    print(f"{'═' * 60}")

    # Write output.
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(db, indent=2, ensure_ascii=False))
    print(f"\n  Saved to {output_path}")
    print(f"  {len(db)} symbols × 4 classification levels")

    # Quick distribution summary.
    sectors: dict[str, int] = {}
    for entry in db.values():
        s = entry.get("sector") or "Unknown"
        sectors[s] = sectors.get(s, 0) + 1
    print(f"\n  Sector distribution ({len(sectors)} unique sectors):")
    for s, n in sorted(sectors.items(), key=lambda x: -x[1])[:15]:
        print(f"    {s:40s}  {n:3d} stocks")
    if len(sectors) > 15:
        print(f"    … and {len(sectors) - 15} more sectors")

    return db


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build NIFTY 500 sector/industry database from NSE",
    )
    parser.add_argument(
        "--index", type=str, default="NIFTY 500",
        help="Index to fetch (default: NIFTY 500).",
    )
    parser.add_argument(
        "--output", type=str,
        default="data/nifty500_industry_db.json",
        help="Output JSON path.",
    )
    parser.add_argument(
        "--delay", type=float, default=0.5,
        help="Delay between per-symbol requests in seconds (default 0.5).",
    )
    args = parser.parse_args()

    db = build_db(
        index_name=args.index,
        output_path=Path(args.output),
        delay=args.delay,
    )
    return 0 if db else 1


if __name__ == "__main__":
    sys.exit(main())
