"""Tests for nimbus_v3.compute.market_breadth."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.market_breadth import (
    breadth_snapshot,
    compute_breadth,
)


def _series(values: list[float], start: str = "2024-01-01") -> pd.DataFrame:
    idx = pd.bdate_range(start, periods=len(values))
    c = pd.Series(values, index=idx, dtype=float)
    return pd.DataFrame({"Open": c, "High": c * 1.01, "Low": c * 0.99,
                         "Close": c, "Volume": 1_000})


def test_empty_panel_gives_empty_frame_and_nan_snapshot():
    assert compute_breadth({}).empty
    snap = breadth_snapshot(compute_breadth({}))
    assert snap.universe == 0
    assert snap.adv == 0


def test_advancers_decliners_count():
    # A rising, B falling on the last bar.
    panel = {
        "A": _series([10, 11, 12, 13]),
        "B": _series([10, 9, 8, 7]),
    }
    b = compute_breadth(panel)
    assert b["adv"].iloc[-1] == 1
    assert b["dec"].iloc[-1] == 1


def test_ad_line_is_cumulative():
    panel = {"A": _series([10, 11, 12, 13]), "B": _series([10, 11, 12, 13])}
    b = compute_breadth(panel)
    # both advance every day after the first → ad_line climbs by 2/day
    assert b["ad_line"].iloc[-1] == b["ad_line"].iloc[-2] + 2


def test_pct_above_sma50_full_when_all_trending_up():
    # 60 ascending bars → every symbol sits above its own SMA50 at the end.
    up = list(range(100, 160))
    panel = {"A": _series(up), "B": _series(up)}
    b = compute_breadth(panel)
    assert b["pct_above_sma50"].iloc[-1] == 100.0


def test_snapshot_reads_latest_and_delta():
    up = list(range(100, 160))
    panel = {"A": _series(up), "B": _series(up)}
    b = compute_breadth(panel)
    snap = breadth_snapshot(b)
    assert snap.asof == b.index[-1]
    assert 0.0 <= snap.pct_above_sma50 <= 100.0
    # delta defined once there are >= 2 rows
    assert snap.breadth_delta == snap.breadth_delta    # not NaN


def test_new_high_counts_on_breakout():
    # B makes a fresh high on the final bar; A is flat.
    panel = {
        "A": _series([50] * 30),
        "B": _series([10] * 29 + [99]),
    }
    b = compute_breadth(panel)
    assert b["new_highs"].iloc[-1] >= 1


def test_pct_members_above_sma50_scoping():
    """Per-industry breadth: a clean-uptrend member set reads ~1.0, a
    downtrend set ~0.0, and an empty set is NaN. Mirrors the universe
    'Close > own SMA50' rule scoped to one industry's members."""
    import numpy as np
    import pandas as pd
    from nimbus_v3.compute.market_breadth import pct_members_above_sma50

    def mk(seed, drift, vol):
        idx = pd.date_range("2023-01-01", "2025-12-31", freq="B")
        c = 100 * np.cumprod(
            1 + np.random.default_rng(seed).normal(drift, vol, len(idx)))
        return pd.DataFrame({"Close": c}, index=idx)

    up = {f"U{i}": mk(i, 0.002, 0.004) for i in range(5)}
    down = {f"D{i}": mk(i + 50, -0.002, 0.004) for i in range(5)}
    assert pct_members_above_sma50(list(up), up) > 0.8
    assert pct_members_above_sma50(list(down), down) < 0.2
    # Empty / no-data → NaN (no valid SMA to judge).
    nan_val = pct_members_above_sma50([], {})
    assert nan_val != nan_val
