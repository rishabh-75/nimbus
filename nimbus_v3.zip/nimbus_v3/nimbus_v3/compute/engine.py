"""nimbus_v3.compute.engine — ``StrategyComputeEngine``.

The single per-symbol indicator enrichment surface. One pass per
symbol per refresh; every downstream consumer (Market Pulse,
Dashboard, ride classifier) reads the resulting columns directly —
no extraction layer, no SignalState dataclass.

Slim profile (post-refactor): the engine adds only what the BB ride
classifier actually consumes — SMA(20), Bollinger 1σ envelope +
bandwidth, ATR(14). Earlier profiles (SMAs at 10/50/200, Williams %R,
RSI, MFI, ADX, BB 2σ, drawdowns, streaks, volume_ratio, ROC) were
research-era artefacts and have been removed. Callers that need a
dropped indicator should add it back through the canonical
:mod:`indicators` module rather than re-introducing one-off math.

Why a class and not a free function
───────────────────────────────────
- Stable identity for the cache schema-hash (``cls.enrichment_schema_hash()``).
- Future room for a "lightweight" profile knob without changing call sites.
- Matches the dependency-injection pattern used elsewhere in v3.

The class is stateless; the constructor takes no arguments.
"""
from __future__ import annotations

from typing import Final

import pandas as pd

from nimbus_v3.compute import indicators as ind


class StrategyComputeEngine:
    """Stateless per-symbol indicator enrichment engine.

    Pure functional: same input → same output, no side effects, thread-safe.

    Usage::

        engine = StrategyComputeEngine()
        enriched = engine.enrich(raw_df, symbol="RELIANCE")
    """

    #: Minimum bars required before long-lookback fields are reliable.
    #: With the slim profile, the binding constraint is BBW's
    #: 100-bar percentile window. We keep a 200-bar floor (matching
    #: the earlier SMA-200 era) so dashboards have a stable warmup
    #: contract — adding back longer indicators later is a no-op.
    MIN_BARS_REQUIRED: Final[int] = 200

    #: The canonical enrichment profile. Each tuple is
    #: (callable, kwargs). One row per indicator family.
    _ENRICHMENT_STEPS: Final[tuple] = (
        (ind.add_moving_averages,        {"periods": (20,)}),
        (ind.add_atr,                    {"period": 14}),
        # 1σ envelope: used by ride classifier and chart overlay.
        (ind.add_bollinger, {
            "period": 20, "std_dev": 1.0, "prefix": "bb_20_1s",
        }),
        # 1σ BBW + slope + percentile: used by ride score and Market
        # Pulse %B colour rule (RIDING when %B ∈ [1.0, 1.5] AND
        # SMA20 slope > 0 AND BBW slope > 0).
        (ind.add_bollinger_bandwidth, {
            "period": 20, "std_dev": 1.0, "prefix": "bb_20_1s",
            "slope_window": 5, "pctl_window": 100,
        }),
    )

    def __init__(self) -> None:
        """Stateless — no constructor arguments."""

    @classmethod
    def enrichment_schema_hash(cls) -> str:
        """Stable, deterministic hash of ``_ENRICHMENT_STEPS``.

        Used by the on-disk enrichment cache to namespace cached
        parquets by schema version. When the enrichment tuple changes
        (new indicator added, a period tweaked, a step reordered),
        the hash changes — old caches stay on disk but become
        unreachable by path, and fresh compute runs populate a new
        subdirectory.

        Uses MD5 for speed — this is a cache key, not a cryptographic
        hash. 8 hex chars of the digest gives 4 billion namespaces,
        far more than we'll ever need for schema versions.
        """
        import hashlib
        parts = []
        for fn, kwargs in cls._ENRICHMENT_STEPS:
            kw_repr = ",".join(
                f"{k}={v!r}" for k, v in sorted(kwargs.items())
            )
            parts.append(f"{fn.__qualname__}({kw_repr})")
        payload = "|".join(parts).encode("utf-8")
        return hashlib.md5(payload).hexdigest()[:8]

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def enrich(self, raw_df: pd.DataFrame, symbol: str) -> pd.DataFrame:
        """Compute every indicator the slim profile produces.

        Args:
            raw_df: DataFrame with OHLCV columns indexed by a
                DatetimeIndex. Must have at least
                :attr:`MIN_BARS_REQUIRED` rows. Not mutated.
            symbol: Symbol name, used in error messages only.

        Returns:
            A new DataFrame sharing ``raw_df``'s index. Columns
            include the original OHLCV plus
            ``sma_20``,
            ``atr_14``, ``atr_14_pct``,
            ``bb_20_1s_upper``, ``bb_20_1s_mid``, ``bb_20_1s_lower``,
            ``bb_20_1s_pct``,
            ``bbw_20_1s``, ``bbw_20_1s_slope``, ``bbw_20_1s_pctl``,
            and ``data_sufficient``.

        Raises:
            ValueError: ``raw_df`` is missing OHLCV columns or has
                fewer than :attr:`MIN_BARS_REQUIRED` rows.
        """
        self._validate_raw(raw_df, symbol)
        out = raw_df.copy()
        for fn, kwargs in self._ENRICHMENT_STEPS:
            out = fn(out, **kwargs)
        out = ind.add_data_sufficiency(out, min_bars=self.MIN_BARS_REQUIRED)
        return out

    # ══════════════════════════════════════════════════════════════════════
    # Private helpers
    # ══════════════════════════════════════════════════════════════════════

    def _validate_raw(self, raw_df: pd.DataFrame, symbol: str) -> None:
        required = {"Open", "High", "Low", "Close", "Volume"}
        missing = required - set(raw_df.columns)
        if missing:
            raise ValueError(
                f"enrich: raw_df for {symbol!r} is missing OHLCV column(s) "
                f"{sorted(missing)}"
            )
        if len(raw_df) < self.MIN_BARS_REQUIRED:
            raise ValueError(
                f"enrich: raw_df for {symbol!r} has {len(raw_df)} bars; "
                f"at least {self.MIN_BARS_REQUIRED} are required for "
                f"full enrichment."
            )
        if not isinstance(raw_df.index, pd.DatetimeIndex):
            raise ValueError(
                f"enrich: raw_df for {symbol!r} must have a DatetimeIndex; "
                f"got {type(raw_df.index).__name__}"
            )
