"""Diagnostic follow-up for run_correlation_regime_validation.py.

The first walk-forward run (2026-04-25) produced an unexpected
result: HIGH_CORR shipped POSITIVE at +3.46pp, opposite to the
academic "fear gauge" prior. Three concerns were flagged:

  1. Fold 4's HIGH_CORR test lift was +9.00pp on n=2,778 — a small-
     sample outlier that doubled the headline mean.
  2. Fold 1's HIGH_CORR train-N was 0 (insufficient warmup to
     produce labels) — the 100% sign-agreement is effectively
     based on 3 folds, not 4.
  3. The directional flip from the prior raises the question: is
     this a real Indian-market regime phenomenon or a sample
     artifact?

This script runs three diagnostic follow-ups:

  D1. Per-fold magnitude stability check. For each (regime), report:
      - mean & median of test-fold lifts
      - max/min individual fold lift
      - ratio of max to mean (flagging Fold-4-style outliers)

  D2. Robust mean — recompute the regime's signal excluding the
      fold with the smallest test-N. If the signal collapses, we
      know the smallest fold was carrying the result. If it
      survives, the signal is robust to that one fold's removal.

  D3. Calendar of HIGH_CORR + LOW_CORR date clusters. Lists every
      contiguous run of ≥5 days in each regime — gives the user
      something to inspect against known macro events (elections,
      corrections, Budget weeks, etc.) to judge whether the
      classifier is picking up coherent regimes.

Output: scripts/output/correlation_regime_diagnostics.txt

Does NOT modify or replace the original verdict file. This is a
strictly additive analysis.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

# Make project root importable
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd

# Reuse all the validated infrastructure from the main script
from scripts.run_correlation_regime_validation import (    # noqa: E402
    _aggregate_regime_lift,
    _build_industry_returns,
    _classify_regimes,
    _make_expanding_folds,
    _mean_pairwise_correlation_series,
    _N_FOLDS,
    _prepare_equity_only,
    _PURGE_BARS,
    _REGIMES,
    _SHIP_FOLD_AGREEMENT_THRESHOLD,
    _SHIP_MIN_LIFT_PP,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("correlation_regime_diagnostics")


_OUT_PATH: Path = _ROOT / "scripts" / "output" / "correlation_regime_diagnostics.txt"

#: Threshold for flagging a fold as a magnitude outlier. A fold's
#: test lift more than 2× the across-fold mean is the kind of
#: spike that should make us nervous about robustness.
_OUTLIER_RATIO_THRESHOLD: float = 2.0

#: Minimum run-length for a regime cluster worth reporting in the
#: calendar. Shorter clusters are noise; ≥5 contiguous days is
#: where regime persistence becomes operationally meaningful.
_MIN_CLUSTER_DAYS: int = 5

#: Cosmetic: divider widths.
_DIV_WIDE: str = "═" * 78
_DIV_THIN: str = "─" * 78


# ══════════════════════════════════════════════════════════════════════
# D1 + D2: per-fold magnitude analysis
# ══════════════════════════════════════════════════════════════════════

def _fold_magnitude_diagnostic(
    fold_results: list[dict], emit,
) -> dict[str, dict]:
    """For each regime, report per-fold magnitude statistics.

    Returns a dict {regime: {fold_lifts, mean, median, max_ratio,
    smallest_n_fold_idx, robust_mean_excl_smallest}}.
    """
    emit(_DIV_WIDE)
    emit("D1 + D2: PER-FOLD MAGNITUDE STABILITY")
    emit(_DIV_WIDE)
    emit("Question: is the headline lift robust, or is it driven")
    emit("by one outlier fold? Flag folds whose test lift exceeds")
    emit(f"{_OUTLIER_RATIO_THRESHOLD}× the regime's mean test lift.")
    emit("")
    emit("Robust mean: recompute mean excluding the smallest-N test")
    emit("fold per regime. If the signal collapses, the smallest")
    emit("fold was carrying it.")
    emit("")

    results: dict[str, dict] = {}
    for regime in _REGIMES:
        emit(f"REGIME: {regime}")
        emit(_DIV_THIN)

        # Pull (lift, n) pairs from each fold
        fold_data = []
        for fi, fold in enumerate(fold_results):
            stats = fold["test_stats"][regime]
            fold_data.append((fi, stats["lift_pp"], stats["n_obs"]))

        # Print per-fold detail
        emit(f"  {'FOLD':<6} {'TEST_LIFT':>11} {'TEST_N':>10}  {'NOTE'}")
        for fi, lift, n in fold_data:
            note = ""
            if n == 0:
                note = "EMPTY — no observations in this fold"
            elif n < 5000:
                note = f"SMALL N ({n})"
            emit(f"  {fi + 1:<6} {lift:>+10.2f}pp {n:>10d}  {note}")
        emit("")

        # Filter to folds with non-trivial N (matches main script's gate)
        valid = [(fi, lift, n) for fi, lift, n in fold_data if n >= 50]
        if not valid:
            emit("  No folds with N ≥ 50; cannot diagnose.")
            emit("")
            results[regime] = {"diagnosable": False}
            continue

        lifts = [v[1] for v in valid]
        ns = [v[2] for v in valid]
        mean_lift = float(np.mean(lifts))
        median_lift = float(np.median(lifts))

        # Magnitude outlier check
        if abs(mean_lift) > 1e-6:
            ratios = [abs(li) / abs(mean_lift) for li in lifts]
            max_ratio = max(ratios)
            outlier_fold_idx = ratios.index(max_ratio)
        else:
            max_ratio = 0.0
            outlier_fold_idx = -1
        outlier_flag = max_ratio > _OUTLIER_RATIO_THRESHOLD

        emit(f"  All-fold mean lift:      {mean_lift:+.2f}pp")
        emit(f"  All-fold median lift:    {median_lift:+.2f}pp")
        emit(f"  Mean/median spread:      "
             f"{abs(mean_lift - median_lift):.2f}pp "
             f"({'large' if abs(mean_lift - median_lift) > 0.5 else 'small'})")
        emit(f"  Max single-fold lift:    {max(lifts):+.2f}pp")
        emit(f"  Min single-fold lift:    {min(lifts):+.2f}pp")
        emit(f"  Largest |lift|/|mean|:   {max_ratio:.2f}× "
             f"({'OUTLIER FLAG' if outlier_flag else 'within bounds'})")
        emit("")

        # Robust mean: drop smallest-N fold
        smallest_n_idx = ns.index(min(ns))
        if len(valid) >= 2:
            robust_lifts = [li for i, li in enumerate(lifts) if i != smallest_n_idx]
            robust_mean = float(np.mean(robust_lifts))
            robust_n = sum(n for i, n in enumerate(ns) if i != smallest_n_idx)
            emit(f"  Robust mean (excl. smallest-N fold): {robust_mean:+.2f}pp")
            emit(f"  Smallest fold dropped: fold {valid[smallest_n_idx][0] + 1} "
                 f"with N={ns[smallest_n_idx]}, lift={lifts[smallest_n_idx]:+.2f}pp")
            emit(f"  Robust N: {robust_n}")
            # Honest comparison
            spread = abs(robust_mean - mean_lift)
            emit(f"  Mean shift from removing smallest fold: "
                 f"{spread:.2f}pp")
            if spread >= _SHIP_MIN_LIFT_PP:
                emit(f"  → SHIFT EXCEEDS SHIP-RULE THRESHOLD "
                     f"({_SHIP_MIN_LIFT_PP}pp). Signal is fragile.")
            else:
                emit(f"  → Shift is within ship-rule threshold. "
                     f"Signal is robust to fold removal.")
        else:
            robust_mean = mean_lift
            emit("  Cannot compute robust mean — only one valid fold.")
        emit("")

        results[regime] = {
            "diagnosable":         True,
            "fold_lifts":          lifts,
            "fold_ns":             ns,
            "mean_lift":           mean_lift,
            "median_lift":         median_lift,
            "max_ratio":           max_ratio,
            "outlier_flag":        outlier_flag,
            "robust_mean":         robust_mean,
            "smallest_n_fold":     valid[smallest_n_idx][0] + 1,
        }

    return results


# ══════════════════════════════════════════════════════════════════════
# D3: regime calendar — list contiguous clusters
# ══════════════════════════════════════════════════════════════════════

def _calendar_diagnostic(
    regime_series: pd.Series, emit,
) -> None:
    """List contiguous runs of HIGH_CORR / LOW_CORR ≥ _MIN_CLUSTER_DAYS
    long. Operator can overlay against known macro events.
    """
    emit(_DIV_WIDE)
    emit("D3: REGIME CALENDAR — CONTIGUOUS CLUSTERS ≥ "
         f"{_MIN_CLUSTER_DAYS} DAYS")
    emit(_DIV_WIDE)
    emit("Question: do HIGH_CORR / LOW_CORR clusters align with")
    emit("known macro events? Inspect the dates below for clustering")
    emit("around: corrections, Budget weeks, election windows,")
    emit("global selloffs, FII flow shifts, etc.")
    emit("")
    emit("If clusters track coherent events → classifier is real.")
    emit("If they're scattered randomly → classifier is noise.")
    emit("")

    # Drop NA bars
    rs = regime_series.dropna()
    if rs.empty:
        emit("  No classified bars.")
        return

    for target_regime in ("HIGH_CORR", "LOW_CORR"):
        emit(f"REGIME: {target_regime}")
        emit(_DIV_THIN)
        # Find contiguous runs
        is_target = (rs == target_regime).astype(int)
        # Run-length encoding via diff
        runs: list[tuple[pd.Timestamp, pd.Timestamp, int]] = []
        in_run = False
        run_start: pd.Timestamp | None = None
        for date, val in is_target.items():
            if val and not in_run:
                in_run = True
                run_start = date
            elif not val and in_run:
                # Run ended on the previous bar
                in_run = False
                # Find the previous bar (last date that was 1)
                prev_idx = rs.index.get_loc(date) - 1
                if prev_idx >= 0:
                    end = rs.index[prev_idx]
                    length = (
                        rs.index.get_loc(end)
                        - rs.index.get_loc(run_start)
                        + 1
                    )
                    if run_start is not None and length >= _MIN_CLUSTER_DAYS:
                        runs.append((run_start, end, length))
        # Handle case where run extends to end of series
        if in_run and run_start is not None:
            end = rs.index[-1]
            length = (
                rs.index.get_loc(end) - rs.index.get_loc(run_start) + 1
            )
            if length >= _MIN_CLUSTER_DAYS:
                runs.append((run_start, end, length))

        if not runs:
            emit(f"  No clusters ≥ {_MIN_CLUSTER_DAYS} days.")
            emit("")
            continue

        emit(f"  {len(runs)} clusters found, totaling "
             f"{sum(r[2] for r in runs)} bars:")
        emit("")
        emit(f"  {'START':<12} {'END':<12} {'LENGTH':>7}")
        for start, end, length in runs:
            emit(f"  {start.date()!s:<12} {end.date()!s:<12} {length:>7d}d")
        emit("")


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Re-running data prep + classification...")
    try:
        prepared = _prepare_equity_only()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    panel_w_fwd = prepared["panel_w_fwd"]
    industry_map = prepared["industry_map"]

    industry_returns = _build_industry_returns(panel_w_fwd, industry_map)
    corr_series = _mean_pairwise_correlation_series(industry_returns)
    regime_series = _classify_regimes(corr_series)

    valid_dates = regime_series.dropna().index
    folds = _make_expanding_folds(valid_dates, _N_FOLDS)

    log.info("Re-running fold aggregation...")
    fold_results = []
    for fi, (train_end, test_start, test_end) in enumerate(folds):
        train_start = regime_series.index.min()
        train_stats, train_baseline = _aggregate_regime_lift(
            panel_w_fwd, regime_series, train_start, train_end,
        )
        test_stats, test_baseline = _aggregate_regime_lift(
            panel_w_fwd, regime_series, test_start, test_end,
        )
        fold_results.append({
            "train_stats":    train_stats,
            "train_baseline": train_baseline,
            "test_stats":     test_stats,
            "test_baseline":  test_baseline,
        })

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("CORRELATION REGIME — DIAGNOSTIC FOLLOW-UP")
        emit(_DIV_WIDE)
        emit("Companion analysis to run_correlation_regime_validation.py.")
        emit("")
        emit("First run produced unexpected directional result")
        emit("(HIGH_CORR ships POSITIVE +3.46pp, opposite to the")
        emit("academic 'fear gauge' prior). This script probes")
        emit("whether the result is robust or fragile.")
        emit("")
        emit(f"Bars classified: {len(valid_dates)} "
             f"({valid_dates.min().date()} → {valid_dates.max().date()})")
        emit("")

        # Run D1 + D2
        diag_results = _fold_magnitude_diagnostic(fold_results, emit)

        # Run D3
        _calendar_diagnostic(regime_series, emit)

        # Final synthesis
        emit(_DIV_WIDE)
        emit("DIAGNOSTIC SYNTHESIS")
        emit(_DIV_WIDE)
        emit("")
        for regime in _REGIMES:
            r = diag_results.get(regime, {})
            if not r.get("diagnosable"):
                continue
            emit(f"{regime}:")
            emit(f"  All-fold mean:     {r['mean_lift']:+.2f}pp")
            emit(f"  Robust mean:       {r['robust_mean']:+.2f}pp "
                 f"(excl. fold {r['smallest_n_fold']})")
            shift = r['robust_mean'] - r['mean_lift']
            emit(f"  Shift on removal:  {shift:+.2f}pp")
            if r['outlier_flag']:
                emit(f"  ⚠  Magnitude outlier: max-fold/mean = "
                     f"{r['max_ratio']:.2f}×")
            else:
                emit(f"  ✓  No magnitude outliers")
            emit("")

        emit(_DIV_WIDE)
        emit("DECISION FRAMEWORK")
        emit(_DIV_WIDE)
        emit("Ship the badge IF (all of):")
        emit("  - Robust mean for each shipped regime stays above")
        emit(f"    {_SHIP_MIN_LIFT_PP}pp threshold")
        emit("  - No magnitude outlier flags fired (max ratio ≤ 2×)")
        emit("  - Calendar clusters look macro-coherent (your eyes)")
        emit("")
        emit("Don't ship the badge IF (any of):")
        emit("  - Robust mean falls below threshold (signal carried")
        emit("    by the smallest fold)")
        emit("  - Magnitude outlier flag fired (one fold doubled the")
        emit("    headline)")
        emit("  - Calendar clusters look random (classifier is noise)")
        emit("")
        emit("Ambiguous / partial pass:")
        emit("  - Ship as a NEUTRAL display badge (CORR: HIGH/NORMAL/")
        emit("    LOW with no color implications, no directional")
        emit("    claim) so operators see the data without being")
        emit("    misled by an unvalidated direction.")
        emit(_DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
