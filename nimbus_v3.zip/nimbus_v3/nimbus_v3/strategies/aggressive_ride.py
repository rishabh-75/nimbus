"""nimbus_v3.strategies.aggressive_ride — oracle's BB upper-band ride
ported onto v3's ``SignalState`` infrastructure.

This is the AGGRESSIVE-mode ride strategy. Reuses v3's enriched
SignalState (same indicators as oracle's ``bb_ride.py``) but applies
oracle's gates with two adaptations:

    1. No industry whitelist. Oracle ran this on every symbol; v3's
       conservative ``RideStrategy`` added an OOS-validated industry
       gate (``_RIDE_EDGE_INDUSTRIES``). Aggressive mode keeps oracle's
       broader firing pattern.

    2. "Fresh breakout" approximation. Oracle's entry gate was
       ``close >= bb_upper AND prev_close < prev_bb_upper`` — a fresh
       cross above the upper band. SignalState carries current-bar
       values only, so we approximate "fresh" with
       ``green_streak >= 1`` (recent upward motion). This catches
       breakouts with a 1-bar lag vs oracle's exact trigger but avoids
       firing on a move that's been above the band for weeks.

Other gates match oracle's defaults:
    - close >= bb_20_1s_upper  (at / above upper band)
    - green_streak >= 1         (upward motion — freshness proxy)
    - adx_14 >= 20              (trending, not chop)
    - vol_ratio_20 >= 1.2       (volume confirms)

Production weight is 1.0 — oracle treated these as tradable signals.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Gate parameters — ported from oracle's bb_ride.py defaults.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class AggressiveRideParams:
    adx_14_min: float = 20.0
    vol_ratio_min: float = 1.2
    green_streak_min: int = 1     # freshness proxy — see module docstring


class AggressiveRideStrategy:
    """Aggressive-mode BB ride. Rejects ETFs. No industry whitelist."""

    name: str = "AggressiveRide"
    setup_type: SetupType = SetupType.RIDE
    priority: int = 40
    production_weight: float = 1.0   # oracle treated this as tradable

    def __init__(
        self, params: AggressiveRideParams = AggressiveRideParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        # Unlike conservative ``RideStrategy``, no industry gate — oracle
        # ran on every symbol. The aggressive mode's whole point is
        # oracle-parity firing frequency.
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        # Must be at or above the upper 1σ band.
        if state.bb_20_1s_upper <= 0:
            return None
        if state.close < state.bb_20_1s_upper:
            return None
        # Freshness proxy — recent upward motion. See module docstring
        # for the "prev_close < prev_bb_upper" adaptation.
        if state.green_streak < self._p.green_streak_min:
            return None
        # Trending, not chop.
        if state.adx_14 < self._p.adx_14_min:
            return None
        # Volume confirms.
        if state.vol_ratio_20 < self._p.vol_ratio_min:
            return None

        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "bb_20_1s_upper": state.bb_20_1s_upper,
                "close": state.close,
                "green_streak": state.green_streak,
                "adx_14": state.adx_14,
                "vol_ratio_20": state.vol_ratio_20,
            },
        )
