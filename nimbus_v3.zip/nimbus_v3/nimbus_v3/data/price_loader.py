"""nimbus_v3.data.price_loader — OHLCV loader for NSE equities and ETFs.

Responsibilities
────────────────
- Fetch historical daily OHLCV from yfinance for an NSE symbol.
- Cache results as parquet via an injected ``CacheStore``.
- Normalise column names to the ``Open/High/Low/Close/Volume`` contract the
  compute engine expects.
- Return tz-naive, ascending-sorted DataFrames.

What this module does NOT do
────────────────────────────
- Does NOT compute indicators — that's ``compute/indicators.py``.
- Does NOT know about sectors or the universe — callers pass a symbol in.
- Does NOT decide staleness policy globally — each call can override the
  TTL or force a refresh.
- Does NOT retry aggressively. yfinance failures are logged and surfaced
  as an empty DataFrame — the orchestrator decides whether to move on or
  alert.

yfinance quirks handled
───────────────────────
- Columns can arrive as a ``MultiIndex`` when the caller asks for a
  basket; we flatten consistently even when a single symbol is passed.
- ``Adj Close`` is stripped — ``auto_adjust=True`` already folds splits
  and dividends into ``Close``.
- Empty frames from delisted symbols are returned as empty DataFrames,
  not exceptions.
- NSE symbols need a ``.NS`` suffix for yfinance lookups; the loader
  applies this transparently.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Final

import pandas as pd
import yfinance as yf

from nimbus_v3.core.market_session import is_market_open
from nimbus_v3.data.base import CacheStore


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Defaults
# ══════════════════════════════════════════════════════════════════════════════

#: Default cache age threshold during NSE trading hours (Mon–Fri,
#: 09:15–15:30 IST). When a cached value is older than this, the
#: next ``load()`` call refetches from yfinance. Balances two
#: needs:
#:
#:   - After-close viewing: a user opens the app at 16:00 to check
#:     today's close; if a stale cache written this morning is
#:     beyond 4h, the loader re-fetches and picks up today's bar
#:     when yfinance has it.
#:   - Intraday back-and-forth: within a 4h window, repeated
#:     symbol clicks hit the cache rather than re-fetching every
#:     time.
#:
#: Prior default was 20h, which prevented same-day re-fetches and
#: was the root cause of "my app shows Friday's close all Monday"
#: reports — if the cache was written Friday after close, 20h kept
#: serving it through Saturday morning; by Monday morning the 20h
#: window had elapsed but no new data existed yet (weekend), so
#: the next fetch after market re-open became the only refresh
#: path. 4h makes post-close refreshes routine. Daily data is
#: cheap — a few extra yfinance calls per day is fine.
_DEFAULT_CACHE_TTL = timedelta(hours=4)

#: Default history window for new fetches.
_DEFAULT_YEARS = 6


# ══════════════════════════════════════════════════════════════════════════════
# PriceLoader
# ══════════════════════════════════════════════════════════════════════════════

class PriceLoader:
    """Daily OHLCV loader with parquet cache.

    The loader is injected with a ``CacheStore`` at construction, then
    serves future requests from cache when fresh. Freshness is decided
    per-call via ``cache_ttl`` or forced by ``force_refresh``.

    One class serves both NSE equities and NSE indices. For equities,
    pass the default ``yfinance_suffix=".NS"``; for indices (e.g.
    ``^NSEI``, ``^NSEBANK``), pass ``yfinance_suffix=""``.
    """

    #: Default yfinance suffix for NSE equities. Exposed as a class
    #: attribute only for backward-compat introspection — the active
    #: suffix is the constructor argument.
    YFINANCE_SUFFIX: Final[str] = ".NS"

    def __init__(
        self,
        cache: CacheStore,
        *,
        default_years: int = _DEFAULT_YEARS,
        default_cache_ttl: timedelta = _DEFAULT_CACHE_TTL,
        yfinance_suffix: str = ".NS",
    ) -> None:
        """Args:
            cache: Store scoped to this loader's namespace (e.g.
                ``ParquetCache(Path("data/cache/price"))``). The loader
                owns every key it writes — namespace collisions are the
                caller's problem.
            default_years: History depth for fresh fetches.
            default_cache_ttl: Age at which cached data is considered
                stale and re-fetched **during NSE trading hours**.
                Override per-call via ``cache_ttl``. When NSE is closed,
                age is irrelevant: cached data is served as-is and
                closed-hours freshness is owned by the startup bulk
                refresh (see :mod:`nimbus_v3.data.panel_refresh`). The
                only closed-hours fetch is for a symbol with no cache at
                all. ``force_refresh=True`` bypasses everything.
            yfinance_suffix: String appended to the symbol before hitting
                yfinance. ``".NS"`` for NSE equities (default); ``""``
                for already-decorated index tickers like ``^NSEBANK``.
        """
        self._cache = cache
        self._default_years = default_years
        self._default_cache_ttl = default_cache_ttl
        self._yf_suffix = yfinance_suffix

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def load(
        self,
        symbol: str,
        *,
        years: int | None = None,
        cache_ttl: timedelta | None = None,
        force_refresh: bool = False,
    ) -> pd.DataFrame:
        """Load OHLCV for ``symbol``.

        Behaviour:
            1. If ``force_refresh``, skip the cache entirely.
            2. Otherwise, if the cached value exists and is younger than
               ``cache_ttl``, return it.
            3. Otherwise, fetch from yfinance, write to cache, return.
            4. If yfinance returns nothing and no cache is available,
               return an empty DataFrame (not an exception).

        Args:
            symbol: Canonical NSE symbol without the ``.NS`` suffix.
            years: Years of history to fetch on a cache miss. Defaults to
                the constructor value.
            cache_ttl: Max age before cache is considered stale. Defaults
                to the constructor value.
            force_refresh: Bypass the cache, fetch fresh, and overwrite.

        Returns:
            DataFrame with columns ``Open``, ``High``, ``Low``, ``Close``,
            ``Volume`` indexed by tz-naive ``DatetimeIndex``, sorted
            ascending. Empty if no data is available.
        """
        if not symbol:
            raise ValueError("symbol must be non-empty")
        years = years if years is not None else self._default_years

        # Freshness policy, by market state:
        #
        #   • force_refresh        → always fetch (REFRESH button).
        #   • explicit cache_ttl=  → honour it (research/tools).
        #   • market OPEN          → per-symbol age check against the 4h
        #                            TTL; a click on a >4h-old symbol
        #                            refetches so intraday/post-close
        #                            bars land promptly.
        #   • market CLOSED        → serve straight from cache, NO age
        #                            check. Closed-hours freshness is
        #                            owned entirely by the startup bulk
        #                            refresh (panel_refresh, 18h): if the
        #                            whole cache was stale at launch it
        #                            already refreshed. Per-symbol clicks
        #                            must never re-fetch during closed
        #                            hours — they read the cache the bulk
        #                            layer produced, keeping every symbol
        #                            consistent for the session. The ONE
        #                            exception is a symbol with no cache
        #                            at all (e.g. an off-universe symbol
        #                            the operator typed): fetch it once so
        #                            it's viewable.
        if not force_refresh:
            if cache_ttl is not None:
                if self._cache_is_fresh(symbol, cache_ttl):
                    cached = self._cache.get(symbol)
                    if cached is not None:
                        return cached
            elif is_market_open():
                if self._cache_is_fresh(symbol, self._default_cache_ttl):
                    cached = self._cache.get(symbol)
                    if cached is not None:
                        return cached
            else:
                # Closed hours: any cached copy wins, regardless of age.
                cached = self._cache.get(symbol)
                if cached is not None:
                    return cached
                # No cache → fall through and fetch this one symbol once.

        fetched = self._download_from_yfinance(symbol, years=years)
        if fetched.empty:
            # Return a cached copy if we have one, even if stale — stale
            # data is more useful than no data when yfinance is having a
            # bad day.
            cached = self._cache.get(symbol)
            if cached is not None:
                logger.info(
                    "price_loader: yfinance returned empty for %r; "
                    "falling back to stale cache", symbol,
                )
                return cached
            logger.warning(
                "price_loader: no data available for %r (yfinance empty, "
                "no cache)", symbol,
            )
            return fetched

        self._cache.set(symbol, fetched)
        return fetched

    def load_batch(
        self,
        symbols: list[str],
        *,
        years: int | None = None,
        cache_ttl: timedelta | None = None,
        force_refresh: bool = False,
    ) -> dict[str, pd.DataFrame]:
        """Load OHLCV for several symbols.

        Equivalent to calling :meth:`load` per symbol. Returns a dict with
        every input symbol as a key; values are DataFrames (possibly empty
        if the symbol has no data anywhere).

        No parallelism — yfinance's rate limits make coordinated batches
        unpredictable. Parallelise at the scan orchestrator if needed.
        """
        return {
            sym: self.load(
                sym,
                years=years,
                cache_ttl=cache_ttl,
                force_refresh=force_refresh,
            )
            for sym in symbols
        }

    def is_cached(self, symbol: str) -> bool:
        """Return True if any cached value exists for ``symbol`` (ignoring
        freshness). Thin wrapper over ``CacheStore.exists``."""
        return self._cache.exists(symbol)

    def cache_age(self, symbol: str) -> timedelta | None:
        """Return the age of the cached value, or ``None`` if absent."""
        return self._cache.age(symbol)

    # ══════════════════════════════════════════════════════════════════════
    # Private helpers
    # ══════════════════════════════════════════════════════════════════════

    def _cache_is_fresh(self, symbol: str, ttl: timedelta) -> bool:
        age = self._cache.age(symbol)
        if age is None:
            return False
        return age < ttl

    def _download_from_yfinance(self, symbol: str, *, years: int) -> pd.DataFrame:
        """Download from yfinance and normalize to the project contract.

        Returns an empty DataFrame on any yfinance failure — never raises
        for data availability issues. Raises only for programming errors
        (invalid arguments).
        """
        yf_symbol = f"{symbol}{self._yf_suffix}"
        # IST-aware "today" for two reasons:
        #   1. NSE's trading day is defined in IST; "today" to a UTC
        #      observer can still be "tomorrow" in IST (and vice
        #      versa), so using UTC-today would drop IST-today's bar
        #      in a ~5.5-hour window every night.
        #   2. yfinance's ``end`` parameter is EXCLUSIVE. Passing
        #      ``end=today`` returns bars up to ``today - 1``, which
        #      is why operators saw yesterday's close even after NSE
        #      published today's EOD bar. Pass ``today + 1`` so the
        #      latest bar is always requested. Overshooting is safe —
        #      yfinance ignores future dates.
        ist = timezone(timedelta(hours=5, minutes=30))
        today_ist = datetime.now(tz=ist).date()
        end = today_ist + timedelta(days=1)
        start = today_ist - timedelta(days=years * 365 + 7)

        try:
            raw = yf.download(
                tickers=yf_symbol,
                start=start.isoformat(),
                end=end.isoformat(),
                interval="1d",
                auto_adjust=True,
                progress=False,
                threads=False,
            )
        except Exception as exc:
            logger.warning(
                "price_loader: yfinance raised for %s: %s", yf_symbol, exc,
            )
            return pd.DataFrame()

        return self._normalize(raw)

    @staticmethod
    def _normalize(raw: pd.DataFrame) -> pd.DataFrame:
        """Apply the project's OHLCV contract to a yfinance frame.

        - Flatten MultiIndex columns if yfinance returned them.
        - Drop ``Adj Close`` (redundant when ``auto_adjust=True``).
        - Ensure index is tz-naive and sorted.
        - Drop rows that are all-NaN (yfinance inserts these around
          non-trading days in some versions).
        """
        if raw is None or raw.empty:
            return pd.DataFrame()

        df = raw.copy()

        # Flatten MultiIndex columns if present.
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        # Keep only the columns we care about, in a stable order.
        wanted = [c for c in ("Open", "High", "Low", "Close", "Volume") if c in df.columns]
        df = df[wanted]

        # Normalise index: tz-naive, ascending, deduplicated on date.
        if df.index.tz is not None:
            df.index = df.index.tz_localize(None)
        df = df.sort_index()
        df = df[~df.index.duplicated(keep="last")]

        # Drop rows where every OHLC value is NaN.
        price_cols = [c for c in ("Open", "High", "Low", "Close") if c in df.columns]
        if price_cols:
            df = df.dropna(subset=price_cols, how="all")

        return df
