"""nimbus_v3.data.panel_refresh — last-refresh timestamp tracking for
the bulk panel.

Background
──────────
The panel loader (:func:`main._make_panel_loader`) fetches OHLCV
for every NSE symbol in the industry DB at startup. Per-symbol
freshness is decided by ``PriceLoader``'s TTL policy
(market-aware: 4h during trading, 7d when closed).

That works well for *individual* symbol clicks, but produces a
class of staleness on weekends: each symbol's parquet was last
refreshed at whatever time the user last clicked it, so the panel
ends up as a patchwork of bars from various days. Sun morning the
operator sees a panel where some symbols have Friday's official
close, others have Thursday's intraday snapshot, etc. Per-symbol
TTL doesn't fix this — it never decides "the panel as a whole is
stale".

This module adds a panel-level marker. The panel loader checks
the marker's age before deciding whether to do a bulk refresh:
  - Age < ``threshold`` → use existing per-symbol caches as-is.
  - Age ≥ ``threshold`` → force-refresh every symbol from
    yfinance, then update the marker.

The threshold is configurable (default 12h) so weekend operators
get one consistent refresh per session without yfinance lag on
every app launch. Markets-open behaviour is unchanged — the
per-symbol 4h TTL handles intraday refreshes naturally.

Storage
───────
A single zero-byte marker file under the data root. We use the
file's mtime rather than writing a timestamp inside, because:
  - mtime is set atomically by the OS — no partial-write window.
  - No parsing needed; ``Path.stat().st_mtime`` is one syscall.
  - Unaffected by TZ ambiguity — mtime is always UTC seconds.

The marker is written *after* a successful bulk refresh, so if
the refresh crashes mid-flight the marker stays at its previous
value and the next launch retries.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

from nimbus_v3.data.paths import data_root


logger = logging.getLogger(__name__)


#: Default age threshold for the panel marker. When the marker
#: is older than this, the next panel load triggers a bulk
#: refresh from yfinance.
#:
#: 12 hours covers the typical operator workflow: open the app
#: once Sat morning (refresh fires once) and once Sun morning
#: (12h+ old → refresh fires once again). Multiple app launches
#: within the same 12h window read straight from disk.
DEFAULT_PANEL_REFRESH_INTERVAL: timedelta = timedelta(hours=18)


def _marker_path() -> Path:
    """Resolve the marker file path. Lives directly under the
    data root rather than under a cache subdir so it survives
    cache wipes (operators sometimes ``rm -rf data/cache/*`` to
    force a from-scratch refresh; the marker should not be
    regenerated as a side effect of that)."""
    return data_root() / ".panel_last_refresh"


def panel_age() -> timedelta | None:
    """Return the age of the panel-refresh marker.

    Returns:
        A :class:`timedelta` if the marker exists, ``None`` if
        not. ``None`` means "no record of any prior refresh" —
        the loader should treat this as needing an immediate
        refresh.
    """
    p = _marker_path()
    if not p.is_file():
        return None
    mtime = p.stat().st_mtime
    age_sec = datetime.now(tz=timezone.utc).timestamp() - mtime
    return timedelta(seconds=age_sec)


def panel_needs_refresh(threshold: timedelta) -> bool:
    """Return ``True`` if the panel hasn't been refreshed within
    ``threshold``.

    The decision rule:
      - No marker on disk → True (first run, or marker was wiped).
      - Marker present but older than ``threshold`` → True.
      - Marker present and younger than ``threshold`` → False.

    Args:
        threshold: How fresh the panel must be to skip a refresh.
            Typical values: 12h on weekends, infinity (a very
            large timedelta) to never auto-refresh.
    """
    age = panel_age()
    if age is None:
        return True
    return age >= threshold


def mark_panel_refreshed() -> None:
    """Record that a successful bulk refresh just completed.

    Touches the marker file's mtime. Called by the panel loader
    after every symbol has been processed (success or failure)
    — partial successes still count, since the alternative
    (don't update the marker) would force endless retries when
    a single symbol misbehaves.
    """
    p = _marker_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        # ``touch`` updates mtime if the file exists, creates an
        # empty file if not. Either way the mtime ends up at "now".
        p.touch()
    except OSError:
        # Marker is a hint, not load-bearing. If we can't write
        # it (read-only fs, etc), the next launch will refresh
        # again; that's the worst-case behaviour and it's fine.
        logger.warning(
            "panel_refresh: failed to update marker at %s — "
            "next launch will retry the bulk refresh", p,
        )
