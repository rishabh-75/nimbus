"""
modules/nse_client.py — Single-responsibility NSE HTTP client.

ALL NSE API calls MUST go through this class.
Handles the two-step cookie handshake NSE requires.

SHARED SINGLETON: Use get_shared_client() instead of NSEClient().
Initialized once at startup (main.py splash screen), shared across all
threads. Thread-safe via RLock on cookie management (warm/seed/reset).

Endpoints served:
  /api/option-chain-contract-info   → fetch_expiries(symbol)
  /api/option-chain-v3              → fetch_option_chain(symbol, expiry)
  /api/etf                          → fetch_etf()
  /api/fiidiiTradeReact             → fetch_fii_dii()
  /api/master-quote                 → fetch_master_quote()
  /api/corporate-announcements      → fetch_announcements(symbol)
  /api/equity-stockIndices          → fetch_index_constituents(index)
  /api/historicalOR/bulk-block-..   → fetch_deals(deal_type, from, to)
"""
import logging
import threading
import time
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)

_NSE_BASE = "https://www.nseindia.com"
_BASE_HEADER = {
    "Host": "www.nseindia.com",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:82.0) "
        "Gecko/20100101 Firefox/82.0"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;"
        "q=0.9,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.5",
    "Connection": "keep-alive",
}

# Referer pages for different endpoint groups
_REFERERS = {
    "base": _NSE_BASE,
    "option_chain": f"{_NSE_BASE}/option-chain",
    "etf": f"{_NSE_BASE}/market-data/exchange-traded-funds-etf",
    "announcements": f"{_NSE_BASE}/companies-listing/corporate-filings-announcements",
    "deals": f"{_NSE_BASE}/report-detail/display-bulk-and-block-deals",
}

_SEED_TTL = 300  # cache seed cookies per-referer for 5 minutes


class NSEClient:
    """
    Stateful NSE HTTP client with cookie management.

    Thread-safe: RLock protects cookie writes (warm/seed/reset).
    Concurrent fetches share the session's connection pool.

    Usage:
        client = get_shared_client()
        chain  = client.fetch_option_chain("SBIN", "27-Mar-2026")
        etfs   = client.fetch_etf()
    """

    def __init__(self, timeout: int = 15, retry: int = 2):
        self._timeout = timeout
        self._retry = retry
        self._lock = threading.RLock()
        self._session = requests.Session()
        self._seed_cache: dict[str, tuple[dict, float]] = {}
        self._warm()

    # ── Session lifecycle ─────────────────────────────────────────────────
    # Session accumulates cookies naturally (additive, never cleared).
    # requests.Session is thread-safe for concurrent gets (urllib3 pool).
    # RLock ONLY protects destructive ops: _warm() and reset().
    # fetch() is NOT locked — concurrent workers can fetch in parallel.

    def _warm(self):
        """Hit homepage to seed base cookies. Thread-safe."""
        with self._lock:
            try:
                self._session.get(
                    _NSE_BASE,
                    headers=self._header(),
                    allow_redirects=False,
                    timeout=self._timeout,
                )
                self._seed_cache.clear()
                logger.debug("NSEClient: homepage warm OK")
            except Exception as exc:
                logger.warning("NSEClient: homepage warm failed: %s", exc)

    def _seed(self, referer: str) -> dict:
        """
        Hit referer page to get endpoint-scoped cookies.
        Cached per-referer for 5 minutes to avoid redundant HTTP calls.
        Session accumulates these cookies in its jar (additive).
        Returns ONLY the new cookies from this referer response.
        """
        now = time.time()
        cached = self._seed_cache.get(referer)
        if cached and (now - cached[1]) < _SEED_TTL:
            return cached[0]

        try:
            resp = self._session.get(
                referer,
                headers=self._header(referer),
                allow_redirects=False,
                timeout=self._timeout,
            )
            cookies = dict(resp.cookies)
            self._seed_cache[referer] = (cookies, now)
            return cookies
        except Exception as exc:
            logger.warning("NSEClient: seed failed for %s: %s", referer, exc)
            return {}

    def reset(self):
        """Force full session reset — call on 401/403."""
        with self._lock:
            self._session = requests.Session()
            self._seed_cache.clear()
        self._warm()

    # ── Core fetch ────────────────────────────────────────────────────────

    def fetch(
        self,
        path: str,
        referer: str = _NSE_BASE,
        params: Optional[dict] = None,
    ) -> Any:
        """
        GET an NSE JSON endpoint. NOT locked — concurrent access OK.
        Seeds cookies from referer (cached 5 min), then fetches.
        Returns parsed JSON or raises RuntimeError on failure.
        """
        url = path if path.startswith("http") else _NSE_BASE + path
        cookies = self._seed(referer)

        for attempt in range(1, self._retry + 1):
            try:
                resp = self._session.get(
                    url,
                    headers=self._header(referer),
                    cookies=cookies,
                    params=params,
                    allow_redirects=False,
                    timeout=self._timeout,
                )
                if resp.status_code == 200:
                    ct = resp.headers.get("Content-Type", "")
                    if "json" in ct or "javascript" in ct:
                        return resp.json()
                    raise RuntimeError(f"NSE returned non-JSON: {ct[:50]}")

                logger.warning(
                    "NSEClient: HTTP %d for %s (attempt %d/%d)",
                    resp.status_code, url, attempt, self._retry,
                )
                if resp.status_code in (401, 403):
                    self.reset()
                    cookies = self._seed(referer)

                time.sleep(1.0 * attempt)

            except requests.RequestException as exc:
                logger.error("NSEClient: request error: %s", exc)
                time.sleep(1.0 * attempt)

        raise RuntimeError(f"NSEClient: failed after {self._retry} attempts — {url}")

    def fetch_safe(
        self,
        path: str,
        referer: str = _NSE_BASE,
        params: Optional[dict] = None,
        default: Any = None,
    ) -> Any:
        """Like fetch() but returns default on failure instead of raising."""
        try:
            return self.fetch(path, referer, params)
        except Exception as exc:
            logger.warning("NSEClient: fetch_safe failed for %s: %s", path, exc)
            return default

    # ── Options ───────────────────────────────────────────────────────────

    def fetch_expiries(self, symbol: str) -> list:
        """Get available expiry dates for a symbol's options."""
        data = self.fetch(
            "/api/option-chain-contract-info",
            referer=_REFERERS["option_chain"],
            params={"symbol": symbol},
        )
        return data.get("expiryDates", [])

    def fetch_option_chain(self, symbol: str, expiry: str) -> dict:
        """Get full option chain for symbol + expiry."""
        return self.fetch(
            "/api/option-chain-v3",
            referer=_REFERERS["option_chain"],
            params={"type": "Indices", "symbol": symbol, "expiry": expiry},
        )

    # ── ETF ───────────────────────────────────────────────────────────────

    def fetch_etf(self) -> dict:
        """Get ETF market data from NSE."""
        return self.fetch("/api/etf", referer=_REFERERS["etf"])

    # ── Market data ───────────────────────────────────────────────────────

    def fetch_fii_dii(self) -> dict:
        """Get FII/DII trading data."""
        return self.fetch("/api/fiidiiTradeReact", referer=_REFERERS["base"])

    def fetch_master_quote(self) -> dict:
        """Get master quote (universe of F&O symbols)."""
        return self.fetch("/api/master-quote", referer=_REFERERS["base"])

    def fetch_index_constituents(self, index: str = "NIFTY 500") -> dict:
        """Get raw index constituent data from NSE."""
        return self.fetch(
            "/api/equity-stockIndices",
            referer=f"{_NSE_BASE}/market-data/live-equity-market",
            params={"index": index},
        )

    def fetch_index_symbols(self, index: str = "NIFTY 50") -> list[str]:
        """
        Get clean symbol list for an NSE index.

        Returns sorted list of symbols (e.g. ['ADANIENT', 'AXISBANK', ...]).
        First entry in API response is the index itself — skipped.
        """
        data = self.fetch_index_constituents(index)
        records = data.get("data", [])
        symbols = []
        for rec in records[1:]:  # skip index row
            meta = rec.get("meta", {})
            sym = meta.get("symbol", rec.get("symbol", ""))
            if sym:
                symbols.append(sym.strip())
        return sorted(set(symbols))

    def fetch_index_with_meta(self, index: str = "NIFTY 50") -> list[dict]:
        """
        Get constituent symbols with company name, industry, and ISIN.

        Returns list of dicts:
            [{"symbol": "RELIANCE", "company": "Reliance Industries Ltd.",
              "industry": "Oil Exploration", "isin": "INE002A01018"}, ...]
        """
        data = self.fetch_index_constituents(index)
        records = data.get("data", [])
        results = []
        for rec in records[1:]:
            meta = rec.get("meta", {})
            sym = meta.get("symbol", rec.get("symbol", ""))
            if not sym:
                continue
            results.append({
                "symbol": sym.strip(),
                "company": meta.get("companyName", ""),
                "industry": meta.get("industry", ""),
                "isin": meta.get("isin", ""),
            })
        return results

    def fetch_all_indices(self) -> dict:
        """
        Get all available NSE indices grouped by segment.

        Returns dict: {"Broad Market": [...], "Sectoral": [...], ...}
        """
        return self.fetch(
            "/api/equity-master",
            referer=f"{_NSE_BASE}/market-data/live-equity-market",
        )

    # ── Corporate filings ─────────────────────────────────────────────────

    def fetch_announcements(self, symbol: str) -> list:
        """Get corporate announcements (Reg-30 filings)."""
        data = self.fetch(
            "/api/corporate-announcements",
            referer=_REFERERS["announcements"],
            params={"index": "equities", "symbol": symbol},
        )
        if isinstance(data, list):
            return data
        return data.get("data", [])

    # fetch_sast and fetch_open_offers removed — NSE endpoints deprecated (404 since 2026)

    # ── Deals ─────────────────────────────────────────────────────────────

    def fetch_deals(
        self, deal_type: str, from_date: str, to_date: str
    ) -> dict:
        """Get bulk/block/short-selling deals (JSON — capped to display rows)."""
        return self.fetch(
            "/api/historicalOR/bulk-block-short-deals",
            referer=_REFERERS["deals"],
            params={
                "optionType": deal_type,
                "from": from_date,
                "to": to_date,
            },
        )

    def fetch_deals_csv(
        self, deal_type: str, from_date: str, to_date: str
    ) -> list[dict]:
        """
        Fetch deals via CSV endpoint — returns ALL rows (no display cap).
        Same pattern as fetch(): seed + session.get, no global lock.
        """
        import csv
        import io

        url = _NSE_BASE + "/api/historicalOR/bulk-block-short-deals"
        cookies = self._seed(_REFERERS["deals"])

        for attempt in range(1, self._retry + 1):
            try:
                resp = self._session.get(
                    url,
                    headers=self._header(_REFERERS["deals"]),
                    cookies=cookies,
                    params={
                        "optionType": deal_type,
                        "from": from_date,
                        "to": to_date,
                        "csv": "true",
                    },
                    allow_redirects=False,
                    timeout=self._timeout,
                )
                if resp.status_code == 200:
                    text = resp.content.decode("utf-8-sig")
                    reader = csv.DictReader(io.StringIO(text))
                    rows = []
                    for row in reader:
                        cleaned = {}
                        for k, v in row.items():
                            if k is None:
                                continue
                            ck = k.replace("\ufeff", "").strip().strip('"').strip()
                            cv = v.strip().strip('"').strip() if v else ""
                            cleaned[ck] = cv
                        rows.append(cleaned)
                    return rows

                logger.warning(
                    "NSEClient: CSV HTTP %d (attempt %d/%d)",
                    resp.status_code, attempt, self._retry,
                )
                if resp.status_code in (401, 403):
                    self.reset()
                    cookies = self._seed(_REFERERS["deals"])
                time.sleep(1.0 * attempt)

            except requests.RequestException as exc:
                logger.error("NSEClient: CSV request error: %s", exc)
                time.sleep(1.0 * attempt)

        raise RuntimeError(
            f"NSEClient: fetch_deals_csv failed after {self._retry} attempts"
        )

    # ── Private ───────────────────────────────────────────────────────────

    def _header(self, referer: str = _NSE_BASE) -> dict:
        """Fresh header dict — never mutates _BASE_HEADER."""
        return {**_BASE_HEADER, "Referer": referer}


# ══════════════════════════════════════════════════════════════════════════════
# SHARED SINGLETON
# ══════════════════════════════════════════════════════════════════════════════
# All code should use get_shared_client() instead of NSEClient().
# Initialized once at startup (main.py), shared across all threads.
# Thread-safe: RLock protects cookie management.

_shared: Optional[NSEClient] = None
_shared_lock = threading.Lock()


def init_shared_client(timeout: int = 15, retry: int = 2) -> NSEClient:
    """
    Initialize the shared NSEClient. Called ONCE at app startup.
    Warms the session (homepage cookie handshake) before any workers start.
    """
    global _shared
    with _shared_lock:
        _shared = NSEClient(timeout=timeout, retry=retry)
        logger.info("NSEClient: shared instance initialized")
    return _shared


def get_shared_client() -> NSEClient:
    """
    Get the shared NSEClient singleton.
    Creates one if not yet initialized (lazy fallback for scripts/tests).
    """
    global _shared
    if _shared is None:
        with _shared_lock:
            if _shared is None:
                _shared = NSEClient()
                logger.info("NSEClient: shared instance created (lazy)")
    return _shared
