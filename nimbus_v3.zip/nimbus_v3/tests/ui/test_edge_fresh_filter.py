"""Fresh-breakout filter on the Edge tab.

A VIEW filter, not a scoring change: it isolates young rides (body above the
band, short streak) for scanning. The ranking is untouched — streak was not
found to predict forward return, so promoting fresh names in the score would
fit an intuition the panel rejected. These tests pin that it filters, that it
requires a real breakout (not just low streak), and that 4h confirmation is
optional but strict when required.
"""
from __future__ import annotations

import dataclasses

import pytest
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication

from nimbus_v3.compute.equity_edge import (
    EdgeHorizonSet,
    EdgeResult,
    SymbolEdge,
)
from nimbus_v3.ui.widgets.edge_tab import _FRESH_MAX_STREAK, EdgeTab

_FIELDS = [f.name for f in dataclasses.fields(SymbolEdge)]


@pytest.fixture(scope="module")
def qapp():
    yield QApplication.instance() or QApplication([])


def _row(sym, *, above, streak, above_4h, rr=0.5):
    return SymbolEdge(**{
        n: (sym if n == "symbol" else "Auto" if n == "industry"
            else above if n == "above" else streak if n == "streak"
            else above_4h if n == "above_4h"
            else rr if n == "reward_to_risk" else 1.0)
        for n in _FIELDS})


def _tab(rows):
    w = EdgeTab()
    w.set_horizon_set(EdgeHorizonSet(
        results=(EdgeResult(rows=tuple(rows), horizon_days=10, kappa=0.5),),
        default_horizon=10))
    return w


def _shown(w):
    m = w._model
    return [m.data(m.index(r, w._COLS.index("Symbol")))
            for r in range(m.rowCount())]


def _board():
    return [
        _row("EXTENDED", above=True, streak=8, above_4h=True, rr=0.9),
        _row("FRESH1", above=True, streak=1, above_4h=True, rr=0.3),
        _row("FRESH2", above=True, streak=2, above_4h=True, rr=0.28),
        _row("FRESH_NO4H", above=True, streak=1, above_4h=None, rr=0.27),
        _row("NOT_ABOVE", above=False, streak=1, above_4h=True, rr=0.5),
        _row("TOO_LONG", above=True, streak=3, above_4h=True, rr=0.4),
    ]


def test_off_shows_everything(qapp):  # noqa: ARG001
    w = _tab(_board())
    assert len(_shown(w)) == 6


def test_isolates_fresh_breakouts(qapp):  # noqa: ARG001
    w = _tab(_board())
    w._btn_fresh.setChecked(True)
    shown = set(_shown(w))
    assert shown == {"FRESH1", "FRESH2", "FRESH_NO4H"}
    assert "EXTENDED" not in shown       # streak 8, filtered
    assert "TOO_LONG" not in shown       # streak 3 > max 2
    assert "NOT_ABOVE" not in shown      # body not above band


def test_requires_a_real_breakout_not_just_low_streak(qapp):  # noqa: ARG001
    """A short streak with the body NOT above the band is not fresh."""
    w = _tab([_row("X", above=False, streak=1, above_4h=True)])
    w._btn_fresh.setChecked(True)
    assert _shown(w) == []


def test_streak_cutoff_is_inclusive(qapp):  # noqa: ARG001
    w = _tab([_row("AT", above=True, streak=_FRESH_MAX_STREAK, above_4h=True),
              _row("OVER", above=True, streak=_FRESH_MAX_STREAK + 1,
                   above_4h=True)])
    w._btn_fresh.setChecked(True)
    assert _shown(w) == ["AT"]


def test_4h_required_mode_excludes_unconfirmed(qapp):  # noqa: ARG001
    w = _tab(_board())
    w._btn_fresh.setChecked(True)
    w._fresh_require_4h = True
    w._refresh_view()
    shown = set(_shown(w))
    assert "FRESH_NO4H" not in shown      # 4h unknown -> excluded when required
    assert shown == {"FRESH1", "FRESH2"}


def test_enabling_sorts_by_reward_risk_desc(qapp):  # noqa: ARG001
    """Enabling Fresh orders the cohort by edge quality (Reward/Risk desc),
    not by recency — the best fresh setups on top."""
    w = _tab(_board())
    w._btn_fresh.setChecked(True)
    header = w._table.horizontalHeader()
    assert w._COLS[header.sortIndicatorSection()] == "Reward / Risk"
    assert header.sortIndicatorOrder() == Qt.SortOrder.DescendingOrder
    rr = [w._model.data(
        w._model.index(r, w._COLS.index("Reward / Risk")),
        Qt.ItemDataRole.UserRole) for r in range(w._model.rowCount())]
    assert rr == sorted(rr, reverse=True)


def test_composes_with_search(qapp):  # noqa: ARG001
    w = _tab(_board())
    w._btn_fresh.setChecked(True)
    w._search.setText("FRESH1")
    assert _shown(w) == ["FRESH1"]


def test_toggling_off_restores_all(qapp):  # noqa: ARG001
    w = _tab(_board())
    w._btn_fresh.setChecked(True)
    w._btn_fresh.setChecked(False)
    assert len(_shown(w)) == 6


def test_toggling_off_restores_previous_sort(qapp):  # noqa: ARG001
    """Undoing Fresh must return the board to the sort it had before.

    Start from a non-default sort (Streak asc) so the forced Reward/Risk
    sort is observable, then confirm it's restored on toggle-off.
    """
    w = _tab(_board())
    header = w._table.horizontalHeader()
    w._on_header_clicked(w._COLS.index("Streak"))   # custom prior sort
    before = (header.sortIndicatorSection(), header.sortIndicatorOrder())
    assert w._COLS[before[0]] == "Streak"
    w._btn_fresh.setChecked(True)
    assert w._COLS[header.sortIndicatorSection()] == "Reward / Risk"  # forced
    w._btn_fresh.setChecked(False)
    after = (header.sortIndicatorSection(), header.sortIndicatorOrder())
    assert after == before, "sort not restored after undoing Fresh"


def test_custom_sort_restored_after_fresh(qapp):  # noqa: ARG001
    """A user-chosen sort (not the default) must also survive Fresh on/off."""
    w = _tab(_board())
    w._on_header_clicked(w._COLS.index("Chg 5d%"))
    chosen = (w._table.horizontalHeader().sortIndicatorSection(),
              w._table.horizontalHeader().sortIndicatorOrder())
    w._btn_fresh.setChecked(True)
    w._btn_fresh.setChecked(False)
    now = (w._table.horizontalHeader().sortIndicatorSection(),
           w._table.horizontalHeader().sortIndicatorOrder())
    assert now == chosen
