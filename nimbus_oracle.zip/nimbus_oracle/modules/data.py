"""
modules/data.py
───────────────
Price data (yfinance) + NSE options chain download.

CONFIRMED WORKING PATTERNS (from nse_dashboard transcript):
NSE session → Firefox/82 UA + allow_redirects=False + cookies = dict(resp.cookies)
NSE API     → same header dict + allow_redirects=False on every call
yfinance    → tickers= kwarg + start= date string (NOT period=)
data fetch  → daily bars with fallback tickers for indices
"""

from __future__ import annotations

import json
import logging
import os
import time
import datetime
from datetime import date, timedelta
from typing import Optional, Tuple

import requests
import pandas as pd
import numpy as np

# ── NSE constants ─────────────────────────────────────────────────────────────
NSE_INDEX_SYMBOLS = {"NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTYNXT50"}

# ── NSE API access via nse_client ─────────────────────────────────────────────
# All NSE calls go through the shared NSEClient singleton.
from modules.nse_client import NSEClient, get_shared_client


def _make_nse_client():
    """Return the shared NSEClient singleton."""
    return get_shared_client()


# Backward compat: some modules import these
_NSE_HEADER = {}  # deprecated — do not use directly
def _make_nse_session():
    """DEPRECATED — use NSEClient instead. Kept for import compat."""
    client = _make_nse_client()
    return client._session, {}


def _get_expiry_dates_via_client(client: NSEClient, symbol: str) -> list:
    return client.fetch_expiries(symbol)


def _fetch_expiry_via_client(client: NSEClient, symbol: str, expiry: str) -> list:
    chain_type = "Indices" if symbol in NSE_INDEX_SYMBOLS else "Equities"
    data = client.fetch(
        "/api/option-chain-v3",
        referer="https://www.nseindia.com/option-chain",
        params={"type": chain_type, "symbol": symbol, "expiry": expiry},
    )
    return data.get("data", []) or data.get("records", {}).get("data", []) or []


def _assert_json(resp: requests.Response) -> None:
    """
    Raise a clear error if NSE returned an error status, HTML, or empty body.

    FIX-HTTP: check status code BEFORE parsing body — gives a cleaner message
    when NSE returns 429 (rate-limited) or 403 (blocked), rather than a
    confusing JSONDecodeError from parsing the error HTML page.
    """
    # FIX-HTTP: status code checks first
    if resp.status_code == 429:
        raise ValueError(
            "NSE rate-limited this IP (HTTP 429). "
            "Wait 30–60s and retry, or reduce scanner concurrency."
        )
    if resp.status_code == 403:
        raise ValueError(
            "NSE blocked this request (HTTP 403). "
            "Session cookie may have expired — NIMBUS will refresh automatically."
        )
    if resp.status_code not in (200, 302):
        raise ValueError(
            f"NSE returned HTTP {resp.status_code}. "
            "Retry in a few seconds; if persistent, check NSE maintenance status."
        )

    body = resp.text.strip()
    if not body:
        raise ValueError(
            "NSE returned an empty response — likely rate-limited. "
            "Wait 30s and retry, or upload a CSV."
        )
    if body.startswith("<"):
        raise ValueError(
            "NSE returned HTML instead of JSON — cookie/session issue. "
            "This sometimes resolves on retry; otherwise upload a CSV."
        )


def download_options(
    symbol: str,
    max_expiries: int = 5,
    progress_cb=None,
    client: Optional[NSEClient] = None,
) -> Tuple[Optional[pd.DataFrame], str]:
    """
    Download full options chain from NSE for up to max_expiries expiries.
    Returns (DataFrame, status_message).
    Accepts optional NSEClient; creates one if not provided.
    """
    _MAX_ATTEMPTS = 2

    for attempt in range(1, _MAX_ATTEMPTS + 1):
        try:
            if client is None or attempt > 1:
                client = _make_nse_client()

            expiries = _get_expiry_dates_via_client(client, symbol)
            if not expiries:
                return None, f"No expiry dates returned for {symbol}"

            expiries = expiries[:max_expiries]
            frames = []

            for i, exp in enumerate(expiries):
                if progress_cb:
                    progress_cb(f"{symbol} {exp} ({i+1}/{len(expiries)})")
                rows = _fetch_expiry_via_client(client, symbol, exp)
                if rows:
                    frames.append(_parse_rows(rows, symbol, exp))
                time.sleep(0.4)

            if not frames:
                return None, "All expiries returned empty data"

            combined = pd.concat(frames, ignore_index=True)
            return combined, f"✓ {len(frames)} expiries downloaded for {symbol}"

        except Exception as exc:
            msg = str(exc)
            if attempt < _MAX_ATTEMPTS and (
                "rate-limited" in msg.lower()
                or "non-json" in msg.lower()
                or "429" in msg
            ):
                logging.warning(
                    "download_options: %s attempt %d failed (%s) — "
                    "waiting 10s before retry",
                    symbol, attempt, msg[:60],
                )
                time.sleep(10)
                client = None  # force new client on retry
                continue
            return None, f"NSE download failed: {exc}"

    return None, f"NSE download failed after {_MAX_ATTEMPTS} attempts for {symbol}"


def _parse_rows(raw_rows: list, symbol: str, expiry: str) -> pd.DataFrame:
    """Convert raw option-chain-v3 rows into a flat DataFrame."""
    records = []
    for item in raw_rows:
        strike = item.get("strikePrice", 0)
        ce = item.get("CE", {})
        pe = item.get("PE", {})
        records.append(
            {
                "Strike": strike,
                "Expiry": expiry,
                "UnderlyingValue": ce.get("underlyingValue")
                or pe.get("underlyingValue")
                or 0,
                "CE_OI": ce.get("openInterest", 0),
                "CE_ChgOI": ce.get("changeinOpenInterest", 0),
                "CE_Volume": ce.get("totalTradedVolume", 0),
                "CE_IV": ce.get("impliedVolatility", 0),
                "CE_LTP": ce.get("lastPrice", 0),
                "PE_OI": pe.get("openInterest", 0),
                "PE_ChgOI": pe.get("changeinOpenInterest", 0),
                "PE_Volume": pe.get("totalTradedVolume", 0),
                "PE_IV": pe.get("impliedVolatility", 0),
                "PE_LTP": pe.get("lastPrice", 0),
            }
        )
    return pd.DataFrame(records)


# ══════════════════════════════════════════════════════════════════════════════
# PRICE DATA (confirmed working yfinance pattern from transcript)
# ══════════════════════════════════════════════════════════════════════════════


def _yf_ticker(symbol: str) -> str:
    """
    Map NSE index symbols to their Yahoo Finance tickers.
    """
    mapping = {
        "NIFTY": "^NSEI",
        "BANKNIFTY": "^NSEBANK",
        "FINNIFTY": "NIFTY_FIN_SERVICE.NS",
        "MIDCPNIFTY": "^NSMIDCP",
        "NIFTYNXT50": "NIFTY_NEXT_50.NS",
        "SENSEX": "^BSESN",
    }
    return mapping.get(symbol, f"{symbol}.NS")


# Fallback tickers when primary times out
_YF_FALLBACKS = {
    "^NSEI": ["NIFTY_50.NS", "^CNXNIFTY"],
    "^NSEBANK": ["NIFTY_BANK.NS"],
    "^NSMIDCP": ["NIFTY_MIDCAP_50.NS"],
}


def _flatten_yf(raw: pd.DataFrame) -> pd.DataFrame:
    """Flatten MultiIndex columns and normalise names."""
    if isinstance(raw.columns, pd.MultiIndex):
        raw.columns = raw.columns.get_level_values(0)
    raw.columns = [str(c).strip().title().replace(" ", "_") for c in raw.columns]
    raw = raw.rename(columns={"Adj_Close": "Close", "Adj Close": "Close"})
    return raw


def get_price_daily(symbol: str, days: int = 365) -> Tuple[pd.DataFrame, str]:
    """
    Fetch daily OHLCV bars. Tries primary ticker, then fallbacks on failure.
    """
    try:
        import yfinance as yf
    except ImportError:
        return pd.DataFrame(), "yfinance not installed"

    ticker = _yf_ticker(symbol)
    start = (date.today() - timedelta(days=days)).isoformat()

    # Try primary ticker + fallbacks
    tickers_to_try = [ticker] + _YF_FALLBACKS.get(ticker, [])

    for t in tickers_to_try:
        try:
            raw = yf.download(
                tickers=t, start=start, interval="1d",
                auto_adjust=True, progress=False, timeout=15,
            )
            raw = _flatten_yf(raw)
            if not raw.empty and "Close" in raw.columns:
                raw = raw[raw["Close"] > 0].copy()
                raw.index = pd.to_datetime(raw.index)
                if len(raw) >= 10:
                    return raw, f"✓ {t} · {len(raw)} daily bars"
        except Exception:
            continue

    return pd.DataFrame(), f"No price data for {symbol}"


# ══════════════════════════════════════════════════════════════════════════════
# UTILITIES
# ══════════════════════════════════════════════════════════════════════════════


def parse_uploaded_csv(file_obj) -> Tuple[Optional[pd.DataFrame], str]:
    """Parse an NSE options CSV uploaded by the user."""
    try:
        df = pd.read_csv(file_obj)
        df.columns = df.columns.str.strip()
        rename = {
            "Strike Price": "Strike",
            "STRIKE": "Strike",
            "Expiry Date": "Expiry",
            "EXPIRY DATE": "Expiry",
        }
        df = df.rename(columns={k: v for k, v in rename.items() if k in df.columns})
        for col in ["CE_OI", "PE_OI", "Strike"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        return df, f"✓ Loaded {len(df)} rows from uploaded file"
    except Exception as exc:
        return None, f"CSV parse error: {exc}"


def infer_spot(options_df: pd.DataFrame) -> Optional[float]:
    """Best-effort spot price from options chain."""
    if options_df is None or options_df.empty:
        return None
    if "UnderlyingValue" in options_df.columns:
        v = pd.to_numeric(options_df["UnderlyingValue"], errors="coerce")
        v = v[v > 0]
        if not v.empty:
            return float(v.median())
    if "Strike" in options_df.columns:
        strikes = pd.to_numeric(options_df["Strike"], errors="coerce")
        oi_cols = [c for c in ["CE_OI", "PE_OI"] if c in options_df.columns]
        if oi_cols:
            oi = (
                options_df[oi_cols]
                .apply(pd.to_numeric, errors="coerce")
                .sum(axis=1)
                .fillna(0)
            )
            total = oi.sum()
            if total > 0:
                return float((strikes * oi).sum() / total)
    return None


def is_market_open() -> bool:
    tz_ist = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    now = datetime.datetime.now(tz_ist)
    if now.weekday() >= 5:
        return False
    open_ = now.replace(hour=9, minute=15, second=0, microsecond=0)
    close_ = now.replace(hour=15, minute=30, second=0, microsecond=0)
    return open_ <= now <= close_


# ══════════════════════════════════════════════════════════════════════════════
# SYMBOL UNIVERSE (NSE master-quote API + local cache)
# ══════════════════════════════════════════════════════════════════════════════

_UNIVERSE_CACHE_PATH = os.path.join(
    os.path.dirname(__file__), "..", "data", "universe_cache.json"
)

# F&O-eligible indices always included regardless of master-quote response
_FNO_INDICES = [
    "NIFTY",
    "BANKNIFTY",
    "FINNIFTY",
    "MIDCPNIFTY",
    "NIFTYNXT50",
]

# Hard fallback uses index_constituents (has its own NSE fetch + disk cache)
def _nifty50_fallback() -> list[str]:
    """Last-resort symbol list when F&O universe fetch and cache both fail."""
    try:
        from modules.index_constituents import get_nifty50
        symbols = get_nifty50()
        if symbols:
            return symbols + list(_FNO_INDICES)
    except Exception:
        pass
    # Absolute last resort — 5 blue chips so the app doesn't show empty
    return ["RELIANCE", "HDFCBANK", "TCS", "INFY", "ICICIBANK"] + list(_FNO_INDICES)


def _universe_cache_valid() -> bool:
    """Return True if cache file exists and was written today (IST)."""
    if not os.path.exists(_UNIVERSE_CACHE_PATH):
        return False
    try:
        with open(_UNIVERSE_CACHE_PATH) as f:
            data = json.load(f)
        saved = datetime.datetime.fromisoformat(data.get("ts", "2000-01-01"))
        tz_ist = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
        now_ist = datetime.datetime.now(tz_ist).replace(tzinfo=None)
        # Refresh if saved before 09:00 today
        today_open = now_ist.replace(hour=9, minute=0, second=0, microsecond=0)
        return saved >= today_open
    except Exception:
        return False


def _load_universe_cache() -> list[str]:
    try:
        with open(_UNIVERSE_CACHE_PATH) as f:
            data = json.load(f)
        syms = data.get("symbols", [])
        if syms:
            return syms
    except Exception:
        pass
    return []


def _save_universe_cache(symbols: list[str]) -> None:
    try:
        os.makedirs(os.path.dirname(_UNIVERSE_CACHE_PATH), exist_ok=True)
        with open(_UNIVERSE_CACHE_PATH, "w") as f:
            json.dump(
                {
                    "ts": datetime.datetime.now().isoformat(),
                    "symbols": symbols,
                },
                f,
            )
    except Exception as exc:
        logging.warning(f"Could not save universe cache: {exc}")


def _fetch_universe_from_nse() -> list[str]:
    """Fetch F&O symbol universe from NSE master-quote API via NSEClient."""
    client = _make_nse_client()
    raw = client.fetch_master_quote()

    if isinstance(raw, list):
        items = raw
    elif isinstance(raw, dict):
        for key in ("data", "symbols", "results", "records"):
            if key in raw and isinstance(raw[key], list):
                items = raw[key]
                break
        else:
            items = []
    else:
        items = []

    symbols = set()
    for item in items:
        if isinstance(item, str):
            symbols.add(item.strip().upper())
        elif isinstance(item, dict):
            sym = (
                (
                    item.get("symbol")
                    or item.get("Symbol")
                    or item.get("SYMBOL")
                    or item.get("name")
                    or ""
                )
                .strip()
                .upper()
            )
            if not sym:
                continue
            inst_type = str(
                item.get("instrumentType")
                or item.get("instrument_type")
                or item.get("series")
                or ""
            ).upper()
            if any(x in inst_type for x in ("ETF", "BOND", "DEBENTURE", "WARRANT")):
                continue
            if (
                sym
                and sym.replace("-", "").replace("&", "").replace("_", "").isalpha()
            ):
                symbols.add(sym)

    for idx in _FNO_INDICES:
        symbols.add(idx)

    return sorted(symbols)


# ── India VIX ────────────────────────────────────────────────────────────────

_vix_cache: dict = {"value": None, "ts": 0.0}
_VIX_CACHE_TTL = 900  # 15 minutes


def fetch_india_vix() -> Optional[float]:
    """
    Fetch current India VIX level. Cached for 15 minutes.

    Priority: NSE live → yfinance intraday → yfinance daily.
    Returns float (e.g. 27.8) or None if unavailable.
    """
    import time as _t

    if _vix_cache["value"] is not None and (_t.time() - _vix_cache["ts"]) < _VIX_CACHE_TTL:
        return _vix_cache["value"]

    val = None

    # 1. Try NSE API (live intraday value)
    try:
        client = _make_nse_client()
        data = client.fetch_safe("/api/allIndices", default=None)
        if data and isinstance(data, dict):
            for idx in data.get("data", []):
                if idx.get("indexSymbol") == "INDIA VIX" or idx.get("index") == "INDIA VIX":
                    val = float(idx.get("last", idx.get("close", 0)))
                    if val > 0:
                        break
            if val and val > 0:
                _vix_cache["value"] = val
                _vix_cache["ts"] = _t.time()
                logging.info("India VIX (NSE live): %.2f", val)
                return val
    except Exception as exc:
        logging.debug("VIX NSE fetch failed: %s", exc)

    # 2. Try yfinance intraday (gets current session data)
    try:
        import yfinance as yf
        vix = yf.download("^INDIAVIX", period="1d", interval="5m",
                         progress=False, timeout=10)
        if vix is not None and not vix.empty:
            if isinstance(vix.columns, pd.MultiIndex):
                vix.columns = vix.columns.get_level_values(0)
            val = float(vix["Close"].dropna().iloc[-1])
            if val > 0:
                _vix_cache["value"] = val
                _vix_cache["ts"] = _t.time()
                logging.info("India VIX (yf intraday): %.2f", val)
                return val
    except Exception as exc:
        logging.debug("VIX yf intraday failed: %s", exc)

    # 3. Fallback: yfinance daily (previous close)
    try:
        import yfinance as yf
        vix = yf.download("^INDIAVIX", period="5d", progress=False, timeout=10)
        if vix is not None and not vix.empty:
            if isinstance(vix.columns, pd.MultiIndex):
                vix.columns = vix.columns.get_level_values(0)
            val = float(vix["Close"].dropna().iloc[-1])
            if val > 0:
                _vix_cache["value"] = val
                _vix_cache["ts"] = _t.time()
                logging.info("India VIX (yf daily): %.2f", val)
                return val
    except Exception as exc:
        logging.debug("VIX yf daily failed: %s", exc)

    return _vix_cache.get("value")  # return stale if available


def get_universe() -> list[str]:
    """
    Return list of NSE F&O symbol strings.
    Priority: valid cache → live NSE fetch → stale cache → hardcoded fallback.
    Never raises; always returns a usable list.
    """
    if _universe_cache_valid():
        cached = _load_universe_cache()
        if cached:
            return cached

    try:
        symbols = _fetch_universe_from_nse()
        if symbols:
            _save_universe_cache(symbols)
            return symbols
    except Exception as exc:
        logging.warning(f"Universe fetch failed: {exc}")

    stale = _load_universe_cache()
    if stale:
        return stale

    return _nifty50_fallback()


# ── Predefined curated lists for the scanner universe selector ──────────────
# Dynamically fetched from NSE via index_constituents module.
# Falls back to cache if NSE is unreachable.

def get_nifty100_symbols() -> list[str]:
    """NIFTY 100 constituents + F&O indices. Dynamic, cached 24h."""
    from modules.index_constituents import get_nifty100
    symbols = get_nifty100()
    # Always include F&O indices
    for idx in ["NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTYNXT50"]:
        if idx not in symbols:
            symbols.append(idx)
    return symbols


# Backward compat — lazy so import doesn't trigger network
class _LazySymbols:
    def __init__(self):
        self._data = None
    def _load(self):
        if self._data is None:
            self._data = get_nifty100_symbols()
    def __iter__(self):
        self._load(); return iter(self._data)
    def __len__(self):
        self._load(); return len(self._data)
    def __contains__(self, x):
        self._load(); return x in self._data
    def __getitem__(self, i):
        self._load(); return self._data[i]


NIFTY100_SYMBOLS = _LazySymbols()
