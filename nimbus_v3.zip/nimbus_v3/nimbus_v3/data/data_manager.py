"""nimbus_v3.data.data_manager — async per-symbol data loader.

Moves the two slow blocking operations (yfinance price fetch, NSE
options chain fetch) off the UI thread and replaces the current
synchronous ``MainWindow._load_symbol`` path with a signal-driven
one. The UI subscribes to ``price_ready`` / ``options_ready`` signals
and updates incrementally as data arrives — price first (chart can
render), then options (walls overlay).

Architecture
────────────

::

    ┌──────────────┐   request_price(sym)   ┌──────────────┐
    │  MainWindow  │ ─────────────────────→ │ DataManager  │
    │              │                        │              │
    │              │ ←──── price_ready ──── │   owns:      │
    │              │       (sym, result)    │  PriceWorker │
    │              │                        │  OptionsWkr  │
    └──────────────┘                        └──────────────┘
                                                   │
                                                   ▼
                                          ┌────────────────┐
                                          │ PriceLoader    │
                                          │  (disk cache)  │
                                          │ OptionsLoader  │
                                          │  (disk cache)  │
                                          └────────────────┘

Layering
────────

Three distinct concerns, one per layer:

1. **Loaders** (``PriceLoader``, ``OptionsLoader``) — already exist.
   Persist fetched data to disk, return DataFrames. Synchronous and
   slow on cache miss.

2. **DataManager** (this module) — new. Orchestrates threading
   and signals. Does NOT cache the returned DataFrames (the loaders
   already cache to disk, and re-caching in memory would create two
   sources of truth that can disagree). Its job is purely to move
   the blocking call off the UI thread and tell the UI when data
   arrives.

3. **Consumers** (``MainWindow``, dashboard panels) — subscribe to
   DataManager signals, apply business logic (enrich, extract state,
   build contexts), update UI.

This separation means:

- Loaders remain testable as pure functions without needing Qt.
- DataManager is the only layer that cares about threading.
- Consumers don't know or care how data was fetched.

Cancellation semantics
──────────────────────

When the user clicks a new symbol while the previous one's fetches
are still in flight, the old fetches are cancelled. "Cancel" means
the worker's ``_cancelled`` flag is set; the worker checks it at
two points (after the fetch completes, before emitting) and stays
silent if cancelled. The actual network operation can't be interrupted
mid-flight — we just discard its result. This is fine: network bytes
are cheap, and a truly orphaned request will finish in a few seconds
regardless.

Design non-goals
────────────────

- **In-memory TTL cache of DataFrames**: the loaders already handle
  this at the disk layer. Adding a second cache here would mean two
  sources of truth that must agree.
- **Auto-refresh timer**: out of scope for Phase 1. Can be layered
  on top in Phase 2 if needed (market-hours-only 60s refresh timer
  that calls ``request_price(current_symbol, force=True)``).
- **Concurrency pool limits**: QThread per request is acceptable
  for single-symbol dashboard loads (~2 threads per click). If we
  ever add bulk-refresh, revisit.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import pandas as pd
from PyQt6.QtCore import QObject, QThread, pyqtSignal

if TYPE_CHECKING:
    from nimbus_v3.data.options_loader import OptionsLoader
    from nimbus_v3.data.price_loader import PriceLoader

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Result envelopes — frozen dataclasses carrying data + provenance
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class PriceResult:
    """Price-fetch outcome for one symbol.

    Attributes
    ----------
    symbol
        Uppercased ticker the fetch was requested for.
    df
        OHLCV DataFrame. Empty when the fetch produced no data
        (consumers must handle this — an empty DF is not an error).
    fetched_at
        When the data was returned by the underlying loader. Not
        when it was last modified upstream — that's the caching
        layer's concern.
    source
        Human-readable provenance tag for diagnostics /
        freshness-indicator UI. One of:

            - ``"yfinance-fallback:<ticker>"`` — index-like symbols
              that route through the ``^NSEI`` fallback chain.
            - ``"PriceLoader"`` — normal equity path.
    """
    symbol: str
    df: pd.DataFrame
    fetched_at: pd.Timestamp
    source: str


@dataclass(frozen=True)
class OptionsResult:
    """Options-chain-fetch outcome for one symbol.

    ``chain`` is a DataFrame in the schema documented on
    :meth:`nimbus_v3.data.options_loader.OptionsLoader.load`. Empty
    when no chain is available (symbol has no F&O, fetch failed, or
    is_index flag was wrong).
    """
    symbol: str
    chain: pd.DataFrame
    fetched_at: pd.Timestamp
    is_index: bool


# ══════════════════════════════════════════════════════════════════════════════
# Workers — QThread subclasses wrapping the slow blocking calls
# ══════════════════════════════════════════════════════════════════════════════

class _BaseDataWorker(QThread):
    """Shared cancellation + error-signalling plumbing.

    Subclasses override :meth:`_do_work` with the actual fetch logic.
    Never raise from ``_do_work``; return a result object (or None
    for cancelled) and emit it via the subclass's ``finished`` signal.
    Use ``self._cancelled`` before any side effect; emit ``failed``
    on exception.
    """
    failed = pyqtSignal(str, str)   # symbol, error_msg

    def __init__(self, symbol: str, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._symbol = symbol
        self._cancelled = False

    def cancel(self) -> None:
        """Signal the worker to stop. The in-flight network call
        can't be interrupted, but the result (if it arrives) will
        be discarded before any signal is emitted.
        """
        self._cancelled = True


class PriceWorker(_BaseDataWorker):
    """Background OHLCV fetch.

    Handles two fetch paths:

    1. **Index-like symbols** (``NIFTY``, ``BANKNIFTY`` etc.) — try
       each yfinance ticker in the supplied fallback list until one
       returns a non-empty DF with a ``Close`` column.

    2. **Equity symbols** — delegate to ``PriceLoader.load(symbol)``
       which handles the standard NSE ``.NS`` suffix + Parquet cache.
    """
    finished = pyqtSignal(object)   # PriceResult

    def __init__(
        self,
        symbol: str,
        loader: "PriceLoader",
        *,
        index_fallbacks: list[str] | None = None,
        force_refresh: bool = False,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(symbol, parent)
        self._loader = loader
        self._fallbacks = index_fallbacks or []
        # When True, the worker must bypass any cached parquet
        # and re-fetch from yfinance. Used by the sidebar REFRESH
        # button so the operator can demand fresh data outside
        # the market-aware TTL window (7 days when NSE is closed —
        # which would otherwise pin Saturday/Sunday clicks to
        # whatever was last fetched).
        self._force_refresh = force_refresh

    def run(self) -> None:
        try:
            df, source = (
                self._fetch_index() if self._fallbacks
                else self._fetch_equity()
            )
        except Exception as exc:    # noqa: BLE001
            logger.exception("PriceWorker[%s]: fetch failed", self._symbol)
            if not self._cancelled:
                self.failed.emit(self._symbol, str(exc))
            return

        if self._cancelled:
            return

        self.finished.emit(PriceResult(
            symbol=self._symbol, df=df,
            fetched_at=pd.Timestamp.now(), source=source,
        ))

    def _fetch_index(self) -> tuple[pd.DataFrame, str]:
        """Try each fallback ticker in order; first non-empty wins."""
        import yfinance as yf
        for ticker in self._fallbacks:
            if self._cancelled:
                return pd.DataFrame(), "cancelled"
            try:
                raw = yf.download(
                    ticker, period="2y", interval="1d",
                    auto_adjust=True, progress=False, timeout=15,
                )
                if isinstance(raw.columns, pd.MultiIndex):
                    raw.columns = raw.columns.get_level_values(0)
                if not raw.empty and "Close" in raw.columns and len(raw) >= 10:
                    logger.info(
                        "PriceWorker[%s]: yfinance %s → %d bars",
                        self._symbol, ticker, len(raw),
                    )
                    return raw, f"yfinance-fallback:{ticker}"
            except Exception:    # noqa: BLE001
                logger.exception(
                    "PriceWorker[%s]: yfinance ticker %s failed — trying next",
                    self._symbol, ticker,
                )
        # All fallbacks exhausted.
        return pd.DataFrame(), "yfinance-fallback:exhausted"

    def _fetch_equity(self) -> tuple[pd.DataFrame, str]:
        df = self._loader.load(
            self._symbol, force_refresh=self._force_refresh,
        )
        logger.info(
            "PriceWorker[%s]: PriceLoader → %d bars (force_refresh=%s)",
            self._symbol, len(df), self._force_refresh,
        )
        return df, "PriceLoader"


class OptionsWorker(_BaseDataWorker):
    """Background NSE options-chain fetch.

    Wraps ``OptionsLoader.load(symbol, is_index=...)`` for off-UI-thread
    execution. Empty chains are returned normally (not treated as
    failures) — the symbol simply has no F&O, and the UI renders
    "no options data available" rather than an error.
    """
    finished = pyqtSignal(object)   # OptionsResult

    def __init__(
        self,
        symbol: str,
        loader: "OptionsLoader",
        *,
        is_index: bool = False,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(symbol, parent)
        self._loader = loader
        self._is_index = is_index

    def run(self) -> None:
        try:
            chain = self._loader.load(self._symbol, is_index=self._is_index)
            logger.info(
                "OptionsWorker[%s]: chain rows=%d (is_index=%s)",
                self._symbol, len(chain), self._is_index,
            )
        except Exception as exc:    # noqa: BLE001
            logger.exception("OptionsWorker[%s]: fetch failed", self._symbol)
            if not self._cancelled:
                self.failed.emit(self._symbol, str(exc))
            return

        if self._cancelled:
            return

        self.finished.emit(OptionsResult(
            symbol=self._symbol, chain=chain,
            fetched_at=pd.Timestamp.now(), is_index=self._is_index,
        ))


# ══════════════════════════════════════════════════════════════════════════════
# DataManager — the public orchestrator
# ══════════════════════════════════════════════════════════════════════════════

class DataManager(QObject):
    """Coordinates async per-symbol data loading.

    Public signals
    ──────────────

    ``price_ready(symbol: str, result: PriceResult)``
        Emitted when a price fetch completes successfully.

    ``options_ready(symbol: str, result: OptionsResult)``
        Emitted when an options-chain fetch completes successfully.

    ``load_failed(symbol: str, kind: str, error: str)``
        Emitted when either fetch fails. ``kind`` is ``"price"`` or
        ``"options"``. Connect this signal to show the user a toast /
        status-bar message.

    Public methods
    ──────────────

    ``request_price(symbol, index_fallbacks=None)``
        Start (or re-start) a price fetch for ``symbol``. If a price
        fetch for this symbol is already in flight, it is cancelled
        first — only the latest request's result will be emitted.

    ``request_options(symbol, is_index=False)``
        Start (or re-start) an options-chain fetch.

    ``cancel_symbol(symbol)``
        Cancel any in-flight requests for this symbol. Used when the
        user navigates away mid-load. Does not affect other symbols.

    ``cancel_all()``
        Cancel every in-flight request. Call on application shutdown.
    """
    price_ready = pyqtSignal(str, object)      # symbol, PriceResult
    options_ready = pyqtSignal(str, object)    # symbol, OptionsResult
    load_failed = pyqtSignal(str, str, str)    # symbol, kind, error

    def __init__(
        self,
        *,
        price_loader: "PriceLoader",
        options_loader: "OptionsLoader",
        index_loader: "PriceLoader | None" = None,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._price_loader = price_loader
        self._options_loader = options_loader
        # Index loader is a separately-configured PriceLoader (empty
        # yfinance suffix so ``^CRSLDX`` isn't decorated to ``.NS``, own
        # cache namespace). Used for benchmark/index series like the
        # Market Pulse CNX500 overlay. Optional so headless/test
        # construction without one still works.
        self._index_loader = index_loader
        self._index_cache: dict[str, "pd.Series | None"] = {}
        # Two distinct concepts:
        #
        # "Active" — the latest registered worker per (symbol, kind).
        # Used for cancellation semantics: when a new request for the
        # same symbol arrives, the active worker is cancelled before
        # the new one takes its place.
        self._active_price: dict[str, PriceWorker] = {}
        self._active_options: dict[str, OptionsWorker] = {}
        # "Alive" — every worker that has been ``start()``-ed and not
        # yet emitted finished or failed. Used for shutdown semantics:
        # we need to wait on these to exit cleanly, regardless of
        # whether they're still the "active" one for their symbol.
        # A cancelled worker stays in _alive until its run() completes
        # and the signal handler drains it; this is what lets a new
        # request for the same symbol safely start without clobbering
        # the old worker's reference before its thread ends.
        self._alive_workers: set[_BaseDataWorker] = set()

    # ── Public API ────────────────────────────────────────────────────────

    def request_price(
        self,
        symbol: str,
        *,
        index_fallbacks: list[str] | None = None,
        force_refresh: bool = False,
    ) -> None:
        """Start an async price fetch for ``symbol``.

        Cancels any in-flight price request for the same symbol
        before starting the new one — this prevents duplicate UI
        updates when the operator rapidly toggles between symbols.

        Args:
            symbol: NSE ticker.
            index_fallbacks: optional yfinance ticker list for
                index-like symbols (NIFTY, BANKNIFTY etc.) that
                aren't on ``.NS``.
            force_refresh: when True, bypasses every cache layer
                and forces a yfinance refetch. Wired to the
                sidebar REFRESH button so the operator can demand
                fresh data outside the market-aware TTL window
                (which, when NSE is closed, otherwise pins data
                for 7 days).
        """
        if not symbol:
            return
        sym = symbol.upper()
        self._cancel_active_price(sym)
        worker = PriceWorker(
            sym, self._price_loader,
            index_fallbacks=index_fallbacks,
            force_refresh=force_refresh,
            parent=self,
        )
        worker.finished.connect(self._on_price_finished)
        worker.failed.connect(self._on_price_failed)
        self._active_price[sym] = worker
        self._alive_workers.add(worker)
        worker.start()
        logger.debug(
            "DataManager: started PriceWorker for %s (force_refresh=%s)",
            sym, force_refresh,
        )

    def request_options(
        self,
        symbol: str,
        *,
        is_index: bool = False,
    ) -> None:
        """Start an async options-chain fetch for ``symbol``."""
        if not symbol:
            return
        sym = symbol.upper()
        self._cancel_active_options(sym)
        worker = OptionsWorker(
            sym, self._options_loader,
            is_index=is_index, parent=self,
        )
        worker.finished.connect(self._on_options_finished)
        worker.failed.connect(self._on_options_failed)
        self._active_options[sym] = worker
        self._alive_workers.add(worker)
        worker.start()
        logger.debug(
            "DataManager: started OptionsWorker for %s (is_index=%s)",
            sym, is_index,
        )

    def load_index(self, symbol: str) -> "pd.Series | None":
        """Return the Close series for an index symbol (e.g. ``^CRSLDX``).

        Synchronous and memoised — used for one-shot benchmark series
        (the Market Pulse CNX500 overlay, seasonality), not the hot
        per-symbol path, so it doesn't need the async worker machinery.
        Fail-soft: returns ``None`` if no index loader was configured or
        the fetch fails, so callers degrade gracefully.
        """
        sym = symbol.upper()
        if sym in self._index_cache:
            return self._index_cache[sym]
        close: "pd.Series | None" = None
        if self._index_loader is not None:
            try:
                df = self._index_loader.load(sym)
                # If the on-disk cache is shallower than the loader's
                # configured depth (e.g. an old 2y entry written before
                # the 5y bump), force one refresh so the CNX500 overlay +
                # seasonality get the full history. The index isn't part
                # of the bulk panel refresh, so without this nudge a stale
                # shallow entry would be served indefinitely.
                want_years = getattr(self._index_loader, "_default_years", 5)
                if df is not None and not df.empty:
                    earliest = pd.Timestamp(df.index.min())
                    if earliest.tzinfo is not None:
                        earliest = earliest.tz_localize(None)
                    want_start = pd.Timestamp.now() - pd.Timedelta(
                        days=want_years * 365)
                    if earliest > want_start + pd.Timedelta(days=183):
                        df = self._index_loader.load(sym, force_refresh=True)
                if df is not None and not df.empty and "Close" in df:
                    close = df["Close"]
            except Exception:    # noqa: BLE001
                logger.exception("index load failed for %s", sym)
        self._index_cache[sym] = close
        return close

    def cancel_symbol(self, symbol: str) -> None:
        """Cancel both price and options requests for ``symbol``.

        Non-blocking — flags are set, but the worker threads may
        still take a moment to finish their in-flight network call.
        Their signals will be silent afterwards. Call
        :meth:`shutdown` instead if you need to wait for the threads
        themselves to exit (e.g., on app shutdown).
        """
        sym = symbol.upper()
        self._cancel_active_price(sym)
        self._cancel_active_options(sym)

    def cancel_all(self) -> None:
        """Cancel every in-flight request. Non-blocking.

        The worker threads may still take a moment to unwind. If
        the caller is shutting down the application, use
        :meth:`shutdown` instead — it cancels AND waits.
        """
        for sym in list(self._active_price.keys()):
            self._cancel_active_price(sym)
        for sym in list(self._active_options.keys()):
            self._cancel_active_options(sym)

    def shutdown(self, timeout_ms: int = 2000) -> None:
        """Cancel everything and wait for all worker threads to exit.

        Call this on application shutdown before the parent QObject
        is destroyed — otherwise Qt will abort with "QThread destroyed
        while thread is still running". Each worker gets up to
        ``timeout_ms`` milliseconds to finish its in-flight operation;
        network-bound fetches that refuse to return within the
        timeout will be orphaned, but at least won't block shutdown
        indefinitely.
        """
        self.cancel_all()
        for w in list(self._alive_workers):
            w.wait(timeout_ms)
        self._alive_workers.clear()

    # ── Internal signal handlers ──────────────────────────────────────────

    def _on_price_finished(self, result: PriceResult) -> None:
        worker = self.sender()
        self._alive_workers.discard(worker)
        # Only emit if this worker is still the active one for its
        # symbol. A late-arriving signal from a cancelled-but-still-
        # running worker must not clobber the new worker's state or
        # fire an unwanted price_ready for the old result.
        if self._active_price.get(result.symbol) is worker:
            self._active_price.pop(result.symbol, None)
            self.price_ready.emit(result.symbol, result)

    def _on_price_failed(self, symbol: str, error: str) -> None:
        worker = self.sender()
        self._alive_workers.discard(worker)
        if self._active_price.get(symbol) is worker:
            self._active_price.pop(symbol, None)
            self.load_failed.emit(symbol, "price", error)

    def _on_options_finished(self, result: OptionsResult) -> None:
        worker = self.sender()
        self._alive_workers.discard(worker)
        if self._active_options.get(result.symbol) is worker:
            self._active_options.pop(result.symbol, None)
            self.options_ready.emit(result.symbol, result)

    def _on_options_failed(self, symbol: str, error: str) -> None:
        worker = self.sender()
        self._alive_workers.discard(worker)
        if self._active_options.get(symbol) is worker:
            self._active_options.pop(symbol, None)
            self.load_failed.emit(symbol, "options", error)

    # ── Cancellation helpers ──────────────────────────────────────────────

    def _cancel_active_price(self, symbol: str) -> None:
        """Mark the active price worker for ``symbol`` as cancelled
        and drop it from the active registry. The worker stays in
        ``_alive_workers`` until its thread exits — :meth:`shutdown`
        waits on it. Its signal handlers will noop via the identity
        check because it's no longer the active worker.
        """
        w = self._active_price.pop(symbol, None)
        if w is not None:
            w.cancel()

    def _cancel_active_options(self, symbol: str) -> None:
        w = self._active_options.pop(symbol, None)
        if w is not None:
            w.cancel()
