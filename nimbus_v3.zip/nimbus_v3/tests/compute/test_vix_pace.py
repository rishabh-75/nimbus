"""Tests for nimbus_v3.compute.vix_pace."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.vix_pace import (
    REGIME_FALLING, REGIME_RISING, REGIME_STABLE, REGIME_UNKNOWN, REGIMES,
    VIXPaceClassifier, VIXPaceState,
)


# ══════════════════════════════════════════════════════════════════════
# Schema hash
# ══════════════════════════════════════════════════════════════════════

class TestSchemaHash:

    def test_format(self):
        """Schema hash is an 8-char hex string (same convention as
        the other engines)."""
        h = VIXPaceClassifier.schema_hash()
        assert isinstance(h, str)
        assert len(h) == 8
        assert all(c in "0123456789abcdef" for c in h)

    def test_stability(self):
        """Same constants → same hash. Call twice, get same value."""
        a = VIXPaceClassifier.schema_hash()
        b = VIXPaceClassifier.schema_hash()
        assert a == b


# ══════════════════════════════════════════════════════════════════════
# Regime labels
# ══════════════════════════════════════════════════════════════════════

class TestRegimes:

    def test_regimes_tuple_canonical_order(self):
        """Canonical order is RISING, STABLE, FALLING — matches how
        UI tables are laid out and how the research output is
        formatted."""
        assert REGIMES == ("RISING", "STABLE", "FALLING")

    def test_regime_constants_are_strings(self):
        """Downstream consumers compare regime labels as strings, not
        enum members — verify they're plain strings."""
        for r in (REGIME_RISING, REGIME_STABLE, REGIME_FALLING, REGIME_UNKNOWN):
            assert isinstance(r, str)


# ══════════════════════════════════════════════════════════════════════
# classify_history
# ══════════════════════════════════════════════════════════════════════

class TestClassifyHistory:

    def _flat_vix(self, n: int, level: float = 15.0):
        return pd.Series(
            np.full(n, level),
            index=pd.bdate_range("2020-01-01", periods=n),
        )

    def test_output_structure(self):
        """Output has the expected columns and same index as input."""
        vix = self._flat_vix(400)
        out = VIXPaceClassifier().classify_history(vix)
        assert list(out.columns) == ["vix", "slope", "z", "regime"]
        pd.testing.assert_index_equal(out.index, vix.index)

    def test_warmup_bars_are_unknown(self):
        """First SLOPE_WINDOW + Z_BASELINE_WINDOW bars are UNKNOWN
        (z-score undefined during baseline warmup)."""
        vix = self._flat_vix(400)
        out = VIXPaceClassifier().classify_history(vix)
        warmup_end = VIXPaceClassifier.SLOPE_WINDOW + VIXPaceClassifier.Z_BASELINE_WINDOW - 1
        # Every bar before warmup_end should be UNKNOWN
        assert (out["regime"].iloc[:warmup_end] == REGIME_UNKNOWN).all()

    def test_flat_series_produces_stable_or_unknown_after_warmup(self):
        """A perfectly flat VIX gives slope=0, z=NaN (sd=0), so regime
        stays UNKNOWN. This is a degenerate edge case worth pinning."""
        vix = self._flat_vix(400)
        out = VIXPaceClassifier().classify_history(vix)
        # After warmup, with sd=0, z is NaN and regime stays UNKNOWN
        # (NaN comparisons are False so no label is applied).
        post = out["regime"].iloc[-50:]
        # Either all UNKNOWN (NaN z) or all STABLE (z=0) — depending
        # on how numpy handles 0/0. Accept both, pin that FALLING and
        # RISING never appear on a flat series.
        assert not (post == REGIME_RISING).any()
        assert not (post == REGIME_FALLING).any()

    def test_sharp_rise_labeled_rising(self):
        """Construct a series where slope jumps sharply — the final
        bar should be RISING."""
        n = 400
        prefix = np.full(n - 30, 15.0)
        rise = np.linspace(15.0, 35.0, 30)
        vix = pd.Series(
            np.concatenate([prefix, rise]),
            index=pd.bdate_range("2020-01-01", periods=n),
        )
        out = VIXPaceClassifier().classify_history(vix)
        # Last bar should be RISING
        assert out["regime"].iloc[-1] == REGIME_RISING

    def test_sharp_fall_labeled_falling(self):
        """Construct a series where VIX drops sharply — the final
        bar should be FALLING."""
        n = 400
        prefix = np.full(n - 30, 35.0)
        drop = np.linspace(35.0, 15.0, 30)
        vix = pd.Series(
            np.concatenate([prefix, drop]),
            index=pd.bdate_range("2020-01-01", periods=n),
        )
        out = VIXPaceClassifier().classify_history(vix)
        assert out["regime"].iloc[-1] == REGIME_FALLING


# ══════════════════════════════════════════════════════════════════════
# classify_current
# ══════════════════════════════════════════════════════════════════════

class TestClassifyCurrent:

    def test_returns_vixpacestate(self):
        """classify_current returns a VIXPaceState frozen dataclass."""
        vix = pd.Series(
            np.full(400, 15.0),
            index=pd.bdate_range("2020-01-01", periods=400),
        )
        state = VIXPaceClassifier().classify_current(vix)
        assert isinstance(state, VIXPaceState)

    def test_empty_series_returns_unknown_state(self):
        """Empty input → UNKNOWN regime, NaN z, zero run_length. Must
        not raise."""
        state = VIXPaceClassifier().classify_current(
            pd.Series([], dtype=float, index=pd.DatetimeIndex([])),
        )
        assert state.regime == REGIME_UNKNOWN
        assert np.isnan(state.slope_z)
        assert state.run_length == 0
        assert np.isnan(state.vix_close)

    def test_short_series_returns_unknown_regime(self):
        """Series shorter than warmup period → UNKNOWN. Classifier
        should degrade gracefully."""
        vix = pd.Series(
            np.full(50, 15.0),
            index=pd.bdate_range("2020-01-01", periods=50),
        )
        state = VIXPaceClassifier().classify_current(vix)
        assert state.regime == REGIME_UNKNOWN

    def test_run_length_counts_consecutive(self):
        """If the last N bars are all RISING, run_length is N. Use a
        sharp rise to force the trailing bars into RISING."""
        n = 500
        # Rising tail for 50 bars
        prefix = np.full(n - 60, 15.0)
        rise = np.linspace(15.0, 30.0, 60)
        vix = pd.Series(
            np.concatenate([prefix, rise]),
            index=pd.bdate_range("2020-01-01", periods=n),
        )
        state = VIXPaceClassifier().classify_current(vix)
        assert state.regime == REGIME_RISING
        # Run length should be reasonably long since the rise
        # continues through the final bars
        assert state.run_length >= 10

    def test_vix_close_matches_last_bar(self):
        """The returned vix_close mirrors the last value of the
        input series."""
        vix = pd.Series(
            [15.0] * 399 + [17.3],
            index=pd.bdate_range("2020-01-01", periods=400),
        )
        state = VIXPaceClassifier().classify_current(vix)
        assert state.vix_close == pytest.approx(17.3)


# ══════════════════════════════════════════════════════════════════════
# regime_distribution
# ══════════════════════════════════════════════════════════════════════

class TestRegimeDistribution:

    def test_returns_series_with_regime_counts(self):
        vix = pd.Series(
            np.full(500, 15.0),
            index=pd.bdate_range("2020-01-01", periods=500),
        )
        dist = VIXPaceClassifier().regime_distribution(vix)
        assert isinstance(dist, pd.Series)
        # Sum equals series length (every bar has some label)
        assert dist.sum() == 500


# ══════════════════════════════════════════════════════════════════════
# VIXPaceState
# ══════════════════════════════════════════════════════════════════════

class TestVIXPaceState:

    def test_is_frozen(self):
        """Frozen dataclass — attempting mutation raises."""
        state = VIXPaceState(
            regime=REGIME_STABLE,
            slope_z=0.2,
            run_length=3,
            vix_close=15.5,
        )
        with pytest.raises((AttributeError, Exception)):
            state.regime = REGIME_RISING
