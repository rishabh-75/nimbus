"""nimbus_v3.ui.presenters — ViewModel builders for UI widgets.

Widgets in :mod:`nimbus_v3.ui` are pure renderers: they own layout
and event wiring, but they do not interpret domain types. Interpreting
an enriched dataframe + NSE metadata into text strings,
colours, and tags lives here, in pure functions returning frozen
dataclasses.

Slim profile (post-refactor)
────────────────────────────
The old surface mapped every strategy to its own view (mean reversion,
ride, breakout, trap, etc.) plus a workflow panel that aggregated
contexts. With strategies and conviction gone, the surface collapses
to three tiny pieces:

    HeaderView                — symbol header (ticker, spot, %change, asof)
    IndustryClassificationView — NSE four-level industry tag

Every consumer (Sidebar + DashboardTab) reads these views; there are
no other presenters and there is no longer any "scan result" layer
between data and view.
"""
from __future__ import annotations

from nimbus_v3.ui.presenters.builders import (
    EMPTY_HEADER_VIEW,
    EMPTY_INDUSTRY_VIEW,
    HeaderView,
    IndustryClassificationView,
    build_header_view,
    build_industry_view,
)


__all__ = (
    "EMPTY_HEADER_VIEW",
    "EMPTY_INDUSTRY_VIEW",
    "HeaderView",
    "IndustryClassificationView",
    "build_header_view",
    "build_industry_view",
)
