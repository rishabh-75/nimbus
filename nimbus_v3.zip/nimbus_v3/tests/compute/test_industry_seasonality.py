"""Tests for nimbus_v3.compute.industry_seasonality."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.industry_seasonality import (
    compute_industry_seasonality,
    IndustrySeasonality,
    SeasonalityGrid,
)


def _series_panel(n_members=6, years=4, strong_month=4, freq="B"):
    idx = pd.date_range("2021-06-01", periods=int(252 * years), freq=freq)
    rng = np.random.default_rng(0)
    panel, syms = {}, []
    for j in range(n_members):
        rets = rng.normal(0.0002, 0.01, len(idx))
        bump = np.array([0.004 if d.month == strong_month else 0.0
                         for d in idx])
        close = 100 * np.cumprod(1 + rets + bump)
        panel[f"S{j}"] = pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(idx), 1e6 * (j + 1))},
            index=idx)
        syms.append(f"S{j}")
    return panel, syms


def test_empty_grid_no_members():
    g = compute_industry_seasonality({}, {})
    assert not g.has_data
    assert g.rows == ()


def test_below_floor_all_blank_row_is_dropped():
    """A below-floor industry (fewer than MIN_MEMBERS) can't form a
    composite in any month, so every cell is blank — and an all-blank row
    just clutters the grid, so it's dropped entirely. An industry at/above
    the floor aggregates and is kept."""
    panel, syms = _series_panel(n_members=6)
    small_rows = compute_industry_seasonality(
        {"Small": syms[:3]}, panel).rows         # 3 < MIN_MEMBERS=5
    assert small_rows == ()                       # dropped, not blank-kept

    big = compute_industry_seasonality({"Big": syms}, panel).rows
    assert len(big) == 1
    assert big[0].has_data
    assert all(n >= 5 for n in big[0].cell_n_members)


def test_min_members_override_matches_nse_spelling_variants():
    """The floor override must match regardless of NSE's hyphen/space
    quirks — the data may say 'Non - Ferrous Metals' (spaces around the
    hyphen, per industry_db.py) or 'Non-Ferrous Metals'. All variants
    must resolve to the lowered floor, while the distinct 'Ferrous Metals'
    must NOT be caught."""
    from nimbus_v3.compute.industry_seasonality import (
        _floor_for, MIN_MEMBERS, _MIN_MEMBERS_OVERRIDES)
    assert "non ferrous metals" in _MIN_MEMBERS_OVERRIDES
    target = _MIN_MEMBERS_OVERRIDES["non ferrous metals"]
    for variant in ("Non - Ferrous Metals", "Non-Ferrous Metals",
                    "Non-ferrous Metals", "non-ferrous metals",
                    "NON  -  FERROUS METALS"):
        assert _floor_for(variant) == target, variant
    # The distinct sibling industry must keep the default floor.
    assert _floor_for("Ferrous Metals") == MIN_MEMBERS


def test_min_members_override_aggregates_below_default_floor():
    """An industry whose floor is lowered via _MIN_MEMBERS_OVERRIDES
    aggregates REAL numbers from its members even though it's below the
    default MIN_MEMBERS, while another industry of the same size with no
    override is dropped."""
    from nimbus_v3.compute import industry_seasonality as iseas

    panel, syms = _series_panel(n_members=8)
    four_a, four_b = syms[:4], syms[4:8]

    # Override "Special" down to a 4-member floor for this test.
    saved = dict(iseas._MIN_MEMBERS_OVERRIDES)
    iseas._MIN_MEMBERS_OVERRIDES["special"] = 4
    try:
        g = compute_industry_seasonality(
            {"Special": four_a, "Plain": four_b}, panel)
    finally:
        iseas._MIN_MEMBERS_OVERRIDES.clear()
        iseas._MIN_MEMBERS_OVERRIDES.update(saved)

    present = {r.industry: r for r in g.rows}
    assert "Special" in present                   # kept via override
    assert present["Special"].has_data            # with real aggregates
    assert any(v == v for v in present["Special"].avg_returns)
    assert "Plain" not in present                 # same size, no override


def test_zero_members_industry_dropped():
    """An industry with NO usable members at all is dropped entirely."""
    panel, _ = _series_panel(n_members=6)
    g = compute_industry_seasonality({"Empty": ["NOPE1", "NOPE2"]}, panel)
    assert g.rows == ()


def test_all_and_unknown_skipped():
    panel, syms = _series_panel()
    g = compute_industry_seasonality(
        {"ALL": syms, "Unknown": syms, "Real": syms}, panel)
    inds = [r.industry for r in g.rows]
    assert inds == ["Real"]


def test_twelve_months_per_row():
    panel, syms = _series_panel()
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    assert len(r.avg_returns) == 12
    assert len(r.hit_rates) == 12


def test_strong_month_is_highest():
    panel, syms = _series_panel(strong_month=4)    # April bump
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    avgs = [v for v in r.avg_returns]
    # April (index 3) should be the strongest month.
    assert np.nanargmax(avgs) == 3
    assert r.has_data


def test_cumulative_path_surfaced_on_row():
    """The per-industry average-year walk is carried on each row (the
    running sum of avg_returns), so the heatmap can draw it without
    recomputing the composite."""
    panel, syms = _series_panel(n_members=6, years=5, strong_month=4)
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    assert len(r.cumulative_path) == 12
    # The path is a running sum of avg_returns (NaN months flat), so each
    # step differs from the prior by that month's avg return.
    avgs = list(r.avg_returns)
    running = 0.0
    for i in range(12):
        if avgs[i] == avgs[i]:
            running += avgs[i]
        assert r.cumulative_path[i] == pytest.approx(running, abs=1e-6)


def test_market_baseline_path_is_running_sum():
    """The grid's market_baseline_path is the cumulative walk of the
    member-weighted baseline — the 'average year' for the market."""
    panel, syms = _series_panel(n_members=6, years=5, strong_month=4)
    panel2, syms2 = _series_panel(n_members=6, years=5, strong_month=4)
    panel.update({f"B_{k}": v for k, v in panel2.items()})
    g = compute_industry_seasonality(
        {"A": syms, "B": [f"B_{s}" for s in syms2]}, panel)
    path = g.market_baseline_path
    assert len(path) == 12
    running = 0.0
    for i in range(12):
        b = g.market_baseline[i]
        if b == b:
            running += b
        assert path[i] == pytest.approx(running, abs=1e-6)


def test_insufficient_history_flagged():
    # ~1.5 years → below MIN_YEARS=3 → has_data False
    panel, syms = _series_panel(years=1)
    g = compute_industry_seasonality({"X": syms}, panel)
    assert g.rows
    assert g.rows[0].has_data is False


def test_populated_rows_sorted_first():
    panel_long, syms_long = _series_panel(years=4, strong_month=2)
    panel_short, syms_short = _series_panel(years=1, strong_month=2)
    # rename short syms to avoid key collision
    panel = dict(panel_long)
    short_map = {}
    for s in syms_short:
        panel[f"SH_{s}"] = panel_short[s]
        short_map[s] = f"SH_{s}"
    g = compute_industry_seasonality(
        {"HasData": syms_long, "NoData": [short_map[s] for s in syms_short]},
        panel)
    # industry with data should sort before the one without
    assert g.rows[0].industry == "HasData"
    assert g.rows[0].has_data


def test_std_returns_populated():
    panel, syms = _series_panel(years=4)
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    assert len(r.std_returns) == 12
    # at least the data months have a finite std (>=2 obs)
    finite = [s for s in r.std_returns if s == s]
    assert len(finite) >= 10


def test_outlier_month_has_high_dispersion():
    """A month whose mean is driven by one freak year should have a
    large std relative to a steadily-seasonal month."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    # consistent April every year vs one-freak-year September
    panel, syms = {}, []
    for j in range(6):
        rng = np.random.default_rng(j)
        rets = rng.normal(0.0002, 0.01, len(idx))
        april = np.array([0.003 if d.month == 4 else 0.0 for d in idx])
        sept_freak = np.array(
            [0.05 if (d.month == 9 and d.year == 2023) else 0.0 for d in idx])
        close = 100 * np.cumprod(1 + rets + april + sept_freak)
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(idx), 1e6)}, index=idx),
            f"S{j}")
        syms.append(f"S{j}")
    g = compute_industry_seasonality({"X": syms}, panel)
    r = g.rows[0]
    # September (idx 8) freak year → higher dispersion than April (idx 3)
    assert r.std_returns[8] > r.std_returns[3]


def test_market_baseline_computed():
    panel, syms = _series_panel(n_members=6, years=4, strong_month=4)
    # two industries so the baseline is a real cross-industry mean
    panel2, syms2 = _series_panel(n_members=6, years=4, strong_month=4)
    panel.update({f"B_{k}": v for k, v in panel2.items()})
    g = compute_industry_seasonality(
        {"A": syms, "B": [f"B_{s}" for s in syms2]}, panel)
    assert len(g.market_baseline) == 12
    # April (idx 3) baseline should be clearly positive (both strong there)
    assert g.market_baseline[3] > 0


def test_relative_nets_out_market_pattern():
    """A market-wide bump applied to ALL industries should cancel in the
    relative (avg - baseline) read, while an industry-specific bump
    survives."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, mbi = {}, {}
    for gi, name in enumerate(["X", "Y", "Z"]):
        syms = []
        for j in range(6):
            rng = np.random.default_rng(gi * 7 + j)
            rets = rng.normal(0.0002, 0.008, len(idx))
            # market-wide April bump for everyone
            april = np.array([0.005 if d.month == 4 else 0.0 for d in idx])
            # X also gets a unique January bump
            jan = np.array([0.006 if (d.month == 1 and gi == 0) else 0.0
                            for d in idx])
            close = 100 * np.cumprod(1 + rets + april + jan)
            panel[f"{name}{j}"] = eng.enrich(pd.DataFrame(
                {"Open": close, "High": close * 1.01, "Low": close * 0.99,
                 "Close": close, "Volume": np.full(len(idx), 1e6)},
                index=idx), f"{name}{j}")
            syms.append(f"{name}{j}")
        mbi[name] = syms
    g = compute_industry_seasonality(mbi, panel)
    by = {r.industry: r for r in g.rows}
    # April relative for X ≈ 0 (everyone shared it); January relative for
    # X clearly positive (X-only bump).
    x_apr_rel = by["X"].avg_returns[3] - g.market_baseline[3]
    x_jan_rel = by["X"].avg_returns[0] - g.market_baseline[0]
    assert abs(x_apr_rel) < 2.0
    assert x_jan_rel > 3.0


def test_market_baseline_is_member_weighted():
    """The baseline weights industries by member count, so a larger
    industry pulls it more than a smaller one. Build two industries that
    DISAGREE on a month's return and assert the weighted baseline sits
    closer to the bigger industry than a plain (unweighted) mean would."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.industry_rotation import MIN_MEMBERS

    idx = pd.date_range("2020-01-01", periods=int(252 * 5), freq="B")

    def _mk(seed, strong_month, n):
        panel, syms = {}, []
        for j in range(n):
            rng = np.random.default_rng(seed * 100 + j)
            rets = rng.normal(0.0002, 0.008, len(idx))
            bump = np.array([0.006 if d.month == strong_month else 0.0
                             for d in idx])
            close = 100 * np.cumprod(1 + rets + bump)
            key = f"G{seed}_{j}"
            panel[key] = pd.DataFrame(
                {"Open": close, "High": close * 1.01, "Low": close * 0.99,
                 "Close": close, "Volume": np.full(len(idx), 1e6)},
                index=idx)
            syms.append(key)
        return panel, syms

    big = max(MIN_MEMBERS + 4, 9)
    small = MIN_MEMBERS                 # smallest allowed industry
    p_big, s_big = _mk(1, strong_month=6, n=big)      # strong in June
    p_small, s_small = _mk(2, strong_month=3, n=small)  # strong in March
    panel = {**p_big, **p_small}
    g = compute_industry_seasonality(
        {"Big": s_big, "Small": s_small}, panel)

    by = {r.industry: r for r in g.rows}
    assert by["Big"].n_members == big
    assert by["Small"].n_members == small

    jun = 5
    big_jun = by["Big"].avg_returns[jun]
    small_jun = by["Small"].avg_returns[jun]
    plain = (big_jun + small_jun) / 2.0
    weighted = g.market_baseline[jun]
    # Big's June bump should dominate the baseline more than a flat mean.
    assert abs(weighted - big_jun) < abs(plain - big_jun)
    # And the weighted baseline is bounded by the two industry values.
    assert min(big_jun, small_jun) <= weighted <= max(big_jun, small_jun)


def test_cell_contributions_basic():
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    panel, syms = _series_panel(n_members=6, years=4, strong_month=4)
    cc = compute_cell_contributions("X", 4, syms, panel)
    assert cc.has_data
    assert len(cc.members) == 6
    # weights sum ~1
    assert abs(sum(m.weight for m in cc.members) - 1.0) < 1e-6
    # magnitude contributions ~ sum to cell avg
    tot = sum(m.magnitude_contribution for m in cc.members
              if m.magnitude_contribution == m.magnitude_contribution)
    assert abs(tot - cc.cell_avg) < 1e-6


def test_cell_contributions_outlier_drags_reliability():
    """A high-weight erratic member should have negative reliability
    impact even if its magnitude contribution is sizable."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, syms = {}, []
    for j in range(5):
        rng = np.random.default_rng(j)
        rets = rng.normal(0.0002, 0.008, len(idx))
        if j == 0:    # erratic: huge April only one year, big weight
            apr = np.array([0.05 if (d.month == 4 and d.year == 2023)
                            else 0.0 for d in idx])
            vol = 5e6
        else:
            apr = np.array([0.003 if d.month == 4 else 0.0 for d in idx])
            vol = 1e6
        close = 100 * np.cumprod(1 + rets + apr)
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(idx), vol)}, index=idx),
            f"S{j}")
        syms.append(f"S{j}")
    cc = compute_cell_contributions("X", 4, syms, panel)
    by = {m.symbol: m for m in cc.members}
    # S0 is the erratic high-weight member → negative reliability impact
    assert by["S0"].reliability_impact < 0
    # a steady member should have higher reliability impact than S0
    steady = max(cc.members, key=lambda m: m.reliability_impact)
    assert steady.symbol != "S0"


def test_cell_contributions_empty_for_no_members():
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    cc = compute_cell_contributions("X", 1, [], {})
    assert not cc.has_data


def test_member_remark_branches():
    from nimbus_v3.compute.industry_seasonality import _member_remark
    nan = float("nan")
    assert "single year" in _member_remark(
        avg=29.0, std=nan, hit=100, weight=0.1, mag=3.0,
        rel_impact=nan, n_years=1)
    assert "2 yrs" in _member_remark(
        avg=10.0, std=5.0, hit=100, weight=0.1, mag=1.0,
        rel_impact=0.05, n_years=2)
    assert "destabilis" in _member_remark(
        avg=5.0, std=15.0, hit=60, weight=0.28, mag=1.4,
        rel_impact=-0.15, n_years=5)
    assert "steady" in _member_remark(
        avg=22.6, std=6.9, hit=100, weight=0.13, mag=3.08,
        rel_impact=0.14, n_years=5)
    assert "lumpy" in _member_remark(
        avg=9.0, std=18.0, hit=80, weight=0.10, mag=0.9,
        rel_impact=0.05, n_years=5)


def test_contribution_includes_remark():
    panel, syms = _series_panel(n_members=6, years=4, strong_month=4)
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)
    cc = compute_cell_contributions("X", 4, syms, panel)
    assert all(isinstance(m.remark, str) for m in cc.members)


def test_remark_negative_consistency_is_not_reassuring():
    """A tightly-clustered NEGATIVE return must be flagged as a reliable
    drag, never as a reassuring 'consistent' positive."""
    from nimbus_v3.compute.industry_seasonality import _member_remark
    # tight, negative, never positive across years → reliably weak
    r = _member_remark(avg=-11.5, std=2.2, hit=0, weight=0.14, mag=-1.56,
                       rel_impact=0.14, n_years=5)
    assert "reliably weak" in r or "negative" in r
    assert "dependable" not in r and "gain" not in r
    # tight, positive → a good label
    r2 = _member_remark(avg=11.5, std=2.2, hit=100, weight=0.14, mag=1.56,
                        rel_impact=0.14, n_years=5)
    assert "dependable" in r2 or "gain" in r2


def test_remark_color_negative_not_green():
    from nimbus_v3.ui.widgets.seasonality_heatmap import _remark_color
    from nimbus_v3.ui.theme import GREEN
    assert _remark_color("reliably weak — steady drag") != GREEN
    assert _remark_color("consistently negative") != GREEN
    assert _remark_color("steady & dependable") == GREEN


def test_remark_recognises_anchor_and_dependable():
    """The dominant healthy driver and up-every-year names must NOT be
    blank — that was the gap where good constituents got no remark."""
    from nimbus_v3.compute.industry_seasonality import _member_remark
    # anchor: dominant weight, positive, steadies the cell
    anchor = _member_remark(avg=5.0, std=3.8, hit=80, weight=0.70,
                            mag=3.52, rel_impact=0.24, n_years=5)
    assert "anchor" in anchor
    # up every year: perfect hit, positive, moderate dispersion
    dep = _member_remark(avg=10.4, std=8.7, hit=100, weight=0.25,
                         mag=2.61, rel_impact=0.05, n_years=5)
    assert "up every year" in dep or "dependable" in dep
    # genuine middle: positive, moderate, not blank
    mid = _member_remark(avg=6.0, std=5.7, hit=60, weight=0.087,
                         mag=0.52, rel_impact=0.0, n_years=5)
    assert mid != ""


def test_remark_good_cases_coloured_green():
    from nimbus_v3.ui.widgets.seasonality_heatmap import _remark_color
    from nimbus_v3.ui.theme import GREEN
    assert _remark_color("anchor — drives & steadies") == GREEN
    assert _remark_color("up every year — dependable") == GREEN
    assert _remark_color("solid — moderate swing") == GREEN


def test_contribution_table_has_ratio_column():
    from nimbus_v3.ui.widgets.seasonality_heatmap import _ContributionTable
    assert "σ/avg" in _ContributionTable._COLS


def _panel_with_month_short_member(min_members):
    """Build an industry of `min_members` solid 5-year members plus one
    'GHOST' that spans 3+ calendar years overall but has only ONE July
    (a mid-year listing whose history hasn't crossed a third July). Used
    to pin the per-month stable filter."""
    solid_idx = pd.date_range("2019-01-01", "2025-12-31", freq="B")
    panel, syms = {}, []
    for j in range(min_members):
        rng = np.random.default_rng(100 + j)
        close = 100 * np.cumprod(1 + rng.normal(0.0004, 0.01, len(solid_idx)))
        k = f"SOLID{j}"
        panel[k] = pd.DataFrame(
            {"Open": close, "High": close * 1.01, "Low": close * 0.99,
             "Close": close, "Volume": np.full(len(solid_idx), 1e6)},
            index=solid_idx)
        syms.append(k)
    # GHOST: continuous Nov-2023..Aug-2024 (one July: 2024) then a gap to
    # Sep-2025..Mar-2026 — touches 4 calendar years, but only 1 July.
    gidx = pd.date_range("2023-11-01", "2024-08-15", freq="B").union(
        pd.date_range("2025-09-01", "2026-03-15", freq="B"))
    gclose = 100 * np.cumprod(
        1 + np.random.default_rng(7).normal(0.0005, 0.01, len(gidx)))
    panel["GHOST"] = pd.DataFrame(
        {"Open": gclose, "High": gclose * 1.01, "Low": gclose * 0.99,
         "Close": gclose, "Volume": np.full(len(gidx), 1e6)}, index=gidx)
    syms.append("GHOST")
    return panel, syms


def test_stable_filter_is_per_month_not_whole_history():
    """Regression: a member with >=3 calendar years overall but <3 of a
    specific month must be EXCLUDED from that month's stable cell — no
    'single year' member may leak through the >=3y toggle."""
    from nimbus_v3.compute.seasonality import MIN_YEARS, compute_seasonality
    from nimbus_v3.compute.industry_rotation import MIN_MEMBERS
    from nimbus_v3.compute.industry_seasonality import (
        _members_with_min_years, _members_with_min_years_in_month)

    panel, syms = _panel_with_month_short_member(MIN_MEMBERS)

    # GHOST spans >=3 calendar years overall, so the OLD whole-history
    # filter would have admitted it...
    assert compute_seasonality(panel["GHOST"]["Close"]).n_years >= MIN_YEARS
    assert "GHOST" in _members_with_min_years(syms, panel, MIN_YEARS)

    # ...but it has only one July, so the per-month filter excludes it
    # from July while the solid members remain.
    jul = _members_with_min_years_in_month(syms, panel, 7, MIN_YEARS)
    assert "GHOST" not in jul
    assert all(f"SOLID{j}" in jul for j in range(MIN_MEMBERS))


def test_stable_grid_has_no_single_year_cells_leaking():
    """End-to-end: with min_member_years on, the July contribution table
    contains no member whose July rests on a single year."""
    from nimbus_v3.compute.seasonality import MIN_YEARS
    from nimbus_v3.compute.industry_rotation import MIN_MEMBERS
    from nimbus_v3.compute.industry_seasonality import (
        compute_cell_contributions)

    panel, syms = _panel_with_month_short_member(MIN_MEMBERS)
    cell = compute_cell_contributions(
        "EE", 7, syms, panel, min_member_years=MIN_YEARS)
    assert cell.members                      # non-empty
    assert all(m.n_years >= MIN_YEARS for m in cell.members)
    assert "GHOST" not in {m.symbol for m in cell.members}
