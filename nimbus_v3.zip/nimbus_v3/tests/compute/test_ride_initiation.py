"""Tests for the LEGACY bool API (compute_ride_init_active,
compute_ride_init_active_industry).

These exist to ensure the backward-compatibility shim keeps working
for any caller that hasn't migrated to RideEngine yet. The detailed
behaviour tests live in tests/compute/ride_initiation/test_engine.py.

If you find yourself wanting to add a new test here, ask yourself
first whether it should go in test_engine.py instead. New code
should use RideEngine.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.ride_initiation import (
    ACTIVE_WINDOW,
    BBW_FLOOR_PERCENTILE,
    BBW_FLOOR_WINDOW,
    BBW_LOOKBACK,
    BODY_STRENGTH_MIN,
    CROSS_LOOKBACK,
    DETACHED_PCTB_MAX,
    DETACHED_PCTB_MAX_COMPRESSED,
    OPEN_PCTB_MAX,
    OPEN_PCTB_MIN,
    SMA_SLOPE_WINDOW,
    VOL_PERCENTILE_FLOOR,
    VOL_PERCENTILE_WINDOW,
    VOL_SURGE_RATIO,
    VOL_SURGE_WINDOW,
    compute_ride_init_active,
    compute_ride_init_active_industry,
    debug_fire_criteria,
    schema_hash,
)


def _enrich(close: np.ndarray, idx: pd.DatetimeIndex,
            open_: np.ndarray | None = None) -> pd.DataFrame:
    n = len(close)
    df = pd.DataFrame(index=idx)
    df["Close"] = close
    df["Open"] = open_ if open_ is not None else close.copy()
    df["High"] = close * 1.005
    df["Low"] = close * 0.995
    df["Volume"] = np.full(n, 1_000_000.0)
    sma = pd.Series(close, index=idx).rolling(20, min_periods=20).mean()
    std = pd.Series(close, index=idx).rolling(20, min_periods=20).std()
    df["sma_20"] = sma
    df["bb_20_1s_upper"] = sma + std
    df["bb_20_1s_lower"] = sma - std
    df["bbw_20_1s"] = (df["bb_20_1s_upper"] - df["bb_20_1s_lower"]) / df["sma_20"] * 100
    return df


# ══════════════════════════════════════════════════════════════════════
# Legacy bool API contract
# ══════════════════════════════════════════════════════════════════════


class TestLegacyBoolApi:

    def test_returns_bool_series(self):
        n = 100
        idx = pd.bdate_range("2024-01-01", periods=n)
        df = _enrich(np.full(n, 100.0), idx)
        result = compute_ride_init_active(df)
        assert isinstance(result, pd.Series)
        assert result.dtype == bool

    def test_missing_columns_returns_all_false(self):
        idx = pd.bdate_range("2024-01-01", periods=50)
        df = pd.DataFrame({"Close": np.full(50, 100.0)}, index=idx)
        result = compute_ride_init_active(df)
        assert not result.any()
        assert result.dtype == bool

    def test_short_panel_returns_all_false(self):
        n = 15
        idx = pd.bdate_range("2024-01-01", periods=n)
        df = _enrich(np.full(n, 100.0), idx)
        result = compute_ride_init_active(df)
        assert not result.any()


# ══════════════════════════════════════════════════════════════════════
# Industry legacy API
# ══════════════════════════════════════════════════════════════════════


class TestIndustryLegacy:

    def test_three_members_works(self):
        n = 150
        idx = pd.bdate_range("2025-01-01", periods=n)
        members = {
            f"SYM{i}": _enrich(np.full(n, 100.0 + i), idx)
            for i in range(3)
        }
        result = compute_ride_init_active_industry(members)
        assert isinstance(result, pd.Series)
        assert result.dtype == bool

    def test_thin_industry_returns_empty(self):
        n = 100
        idx = pd.bdate_range("2025-01-01", periods=n)
        members = {"SYM0": _enrich(np.full(n, 100.0), idx)}
        result = compute_ride_init_active_industry(members)
        assert result.empty


# ══════════════════════════════════════════════════════════════════════
# Schema hash
# ══════════════════════════════════════════════════════════════════════


class TestSchemaHash:

    def test_returns_8_char_string(self):
        h = schema_hash()
        assert isinstance(h, str)
        assert len(h) == 8

    def test_stable_across_calls(self):
        assert schema_hash() == schema_hash()


# ══════════════════════════════════════════════════════════════════════
# Constants accessibility
# ══════════════════════════════════════════════════════════════════════


class TestConstantsExposed:
    """All public constants the UI / tests / scanner snapshot depend on
    must remain importable from the package root."""

    def test_initiation_constants(self):
        assert CROSS_LOOKBACK > 0
        assert 0 < BBW_FLOOR_PERCENTILE < 1
        assert BBW_FLOOR_WINDOW > 0
        assert BBW_LOOKBACK > 0
        assert OPEN_PCTB_MIN < OPEN_PCTB_MAX
        assert DETACHED_PCTB_MAX < DETACHED_PCTB_MAX_COMPRESSED
        assert SMA_SLOPE_WINDOW > 0
        assert ACTIVE_WINDOW > 0

    def test_volume_constants(self):
        assert VOL_SURGE_WINDOW > 0
        assert VOL_SURGE_RATIO > 0
        assert VOL_PERCENTILE_WINDOW > 0
        assert 0 < VOL_PERCENTILE_FLOOR < 1

    def test_body_strength_constant(self):
        assert 0 < BODY_STRENGTH_MIN < 1


# ══════════════════════════════════════════════════════════════════════
# Debug utility
# ══════════════════════════════════════════════════════════════════════


class TestDebugUtility:

    def test_debug_returns_dataframe(self):
        n = 100
        idx = pd.bdate_range("2024-01-01", periods=n)
        df = _enrich(np.full(n, 100.0), idx)
        dbg = debug_fire_criteria(df)
        assert isinstance(dbg, pd.DataFrame)
        assert (dbg.index == df.index).all()

    def test_debug_includes_per_phase_fires(self):
        n = 100
        idx = pd.bdate_range("2024-01-01", periods=n)
        df = _enrich(np.full(n, 100.0), idx)
        dbg = debug_fire_criteria(df)
        for col in ("init_fire", "retest_fire", "cont_fire"):
            assert col in dbg.columns
            assert dbg[col].dtype == bool

    def test_debug_raises_on_missing_columns(self):
        import pytest
        idx = pd.bdate_range("2024-01-01", periods=50)
        df = pd.DataFrame({"Close": np.full(50, 100.0)}, index=idx)
        with pytest.raises(ValueError):
            debug_fire_criteria(df)
