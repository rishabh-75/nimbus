"""RS-reversion display signal (compute/rs_reversion.py). DISPLAY ONLY —
these pin the sign convention and fail-soft behaviour, not any score."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.rs_reversion import ZWIN, compute_rs_reversion_z


def _panel_with(mkt, specials):
    idx = mkt.index
    panel = {}
    for name, series in specials.items():
        panel[name] = pd.DataFrame({"Close": series}, index=idx)
    # neutral filler so the cross-sectional demean has a real cross-section
    for k in range(6):
        c = mkt * (1 + np.random.default_rng(k + 20).normal(0, 0.02, len(idx)))
        panel[f"N{k}"] = pd.DataFrame({"Close": c}, index=idx)
    return panel


def _market(n=700, seed=1):
    idx = pd.bdate_range("2022-01-01", periods=n)
    return pd.Series(
        100 * np.exp(np.cumsum(np.random.default_rng(seed).normal(0.0003, 0.01, n))),
        index=idx)


def test_laggard_is_cheap_surger_is_rich():
    mkt = _market()
    lag = mkt.copy(); lag.iloc[-40:] *= np.linspace(1, 0.90, 40)
    sur = mkt.copy(); sur.iloc[-40:] *= np.linspace(1, 1.12, 40)
    z = compute_rs_reversion_z(_panel_with(mkt, {"LAG": lag, "SUR": sur}), mkt)
    assert z["LAG"] < 0 < z["SUR"]        # sign convention
    assert z["LAG"] < z["SUR"]


def test_short_history_is_none():
    mkt = _market(n=ZWIN // 2 - 5)
    z = compute_rs_reversion_z(
        _panel_with(mkt, {"X": mkt.copy()}), mkt)
    assert z["X"] is None


def test_no_benchmark_all_none():
    mkt = _market()
    panel = _panel_with(mkt, {"X": mkt.copy()})
    z = compute_rs_reversion_z(panel, None)
    assert all(v is None for v in z.values())


def test_demean_centers_cross_section():
    """The returned z's are demeaned, so the finite values average ~0."""
    mkt = _market()
    lag = mkt.copy(); lag.iloc[-40:] *= np.linspace(1, 0.9, 40)
    z = compute_rs_reversion_z(_panel_with(mkt, {"LAG": lag}), mkt)
    finite = [v for v in z.values() if v is not None]
    assert abs(float(np.mean(finite))) < 1e-6


def test_fail_soft_on_bad_frame():
    mkt = _market()
    panel = _panel_with(mkt, {"X": mkt.copy()})
    panel["BAD"] = pd.DataFrame({"NotClose": [1, 2, 3]})
    z = compute_rs_reversion_z(panel, mkt)
    assert z["BAD"] is None            # bad frame -> None, no raise
