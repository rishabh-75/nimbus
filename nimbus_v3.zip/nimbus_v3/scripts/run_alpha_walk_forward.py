"""scripts/run_alpha_walk_forward.py — out-of-sample validation of the
alpha-vs-industry signal.

The in-sample research (scripts/run_beta_feature_research.py) produced:

    alpha top 10% (>+0.416%/day)  @ fwd_20d:  +2.00pp, t=+27.58, n=49,273

That was measured with the threshold fit to the entire panel. This
script tests whether the edge survives when the threshold is
determined with information available *only prior to* each
measurement bar — the realistic live-deployment scenario.

Two protocols
─────────────

Protocol A: Static train/test split
    - Train: 2020-01-01 → 2023-06-30
    - Test:  2023-07-01 → 2026-04-01
    - Compute the 90th percentile alpha threshold from train bars only.
    - Measure forward 10d/20d returns for stocks above that threshold
      in test bars.

Protocol B: Rolling expanding window
    - At each bar T in the test region, compute the threshold as the
      90th percentile of alpha values from all bars before T-60.
      (The 60-day buffer prevents look-ahead into the forward-return
      window.)
    - For computational efficiency, update the threshold every 180
      bars rather than every bar — mimicking a monthly re-calibration
      cadence.

If the test-period edge is within 30% of the in-sample edge, alpha
is a robust signal. If it collapses below 0.5pp or flips sign,
alpha was period-specific and should not be trusted in production.

Output
──────
stdout report + data/alpha_walk_forward.csv.

Run::

    python scripts/run_alpha_walk_forward.py
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nimbus_v3.data.industry_db import load_industry_db                  # noqa: E402
from nimbus_v3.research.equity_universe import load_equity_panel         # noqa: E402
from scripts.run_beta_feature_research import (                           # noqa: E402
    build_industry_returns_and_phase,
    compute_beta_features,
    MIN_INDUSTRY_SIZE,
)


logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("alpha_wf")


# ══════════════════════════════════════════════════════════════════════
# Statistics
# ══════════════════════════════════════════════════════════════════════

def welch_t(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(va / na + vb / nb)
    if denom == 0 or not np.isfinite(denom):
        return float("nan")
    return float((a.mean() - b.mean()) / denom)


def measure_edge(
    feats: pd.DataFrame,
    alpha_threshold: float,
    label: str,
) -> list[dict]:
    """For each horizon, compute forward-return delta for the
    cohort above ``alpha_threshold`` vs the rest."""
    alpha = feats["alpha_vs_industry"].to_numpy()
    above = (alpha > alpha_threshold)
    rows: list[dict] = []
    for horizon in ("fwd_10d", "fwd_20d"):
        fwd = feats[horizon].to_numpy()
        valid = np.isfinite(fwd)
        fired = valid & above
        kept = valid & ~above
        f, k = fwd[fired], fwd[kept]
        rows.append({
            "label": label,
            "horizon": horizon,
            "threshold": alpha_threshold,
            "n_fired": int(fired.sum()),
            "n_kept": int(kept.sum()),
            "fired_pct": float(f.mean() * 100) if len(f) else float("nan"),
            "kept_pct": float(k.mean() * 100) if len(k) else float("nan"),
            "delta_pp": (
                float((f.mean() - k.mean()) * 100)
                if len(f) and len(k) else float("nan")
            ),
            "t_stat": welch_t(f, k),
        })
    return rows


# ══════════════════════════════════════════════════════════════════════
# Protocol A: Static train/test
# ══════════════════════════════════════════════════════════════════════

def run_static_split(
    feats: pd.DataFrame,
    train_end: pd.Timestamp,
    test_start: pd.Timestamp,
) -> tuple[list[dict], list[dict], float]:
    """Fit threshold on train window, evaluate on test window.

    Returns (train_results, test_results, fitted_threshold).
    """
    # Align feats to bar_date if that column exists; otherwise
    # rely on whatever date column the panel carries. The research
    # script attaches bar dates via compute_features' DataFrame index
    # which becomes feats' index after concat — preserve it.
    dates = feats["bar_date"] if "bar_date" in feats.columns else None
    if dates is None:
        raise RuntimeError(
            "feats missing bar_date column — can't split by date"
        )

    train_mask = dates <= train_end
    test_mask = dates >= test_start

    train_alpha = feats.loc[train_mask, "alpha_vs_industry"].dropna()
    if len(train_alpha) < 1000:
        raise RuntimeError(
            f"Train set too small: {len(train_alpha)} valid alpha rows"
        )
    threshold = float(np.quantile(train_alpha, 0.90))

    log.info(
        "Protocol A: train %d bars, test %d bars, threshold = %.4f%%/day",
        int(train_mask.sum()), int(test_mask.sum()), threshold,
    )

    train_rows = measure_edge(
        feats.loc[train_mask], threshold, "train (in-sample)",
    )
    test_rows = measure_edge(
        feats.loc[test_mask], threshold, "test (out-of-sample)",
    )
    return train_rows, test_rows, threshold


# ══════════════════════════════════════════════════════════════════════
# Protocol B: Rolling expanding window
# ══════════════════════════════════════════════════════════════════════

def run_rolling_expanding(
    feats: pd.DataFrame,
    initial_train_end: pd.Timestamp,
    buffer_days: int = 60,
    recalibration_interval_days: int = 180,
) -> list[dict]:
    """Simulate live deployment: at each bar T, use only alpha values
    from bars before T-buffer_days to estimate the threshold.
    Re-estimate the threshold every ``recalibration_interval_days``.

    Returns a list of per-period result dicts. Also prints an aggregate
    row combining all held-out periods weighted by sample size.
    """
    if "bar_date" not in feats.columns:
        raise RuntimeError("feats missing bar_date column")

    dates = feats["bar_date"]
    test_start = initial_train_end + pd.Timedelta(days=1)
    test_end = dates.max()

    period_start = test_start
    all_rows: list[dict] = []
    log.info(
        "Protocol B: rolling, recalibrate every %dd, buffer=%dd, "
        "test window %s → %s",
        recalibration_interval_days, buffer_days,
        test_start.date(), test_end.date(),
    )

    while period_start < test_end:
        period_end = min(
            period_start + pd.Timedelta(days=recalibration_interval_days),
            test_end,
        )
        # Training data: everything before period_start - buffer_days.
        # This prevents alpha computed at T-1 from "leaking" the
        # forward return window into the threshold estimation.
        buffer_end = period_start - pd.Timedelta(days=buffer_days)
        train_alpha = feats.loc[
            dates <= buffer_end, "alpha_vs_industry",
        ].dropna()
        if len(train_alpha) < 1000:
            # Not enough warm-up yet, skip this period.
            period_start = period_end
            continue
        threshold = float(np.quantile(train_alpha, 0.90))

        # Measure edge in the period window.
        period_mask = (dates >= period_start) & (dates < period_end)
        period_feats = feats.loc[period_mask]
        if len(period_feats) < 100:
            period_start = period_end
            continue

        rows = measure_edge(
            period_feats, threshold,
            f"{period_start.date()} .. {period_end.date()}",
        )
        for r in rows:
            r["train_cutoff"] = str(buffer_end.date())
        all_rows.extend(rows)
        period_start = period_end

    return all_rows


# ══════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════

def print_static_report(train_rows: list[dict], test_rows: list[dict]) -> None:
    print("\n" + "═" * 72)
    print("PROTOCOL A — STATIC TRAIN/TEST SPLIT")
    print("═" * 72)
    hdr = (
        f"  {'label':24s}  {'horizon':8s}  {'n_fire':>7s}  "
        f"{'fired%':>8s}  {'kept%':>8s}  {'Δ pp':>8s}  {'t':>7s}"
    )
    sep = "─" * len(hdr)
    print(sep)
    print(hdr)
    print(sep)
    for r in train_rows + test_rows:
        print(
            f"  {r['label']:24s}  {r['horizon']:8s}  {r['n_fired']:>7,d}  "
            f"{r['fired_pct']:>+7.3f}  {r['kept_pct']:>+7.3f}  "
            f"{r['delta_pp']:>+7.3f}  {r['t_stat']:>+6.2f}"
        )
    print(sep)

    # Interpretation: compare test fwd_20d delta to in-sample.
    in_sample_20d = 2.00      # from earlier research
    test_20d_rows = [r for r in test_rows if r["horizon"] == "fwd_20d"]
    if test_20d_rows:
        test_delta = test_20d_rows[0]["delta_pp"]
        retention = test_delta / in_sample_20d if in_sample_20d else 0
        print(f"\n  In-sample 20d edge (reference): +{in_sample_20d:.2f}pp")
        print(f"  Out-of-sample 20d edge:         {test_delta:+.2f}pp")
        print(f"  Retention: {retention:.1%}")
        if retention >= 0.7:
            print("  → Signal is robust; small decay is typical.")
        elif retention >= 0.3:
            print("  → Signal is present but decayed; deploy with smaller size.")
        elif retention > 0:
            print("  → Signal is weak out-of-sample; consider re-examining.")
        else:
            print("  ⚠  Signal flipped sign or collapsed — DO NOT trust in-sample.")


def print_rolling_report(rows: list[dict]) -> None:
    print("\n" + "═" * 72)
    print("PROTOCOL B — ROLLING EXPANDING WINDOW")
    print("═" * 72)
    hdr = (
        f"  {'period':30s}  {'horizon':8s}  {'n_fire':>7s}  "
        f"{'Δ pp':>8s}  {'t':>7s}  {'thresh':>8s}"
    )
    sep = "─" * len(hdr)
    print(sep)
    print(hdr)
    print(sep)
    for r in rows:
        print(
            f"  {r['label']:30s}  {r['horizon']:8s}  {r['n_fired']:>7,d}  "
            f"{r['delta_pp']:>+7.3f}  {r['t_stat']:>+6.2f}  "
            f"{r['threshold']:>+7.4f}"
        )
    print(sep)

    # Aggregate across all periods, weighted by fires, for each horizon.
    for horizon in ("fwd_10d", "fwd_20d"):
        h_rows = [r for r in rows if r["horizon"] == horizon]
        if not h_rows:
            continue
        total_fires = sum(r["n_fired"] for r in h_rows)
        # Weighted-mean delta across periods.
        weighted_delta = (
            sum(r["delta_pp"] * r["n_fired"] for r in h_rows) / total_fires
            if total_fires else float("nan")
        )
        n_positive = sum(1 for r in h_rows if r["delta_pp"] > 0)
        print(
            f"\n  {horizon}: {len(h_rows)} periods, "
            f"{n_positive} positive ({n_positive/len(h_rows):.0%}), "
            f"weighted Δ = {weighted_delta:+.3f}pp"
        )


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Loading equity panel …")
    panel = load_equity_panel(verbose=False)
    log.info("Panel: %d symbols", len(panel))

    log.info("Loading industry DB …")
    ind_db = load_industry_db()
    if not ind_db:
        log.error("Industry DB empty — run scripts/build_industry_db.py first")
        sys.exit(1)

    industry_map = {sym: rec.industry for sym, rec in ind_db.items()}

    log.info("Building industry return + phase series …")
    industry_rets, industry_phases, industry_members = (
        build_industry_returns_and_phase(panel, industry_map)
    )

    log.info("Computing per-stock beta / alpha …")
    feats = compute_beta_features(
        panel, industry_map, industry_rets, industry_phases, industry_members,
    )

    if "bar_date" not in feats.columns:
        log.error(
            "feats missing bar_date column — update "
            "scripts/run_beta_feature_research.py to preserve it"
        )
        sys.exit(1)

    log.info("Feats with dates: %d rows", len(feats))

    # ── Protocol A: static split ───────────────────────────────────
    train_end = pd.Timestamp("2023-06-30")
    test_start = pd.Timestamp("2023-07-01")
    train_rows, test_rows, threshold = run_static_split(
        feats, train_end, test_start,
    )
    print_static_report(train_rows, test_rows)

    # ── Protocol B: rolling expanding window ───────────────────────
    # Use a later start for the rolling test so we have enough warmup.
    rolling_start = pd.Timestamp("2023-01-01")
    rolling_rows = run_rolling_expanding(
        feats, rolling_start,
        buffer_days=60, recalibration_interval_days=180,
    )
    print_rolling_report(rolling_rows)

    # Persist
    all_rows = list(train_rows) + list(test_rows) + list(rolling_rows)
    out_df = pd.DataFrame(all_rows)
    out_path = Path("data/alpha_walk_forward.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    log.info("\nResults → %s", out_path)

    # ── Bottom line ────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("BOTTOM LINE")
    print("═" * 72)

    test_20d = [r for r in test_rows if r["horizon"] == "fwd_20d"]
    rolling_20d = [r for r in rolling_rows if r["horizon"] == "fwd_20d"]

    if test_20d:
        test_delta = test_20d[0]["delta_pp"]
        test_t = test_20d[0]["t_stat"]
        print(
            f"Static OOS (20d):  Δ = {test_delta:+.2f}pp, t = {test_t:+.2f}"
        )

    if rolling_20d:
        total_fires = sum(r["n_fired"] for r in rolling_20d)
        weighted_delta = (
            sum(r["delta_pp"] * r["n_fired"] for r in rolling_20d) / total_fires
            if total_fires else float("nan")
        )
        n_positive = sum(1 for r in rolling_20d if r["delta_pp"] > 0)
        print(
            f"Rolling OOS (20d): Δ = {weighted_delta:+.2f}pp weighted-mean, "
            f"{n_positive}/{len(rolling_20d)} periods positive"
        )

    # Recommendation logic
    if test_20d:
        test_delta = test_20d[0]["delta_pp"]
        if test_delta >= 1.0:
            print(
                "\n✓ RECOMMENDATION: Alpha signal validates out-of-sample. "
                "Safe to proceed with UI integration."
            )
        elif test_delta >= 0.5:
            print(
                "\n~ RECOMMENDATION: Alpha signal is weaker out-of-sample but "
                "still positive. UI integration OK; size conservatively; "
                "consider re-validating annually."
            )
        elif test_delta > 0:
            print(
                "\n~ RECOMMENDATION: Alpha signal is materially weaker "
                "out-of-sample. Revisit threshold or drop before UI work."
            )
        else:
            print(
                "\n⚠ RECOMMENDATION: Alpha signal does NOT validate "
                "out-of-sample. DO NOT wire into live trading UI."
            )


if __name__ == "__main__":
    main()
