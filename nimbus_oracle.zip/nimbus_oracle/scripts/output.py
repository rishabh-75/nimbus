"""
scripts/output.py — Auto-export console output to timestamped file.

Usage (one line at top of any script, after sys.path setup):

    from scripts.output import enable_export
    enable_export()  # creates data/reports/run_xxx_20260402_1430.txt

That's it. All print() AND logger.info() calls go to both console AND file.
File path is printed at the end for easy sharing.

Captures both stdout and stderr. Python's logging module sends INFO/WARNING
output to stderr by default, so capturing only stdout would miss every
logger.info() call — which is how some scripts (run_walkforward.py, etc.)
emit their results. We tee both streams and also reach into any existing
logging handlers to rebind them to the tee'd streams.
"""
import atexit, datetime, io, logging, os, sys


class _Tee:
    """Write to both console and file simultaneously."""
    __slots__ = ("_console", "_file")

    def __init__(self, console, filepath, mode="w"):
        self._console = console
        self._file = open(filepath, mode, encoding="utf-8", buffering=1)

    def write(self, text):
        self._console.write(text)
        self._file.write(text)

    def flush(self):
        self._console.flush()
        self._file.flush()

    def close(self):
        self._file.close()

    # Pass through any other attributes to console
    def __getattr__(self, name):
        return getattr(self._console, name)


def enable_export(name: str = None):
    """
    Start capturing all stdout AND stderr to a report file.

    Args:
        name: optional report name. Defaults to calling script's filename.
              e.g. "run_etf_pairs_study" → data/reports/run_etf_pairs_study_20260402_1430.txt
    """
    import inspect

    # Derive name from calling script
    if name is None:
        frame = inspect.stack()[1]
        caller = os.path.basename(frame.filename)
        name = os.path.splitext(caller)[0]

    # Create reports directory
    # Look for data/ relative to nimbus_oracle root
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    reports_dir = os.path.join(root, "data", "reports")
    os.makedirs(reports_dir, exist_ok=True)

    # Timestamped filename
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M")
    filepath = os.path.join(reports_dir, f"{name}_{ts}.txt")

    # Save originals so we can restore at exit
    original_stdout = sys.stdout
    original_stderr = sys.stderr

    # Both tees write to the same file. We use a single shared file handle
    # so stdout and stderr lines interleave correctly in chronological order.
    shared_file = open(filepath, "w", encoding="utf-8", buffering=1)

    class _SharedTee:
        """Tee that uses an externally-managed file handle (shared between
        the stdout-tee and stderr-tee so output stays in chronological order)."""
        __slots__ = ("_console",)

        def __init__(self, console):
            self._console = console

        def write(self, text):
            self._console.write(text)
            shared_file.write(text)

        def flush(self):
            self._console.flush()
            shared_file.flush()

        def __getattr__(self, name):
            return getattr(self._console, name)

    stdout_tee = _SharedTee(original_stdout)
    stderr_tee = _SharedTee(original_stderr)
    sys.stdout = stdout_tee
    sys.stderr = stderr_tee

    # Rebind any existing logging handlers that point at the original
    # stdout/stderr to point at the tees instead. logging.basicConfig() at
    # script-import time captures sys.stderr by reference; if we install
    # the tee after that, the handler still points at the original stderr
    # and bypasses the tee. Rebind to fix this.
    for handler in logging.getLogger().handlers:
        if isinstance(handler, logging.StreamHandler):
            if handler.stream is original_stderr:
                handler.stream = stderr_tee
            elif handler.stream is original_stdout:
                handler.stream = stdout_tee

    # Print footer on exit
    def _footer():
        # Restore originals before printing the final message
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        # Also restore logging handlers
        for handler in logging.getLogger().handlers:
            if isinstance(handler, logging.StreamHandler):
                if handler.stream is stderr_tee:
                    handler.stream = original_stderr
                elif handler.stream is stdout_tee:
                    handler.stream = original_stdout
        try:
            shared_file.write(f"\n[Report saved: {filepath}]\n")
            shared_file.close()
        except Exception:
            pass
        print(f"\n📄 Report saved: {filepath}")

    atexit.register(_footer)
