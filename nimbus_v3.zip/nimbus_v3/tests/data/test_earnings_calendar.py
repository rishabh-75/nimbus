"""Tests for :mod:`nimbus_v3.data.earnings_calendar`."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock

import pandas as pd
import pytest

from nimbus_v3.data.earnings_calendar import (
    DEFAULT_CACHE_TTL,
    DEFAULT_LOOKAHEAD_SESSIONS,
    EarningsCalendar,
    EarningsCaution,
    _is_results_purpose,
    _parse_event_payload,
    _parse_event_date,
    _sessions_between,
)


# ══════════════════════════════════════════════════════════════════════════════
# _sessions_between — pure weekday math
# ══════════════════════════════════════════════════════════════════════════════


class TestSessionsBetween:
    """Walks calendar days forward, counts weekdays only."""

    def test_same_day_is_zero(self):
        d = date(2026, 5, 13)    # Wednesday
        assert _sessions_between(d, d) == 0

    def test_next_weekday_is_one(self):
        wed = date(2026, 5, 13)
        thu = date(2026, 5, 14)
        assert _sessions_between(wed, thu) == 1

    def test_skips_weekend(self):
        """Fri → Mon = 1 session, not 3 — Sat/Sun don't count."""
        fri = date(2026, 5, 15)
        mon = date(2026, 5, 18)
        assert _sessions_between(fri, mon) == 1

    def test_wed_to_mon_via_weekend(self):
        wed = date(2026, 5, 13)
        mon = date(2026, 5, 18)
        # Thu, Fri, Mon → 3 sessions (Sat/Sun skipped)
        assert _sessions_between(wed, mon) == 3

    def test_wed_to_tue_following_week(self):
        wed = date(2026, 5, 13)
        tue = date(2026, 5, 19)
        # Thu, Fri, Mon, Tue → 4 sessions
        assert _sessions_between(wed, tue) == 4

    def test_past_date_returns_negative(self):
        """Past events have negative session counts. Caller treats
        these as 'not a caution' (the check_symbol predicate
        explicitly filters them out)."""
        today = date(2026, 5, 13)
        yesterday = date(2026, 5, 12)
        assert _sessions_between(today, yesterday) < 0


# ══════════════════════════════════════════════════════════════════════════════
# _is_results_purpose — keyword match
# ══════════════════════════════════════════════════════════════════════════════


class TestIsResultsPurpose:
    """Case-insensitive substring match against the results-keyword
    tuple. Matches the real NSE ``purpose`` strings we see in the
    API response."""

    @pytest.mark.parametrize("purpose", [
        "Financial Results",
        "Financial Results/Dividend",
        "Financial Results/Dividend/Other business matters",
        "Financial Results/Fund Raising",
        "Quarterly Result",
        "Audited Financial Statements",
        "Unaudited Financial Results",
        "FINANCIAL RESULTS",     # case insensitive
        "financial results",
    ])
    def test_results_purposes_match(self, purpose):
        assert _is_results_purpose(purpose) is True

    @pytest.mark.parametrize("purpose", [
        "Dividend",
        "Fund Raising",
        "Stock Split",
        "Other business matters",
        "Bonus Issue",
        "Buyback",
        "AGM",
        "EGM",
        "Postal Ballot",
        "",
    ])
    def test_non_results_purposes_dropped(self, purpose):
        assert _is_results_purpose(purpose) is False


# ══════════════════════════════════════════════════════════════════════════════
# _parse_event_date — defensive date parsing
# ══════════════════════════════════════════════════════════════════════════════


class TestParseEventDate:
    def test_canonical_format(self):
        """NSE's standard format: '15-May-2026' → date(2026, 5, 15)."""
        result = _parse_event_date("15-May-2026")
        assert result == date(2026, 5, 15)

    def test_iso_format_fallback(self):
        """pandas fallback handles ISO and other common formats."""
        result = _parse_event_date("2026-05-15")
        assert result == date(2026, 5, 15)

    def test_garbage_returns_none(self):
        assert _parse_event_date("not a date") is None
        assert _parse_event_date("") is None


# ══════════════════════════════════════════════════════════════════════════════
# _parse_event_payload — filters + normalises NSE response rows
# ══════════════════════════════════════════════════════════════════════════════


class TestParseEventPayload:
    """Real-shape input drawn from the NSE event-calendar response."""

    def test_keeps_results_drops_others(self):
        """Mixed payload: results-bearing rows survive, the rest
        are dropped silently. Confirmed against the real NSE
        response shape (`symbol`, `date`, `purpose` fields)."""
        rows = [
            {"symbol": "RELIANCE", "purpose": "Financial Results",
             "date": "28-May-2026"},
            {"symbol": "TCS", "purpose": "Dividend",
             "date": "28-May-2026"},
            {"symbol": "INFY", "purpose": "Quarterly Result",
             "date": "29-May-2026"},
            {"symbol": "ASHOKLEY", "purpose": "Financial Results/Dividend",
             "date": "28-May-2026"},
            {"symbol": "CANBK", "purpose": "Fund Raising",
             "date": "02-Jun-2026"},
        ]
        df = _parse_event_payload(rows)
        assert sorted(df["symbol"].tolist()) == ["ASHOKLEY", "INFY", "RELIANCE"]

    def test_uppercase_symbol_normalisation(self):
        """Symbols are uppercased so lookups are case-insensitive."""
        rows = [{"symbol": "reliance", "purpose": "Financial Results",
                 "date": "28-May-2026"}]
        df = _parse_event_payload(rows)
        assert df.iloc[0]["symbol"] == "RELIANCE"

    def test_event_date_is_date_dtype(self):
        rows = [{"symbol": "X", "purpose": "Financial Results",
                 "date": "28-May-2026"}]
        df = _parse_event_payload(rows)
        # Either python `date` or pandas Timestamp — both acceptable;
        # _rebuild_index normalises further.
        val = df.iloc[0]["event_date"]
        assert val == date(2026, 5, 28) or pd.Timestamp(val).date() == date(2026, 5, 28)

    def test_field_name_variants(self):
        """The parser tolerates alternative field-name spellings
        seen in unofficial NSE wrappers (bm_date vs date, Symbol
        vs symbol)."""
        rows = [
            {"Symbol": "FOO", "Purpose": "Financial Results",
             "bm_date": "15-May-2026"},
        ]
        df = _parse_event_payload(rows)
        assert df.iloc[0]["symbol"] == "FOO"
        assert df.iloc[0]["event_date"] == date(2026, 5, 15)

    def test_malformed_rows_dropped_silently(self):
        rows = [
            {"symbol": "GOOD", "purpose": "Financial Results",
             "date": "28-May-2026"},
            {"symbol": "NO_DATE", "purpose": "Financial Results"},
            {"symbol": "BAD_DATE", "purpose": "Financial Results",
             "date": "not a date"},
            {"purpose": "Financial Results", "date": "28-May-2026"},    # no symbol
            "not a dict at all",                                          # noqa: F841
            {},
        ]
        df = _parse_event_payload(rows)
        assert df["symbol"].tolist() == ["GOOD"]

    def test_empty_input(self):
        df = _parse_event_payload([])
        assert len(df) == 0
        # Schema still complete — downstream callers can rely on cols.
        assert set(df.columns) >= {"symbol", "event_date", "purpose"}


# ══════════════════════════════════════════════════════════════════════════════
# EarningsCalendar — predicate + cache behaviour
# ══════════════════════════════════════════════════════════════════════════════


def _build_calendar(tmp_path: Path, *, ttl: timedelta | None = None) -> EarningsCalendar:
    """Helper: a calendar wired to a per-test cache path with a mock client."""
    client = MagicMock()
    return EarningsCalendar(
        client=client,
        cache_path=tmp_path / "earnings_calendar.parquet",
        cache_ttl=ttl if ttl is not None else DEFAULT_CACHE_TTL,
    )


def _seed_cache(calendar: EarningsCalendar, rows: list[dict]) -> None:
    """Write a known set of rows directly to the calendar's parquet
    cache, bypassing the network. Used in predicate tests."""
    df = pd.DataFrame(rows)
    calendar._cache_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(calendar._cache_path, index=False)


class TestCheckSymbol:
    """The single public predicate. Three outcome modes are tested
    against the 2-session default lookahead window:
      - within window → EarningsCaution
      - outside window → None
      - symbol absent → None
    """

    def test_within_window_returns_caution(self, tmp_path):
        cal = _build_calendar(tmp_path)
        ref = date(2026, 5, 27)    # Wednesday
        _seed_cache(cal, [{
            "symbol": "RELIANCE",
            "event_date": date(2026, 5, 28),    # Thu — 1 session away
            "purpose": "Financial Results",
            "company": "Reliance Industries",
        }])
        result = cal.check_symbol("RELIANCE", today=ref)
        assert isinstance(result, EarningsCaution)
        assert result.symbol == "RELIANCE"
        assert result.sessions_away == 1
        assert result.next_event_date == date(2026, 5, 28)
        assert result.purpose == "Financial Results"

    def test_today_returns_zero_sessions(self, tmp_path):
        cal = _build_calendar(tmp_path)
        ref = date(2026, 5, 28)
        _seed_cache(cal, [{
            "symbol": "INFY",
            "event_date": date(2026, 5, 28),
            "purpose": "Financial Results",
            "company": "Infosys",
        }])
        result = cal.check_symbol("INFY", today=ref)
        assert result is not None
        assert result.sessions_away == 0

    def test_outside_window_returns_none(self, tmp_path):
        """3 sessions away with the default 2-session window → no caution."""
        cal = _build_calendar(tmp_path)
        ref = date(2026, 5, 27)
        _seed_cache(cal, [{
            "symbol": "FAR",
            "event_date": date(2026, 6, 1),    # Monday — 3 sessions
            "purpose": "Financial Results",
            "company": "Far Future Co",
        }])
        assert cal.check_symbol("FAR", today=ref) is None

    def test_custom_window_widens_caution(self, tmp_path):
        """Same symbol/date as above, but sessions=5 catches it."""
        cal = _build_calendar(tmp_path)
        ref = date(2026, 5, 27)
        _seed_cache(cal, [{
            "symbol": "FAR",
            "event_date": date(2026, 6, 1),
            "purpose": "Financial Results",
            "company": "Far Future Co",
        }])
        result = cal.check_symbol("FAR", today=ref, sessions=5)
        assert result is not None
        assert result.sessions_away == 3

    def test_symbol_absent_returns_none(self, tmp_path):
        cal = _build_calendar(tmp_path)
        _seed_cache(cal, [{
            "symbol": "OTHER", "event_date": date(2026, 5, 28),
            "purpose": "Financial Results", "company": "x",
        }])
        assert cal.check_symbol("UNKNOWN", today=date(2026, 5, 27)) is None

    def test_empty_symbol_returns_none(self, tmp_path):
        cal = _build_calendar(tmp_path)
        assert cal.check_symbol("", today=date(2026, 5, 27)) is None
        assert cal.check_symbol("  ", today=date(2026, 5, 27)) is None

    def test_case_insensitive_symbol_match(self, tmp_path):
        """Operator might pass lowercase symbol; the index is
        uppercase. Lookup must canonicalise."""
        cal = _build_calendar(tmp_path)
        _seed_cache(cal, [{
            "symbol": "RELIANCE", "event_date": date(2026, 5, 28),
            "purpose": "Financial Results", "company": "x",
        }])
        result = cal.check_symbol("reliance", today=date(2026, 5, 27))
        assert result is not None
        assert result.symbol == "RELIANCE"

    def test_no_cache_returns_none_silently(self, tmp_path):
        """Predicate against a fresh calendar with no cache and no
        refresh → None (degrade silently, sidebar shows blank)."""
        cal = _build_calendar(tmp_path)
        assert cal.check_symbol("RELIANCE", today=date(2026, 5, 27)) is None

    def test_past_event_treated_as_no_caution(self, tmp_path):
        """Stale cache that has past events shouldn't fire cautions."""
        cal = _build_calendar(tmp_path)
        _seed_cache(cal, [{
            "symbol": "PAST",
            "event_date": date(2026, 5, 1),
            "purpose": "Financial Results",
            "company": "x",
        }])
        assert cal.check_symbol("PAST", today=date(2026, 5, 27)) is None


class TestRefresh:
    """Bulk fetch + cache write path."""

    def test_refresh_writes_parquet(self, tmp_path):
        cal = _build_calendar(tmp_path)
        # Mock the client to return one results row.
        cal._client.fetch = MagicMock(return_value=[
            {"symbol": "ABAN", "purpose": "Financial Results",
             "date": "28-May-2026", "company": "Aban Offshore Limited"},
            {"symbol": "CANBK", "purpose": "Fund Raising",
             "date": "02-Jun-2026", "company": "Canara Bank"},
        ])
        assert cal.refresh(force=True) is True
        assert cal._cache_path.is_file()

        # Index should hold only the results-bearing symbol.
        assert "ABAN" in cal._index
        assert "CANBK" not in cal._index

    def test_refresh_fail_soft_when_fetch_returns_none(self, tmp_path):
        """NSE down / WAF block → fetch returns None → refresh returns
        False, prior cache untouched."""
        cal = _build_calendar(tmp_path)
        # Pre-existing good cache.
        _seed_cache(cal, [{
            "symbol": "OLD", "event_date": date(2026, 5, 28),
            "purpose": "Financial Results", "company": "x",
        }])
        original_mtime = cal._cache_path.stat().st_mtime

        cal._client.fetch = MagicMock(return_value=None)
        assert cal.refresh(force=True) is False
        # Cache file unchanged.
        assert cal._cache_path.stat().st_mtime == original_mtime
        # Index still holds the prior row (now loaded lazily).
        assert cal.check_symbol("OLD", today=date(2026, 5, 27)) is not None

    def test_refresh_passes_correct_url_and_referer(self, tmp_path):
        """The client.fetch call composes the documented endpoint
        and referer — the warm/seed/cookie machinery in NSEClient
        relies on the referer being the right page-URL."""
        cal = _build_calendar(tmp_path)
        cal._client.fetch = MagicMock(return_value=[])
        cal.refresh(force=True)

        cal._client.fetch.assert_called_once()
        args, kwargs = cal._client.fetch.call_args
        assert args[0] == "https://www.nseindia.com/api/event-calendar"
        assert "corporate-filings-event-calendar" in kwargs["referer"]
        assert kwargs["params"]["index"] == "equities"
        # from_date / to_date are formatted DD-MM-YYYY.
        assert len(kwargs["params"]["from_date"].split("-")) == 3

    def test_refresh_respects_ttl_skipping_when_fresh(self, tmp_path):
        """force=False + fresh cache → no fetch fires."""
        cal = _build_calendar(tmp_path, ttl=timedelta(hours=12))
        _seed_cache(cal, [{
            "symbol": "FRESH", "event_date": date(2026, 5, 28),
            "purpose": "Financial Results", "company": "x",
        }])
        cal._client.fetch = MagicMock()
        cal.refresh(force=False)
        cal._client.fetch.assert_not_called()

    def test_refresh_force_bypasses_fresh_cache(self, tmp_path):
        """force=True ignores the TTL and refetches."""
        cal = _build_calendar(tmp_path, ttl=timedelta(hours=12))
        _seed_cache(cal, [{
            "symbol": "FRESH", "event_date": date(2026, 5, 28),
            "purpose": "Financial Results", "company": "x",
        }])
        cal._client.fetch = MagicMock(return_value=[])
        cal.refresh(force=True)
        cal._client.fetch.assert_called_once()


class TestPayloadShapeTolerance:
    """The endpoint occasionally wraps the list in a dict
    (``{"data": [...]}``); the calendar tolerates that."""

    def test_dict_wrapped_payload(self, tmp_path):
        cal = _build_calendar(tmp_path)
        cal._client.fetch = MagicMock(return_value={
            "data": [{"symbol": "WRAP", "purpose": "Financial Results",
                      "date": "28-May-2026"}],
        })
        assert cal.refresh(force=True) is True
        assert "WRAP" in cal._index

    def test_garbage_payload_fails_soft(self, tmp_path):
        cal = _build_calendar(tmp_path)
        cal._client.fetch = MagicMock(return_value=12345)
        # Should not raise.
        assert cal.refresh(force=True) is False


class TestRebuildIndexDedup:
    """Multiple events per symbol — keep chronologically earliest."""

    def test_earliest_event_wins(self, tmp_path):
        """If RELIANCE has two filings (rescheduled meetings, e.g.
        MMTC 28-May AND 29-May seen in real data), the earliest
        wins. The caution fires one session sooner, which is the
        safe direction for an advisory flag."""
        cal = _build_calendar(tmp_path)
        df = pd.DataFrame([
            {"symbol": "MMTC", "event_date": date(2026, 5, 28),
             "purpose": "Financial Results", "company": "MMTC"},
            {"symbol": "MMTC", "event_date": date(2026, 5, 29),
             "purpose": "Financial Results/Other", "company": "MMTC"},
        ])
        cal._rebuild_index(df)
        assert cal._index["MMTC"][0] == date(2026, 5, 28)
