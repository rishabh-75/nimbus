"""nimbus_v3.compute.flow_analytics — stateless compute facade for
commodity macro flow analysis.

This module is the compute-side counterpart to the UI panel in
``nimbus_v3/ui/widgets/macro_flow_panel.py``. Before this turn, the
panel widget contained all the verdict-computation logic inline —
``_compute_verdict``, ``_avg_z``, the threshold constants, and the
``MacroVerdict`` + ``CategoryStats`` dataclasses were all defined
alongside the Qt rendering code.

Extracting those into this module achieves three things:

1. **Test-ability** — compute can now be tested without importing Qt,
   same as ``IndustryAnalyticsEngine`` vs its Market Pulse UI.
2. **Reusability** — research scripts can consume the engine directly
   rather than duplicating the verdict logic.
3. **Isolation** — changes to the UI can't silently affect the
   computed signals, and vice versa.

Shape mirrors ``IndustryAnalyticsEngine``: the class is stateless
between calls, carries tuning constants as instance attributes that
tests can override without monkeypatching module globals, and exposes
a single ``analyze()`` method that returns a frozen result bundle.

The upstream raw signal detector (``detect_flows`` in
``macro/flow_detector.py``) was already stateless and well-placed;
it stays where it is. This module builds ON TOP of that — consumes
``MacroFlowResult`` values, produces ``FlowAnalyticsResult``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd

from nimbus_v3.macro.flow_detector import MacroFlowResult, detect_flows
from nimbus_v3.macro.universe import (
    COMMODITY_UNIVERSE, CommodityCategory, CommodityInstrument,
)


# ══════════════════════════════════════════════════════════════════════════════
# Threshold constants — historically tuned on the 23-instrument universe.
# ══════════════════════════════════════════════════════════════════════════════

#: A commodity is considered "bullish" when its avg-z across the three
#: windows is at or above this threshold. "Bearish" is the negative
#: mirror. 0.5 was picked to line up with the UI table's first colour
#: bucket (|z| ≥ 1 is mid-green, but a 0.5 mean over three windows
#: typically means at least one window is meaningfully hot).
_BULL_Z: Final[float] = 0.5
_BEAR_Z: Final[float] = -0.5

#: Strength bands on the category with the biggest |mean z|. Used to
#: classify the overall regime reading as "strong / moderate / weak".
_STRONG_Z: Final[float] = 1.5
_MODERATE_Z: Final[float] = 0.8

#: ``REBOUND`` tag threshold — ``z_60d`` below this value on a
#: commodity, combined with panel vol regime != "volatile", is the
#: mean-reversion rebound signal. -2 matches the research script's
#: threshold where the edge was measured. See
#: ``MacroFlowResult.is_rebound`` docstring for the full numbers.
_REBOUND_Z_THRESHOLD: Final[float] = -2.0

#: Trading days of panel realized vol to compute for the regime
#: classification. 60d matches the equity-side volatility framework
#: and is a reasonable compromise between "responsive to regime
#: changes" and "not jumpy from a single crisis day."
_VOL_REGIME_WINDOW: Final[int] = 60

#: Lookback (days) for the regime tercile baseline. The vol value at
#: the latest bar is ranked against its last N days of history — if
#: it's in the top third (above 67th percentile), regime is "volatile";
#: bottom third (below 33rd), "calm"; middle, "normal". 2 years of
#: history is long enough to span multiple regime cycles without
#: letting a crisis 5 years ago dominate today's classification.
_VOL_REGIME_HISTORY_DAYS: Final[int] = 500

#: Category display order on the verdict bar. Chosen so the eye reads
#: defensive-to-cyclical and then agri/livestock which are less
#: diagnostic for risk-on/off.
_CAT_ORDER: Final[tuple[CommodityCategory, ...]] = (
    CommodityCategory.PRECIOUS,
    CommodityCategory.INDUSTRIAL,
    CommodityCategory.ENERGY,
    CommodityCategory.AGRICULTURAL,
    CommodityCategory.LIVESTOCK,
)


# ══════════════════════════════════════════════════════════════════════════════
# Result types
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class CategoryStats:
    """Summary stats for one commodity category at an asof date.

    ``mean_z`` is the arithmetic mean of per-instrument avg-z values.
    ``bulls`` / ``bears`` count instruments at or beyond the
    ``_BULL_Z`` / ``_BEAR_Z`` thresholds — tells you whether the
    category's mean is driven by a broad move or a single outlier.
    """
    category: CommodityCategory
    mean_z: float         # mean of per-instrument avg-z (NaN-safe)
    total: int            # instruments scored in this category
    bulls: int            # instruments at avg_z ≥ +_BULL_Z
    bears: int            # instruments at avg_z ≤ -_BULL_Z


@dataclass(frozen=True)
class MacroVerdict:
    """Computed macro regime summary. Safe to render directly.

    ``label`` is one of: RISK-OFF, INFLATIONARY, DEFLATIONARY, RISK-ON,
    GOLDILOCKS, STAGFLATION, COMMODITY DEFLATION, MIXED. ``color``
    is a theme hex string matching the label's semantic (e.g. RED
    for RISK-OFF, GREEN for RISK-ON). ``strength`` communicates
    confidence: strong / moderate / weak · mixed.
    """
    label: str
    color: str                 # hex fg for the label badge
    strength: str              # "strong signal" / "moderate" / "weak · mixed"
    strength_color: str
    reasons: tuple[str, ...]   # 0–3 short phrases
    by_category: tuple[CategoryStats, ...]  # ordered per _CAT_ORDER
    movers_up: tuple[tuple[str, float], ...]    # (ticker, avg_z) top 3 up
    movers_down: tuple[tuple[str, float], ...]
    bulls_count: int
    bears_count: int
    total_count: int


@dataclass(frozen=True)
class FlowAnalyticsResult:
    """Full output of ``FlowAnalyticsEngine.analyze`` — bundles the
    raw per-instrument flow results alongside the derived regime
    verdict. The UI panel consumes this directly; research scripts
    can ignore ``verdict`` and work with ``results`` alone."""
    results: tuple[MacroFlowResult, ...]
    verdict: MacroVerdict
    asof_date: pd.Timestamp
    #: Panel-wide volatility regime label: "calm", "normal",
    #: "volatile", or "unknown" (when insufficient history prevents
    #: tercile classification). Computed from the 60d realized vol of
    #: the universe's equal-weight daily return series, compared
    #: against its 500-day rolling distribution.
    #:
    #: Used as the regime gate for the REBOUND tag — the
    #: mean-reversion signal was validated in calm/normal regimes
    #: only. See ``_REBOUND_Z_THRESHOLD`` and
    #: ``MacroFlowResult.is_rebound`` for the research numbers.
    vol_regime: str = "unknown"


# ══════════════════════════════════════════════════════════════════════════════
# Theme-hex references
# ══════════════════════════════════════════════════════════════════════════════
#
# We import theme colors lazily inside the engine rather than at module
# load — this keeps the module headless (no PyQt6 imports) so it can be
# used from research scripts that don't want the Qt subsystem.

def _colors() -> dict[str, str]:
    """Return the hex-color palette for verdict labels. Imported
    lazily to keep this module free of Qt imports."""
    from nimbus_v3.ui.theme import BLUE, EM, GOLD, GREEN, MUTED, RED
    return {
        "RED": RED, "GREEN": GREEN, "GOLD": GOLD,
        "EM": EM, "BLUE": BLUE, "MUTED": MUTED,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Stateless engine
# ══════════════════════════════════════════════════════════════════════════════

class FlowAnalyticsEngine:
    """Stateless compute engine for commodity macro flow analytics.

    Usage::

        engine = FlowAnalyticsEngine()
        result = engine.analyze(panel={"GC=F": df, "CL=F": df, ...})
        for cat_stats in result.verdict.by_category:
            print(cat_stats.category, cat_stats.mean_z)

    The engine holds no state between calls — two calls with the same
    inputs always produce the same output. Threshold constants are
    bound at construction and can be overridden for testing without
    monkeypatching module globals::

        engine = FlowAnalyticsEngine(
            bull_z=0.3, bear_z=-0.3,    # tighter thresholds
        )
    """

    #: Public class attributes — can be read by consumers that want
    #: to align rendering (e.g. the UI's |z| legend) with the engine's
    #: definitions. These carry the module constants' defaults; if a
    #: caller overrides them at construction, ``self.*`` reflects the
    #: override.
    BULL_Z: float = _BULL_Z
    BEAR_Z: float = _BEAR_Z
    STRONG_Z: float = _STRONG_Z
    MODERATE_Z: float = _MODERATE_Z
    CAT_ORDER: tuple[CommodityCategory, ...] = _CAT_ORDER

    def __init__(
        self,
        *,
        bull_z: float | None = None,
        bear_z: float | None = None,
        strong_z: float | None = None,
        moderate_z: float | None = None,
    ) -> None:
        """Stateless — no mutable state between calls.

        Optional threshold overrides let research scripts and tests
        probe behavior at different cutoffs without monkeypatching
        module globals. Unlike ``StrategyComputeEngine`` and
        ``IndustryAnalyticsEngine``, this engine accepts constructor
        kwargs because its thresholds (``BULL_Z``, ``BEAR_Z`` etc.)
        were identified as research-relevant tuning knobs during the
        commodity flow research — research scripts at ``scripts/``
        construct custom-threshold engines to test sensitivity.

        Each kwarg falls through to the corresponding class attribute
        when ``None``. Instances with all overrides ``None`` behave
        identically to ``FlowAnalyticsEngine()`` with no kwargs.
        """
        # Bind overrides per-instance. Falls through to class defaults.
        if bull_z is not None:
            self.BULL_Z = bull_z
        if bear_z is not None:
            self.BEAR_Z = bear_z
        if strong_z is not None:
            self.STRONG_Z = strong_z
        if moderate_z is not None:
            self.MODERATE_Z = moderate_z

    # ══════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════

    def analyze(
        self,
        panel: dict[str, pd.DataFrame],
        *,
        asof_date: pd.Timestamp | None = None,
        universe: tuple[CommodityInstrument, ...] = COMMODITY_UNIVERSE,
    ) -> FlowAnalyticsResult:
        """Full pipeline: raw flow detection + regime verdict.

        Args:
            panel: dict of ticker → OHLCV DataFrame. Passed through
                to ``detect_flows``. Tickers missing from the panel
                are skipped silently; symbols with insufficient
                history produce NaN z-scores but still appear in
                the result set.
            asof_date: compute as of this bar. ``None`` means the
                most-recent available bar per instrument.
            universe: override the default 23-instrument universe
                (testing).

        Returns:
            Frozen ``FlowAnalyticsResult`` — the full data bundle
            needed to render the commodity tab. UI consumers pass
            this to their render method directly; research scripts
            can read ``result.results`` for the per-instrument
            data and ignore the verdict.
        """
        raw_results = detect_flows(
            panel, asof_date=asof_date, universe=universe,
        )
        # Panel-wide vol regime, computed ONCE from the full panel.
        # All per-instrument tags that need a regime gate read the
        # same value — the regime is a property of the commodity
        # complex as a whole, not of any single instrument.
        vol_regime = self._compute_vol_regime(
            panel, asof_date=asof_date,
        )
        # Enrich: attach is_rebound to each result based on its own
        # z_60d and the panel regime. Uses dataclasses.replace so the
        # frozen dataclass stays frozen — we produce enriched copies,
        # not mutate in place.
        from dataclasses import replace as _dc_replace
        results = tuple(
            _dc_replace(r, is_rebound=self._should_fire_rebound(r, vol_regime))
            for r in raw_results
        )
        verdict = self._compute_verdict(results)
        # The asof on the result bundle is the latest asof across
        # instruments — any given instrument's ``asof_date`` may be
        # earlier due to missing data.
        if results:
            bundle_asof = max(r.asof_date for r in results)
        else:
            bundle_asof = asof_date or pd.Timestamp.now().normalize()
        return FlowAnalyticsResult(
            results=results, verdict=verdict,
            asof_date=bundle_asof, vol_regime=vol_regime,
        )

    def compute_verdict(
        self, results: list[MacroFlowResult] | tuple[MacroFlowResult, ...],
    ) -> MacroVerdict:
        """Public wrapper around the internal verdict computation.

        Exposed so callers that already have ``MacroFlowResult``
        values (e.g. the UI's filter-bar which re-computes verdict
        on the unfiltered results while the table renders a subset)
        can request just the verdict without re-running
        ``detect_flows``. Fully equivalent to the verdict produced
        by ``analyze()``.
        """
        return self._compute_verdict(tuple(results))

    # ══════════════════════════════════════════════════════════════════
    # Internals
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def _avg_z(r: MacroFlowResult) -> float | None:
        """Mean of the three-window z-scores, NaN-aware. Returns
        ``None`` if every window is NaN."""
        zs = [
            z for z in (r.price_z_10d, r.price_z_30d, r.price_z_60d)
            if z == z
        ]
        if not zs:
            return None
        return sum(zs) / len(zs)

    @staticmethod
    def _compute_vol_regime(
        panel: dict[str, pd.DataFrame],
        *, asof_date: pd.Timestamp | None,
    ) -> str:
        """Classify the panel's current volatility regime as
        ``"calm"``, ``"normal"``, ``"volatile"``, or ``"unknown"``.

        Methodology:
        1. Per-instrument daily log returns, aligned on index.
        2. Cross-instrument mean = panel EW daily return.
        3. 60d rolling std of that series = panel realized vol.
        4. Compare the latest vol value against its trailing 500-day
           distribution via terciles: below 33rd %ile → calm; above
           67th %ile → volatile; middle → normal.

        Returns ``"unknown"`` when there's insufficient history to
        classify (fewer than ``_VOL_REGIME_HISTORY_DAYS // 2`` valid
        rolling-vol observations). This is the safe default — callers
        using this for a regime gate (e.g. the REBOUND tag) should
        not fire the gated signal in ``unknown`` either, since we
        can't distinguish calm from volatile.
        """
        if not panel:
            return "unknown"

        # Build a wide frame of daily log returns.
        closes = {}
        for ticker, df in panel.items():
            if "Close" not in df.columns:
                continue
            work = df.copy()
            if work.index.tz is not None:
                work.index = work.index.tz_localize(None)
            work = work.sort_index()
            if asof_date is not None:
                asof = pd.Timestamp(asof_date).normalize()
                work = work[work.index <= asof]
            if work.empty:
                continue
            closes[ticker] = work["Close"].astype(float)

        if not closes:
            return "unknown"

        # Align on common index (outer join — empty cells become NaN)
        wide = pd.DataFrame(closes)
        # Daily log returns per instrument
        with np.errstate(invalid="ignore", divide="ignore"):
            log_rets = np.log(wide / wide.shift(1))
        # Cross-instrument mean (EW panel return) — skip NaN per bar
        ew_ret = log_rets.mean(axis=1, skipna=True)
        # 60d rolling std of the EW return series
        vol = ew_ret.rolling(_VOL_REGIME_WINDOW).std()
        vol = vol.dropna()
        if len(vol) < _VOL_REGIME_HISTORY_DAYS // 2:
            return "unknown"

        # Tercile the trailing 500 days (or all we have if less)
        history = vol.iloc[-_VOL_REGIME_HISTORY_DAYS:]
        latest = float(vol.iloc[-1])
        q33 = float(history.quantile(0.33))
        q67 = float(history.quantile(0.67))
        if not (np.isfinite(q33) and np.isfinite(q67) and np.isfinite(latest)):
            return "unknown"

        if latest < q33:
            return "calm"
        if latest > q67:
            return "volatile"
        return "normal"

    @staticmethod
    def _should_fire_rebound(
        r: MacroFlowResult, vol_regime: str,
    ) -> bool:
        """Apply the REBOUND tag formula: ``z_60d < -2`` AND the
        panel vol regime is not volatile.

        NaN-safe — returns False if z_60d isn't finite, preserving
        the invariant that the tag never fires on insufficient-history
        instruments (which default is_rebound to False anyway).
        """
        if r.price_z_60d != r.price_z_60d:    # NaN
            return False
        if r.price_z_60d >= _REBOUND_Z_THRESHOLD:
            return False
        # Only fire in calm or normal regimes — research showed the
        # signal flips sign in volatile regimes. Unknown regime: also
        # don't fire, because we can't tell whether we're in a regime
        # where the signal works or one where it's opposite.
        return vol_regime in ("calm", "normal")

    def _compute_verdict(
        self, results: tuple[MacroFlowResult, ...],
    ) -> MacroVerdict:
        """Derive the macro regime label + per-category stats.

        The rules are intentionally transparent and rank-ordered so
        a reader can see why a given regime fired:

        **Extreme / 3-category patterns** (high-conviction regimes
        where the entire commodity complex aligns):

        1. **RISK-OFF**     — precious ≥ +0.5 AND energy ≤ -0.5.
        2. **INFLATIONARY** — energy, industrial, precious all ≥ +0.5.
        3. **DEFLATIONARY** — precious, industrial, energy all ≤ -0.5.

        **2-category divergence patterns** (common mid-regime setups):

        4. **RISK-ON**      — industrial ≥ +0.5 AND energy ≥ +0.5 AND
           precious < +0.3. Cyclicals leading without haven bid.
        5. **GOLDILOCKS**   — industrial ≥ +0.5 AND energy ≤ -0.3 AND
           precious ≤ +0.3. Growth without inflation pressure.
        6. **STAGFLATION**  — energy ≥ +0.5 AND industrial ≤ -0.3.
           Cost-push without growth.
        7. **COMMODITY DEFLATION** — energy ≤ -0.5 AND industrial ≤ -0.5
           AND precious > -0.3. Demand destruction without panic.

        **Fallback**: MIXED when no diagnostic pattern fires.

        Signal strength: max |mean_z| across any category, mapped to
        strong / moderate / weak per ``STRONG_Z`` / ``MODERATE_Z``.
        """
        pal = _colors()
        scored: list[tuple[MacroFlowResult, float]] = []
        for r in results:
            mz = self._avg_z(r)
            if mz is None:
                continue
            scored.append((r, mz))

        # Aggregate by category.
        by_cat: dict[CommodityCategory, list[float]] = {}
        for r, mz in scored:
            by_cat.setdefault(r.category, []).append(mz)

        cat_stats: list[CategoryStats] = []
        for cat in self.CAT_ORDER:
            vals = by_cat.get(cat, [])
            total = len(vals)
            if total == 0:
                cat_stats.append(CategoryStats(
                    category=cat, mean_z=float("nan"),
                    total=0, bulls=0, bears=0,
                ))
                continue
            cat_stats.append(CategoryStats(
                category=cat,
                mean_z=sum(vals) / total,
                total=total,
                bulls=sum(1 for z in vals if z >= self.BULL_Z),
                bears=sum(1 for z in vals if z <= self.BEAR_Z),
            ))

        cat_mean = {cs.category: cs.mean_z for cs in cat_stats if cs.total > 0}
        energy = cat_mean.get(CommodityCategory.ENERGY, 0.0)
        precious = cat_mean.get(CommodityCategory.PRECIOUS, 0.0)
        industrial = cat_mean.get(CommodityCategory.INDUSTRIAL, 0.0)

        reasons: list[str] = []

        # ── Tier 1: extreme 3-category patterns ──────────────────────
        if precious >= self.BULL_Z and energy <= self.BEAR_Z:
            label, color = "RISK-OFF", pal["RED"]
            reasons.append("Precious metals bid")
            reasons.append("Energy complex dumping")
            if industrial <= -0.3:
                reasons.append("Industrial metals soft")
        elif (energy >= self.BULL_Z and industrial >= self.BULL_Z
              and precious >= self.BULL_Z):
            label, color = "INFLATIONARY", pal["GOLD"]
            reasons.append("Commodities hot across board")
            if energy >= 1.0:
                reasons.append(f"Energy {energy:+.1f}z")
        elif (precious <= self.BEAR_Z and industrial <= self.BEAR_Z
              and energy <= self.BEAR_Z):
            label, color = "DEFLATIONARY", pal["RED"]
            reasons.append("Broad-based selling")

        # ── Tier 2: 2-category divergence patterns ───────────────────
        elif (industrial >= self.BULL_Z and energy >= self.BULL_Z
              and precious < 0.3):
            label, color = "RISK-ON", pal["GREEN"]
            reasons.append("Cyclicals rallying")
            if precious < -0.3:
                reasons.append("Haven demand light")
        elif (industrial >= self.BULL_Z and energy <= -0.3
              and precious <= 0.3):
            # Growth without inflation: industrial demand rising,
            # energy weak (lower input costs), havens quiet.
            label, color = "GOLDILOCKS", pal["EM"]
            reasons.append("Industrial demand rising")
            reasons.append(f"Energy soft ({energy:+.1f}z)")
            if precious <= -0.3:
                reasons.append("Havens quiet — no inflation fear")
        elif energy >= self.BULL_Z and industrial <= -0.3:
            # Cost-push without growth.
            label, color = "STAGFLATION", pal["GOLD"]
            reasons.append(f"Energy bid ({energy:+.1f}z)")
            reasons.append("Industrial metals soft — growth fading")
            if precious >= 0.3:
                reasons.append("Gold catching bid")
        elif (energy <= self.BEAR_Z and industrial <= self.BEAR_Z
              and precious > -0.3):
            # Demand destruction without haven panic.
            label, color = "COMMODITY DEFLATION", pal["BLUE"]
            reasons.append("Energy + industrial both dumping")
            reasons.append("Gold not bid — no panic")

        # ── Tier 3: fallback ─────────────────────────────────────────
        else:
            label, color = "MIXED", pal["MUTED"]
            strongest = max(
                cat_mean.items(),
                key=lambda kv: abs(kv[1]),
                default=(None, 0.0),
            )
            if strongest[0] is not None and abs(strongest[1]) >= 0.5:
                direction = "hot" if strongest[1] > 0 else "soft"
                reasons.append(
                    f"{strongest[0].value.lower()} {direction} "
                    f"({strongest[1]:+.1f}z)"
                )
            else:
                reasons.append("No clear regime")

        # Strength — biggest absolute category mean.
        max_abs = max(
            (abs(v) for v in cat_mean.values()), default=0.0,
        )
        if max_abs >= self.STRONG_Z:
            strength, strength_color = "strong signal", color
        elif max_abs >= self.MODERATE_Z:
            strength, strength_color = "moderate", pal["GOLD"]
        else:
            strength, strength_color = "weak · mixed", pal["MUTED"]

        # Movers — sorted by avg-z, top 3 up, bottom 3 down.
        scored.sort(key=lambda t: t[1], reverse=True)
        movers_up = tuple(
            (r.instrument.ticker, mz) for r, mz in scored[:3] if mz > 0
        )
        movers_down = tuple(
            (r.instrument.ticker, mz) for r, mz in scored[::-1][:3] if mz < 0
        )

        bulls = sum(1 for _, mz in scored if mz >= self.BULL_Z)
        bears = sum(1 for _, mz in scored if mz <= self.BEAR_Z)

        return MacroVerdict(
            label=label,
            color=color,
            strength=strength,
            strength_color=strength_color,
            reasons=tuple(reasons[:3]),
            by_category=tuple(cat_stats),
            movers_up=movers_up,
            movers_down=movers_down,
            bulls_count=bulls,
            bears_count=bears,
            total_count=len(scored),
        )
