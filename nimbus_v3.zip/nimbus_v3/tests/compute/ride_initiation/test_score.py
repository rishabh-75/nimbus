"""Tests for nimbus_v3.compute.ride_initiation.score — composite
score penalties.

The five conviction components have implicit coverage via the
broader engine tests; this file pins down the two new
**tradeability** discount factors that multiplicatively dock the
final score:

  - ``_extension_penalty`` — %B-based, dampens over-extended fires.
  - ``_liquidity_penalty`` — ADTV-based, dampens illiquid symbols.

Both are purely numerical so the tests can hand-build minimal
dataframes targeting specific %B / ADTV regimes without going
through the full enrichment pipeline. The minimum required
columns vary per function and are documented in each test class.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.ride_initiation.constants import (
    SCORE_EXTENSION_PCTB_MAX,
    SCORE_EXTENSION_PCTB_MIN,
    SCORE_EXTENSION_PENALTY_FLOOR,
    SCORE_LIQUIDITY_ADTV_FULL,
    SCORE_LIQUIDITY_ADTV_MID,
    SCORE_LIQUIDITY_ADTV_SMALL,
    SCORE_LIQUIDITY_PENALTY_FLOOR,
)
from nimbus_v3.compute.ride_initiation.score import (
    _extension_penalty,
    _liquidity_penalty,
    compute_composite_score,
)


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════


def _df_with_pct_b(pct_b_values: list[float]) -> pd.DataFrame:
    """Build the minimum dataframe ``_extension_penalty`` reads.

    ``pct_b_close`` requires ``Close``, ``bb_20_1s_lower`` and
    ``bb_20_1s_upper``. We fix the band at [100, 120] (20-wide)
    and set Close so that %B = (Close - 100) / 20 lands on the
    requested values.
    """
    n = len(pct_b_values)
    closes = [100.0 + 20.0 * pb for pb in pct_b_values]
    return pd.DataFrame(
        {
            "Close":            closes,
            "bb_20_1s_lower":   [100.0] * n,
            "bb_20_1s_upper":   [120.0] * n,
        },
        index=pd.bdate_range("2024-01-01", periods=n),
    )


def _df_with_adtv(adtv_values: list[float]) -> pd.DataFrame:
    """Build the minimum dataframe ``_liquidity_penalty`` reads.

    Computes ADTV as 20-bar mean of ``Close × Volume``. We feed
    a series long enough to satisfy the rolling window and fix
    the per-bar ADTV exactly.
    """
    rows = []
    for target_adtv in adtv_values:
        # 20 bars of identical ADTV at this level. Use Close=100,
        # Volume=target/100 so each bar is target_adtv exactly.
        rows.extend([(100.0, target_adtv / 100.0)] * 20)
    df = pd.DataFrame(
        rows, columns=["Close", "Volume"],
        index=pd.bdate_range("2024-01-01", periods=len(rows)),
    )
    return df


# ══════════════════════════════════════════════════════════════════════════════
# Extension penalty
# ══════════════════════════════════════════════════════════════════════════════


class TestExtensionPenalty:
    def test_below_min_threshold_no_penalty(self):
        """%B values below ``SCORE_EXTENSION_PCTB_MIN`` (1.4)
        receive penalty 1.0 — comfortably-inside-band bars are
        not docked at all."""
        df = _df_with_pct_b([0.5, 1.0, 1.2, 1.39])
        pen = _extension_penalty(df)
        for v in pen:
            assert v == pytest.approx(1.0)

    def test_at_min_threshold_no_penalty(self):
        """Exactly at the threshold we're still at full strength —
        the penalty starts ramping *above* it."""
        df = _df_with_pct_b([SCORE_EXTENSION_PCTB_MIN])
        assert _extension_penalty(df).iloc[0] == pytest.approx(1.0)

    def test_at_max_threshold_floor_penalty(self):
        """At ``SCORE_EXTENSION_PCTB_MAX`` (1.7) the penalty has
        hit its floor (0.55)."""
        df = _df_with_pct_b([SCORE_EXTENSION_PCTB_MAX])
        assert _extension_penalty(df).iloc[0] == pytest.approx(
            SCORE_EXTENSION_PENALTY_FLOOR,
        )

    def test_above_max_clipped_to_floor(self):
        """%B values above ``SCORE_EXTENSION_PCTB_MAX`` are clipped
        to the floor — bars in the strategy's "extended" envelope
        don't get penalised more than the cap."""
        df = _df_with_pct_b([1.8, 2.0, 3.0])
        pen = _extension_penalty(df)
        for v in pen:
            assert v == pytest.approx(SCORE_EXTENSION_PENALTY_FLOOR)

    def test_midpoint_linear_interpolation(self):
        """%B exactly halfway between 1.4 and 1.7 (= 1.55) gives
        penalty exactly halfway between 1.0 and the floor (=
        0.775)."""
        midpoint = (SCORE_EXTENSION_PCTB_MIN + SCORE_EXTENSION_PCTB_MAX) / 2
        df = _df_with_pct_b([midpoint])
        expected = (1.0 + SCORE_EXTENSION_PENALTY_FLOOR) / 2
        assert _extension_penalty(df).iloc[0] == pytest.approx(expected)

    def test_monotonic_decreasing(self):
        """Penalty must be monotonically non-increasing as %B
        rises across the active window."""
        df = _df_with_pct_b([1.40, 1.45, 1.50, 1.55, 1.60, 1.65, 1.70])
        pen = _extension_penalty(df).tolist()
        for a, b in zip(pen, pen[1:]):
            assert a >= b

    def test_nan_pct_b_yields_one(self):
        """NaN %B (warm-up period before bands form) → penalty 1.0
        so the warmup bars don't get docked into negative territory."""
        df = _df_with_pct_b([1.5])
        df.loc[df.index[0], "Close"] = np.nan
        # Reset bands to NaN to ensure %B is NaN
        df.loc[df.index[0], "bb_20_1s_lower"] = np.nan
        df.loc[df.index[0], "bb_20_1s_upper"] = np.nan
        pen = _extension_penalty(df)
        assert pen.iloc[0] == pytest.approx(1.0)


# ══════════════════════════════════════════════════════════════════════════════
# Liquidity penalty
# ══════════════════════════════════════════════════════════════════════════════


class TestLiquidityPenalty:
    def test_mega_cap_no_penalty(self):
        """ADTV ≥ ``SCORE_LIQUIDITY_ADTV_FULL`` (₹1B) → 1.0."""
        df = _df_with_adtv([SCORE_LIQUIDITY_ADTV_FULL])
        # Take the last bar — the rolling 20-bar mean of ADTV is
        # well-formed by then.
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(1.0)

    def test_above_mega_cap_no_penalty(self):
        """₹10B (well above the ₹1B threshold) is still 1.0."""
        df = _df_with_adtv([10_000_000_000.0])
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(1.0)

    def test_at_mid_threshold_yields_0_85(self):
        """At ``SCORE_LIQUIDITY_ADTV_MID`` (₹250M) the penalty is
        exactly the upper-mid floor (0.85)."""
        df = _df_with_adtv([SCORE_LIQUIDITY_ADTV_MID])
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(0.85)

    def test_at_small_threshold_yields_floor(self):
        """At ``SCORE_LIQUIDITY_ADTV_SMALL`` (₹50M) the penalty has
        hit ``SCORE_LIQUIDITY_PENALTY_FLOOR`` (0.6)."""
        df = _df_with_adtv([SCORE_LIQUIDITY_ADTV_SMALL])
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(
            SCORE_LIQUIDITY_PENALTY_FLOOR,
        )

    def test_below_small_threshold_clipped_to_floor(self):
        """Micro-cap (< ₹50M ADTV) clipped at the floor."""
        df = _df_with_adtv([10_000_000.0])    # ₹10M
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(
            SCORE_LIQUIDITY_PENALTY_FLOOR,
        )

    def test_mid_band_linear_interpolation(self):
        """ADTV exactly halfway between ₹250M and ₹1B (= ₹625M)
        gives penalty exactly halfway between 0.85 and 1.0 (=
        0.925)."""
        midpoint = (
            SCORE_LIQUIDITY_ADTV_MID + SCORE_LIQUIDITY_ADTV_FULL
        ) / 2
        df = _df_with_adtv([midpoint])
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(0.925)

    def test_small_band_linear_interpolation(self):
        """ADTV exactly halfway between ₹50M and ₹250M (= ₹150M)
        gives penalty exactly halfway between floor (0.6) and
        0.85 (= 0.725)."""
        midpoint = (
            SCORE_LIQUIDITY_ADTV_SMALL + SCORE_LIQUIDITY_ADTV_MID
        ) / 2
        df = _df_with_adtv([midpoint])
        assert _liquidity_penalty(df).iloc[-1] == pytest.approx(0.725)

    def test_monotonic_increasing_with_adtv(self):
        """Penalty must be monotonically non-decreasing as ADTV
        rises across the active region."""
        adtv_values = [
            10_000_000.0,    # below floor
            50_000_000.0,    # small threshold
            150_000_000.0,   # small-band midpoint
            250_000_000.0,   # mid threshold
            625_000_000.0,   # mid-band midpoint
            1_000_000_000.0, # full threshold
            10_000_000_000.0,    # above full
        ]
        # One bar each — pull from the last position of each
        # 20-bar block.
        results = []
        for v in adtv_values:
            df = _df_with_adtv([v])
            results.append(_liquidity_penalty(df).iloc[-1])
        for a, b in zip(results, results[1:]):
            assert a <= b

    def test_no_volume_column_yields_one(self):
        """Defensive — for symbols without Volume (e.g. indices),
        no liquidity penalty applies (factor 1.0)."""
        df = pd.DataFrame(
            {"Close": [100.0] * 30},
            index=pd.bdate_range("2024-01-01", periods=30),
        )
        pen = _liquidity_penalty(df)
        for v in pen:
            assert v == pytest.approx(1.0)


# ══════════════════════════════════════════════════════════════════════════════
# Combined effect on compute_composite_score
# ══════════════════════════════════════════════════════════════════════════════


class TestPenaltiesAppliedToCompositeScore:
    """End-to-end: do the penalties show up in the final score?

    These tests build a minimal enriched dataframe through the
    real enrichment pipeline so all upstream score components
    are populated, then confirm the final ``score`` reflects the
    expected discount when %B is extended or ADTV is small.
    """

    @staticmethod
    def _build_enriched(
        n: int = 250, *, volume: float = 5_000_000.0,
    ) -> pd.DataFrame:
        from nimbus_v3.compute.engine import StrategyComputeEngine
        rng = np.random.default_rng(0)
        # Build a clean uptrend: 230 bars of mild walk + 20 bars
        # of steady up. Last bar will fire if criteria align.
        prices = []
        v = 100.0
        for _ in range(230):
            v *= (1 + rng.normal(0, 0.005))
            prices.append(v)
        for _ in range(20):
            v *= 1.012
            prices.append(v)
        prices = np.array(prices)
        df = pd.DataFrame(
            {
                "Open":   prices * 0.999,
                "High":   prices * 1.008,
                "Low":    prices * 0.992,
                "Close":  prices,
                "Volume": [volume] * len(prices),
            },
            index=pd.bdate_range("2024-01-01", periods=n),
        )
        return StrategyComputeEngine().enrich(df, "X")

    def test_micro_cap_score_lower_than_mega_cap(self):
        """Same enriched series differing only in Volume — micro
        produces a lower composite score because the liquidity
        penalty kicks in."""
        # ADTV depends on Volume × Close; with Close near 100, set
        # Volumes that produce ADTV in the right tiers.
        e_micro = self._build_enriched(volume=200_000.0)        # ~₹20M ADTV
        e_mega  = self._build_enriched(volume=20_000_000.0)     # ~₹2B  ADTV

        # Force fire on the last bar so the score is computed
        # rather than masked. Doesn't matter what raw conviction
        # came out — what matters is the *ratio*.
        fire = pd.Series([False] * (len(e_micro) - 1) + [True], index=e_micro.index)
        s_micro = compute_composite_score(e_micro, fire).iloc[-1]
        s_mega  = compute_composite_score(e_mega,  fire).iloc[-1]
        assert s_micro < s_mega
        # Specifically — mega keeps liq=1.0, micro drops to 0.6,
        # so the ratio should be near 0.6 (other components are
        # identical because the price series is identical).
        assert s_micro / s_mega == pytest.approx(0.6, abs=0.01)

    def test_extended_pctb_score_lower_than_inside_band(self):
        """Two contrived snapshots: one with %B 1.10 (in-band), one
        with %B 1.60 (extended). Same conviction inputs → final
        score is lower for the extended bar."""
        # We build via direct dataframes since we want exact %B
        # control and don't need real enrichment.
        from nimbus_v3.compute.ride_initiation.score import (
            _extension_penalty, _liquidity_penalty,
        )
        df_in   = _df_with_pct_b([1.10])
        df_ext  = _df_with_pct_b([1.60])

        ext_in   = _extension_penalty(df_in).iloc[0]
        ext_out  = _extension_penalty(df_ext).iloc[0]
        assert ext_in == pytest.approx(1.0)
        # Linear ramp from 1.4 to 1.7 → at 1.6 we're 2/3 of the
        # way to floor. (1 − 2/3 × (1 − 0.55)) = 0.7.
        assert ext_out == pytest.approx(0.7, abs=0.01)
