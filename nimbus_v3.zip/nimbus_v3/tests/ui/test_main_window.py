"""tests.ui.test_main_window — smoke tests for MainWindow.

The slim profile doesn't mock the data layer — it constructs
MainWindow with a stub ``panel_loader`` that returns whatever the
test wants, then exercises the public surface (auto_load_initial,
sidebar-driven loads, the lazy-panel path).
"""
from __future__ import annotations

from typing import Callable

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.ui.main_window import MainWindow


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════


def _enriched(n: int = 250, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    close = 100 + np.cumsum(rng.normal(0.05, 1.0, n))
    df = pd.DataFrame(
        {
            "Open":   close * 0.998,
            "High":   close * 1.005,
            "Low":    close * 0.995,
            "Close":  close,
            "Volume": rng.integers(1_000_000, 5_000_000, n).astype(float),
        },
        index=pd.bdate_range("2024-01-01", periods=n),
    )
    return StrategyComputeEngine().enrich(df, "TEST")


def _stub_universe(*symbols: str) -> Universe:
    return Universe(
        symbols={s: SymbolMeta(symbol=s) for s in symbols},
        built_at=pd.Timestamp.now("UTC"),
    )


def _stub_loader(panel: dict, universe: Universe | None) -> Callable:
    def _load():
        return panel, universe
    return _load


# ══════════════════════════════════════════════════════════════════════════════
# Construction
# ══════════════════════════════════════════════════════════════════════════════


def test_main_window_has_dashboard_market_pulse_watchlist_tabs(qapp):    # noqa: ARG001
    """MainWindow embeds a QTabWidget with three tabs: Dashboard,
    Market Pulse (breadth vs CNX500), and Watchlist (persisted symbols).
    The old per-symbol Market Context tab remains deleted."""
    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=lambda: ({}, None),
        data_manager=None,
    )
    assert hasattr(w, "_tabs")
    assert hasattr(w, "_dashboard_tab")
    assert hasattr(w, "_market_pulse_tab")
    assert hasattr(w, "_watchlist_tab")
    assert hasattr(w, "_rotation_tab")
    assert not hasattr(w, "_market_context_tab")
    tab_titles = [w._tabs.tabText(i) for i in range(w._tabs.count())]
    assert tab_titles == ["Dashboard", "Market Pulse", "Watchlist"]
    # Market Pulse is now a sub-tab container: Breadth · ROC · RRG ·
    # Seasonality.
    sub = w._rotation_tab._subtabs
    subtitles = [sub.tabText(i) for i in range(sub.count())]
    assert subtitles == ["Breadth", "ROC", "RRG", "Seasonality"]
    w.close()


def test_main_window_initial_status_message(qapp):    # noqa: ARG001
    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=lambda: ({}, None),
        data_manager=None,
    )
    assert "sidebar" in w._status.currentMessage().lower()
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Lazy panel
# ══════════════════════════════════════════════════════════════════════════════


def test_panel_loader_called_on_first_ensure(qapp):    # noqa: ARG001
    """``_ensure_panel`` is idempotent — first call hits the loader,
    subsequent calls don't."""
    calls = []

    def loader():
        calls.append(1)
        return {"X": _enriched()}, _stub_universe("X")

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=loader,
        data_manager=None,
    )
    assert calls == []    # nothing called at construction time
    w._ensure_panel()
    assert calls == [1]
    w._ensure_panel()
    assert calls == [1]    # still 1 — idempotent
    w.close()


def test_panel_loader_failure_does_not_retry(qapp):    # noqa: ARG001
    """A failing loader is logged + swallowed; we don't retry on
    every click."""
    calls = []

    def loader():
        calls.append(1)
        raise RuntimeError("yfinance down")

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=loader,
        data_manager=None,
    )
    w._ensure_panel()
    w._ensure_panel()
    assert calls == [1]
    assert w._panel == {}
    assert w._universe is None
    w.close()


def test_universe_pushed_to_sidebar_after_load(qapp):    # noqa: ARG001
    universe = _stub_universe("ALPHA", "BETA", "GAMMA")

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({}, universe),
        data_manager=None,
    )
    w._ensure_panel()
    items = {
        w._sidebar._symbol_combo.itemText(i)
        for i in range(w._sidebar._symbol_combo.count())
    }
    assert {"ALPHA", "BETA", "GAMMA"}.issubset(items)
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Sync render path (no DataManager → falls through to panel cache)
# ══════════════════════════════════════════════════════════════════════════════


def test_sync_render_from_panel_populates_dashboard(qapp):    # noqa: ARG001
    enriched = _enriched()
    panel = {"RELIANCE": enriched}
    universe = _stub_universe("RELIANCE")

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader(panel, universe),
        data_manager=None,
        industry_map={"RELIANCE": "Refineries & Marketing"},
    )
    # auto_load_initial is the real public entrypoint MainWindow uses
    # at startup. It synchronises the sidebar selection then schedules
    # the load. We call it directly + drain the timer manually because
    # the test event loop isn't spinning.
    w.auto_load_initial("RELIANCE")
    w._load_symbol("RELIANCE")    # equivalent to the QTimer firing

    assert w._dashboard_tab.symbol == "RELIANCE"
    assert w._sidebar.current_symbol() == "RELIANCE"
    assert w._dashboard_tab._h_symbol_lbl.text() == "RELIANCE"
    w.close()


def test_sync_render_handles_missing_symbol(qapp):    # noqa: ARG001
    """Symbol not in panel + no DataManager → status message + empty
    dashboard, no exception."""
    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({}, _stub_universe()),
        data_manager=None,
    )
    w._load_symbol("UNKNOWN_TICKER")
    assert w._dashboard_tab.symbol == ""
    assert "not in" in w._status.currentMessage().lower()
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Sidebar wiring
# ══════════════════════════════════════════════════════════════════════════════


def test_sidebar_symbol_changed_triggers_load(qapp):    # noqa: ARG001
    enriched = _enriched()
    panel = {"INFY": enriched}

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader(panel, _stub_universe("INFY")),
        data_manager=None,
    )
    # Drive the public signal pathway, not the private slot.
    w._sidebar.symbol_changed.emit("INFY")
    assert w._dashboard_tab.symbol == "INFY"
    w.close()


def test_sidebar_refresh_reloads_current_symbol(qapp):    # noqa: ARG001
    enriched = _enriched()
    panel = {"TCS": enriched}

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader(panel, _stub_universe("TCS")),
        data_manager=None,
        industry_map={"TCS": "Software"},
    )
    # Drive load via the public auto-load entrypoint.
    w.auto_load_initial("TCS")
    w._load_symbol("TCS")
    assert w._dashboard_tab.symbol == "TCS"

    # Clear dashboard, then trigger refresh — should re-populate.
    w._dashboard_tab.clear()
    assert w._dashboard_tab.symbol == ""
    w._sidebar.refresh_clicked.emit()
    assert w._dashboard_tab.symbol == "TCS"
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Helper utilities
# ══════════════════════════════════════════════════════════════════════════════


def test_is_index_symbol_recognises_canonical_indices(qapp):    # noqa: ARG001
    assert MainWindow._is_index_symbol("NIFTY")
    assert MainWindow._is_index_symbol("BANKNIFTY")
    assert MainWindow._is_index_symbol("FINNIFTY")
    assert not MainWindow._is_index_symbol("RELIANCE")


def test_is_already_enriched_distinguishes(qapp):    # noqa: ARG001
    raw = pd.DataFrame(
        {"Open": [1.0], "High": [1.0], "Low": [1.0], "Close": [1.0],
         "Volume": [1.0]},
        index=pd.bdate_range("2024-01-01", periods=1),
    )
    assert not MainWindow._is_already_enriched(raw)

    enriched = _enriched(n=205)
    assert MainWindow._is_already_enriched(enriched)


# ══════════════════════════════════════════════════════════════════════════════
# Lazy options builder
# ══════════════════════════════════════════════════════════════════════════════


def test_options_builder_only_called_once(qapp):    # noqa: ARG001
    builder_calls = []

    def builder():
        builder_calls.append(1)
        return None    # builder may legitimately return None on failure

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=lambda: ({}, None),
        data_manager=None,
        options_builder=builder,
    )
    assert builder_calls == []    # nothing called at construction
    w._ensure_options_provider()
    w._ensure_options_provider()
    assert builder_calls == [1]    # idempotent — built once, even on None return
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Partial-state rendering (price-empty + options-OK regression)
# ══════════════════════════════════════════════════════════════════════════════


def test_render_current_with_no_enriched_still_shows_symbol(qapp):    # noqa: ARG001
    """Regression for the NIFTY 404 case: when the price feed returns
    empty but options came through (or industry context is available),
    the dashboard must still render the symbol header rather than
    clearing to em-dashes."""
    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({}, _stub_universe()),
        data_manager=None,
        industry_map={"FOO": "TestIndustry"},
    )
    # Simulate the failed-price path: current_symbol set, no enriched.
    w._current_symbol = "FOO"
    w._current_enriched = None
    w._current_options = None
    w._render_current()

    # Dashboard tab keeps the symbol on the header strip even
    # without price data.
    assert w._dashboard_tab.symbol == "FOO"
    assert w._dashboard_tab._h_symbol_lbl.text() == "FOO"
    # Status surfaces the partial-render condition.
    assert "no price data" in w._status.currentMessage().lower()
    w.close()


def test_load_symbol_clears_stale_enriched(qapp):    # noqa: ARG001
    """Switching from a working symbol to a failing one must not
    leave the previous symbol's enriched frame visible."""
    enriched_a = _enriched()

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({"A": enriched_a}, _stub_universe("A", "B")),
        data_manager=None,
        industry_map={"A": "I", "B": "I"},
    )
    # Load A successfully (sync path via panel cache).
    w._load_symbol("A")
    assert w._current_enriched is not None
    assert w._dashboard_tab.symbol == "A"

    # Switch to B — not in panel. Should reset enriched, leaving
    # neither A's data nor B's (which doesn't exist).
    w._load_symbol("B")
    assert w._current_enriched is None
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Constituents double-click wiring (now an internal Dashboard signal)
# ══════════════════════════════════════════════════════════════════════════════


def test_constituents_double_click_loads_symbol(qapp):    # noqa: ARG001
    """Double-click on a Constituents row inside the Dashboard's
    bottom strip → symbol loads on the chart, sidebar combo
    follows. Regression for the unwired signal pathway."""
    enriched = _enriched()
    panel = {"INFY": enriched}

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader(panel, _stub_universe("INFY")),
        data_manager=None,
        industry_map={"INFY": "Software"},
    )
    # Emit the signal as the Constituents table would on double-click.
    # The Dashboard bubbles its constituents-table activation up as
    # its own ``symbol_activated`` signal, which MainWindow connects
    # to the load pathway.
    w._dashboard_tab.symbol_activated.emit("INFY")

    assert w._dashboard_tab.symbol == "INFY"
    assert w._sidebar.current_symbol() == "INFY"
    w.close()


def test_constituents_double_click_ignores_empty_symbol(qapp):    # noqa: ARG001
    """Defensive: an empty / whitespace symbol should not cause a load."""
    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({}, _stub_universe()),
        data_manager=None,
    )
    w._dashboard_tab.symbol_activated.emit("")
    assert w._dashboard_tab.symbol == ""
    w.close()


# ══════════════════════════════════════════════════════════════════════════════
# Partial-state rendering (price-empty + options-OK regression)
# ══════════════════════════════════════════════════════════════════════════════


def test_render_current_with_no_enriched_still_shows_symbol(qapp):    # noqa: ARG001
    """Regression for the NIFTY 404 case: when the price feed returns
    empty but options came through (or industry context is available),
    the dashboard must still render the symbol header rather than
    clearing to em-dashes."""
    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({}, _stub_universe()),
        data_manager=None,
        industry_map={"FOO": "TestIndustry"},
    )
    # Simulate the failed-price path: current_symbol set, no enriched.
    w._current_symbol = "FOO"
    w._current_enriched = None
    w._current_options = None
    w._render_current()

    # Dashboard tab keeps the symbol on the header strip even
    # without price data.
    assert w._dashboard_tab.symbol == "FOO"
    assert w._dashboard_tab._h_symbol_lbl.text() == "FOO"
    # Status surfaces the partial-render condition.
    assert "no price data" in w._status.currentMessage().lower()
    w.close()


def test_load_symbol_clears_stale_enriched(qapp):    # noqa: ARG001
    """Switching from a working symbol to a failing one must not
    leave the previous symbol's enriched frame visible."""
    enriched_a = _enriched()

    w = MainWindow(
        compute_engine=StrategyComputeEngine(),
        panel_loader=_stub_loader({"A": enriched_a}, _stub_universe("A", "B")),
        data_manager=None,
        industry_map={"A": "I", "B": "I"},
    )
    # Load A successfully (sync path via panel cache).
    w._load_symbol("A")
    assert w._current_enriched is not None
    assert w._dashboard_tab.symbol == "A"

    # Switch to B — not in panel. Should reset enriched, leaving
    # neither A's data nor B's (which doesn't exist).
    w._load_symbol("B")
    assert w._current_enriched is None
    w.close()


def test_seasonality_heatmap_view_toggle(qapp):    # noqa: ARG001
    """The heatmap exposes magnitude/reliability view toggle + sorting."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.ui.widgets.seasonality_heatmap import (
        SeasonalityHeatmap, _reliability,
    )
    # reliability metric sanity
    assert _reliability(10.0, 1.0) > _reliability(10.0, 20.0)
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, syms = {}, []
    for j in range(6):
        rng = np.random.default_rng(j)
        close = 100 * np.cumprod(1 + rng.normal(0.0003, 0.01, len(idx)))
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(len(idx), 1e6)}, index=idx), f"S{j}")
        syms.append(f"S{j}")
    h = SeasonalityHeatmap()
    h.set_data({"X": syms}, panel)
    assert h._view == "magnitude"
    h._set_view("reliability")
    assert h._view == "reliability"
    # sorting by a month works without error
    h._on_month_clicked(3)
    assert h._sort_month == 3


def test_seasonality_reliability_sort_uses_reliability(qapp):    # noqa: ARG001
    """In the Reliability view, sorting by a month must order by the
    reliability score (what's shown), not the avg return."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.ui.widgets.seasonality_heatmap import (
        SeasonalityHeatmap, _reliability,
    )
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    # two industries: one consistent in Sep, one freak-year Sep
    panel, mbi = {}, {}
    for gi, (name, freak) in enumerate(
            [("Steady", False), ("Freak", True)]):
        syms = []
        for j in range(6):
            rng = np.random.default_rng(gi * 10 + j)
            rets = rng.normal(0.0002, 0.008, len(idx))
            if freak:
                sep = np.array([0.06 if (d.month == 9 and d.year == 2023)
                                else 0.0 for d in idx])
            else:
                sep = np.array([0.004 if d.month == 9 else 0.0 for d in idx])
            close = 100 * np.cumprod(1 + rets + sep)
            panel[f"{name}{j}"] = eng.enrich(pd.DataFrame(
                {"Open": close, "High": close * 1.01, "Low": close * 0.99,
                 "Close": close, "Volume": np.full(len(idx), 1e6)},
                index=idx), f"{name}{j}")
            syms.append(f"{name}{j}")
        mbi[name] = syms
    h = SeasonalityHeatmap()
    h.set_data(mbi, panel)
    h._set_view("reliability")
    h._on_month_clicked(8)    # September
    order = [h._table.verticalHeaderItem(r).text()
             for r in range(h._table.rowCount())]
    # Steady (high consistency) should rank above Freak in reliability sort
    assert order.index("Steady") < order.index("Freak")


def test_seasonality_cross_highlight(qapp):    # noqa: ARG001
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.ui.widgets.seasonality_heatmap import SeasonalityHeatmap
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, syms = {}, []
    for j in range(6):
        rng = np.random.default_rng(j)
        close = 100 * np.cumprod(1 + rng.normal(0.0003, 0.01, len(idx)))
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(len(idx), 1e6)}, index=idx), f"S{j}")
        syms.append(f"S{j}")
    h = SeasonalityHeatmap()
    h.set_data({"X": syms}, panel)
    h._on_cell_selected(0, 4)
    assert h._delegate.sel_row == 0
    assert h._delegate.sel_col == 4
    # re-render clears the stale highlight
    h._set_view("reliability")
    assert h._delegate.sel_row == -1


def test_seasonality_relative_view(qapp):    # noqa: ARG001
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.ui.widgets.seasonality_heatmap import SeasonalityHeatmap
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, mbi = {}, {}
    for gi, name in enumerate(["A", "B"]):
        syms = []
        for j in range(6):
            rng = np.random.default_rng(gi * 5 + j)
            close = 100 * np.cumprod(1 + rng.normal(0.0003, 0.01, len(idx)))
            panel[f"{name}{j}"] = eng.enrich(pd.DataFrame(
                {"Open": close, "High": close, "Low": close, "Close": close,
                 "Volume": np.full(len(idx), 1e6)}, index=idx), f"{name}{j}")
            syms.append(f"{name}{j}")
        mbi[name] = syms
    h = SeasonalityHeatmap()
    h.set_data(mbi, panel)
    h._set_view("relative")
    assert h._view == "relative"
    assert h._btn_relm.isChecked()
    # sorting in relative view works
    h._on_month_clicked(0)
    assert h._sort_month == 0


def test_seasonality_contribution_table(qapp):    # noqa: ARG001
    """Selecting a cell populates the constituent-contribution table."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.ui.widgets.seasonality_heatmap import SeasonalityHeatmap
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, syms = {}, []
    for j in range(6):
        rng = np.random.default_rng(j)
        close = 100 * np.cumprod(1 + rng.normal(0.0003, 0.01, len(idx)))
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(len(idx), 1e6)}, index=idx), f"S{j}")
        syms.append(f"S{j}")
    h = SeasonalityHeatmap()
    h.set_data({"X": syms}, panel)
    # nothing selected → contribution table empty
    assert h._contrib._table.rowCount() == 0
    h._on_cell_selected(0, 3)    # April
    assert h._contrib._table.rowCount() == 6
    assert "April" in h._contrib._title.text() or "Apr" in h._contrib._title.text()
    # re-loading data clears it
    h.set_data({"X": syms}, panel)
    assert h._contrib._table.rowCount() == 0


def test_seasonality_contrib_double_click_emits_symbol(qapp):    # noqa: ARG001
    """Double-clicking a constituent row bubbles symbol_activated up
    through the heatmap and the RotationTab container."""
    import numpy as np, pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.ui.widgets.market_pulse_tab import MarketPulseTab
    from nimbus_v3.ui.widgets.rotation_tab import RotationTab
    eng = StrategyComputeEngine()
    idx = pd.date_range("2021-06-01", "2026-05-31", freq="B")
    panel, syms = {}, []
    for j in range(6):
        rng = np.random.default_rng(j)
        close = 100 * np.cumprod(1 + rng.normal(0.0003, 0.01, len(idx)))
        panel[f"S{j}"] = eng.enrich(pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(len(idx), 1e6)}, index=idx), f"S{j}")
        syms.append(f"S{j}")
    container = RotationTab(breadth_widget=MarketPulseTab())
    container.set_data({"X": syms}, panel, None)
    captured = []
    container.symbol_activated.connect(lambda s: captured.append(s))
    heat = container._seasonality
    heat._on_cell_selected(0, 3)    # populate contribution table
    sym0 = heat._contrib._table.item(0, 0).text()
    heat._contrib._on_row_activated(0, 0)
    assert captured == [sym0]
