"""
backtest/ — NIMBUS Historical Validation Framework
────────────────────────────────────────────────────
Pure computation modules. No Qt, no network at runtime.
Reuses modules/indicators.py signal functions directly.

Entry point: python3 scripts/run_backtest.py
"""
