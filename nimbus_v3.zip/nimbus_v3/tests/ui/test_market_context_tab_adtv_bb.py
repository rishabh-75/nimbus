"""tests.ui.test_market_context_tab_adtv_bb — ADTV column, %B column
with riding-BB color rule, and BBW slope column on Market Pulse.

Covers:
- _format_adtv_m: ₹ → Millions formatting across liquidity ranges
- _is_riding_upper_bb: triple-condition check (%B range, SMA slope,
  BBW slope)
- _pct_b_color: GREEN when riding, RED when outside riding range,
  WHITE when %B in range but slopes fail, MUTED on NaN
- End-to-end: _analyze_group and _analyze_symbol return the new
  columns with expected shapes
"""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pandas as pd
import pytest
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication

from nimbus_v3.ui.theme import GREEN, MUTED, RED, WHITE
from nimbus_v3.ui.widgets.market_context_tab import (
    MarketContextTab,
    _format_adtv_m,
    _is_riding_upper_bb,
    _pct_b_color,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


# ══════════════════════════════════════════════════════════════════════
# _format_adtv_m
# ══════════════════════════════════════════════════════════════════════

class TestFormatAdtvM:

    def test_nan_returns_dash(self):
        assert _format_adtv_m(float("nan")) == "—"

    def test_zero_returns_dash(self):
        """Zero ADTV treated as no-data, not a legitimate zero."""
        assert _format_adtv_m(0.0) == "—"

    def test_negative_returns_dash(self):
        """Defensive — negative ₹ is always a data corruption."""
        assert _format_adtv_m(-100.0) == "—"

    def test_sub_billion_displayed_as_direct_millions(self):
        """100 M ₹ → '100 M' (retail-ADTV range)."""
        assert _format_adtv_m(100_000_000.0) == "100 M"

    def test_upper_bound_of_direct_m_range(self):
        """999 M ₹ in direct millions range."""
        assert _format_adtv_m(999_000_000.0) == "999 M"

    def test_billion_range_uses_thousands_separator(self):
        """1 B ₹ = 1000 M → '1,000 M' (straight M with comma)."""
        assert _format_adtv_m(1_000_000_000.0) == "1,000 M"

    def test_large_bank_range(self):
        """HDFC Bank-size ADTV ~ ₹40 B → '40,000 M'."""
        assert _format_adtv_m(40_000_000_000.0) == "40,000 M"

    def test_mega_billion_range(self):
        """Above 1 trillion ₹ → straight M with comma separators.
        Rare but covers index-level sums."""
        assert _format_adtv_m(2_500_000_000_000.0) == "2,500,000 M"


# ══════════════════════════════════════════════════════════════════════
# _is_riding_upper_bb
# ══════════════════════════════════════════════════════════════════════

class TestIsRidingUpperBb:

    def test_all_three_conditions_met(self):
        """%B in [1.0, 1.5], SMA slope > 0, BBW slope > 0 → riding."""
        assert _is_riding_upper_bb(1.15, +0.5, +0.3)

    def test_pct_b_below_one(self):
        """%B < 1.0 → not riding (below upper band)."""
        assert not _is_riding_upper_bb(0.85, +0.5, +0.3)

    def test_pct_b_above_one_five(self):
        """%B > 1.5 → blown off, not considered riding."""
        assert not _is_riding_upper_bb(1.75, +0.5, +0.3)

    def test_pct_b_at_lower_bound(self):
        """%B exactly 1.0 — inclusive bound, counts as riding."""
        assert _is_riding_upper_bb(1.0, +0.5, +0.3)

    def test_pct_b_at_upper_bound(self):
        """%B exactly 1.5 — inclusive bound."""
        assert _is_riding_upper_bb(1.5, +0.5, +0.3)

    def test_sma_slope_zero(self):
        """SMA20 slope exactly 0 is NOT positive → not riding."""
        assert not _is_riding_upper_bb(1.2, 0.0, +0.3)

    def test_sma_slope_negative(self):
        """Falling trend → not riding regardless of %B."""
        assert not _is_riding_upper_bb(1.2, -0.5, +0.3)

    def test_bbw_slope_negative(self):
        """Contracting bands → not riding (probably squeeze, not
        breakout)."""
        assert not _is_riding_upper_bb(1.2, +0.5, -0.3)

    def test_nan_pct_b_returns_false(self):
        assert not _is_riding_upper_bb(float("nan"), +0.5, +0.3)

    def test_nan_slope_returns_false(self):
        assert not _is_riding_upper_bb(1.2, float("nan"), +0.3)


# ══════════════════════════════════════════════════════════════════════
# _pct_b_color
# ══════════════════════════════════════════════════════════════════════

class TestPctBColor:

    def test_riding_returns_green(self):
        assert _pct_b_color(1.15, +0.5, +0.3) == GREEN

    def test_below_band_returns_red(self):
        """%B under 1.0 → RED, regardless of slopes. Below upper
        band means not riding, potential snap-back or pre-setup."""
        assert _pct_b_color(0.75, +0.5, +0.3) == RED

    def test_blown_off_returns_red(self):
        """%B > 1.5 → RED. Same snap-back risk from over-extension."""
        assert _pct_b_color(1.80, +0.5, +0.3) == RED

    def test_in_range_but_slopes_fail_returns_white(self):
        """%B in riding band but SMA or BBW slope failed → WHITE.
        Touching the band without trend/vol confirmation is
        ambiguous — don't mislead with color."""
        assert _pct_b_color(1.15, -0.5, +0.3) == WHITE
        assert _pct_b_color(1.15, +0.5, -0.3) == WHITE

    def test_nan_returns_muted(self):
        assert _pct_b_color(float("nan"), +0.5, +0.3) == MUTED


# ══════════════════════════════════════════════════════════════════════
# _NumericTextItem — numeric sort with formatted text
# ══════════════════════════════════════════════════════════════════════

class TestNumericTextItem:

    def _item(self, raw):
        """Build a _NumericTextItem with the given raw value stashed
        on UserRole and the formatted string as display text."""
        from nimbus_v3.ui.widgets.market_context_tab import _NumericTextItem
        it = _NumericTextItem()
        it.setData(Qt.ItemDataRole.UserRole, raw)
        it.setText(_format_adtv_m(raw) if raw == raw else "—")
        return it

    def test_sorts_numerically_across_magnitude_boundary(self, qapp):
        """String sort of '65,300 M' vs '946 M' would put 946 first
        (comma < digit). Numeric sort puts 946 first correctly too
        — but for a different reason. Verify this is numeric."""
        small = self._item(946_000_000.0)          # 946 M
        large = self._item(65_300_000_000.0)       # 65,300 M
        # 946 M < 65,300 M numerically
        assert small < large
        assert not (large < small)

    def test_sorts_numerically_across_string_reorderings(self, qapp):
        """This is the case that string-sort gets wrong: "100" vs
        "1,000" — string sort thinks "1,000" < "100" because ','
        < '0'. Numeric sort must disagree."""
        val_100m = self._item(100_000_000.0)       # 100 M
        val_1b = self._item(1_000_000_000.0)       # 1,000 M
        assert val_100m < val_1b
        assert not (val_1b < val_100m)

    def test_nan_sorts_to_bottom_ascending(self, qapp):
        """NaN (missing) should not compare as smaller than real
        values — mixing '—' rows into the top of the list is ugly."""
        real = self._item(500_000_000.0)
        missing = self._item(float("nan"))
        # `missing < real` should be False — meaning in ascending
        # sort, the missing row sits after the real one.
        assert not (missing < real)
        # And `real < missing` should be True.
        assert real < missing

    def test_two_nans_are_equal(self, qapp):
        a = self._item(float("nan"))
        b = self._item(float("nan"))
        assert not (a < b)
        assert not (b < a)


# ══════════════════════════════════════════════════════════════════════
# End-to-end analyze_group / analyze_symbol return the new columns
# ══════════════════════════════════════════════════════════════════════

def _synthetic_panel(n: int = 150, n_symbols: int = 5):
    """Build a small synthetic panel for the analyze path. All
    symbols get the same Close/Volume pattern — details don't
    matter for the new-column checks, only that the columns
    populate with finite numeric values."""
    idx = pd.bdate_range("2024-01-01", periods=n)
    rng = np.random.default_rng(42)
    panel = {}
    for i in range(n_symbols):
        # Gentle uptrend to keep SMA20 slope positive and clean
        close = pd.Series(100 + np.arange(n) * 0.2 + rng.normal(0, 0.5, n), index=idx)
        volume = pd.Series(1_000_000 + rng.integers(-50_000, 50_000, n), index=idx)
        panel[f"SYM{i}"] = pd.DataFrame({"Close": close, "Volume": volume})
    return panel


class TestAnalyzeGroupNewColumns:

    def test_group_row_has_adtv_pct_b_bbw_slope(self, qapp):
        tab = MarketContextTab()
        tab._panel = _synthetic_panel(n=150, n_symbols=5)
        result = tab._analyze_group("TEST_IND", [f"SYM{i}" for i in range(5)])
        assert result is not None
        # The three new columns are present
        assert "ADTV" in result
        assert "%B" in result
        assert "BBW slope" in result

    def test_group_adtv_is_sum_of_members(self, qapp):
        """ADTV at the group level should be the SUM of member
        ADTVs — roughly, for 5 identical ~1M-volume × 100₹
        symbols, ~5 × 1M × 100 = 500M ₹."""
        tab = MarketContextTab()
        tab._panel = _synthetic_panel(n=150, n_symbols=5)
        result = tab._analyze_group("TEST_IND", [f"SYM{i}" for i in range(5)])
        assert result is not None
        # Expect roughly 5 * ~100 * ~1_000_000 = ~500_000_000
        # Bands of [300M, 700M] absorb the rng noise safely
        assert 3e8 <= result["ADTV"] <= 7e8

    def test_group_pct_b_is_numeric_float(self, qapp):
        tab = MarketContextTab()
        tab._panel = _synthetic_panel(n=150, n_symbols=5)
        result = tab._analyze_group("TEST_IND", [f"SYM{i}" for i in range(5)])
        # %B can be any float (NaN allowed for ultra-short series;
        # at n=150 we expect a real value)
        assert isinstance(result["%B"], float)
        assert not np.isnan(result["%B"])


class TestAnalyzeSymbolNewColumns:

    def test_symbol_row_has_adtv_pct_b_bbw_slope(self, qapp):
        tab = MarketContextTab()
        tab._panel = _synthetic_panel(n=150, n_symbols=1)
        tab._industry_relative_states = {}
        result = tab._analyze_symbol("SYM0")
        assert result is not None
        assert "ADTV" in result
        assert "%B" in result
        assert "BBW slope" in result

    def test_symbol_adtv_no_volume_is_nan(self, qapp):
        """A symbol with no Volume column should get NaN ADTV —
        renderer will show '—'."""
        tab = MarketContextTab()
        idx = pd.bdate_range("2024-01-01", periods=100)
        close = pd.Series(np.linspace(100, 120, 100), index=idx)
        tab._panel = {"SYM0": pd.DataFrame({"Close": close})}   # no Volume
        tab._industry_relative_states = {}
        result = tab._analyze_symbol("SYM0")
        assert result is not None
        # ADTV should be NaN (renderer converts to "—")
        assert np.isnan(result["ADTV"])
