"""scripts.run_sweep — placeholder. Implemented in a later phase."""
from __future__ import annotations

import sys


def main() -> int:
    print(
        "scripts.run_sweep is not yet implemented. "
        "See docs/ARCHITECTURE.md §16 for the phase plan.",
        file=sys.stderr,
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
