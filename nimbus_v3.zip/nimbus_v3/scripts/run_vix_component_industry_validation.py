"""scripts/run_vix_component_industry_validation.py — per-symbol
regime response aggregated to per-industry direction, with
expanding-window walk-forward validation.

Fourth and final iteration of VIX regime research. Earlier iterations:
  1. Single-window, single-split (20d, midpoint): research established
     tag × regime lifts but walk-forward failed (sign flips).
  2. Multi-window bake-off (5/10/20/60): cross-window replication of
     LOWβ + ACCUM-STABLE findings, but tag × regime interactions
     only held within a single time period.
  3. Walk-forward validation of tag × regime multipliers: ALL windows
     had >3 sign flips. Per-tag × regime signal does not generalize.

This iteration is the last attempt. Key design shifts:
  - Aggregation level: per-symbol regime response (each stock carries
    ~1200 bars of history), MEDIAN-aggregated to per-industry
    direction (~15-30 members per industry). Much deeper sample per
    cell than the pooled industry-level cell that failed before.
  - Validation: expanding-window walk-forward with 4 folds, purged at
    10-bar boundary to block fwd_10d leakage. Sign-agreement across
    folds is the "stability score."
  - Ship decision: industries with ≥ 75% stability (sign agrees in
    ≥ 3 of 4 folds) in ≥ 2 regimes are productionizable. Others
    are not. If fewer than N industries pass in any window, we
    ship the panel-wide VIX badge only and close the thread.

Reuses _prepare_data from run_vix_pace_research.py.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))
if str(_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(_ROOT / "scripts"))

from run_vix_pace_research import (                                   # noqa: E402
    _prepare_data,
    classify_vix_pace,
)

logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("vix_component_valid")
log.setLevel(logging.INFO)


# ══════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════

_OUT_PATH = Path("scripts/output/vix_component_industry_validation.txt")

#: Slope windows to test.
_WINDOWS: tuple[int, ...] = (5, 10, 20, 60)

#: Regime labels we stratify over.
_REGIMES: tuple[str, ...] = ("RISING", "STABLE", "FALLING")

#: Number of walk-forward folds. Each fold uses an expanding window
#: of train data and the next slice as test. Fold 1 trains on the
#: first half, tests on the next ~year; fold 4 trains on ~4 years,
#: tests on the last ~year.
_N_FOLDS: int = 4

#: Bars to drop at the train/test boundary to prevent fwd_10d
#: leakage. Matches the forward-return horizon.
_PURGE_BARS: int = 10

#: Minimum in-regime observations for a symbol to count in the
#: industry aggregation. Thin but realistic given RISING/FALLING
#: scarcity.
_MIN_SYMBOL_OBS: int = 30

#: Minimum members per industry after the per-symbol gate.
_MIN_INDUSTRY_MEMBERS: int = 5

#: Sign-agreement threshold across folds to declare a signal "stable."
#: 0.75 = sign agrees in ≥ 3 of 4 folds.
_STABILITY_THRESHOLD: float = 0.75


# ══════════════════════════════════════════════════════════════════════
# Fold construction
# ══════════════════════════════════════════════════════════════════════

def _make_expanding_folds(
    dates: pd.DatetimeIndex, n_folds: int,
) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    """Return a list of (train_end, test_start, test_end) tuples.

    Strategy: split the date range into (n_folds + 1) equal chunks.
    Fold i trains on the first (i+1) chunks and tests on chunk (i+2).
    The +1 chunk offset means we always have at least half the data
    for training in fold 1.
    """
    start = dates.min()
    end = dates.max()
    total = end - start
    chunk = total / (n_folds + 1)

    folds: list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]] = []
    for i in range(n_folds):
        train_end = start + chunk * (i + 1)
        test_start = train_end
        test_end = start + chunk * (i + 2)
        folds.append((train_end, test_start, test_end))
    return folds


# ══════════════════════════════════════════════════════════════════════
# Per-symbol regime response measurement
# ══════════════════════════════════════════════════════════════════════

def _per_symbol_lift(
    panel_w_fwd: dict[str, pd.DataFrame],
    regime_series: pd.Series,
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
    min_obs: int = _MIN_SYMBOL_OBS,
) -> pd.DataFrame:
    """For each (symbol, regime) with sufficient observations in
    [date_start, date_end]:
      lift = symbol's in-regime fwd_10d mean
              − symbol's all-regime (unconditional) fwd_10d mean

    This measures how much each regime shifts a symbol's return
    profile relative to its own baseline. Symbols with < min_obs
    observations in a given regime are dropped from that cell.

    Returns long DataFrame: [symbol, regime, n_in_cell, in_cell_mean,
    unconditional_mean, lift_pp].
    """
    regime_aligned = regime_series.rename("regime")
    rows: list[dict] = []
    for sym, df in panel_w_fwd.items():
        if "fwd_ret_10d" not in df.columns:
            continue
        sub = df[["fwd_ret_10d"]].join(regime_aligned, how="inner")
        # Date-bound
        mask = (sub.index >= date_start) & (sub.index <= date_end)
        sub = sub.loc[mask].dropna(subset=["fwd_ret_10d"])
        if len(sub) < min_obs:
            continue
        uncond_mean = float(sub["fwd_ret_10d"].mean())
        for regime in _REGIMES:
            in_cell = sub.loc[sub["regime"] == regime, "fwd_ret_10d"]
            if len(in_cell) < min_obs:
                continue
            in_mean = float(in_cell.mean())
            rows.append({
                "symbol":            sym,
                "regime":            regime,
                "n_in_cell":         len(in_cell),
                "in_cell_mean_pp":   in_mean * 100,
                "unconditional_pp":  uncond_mean * 100,
                "lift_pp":           (in_mean - uncond_mean) * 100,
            })
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════
# Per-industry aggregation
# ══════════════════════════════════════════════════════════════════════

def _aggregate_to_industry(
    symbol_lifts: pd.DataFrame,
    industry_map: dict[str, str],
    min_members: int = _MIN_INDUSTRY_MEMBERS,
) -> pd.DataFrame:
    """Median-aggregate per-symbol lifts to per-industry direction.

    Drops industries with < min_members members passing the
    per-symbol threshold in a given regime.

    Returns long DataFrame: [industry, regime, n_members, median_lift_pp].
    """
    if symbol_lifts.empty:
        return pd.DataFrame()
    # Attach industry labels
    sl = symbol_lifts.copy()
    sl["industry"] = sl["symbol"].map(industry_map)
    sl = sl.dropna(subset=["industry"])

    grouped = sl.groupby(["industry", "regime"])["lift_pp"]
    agg = grouped.agg(["count", "median"]).reset_index()
    agg.columns = ["industry", "regime", "n_members", "median_lift_pp"]
    agg = agg[agg["n_members"] >= min_members]
    return agg.reset_index(drop=True)


# ══════════════════════════════════════════════════════════════════════
# Single fold: train direction + test direction
# ══════════════════════════════════════════════════════════════════════

def _run_fold(
    panel_w_fwd: dict,
    regime_series: pd.Series,
    industry_map: dict,
    train_end: pd.Timestamp,
    test_start: pd.Timestamp,
    test_end: pd.Timestamp,
    fold_id: int,
) -> pd.DataFrame:
    """Compute per-industry × regime direction on the train half and
    on the held-out test slice. Returns a merged DataFrame with both
    directions side-by-side for this fold.

    Purging: the train window ends at (train_end - _PURGE_BARS * 1.5
    days) so fwd_10d computed on the latest train bar can't spill
    into the test period.
    """
    # Purge — back off train_end by enough business days to cover
    # fwd_10d. 1.5x buffer accounts for weekends.
    purge_offset = pd.Timedelta(days=int(_PURGE_BARS * 1.5))
    train_hard_end = train_end - purge_offset

    train_symbols = _per_symbol_lift(
        panel_w_fwd, regime_series,
        date_start=regime_series.index.min(),
        date_end=train_hard_end,
    )
    test_symbols = _per_symbol_lift(
        panel_w_fwd, regime_series,
        date_start=test_start,
        date_end=test_end,
    )

    train_industries = _aggregate_to_industry(train_symbols, industry_map)
    test_industries = _aggregate_to_industry(test_symbols, industry_map)

    if train_industries.empty or test_industries.empty:
        return pd.DataFrame()

    merged = train_industries.merge(
        test_industries, on=["industry", "regime"],
        suffixes=("_train", "_test"),
        how="inner",
    )
    merged["fold"] = fold_id
    merged["sign_agree"] = (
        (merged["median_lift_pp_train"] > 0) ==
        (merged["median_lift_pp_test"] > 0)
    )
    return merged


# ══════════════════════════════════════════════════════════════════════
# Across-fold stability aggregation
# ══════════════════════════════════════════════════════════════════════

def _compute_stability(all_folds: pd.DataFrame) -> pd.DataFrame:
    """For each (industry, regime), compute the fraction of folds
    where the train and test directions agreed. Returns a long
    DataFrame with stability_score in [0, 1].
    """
    grp = all_folds.groupby(["industry", "regime"])
    out = grp.agg(
        n_folds=("fold", "count"),
        n_agree=("sign_agree", "sum"),
        mean_train=("median_lift_pp_train", "mean"),
        mean_test=("median_lift_pp_test", "mean"),
        min_n_members=("n_members_train", "min"),
    ).reset_index()
    out["stability_score"] = out["n_agree"] / out["n_folds"]
    return out.sort_values(
        ["stability_score", "regime"], ascending=[False, True],
    )


# ══════════════════════════════════════════════════════════════════════
# Verdict
# ══════════════════════════════════════════════════════════════════════

def _verdict_for_window(stability_df: pd.DataFrame) -> dict:
    """Summarize: how many (industry, regime) cells are stable?
    How many industries have ≥ 2 stable regimes?

    Also computes ``evidence_score`` — the sum of ``n_folds`` across
    stable cells. A cell that agreed across 3 folds provides stronger
    evidence than one that agreed across 2; summing the fold depth
    rewards windows whose stability came from deep agreement rather
    than shallow pairwise agreement.
    """
    if stability_df.empty:
        return {
            "n_stable_cells":      0,
            "n_stable_industries": 0,
            "stable_industries":   [],
            "evidence_score":      0,
        }
    stable_cells = stability_df[
        stability_df["stability_score"] >= _STABILITY_THRESHOLD
    ]
    per_ind = stable_cells.groupby("industry").size()
    stable_inds = per_ind[per_ind >= 2].index.tolist()
    evidence_score = int(stable_cells["n_folds"].sum())
    return {
        "n_stable_cells":      len(stable_cells),
        "n_stable_industries": len(stable_inds),
        "stable_industries":   stable_inds,
        "evidence_score":      evidence_score,
    }


# ══════════════════════════════════════════════════════════════════════
# Output formatting
# ══════════════════════════════════════════════════════════════════════

def _fmt(df: pd.DataFrame, precision: int = 3) -> str:
    if df.empty:
        return "(empty)"
    with pd.option_context("display.max_rows", None,
                            "display.max_columns", None,
                            "display.width", 180,
                            "display.float_format", lambda x: f"{x:.{precision}f}"):
        return df.to_string(index=False)


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data...")
    try:
        prepared = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    vix_close = prepared["vix_close"]
    panel_w_fwd = prepared["panel_w_fwd"]
    industry_map = prepared["industry_map"]

    folds = _make_expanding_folds(vix_close.index, _N_FOLDS)

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("VIX COMPONENT × INDUSTRY DIRECTION — WALK-FORWARD VALIDATION")
        emit("=" * 78)
        emit(f"Approach: per-symbol regime response → median-aggregated per-industry direction")
        emit(f"Validation: expanding-window walk-forward, {_N_FOLDS} folds, purged ±{_PURGE_BARS} bars")
        emit(f"Ship rule: ≥ {_STABILITY_THRESHOLD:.0%} sign-agreement across folds in ≥ 2 regimes")
        emit(f"Min per-symbol in-regime observations:  {_MIN_SYMBOL_OBS}")
        emit(f"Min industry members (post per-sym gate): {_MIN_INDUSTRY_MEMBERS}")
        emit("")
        emit(f"VIX history: {len(vix_close)} bars ({vix_close.index.min().date()} → {vix_close.index.max().date()})")
        emit(f"Tagged panel: {len(panel_w_fwd)} symbols")
        emit("")
        emit("Fold boundaries:")
        for i, (train_end, test_start, test_end) in enumerate(folds):
            emit(f"  Fold {i+1}: train → {train_end.date()}, test {test_start.date()} → {test_end.date()}")
        emit("")

        verdict_rows: list[dict] = []

        for win in _WINDOWS:
            emit("━" * 78)
            emit(f"SLOPE WINDOW = {win}d")
            emit("━" * 78)

            regime_df = classify_vix_pace(vix_close, slope_win=win)
            regime_series = regime_df["regime"]

            # Run all folds for this window
            fold_results: list[pd.DataFrame] = []
            for i, (train_end, test_start, test_end) in enumerate(folds):
                fold_df = _run_fold(
                    panel_w_fwd, regime_series, industry_map,
                    train_end, test_start, test_end, fold_id=i + 1,
                )
                if not fold_df.empty:
                    fold_results.append(fold_df)
                emit(f"\nFold {i+1}: train → {train_end.date()} | test {test_start.date()} → {test_end.date()}")
                if fold_df.empty:
                    emit("  (empty — no industries passed gates)")
                    continue
                # Per-regime fold summary: N industries, % sign agreement
                for regime in _REGIMES:
                    cell = fold_df[fold_df["regime"] == regime]
                    if cell.empty:
                        continue
                    n = len(cell)
                    agree = int(cell["sign_agree"].sum())
                    pct = agree / n * 100 if n else 0
                    emit(f"  {regime:8s}: {n:3d} industries, "
                         f"{agree:3d} agreed in sign ({pct:5.1f}%)")

            if not fold_results:
                emit(f"\n[no valid folds at {win}d — skipping stability analysis]\n")
                continue

            all_folds = pd.concat(fold_results, ignore_index=True)

            # Stability scores
            stability = _compute_stability(all_folds)
            emit("")
            emit("STABILITY: sign-agreement rate across folds per (industry, regime)")
            emit("-" * 78)
            emit("(only showing industries that appeared in ≥ 2 folds per regime)")
            stable_shown = stability[stability["n_folds"] >= 2].copy()
            stable_shown = stable_shown.sort_values(
                ["stability_score", "industry", "regime"],
                ascending=[False, True, True],
            )
            emit(_fmt(stable_shown[[
                "industry", "regime", "n_folds", "n_agree",
                "stability_score", "mean_train", "mean_test",
            ]]))
            emit("")

            verdict = _verdict_for_window(stability)
            emit(f"Window {win}d verdict:")
            emit(f"  Stable (≥{_STABILITY_THRESHOLD:.0%}) cells: {verdict['n_stable_cells']}")
            emit(f"  Industries with ≥ 2 stable regimes: {verdict['n_stable_industries']}")
            if verdict["stable_industries"]:
                emit(f"  → {', '.join(verdict['stable_industries'])}")
            emit("")

            verdict_rows.append({
                "window": win,
                **verdict,
            })

        # ── Final verdict ──────────────────────────────────────────
        emit("━" * 78)
        emit("FINAL VERDICT")
        emit("━" * 78)
        emit("")

        if not verdict_rows:
            emit("No windows produced valid folds. Signal does not exist at this horizon.")
            emit("SHIP: panel-wide VIX badge only (from prior iteration's Option 1).")
            return

        # Pick the best window by evidence-weighted stability, not
        # just the raw count of stable industries. A 2-fold cell at
        # stability=1.0 has a ~25% chance of being coincidence (1/2^2
        # directional agreements); a 3-fold cell at stability=1.0 has
        # ~12.5%; a 4-fold cell has ~6%. Windows with deeper folds
        # per cell provide much stronger evidence even at the same
        # raw industry count.
        #
        # evidence_score = sum of n_folds across each stable
        # (industry, regime) cell. Shallow cells contribute less.
        best = max(
            verdict_rows,
            key=lambda r: (r["evidence_score"], r["n_stable_industries"]),
        )
        emit(f"Best window:  {best['window']}d")
        emit(f"  {best['n_stable_cells']} stable cells across "
             f"{best['n_stable_industries']} industries")
        emit(f"  evidence_score: {best['evidence_score']} "
             f"(sum of fold-depth across stable cells — higher = "
             f"stronger replication)")
        emit("")

        # Decision
        if best["n_stable_industries"] >= 10:
            emit(f"✓ SHIP: ≥ 10 industries have stable regime directions at {best['window']}d.")
            emit("Next step: productionize per-industry regime direction indicators.")
            emit(f"Stable industries: {', '.join(best['stable_industries'])}")
        elif best["n_stable_industries"] >= 5:
            emit(f"⚠ MARGINAL: only {best['n_stable_industries']} industries stable at {best['window']}d.")
            emit("Ship decision: surface these specific industries' regime directions,")
            emit("or ship panel-wide badge only. Either is defensible.")
        else:
            emit(f"✗ DO NOT SHIP: fewer than 5 stable industries at any window.")
            emit("SHIP: panel-wide VIX badge only. Close the research thread.")

        emit("")
        emit("Per-window summary (sorted by evidence_score):")
        for r in sorted(verdict_rows, key=lambda x: -x["evidence_score"]):
            emit(f"  {r['window']:3d}d: {r['n_stable_cells']:3d} stable cells, "
                 f"{r['n_stable_industries']:3d} stable industries, "
                 f"evidence_score={r['evidence_score']:3d}")

    log.info("Wrote %s", _OUT_PATH)
    # Echo verdict to stdout
    with _OUT_PATH.open("r") as fh:
        content = fh.read()
    if "FINAL VERDICT" in content:
        idx = content.index("━" * 78 + "\nFINAL VERDICT")
        print(content[idx:])


if __name__ == "__main__":
    main()
