#!/usr/bin/env python3
"""
scripts/run_vix_momentum.py — Does momentum work for equities in specific VIX regimes?

Background: We switched from momentum to mean reversion because MR dominated
overall. But "overall" blends all VIX regimes. Hypothesis:
  - LOW VIX (orderly trend) → momentum (trend-following) may outperform
  - ELEVATED/PANIC → mean reversion dominates
  - NORMAL → mixed, MR slightly better

Approach:
  1. For each NIFTY 100 stock, generate BOTH momentum and MR signals
  2. Compute 5d/10d/21d forward returns from each signal
  3. Segment by VIX regime at signal date
  4. Compare: which strategy wins in which regime?

Momentum signal: price > SMA50, SMA50 > SMA200, WR(30) rising from oversold
                 (crossing -50 from below = pullback in uptrend)
MR signal:       price < SMA50, WR(30) < -70, BB position < 0.2
                 (our existing oversold entry)

Run:
    python3 scripts/run_vix_momentum.py
    python3 scripts/run_vix_momentum.py --symbols 30   # fewer stocks, faster
    python3 scripts/run_vix_momentum.py --years 5
"""
import os, sys, logging, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger("vix_momentum")


# ══════════════════════════════════════════════════════════════════════════════
# SIGNAL GENERATION
# ══════════════════════════════════════════════════════════════════════════════

def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Add all needed indicators to OHLCV dataframe."""
    c = df["Close"]
    df = df.copy()

    df["sma_50"] = c.rolling(50, min_periods=40).mean()
    df["sma_200"] = c.rolling(200, min_periods=150).mean()

    # Williams %R (30)
    h30 = df["High"].rolling(30, min_periods=20).max()
    l30 = df["Low"].rolling(30, min_periods=20).min()
    df["wr_30"] = ((h30 - c) / (h30 - l30) * -100).clip(-100, 0)

    # Bollinger position
    sma20 = c.rolling(20, min_periods=15).mean()
    std20 = c.rolling(20, min_periods=15).std()
    upper = sma20 + 2 * std20
    lower = sma20 - 2 * std20
    df["bb_pos"] = ((c - lower) / (upper - lower)).clip(0, 1)

    # MFI (14)
    tp = (df["High"] + df["Low"] + c) / 3
    mf = tp * df["Volume"]
    pos_mf = mf.where(tp > tp.shift(1), 0).rolling(14).sum()
    neg_mf = mf.where(tp < tp.shift(1), 0).rolling(14).sum()
    mfi = 100 - 100 / (1 + pos_mf / neg_mf.replace(0, 1))
    df["mfi"] = mfi.clip(0, 100)

    # Drawdown from 50d high
    h50 = df["High"].rolling(50, min_periods=20).max()
    df["dd_50"] = (c / h50 - 1) * 100

    return df.dropna(subset=["sma_50", "wr_30", "bb_pos"])


def detect_momentum_signals(df: pd.DataFrame, cooldown: int = 10) -> list:
    """
    Momentum signal: pullback-in-uptrend.
    - Price > SMA50
    - SMA50 > SMA200 (broad uptrend)
    - WR(30) crosses above -50 from below (pullback bounce)
    - MFI > 40 (money flowing in)
    """
    signals = []
    last_signal = None

    wr = df["wr_30"]
    wr_prev = wr.shift(1)
    crosses = (wr > -50) & (wr_prev <= -50)

    for i in range(1, len(df)):
        if not crosses.iloc[i]:
            continue
        row = df.iloc[i]
        if row["Close"] <= row["sma_50"]:
            continue
        if pd.isna(row["sma_200"]) or row["sma_50"] <= row["sma_200"]:
            continue
        if row["mfi"] < 40:
            continue

        d = df.index[i]
        if last_signal and (d - last_signal).days < cooldown:
            continue
        signals.append({"date": d, "strategy": "MOMENTUM", "idx": i})
        last_signal = d

    return signals


def detect_mr_signals(df: pd.DataFrame, cooldown: int = 10) -> list:
    """
    Mean reversion signal: oversold bounce.
    - WR(30) < -70 (deeply oversold)
    - BB position < 0.2 (near lower band)
    - DD from 50d high > -5% (confirmed pullback)
    """
    signals = []
    last_signal = None

    for i in range(1, len(df)):
        row = df.iloc[i]
        if row["wr_30"] >= -70:
            continue
        if row["bb_pos"] >= 0.2:
            continue
        if row["dd_50"] >= -5:
            continue

        d = df.index[i]
        if last_signal and (d - last_signal).days < cooldown:
            continue
        signals.append({"date": d, "strategy": "MR", "idx": i})
        last_signal = d

    return signals


def compute_forward_returns(df: pd.DataFrame, signals: list) -> list:
    """Compute 5d/10d/21d forward returns for each signal."""
    results = []
    for sig in signals:
        i = sig["idx"]
        base = float(df["Close"].iloc[i])
        rec = {"date": sig["date"], "strategy": sig["strategy"]}

        for label, days in [("5d", 5), ("10d", 10), ("21d", 21)]:
            fi = i + days
            if fi < len(df):
                rec[f"fwd_{label}"] = (float(df["Close"].iloc[fi]) / base - 1) * 100
            else:
                rec[f"fwd_{label}"] = np.nan
        results.append(rec)
    return results


# ══════════════════════════════════════════════════════════════════════════════
# DATA FETCH
# ══════════════════════════════════════════════════════════════════════════════

def fetch_stock(symbol: str, years: int = 5) -> pd.DataFrame:
    """Fetch daily OHLCV for an NSE stock."""
    import yfinance as yf
    from datetime import date, timedelta
    start = (date.today() - timedelta(days=years * 365)).isoformat()
    ticker = symbol if symbol.startswith("^") else f"{symbol}.NS"
    try:
        df = yf.download(ticker, start=start, progress=False, auto_adjust=True, timeout=15)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        if not df.empty and len(df) > 200:
            return df
    except Exception:
        pass
    return pd.DataFrame()


def fetch_vix(years: int = 5) -> pd.Series:
    """Fetch India VIX."""
    import yfinance as yf
    from datetime import date, timedelta
    start = (date.today() - timedelta(days=years * 365)).isoformat()
    for ticker in ["^INDIAVIX", "INDIAVIX.NS"]:
        try:
            df = yf.download(ticker, start=start, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if not df.empty:
                return df["Close"].dropna()
        except Exception:
            continue
    return pd.Series(dtype=float)


def get_symbols(n: int = 50) -> list:
    """Get NIFTY 100 symbols."""
    try:
        from modules.index_constituents import get_nifty100
        syms = get_nifty100()
        return syms[:n] if n else syms
    except Exception:
        # Hardcoded fallback
        return [
            "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK",
            "BHARTIARTL", "ITC", "SBIN", "LT", "HINDUNILVR",
            "KOTAKBANK", "AXISBANK", "BAJFINANCE", "MARUTI", "TITAN",
            "SUNPHARMA", "HCLTECH", "WIPRO", "ULTRACEMCO", "NESTLEIND",
            "ASIANPAINT", "POWERGRID", "NTPC", "TATAMOTORS", "TATASTEEL",
            "JSWSTEEL", "HINDALCO", "ONGC", "COALINDIA", "DRREDDY",
        ][:n]


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def assign_vix_regime(date, vix: pd.Series) -> str:
    mask = vix.index <= date
    if not mask.any():
        return "UNKNOWN"
    val = float(vix[mask].iloc[-1])
    if val > 25:
        return "PANIC"
    elif val > 20:
        return "ELEVATED"
    elif val < 13:
        return "LOW"
    else:
        return "NORMAL"


def print_report(all_signals: pd.DataFrame):
    """Print the comparative analysis."""

    log.info(f"\n{'=' * 75}")
    log.info(f"  VIX-GATED MOMENTUM vs MEAN REVERSION — EQUITY SIGNALS")
    log.info(f"{'=' * 75}")
    log.info(f"  Total signals: {len(all_signals)} "
             f"(MOM={len(all_signals[all_signals.strategy=='MOMENTUM'])}, "
             f"MR={len(all_signals[all_signals.strategy=='MR'])})")

    for horizon in ["fwd_5d", "fwd_10d", "fwd_21d"]:
        h_label = horizon.replace("fwd_", "")
        log.info(f"\n{'─' * 75}")
        log.info(f"  FORWARD RETURNS: {h_label}")
        log.info(f"{'─' * 75}")
        log.info(f"{'VIX Regime':>15} {'Strategy':>12} {'Signals':>8} {'WR%':>7} {'Avg':>8} {'Med':>8} {'Sharpe':>8}")
        log.info(f"{'─' * 68}")

        for regime in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            for strat in ["MOMENTUM", "MR"]:
                mask = (all_signals["vix_regime"] == regime) & (all_signals["strategy"] == strat)
                sub = all_signals.loc[mask, horizon].dropna()
                if len(sub) < 5:
                    continue
                wr = (sub > 0).mean() * 100
                avg = sub.mean()
                med = sub.median()
                sh = sub.mean() / sub.std() * np.sqrt(252) if sub.std() > 0 else 0
                marker = " ◀" if avg > 0 and wr > 55 else ""
                log.info(f"{regime:>15} {strat:>12} {len(sub):>8} {wr:>7.1f} {avg:>8.2f} {med:>8.2f} {sh:>8.2f}{marker}")

    # Overall comparison
    log.info(f"\n{'=' * 75}")
    log.info(f"  OVERALL (all regimes)")
    log.info(f"{'=' * 75}")
    for strat in ["MOMENTUM", "MR"]:
        sub = all_signals[all_signals.strategy == strat]
        for h in ["fwd_5d", "fwd_10d", "fwd_21d"]:
            vals = sub[h].dropna()
            if len(vals) < 5:
                continue
            wr = (vals > 0).mean() * 100
            log.info(f"  {strat:>10} {h.replace('fwd_', ''):>4}: "
                     f"WR={wr:.1f}%  Avg={vals.mean():+.2f}%  "
                     f"Med={vals.median():+.2f}%  Sh={vals.mean() / vals.std() * np.sqrt(252):.2f}  "
                     f"({len(vals)} signals)")

    # Key finding
    log.info(f"\n{'=' * 75}")
    log.info(f"  KEY QUESTION: Does any VIX regime support momentum over MR?")
    log.info(f"{'=' * 75}")
    for regime in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
        mom = all_signals[(all_signals.vix_regime == regime) & (all_signals.strategy == "MOMENTUM")]["fwd_21d"].dropna()
        mr = all_signals[(all_signals.vix_regime == regime) & (all_signals.strategy == "MR")]["fwd_21d"].dropna()
        if len(mom) >= 10 and len(mr) >= 10:
            winner = "MOMENTUM" if mom.mean() > mr.mean() else "MR"
            edge = abs(mom.mean() - mr.mean())
            log.info(f"  {regime:>10}: MOM avg={mom.mean():+.2f}% ({len(mom)}) vs "
                     f"MR avg={mr.mean():+.2f}% ({len(mr)}) → {winner} wins by {edge:.2f}pp")
        else:
            counts = f"MOM={len(mom)}, MR={len(mr)}"
            log.info(f"  {regime:>10}: insufficient data ({counts})")


def main():
    parser = argparse.ArgumentParser(description="VIX-gated momentum analysis")
    parser.add_argument("--symbols", type=int, default=50, help="Number of symbols (default 50)")
    parser.add_argument("--years", type=int, default=5, help="Years of history (default 5)")
    args = parser.parse_args()

    symbols = get_symbols(args.symbols)
    log.info(f"Analyzing {len(symbols)} symbols × {args.years} years")

    log.info("Fetching India VIX...")
    vix = fetch_vix(args.years)
    if vix.empty:
        log.error("Could not fetch VIX — aborting")
        return
    log.info(f"VIX data: {vix.index[0].date()} → {vix.index[-1].date()}")

    all_signals = []
    success = 0

    for i, sym in enumerate(symbols):
        log.info(f"  [{i+1}/{len(symbols)}] {sym}...")
        df = fetch_stock(sym, args.years)
        if df.empty:
            continue

        df = compute_indicators(df)
        if len(df) < 200:
            continue

        mom_sigs = detect_momentum_signals(df)
        mr_sigs = detect_mr_signals(df)

        mom_fwd = compute_forward_returns(df, mom_sigs)
        mr_fwd = compute_forward_returns(df, mr_sigs)

        for rec in mom_fwd + mr_fwd:
            rec["symbol"] = sym
            rec["vix_regime"] = assign_vix_regime(rec["date"], vix)
            all_signals.append(rec)

        success += 1

    log.info(f"\nProcessed {success}/{len(symbols)} symbols")

    if not all_signals:
        log.error("No signals generated")
        return

    df_all = pd.DataFrame(all_signals)
    df_all["date"] = pd.to_datetime(df_all["date"])

    log.info(f"Total signals: {len(df_all)}")
    log.info(f"  Momentum: {len(df_all[df_all.strategy=='MOMENTUM'])}")
    log.info(f"  MR:       {len(df_all[df_all.strategy=='MR'])}")

    print_report(df_all)

    # Save
    out = "data/backtest_results/vix_momentum_analysis.csv"
    df_all.to_csv(out, index=False)
    log.info(f"\nSaved → {out}")


if __name__ == "__main__":
    main()
