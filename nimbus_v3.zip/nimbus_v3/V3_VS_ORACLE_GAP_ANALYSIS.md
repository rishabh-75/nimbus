# NIMBUS v3 vs Oracle — post-refactor posture

This document used to be a structural gap analysis tracking what v3
needed to reach parity with `nimbus_oracle`. That goal is no longer
the design target.

## What changed

The terminal is now intentionally narrower than oracle. Everything
that wasn't part of the BB ride strategy was deleted in the
v0.2.0a0 refactor (see `CHANGES.md`):

- Mean-reversion / breakout / trap / drawdown-reversal / ETF-momentum
  strategies — gone.
- Conviction grading layer (formula + grade engine + fixtures) — gone.
- Scan orchestrator and scanner tab — gone.
- Macro / commodity flow tab — gone.
- Conservative / aggressive mode toggle — gone.
- Industry-relative analytics (alpha percentile, beta tags, RS
  regime aggregation) — gone.
- 13-section Workflow Analysis panel on the Dashboard — collapsed
  to two: Options Overlay + Industry Context.

## What v3 keeps from oracle's pattern

- Async per-symbol I/O via `DataManager` + `PriceWorker` /
  `OptionsWorker` Qt threads.
- Auto-refresh QTimer gated by `is_market_open()`.
- Freshness label on the status bar.
- EOD label colouring (LIVE / CLOSE / STALE).
- Splash + JetBrains Mono + pyqtgraph global config in `main.py`.
- ADTV-weighted synthetic-index industry classification (this is
  v3-specific and supersedes oracle's per-member consensus).

## What v3 deliberately does not have

- Live scan over the F&O universe. The Market Pulse tab does
  industry-level aggregation; per-symbol scans are not part of the
  product.
- Options-derived KPI tiles, key-levels grid, checklist panel.
  Options data drives the chart's wall overlay and the Options
  Overlay panel; no deeper consumer.
- Filings / VIX / sector providers wired into the slim Dashboard.
  The provider classes survive in `nimbus_v3/context/` and the
  enums survive in `core/types.py`, ready to be re-introduced if a
  concrete dashboard panel ever requires them — but right now no
  panel reads from them.

## If you need oracle's behaviour

It's intact in `nimbus_oracle`. v3 is the new line of development;
oracle is the reference. There is no migration path because there is
no shared module — every overlap was deliberately rebuilt fresh.
