"""nimbus_v3.ui.widgets.price_chart — 2-panel price + volume chart.

Scope, per locked decision: **price + volume + levels only**. No W%R or
MFI subplots on the chart — those live in the conviction panel's
contribution breakdown, not on the price axis. The chart is a visual
anchor, not a dashboard.

What's on the chart
───────────────────
    ┌ Price plot  (75%) ── candles · BB bands + fill + dashed mid
    │                     · SMA(20/50/200) · VWAP (intraday)
    │                     · wall lines + right-margin labels
    │                       ("R 25,430")
    └ Volume plot (25%) ── up/down-coloured bars · "1.9M / 340K" ticks
                          · date axis

Public API (locked):
    :meth:`set_data(df, options=None, bars=...)`  ·  :meth:`clear()`

Enriched-panel column probing
─────────────────────────────
Recognises both v3 (``bb_20_1s_upper / _mid / _lower``, ``sma_N``)
and oracle (``BB_Upper / BB_Mid / BB_Lower``) naming via
``_first_present``, so the same widget renders a v3 enriched frame
*or* a raw frame that only has OHLCV.

OptionsContext shape
────────────────────
Oracle used ``ctx.walls.*``/``ctx.gex.hvl``; v3's :class:`OptionsContext`
is flat — we read ``support_wall / resistance_wall / max_pain / hvl``.

Volume axis scientific-notation fix
───────────────────────────────────
pyqtgraph's ``AxisItem`` applies an auto-SI-prefix scale factor when
values are large — that's what overrode the ``tickStrings`` output and
caused "×10⁶" to appear on the right side of the volume panel.
``enableAutoSIPrefix(False)`` disables the overlay so the "1.9M / 340K"
strings render cleanly.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pyqtgraph as pg
from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtGui import QColor, QFont, QPainter, QPicture
from PyQt6.QtWidgets import QVBoxLayout, QWidget

from nimbus_v3.core.context import OptionsContext
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, FONT_MONO, GOLD, GREEN, MUTED, RED, VIOLET,
)


# ══════════════════════════════════════════════════════════════════════════════
# Pens / brushes — constructed once at import time
# ══════════════════════════════════════════════════════════════════════════════

_UP = "#26A69A"     # bullish candle fill
_DOWN = "#EF5350"   # bearish candle fill

_BB_UPPER = pg.mkPen("#BEBEC8", width=1.8)
_BB_LOWER = pg.mkPen("#BEBEC8", width=1.8)
_BB_MID = pg.mkPen("#F59E0B", width=1.2, style=Qt.PenStyle.DashLine)
_BB_FILL = pg.mkBrush(200, 200, 210, 18)

_VWAP_PEN = pg.mkPen("#E2E8F0", width=1.0, style=Qt.PenStyle.DotLine)
_CROSS_PEN = pg.mkPen(BORDER, width=0.6, style=Qt.PenStyle.DashLine)

_VOL_UP = pg.mkBrush(38, 166, 154, 180)
_VOL_DOWN = pg.mkBrush(239, 83, 80, 180)

# SMA lines — (column name, colour, line width).
_SMA_LINES: tuple[tuple[str, str, float], ...] = (
    ("sma_20", MUTED, 0.9),
    ("sma_50", BLUE, 1.1),
    ("sma_200", VIOLET, 0.9),
)

#: Consistent right-side Y axis width so the two panels align.
#: 52px fits 5-character price labels at 7pt mono ("1234.5", "30.0M")
#: with breathing room. Going from 64→52 closes the dead-zone
#: between the rightmost candle and the workflow column on its right.
_Y_AXIS_W = 52


# ══════════════════════════════════════════════════════════════════════════════
# Axis items — date on bottom of volume panel, human-readable volume ticks
# ══════════════════════════════════════════════════════════════════════════════

class _DateAxisItem(pg.AxisItem):
    """X-axis that maps integer bar indices to date / time strings."""

    def __init__(self, timestamps=None, *a, **kw):
        super().__init__(*a, **kw)
        self._ts: list = list(timestamps or [])
        self.setStyle(tickFont=QFont(FONT_MONO, 7))

    def set_timestamps(self, ts) -> None:
        self._ts = list(ts)

    def tickStrings(self, values, scale, spacing):    # noqa: N802
        out: list[str] = []
        prev_date: str | None = None
        for v in values:
            i = int(round(v))
            if 0 <= i < len(self._ts):
                t = self._ts[i]
                if isinstance(t, pd.Timestamp):
                    t = t.to_pydatetime()
                d = t.strftime("%d %b")
                # Show the date on a day-change, time otherwise, so
                # intraday charts don't repeat "13 Nov" every tick.
                out.append(d if d != prev_date else t.strftime("%H:%M"))
                prev_date = d
            else:
                out.append("")
        return out


class _VolumeAxisItem(pg.AxisItem):
    """Format volume ticks as 1.9M / 340K / 42 rather than 1.9e+06."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.setStyle(tickFont=QFont(FONT_MONO, 7))

    def tickStrings(self, values, scale, spacing):    # noqa: N802
        out: list[str] = []
        for v in values:
            av = abs(v)
            if av >= 1_000_000_000:
                out.append(f"{av / 1_000_000_000:.1f}B")
            elif av >= 1_000_000:
                out.append(f"{av / 1_000_000:.1f}M")
            elif av >= 1_000:
                out.append(f"{av / 1_000:.0f}K")
            elif av > 0:
                out.append(f"{int(av)}")
            else:
                out.append("")
        return out


# ══════════════════════════════════════════════════════════════════════════════
# Candlestick item — custom QGraphicsItem
# ══════════════════════════════════════════════════════════════════════════════

class _CandlestickItem(pg.GraphicsObject):
    """Draws OHLC candlesticks. Green on up-days, red on down-days.

    Parameters match oracle's ``chart_widget.CandlestickItem`` exactly —
    half-width 0.28, single 0.8px pen for wick + body outline, AA on
    throughout. Earlier v3 tunings (wider body, no outline, body AA
    off) produced the "too saturated / high contrast" look the
    operator flagged; restoring oracle's softer rendering.
    """

    _BODY_HALFWIDTH = 0.28
    _PEN_WIDTH = 0.8

    def __init__(self, df: pd.DataFrame) -> None:
        super().__init__()
        self._picture = QPicture()
        self._paint_candles(df)

    def _paint_candles(self, df: pd.DataFrame) -> None:
        painter = QPainter(self._picture)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w = self._BODY_HALFWIDTH
        for i, (_, row) in enumerate(df.iterrows()):
            o, h, l, c = row["Open"], row["High"], row["Low"], row["Close"]
            if pd.isna(o) or pd.isna(c) or pd.isna(h) or pd.isna(l):
                continue
            colour = QColor(_UP) if c >= o else QColor(_DOWN)
            # Single pen for wick + body outline — same width, same
            # colour. Anti-aliased edges soften the fill so candles
            # read as matte blocks rather than saturated pixels.
            painter.setPen(pg.mkPen(colour, width=self._PEN_WIDTH))
            painter.drawLine(QPointF(i, l), QPointF(i, h))
            painter.setBrush(pg.mkBrush(colour))
            top, bot = max(o, c), min(o, c)
            if top - bot < 0.001:
                painter.drawLine(QPointF(i - w, c), QPointF(i + w, c))
            else:
                painter.drawRect(pg.QtCore.QRectF(i - w, bot, 2 * w, top - bot))
        painter.end()

    def paint(self, painter, option, widget=None):   # noqa: ARG002
        painter.drawPicture(0, 0, self._picture)

    def boundingRect(self):
        return pg.QtCore.QRectF(self._picture.boundingRect())


# ══════════════════════════════════════════════════════════════════════════════
# Pure helpers — market-hours filter, IST conversion, VWAP
# ══════════════════════════════════════════════════════════════════════════════

def _filter_market_hours(df: pd.DataFrame) -> pd.DataFrame:
    """Keep only weekday 09:00–15:59 IST rows for intraday frames.

    Daily frames (min hour == max hour) pass through unchanged.
    """
    if df is None or df.empty:
        return df
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is not None:
        idx_ist = idx.tz_convert("Asia/Kolkata")
    else:
        try:
            idx_ist = idx.tz_localize("UTC").tz_convert("Asia/Kolkata")
        except Exception:    # noqa: BLE001
            return df
    if not hasattr(idx_ist, "hour"):
        return df
    hours = idx_ist.hour
    if hours.min() == hours.max():
        return df
    mask = (idx_ist.weekday < 5) & (hours >= 9) & (hours < 16)
    return df[mask].copy()


def _to_ist_list(df: pd.DataFrame) -> list:
    """Return the DataFrame index as IST-naive Python datetimes."""
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is not None:
        idx = idx.tz_convert("Asia/Kolkata").tz_localize(None)
    return list(idx.to_pydatetime())


def _compute_vwap(df: pd.DataFrame) -> np.ndarray | None:
    """Session-reset VWAP for intraday frames; ``None`` on EOD or no-volume."""
    if "Volume" not in df.columns or df["Volume"].sum() == 0:
        return None
    tp = (df["High"] + df["Low"] + df["Close"]) / 3.0
    vol = df["Volume"].fillna(0.0)
    dates = pd.DatetimeIndex(df.index).date
    if len(set(dates)) == 1:
        cv = (tp * vol).cumsum()
        denom = vol.cumsum().replace(0, np.nan)
        return (cv / denom).to_numpy(dtype=float)
    vwap = pd.Series(index=df.index, dtype=float)
    for d in pd.unique(dates):
        m = dates == d
        cv = (tp[m] * vol[m]).cumsum()
        denom = vol[m].cumsum().replace(0, np.nan)
        vwap[m] = cv / denom
    return vwap.to_numpy(dtype=float)


def _first_present(df: pd.DataFrame, candidates: tuple[str, ...]) -> str | None:
    """Return the first existing column name in ``df`` from ``candidates``."""
    for c in candidates:
        if c in df.columns:
            return c
    return None


# ══════════════════════════════════════════════════════════════════════════════
# Public widget
# ══════════════════════════════════════════════════════════════════════════════

class PriceChart(QWidget):
    """Price + volume chart for one symbol.

    Public API (locked): :meth:`set_data` / :meth:`clear`. The shape
    is compatible with the prior widget so ``DashboardTab`` doesn't
    need any changes to pick up the rework.
    """

    #: Default trailing window. 150 bars fills a ~8 month daily view —
    #: enough to see the 200-SMA relationship without squeezing the
    #: candles flat.
    DEFAULT_BARS = 150

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._current_df: pd.DataFrame | None = None
        self._current_options: OptionsContext | None = None
        self._show_vwap = True

        # ── Layout + plots ────────────────────────────────────────────────
        self._layout_widget = pg.GraphicsLayoutWidget()
        self._layout_widget.setBackground(BG)
        self._layout_widget.ci.layout.setSpacing(3)
        self._layout_widget.ci.layout.setContentsMargins(0, 0, 0, 0)

        self._date_axis = _DateAxisItem(orientation="bottom")

        self._price_plot = self._layout_widget.addPlot(row=0, col=0)
        self._cfg_plot(self._price_plot)

        # Volume owns the date axis — it's the bottom panel.
        self._vol_axis = _VolumeAxisItem(orientation="right")
        self._vol_plot = self._layout_widget.addPlot(
            row=1, col=0,
            axisItems={"right": self._vol_axis, "bottom": self._date_axis},
        )
        self._cfg_plot(self._vol_plot, label="VOL", show_x=True)
        self._vol_axis.enableAutoSIPrefix(False)    # fix: no "×10⁶" overlay
        self._vol_plot.setXLink(self._price_plot)

        layout = self._layout_widget.ci.layout
        layout.setRowStretchFactor(0, 75)    # price
        layout.setRowStretchFactor(1, 25)    # volume

        self._all_plots = (self._price_plot, self._vol_plot)

        # ── Crosshair ─────────────────────────────────────────────────────
        self._crosshair_v: pg.InfiniteLine | None = None
        self._crosshair_h: list[pg.InfiniteLine] = []
        self._install_crosshair()
        self._price_plot.scene().sigMouseMoved.connect(self._on_mouse_moved)

        # ── Empty-state placeholder ──────────────────────────────────────
        self._placeholder = pg.TextItem(
            "Select a signal to view its chart.",
            color=(100, 116, 139),    # MUTED rgb
        )
        self._price_plot.addItem(self._placeholder)
        self._placeholder.setPos(0.5, 0.5)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self._layout_widget)

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def set_data(
        self,
        df: pd.DataFrame | None,
        options: OptionsContext | None = None,
        *,
        bars: int = DEFAULT_BARS,
    ) -> None:
        """Render ``df`` with optional options-level overlays.

        Args:
            df: OHLCV DataFrame with a ``DatetimeIndex``. May carry
                enriched indicator columns (bb / sma). Missing columns
                are silently skipped. ``None`` returns the empty state.
            options: v3 :class:`OptionsContext`. When present, draws
                horizontal lines + right-margin labels for
                ``resistance_wall / support_wall / max_pain / hvl``.
            bars: Only the trailing ``bars`` rows are rendered.
        """
        self._clear_all_plots()
        if df is None or df.empty:
            self._price_plot.addItem(self._placeholder)
            return

        view_df = _filter_market_hours(df.tail(bars).copy())
        if view_df is None or view_df.empty:
            view_df = df.tail(bars).copy()
        if not all(c in view_df.columns for c in ("Open", "High", "Low", "Close")):
            return

        self._current_df = view_df
        self._current_options = options
        self._install_crosshair()

        ts = _to_ist_list(view_df)
        self._date_axis.set_timestamps(ts)

        n = len(view_df)
        x = np.arange(n, dtype=float)

        self._draw_candles(view_df)
        self._draw_bollinger(view_df, x)
        self._draw_vwap(view_df, x)
        self._draw_smas(view_df, x)
        self._draw_options_levels(options, n)
        self._draw_volume(view_df, x)

        # Ranges.
        self._price_plot.setXRange(-1, n + 2, padding=0.01)
        ymin = float(view_df["Low"].min())
        ymax = float(view_df["High"].max())
        if options is not None:
            for lv in (options.support_wall, options.resistance_wall,
                       options.max_pain, options.hvl):
                if lv is not None:
                    ymin = min(ymin, float(lv))
                    ymax = max(ymax, float(lv))
        self._price_plot.setYRange(ymin * 0.997, ymax * 1.003, padding=0.01)

    def clear(self) -> None:
        """Reset to the empty placeholder state."""
        self.set_data(None, None)

    # ══════════════════════════════════════════════════════════════════════
    # Plot configuration + crosshair
    # ══════════════════════════════════════════════════════════════════════

    def _cfg_plot(
        self, plot: pg.PlotItem, *, show_x: bool = False, label: str | None = None,
    ) -> None:
        plot.hideButtons()
        plot.setMenuEnabled(False)
        plot.showGrid(x=True, y=True, alpha=0.08)
        for side in ("left", "right", "top", "bottom"):
            ax = plot.getAxis(side)
            ax.setPen(pg.mkPen(BORDER, width=0.5))
            ax.setTextPen(pg.mkPen(MUTED))
            ax.setStyle(tickLength=-4, tickTextOffset=4,
                        tickFont=QFont(FONT_MONO, 7))
        plot.showAxis("right")
        plot.hideAxis("left")
        plot.getAxis("right").setWidth(_Y_AXIS_W)
        if not show_x:
            plot.hideAxis("bottom")
        plot.hideAxis("top")
        plot.getViewBox().setDefaultPadding(0.01)
        if label:
            txt = pg.TextItem(
                html=(
                    f'<span style="color:{MUTED}; font-family:{FONT_MONO}; '
                    f'font-size:8px; font-weight:600;">{label}</span>'
                ),
                anchor=(0, 0),
            )
            txt.setParentItem(plot.getViewBox())
            txt.setPos(4, 2)
            txt.setZValue(100)

    def _install_crosshair(self) -> None:
        self._crosshair_v = pg.InfiniteLine(angle=90, movable=False, pen=_CROSS_PEN)
        self._crosshair_v.setVisible(False)
        self._price_plot.addItem(self._crosshair_v, ignoreBounds=True)
        self._crosshair_h = []
        for plot in self._all_plots:
            h = pg.InfiniteLine(angle=0, movable=False, pen=_CROSS_PEN)
            h.setVisible(False)
            plot.addItem(h, ignoreBounds=True)
            self._crosshair_h.append(h)

    def _on_mouse_moved(self, pos) -> None:
        if self._crosshair_v is None:
            return
        for i, plot in enumerate(self._all_plots):
            if plot.sceneBoundingRect().contains(pos):
                mp = plot.vb.mapSceneToView(pos)
                self._crosshair_v.setPos(mp.x())
                self._crosshair_v.setVisible(True)
                self._crosshair_h[i].setPos(mp.y())
                self._crosshair_h[i].setVisible(True)
                for j, h in enumerate(self._crosshair_h):
                    if j != i:
                        h.setVisible(False)
                return
        self._crosshair_v.setVisible(False)
        for h in self._crosshair_h:
            h.setVisible(False)

    # ══════════════════════════════════════════════════════════════════════
    # Per-panel draw helpers
    # ══════════════════════════════════════════════════════════════════════

    def _clear_all_plots(self) -> None:
        for plot in self._all_plots:
            plot.clear()
        self._current_df = None
        self._current_options = None

    def _draw_candles(self, df: pd.DataFrame) -> None:
        self._price_plot.addItem(_CandlestickItem(df))

    def _draw_bollinger(self, df: pd.DataFrame, x: np.ndarray) -> None:
        up_col = _first_present(df, ("bb_20_1s_upper", "BB_Upper"))
        lo_col = _first_present(df, ("bb_20_1s_lower", "BB_Lower"))
        md_col = _first_present(df, ("bb_20_1s_mid", "BB_Mid"))
        if not up_col or not lo_col:
            return
        u = df[up_col].ffill().to_numpy(dtype=float)
        l = df[lo_col].ffill().to_numpy(dtype=float)
        uc = pg.PlotDataItem(x, u, pen=_BB_UPPER)
        lc = pg.PlotDataItem(x, l, pen=_BB_LOWER)
        self._price_plot.addItem(pg.FillBetweenItem(uc, lc, brush=_BB_FILL))
        self._price_plot.addItem(uc)
        self._price_plot.addItem(lc)
        if md_col:
            m = df[md_col].ffill().to_numpy(dtype=float)
            self._price_plot.addItem(pg.PlotDataItem(x, m, pen=_BB_MID))

    def _draw_vwap(self, df: pd.DataFrame, x: np.ndarray) -> None:
        if not self._show_vwap:
            return
        vwap = _compute_vwap(df)
        if vwap is None:
            return
        ok = ~np.isnan(vwap)
        if not ok.any():
            return
        self._price_plot.addItem(
            pg.PlotDataItem(x[ok], vwap[ok], pen=_VWAP_PEN, connect="finite"),
        )

    def _draw_smas(self, df: pd.DataFrame, x: np.ndarray) -> None:
        for col, colour, width in _SMA_LINES:
            if col not in df.columns:
                continue
            sma = df[col].ffill().to_numpy(dtype=float)
            ok = ~np.isnan(sma)
            if not ok.any():
                continue
            self._price_plot.addItem(
                pg.PlotDataItem(x[ok], sma[ok], pen=pg.mkPen(colour, width=width)),
            )

    def _draw_options_levels(
        self, options: OptionsContext | None, n: int,
    ) -> None:
        if options is None:
            return
        levels: tuple[tuple[float | None, str, Qt.PenStyle, str], ...] = (
            (options.resistance_wall, RED, Qt.PenStyle.DashLine, "R"),
            (options.support_wall, GREEN, Qt.PenStyle.DashLine, "S"),
            (options.max_pain, GOLD, Qt.PenStyle.DotLine, "MP"),
            (options.hvl, VIOLET, Qt.PenStyle.DashDotLine, "HVL"),
        )
        for yv, colour, dash, prefix in levels:
            if yv is None:
                continue
            self._price_plot.addItem(
                pg.InfiniteLine(
                    pos=float(yv), angle=0, movable=False,
                    pen=pg.mkPen(colour, width=0.8, style=dash),
                ),
            )
            lbl = pg.TextItem(
                f" {prefix} {float(yv):,.0f} ",
                color=colour,
                anchor=(0, 0.5),
                fill=pg.mkBrush(QColor(BG)),
                border=pg.mkPen(colour, width=0.5),
            )
            lbl.setFont(QFont(FONT_MONO, 7))
            lbl.setPos(n + 0.5, float(yv))
            self._price_plot.addItem(lbl)

    def _draw_volume(self, df: pd.DataFrame, x: np.ndarray) -> None:
        if "Volume" not in df.columns:
            return
        vols = df["Volume"].fillna(0).to_numpy(dtype=float)
        if vols.sum() <= 0:
            return
        opens = df["Open"].to_numpy(dtype=float)
        closes = df["Close"].to_numpy(dtype=float)
        brushes = [_VOL_UP if c >= o else _VOL_DOWN for o, c in zip(opens, closes)]
        self._vol_plot.addItem(
            pg.BarGraphItem(x=x, height=vols, width=0.7, brushes=brushes, pen=pg.mkPen(None)),
        )
        self._vol_plot.enableAutoRange(axis="y")
