"""nimbus_v3.conviction.formula — contribution functions for grading.

This module is the SINGLE SOURCE OF TRUTH for how inputs turn into a
numeric conviction score. The grade engine composes these functions
(``ConvictionEngine.grade``) but does not itself decide the shape of
the formula.

Architecture
────────────

A **contribution** is a pure function ``f(state, contexts, signal)``
that returns a ``Contribution`` record: a signed numeric score and a
human-readable reason. The final conviction score is the
weight-scaled sum of contributions, so every individual factor is
separately testable and tunable.

Weights
───────

Each contribution carries an implicit per-strategy weight via the
strategy's ``production_weight`` field. The grade engine multiplies
the sum of contributions by this weight, producing zero output for
research-only strategies (they still emit signals and feed
SignalTracker, but do not influence grades).

The per-contribution **scaling weights** defined in ``WEIGHTS`` below
control how much each named contribution matters within a single
strategy's score. These are the values that change as Phase 7
research refines the formula. Keeping them centralised means a
formula tweak is a single config edit, not a code change.

Validation-derived defaults (as of fresh-data OOS study, April 2026)
────────────────────────────────────────────────────────────────────
- MR has ~+2.0pp OOS lift at strict parameters. This is the primary
  signal. Its contributions are weighted fully.
- Breakout, Ride, ETF Momentum: no OOS-confirmed edge. Production
  weight on the *strategy* is 0, so their contributions multiply
  through to zero regardless of the scaling weights here.
- PullbackUptrend, DrawdownReversal: research-tier with positive
  OOS t-stats but small samples. Production weight 0.
- TRAP is handled specially — it forces ``Sizing.SKIP`` via the
  verdict layer, regardless of score.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import (
    RSRegime, SetupType, VIXRegime,
)
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Per-contribution scaling weights
# ══════════════════════════════════════════════════════════════════════════════
#
# These weights determine how much each contribution influences the
# total score BEFORE the per-strategy production_weight is applied.
# Tune here, not in the engine. Values are on a unitless scale;
# the grade engine maps the summed score to A/B/C/D via
# ``GRADE_THRESHOLDS``.

WEIGHTS: Final[dict[str, float]] = {
    # Core technical contributions.
    "mfi":            1.0,   # money-flow alignment with setup direction
    "volume":         1.0,   # volume ratio vs 20-bar avg
    "rsi":            1.0,   # oversold/overbought confirmation
    "divergence":     1.0,   # MFI slope vs price (hidden momentum)
    # Context contributions.
    "vix":            1.5,   # VIX regime — MR depends on this heavily
    "sector_rs":      0.8,   # sector relative strength
    "sector_vol":     0.6,   # sector realised volatility z-score
    # Operational penalties (contribution values are ALREADY signed;
    # weights here are positive magnitudes).
    "filing":         1.0,
    "day_of_week":    0.3,
}


# ══════════════════════════════════════════════════════════════════════════════
# Contribution record
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class Contribution:
    """One named contribution to a conviction score.

    Attributes:
        name: Short key — matches a key in :data:`WEIGHTS`.
        value: Signed raw score, typically in [-1.0, +1.0].
        reason: Human-readable explanation (one sentence). Used by the
            conviction panel in the UI and by the signal-tracker log.
    """
    name: str
    value: float
    reason: str

    @property
    def weighted(self) -> float:
        """Return ``value * WEIGHTS[name]``. Unknown names get weight 1.0
        (tolerant default so new contributions can be added without
        breaking existing callers)."""
        return self.value * WEIGHTS.get(self.name, 1.0)


# ══════════════════════════════════════════════════════════════════════════════
# Individual contribution functions
# ══════════════════════════════════════════════════════════════════════════════
#
# Each function returns ``Contribution(name, value, reason)`` where
# ``value`` is on roughly a [-1, +1] scale. The engine sums the
# weighted contributions.

def mfi_contribution(
    state: SignalState, signal: StrategySignal,
) -> Contribution:
    """Money Flow Index alignment with the setup direction.

    For LONG setups (MR, Breakout, Ride, pullbacks, etc.):
      - MFI < 20 (oversold)      → +1.0 for reversal setups, +0.0 for continuation
      - MFI in [20, 40]          → +0.5 mild oversold, supportive
      - MFI in [40, 60]          → +0.0 neutral
      - MFI in [60, 80]          → +0.5 for continuation, -0.3 for reversal
      - MFI > 80 (overbought)    → -0.7 for continuation, -1.0 for reversal

    For SHORT setups: signs flip. v3.0 ships LONG only, but the
    function handles both for future-proofing.
    """
    mfi = state.mfi_14
    is_reversal = signal.setup_type in (
        SetupType.MEAN_REVERSION, SetupType.DRAWDOWN_REVERSAL,
    )
    is_short = signal.direction == "SHORT"

    # Base value for a LONG setup.
    if mfi < 20:
        raw = +1.0 if is_reversal else 0.0
        reason = f"MFI {mfi:.0f} deeply oversold"
    elif mfi < 40:
        raw = +0.5
        reason = f"MFI {mfi:.0f} mild oversold"
    elif mfi < 60:
        raw = 0.0
        reason = f"MFI {mfi:.0f} neutral"
    elif mfi < 80:
        raw = +0.5 if not is_reversal else -0.3
        reason = f"MFI {mfi:.0f} strong inflow" if not is_reversal else f"MFI {mfi:.0f} high for reversal setup"
    else:
        raw = -0.7 if not is_reversal else -1.0
        reason = f"MFI {mfi:.0f} overbought"

    if is_short:
        raw = -raw
    return Contribution("mfi", raw, reason)


def volume_contribution(state: SignalState) -> Contribution:
    """Volume ratio vs 20-bar average.

    Higher volume relative to average suggests conviction behind the
    move. The curve is monotonic until ~3.0× (beyond which it's
    treated as noise or event-driven).

    - ratio < 0.8   → -0.5 anaemic
    - ratio in [0.8, 1.2]  → 0.0
    - ratio in [1.2, 2.0]  → +0.5
    - ratio in [2.0, 3.0]  → +1.0
    - ratio >= 3.0          → +0.8 (capped — suspiciously high)
    """
    r = state.vol_ratio_20
    if r < 0.8:
        return Contribution("volume", -0.5, f"volume ratio {r:.2f} anaemic")
    if r < 1.2:
        return Contribution("volume", 0.0, f"volume ratio {r:.2f} normal")
    if r < 2.0:
        return Contribution("volume", +0.5, f"volume ratio {r:.2f} above average")
    if r < 3.0:
        return Contribution("volume", +1.0, f"volume ratio {r:.2f} strong")
    return Contribution("volume", +0.8, f"volume ratio {r:.2f} very high (capped)")


def rsi_contribution(
    state: SignalState, signal: StrategySignal,
) -> Contribution:
    """RSI alignment with setup direction.

    Reversal setups (MR, DRAWDOWN_REVERSAL) want oversold;
    continuation setups (BO, RIDE, PULLBACK) want 'not overbought'.
    """
    rsi = state.rsi_14
    is_reversal = signal.setup_type in (
        SetupType.MEAN_REVERSION, SetupType.DRAWDOWN_REVERSAL,
    )

    if is_reversal:
        if rsi < 25:
            return Contribution("rsi", +1.0, f"RSI {rsi:.0f} deeply oversold")
        if rsi < 35:
            return Contribution("rsi", +0.7, f"RSI {rsi:.0f} oversold")
        if rsi < 50:
            return Contribution("rsi", +0.2, f"RSI {rsi:.0f} mild oversold")
        if rsi < 70:
            return Contribution("rsi", -0.3, f"RSI {rsi:.0f} neutral to high")
        return Contribution("rsi", -0.8, f"RSI {rsi:.0f} overbought — bad reversal setup")

    # Continuation.
    if rsi > 75:
        return Contribution("rsi", -0.5, f"RSI {rsi:.0f} overbought — extended")
    if rsi > 60:
        return Contribution("rsi", +0.3, f"RSI {rsi:.0f} momentum intact")
    if rsi > 45:
        return Contribution("rsi", +0.1, f"RSI {rsi:.0f} mild bullish")
    return Contribution("rsi", -0.2, f"RSI {rsi:.0f} weak for continuation")


def divergence_contribution(state: SignalState) -> Contribution:
    """MFI slope direction — money flow building or receding?

    Positive slope = money is flowing in faster than recently.
    Negative slope = money is flowing out or decelerating.
    Magnitude ignored here (already captured in ``mfi_contribution``).
    """
    slope = state.mfi_slope_3
    if slope > 3.0:
        return Contribution("divergence", +0.7, f"MFI slope +{slope:.1f} strong inflow")
    if slope > 0.5:
        return Contribution("divergence", +0.3, f"MFI slope +{slope:.1f} turning up")
    if slope > -0.5:
        return Contribution("divergence", 0.0, f"MFI slope {slope:+.1f} flat")
    if slope > -3.0:
        return Contribution("divergence", -0.3, f"MFI slope {slope:+.1f} turning down")
    return Contribution("divergence", -0.7, f"MFI slope {slope:+.1f} strong outflow")


def vix_contribution(
    contexts: ContextBundle, signal: StrategySignal,
) -> Contribution:
    """VIX regime interacts differently with each setup type.

    MR's edge depends on ``vix_streak >= 6`` — a strong contribution
    when in HIGH regime. Breakout/Ride/continuation setups prefer
    calm-to-normal regimes. Counter-cyclical setups (DRAWDOWN_REVERSAL)
    are ambivalent about VIX regime.
    """
    regime = contexts.market.vix_regime
    streak = contexts.market.vix_high_streak
    setup = signal.setup_type

    if setup == SetupType.MEAN_REVERSION:
        # Primary: MR loves HIGH regimes.
        if regime == VIXRegime.HIGH and streak >= 6:
            return Contribution("vix", +1.0,
                f"VIX HIGH regime, streak {streak} — MR sweet spot")
        if regime == VIXRegime.HIGH:
            return Contribution("vix", +0.5,
                f"VIX HIGH regime, streak {streak} — MR edge still present")
        if regime == VIXRegime.ELEVATED:
            return Contribution("vix", +0.2, "VIX ELEVATED — partial MR support")
        return Contribution("vix", -0.5, "VIX NORMAL — MR edge not established")

    if setup in (SetupType.BREAKOUT, SetupType.RIDE,
                   SetupType.ETF_MOMENTUM, SetupType.PULLBACK_IN_UPTREND):
        # Continuation/trend setups prefer calm.
        if regime == VIXRegime.NORMAL:
            return Contribution("vix", +0.5, "VIX NORMAL — trend setups favoured")
        if regime == VIXRegime.ELEVATED:
            return Contribution("vix", 0.0, "VIX ELEVATED — cautious")
        return Contribution("vix", -0.5, "VIX HIGH — trend setups struggle")

    if setup == SetupType.DRAWDOWN_REVERSAL:
        # Counter-cyclical by design; ambivalent.
        return Contribution("vix", 0.0, "DRAWDOWN_REVERSAL ambivalent to VIX")

    return Contribution("vix", 0.0, f"no VIX rule for {setup.value}")


def sector_rs_contribution(
    contexts: ContextBundle, signal: StrategySignal,
) -> Contribution:
    """Sector relative strength vs broad market.

    Continuation setups prefer LEADING sectors. Reversal setups are
    ambivalent (oversold-in-strong-sector is fine, oversold-in-weak-
    sector is also fine — these are separate strategies we grade but
    don't filter on RS).
    """
    if contexts.sector is None:
        return Contribution("sector_rs", 0.0, "no sector context")
    rs = contexts.sector.rs_regime
    rs_20d = contexts.sector.rs_20d
    setup = signal.setup_type

    is_reversal = setup in (
        SetupType.MEAN_REVERSION, SetupType.DRAWDOWN_REVERSAL,
    )
    if is_reversal:
        # Mild preference for LEADING (mean-reversion has further to run
        # in a strong sector) but not structural.
        if rs == RSRegime.LEADING:
            return Contribution("sector_rs", +0.3, f"sector leading ({rs_20d:+.1f}pp) — MR in strength")
        if rs == RSRegime.LAGGING:
            return Contribution("sector_rs", -0.2, f"sector lagging ({rs_20d:+.1f}pp) — broader weakness risk")
        return Contribution("sector_rs", 0.0, f"sector RS neutral ({rs_20d:+.1f}pp)")

    # Continuation/trend — want LEADING.
    if rs == RSRegime.LEADING:
        return Contribution("sector_rs", +0.8, f"sector leading ({rs_20d:+.1f}pp) — trend-aligned")
    if rs == RSRegime.LAGGING:
        return Contribution("sector_rs", -0.8, f"sector lagging ({rs_20d:+.1f}pp) — fighting the tide")
    return Contribution("sector_rs", 0.0, f"sector RS neutral ({rs_20d:+.1f}pp)")


def sector_vol_contribution(contexts: ContextBundle) -> Contribution:
    """Sector realised-vol z-score.

    High z-score → sector is in stress. This is a mild boost for
    mean-reversion (MR setups in stressed sectors have the most room)
    and a penalty for continuation setups. The effect is milder than
    VIX because it's sector-local.
    """
    if contexts.sector is None or contexts.sector.vol_z_score is None:
        return Contribution("sector_vol", 0.0, "no sector vol context")
    z = contexts.sector.vol_z_score

    if z > 2.0:
        return Contribution("sector_vol", +0.4,
            f"sector vol z={z:+.1f} stressed")
    if z > 1.0:
        return Contribution("sector_vol", +0.2,
            f"sector vol z={z:+.1f} elevated")
    if z > -1.0:
        return Contribution("sector_vol", 0.0,
            f"sector vol z={z:+.1f} normal")
    return Contribution("sector_vol", -0.2,
        f"sector vol z={z:+.1f} suppressed")


def filing_contribution(contexts: ContextBundle) -> Contribution:
    """Filing-impact penalty.

    NOTE: TRAP filings are a HARD STOP handled in the grade engine
    (they force ``Sizing.SKIP`` regardless of score). This
    contribution only handles the softer MATERIAL / MINOR impact
    levels, where we still grade but apply a penalty.
    """
    if contexts.filing is None:
        return Contribution("filing", 0.0, "no filing in window")
    impact = contexts.filing.latest_impact
    from nimbus_v3.core.types import FilingImpact
    if impact == FilingImpact.TRAP:
        # Engine will override; neutral here to avoid double-counting.
        return Contribution("filing", 0.0,
            "TRAP filing — handled by verdict/sizing override")
    if impact == FilingImpact.MATERIAL:
        return Contribution("filing", -0.5,
            f"material filing {contexts.filing.days_since_latest}d ago")
    if impact == FilingImpact.MINOR:
        return Contribution("filing", -0.1,
            f"minor filing {contexts.filing.days_since_latest}d ago")
    return Contribution("filing", 0.0, "no material filing")


def day_of_week_contribution(signal: StrategySignal) -> Contribution:
    """Friday penalty — weekend gap risk on LONG positions.

    Small penalty to discourage fresh entries into the weekend.
    Applies to every setup.
    """
    dow = signal.asof_date.day_of_week     # Mon=0, Fri=4, Sun=6
    if dow == 4:
        return Contribution("day_of_week", -1.0, "Friday — weekend gap risk")
    return Contribution("day_of_week", 0.0, f"intraweek day {dow}")


# ══════════════════════════════════════════════════════════════════════════════
# Assembly
# ══════════════════════════════════════════════════════════════════════════════

def compute_contributions(
    state: SignalState,
    contexts: ContextBundle,
    signal: StrategySignal,
) -> list[Contribution]:
    """Compute every contribution for a (state, contexts, signal) triple.

    Order is fixed: technicals first, then context, then penalties.
    The engine expects this order for deterministic golden-fixture
    comparison.
    """
    return [
        mfi_contribution(state, signal),
        volume_contribution(state),
        rsi_contribution(state, signal),
        divergence_contribution(state),
        vix_contribution(contexts, signal),
        sector_rs_contribution(contexts, signal),
        sector_vol_contribution(contexts),
        filing_contribution(contexts),
        day_of_week_contribution(signal),
    ]
