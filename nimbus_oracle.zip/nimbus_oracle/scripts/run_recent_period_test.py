#!/usr/bin/env python3
"""
scripts/run_recent_period_test.py — Head-to-head OOS test for OLD vs NEW
mean-reversion parameters over a specific recent date range.

Background:
    The robust sweep walkforward (2026-04-08) tested both parameter sets
    over Oct 2021 → May 2024. The Nov 2024 → Apr 2026 period — which
    contains the regime change that broke the old strategy in production —
    was NOT in the walkforward test set because it falls beyond the most
    recent fold's test window.

    This script directly answers: "Do the new robust-sweep params survive
    the recent period that broke the old params?"

What this does:
    1. Downloads ~6 years of NSE data for the NIFTY 200 universe
    2. Slices to the user-specified date range (default: 2024-11-01 →
       today)
    3. Runs simulate() with TWO parameter sets:
         OLD = the previous live values (DD<=-5, Streak>=2, Vol>=0.5,
                primary_only=False — both PRIMARY and SECONDARY tiers)
         NEW = the current dual_mode.py values (DD<=-8, Streak>=4,
                Vol>=1.5, primary_only=True — PRIMARY only)
    4. Reports head-to-head: trade count, win rate, avg, sharpe, PF,
       exit reason distribution, and per-month breakdown if enough data

Usage:
    python3 scripts/run_recent_period_test.py
    python3 scripts/run_recent_period_test.py --start 2024-11-01 --end 2026-04-08
    python3 scripts/run_recent_period_test.py --n 100  # smaller universe for speed

Output:
    Console + report file at data/reports/run_recent_period_test_<ts>.txt
    CSV at data/backtest_results/recent_period_comparison.csv
"""
import sys, os, argparse, datetime, logging, time
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.output import enable_export
enable_export()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("recent_period")

import numpy as np
import pandas as pd

# Reuse the walkforward's simulate() and compute_indicators() — single
# source of truth for entry/exit logic. No reimplementation.
from scripts.run_walkforward import simulate, compute_indicators, calc_stats, UNIVERSE_SYMBOLS


# ══════════════════════════════════════════════════════════════════════════════
# PARAMETER SETS
# ══════════════════════════════════════════════════════════════════════════════

# OLD = the live constants BEFORE the 2026-04-08 robust sweep upgrade.
# Captured here as literals (NOT imported from dual_mode.py) because
# dual_mode.py now has the NEW values. This is the "previous production"
# baseline we're comparing against.
OLD_PARAMS = {
    "wr_period": 30,
    "wr_thresh": -30,
    "sma_period": 20,
    "mfi_min": 30,
    "dd_thresh": -5.0,         # was -5
    "streak_min": 2,           # was 2
    "vol_min_ratio": 0.5,      # was 0.5
    "profit_target": 5.0,
    "max_hold": 30,
    "hard_stop_pct": -5.0,
    "bar_ratchet": 8,
    "trail_atr_mult": 1.5,
    "max_trail_pct": 4.0,
    "primary_only": False,     # was both PRIMARY and SECONDARY tiers
}

# NEW = current dual_mode.py constants. Imported live so this script
# stays accurate if dual_mode constants change.
def _new_params():
    from modules.dual_mode import (
        WR_PERIOD, WR_THRESH, SMA_PERIOD, MFI_MIN,
        DD_MODERATE, RED_STREAK_MIN, VOL_MIN_RATIO,
        PROFIT_TARGET, MAX_HOLD,
        HARD_STOP_PCT, BAR_RATCHET, TRAIL_ATR_MULT, MAX_TRAIL_PCT,
        ENABLE_SECONDARY_TIER,
    )
    return {
        "wr_period": WR_PERIOD,
        "wr_thresh": WR_THRESH,
        "sma_period": SMA_PERIOD,
        "mfi_min": MFI_MIN,
        "dd_thresh": DD_MODERATE,
        "streak_min": RED_STREAK_MIN,
        "vol_min_ratio": VOL_MIN_RATIO,
        "profit_target": PROFIT_TARGET,
        "max_hold": MAX_HOLD,
        "hard_stop_pct": HARD_STOP_PCT,
        "bar_ratchet": BAR_RATCHET,
        "trail_atr_mult": TRAIL_ATR_MULT,
        "max_trail_pct": MAX_TRAIL_PCT,
        "primary_only": not ENABLE_SECONDARY_TIER,
    }


def _label(p):
    po = "PRI" if p.get("primary_only") else "ALL"
    return (f"{po} DD<={p['dd_thresh']:.0f} Str>={p['streak_min']} "
            f"Vol>={p['vol_min_ratio']:.1f} PT{p['profit_target']:.0f}%")


# ══════════════════════════════════════════════════════════════════════════════
# DATE RANGE SLICING
# ══════════════════════════════════════════════════════════════════════════════

def slice_universe_by_date(universe, start_date, end_date):
    """Slice each symbol's df to [start_date, end_date]. Returns sliced dict."""
    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    sliced = {}
    for sym, df in universe.items():
        idx = df.index
        if idx.tz is not None:
            idx = idx.tz_localize(None)
            df = df.copy()
            df.index = idx
        # Need indicator warmup before start_date — keep ~100 prior bars
        warmup_start = start_ts - pd.Timedelta(days=180)
        mask = (df.index >= warmup_start) & (df.index <= end_ts)
        sub = df[mask]
        if len(sub) >= 100:
            sliced[sym] = sub
    return sliced, start_ts, end_ts


def find_test_window_indices(df, start_ts, end_ts):
    """Return (start_idx, end_idx) within df for the test date range.
    Bars before start_ts are warmup; bars within [start_ts, end_ts] are test."""
    # First bar at or after start_ts is the entry window opening
    after_start = df.index >= start_ts
    if not after_start.any():
        return None, None
    start_idx = int(np.argmax(after_start))
    # Last bar at or before end_ts
    at_or_before_end = df.index <= end_ts
    end_idx = int(np.where(at_or_before_end)[0].max()) + 1 if at_or_before_end.any() else len(df)
    return start_idx, end_idx


# ══════════════════════════════════════════════════════════════════════════════
# BY-MONTH BREAKDOWN
# ══════════════════════════════════════════════════════════════════════════════

def monthly_breakdown(trades):
    """Group trades by entry month and compute per-month stats."""
    if not trades:
        return []
    by_month = {}
    for t in trades:
        try:
            ed = pd.Timestamp(t["entry_date"])
            key = f"{ed.year}-{ed.month:02d}"
        except Exception:
            continue
        by_month.setdefault(key, []).append(t["pnl_pct"])
    rows = []
    for month in sorted(by_month.keys()):
        pnls = by_month[month]
        s = calc_stats(pnls)
        rows.append({
            "month": month,
            "n": s["n"],
            "win": s["win"],
            "avg": s["avg"],
            "sharpe": s["sharpe"],
            "pf": s["pf"],
        })
    return rows


# ══════════════════════════════════════════════════════════════════════════════
# REPORT
# ══════════════════════════════════════════════════════════════════════════════

def report_config(label, params, all_trades):
    logger.info("")
    logger.info("─" * 80)
    logger.info("%s — %s", label, _label(params))
    logger.info("─" * 80)

    if not all_trades:
        logger.info("  No trades fired in this window")
        return

    pnls = [t["pnl_pct"] for t in all_trades]
    s = calc_stats(pnls)
    pri_pnls = [t["pnl_pct"] for t in all_trades if t["tier"] == "PRIMARY"]
    sec_pnls = [t["pnl_pct"] for t in all_trades if t["tier"] == "SECONDARY"]

    logger.info("  N=%d  Sharpe=%.2f  Win=%.1f%%  Avg=%+.3f%%  PF=%.2f",
                 s["n"], s["sharpe"], s["win"], s["avg"], s["pf"])
    if pri_pnls and sec_pnls:
        ps = calc_stats(pri_pnls)
        ss = calc_stats(sec_pnls)
        logger.info("    PRIMARY:   N=%d  Sh=%.2f  W=%.1f%%  Avg=%+.3f%%",
                     ps["n"], ps["sharpe"], ps["win"], ps["avg"])
        logger.info("    SECONDARY: N=%d  Sh=%.2f  W=%.1f%%  Avg=%+.3f%%",
                     ss["n"], ss["sharpe"], ss["win"], ss["avg"])

    # Exit reasons
    logger.info("  Exit reasons:")
    n_total = len(all_trades)
    for reason, cnt in Counter(t["exit_reason"] for t in all_trades).most_common():
        rs = calc_stats([t["pnl_pct"] for t in all_trades if t["exit_reason"] == reason])
        pct = cnt / n_total * 100
        logger.info("    %-12s: N=%4d (%4.1f%%)  W=%5.1f%%  Avg=%+.3f%%",
                     reason, cnt, pct, rs["win"], rs["avg"])

    # Monthly breakdown
    rows = monthly_breakdown(all_trades)
    if len(rows) >= 2:
        logger.info("  By month (entry date):")
        logger.info("    %-9s %-5s %-7s %-8s %-7s",
                     "Month", "N", "Win%", "Avg%", "Sharpe")
        for r in rows:
            logger.info("    %-9s %5d  %5.1f%%  %+6.2f%%  %+5.2f",
                         r["month"], r["n"], r["win"], r["avg"], r["sharpe"])


def head_to_head(old_trades, new_trades):
    logger.info("")
    logger.info("=" * 80)
    logger.info("HEAD-TO-HEAD COMPARISON")
    logger.info("=" * 80)

    o = calc_stats([t["pnl_pct"] for t in old_trades]) if old_trades else None
    n = calc_stats([t["pnl_pct"] for t in new_trades]) if new_trades else None

    def fmt(s, key, fmt_str="%.3f"):
        if s is None:
            return "—"
        return fmt_str % s[key]

    logger.info("                    OLD        NEW        Δ")
    logger.info("  Trade count:    %6d    %6d     %+d",
                 o["n"] if o else 0, n["n"] if n else 0,
                 (n["n"] if n else 0) - (o["n"] if o else 0))
    if o and n:
        logger.info("  Win rate:       %5.1f%%    %5.1f%%     %+.1fpp",
                     o["win"], n["win"], n["win"] - o["win"])
        logger.info("  Avg per trade:  %+5.2f%%   %+5.2f%%    %+.2fpp",
                     o["avg"], n["avg"], n["avg"] - o["avg"])
        logger.info("  Sharpe:         %+5.2f    %+5.2f      %+.2f",
                     o["sharpe"], n["sharpe"], n["sharpe"] - o["sharpe"])
        logger.info("  Profit factor:   %4.2f     %4.2f      %+.2f",
                     o["pf"], n["pf"], n["pf"] - o["pf"])

    logger.info("")
    if o and n:
        if n["sharpe"] > o["sharpe"] and n["pf"] > o["pf"]:
            logger.info("VERDICT: NEW params outperform OLD on this period — strategy")
            logger.info("         upgrade survives the regime that broke the old config.")
            logger.info("         Safe to deploy.")
        elif n["sharpe"] > 0 and o["sharpe"] < 0:
            logger.info("VERDICT: NEW params POSITIVE on this period, OLD was NEGATIVE.")
            logger.info("         Strategy upgrade fixes the regime break. Deploy.")
        elif n["sharpe"] < 0 and o["sharpe"] < 0:
            logger.info("VERDICT: BOTH configs lose money on this period.")
            logger.info("         The regime change breaks the strategy regardless of")
            logger.info("         entry filter strictness. Investigate before deploying.")
        elif n["sharpe"] < 0 and o["sharpe"] > 0:
            logger.info("VERDICT: NEW is WORSE than OLD on this period. Unexpected —")
            logger.info("         the robust sweep window may have favored the strict")
            logger.info("         filter for reasons that don't generalize. Reconsider.")
        else:
            logger.info("VERDICT: Mixed result. NEW Sharpe=%+.2f vs OLD Sharpe=%+.2f.",
                         n["sharpe"], o["sharpe"])
            logger.info("         Make a judgment call based on the per-month breakdown.")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(description="OLD vs NEW MR params on a recent date range")
    ap.add_argument("--start", type=str, default="2024-11-01",
                    help="Test window start (YYYY-MM-DD, default 2024-11-01)")
    ap.add_argument("--end", type=str, default=None,
                    help="Test window end (YYYY-MM-DD, default today)")
    ap.add_argument("--n", type=int, default=200,
                    help="Number of NIFTY 200 symbols (default 200)")
    ap.add_argument("--years", type=int, default=6,
                    help="Years of history to download (default 6, must include test window + warmup)")
    args = ap.parse_args()

    end_date = args.end or datetime.date.today().isoformat()
    start_date = args.start

    t0 = time.time()
    logger.info("=" * 80)
    logger.info("RECENT PERIOD HEAD-TO-HEAD: OLD vs NEW MR params")
    logger.info("=" * 80)
    logger.info("Test window: %s → %s", start_date, end_date)
    logger.info("Universe:    NIFTY 200 (top %d symbols)", args.n)
    logger.info("History:     %d years (download)", args.years)
    logger.info("")
    logger.info("OLD config:  %s", _label(OLD_PARAMS))
    logger.info("NEW config:  %s", _label(_new_params()))
    logger.info("")

    # Download
    logger.info("Downloading %d symbols, %dyr...", args.n, args.years)
    from backtest.data_loader import download_batch
    symbols = UNIVERSE_SYMBOLS[:args.n]
    raw = download_batch(symbols, years=args.years)
    logger.info("Loaded %d symbols", len(raw))

    # Compute indicators
    logger.info("Computing indicators...")
    universe = {}
    for sym, df in raw.items():
        if len(df) >= 100:
            universe[sym] = compute_indicators(df)
    logger.info("Ready: %d symbols", len(universe))

    # Slice to test window (with warmup)
    sliced, start_ts, end_ts = slice_universe_by_date(universe, start_date, end_date)
    logger.info("After slicing to %s → %s: %d symbols",
                 start_date, end_date, len(sliced))
    if not sliced:
        logger.error("No symbols have data in the test window. Check --start / --end.")
        return

    # Run both configs over the test window
    new_params = _new_params()
    old_trades_all = []
    new_trades_all = []

    for sym, df in sliced.items():
        s_idx, e_idx = find_test_window_indices(df, start_ts, end_ts)
        if s_idx is None or e_idx is None:
            continue
        if s_idx < 60:
            s_idx = 60  # respect simulate's warmup floor

        old_t = simulate(df, s_idx, e_idx, OLD_PARAMS)
        for t in old_t:
            t["symbol"] = sym
        old_trades_all.extend(old_t)

        new_t = simulate(df, s_idx, e_idx, new_params)
        for t in new_t:
            t["symbol"] = sym
        new_trades_all.extend(new_t)

    # Reports
    report_config("OLD", OLD_PARAMS, old_trades_all)
    report_config("NEW", new_params, new_trades_all)
    head_to_head(old_trades_all, new_trades_all)

    # Save CSV with both
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out = os.path.join(project_root, "data", "backtest_results")
    os.makedirs(out, exist_ok=True)

    rows = []
    for t in old_trades_all:
        rows.append({**t, "config": "OLD"})
    for t in new_trades_all:
        rows.append({**t, "config": "NEW"})
    if rows:
        df_out = pd.DataFrame(rows)
        out_path = os.path.join(out, "recent_period_comparison.csv")
        df_out.to_csv(out_path, index=False)
        logger.info("")
        logger.info("Detail CSV: %s (%d trades)", out_path, len(rows))

    logger.info("Complete in %.1f min", (time.time() - t0) / 60)


if __name__ == "__main__":
    main()
