"""nimbus_v3.compute.market_pulse_common — shared cross-engine primitives.

Small helpers used by more than one Market Pulse engine, centralised so
the definitions can't drift apart. In particular the *benchmark-relative
relative-strength* of an industry — the single definition of "how much is
this industry out/under-performing the market" — lives here, so the
Confluence strength factor and the Edge RS-excess anchor are guaranteed to
be the same number (they used to be two subtly different definitions that
could disagree in sign).
"""
from __future__ import annotations

import pandas as pd


def window_return_pct(close: pd.Series, lookback: int) -> float:
    """Percent return of a close series over the trailing ``lookback`` bars.

    NaN when there is too little history or the base is non-positive.
    """
    if close is None:
        return float("nan")
    c = close.dropna()
    if c.shape[0] < 2:
        return float("nan")
    tail = c.iloc[-lookback:] if c.shape[0] > lookback else c
    first = tail.iloc[0]
    last = tail.iloc[-1]
    if first == 0 or first != first or last != last:
        return float("nan")
    return (last / first - 1.0) * 100.0


def industry_rs_excess(
    industry_roc: dict[str, float],
    benchmark_return: float,
) -> dict[str, float]:
    """The single, shared definition of benchmark-relative industry
    strength: each industry's composite return over the window MINUS the
    benchmark's return over the same window.

    Args:
        industry_roc: ``{industry: composite ROC %}`` — the absolute
            composite return over the strength window (from the rotation
            engine).
        benchmark_return: the benchmark's % return over the same window
            (0 if unavailable, i.e. excess vs a flat benchmark).

    Returns:
        ``{industry: rs_excess %}``. Positive = out-performing the market.
    """
    b = benchmark_return if benchmark_return == benchmark_return else 0.0
    return {ind: (roc - b) for ind, roc in industry_roc.items()
            if roc == roc}
