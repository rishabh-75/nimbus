"""nimbus_v3.strategies.breakout — equity momentum continuation setup.

⚠ **OOS validation result (2025-01 → 2026-04)**: this strategy
underperformed universe baseline by 0.91pp on out-of-sample data
even after the in-sample ablation cleanup. Phase 4 should treat
Breakout as a **research-only signal**: it accumulates SignalTracker
records but does not contribute to live grades. See
``out/OOS_VALIDATION_REPORT.md`` for the full reasoning.

The setup is intentionally minimal after the in-sample validation
study (``scripts/run_strategy_validation.py``) showed that the
historical ``vol_ratio_20 >= 1.5`` and ``vix_high_streak >= 4`` gates
were *destroying* alpha rather than contributing — a finding that
turned out to be misleading when the OOS test was applied: those gates
had also been protecting against drawdowns of the kind seen in 2025.

Validation result driving the redesign
──────────────────────────────────────

| Gate set                                           | n      | mean 10d |
|---------------------------------------------------|-------:|---------:|
| Old: roc_20≥5 + vol_ratio≥1.5 + vix_streak≥4      | 1,630  | +1.09%   |
| Old set without vol_ratio_20                      | 9,233  | +1.57%   |
| Old set without vix_streak                        | 12,725 | +1.27%   |

Tightening ``vol_ratio`` from 1.0 → 3.0 monotonically *reduces* mean
forward return (+1.43% → +0.23%). The "volume confirms breakout"
intuition does not survive ablation on the v2 NIFTY-200 panel.

Current entry gate
──────────────────
- ``state.roc_20 > 7.0``   — 20-bar uptrend, tightened from 5.0 per the
                             roc_20 sweep (mean 10d +1.33% at 7 vs +1.09% at 5).
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class BreakoutParams:
    #: Tightened from 5.0 → 7.0 per the validation sweep:
    #:    roc_20=5  → mean 10d +1.09%, t=+5.62
    #:    roc_20=7  → mean 10d +1.33%, t=+5.96
    roc_20_min: float = 7.0


class BreakoutStrategy:
    """Momentum-breakout equity setup. Rejects ETFs.

    Note: ``data_sufficient`` is not a gate here — the scan engine is
    expected to only invoke ``evaluate`` on warmed-up states.
    """

    name: str = "Breakout"
    setup_type: SetupType = SetupType.BREAKOUT
    priority: int = 50
    production_weight: float = 0.0   # failed OOS validation — research-only

    def __init__(self, params: BreakoutParams = BreakoutParams()) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — no context-driven gates
    ) -> StrategySignal | None:
        if state.roc_20 <= self._p.roc_20_min:
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={"roc_20": state.roc_20},
        )
