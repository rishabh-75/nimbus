"""nimbus_v3.ui.widgets.price_chart — 2-panel price + volume chart.

Scope, per locked decision: **price + volume + levels only**. No W%R or
MFI subplots on the chart — those live in the conviction panel's
contribution breakdown, not on the price axis. The chart is a visual
anchor, not a dashboard.

What's on the chart
───────────────────
    ┌ Price plot  (75%) ── candles · BB bands + fill + dashed mid
    │                     · SMA(20/50/200) · VWAP (intraday)
    │                     · wall lines + right-margin labels
    │                       ("R 25,430")
    └ Volume plot (25%) ── up/down-coloured bars · "1.9M / 340K" ticks
                          · date axis

Public API (locked):
    :meth:`set_data(df, options=None, bars=...)`  ·  :meth:`clear()`

Enriched-panel column probing
─────────────────────────────
Recognises both v3 (``bb_20_1s_upper / _mid / _lower``, ``sma_N``)
and oracle (``BB_Upper / BB_Mid / BB_Lower``) naming via
``_first_present``, so the same widget renders a v3 enriched frame
*or* a raw frame that only has OHLCV.

OptionsContext shape
────────────────────
Oracle used ``ctx.walls.*``/``ctx.gex.hvl``; v3's :class:`OptionsContext`
is flat — we read ``support_wall / resistance_wall / max_pain / hvl``.

Volume axis scientific-notation fix
───────────────────────────────────
pyqtgraph's ``AxisItem`` applies an auto-SI-prefix scale factor when
values are large — that's what overrode the ``tickStrings`` output and
caused "×10⁶" to appear on the right side of the volume panel.
``enableAutoSIPrefix(False)`` disables the overlay so the "1.9M / 340K"
strings render cleanly.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pyqtgraph as pg
from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtGui import QColor, QFont, QPainter, QPicture
from PyQt6.QtWidgets import QPushButton, QVBoxLayout, QWidget

from nimbus_v3.compute.indicators import vwap as compute_vwap
from nimbus_v3.compute.volume_profile import compute_volume_profile
from nimbus_v3.core.context import OptionsContext
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, EM, FONT_MONO, GOLD, GREEN, MUTED, RED, S2, VIOLET, WHITE,
)


# ══════════════════════════════════════════════════════════════════════════════
# Pens / brushes — constructed once at import time
# ══════════════════════════════════════════════════════════════════════════════

_UP = "#26A69A"     # bullish candle fill
_DOWN = "#EF5350"   # bearish candle fill

_BB_UPPER = pg.mkPen("#BEBEC8", width=1.8)
_BB_LOWER = pg.mkPen("#BEBEC8", width=1.8)
_BB_MID = pg.mkPen("#F59E0B", width=1.2, style=Qt.PenStyle.DashLine)
_BB_FILL = pg.mkBrush(200, 200, 210, 18)

_VWAP_PEN = pg.mkPen("#E2E8F0", width=1.0, style=Qt.PenStyle.DotLine)
_CROSS_PEN = pg.mkPen(BORDER, width=0.6, style=Qt.PenStyle.DashLine)

_VOL_UP = pg.mkBrush(38, 166, 154, 180)
_VOL_DOWN = pg.mkBrush(239, 83, 80, 180)

# SMA lines — (column name, colour, line width).
_SMA_LINES: tuple[tuple[str, str, float], ...] = (
    ("sma_20", MUTED, 0.9),
    ("sma_50", BLUE, 1.1),
    ("sma_200", VIOLET, 0.9),
)

#: Consistent right-side Y axis width so the two panels align.
#: 52px fits 5-character price labels at 7pt mono ("1234.5", "30.0M")
#: with breathing room. Going from 64→52 closes the dead-zone
#: between the rightmost candle and the workflow column on its right.
_Y_AXIS_W = 52


# ══════════════════════════════════════════════════════════════════════════════
# Axis items — date on bottom of volume panel, human-readable volume ticks
# ══════════════════════════════════════════════════════════════════════════════

class _DateAxisItem(pg.AxisItem):
    """X-axis that maps integer bar indices to date / time strings."""

    def __init__(self, timestamps=None, *a, **kw):
        super().__init__(*a, **kw)
        self._ts: list = list(timestamps or [])
        self.setStyle(tickFont=QFont(FONT_MONO, 7))

    def set_timestamps(self, ts) -> None:
        self._ts = list(ts)

    def tickStrings(self, values, scale, spacing):    # noqa: N802
        out: list[str] = []
        prev_date: str | None = None
        for v in values:
            i = int(round(v))
            if 0 <= i < len(self._ts):
                t = self._ts[i]
                if isinstance(t, pd.Timestamp):
                    t = t.to_pydatetime()
                d = t.strftime("%d %b")
                # Show the date on a day-change, time otherwise, so
                # intraday charts don't repeat "13 Nov" every tick.
                out.append(d if d != prev_date else t.strftime("%H:%M"))
                prev_date = d
            else:
                out.append("")
        return out


class _VolumeAxisItem(pg.AxisItem):
    """Format volume ticks as 1.9M / 340K / 42 rather than 1.9e+06."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.setStyle(tickFont=QFont(FONT_MONO, 7))

    def tickStrings(self, values, scale, spacing):    # noqa: N802
        out: list[str] = []
        for v in values:
            av = abs(v)
            if av >= 1_000_000_000:
                out.append(f"{av / 1_000_000_000:.1f}B")
            elif av >= 1_000_000:
                out.append(f"{av / 1_000_000:.1f}M")
            elif av >= 1_000:
                out.append(f"{av / 1_000:.0f}K")
            elif av > 0:
                out.append(f"{int(av)}")
            else:
                out.append("")
        return out


# ══════════════════════════════════════════════════════════════════════════════
# Candlestick item — custom QGraphicsItem
# ══════════════════════════════════════════════════════════════════════════════

class _CandlestickItem(pg.GraphicsObject):
    """Draws OHLC candlesticks. Green on up-days, red on down-days.

    Parameters match oracle's ``chart_widget.CandlestickItem`` exactly —
    half-width 0.28, single 0.8px pen for wick + body outline, AA on
    throughout. Earlier v3 tunings (wider body, no outline, body AA
    off) produced the "too saturated / high contrast" look the
    operator flagged; restoring oracle's softer rendering.
    """

    _BODY_HALFWIDTH = 0.28
    _PEN_WIDTH = 0.8

    def __init__(self, df: pd.DataFrame) -> None:
        super().__init__()
        self._picture = QPicture()
        self._paint_candles(df)

    def _paint_candles(self, df: pd.DataFrame) -> None:
        painter = QPainter(self._picture)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w = self._BODY_HALFWIDTH
        for i, (_, row) in enumerate(df.iterrows()):
            o, h, l, c = row["Open"], row["High"], row["Low"], row["Close"]
            if pd.isna(o) or pd.isna(c) or pd.isna(h) or pd.isna(l):
                continue
            colour = QColor(_UP) if c >= o else QColor(_DOWN)
            # Single pen for wick + body outline — same width, same
            # colour. Anti-aliased edges soften the fill so candles
            # read as matte blocks rather than saturated pixels.
            painter.setPen(pg.mkPen(colour, width=self._PEN_WIDTH))
            painter.drawLine(QPointF(i, l), QPointF(i, h))
            painter.setBrush(pg.mkBrush(colour))
            top, bot = max(o, c), min(o, c)
            if top - bot < 0.001:
                painter.drawLine(QPointF(i - w, c), QPointF(i + w, c))
            else:
                painter.drawRect(pg.QtCore.QRectF(i - w, bot, 2 * w, top - bot))
        painter.end()

    def paint(self, painter, option, widget=None):   # noqa: ARG002
        painter.drawPicture(0, 0, self._picture)

    def boundingRect(self):
        return pg.QtCore.QRectF(self._picture.boundingRect())


# ══════════════════════════════════════════════════════════════════════════════
# Pure helpers — market-hours filter, IST conversion, VWAP
# ══════════════════════════════════════════════════════════════════════════════

def _filter_market_hours(df: pd.DataFrame) -> pd.DataFrame:
    """Keep only weekday 09:00–15:59 IST rows for intraday frames.

    Daily frames (min hour == max hour) pass through unchanged.
    """
    if df is None or df.empty:
        return df
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is not None:
        idx_ist = idx.tz_convert("Asia/Kolkata")
    else:
        try:
            idx_ist = idx.tz_localize("UTC").tz_convert("Asia/Kolkata")
        except Exception:    # noqa: BLE001
            return df
    if not hasattr(idx_ist, "hour"):
        return df
    hours = idx_ist.hour
    if hours.min() == hours.max():
        return df
    mask = (idx_ist.weekday < 5) & (hours >= 9) & (hours < 16)
    return df[mask].copy()


def _to_ist_list(df: pd.DataFrame) -> list:
    """Return the DataFrame index as IST-naive Python datetimes."""
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is not None:
        idx = idx.tz_convert("Asia/Kolkata").tz_localize(None)
    return list(idx.to_pydatetime())


def _first_present(df: pd.DataFrame, candidates: tuple[str, ...]) -> str | None:
    """Return the first existing column name in ``df`` from ``candidates``."""
    for c in candidates:
        if c in df.columns:
            return c
    return None


# ══════════════════════════════════════════════════════════════════════════════
# Public widget
# ══════════════════════════════════════════════════════════════════════════════

class PriceChart(QWidget):
    """Price + volume chart for one symbol.

    Public API (locked): :meth:`set_data` / :meth:`clear`. The shape
    is compatible with the prior widget so ``DashboardTab`` doesn't
    need any changes to pick up the rework.
    """

    #: Default trailing window. 150 bars fills a ~8 month daily view —
    #: enough to see the 200-SMA relationship without squeezing the
    #: candles flat.
    DEFAULT_BARS = 150

    #: Trailing sessions the volume profile is reconstructed from. ~60
    #: trading days (≈3 months): long enough for acceptance structure to
    #: form, recent enough to describe the CURRENT regime rather than a
    #: stale one. Shorter than DEFAULT_BARS on purpose — the profile should
    #: describe where price is being accepted NOW, not across the whole
    #: visible history.
    VP_LOOKBACK = 60

    #: Blank space kept to the RIGHT of the last bar, so the level labels
    #: (POC / VAH / VAL / options walls) have room to render in full rather
    #: than being clipped to a letter or two by the plot edge.
    #:
    #: Expressed as a FRACTION of the visible window (with a floor in bars),
    #: so the gutter stays roughly constant in screen space as the operator
    #: zooms: a fixed bar count would be invisible at 150 bars and would
    #: swallow the chart at 20.
    LABEL_GUTTER_FRAC = 0.10
    LABEL_GUTTER_MIN_BARS = 6

    #: Hard ceiling on rendered bars. The cache is capped at 5y of
    #: daily data; this bounds the chart to the same window even if a
    #: frame somehow carries more. ~252 trading days/yr × 5.
    MAX_BARS = 1300

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._current_df: pd.DataFrame | None = None
        self._current_options: OptionsContext | None = None
        self._show_vwap = True

        # ── Layout + plots ────────────────────────────────────────────────
        self._layout_widget = pg.GraphicsLayoutWidget()
        self._layout_widget.setBackground(BG)
        self._layout_widget.ci.layout.setSpacing(3)
        self._layout_widget.ci.layout.setContentsMargins(0, 0, 0, 0)

        self._date_axis = _DateAxisItem(orientation="bottom")

        self._price_plot = self._layout_widget.addPlot(row=0, col=0)
        self._cfg_plot(self._price_plot)

        # Volume owns the date axis — it's the bottom panel.
        self._vol_axis = _VolumeAxisItem(orientation="right")
        self._vol_plot = self._layout_widget.addPlot(
            row=1, col=0,
            axisItems={"right": self._vol_axis, "bottom": self._date_axis},
        )
        self._cfg_plot(self._vol_plot, label="VOL", show_x=True)
        self._vol_axis.enableAutoSIPrefix(False)    # fix: no "×10⁶" overlay
        self._vol_plot.setXLink(self._price_plot)

        layout = self._layout_widget.ci.layout
        layout.setRowStretchFactor(0, 75)    # price
        layout.setRowStretchFactor(1, 25)    # volume

        self._all_plots = (self._price_plot, self._vol_plot)

        # ── Crosshair ─────────────────────────────────────────────────────
        self._crosshair_v: pg.InfiniteLine | None = None
        self._crosshair_h: list[pg.InfiniteLine] = []
        # Options-wall overlay lines (support / resistance / max-pain /
        # HVL). Tracked so a rebind or clear() can remove exactly the
        # lines the previous binding added, without disturbing the
        # candles / BB / SMA items.
        self._level_lines: list[pg.InfiniteLine] = []
        # Volume-profile levels are tracked SEPARATELY from the options
        # levels. Sharing one list made `_level_lines` mean two different
        # things and silently broke the options tests' contract.
        self._vp_lines: list[pg.InfiniteLine] = []
        self._vp_labels: list = []      # text items, removed on toggle too
        #: Volume-profile levels are OFF by default. The profile is a
        #: reconstruction from daily bars (see compute/volume_profile), so
        #: it is opt-in rather than always-on.
        self._show_vp: bool = False
        self._install_crosshair()
        self._price_plot.scene().sigMouseMoved.connect(self._on_mouse_moved)

        # ── Empty-state placeholder ──────────────────────────────────────
        self._placeholder = pg.TextItem(
            "Select a signal to view its chart.",
            color=(100, 116, 139),    # MUTED rgb
        )
        self._price_plot.addItem(self._placeholder)
        self._placeholder.setPos(0.5, 0.5)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self._layout_widget)

        # "Reset view" control overlaid on the chart (bottom-left), the
        # price-chart analogue of the ROC/RRG reset — brings the view back
        # into focus on the trailing window after panning/zooming.
        self._reset_btn = QPushButton("\u21ba view", self._layout_widget)
        self._reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._reset_btn.setToolTip("Reset chart to the latest window")
        self._reset_btn.setStyleSheet(
            f"QPushButton {{ background: {S2}; color: {MUTED}; "
            f"border: 1px solid {BORDER}; border-radius: 4px; "
            f"padding: 2px 8px; font-family: '{FONT_MONO}'; font-size: 8pt; }}"
            f"QPushButton:hover {{ color: {WHITE}; border-color: {EM}; }}")
        self._reset_btn.clicked.connect(self.reset_view)
        self._reset_btn.hide()    # shown once data is loaded
        self._position_reset_btn()

    def _position_reset_btn(self) -> None:
        """Park the reset button at the chart's bottom-left corner."""
        if not hasattr(self, "_reset_btn"):
            return
        self._reset_btn.adjustSize()
        m = 8
        self._reset_btn.move(
            m, self._layout_widget.height() - self._reset_btn.height() - m)

    def resizeEvent(self, event):    # noqa: N802
        super().resizeEvent(event)
        self._position_reset_btn()

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def set_data(
        self,
        df: pd.DataFrame | None,
        options: OptionsContext | None = None,
        *,
        bars: int = DEFAULT_BARS,
        focus_bars: int | None = None,
    ) -> None:
        """Render ``df`` with optional options-level overlays.

        Args:
            df: OHLCV DataFrame with a ``DatetimeIndex``. May carry
                enriched indicator columns (bb / sma). Missing columns
                are silently skipped. ``None`` returns the empty state.
            options: v3 :class:`OptionsContext`. When present, draws
                horizontal lines + right-margin labels for
                ``resistance_wall / support_wall / max_pain / hvl``.
            bars: Up to ``bars`` trailing rows are RENDERED (all present
                in the plot and scrollable).
            focus_bars: Initial x-range shows only the trailing
                ``focus_bars`` candles; the operator scrolls/pans back
                to see the rest. ``None`` (default) focuses everything
                rendered — pass e.g. ``DEFAULT_BARS`` to load zoomed to
                the latest window while keeping full history scrollable.
        """
        self._clear_all_plots()
        if df is None or df.empty:
            self._current_df = None
            self._current_options = None
            self._level_lines = []
            self._vp_lines = []
            self._price_plot.addItem(self._placeholder)
            self._reset_btn.hide()
            return

        view_df = _filter_market_hours(df.tail(bars).copy())
        if view_df is None or view_df.empty:
            view_df = df.tail(bars).copy()
        if not all(c in view_df.columns for c in ("Open", "High", "Low", "Close")):
            return

        self._current_df = view_df
        self._current_options = options
        self._install_crosshair()

        ts = _to_ist_list(view_df)
        self._date_axis.set_timestamps(ts)

        n = len(view_df)
        x = np.arange(n, dtype=float)

        self._draw_candles(view_df)
        self._draw_bollinger(view_df, x)
        self._draw_vwap(view_df, x)
        self._draw_smas(view_df, x)
        self._draw_options_levels(options, n)
        # Volume-profile levels track their own list (_vp_lines), so order
        # relative to _draw_options_levels no longer matters — but they are
        # kept adjacent for readability.
        self._draw_volume_profile(view_df, n)
        self._draw_volume(view_df, x)

        # Ranges. The full frame is rendered (all n bars live in the
        # plot), but the initial view focuses just the trailing
        # ``focus_bars`` so the latest action is on screen without
        # scrolling. The rest stays pannable to the left. setLimits
        # keeps the operator from scrolling off into empty space.
        focus = n if focus_bars is None else min(focus_bars, n)
        left = n - focus

        # Right gutter. Level labels (POC/VAH/VAL, options walls) are
        # anchored just past the last bar and drawn LEFT-anchored, so they
        # extend rightward into whatever space the view leaves. With the
        # range ending at n+1 they were clipped to a single letter.
        #
        # The gutter is scaled to the VISIBLE window rather than being a
        # fixed bar count: at 150 visible bars a 6-bar gutter is a sliver,
        # but zoom in to 20 bars and that same 6 bars would swallow a third
        # of the chart. A proportional gutter keeps the label strip roughly
        # constant in SCREEN space, which is what actually matters.
        gutter = max(self.LABEL_GUTTER_MIN_BARS,
                     focus * self.LABEL_GUTTER_FRAC)

        # Remember the initial focus view so "reset view" can restore it
        # after the user pans/zooms.
        self._focus_xrange = (left - 0.5, n + gutter)
        self._focus_yrange = None
        # Pan limit must clear the gutter too, or the operator can't scroll
        # far enough right to read the labels they just made room for.
        self._price_plot.setLimits(xMin=-1, xMax=n + gutter + 1)
        self._price_plot.setXRange(left - 0.5, n + gutter, padding=0.01)

        # Y-range scaled to the FOCUSED window (not the whole history),
        # so the visible candles fill the panel instead of being
        # squashed by a 5-year high/low spread.
        focus_df = view_df.iloc[left:]
        ymin = float(focus_df["Low"].min())
        ymax = float(focus_df["High"].max())
        if options is not None:
            for lv in (options.support_wall, options.resistance_wall,
                       options.max_pain, options.hvl):
                if lv is not None:
                    ymin = min(ymin, float(lv))
                    ymax = max(ymax, float(lv))
        self._focus_yrange = (ymin * 0.997, ymax * 1.003)
        self._price_plot.setYRange(ymin * 0.997, ymax * 1.003, padding=0.01)
        self._reset_btn.show()
        self._position_reset_btn()

        # As the operator pans/zooms X (scrolling back through history),
        # auto-rescale Y to whatever candles are now visible — otherwise
        # older bars outside the initial focus window's price range fall
        # off the top/bottom. X stays under manual control.
        self._price_plot.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)
        self._price_plot.setAutoVisible(y=True)

    def set_volume_profile_visible(self, visible: bool) -> None:
        """Show / hide the reconstructed volume-profile levels.

        Redraws in place rather than re-running set_data: the profile lines
        track their own list (``_vp_lines``), so they can be dropped and
        rebuilt without disturbing the candles, bands, or the operator's
        current pan/zoom.
        """
        if bool(visible) == self._show_vp:
            return
        self._show_vp = bool(visible)

        # Drop whatever is currently drawn.
        for ln in self._vp_lines:
            self._price_plot.removeItem(ln)
        self._vp_lines = []
        for lbl in getattr(self, "_vp_labels", []):
            self._price_plot.removeItem(lbl)
        self._vp_labels = []

        df = getattr(self, "_current_df", None)
        if self._show_vp and df is not None and not df.empty:
            self._draw_volume_profile(df, len(df))

    def reset_view(self) -> None:
        """Restore the initial focus view (trailing window) after the user
        has panned or zoomed — the price-chart analogue of the ROC/RRG
        'reset view' control."""
        xr = getattr(self, "_focus_xrange", None)
        if xr is not None:
            self._price_plot.setXRange(xr[0], xr[1], padding=0.01)
        yr = getattr(self, "_focus_yrange", None)
        if yr is not None:
            self._price_plot.setYRange(yr[0], yr[1], padding=0.01)
        # Re-enable the follow-the-visible-candles Y auto-range.
        self._price_plot.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)
        self._price_plot.setAutoVisible(y=True)

    def clear(self) -> None:
        """Reset to the empty placeholder state."""
        self.set_data(None, None)

    # ══════════════════════════════════════════════════════════════════════
    # Plot configuration + crosshair
    # ══════════════════════════════════════════════════════════════════════

    def _cfg_plot(
        self, plot: pg.PlotItem, *, show_x: bool = False, label: str | None = None,
    ) -> None:
        plot.hideButtons()
        plot.setMenuEnabled(False)
        plot.showGrid(x=True, y=True, alpha=0.08)
        for side in ("left", "right", "top", "bottom"):
            ax = plot.getAxis(side)
            ax.setPen(pg.mkPen(BORDER, width=0.5))
            ax.setTextPen(pg.mkPen(MUTED))
            ax.setStyle(tickLength=-4, tickTextOffset=4,
                        tickFont=QFont(FONT_MONO, 7))
        plot.showAxis("right")
        plot.hideAxis("left")
        plot.getAxis("right").setWidth(_Y_AXIS_W)
        if not show_x:
            plot.hideAxis("bottom")
        plot.hideAxis("top")
        plot.getViewBox().setDefaultPadding(0.01)
        if label:
            txt = pg.TextItem(
                html=(
                    f'<span style="color:{MUTED}; font-family:{FONT_MONO}; '
                    f'font-size:8px; font-weight:600;">{label}</span>'
                ),
                anchor=(0, 0),
            )
            txt.setParentItem(plot.getViewBox())
            txt.setPos(4, 2)
            txt.setZValue(100)

    def _install_crosshair(self) -> None:
        self._crosshair_v = pg.InfiniteLine(angle=90, movable=False, pen=_CROSS_PEN)
        self._crosshair_v.setVisible(False)
        self._price_plot.addItem(self._crosshair_v, ignoreBounds=True)
        self._crosshair_h = []
        for plot in self._all_plots:
            h = pg.InfiniteLine(angle=0, movable=False, pen=_CROSS_PEN)
            h.setVisible(False)
            plot.addItem(h, ignoreBounds=True)
            self._crosshair_h.append(h)
        # Per-bar stats readout, anchored top-left of the price panel —
        # mirrors the Market Pulse index readout but for the single
        # symbol (OHLC, change, %B, BBW pctl, ATR%, vs SMA20, volume).
        self._readout = pg.TextItem(color=WHITE, anchor=(0, 0))
        self._readout.setFont(QFont(FONT_MONO, 9))
        self._readout.setVisible(False)
        self._price_plot.addItem(self._readout, ignoreBounds=True)

    @staticmethod
    def _fmt_vol(v: float) -> str:
        """Human-readable volume (1.9M, 340K)."""
        if v != v:
            return "—"
        if abs(v) >= 1e7:
            return f"{v / 1e7:.1f}Cr"
        if abs(v) >= 1e5:
            return f"{v / 1e5:.1f}L"
        if abs(v) >= 1e3:
            return f"{v / 1e3:.0f}K"
        return f"{v:.0f}"

    def _update_readout(self, xi: int) -> None:
        df = self._current_df
        if df is None or xi < 0 or xi >= len(df):
            self._readout.setVisible(False)
            return
        row = df.iloc[xi]

        def g(col: str) -> float:
            try:
                v = float(row[col])
                return v
            except (KeyError, TypeError, ValueError):
                return float("nan")

        ts = df.index[xi]
        parts = [pd.Timestamp(ts).strftime("%a %d %b %Y")]

        close = g("Close")
        parts.append(f"O {g('Open'):.1f}")
        parts.append(f"H {g('High'):.1f}")
        parts.append(f"L {g('Low'):.1f}")
        parts.append(f"C {close:.1f}")

        # Change % vs previous bar.
        if xi > 0:
            prev = float(df["Close"].iloc[xi - 1])
            if prev > 0:
                parts.append(f"Chg {(close / prev - 1) * 100:+.2f}%")

        pct_b = g("bb_20_1s_pct")
        if pct_b == pct_b:
            parts.append(f"%B {pct_b:.2f}")
        bbw_pctl = g("bbw_20_1s_pctl")
        if bbw_pctl == bbw_pctl:
            parts.append(f"BBW {bbw_pctl:.0f}")
        atr_pct = g("atr_14_pct")
        if atr_pct == atr_pct:
            parts.append(f"ATR {atr_pct:.1f}%")
        sma = g("sma_20")
        if sma == sma and sma > 0 and close == close:
            parts.append(f"vsSMA {(close / sma - 1) * 100:+.1f}%")
        parts.append(f"Vol {self._fmt_vol(g('Volume'))}")

        self._readout.setText("  ".join(parts))
        vb = self._price_plot.vb.viewRange()
        self._readout.setPos(vb[0][0], vb[1][1])
        self._readout.setVisible(True)

    def _on_mouse_moved(self, pos) -> None:
        if self._crosshair_v is None:
            return
        for i, plot in enumerate(self._all_plots):
            if plot.sceneBoundingRect().contains(pos):
                mp = plot.vb.mapSceneToView(pos)
                self._crosshair_v.setPos(mp.x())
                self._crosshair_v.setVisible(True)
                self._crosshair_h[i].setPos(mp.y())
                self._crosshair_h[i].setVisible(True)
                for j, h in enumerate(self._crosshair_h):
                    if j != i:
                        h.setVisible(False)
                self._update_readout(int(round(mp.x())))
                return
        self._crosshair_v.setVisible(False)
        for h in self._crosshair_h:
            h.setVisible(False)
        if getattr(self, "_readout", None) is not None:
            self._readout.setVisible(False)

    # ══════════════════════════════════════════════════════════════════════
    # Per-panel draw helpers
    # ══════════════════════════════════════════════════════════════════════

    def _clear_all_plots(self) -> None:
        for plot in self._all_plots:
            plot.clear()
        self._current_df = None
        self._current_options = None

    def _draw_candles(self, df: pd.DataFrame) -> None:
        self._price_plot.addItem(_CandlestickItem(df))

    def _draw_bollinger(self, df: pd.DataFrame, x: np.ndarray) -> None:
        up_col = _first_present(df, ("bb_20_1s_upper", "BB_Upper"))
        lo_col = _first_present(df, ("bb_20_1s_lower", "BB_Lower"))
        md_col = _first_present(df, ("bb_20_1s_mid", "BB_Mid"))
        if not up_col or not lo_col:
            return
        u = df[up_col].ffill().to_numpy(dtype=float)
        l = df[lo_col].ffill().to_numpy(dtype=float)
        uc = pg.PlotDataItem(x, u, pen=_BB_UPPER)
        lc = pg.PlotDataItem(x, l, pen=_BB_LOWER)
        self._price_plot.addItem(pg.FillBetweenItem(uc, lc, brush=_BB_FILL))
        self._price_plot.addItem(uc)
        self._price_plot.addItem(lc)
        if md_col:
            m = df[md_col].ffill().to_numpy(dtype=float)
            self._price_plot.addItem(pg.PlotDataItem(x, m, pen=_BB_MID))

    def _draw_vwap(self, df: pd.DataFrame, x: np.ndarray) -> None:
        if not self._show_vwap:
            return
        vwap = compute_vwap(df)
        if vwap is None:
            return
        ok = ~np.isnan(vwap)
        if not ok.any():
            return
        self._price_plot.addItem(
            pg.PlotDataItem(x[ok], vwap[ok], pen=_VWAP_PEN, connect="finite"),
        )

    def _draw_smas(self, df: pd.DataFrame, x: np.ndarray) -> None:
        for col, colour, width in _SMA_LINES:
            if col not in df.columns:
                continue
            sma = df[col].ffill().to_numpy(dtype=float)
            ok = ~np.isnan(sma)
            if not ok.any():
                continue
            self._price_plot.addItem(
                pg.PlotDataItem(x[ok], sma[ok], pen=pg.mkPen(colour, width=width)),
            )

    def _draw_options_levels(
        self, options: OptionsContext | None, n: int,
    ) -> None:
        # Fresh binding — the caller (set_data) has already cleared the
        # plot, so drop our stale references too before (maybe)
        # repopulating. This keeps ``_level_lines`` in lockstep with
        # what's actually on the plot.
        self._level_lines = []
        if options is None:
            return
        levels: tuple[tuple[float | None, str, Qt.PenStyle, str], ...] = (
            (options.resistance_wall, RED, Qt.PenStyle.DashLine, "R"),
            (options.support_wall, GREEN, Qt.PenStyle.DashLine, "S"),
            (options.max_pain, GOLD, Qt.PenStyle.DotLine, "MP"),
            (options.hvl, VIOLET, Qt.PenStyle.DashDotLine, "HVL"),
        )
        for yv, colour, dash, prefix in levels:
            if yv is None:
                continue
            line = pg.InfiniteLine(
                pos=float(yv), angle=0, movable=False,
                pen=pg.mkPen(colour, width=0.8, style=dash),
            )
            self._price_plot.addItem(line)
            self._level_lines.append(line)
            lbl = pg.TextItem(
                f" {prefix} {float(yv):,.0f} ",
                color=colour,
                anchor=(0, 0.5),
                fill=pg.mkBrush(QColor(BG)),
                border=pg.mkPen(colour, width=0.5),
            )
            lbl.setFont(QFont(FONT_MONO, 7))
            lbl.setPos(n + 0.5, float(yv))
            self._price_plot.addItem(lbl)

    def _draw_volume_profile(self, df: pd.DataFrame | None, n: int) -> None:
        """Draw POC / VAH / VAL from a reconstructed volume profile.

        Deliberately levels-only, no histogram. The profile is RECONSTRUCTED
        from daily bars (volume distributed across each day's range, not
        measured at each price), so a full histogram would render an
        authoritative-looking shape that the underlying data does not earn.
        Three lines state the useful, coarse conclusion — where the market
        has been accepting price — without implying tick-level precision.
        """
        # Fresh binding — drop stale references so the list stays in
        # lockstep with what is actually on the plot.
        self._vp_lines = []
        self._vp_labels = []
        if not self._show_vp:
            return
        if df is None or df.empty:
            return
        profile = compute_volume_profile(df, lookback=self.VP_LOOKBACK)
        if profile is None or not profile.has_data:
            return

        levels = (
            (profile.poc, GOLD, Qt.PenStyle.SolidLine, "POC"),
            (profile.vah, VIOLET, Qt.PenStyle.DashLine, "VAH"),
            (profile.val, VIOLET, Qt.PenStyle.DashLine, "VAL"),
        )
        for yv, colour, dash, prefix in levels:
            if yv is None or yv != yv:
                continue
            line = pg.InfiniteLine(
                pos=float(yv), angle=0, movable=False,
                pen=pg.mkPen(colour, width=0.8, style=dash),
            )
            self._price_plot.addItem(line)
            self._vp_lines.append(line)
            lbl = pg.TextItem(
                f" {prefix} {float(yv):,.0f} ",
                color=colour,
                anchor=(0, 0.5),
                fill=pg.mkBrush(QColor(BG)),
                border=pg.mkPen(colour, width=0.5),
            )
            lbl.setFont(QFont(FONT_MONO, 7))
            lbl.setPos(n + 0.5, float(yv))
            self._price_plot.addItem(lbl)
            self._vp_labels.append(lbl)

    def _draw_volume(self, df: pd.DataFrame, x: np.ndarray) -> None:
        if "Volume" not in df.columns:
            return
        vols = df["Volume"].fillna(0).to_numpy(dtype=float)
        if vols.sum() <= 0:
            return
        opens = df["Open"].to_numpy(dtype=float)
        closes = df["Close"].to_numpy(dtype=float)
        brushes = [_VOL_UP if c >= o else _VOL_DOWN for o, c in zip(opens, closes)]
        self._vol_plot.addItem(
            pg.BarGraphItem(x=x, height=vols, width=0.7, brushes=brushes, pen=pg.mkPen(None)),
        )
        self._vol_plot.enableAutoRange(axis="y")
