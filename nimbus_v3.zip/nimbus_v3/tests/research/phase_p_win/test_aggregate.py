"""Tests for ``research.phase_p_win.aggregate``.

Beta-binomial smoothing math + edge cases under all three
parallel win definitions (relative, profit, meaningful).
"""
from __future__ import annotations

import pytest

from nimbus_v3.research.phase_p_win.aggregate import (
    DEFAULT_PRIOR_STRENGTH,
    aggregate_per_symbol,
    stats_to_dataframe,
    universe_win_rates,
)
from nimbus_v3.research.phase_p_win.schema import (
    FireEvent,
    MEANINGFUL_RETURN_PCT,
)


# ══════════════════════════════════════════════════════════════════════════════
# Fixture builders
# ══════════════════════════════════════════════════════════════════════════════


def _ev(symbol: str, phase: str, idx: int, hold: int | None,
        ret_pct: float | None, *, resolved: bool = True) -> FireEvent:
    """Concise FireEvent constructor — features defaulted to 0."""
    return FireEvent(
        symbol=symbol, phase=phase,
        trigger_idx=idx, trigger_date="2024-01-01",
        hold_bars=hold, exit_idx=(idx + hold) if hold else None,
        return_pct=ret_pct, is_resolved=resolved,
        pct_b_at_trigger=0.0, sma20_slope_pct=0.0, sma50_slope_pct=0.0,
        bb_width_pctile=0.0, vol_ratio_20=0.0, atr_14_pct=0.0,
        bars_since_sma20_above_sma50=0, body_above_count_prior_5=0,
    )


# ══════════════════════════════════════════════════════════════════════════════
# universe_win_rates — three definitions
# ══════════════════════════════════════════════════════════════════════════════


class TestUniverseWinRates:
    def test_no_events_yields_neutral_rates(self):
        """Empty corpus → 0.5 for every (phase, definition)."""
        rates = universe_win_rates([])
        for phase in ("INIT", "RETEST", "CONT"):
            assert rates[phase]["relative"] == 0.5
            assert rates[phase]["profit"] == 0.5
            assert rates[phase]["meaningful"] == 0.5

    def test_unresolved_events_excluded(self):
        events = [_ev("X", "INIT", 0, None, None, resolved=False)]
        rates = universe_win_rates(events)
        assert rates["INIT"]["relative"] == 0.5
        assert rates["INIT"]["profit"] == 0.5
        assert rates["INIT"]["meaningful"] == 0.5

    def test_relative_uses_per_symbol_mean(self):
        """Relative wins computed against each symbol's own mean."""
        events = [
            # Symbol A: returns 1, 3, 5 → mean 3 → 5 wins (1 of 3)
            _ev("A", "INIT", 0, 5, 1.0),
            _ev("A", "INIT", 1, 5, 3.0),
            _ev("A", "INIT", 2, 5, 5.0),
            # Symbol B: returns 10, 12, 14 → mean 12 → 14 wins (1 of 3)
            _ev("B", "INIT", 0, 5, 10.0),
            _ev("B", "INIT", 1, 5, 12.0),
            _ev("B", "INIT", 2, 5, 14.0),
        ]
        rates = universe_win_rates(events)
        # Pool: 1 win out of 3 + 1 win out of 3 = 2/6
        assert rates["INIT"]["relative"] == pytest.approx(2 / 6)

    def test_profit_uses_zero_threshold(self):
        """Profit wins are returns > 0 regardless of symbol mean."""
        events = [
            _ev("A", "INIT", 0, 5, -1.0),    # loss
            _ev("A", "INIT", 1, 5, 0.0),     # exactly 0 — not a win (strict >)
            _ev("A", "INIT", 2, 5, 0.5),     # tiny win
            _ev("B", "INIT", 0, 5, 5.0),     # win
            _ev("B", "INIT", 1, 5, -5.0),    # loss
        ]
        rates = universe_win_rates(events)
        # 2 of 5 events have return > 0
        assert rates["INIT"]["profit"] == pytest.approx(2 / 5)

    def test_meaningful_uses_one_percent_threshold(self):
        """Meaningful wins must clear MEANINGFUL_RETURN_PCT."""
        events = [
            _ev("A", "INIT", 0, 5, 0.5),     # tiny positive — no
            _ev("A", "INIT", 1, 5, 1.0),     # exactly threshold — no (strict >)
            _ev("A", "INIT", 2, 5, 1.5),     # clears — yes
            _ev("A", "INIT", 3, 5, -3.0),    # loss
        ]
        rates = universe_win_rates(events)
        assert MEANINGFUL_RETURN_PCT == 1.0    # contract
        # Only the 1.5% return clears.
        assert rates["INIT"]["meaningful"] == pytest.approx(1 / 4)

    def test_three_definitions_can_diverge(self):
        """Construct events where the three definitions land at
        different rates — sanity that they're computed
        independently."""
        events = [
            # Symbol with mean = 0, all small magnitudes
            _ev("A", "INIT", 0, 5, +0.5),
            _ev("A", "INIT", 1, 5, -0.5),
            _ev("A", "INIT", 2, 5, +0.3),
            _ev("A", "INIT", 3, 5, -0.3),
        ]
        # Mean = 0
        # Relative wins (> 0 mean): 2 of 4
        # Profit wins (> 0): 2 of 4
        # Meaningful wins (> 1.0%): 0 of 4
        rates = universe_win_rates(events)
        assert rates["INIT"]["relative"] == pytest.approx(0.5)
        assert rates["INIT"]["profit"] == pytest.approx(0.5)
        assert rates["INIT"]["meaningful"] == pytest.approx(0.0)


# ══════════════════════════════════════════════════════════════════════════════
# aggregate_per_symbol — Beta-binomial smoothing math
# ══════════════════════════════════════════════════════════════════════════════


class TestBetaSmoothing:
    def test_zero_samples_falls_back_to_universe_rate(self):
        """Symbol with only open fires → all three p_wins fall
        back to the corresponding universe rate."""
        events = [_ev("X", "INIT", 0, None, None, resolved=False)]
        u = {
            "INIT":   {"relative": 0.7, "profit": 0.4, "meaningful": 0.2},
            "RETEST": {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "CONT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
        }
        stats = aggregate_per_symbol(events, universe_rates=u)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        assert x.n_resolved == 0
        assert x.n_open == 1
        assert x.p_win_relative_smoothed == pytest.approx(0.7)
        assert x.p_win_profit_smoothed == pytest.approx(0.4)
        assert x.p_win_meaningful_smoothed == pytest.approx(0.2)
        # Raw NaNs since no resolved events.
        assert x.p_win_relative_raw != x.p_win_relative_raw
        assert x.p_win_profit_raw != x.p_win_profit_raw
        assert x.p_win_meaningful_raw != x.p_win_meaningful_raw

    def test_three_definitions_distinct_for_same_events(self):
        """Same events, three different counts — verifies the
        thresholds are applied independently."""
        events = [
            # mean = 0 by symmetry; thresholds give different counts.
            _ev("X", "INIT", 0, 5, +2.0),    # all defs win
            _ev("X", "INIT", 1, 5, +0.5),    # rel: <mean(1.0625)? rel=N. profit=Y. mean=N
            _ev("X", "INIT", 2, 5, -1.0),    # all loss
            _ev("X", "INIT", 3, 5, +2.75),   # all win (>1, >0, >mean)
        ]
        u = {
            "INIT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "RETEST": {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "CONT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
        }
        stats = aggregate_per_symbol(events, universe_rates=u, prior_strength=0.0)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        # Mean = (2 + 0.5 - 1 + 2.75) / 4 = 1.0625
        assert x.avg_return_pct == pytest.approx(1.0625)
        # Relative: > 1.0625 → 2 wins (the 2.0 and 2.75)
        assert x.n_wins_relative == 2
        # Profit: > 0 → 3 wins (0.5, 2.0, 2.75)
        assert x.n_wins_profit == 3
        # Meaningful: > 1.0 → 2 wins (2.0 and 2.75)
        assert x.n_wins_meaningful == 2
        # With prior_strength=0, raw = smoothed
        assert x.p_win_relative_smoothed == pytest.approx(0.5)
        assert x.p_win_profit_smoothed == pytest.approx(0.75)
        assert x.p_win_meaningful_smoothed == pytest.approx(0.5)

    def test_large_n_dominates_prior_for_each_definition(self):
        """With 100 events the symbol's raw rate dominates the
        prior under each definition independently."""
        events = []
        # 60 returns of +5 (all defs win), 40 returns of -2 (all defs lose).
        for i in range(60):
            events.append(_ev("X", "INIT", i, 5, 5.0))
        for i in range(40):
            events.append(_ev("X", "INIT", 60 + i, 5, -2.0))
        # Mean = (60 × 5 + 40 × -2) / 100 = (300 - 80) / 100 = 2.2
        # Relative > 2.2 → 60 wins
        # Profit > 0 → 60 wins
        # Meaningful > 1.0 → 60 wins
        u = {
            "INIT":   {"relative": 0.3, "profit": 0.3, "meaningful": 0.3},
            "RETEST": {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "CONT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
        }
        stats = aggregate_per_symbol(events, universe_rates=u, prior_strength=5.0)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        # All three raws should be 0.6.
        assert x.p_win_relative_raw == pytest.approx(0.6)
        assert x.p_win_profit_raw == pytest.approx(0.6)
        assert x.p_win_meaningful_raw == pytest.approx(0.6)
        # Smoothed: (5×0.3 + 60) / 105 ≈ 0.5857 (same for each since
        # universe rates are identical here).
        expected = (5 * 0.3 + 60) / (5 + 100)
        assert x.p_win_relative_smoothed == pytest.approx(expected)
        assert x.p_win_profit_smoothed == pytest.approx(expected)
        assert x.p_win_meaningful_smoothed == pytest.approx(expected)

    def test_small_n_pulled_toward_prior(self):
        events = [
            _ev("X", "INIT", 0, 5, 1.0),
            _ev("X", "INIT", 1, 5, 2.0),
            _ev("X", "INIT", 2, 5, 100.0),
        ]
        # Mean = 34.33, only the 100 wins (relative)
        # Profit (>0): all 3 win.
        # Meaningful (>1.0 strict): 1.0 doesn't clear; 2.0 and
        # 100.0 do → 2 wins.
        u = {
            "INIT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "RETEST": {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "CONT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
        }
        stats = aggregate_per_symbol(events, universe_rates=u, prior_strength=5.0)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        assert x.n_wins_relative == 1
        assert x.n_wins_profit == 3
        assert x.n_wins_meaningful == 2
        # Smoothed pull-toward-prior:
        # relative:    (5×0.5 + 1) / (5+3) = 3.5 / 8 = 0.4375
        # profit:      (5×0.5 + 3) / 8 = 5.5 / 8 = 0.6875
        # meaningful:  (5×0.5 + 2) / 8 = 4.5 / 8 = 0.5625
        assert x.p_win_relative_smoothed == pytest.approx(3.5 / 8)
        assert x.p_win_profit_smoothed == pytest.approx(5.5 / 8)
        assert x.p_win_meaningful_smoothed == pytest.approx(4.5 / 8)

    def test_prior_strength_zero_recovers_raw_for_all_definitions(self):
        events = [
            _ev("X", "INIT", 0, 5, 1.5),
            _ev("X", "INIT", 1, 5, -0.5),
            _ev("X", "INIT", 2, 5, 2.0),
        ]
        u = {
            "INIT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "RETEST": {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
            "CONT":   {"relative": 0.5, "profit": 0.5, "meaningful": 0.5},
        }
        stats = aggregate_per_symbol(events, universe_rates=u, prior_strength=0.0)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        assert x.p_win_relative_smoothed == pytest.approx(x.p_win_relative_raw)
        assert x.p_win_profit_smoothed == pytest.approx(x.p_win_profit_raw)
        assert x.p_win_meaningful_smoothed == pytest.approx(x.p_win_meaningful_raw)

    def test_default_prior_strength_locked(self):
        assert DEFAULT_PRIOR_STRENGTH == 5.0


# ══════════════════════════════════════════════════════════════════════════════
# Outcome counts
# ══════════════════════════════════════════════════════════════════════════════


class TestCounts:
    def test_n_open_separate_from_n_resolved(self):
        events = [
            _ev("X", "INIT", 0, 5, 1.0),
            _ev("X", "INIT", 1, 5, 2.0),
            _ev("X", "INIT", 2, None, None, resolved=False),
        ]
        stats = aggregate_per_symbol(events)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        assert x.n_resolved == 2
        assert x.n_open == 1

    def test_median_hold_bars_from_resolved_only(self):
        events = [
            _ev("X", "INIT", 0, 5,  1.0),
            _ev("X", "INIT", 1, 7,  2.0),
            _ev("X", "INIT", 2, 9,  3.0),
            _ev("X", "INIT", 3, None, None, resolved=False),
        ]
        stats = aggregate_per_symbol(events)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        assert x.median_hold_bars == 7

    def test_avg_return_pct_from_resolved_only(self):
        events = [
            _ev("X", "INIT", 0, 5, 1.0),
            _ev("X", "INIT", 1, 5, 3.0),
            _ev("X", "INIT", 2, None, None, resolved=False),
        ]
        stats = aggregate_per_symbol(events)
        x = next(s for s in stats if s.symbol == "X" and s.phase == "INIT")
        assert x.avg_return_pct == pytest.approx(2.0)


# ══════════════════════════════════════════════════════════════════════════════
# Output flattening
# ══════════════════════════════════════════════════════════════════════════════


class TestStatsToDataframe:
    def test_round_trips(self):
        events = [_ev("X", "INIT", 0, 5, 1.0), _ev("X", "INIT", 1, 5, 2.0)]
        stats = aggregate_per_symbol(events)
        df = stats_to_dataframe(stats)
        assert len(df) == 1
        for col in (
            "symbol", "n_resolved", "n_open", "median_hold_bars",
            "p_win_relative_smoothed", "p_win_profit_smoothed",
            "p_win_meaningful_smoothed",
            "p_win_relative_raw", "p_win_profit_raw",
            "p_win_meaningful_raw",
        ):
            assert col in df.columns, f"{col} missing from stats df"
