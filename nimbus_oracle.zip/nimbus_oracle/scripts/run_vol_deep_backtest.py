#!/usr/bin/env python3
"""
scripts/run_vol_deep_backtest.py — Deep per-stock vol + VIX regime analysis.

Extends the basic VIX backtest with:
  1. Fine-grained per-stock vol quintiles
  2. Per-stock vol effect WITHIN each VIX regime (interaction)
  3. 3x3 combined regime matrix (VIX × stock vol, finer cuts)
  4. Correlation of stock vol with specific trade outcomes
  5. Conditional analysis: does vol predict MAX_HOLD failure?
  6. Vol as entry filter: what if we skip high/low vol entries?
  7. Tier × vol interaction: does vol affect PRIMARY vs SECONDARY differently?

Usage:
    python3 scripts/run_vol_deep_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("vol_deep")


def calc_stats(pnls):
    if len(pnls) < 3:
        return {"n": len(pnls), "avg": 0, "win": 0, "sharpe": 0, "median": 0,
                "worst": 0, "best": 0, "pt_pct": 0, "max_pct": 0}
    arr = np.array(pnls)
    avg = float(np.mean(arr)); std = float(np.std(arr))
    return {
        "n": len(arr), "avg": round(avg, 3),
        "win": round((arr > 0).mean() * 100, 1),
        "sharpe": round(avg / std * np.sqrt(252/10), 2) if std > 0 else 0,
        "median": round(float(np.median(arr)), 3),
        "worst": round(float(arr.min()), 2),
        "best": round(float(arr.max()), 2),
    }


def load_trades(path):
    df = pd.read_csv(path)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    return df


def fetch_vix(trades_df):
    try:
        import yfinance as yf
        start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
        end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
        vix = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                          end=end.strftime("%Y-%m-%d"), progress=False)
        if isinstance(vix.columns, pd.MultiIndex):
            vix.columns = vix.columns.get_level_values(0)
        vix.index = pd.to_datetime(vix.index)
        if hasattr(vix.index, "tz") and vix.index.tz is not None:
            vix.index = vix.index.tz_localize(None)
        return vix["Close"]
    except Exception as e:
        logger.warning("VIX fetch failed: %s", e)
        return None


def match_vix(trades_df, vix_series):
    vals = []
    for _, row in trades_df.iterrows():
        dt = row["entry_date"]
        mask = vix_series.index <= dt
        vals.append(float(vix_series[mask].iloc[-1]) if mask.any() else np.nan)
    return np.array(vals)


def compute_rvol(trades_df, cache_dir="data/backtest_cache"):
    """Compute 20d annualized realized vol for each trade's stock at entry."""
    price_data = {}
    for sym in trades_df["symbol"].unique():
        cache_file = os.path.join(cache_dir, f"{sym}_1d.parquet")
        if os.path.exists(cache_file):
            try:
                df = pd.read_parquet(cache_file)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_data[sym] = df
            except Exception:
                pass

    missing = [s for s in trades_df["symbol"].unique() if s not in price_data]
    if missing:
        logger.info("Fetching %d symbols missing from cache...", len(missing))
        try:
            import yfinance as yf
            for sym in missing:
                try:
                    df = yf.download(f"{sym}.NS", period="5y", progress=False, timeout=10)
                    if df is not None and not df.empty:
                        if isinstance(df.columns, pd.MultiIndex):
                            df.columns = df.columns.get_level_values(0)
                        df.index = pd.to_datetime(df.index)
                        if hasattr(df.index, "tz") and df.index.tz is not None:
                            df.index = df.index.tz_localize(None)
                        price_data[sym] = df
                except Exception:
                    pass
        except ImportError:
            pass

    rvols = []
    for _, row in trades_df.iterrows():
        sym, dt = row["symbol"], row["entry_date"]
        rvol = np.nan
        if sym in price_data:
            df = price_data[sym]
            mask = df.index <= dt
            if mask.sum() >= 20:
                recent = df.loc[mask].tail(21)
                if len(recent) >= 20:
                    rets = recent["Close"].pct_change().dropna()
                    if len(rets) >= 15:
                        rvol = float(rets.std() * np.sqrt(252) * 100)
        rvols.append(rvol)
    return np.array(rvols)


def t_test(a, b):
    if len(a) < 10 or len(b) < 10:
        return 0, 1.0, False
    try:
        from scipy import stats
        t, p = stats.ttest_ind(a, b, equal_var=False)
        return float(t), float(p), p < 0.05
    except ImportError:
        return 0, 1.0, False


# ══════════════════════════════════════════════════════════════════════════════
# TESTS
# ══════════════════════════════════════════════════════════════════════════════

def test_rvol_quintiles(df, report):
    """TEST 1: Per-stock vol quintile analysis — finer than 4 buckets."""
    report.append("\n" + "=" * 70)
    report.append("TEST 1: PER-STOCK REALIZED VOL — QUINTILE ANALYSIS")
    report.append("=" * 70)

    valid = df.dropna(subset=["rvol"])
    quintile_edges = np.percentile(valid["rvol"], [0, 20, 40, 60, 80, 100])
    report.append(f"\n  Quintile edges: {[f'{e:.1f}%' for e in quintile_edges]}")

    for i in range(5):
        lo, hi = quintile_edges[i], quintile_edges[i+1]
        if i == 4: hi += 1  # include max
        bucket = valid[(valid["rvol"] >= lo) & (valid["rvol"] < hi)]
        s = calc_stats(bucket["pnl_pct"].values)
        pt_pct = (bucket["exit_reason"] == "PT").mean() * 100 if len(bucket) > 0 else 0
        max_pct = (bucket["exit_reason"] == "MAX").mean() * 100 if len(bucket) > 0 else 0
        report.append(f"  Q{i+1} ({lo:5.1f}–{hi:5.1f}%): N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}  "
                      f"PT={pt_pct:.0f}%  MAX={max_pct:.0f}%")

    # Monotonicity check
    avgs = []
    for i in range(5):
        lo, hi = quintile_edges[i], quintile_edges[i+1]
        if i == 4: hi += 1
        bucket = valid[(valid["rvol"] >= lo) & (valid["rvol"] < hi)]
        avgs.append(np.mean(bucket["pnl_pct"].values))
    increasing = all(avgs[i] <= avgs[i+1] for i in range(4))
    decreasing = all(avgs[i] >= avgs[i+1] for i in range(4))
    report.append(f"\n  Monotonic increasing: {increasing}")
    report.append(f"  Monotonic decreasing: {decreasing}")
    if not increasing and not decreasing:
        report.append("  → Non-monotonic — vol is not a linear predictor")

    # Q1 vs Q5 t-test
    q1 = valid[valid["rvol"] < quintile_edges[1]]["pnl_pct"].values
    q5 = valid[valid["rvol"] >= quintile_edges[4]]["pnl_pct"].values
    t, p, sig = t_test(q1, q5)
    report.append(f"\n  Q1 vs Q5: t={t:.3f}  p={p:.4f}  {'✓ SIGNIFICANT' if sig else '○ not significant'}")


def test_rvol_within_vix(df, report):
    """TEST 2: Does per-stock vol matter WITHIN each VIX regime?"""
    report.append("\n" + "=" * 70)
    report.append("TEST 2: PER-STOCK VOL WITHIN VIX REGIME (INTERACTION)")
    report.append("=" * 70)

    valid = df.dropna(subset=["vix", "rvol"])
    vix_regimes = [("Low VIX (<13)", 0, 13), ("Normal (13-18)", 13, 18),
                   ("Stressed (≥18)", 18, 999)]
    vol_splits = [("Low vol", 0, 25), ("High vol", 25, 999)]

    for vix_label, vix_lo, vix_hi in vix_regimes:
        report.append(f"\n  {vix_label}:")
        for vol_label, vol_lo, vol_hi in vol_splits:
            bucket = valid[(valid["vix"] >= vix_lo) & (valid["vix"] < vix_hi) &
                           (valid["rvol"] >= vol_lo) & (valid["rvol"] < vol_hi)]
            if len(bucket) < 15:
                report.append(f"    {vol_label:12s}: N={len(bucket):4d}  (insufficient)")
                continue
            s = calc_stats(bucket["pnl_pct"].values)
            pt_pct = (bucket["exit_reason"] == "PT").mean() * 100
            report.append(f"    {vol_label:12s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                          f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}  PT={pt_pct:.0f}%")

        # T-test low vs high vol within this VIX regime
        low_v = valid[(valid["vix"] >= vix_lo) & (valid["vix"] < vix_hi) &
                       (valid["rvol"] < 25)]["pnl_pct"].values
        high_v = valid[(valid["vix"] >= vix_lo) & (valid["vix"] < vix_hi) &
                        (valid["rvol"] >= 25)]["pnl_pct"].values
        t, p, sig = t_test(low_v, high_v)
        if len(low_v) >= 10 and len(high_v) >= 10:
            report.append(f"    Low vs High vol: t={t:.3f}  p={p:.4f}  "
                          f"{'✓ SIGNIFICANT' if sig else '○ not significant'}")


def test_3x3_matrix(df, report):
    """TEST 3: Full 3×3 VIX × stock vol matrix."""
    report.append("\n" + "=" * 70)
    report.append("TEST 3: 3×3 REGIME MATRIX (VIX × STOCK VOL)")
    report.append("=" * 70)

    valid = df.dropna(subset=["vix", "rvol"])
    vix_cuts = [("VIX<13", 0, 13), ("VIX 13-18", 13, 18), ("VIX≥18", 18, 999)]
    vol_cuts = [("Vol<20%", 0, 20), ("Vol 20-35%", 20, 35), ("Vol≥35%", 35, 999)]

    report.append(f"\n  {'':20s} | {'Vol<20%':>18s} | {'Vol 20-35%':>18s} | {'Vol≥35%':>18s}")
    report.append("  " + "-" * 80)

    for vix_label, vix_lo, vix_hi in vix_cuts:
        cells = []
        for vol_label, vol_lo, vol_hi in vol_cuts:
            bucket = valid[(valid["vix"] >= vix_lo) & (valid["vix"] < vix_hi) &
                           (valid["rvol"] >= vol_lo) & (valid["rvol"] < vol_hi)]
            if len(bucket) < 10:
                cells.append(f"N={len(bucket):3d} (insuff)")
            else:
                s = calc_stats(bucket["pnl_pct"].values)
                cells.append(f"N={s['n']:3d} W={s['win']:.0f}% Sh={s['sharpe']:.1f}")
        report.append(f"  {vix_label:20s} | {cells[0]:>18s} | {cells[1]:>18s} | {cells[2]:>18s}")

    # Find best and worst cells
    best_sh = -999; best_cell = ""; worst_sh = 999; worst_cell = ""
    for vix_label, vix_lo, vix_hi in vix_cuts:
        for vol_label, vol_lo, vol_hi in vol_cuts:
            bucket = valid[(valid["vix"] >= vix_lo) & (valid["vix"] < vix_hi) &
                           (valid["rvol"] >= vol_lo) & (valid["rvol"] < vol_hi)]
            if len(bucket) >= 20:
                s = calc_stats(bucket["pnl_pct"].values)
                if s["sharpe"] > best_sh:
                    best_sh = s["sharpe"]; best_cell = f"{vix_label} × {vol_label}"
                if s["sharpe"] < worst_sh:
                    worst_sh = s["sharpe"]; worst_cell = f"{vix_label} × {vol_label}"

    report.append(f"\n  Best cell:  {best_cell} (Sh={best_sh:.2f})")
    report.append(f"  Worst cell: {worst_cell} (Sh={worst_sh:.2f})")


def test_tier_interaction(df, report):
    """TEST 4: Does vol affect PRIMARY and SECONDARY tiers differently?"""
    report.append("\n" + "=" * 70)
    report.append("TEST 4: TIER × VOL INTERACTION")
    report.append("=" * 70)

    valid = df.dropna(subset=["rvol"])
    vol_median = valid["rvol"].median()
    report.append(f"\n  Vol median: {vol_median:.1f}% (split point)")

    for tier in ("PRIMARY", "SECONDARY"):
        tier_df = valid[valid["tier"] == tier]
        low = tier_df[tier_df["rvol"] < vol_median]
        high = tier_df[tier_df["rvol"] >= vol_median]

        sl = calc_stats(low["pnl_pct"].values)
        sh = calc_stats(high["pnl_pct"].values)
        report.append(f"\n  {tier}:")
        report.append(f"    Low vol  (<{vol_median:.0f}%): N={sl['n']:4d}  avg={sl['avg']:+.3f}%  "
                      f"win={sl['win']:.1f}%  Sh={sl['sharpe']:.2f}")
        report.append(f"    High vol (≥{vol_median:.0f}%): N={sh['n']:4d}  avg={sh['avg']:+.3f}%  "
                      f"win={sh['win']:.1f}%  Sh={sh['sharpe']:.2f}")
        t, p, sig = t_test(low["pnl_pct"].values, high["pnl_pct"].values)
        report.append(f"    t={t:.3f}  p={p:.4f}  {'✓ SIGNIFICANT' if sig else '○ not significant'}")


def test_vol_filter_simulation(df, report):
    """TEST 5: What if we filter out trades by vol? Simulated equity curves."""
    report.append("\n" + "=" * 70)
    report.append("TEST 5: VOL FILTER SIMULATION — SKIP TRADES BY VOL REGIME")
    report.append("=" * 70)

    valid = df.dropna(subset=["rvol", "vix"])
    baseline = calc_stats(valid["pnl_pct"].values)
    report.append(f"\n  Baseline (all trades): N={baseline['n']}  avg={baseline['avg']:+.3f}%  "
                  f"win={baseline['win']:.1f}%  Sh={baseline['sharpe']:.2f}")

    filters = [
        ("Skip Normal VIX (13-18) + Secondary",
         lambda r: not (13 <= r["vix"] < 18 and r["tier"] == "SECONDARY")),
        ("Skip Normal VIX (13-18) entirely",
         lambda r: not (13 <= r["vix"] < 18)),
        ("Skip per-stock vol < 15%",
         lambda r: r["rvol"] >= 15),
        ("Skip Normal VIX + low stock vol (<20%)",
         lambda r: not (13 <= r["vix"] < 18 and r["rvol"] < 20)),
        ("Keep only: VIX<13 OR VIX≥18",
         lambda r: r["vix"] < 13 or r["vix"] >= 18),
        ("Keep only: VIX≥18 (stressed)",
         lambda r: r["vix"] >= 18),
        ("Keep only: stock vol ≥ 25%",
         lambda r: r["rvol"] >= 25),
        ("Keep only: VIX<13 + stock vol ≥ 20%",
         lambda r: r["vix"] < 13 and r["rvol"] >= 20),
    ]

    for label, cond in filters:
        filtered = valid[valid.apply(cond, axis=1)]
        if len(filtered) < 30:
            report.append(f"  {label:50s}: N={len(filtered):4d}  (insufficient)")
            continue
        s = calc_stats(filtered["pnl_pct"].values)
        delta_sh = s["sharpe"] - baseline["sharpe"]
        delta_win = s["win"] - baseline["win"]
        kept_pct = len(filtered) / len(valid) * 100
        report.append(f"  {label:50s}: N={s['n']:4d} ({kept_pct:4.0f}%)  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}  "
                      f"ΔSh={delta_sh:+.2f}  ΔW={delta_win:+.1f}pp")


def test_bars_held_by_vol(df, report):
    """TEST 6: Do high-vol trades resolve faster (fewer bars held)?"""
    report.append("\n" + "=" * 70)
    report.append("TEST 6: BARS HELD BY VOL REGIME")
    report.append("=" * 70)

    valid = df.dropna(subset=["rvol"])
    if "bars_held" not in valid.columns:
        report.append("  bars_held column not available — skipping")
        return

    vol_cuts = [("Vol<15%", 0, 15), ("Vol 15-25%", 15, 25),
                ("Vol 25-40%", 25, 40), ("Vol>40%", 40, 999)]

    for label, lo, hi in vol_cuts:
        bucket = valid[(valid["rvol"] >= lo) & (valid["rvol"] < hi)]
        if len(bucket) < 20:
            continue
        avg_bars = bucket["bars_held"].mean()
        med_bars = bucket["bars_held"].median()
        wins = bucket[bucket["pnl_pct"] > 0]
        loses = bucket[bucket["pnl_pct"] <= 0]
        avg_win_bars = wins["bars_held"].mean() if len(wins) > 0 else 0
        avg_lose_bars = loses["bars_held"].mean() if len(loses) > 0 else 0
        report.append(f"  {label:15s}: N={len(bucket):4d}  avg_bars={avg_bars:.1f}  "
                      f"med={med_bars:.0f}  win_bars={avg_win_bars:.1f}  "
                      f"lose_bars={avg_lose_bars:.1f}")

    r = np.corrcoef(valid["rvol"].values, valid["bars_held"].values)[0, 1]
    report.append(f"\n  Correlation (rvol vs bars_held): r={r:.4f}")
    if r < -0.05:
        report.append("  → Higher vol = faster resolution (fewer bars)")
    elif r > 0.05:
        report.append("  → Higher vol = slower resolution (more bars)")
    else:
        report.append("  → Vol doesn't affect trade duration")


def test_rvol_correlation_deep(df, report):
    """TEST 7: Deeper correlation analysis — partial correlations, rank correlation."""
    report.append("\n" + "=" * 70)
    report.append("TEST 7: DEEPER CORRELATION ANALYSIS")
    report.append("=" * 70)

    valid = df.dropna(subset=["rvol", "vix"])

    # Pearson
    r_pear = np.corrcoef(valid["rvol"].values, valid["pnl_pct"].values)[0, 1]
    report.append(f"\n  Pearson r (rvol vs pnl):  {r_pear:.4f}")

    # Spearman rank
    try:
        from scipy import stats
        rho, p_rho = stats.spearmanr(valid["rvol"].values, valid["pnl_pct"].values)
        report.append(f"  Spearman ρ (rvol vs pnl): {rho:.4f}  p={p_rho:.4f}")
    except ImportError:
        rho = 0

    # Partial correlation: rvol vs pnl controlling for VIX
    try:
        from scipy import stats
        # Regress pnl on VIX, get residuals
        slope_pv, intercept_pv, _, _, _ = stats.linregress(valid["vix"].values, valid["pnl_pct"].values)
        pnl_resid = valid["pnl_pct"].values - (slope_pv * valid["vix"].values + intercept_pv)
        # Regress rvol on VIX, get residuals
        slope_rv, intercept_rv, _, _, _ = stats.linregress(valid["vix"].values, valid["rvol"].values)
        rvol_resid = valid["rvol"].values - (slope_rv * valid["vix"].values + intercept_rv)
        # Correlate residuals
        r_partial = np.corrcoef(rvol_resid, pnl_resid)[0, 1]
        report.append(f"  Partial r (rvol vs pnl | VIX): {r_partial:.4f}")
        if abs(r_partial) < 0.03:
            report.append("  → After controlling for VIX, per-stock vol adds NOTHING")
        elif abs(r_partial) > 0.08:
            report.append("  → Per-stock vol has independent predictive value beyond VIX")
        else:
            report.append("  → Marginal independent effect")
    except ImportError:
        report.append("  (scipy not installed — skipping partial correlation)")

    # VIX vs rvol correlation (how much overlap?)
    r_vix_rvol = np.corrcoef(valid["vix"].values, valid["rvol"].values)[0, 1]
    report.append(f"\n  VIX vs stock vol correlation: r={r_vix_rvol:.4f}")
    if r_vix_rvol > 0.4:
        report.append("  → High overlap — VIX already captures most of stock vol regime")
    elif r_vix_rvol > 0.2:
        report.append("  → Moderate overlap — some independent signal in stock vol")
    else:
        report.append("  → Low overlap — stock vol is genuinely independent of VIX")


# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="vol_deep_backtest_report.txt")
    args = parser.parse_args()

    trades_df = load_trades(args.trades)
    logger.info("Trades: %d, symbols: %d", len(trades_df), trades_df["symbol"].nunique())

    logger.info("Fetching India VIX...")
    vix_series = fetch_vix(trades_df)
    logger.info("Computing per-stock realized vol...")
    rvols = compute_rvol(trades_df)
    logger.info("Rvol computed: %d/%d", np.sum(~np.isnan(rvols)), len(rvols))

    trades_df["rvol"] = rvols
    if vix_series is not None:
        trades_df["vix"] = match_vix(trades_df, vix_series)

    report = []
    report.append("=" * 70)
    report.append("DEEP VOLATILITY REGIME BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(trades_df)} | Symbols: {trades_df['symbol'].nunique()}")
    report.append(f"Dates: {trades_df['entry_date'].min().date()} → {trades_df['entry_date'].max().date()}")
    report.append(f"Rvol range: {np.nanmin(rvols):.1f}% – {np.nanmax(rvols):.1f}%  median={np.nanmedian(rvols):.1f}%")
    report.append("=" * 70)

    test_rvol_quintiles(trades_df, report)
    test_rvol_within_vix(trades_df, report)
    test_3x3_matrix(trades_df, report)
    test_tier_interaction(trades_df, report)
    test_vol_filter_simulation(trades_df, report)
    test_bars_held_by_vol(trades_df, report)
    test_rvol_correlation_deep(trades_df, report)

    report.append("\n" + "=" * 70)
    report.append("DECISION FRAMEWORK")
    report.append("=" * 70)
    report.append("""
  KEY QUESTIONS THIS REPORT ANSWERS:

  1. Is per-stock vol monotonically predictive? (Test 1 quintiles)
     → If yes: consider as score modifier
     → If non-monotonic: not a clean signal

  2. Does stock vol matter AFTER controlling for VIX? (Test 2, 7)
     → If partial r ≈ 0: VIX alone is sufficient
     → If partial r > 0.08: stock vol adds independent value

  3. Does vol affect PRIMARY vs SECONDARY differently? (Test 4)
     → If only one tier shows significance: apply filter selectively

  4. Which regime filter improves Sharpe most? (Test 5)
     → Pick the filter with best ΔSharpe that keeps ≥50% of trades

  5. Do high-vol trades resolve faster? (Test 6)
     → If yes: high vol is GOOD for mean reversion (faster PT hits)
     → Validates keeping high vol entries rather than filtering them

  IMPLEMENTATION OPTIONS (ranked by data support):
    A. VIX-only sizing gate (if stock vol adds nothing beyond VIX)
    B. VIX sizing + stock vol score modifier (if independent effect)
    C. Combined regime filter (if 3x3 matrix shows clear winners/losers)
    D. Display context only (if nothing is significant after proper testing)
""")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
