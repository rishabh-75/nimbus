# Composite Rank Rotation Research

Research thread: does **composite-rank rotation** at the industry
level predict forward returns? Inspired by Marathon Asset
Management's capital-cycle thesis (Edward Chancellor, *Capital
Returns*) — capital flows to industries where returns are rising
and away from industries where returns are falling. We can't
observe capex or supply directly from price+volume, but we can
observe the *relative* trajectory of an industry's composite
score among its peers.

## Status: ARCHIVED — DO NOT SHIP

**Walk-forward run on 2026-04-25 produced a clean negative
result.** No (window, band) cell cleared the ship criteria.
Largest test-fold lift across 15 cells × 4 folds was -0.21pp
(BIG_FALL at 20d, 100% sign agreement) — well below the 0.5pp
threshold required to ship.

Verdict file: `run_2026_04_25_walk_forward_verdict.txt`

## Key takeaways

The signal direction was correct everywhere it was measurable:

- **BIG_FALL at 20d**: -0.21pp test lift, 100% fold sign-agreement.
  Industries falling 10+ ranks over 20 days deliver below-baseline
  returns. Direction real; magnitude too small to act on.
- **BIG_CLIMB at 20d**: +0.08pp test lift, 100% sign agreement.
  Symmetric direction but even smaller magnitude.
- **5d / 10d windows**: noisier, more sign disagreement across
  folds, no meaningful lifts.

## Why it failed walk-forward

Three honest explanations, all probably partly true:

1. **The signal is real but mostly subsumed by composite itself.**
   Composite already incorporates trend, momentum, and inflow.
   Industries climbing rank are by construction already in the
   high-momentum tail of the cross-section — their member symbols
   already trade at elevated technical scores. Rank-Δ doesn't add
   incremental information beyond what composite already says.

2. **Cross-sectional noise dominates at the industry level.**
   Indian equity industries show high common-factor correlation
   — they mostly move together with small dispersion, not in
   distinct rotations.

3. **Sample sizes are huge so the small effect is statistically
   robust** — but the magnitudes are just too small. With 30,000+
   test observations per cell, a 0.21pp effect is real but not
   actionable.

## What this rules out and what it doesn't

**Rules out**:
- Shipping a "Rank Δ" column color-coded by validated bands. The
  validated bands' magnitudes are operationally meaningless.
- Feeding rank-rotation into conviction scoring.

**Doesn't rule out**:
- The Marathon thesis as a whole — it's just not capturable at
  this resolution from price+volume alone. Real capital-cycle
  signals would need supply-side data (capex, share count growth,
  IPO calendars, promoter holding changes).
- A different composite formula. The script is parameterized;
  swap `_compute_composite_series` and re-run if the formula
  evolves.

## Hypothesis tested (for posterity)

Industries climbing the cross-sectional composite-rank ladder
over the past N days deliver above-baseline forward returns;
industries falling deliver below-baseline returns. Symmetric.

## Methodology (as run)

1. Compute composite per (industry, bar) using same formula as
   live UI: `trend + momentum*0.5 + inflow`.
2. Rank cross-sectionally per bar (1 = highest among ~50
   industries).
3. Compute Δrank over 5 / 10 / 20 day lookbacks.
4. Stratify into 5 bands: BIG_CLIMB / MILD_CLIMB / FLAT /
   MILD_FALL / BIG_FALL.
5. Pool member-symbol fwd_10d returns per (window, band, fold),
   measure lift vs universe baseline.
6. Walk-forward 4 expanding folds with 10-bar purge.

## Ship rule (locked in before run)

- Sign agreement ≥ 75% of folds (≥ 3 of 4)
- |mean test-fold lift| ≥ 0.5 pp absolute

## How to re-run

```bash
python scripts/run_composite_rank_rotation_validation.py
```

Reuses the enriched panel cache. Output lands at:
`scripts/output/composite_rank_rotation_validation.txt`

Re-running with the same composite formula will produce the same
verdict. Re-run if you change the composite formula and want to
test whether the new formula's rank rotation is shippable.
