"""Unit tests for nimbus_v3.conviction.grade_engine."""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
import pytest

from nimbus_v3.conviction.grade_engine import (
    Conviction,
    ConvictionEngine,
    GRADE_THRESHOLDS,
    TAKE_SCORE_MIN,
)
from nimbus_v3.core.context import (
    ContextBundle, FilingContext, MarketContext, SectorContext,
)
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import (
    FilingImpact, GradeLetter, RSRegime, SetupType, Sizing, Verdict, VIXRegime,
)
from nimbus_v3.strategies.base import StrategySignal


_ASOF = pd.Timestamp("2024-05-15")   # Wednesday


# ══════════════════════════════════════════════════════════════════════════════
# Fixture builders (shared with formula tests — duplicated here to decouple)
# ══════════════════════════════════════════════════════════════════════════════

def _state(**overrides) -> SignalState:
    defaults = dict(
        symbol="R", bar_date=_ASOF, bar_index=250,
        open=100.0, high=100.0, low=100.0, close=100.0, volume=1e6,
        sma_10=99.0, sma_20=98.0, sma_50=95.0, sma_200=90.0,
        wr_14=-50.0, wr_20=-50.0, wr_30=-50.0, wr_50=-50.0,
        rsi_14=50.0, mfi_14=50.0, mfi_slope_3=0.0,
        adx_14=25.0, atr_14=1.0, atr_14_pct=1.0,
        bb_20_1s_upper=101.0, bb_20_1s_mid=100.0,
        bb_20_1s_lower=99.0, bb_20_1s_pct=0.5,
        bb_20_2s_upper=103.0, bb_20_2s_lower=97.0,
        bbw_20_2s=6.0, bbw_20_2s_slope=0.0, bbw_20_2s_pctl=50.0,
        pct_from_sma_20=0.0, pct_from_sma_50=0.0, pct_from_sma_200=0.0,
        above_sma_20=True, above_sma_50=True, above_sma_200=True,
        dd_from_high_20=0.0, dd_from_high_50=0.0,
        red_streak=0, green_streak=0,
        vol_ratio_20=1.0, roc_5=0.0, roc_10=0.0, roc_20=0.0,
        data_sufficient=True,
    )
    defaults.update(overrides)
    return SignalState(**defaults)


def _bundle(*, vix_regime=VIXRegime.NORMAL, vix_streak=0,
              filing_impact=None) -> ContextBundle:
    market = MarketContext(
        asof_date=_ASOF, vix_value=None,
        vix_regime=vix_regime, vix_high_streak=vix_streak,
    )
    sector = SectorContext(
        asof_date=_ASOF, symbol="R", sector_name="X", sector_type=None,
        rs_regime=RSRegime.NEUTRAL, rs_20d=0.0, realized_vol_20d=15.0,
        vol_z_score=0.0,
    )
    filing = None
    if filing_impact is not None:
        filing = FilingContext(
            asof_date=_ASOF, symbol="R",
            latest_impact=filing_impact,
            is_trap=(filing_impact == FilingImpact.TRAP),
            days_since_latest=1, latest_headline="hdr",
        )
    return ContextBundle(symbol="R", asof_date=_ASOF,
                          market=market, sector=sector, filing=filing)


@dataclass
class _FakeStrategy:
    """Minimal Strategy-shaped object for engine tests."""
    name: str = "Test"
    setup_type: SetupType = SetupType.MEAN_REVERSION
    priority: int = 50
    production_weight: float = 1.0

    def accepts(self, meta): return True                     # noqa: ARG002
    def evaluate(self, **kwargs): return None                # noqa: ARG002


def _signal(setup_type=SetupType.MEAN_REVERSION, symbol="R") -> StrategySignal:
    return StrategySignal(
        strategy_name="Test", symbol=symbol,
        setup_type=setup_type, asof_date=_ASOF, priority=50,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Conviction dataclass
# ══════════════════════════════════════════════════════════════════════════════

def test_conviction_is_frozen() -> None:
    import dataclasses
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(), contexts=_bundle(),
        signal=_signal(), strategy=_FakeStrategy(),
    )
    with pytest.raises(dataclasses.FrozenInstanceError):
        c.score = 99.0    # type: ignore[misc]


def test_conviction_carries_contributions_in_fixed_order() -> None:
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(), contexts=_bundle(),
        signal=_signal(), strategy=_FakeStrategy(),
    )
    assert [x.name for x in c.contributions] == [
        "mfi", "volume", "rsi", "divergence",
        "vix", "sector_rs", "sector_vol", "filing", "day_of_week",
    ]


# ══════════════════════════════════════════════════════════════════════════════
# Normal grading path — MR with favourable context
# ══════════════════════════════════════════════════════════════════════════════

def test_mr_sweet_spot_grades_high() -> None:
    """Classic MR setup: oversold, decent volume, HIGH VIX."""
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(mfi_14=22.0, rsi_14=28.0, vol_ratio_20=1.8,
                      mfi_slope_3=2.0),
        contexts=_bundle(vix_regime=VIXRegime.HIGH, vix_streak=7),
        signal=_signal(), strategy=_FakeStrategy(production_weight=1.0),
    )
    assert c.score > 2.0
    assert c.grade in (GradeLetter.A, GradeLetter.B)
    assert c.verdict == Verdict.TAKE
    assert c.sizing in (Sizing.FULL, Sizing.HALF)


def test_weak_mr_signal_grades_low() -> None:
    """Overbought RSI in NORMAL VIX — should grade poorly or SKIP."""
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(mfi_14=75.0, rsi_14=72.0),
        contexts=_bundle(vix_regime=VIXRegime.NORMAL, vix_streak=0),
        signal=_signal(), strategy=_FakeStrategy(production_weight=1.0),
    )
    assert c.score < 0
    assert c.verdict == Verdict.SKIP
    assert c.sizing == Sizing.SKIP


# ══════════════════════════════════════════════════════════════════════════════
# Research-only path — production_weight = 0
# ══════════════════════════════════════════════════════════════════════════════

def test_research_weight_zero_produces_watch_skip() -> None:
    """Even with a strong raw score, weight=0 → WATCH / SKIP / grade D."""
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(mfi_14=15.0, rsi_14=20.0, vol_ratio_20=2.0),
        contexts=_bundle(vix_regime=VIXRegime.HIGH, vix_streak=7),
        signal=_signal(), strategy=_FakeStrategy(production_weight=0.0),
    )
    # Raw score is strong, but weighted score is zero.
    assert c.raw_score > 2.0
    assert c.score == pytest.approx(0.0)
    assert c.grade == GradeLetter.D
    assert c.verdict == Verdict.WATCH
    assert c.sizing == Sizing.SKIP
    assert c.override_reason is not None
    assert "research-only" in c.override_reason


def test_research_weight_still_computes_all_contributions() -> None:
    """Research-tier strategies feed SignalTracker — the full contribution
    trail must be preserved for forward-return attribution."""
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(), contexts=_bundle(),
        signal=_signal(), strategy=_FakeStrategy(production_weight=0.0),
    )
    assert len(c.contributions) == 9


# ══════════════════════════════════════════════════════════════════════════════
# TRAP override — hard stop
# ══════════════════════════════════════════════════════════════════════════════

def test_trap_setup_type_forces_skip() -> None:
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(mfi_14=15.0, rsi_14=20.0),   # would otherwise grade high
        contexts=_bundle(vix_regime=VIXRegime.HIGH, vix_streak=6),
        signal=_signal(setup_type=SetupType.TRAP),
        strategy=_FakeStrategy(setup_type=SetupType.TRAP, priority=100),
    )
    assert c.verdict == Verdict.SKIP
    assert c.sizing == Sizing.SKIP
    assert c.grade == GradeLetter.D
    assert c.override_reason is not None
    assert "TRAP" in c.override_reason


def test_trap_filing_overrides_even_non_trap_setup() -> None:
    """A TRAP-impact filing in the recent window forces SKIP even if the
    setup type is a normal one."""
    engine = ConvictionEngine()
    c = engine.grade(
        state=_state(mfi_14=20.0, rsi_14=25.0),
        contexts=_bundle(filing_impact=FilingImpact.TRAP),
        signal=_signal(setup_type=SetupType.MEAN_REVERSION),
        strategy=_FakeStrategy(),
    )
    assert c.verdict == Verdict.SKIP
    assert c.sizing == Sizing.SKIP
    assert "TRAP" in (c.override_reason or "")


# ══════════════════════════════════════════════════════════════════════════════
# Material filing softens but does not SKIP
# ══════════════════════════════════════════════════════════════════════════════

def test_material_filing_penalises_but_allows_grading() -> None:
    """MATERIAL filing reduces score via contribution but doesn't force SKIP."""
    engine = ConvictionEngine()
    c_clean = engine.grade(
        state=_state(mfi_14=20.0, rsi_14=25.0, vol_ratio_20=1.5),
        contexts=_bundle(vix_regime=VIXRegime.HIGH, vix_streak=7),
        signal=_signal(), strategy=_FakeStrategy(),
    )
    c_material = engine.grade(
        state=_state(mfi_14=20.0, rsi_14=25.0, vol_ratio_20=1.5),
        contexts=_bundle(vix_regime=VIXRegime.HIGH, vix_streak=7,
                           filing_impact=FilingImpact.MATERIAL),
        signal=_signal(), strategy=_FakeStrategy(),
    )
    assert c_material.score < c_clean.score
    assert c_material.override_reason is None    # not a hard override


# ══════════════════════════════════════════════════════════════════════════════
# _score_to_grade boundaries
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("score,expected", [
    (5.0, GradeLetter.A),
    (3.0, GradeLetter.A),   # boundary inclusive
    (2.99, GradeLetter.B),
    (1.5, GradeLetter.B),   # boundary inclusive
    (1.49, GradeLetter.C),
    (0.0, GradeLetter.C),   # boundary inclusive
    (-0.01, GradeLetter.D),
    (-5.0, GradeLetter.D),
])
def test_score_to_grade_boundaries(score, expected) -> None:
    assert ConvictionEngine._score_to_grade(score) == expected


# ══════════════════════════════════════════════════════════════════════════════
# _score_to_verdict boundaries
# ══════════════════════════════════════════════════════════════════════════════

def test_score_to_verdict_skip_for_negative() -> None:
    bundle = _bundle()
    assert ConvictionEngine._score_to_verdict(-0.1, bundle) == Verdict.SKIP


def test_score_to_verdict_take_at_threshold() -> None:
    bundle = _bundle()
    assert ConvictionEngine._score_to_verdict(TAKE_SCORE_MIN, bundle) == Verdict.TAKE
    assert ConvictionEngine._score_to_verdict(TAKE_SCORE_MIN - 0.01, bundle) == Verdict.WATCH


# ══════════════════════════════════════════════════════════════════════════════
# _verdict_to_sizing
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("verdict,grade,expected", [
    (Verdict.SKIP, GradeLetter.A, Sizing.SKIP),
    (Verdict.SKIP, GradeLetter.B, Sizing.SKIP),
    (Verdict.WATCH, GradeLetter.A, Sizing.SKIP),
    (Verdict.WATCH, GradeLetter.B, Sizing.SKIP),
    (Verdict.TAKE, GradeLetter.A, Sizing.FULL),
    (Verdict.TAKE, GradeLetter.B, Sizing.HALF),
    (Verdict.TAKE, GradeLetter.C, Sizing.HALF),      # boundary defensive default
    (Verdict.TAKE, GradeLetter.D, Sizing.HALF),
])
def test_verdict_to_sizing_matrix(verdict, grade, expected) -> None:
    assert ConvictionEngine._verdict_to_sizing(verdict, grade) == expected


# ══════════════════════════════════════════════════════════════════════════════
# End-to-end invariants
# ══════════════════════════════════════════════════════════════════════════════

def test_engine_is_stateless() -> None:
    """Same inputs → same Conviction, regardless of call order or engine instance."""
    engine1 = ConvictionEngine()
    engine2 = ConvictionEngine()
    state, bundle, sig, strat = _state(), _bundle(), _signal(), _FakeStrategy()
    c1 = engine1.grade(state=state, contexts=bundle, signal=sig, strategy=strat)
    c2 = engine2.grade(state=state, contexts=bundle, signal=sig, strategy=strat)
    c3 = engine1.grade(state=state, contexts=bundle, signal=sig, strategy=strat)
    assert c1.score == c2.score == c3.score
    assert c1.grade == c2.grade == c3.grade


def test_conviction_carries_production_weight_for_tracker() -> None:
    """SignalTracker (Phase 6) needs to distinguish production from research
    signals in the log. The weight field is authoritative."""
    engine = ConvictionEngine()
    c_prod = engine.grade(
        state=_state(), contexts=_bundle(),
        signal=_signal(), strategy=_FakeStrategy(production_weight=1.0),
    )
    c_research = engine.grade(
        state=_state(), contexts=_bundle(),
        signal=_signal(), strategy=_FakeStrategy(production_weight=0.0),
    )
    assert c_prod.production_weight == 1.0
    assert c_research.production_weight == 0.0
