"""Debug utility — per-criterion boolean breakdown.

Uses the same criterion functions as ``engine.py`` so there is no
risk of drift between fire detection and debug output.
"""

from __future__ import annotations

import pandas as pd

from . import criteria as cr
from .constants import REQUIRED_COLS
from .engine import _continuation_fire, _initiation_fire, _retest_fire


def debug_fire_criteria(df: pd.DataFrame) -> pd.DataFrame:
    """Return a DataFrame with one boolean column per criterion,
    aligned to ``df``'s index. Useful for diagnosing why a symbol
    produces no fires.

    Columns are grouped by phase. Each phase's combined fire bool
    is the last column of its group.
    """
    if not all(c in df.columns for c in REQUIRED_COLS):
        missing = [c for c in REQUIRED_COLS if c not in df.columns]
        raise ValueError(f"Missing required columns: {missing}")

    return pd.DataFrame(
        {
            # Shared / INITIATION
            "hold_ok": cr.crit_hold_ok(df),
            "fresh_cross": cr.crit_fresh_cross(df),
            "not_detached_today": cr.crit_not_detached_today(df),
            "not_detached_yest": cr.crit_not_detached_yesterday(df),
            "open_zone_today": cr.crit_open_in_zone(df),
            "not_gap_through": cr.crit_not_gap_through(df),
            "slope_ok": cr.crit_slope_ok(df),
            "bbw_ok": cr.crit_bbw_ok(df),
            "vol_surge": cr.crit_vol_surge(df),
            "body_strength": cr.crit_body_strength(df),
            "init_fire": _initiation_fire(df),
            # CONTINUATION
            "cont_established_ride": cr.crit_cont_established_ride(df),
            "cont_not_extended": cr.crit_cont_not_extended(df),
            "cont_above_trend": cr.crit_cont_above_trend(df),
            "cont_vol_not_decayed": cr.crit_cont_vol_not_decayed(df),
            "cont_fire": _continuation_fire(df),
            # RETEST
            "retest_qualified_base": cr.crit_retest_qualified_base(df),
            "retest_pullback_occurred": cr.crit_retest_pullback_occurred(df),
            "retest_held_sma": cr.crit_retest_held_sma(df),
            "retest_resumption": cr.crit_retest_resumption(df),
            "retest_fire": _retest_fire(df),
        },
        index=df.index,
    )
