<!--
TEMPLATE — copy this file to docs/research/NNN-short-slug.md for each
new research effort, fill it in, and delete the script once the findings
and any reusable code snippets are captured here.

Numbering: zero-padded sequential (001, 002, ...). The slug is a short
kebab-case topic. Example: docs/research/004-bbw-percentile-gate.md
-->

# RT-NNN · <Title of the research question>

| Field        | Value                                              |
|--------------|----------------------------------------------------|
| Date         | YYYY-MM-DD                                          |
| Status       | `exploratory` \| `validated` \| `rejected` \| `superseded` |
| Outcome      | One-line verdict (what changed in the system, or "no change") |
| Baked into   | File(s)/constant(s) the finding now lives in, or "—" |
| Data window  | e.g. "NSE 500, 2019-01 → 2026-04, 4H bars"          |

## Question

What were we trying to find out, stated as a falsifiable question?

## Hypothesis

What we expected before running it, and why.

## Methodology

How the study was actually run — enough that someone could reproduce it
without the original script:

- Universe / sample
- Indicators / features computed (reference `compute/` where reused)
- The specific test (sweep grid, ablation arms, walk-forward folds, etc.)
- Success metric and threshold for "this works"
- Controls / what was held fixed

## Key code

The reusable core of the (now-deleted) script — not the whole CLI
scaffolding, just the logic worth keeping. Trim I/O, argparse, logging.

```python
# e.g. the actual scoring/aggregation that produced the result
```

## Results

The numbers. Tables welcome. Include the negative/null results too —
knowing what *didn't* work is half the value of the log.

| Arm / variant | Metric | n | Notes |
|---------------|--------|---|-------|
|               |        |   |       |

## Conclusion & decision

What we concluded and what we did about it (changed a constant, added a
gate, dropped the idea). If a constant changed, record old → new value.

## Reproduce

Minimal steps to re-run if ever needed (which cache, which symbols,
roughly how long). Since the script is gone, this is the "Key code" block
above plus the data pointer.
