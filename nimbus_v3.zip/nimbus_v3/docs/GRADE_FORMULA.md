# GRADE_FORMULA

**Status:** Placeholder. Populated in Phase 4 (Conviction).

## Purpose

Human-readable authoritative specification of the grade formula implemented in
`nimbus_v3/conviction/formula.py`. Every contribution function in the code maps
to a section in this document with:

- The function's signature and inputs.
- The rule in plain English.
- The point range it can produce (e.g. `-5 to +10`).
- The reason string emitted when the contribution is non-zero.
- The worked-example inputs and expected output.
- The provenance: walk-forward result or oracle validation that justifies the
  contribution.

## Authority when docs, code, and fixtures disagree

Per `ARCHITECTURE.md §18.4`:

1. **Golden fixtures** (`nimbus_v3/conviction/fixtures/golden.json`) are
   authoritative. They are the definition of correct.
2. **`formula.py`** implements the fixtures.
3. **This document** describes both. It is refreshed whenever the formula or
   fixtures change.

## Contributions (to be populated in Phase 4)

- `mfi_contribution(state)`
- `volume_contribution(state)`
- `rsi_contribution(state)`
- `vix_contribution(market_ctx)`
- `sector_rs_contribution(sector_ctx, signal)`
- `sector_vol_contribution(sector_ctx, market_ctx)` — **deferred to Phase 7
  research validation** per `ARCHITECTURE.md §18.8`.
- `divergence_contribution(state)`
- `filing_contribution(filing_ctx)`
- `flow_contribution(flow_ctx)`
- `event_contribution(event_ctx)`
- `day_of_week_contribution(state)`

## Verdict derivation

To be populated in Phase 4. See `nimbus_v3/conviction/verdict.py`.

## Sizing derivation

To be populated in Phase 4. See `nimbus_v3/conviction/sizing.py`.
