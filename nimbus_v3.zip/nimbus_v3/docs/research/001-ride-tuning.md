# RT-001 · Ride continuation / retest detection tuning

| Field        | Value                                                       |
|--------------|-------------------------------------------------------------|
| Date         | 2026-05 (consolidated retroactively)                        |
| Status       | `validated`                                                 |
| Outcome      | Locked the CONT/RETEST lookback windows and body/detachment thresholds; the four reference symbols classify exactly. |
| Baked into   | `compute/ride_initiation/constants.py`, `criteria.py`, `engine.py` |
| Data window  | NSE 500, 4H Bollinger(20, 1σ) + Williams %R(50)             |

## Question

What window lengths and band thresholds make the 4H ride classifier
fire CONT (established ride) and RETEST (first-dip re-entry) on real
NSE names without over- or under-firing?

## Hypothesis

The original windows (CONT over the last 10 bars needing 5 above-band;
detachment ceiling at %B 1.5) were too loose — they let late, extended
entries through and were slow to recognise a fresh ride.

## Methodology

- Reference symbols with known-correct intended labels were used as
  fixtures: AWL (RETEST), CLEAN, CIPLA, SUNPHARMA (all CONT).
- Each candidate constant was swept and the resulting phase + viability
  score on the latest bar compared against the intended label.
- The classifier is the single source of truth (`RideEngine.classify`);
  no separate scoring path. Success = all four fixtures land on their
  intended phase with a stable score, and the contract test-suite
  (70 ride tests) stays green.
- A `schema_hash` over every classifier constant guards against silent
  drift — it must stay `3eb7942e`.

## Key code

The established-ride ("continuation") test — at least N of the last M
bars closed with %B ≥ 1.0, and the entry bar isn't over-detached:

```python
# criteria.py (essence)
prior_above = (pctb_close >= 1.0).shift(1).rolling(
    CONT_RIDE_LOOKBACK, min_periods=1
).sum()
is_established = prior_above >= CONT_RIDE_BARS_MIN
is_not_detached = pctb_close <= CONT_DETACHED_PCTB_MAX
cont_fires = is_established & is_not_detached & body_ok
```

## Results

Final constants (old → new):

| Constant                  | Initial | Final | Effect                          |
|---------------------------|---------|-------|---------------------------------|
| `CONT_RIDE_LOOKBACK`      | 10      | 3     | Recognise a ride faster         |
| `CONT_RIDE_BARS_MIN`      | 5       | 3     | (paired with lookback)          |
| `CONT_DETACHED_PCTB_MAX`  | 1.5     | 1.7   | Allow slightly hotter CONT entry |
| `BODY_STRENGTH_MIN`       | 0.35    | 0.25  | Don't reject modest-body bars    |
| `RETEST_PULLBACK_MAX_BARS`| —       | 5     | First-dip window after detach    |
| `RETEST_ACTIVE_WINDOW`    | —       | 2     | Retest must be recent            |

Verified classifications (latest bar):

| Symbol    | Phase  | Score |
|-----------|--------|-------|
| AWL       | RETEST | 40.9  |
| CLEAN     | CONT   | 26.9  |
| CIPLA     | CONT   | 36.3  |
| SUNPHARMA | CONT   | 36.7  |

## Conclusion & decision

Adopted the final constants. `riding_upper` keys off `position_state`
(`RIDING_UPPER` / `FIRST_DIP`), not a single-bar `spot >= bb_upper`
check. The momentum filter (Williams %R) is a hard gate.

## Reproduce

```python
import pandas as pd
from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import RideEngine
e = StrategyComputeEngine()
for f in ["AWL", "CLEAN", "CIPLA", "SUNPHARMA"]:
    r = RideEngine().classify(e.enrich(pd.read_parquet(f"{f}.parquet"), f))
    print(f, r.phase.iloc[-1], r.latest_score)
# expect: AWL RETEST 40.9 | CLEAN CONT 26.9 | CIPLA CONT 36.3 | SUNPHARMA CONT 36.7
```
