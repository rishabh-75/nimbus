"""nimbus_v3.strategies.mean_reversion_tracking — conservative-tier MR tracking.

Companion to :class:`MeanReversionStrategy` (conservative production).
Where the production strategy requires oracle's strict three-gate
primary (roc_5<-3, bbw_pctl<40, vix_streak>=6), this tracking strategy
captures the broader "developing oversold below trend" population
that doesn't meet all three gates simultaneously — most commonly
the vix_streak gate, which only passes during sustained high-VIX
regimes.

Matches the same design as :mod:`.aggressive_mean_reversion_tracking`:
shared ``setup_type = SetupType.MEAN_REVERSION`` so it routes to the
MR bucket, but ``production_weight = 0.0`` so the conviction engine's
research-only override forces grade=D, verdict=WATCH, sizing=SKIP.
Shows up in the Scanner MR table alongside real graded entries.

Rationale for conservative-mode tracking
────────────────────────────────────────

Before this strategy existed, the conservative MR panel was empty
whenever any of:
  - VIX was not on a sustained high-streak (vix_streak<6)
  - Volatility regime was normal/wide (bbw_pctl>=40)
  - The recent move wasn't sharp enough (roc_5>=-3)
…and the operator saw no MR-labelled candidates even when plenty of
stocks were demonstrably oversold. The tracking tier fixes that by
surfacing the oversold-below-trend population for operator
awareness, without upgrading them to graded-entry status.

De-duplication
──────────────

When the production gates would fire for a bar, this tracking
strategy returns None. Prevents double-emission in the MR bucket.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class MeanReversionTrackingParams:
    #: Only gate — WR<-30 is the MR regime marker. No vix_streak,
    #: bbw_pctl, or roc_5 requirement; those are on the production
    #: sibling. Tracking surfaces every oversold-below-trend case.
    wr_30_max: float = -30.0


#: Primary-tier gates from MeanReversion for de-dupe.
_PRIMARY_ROC_5_MAX: float = -3.0
_PRIMARY_BBW_PCTL_MAX: float = 40.0
_PRIMARY_VIX_STREAK_MIN: int = 6


class MeanReversionTrackingStrategy:
    """Developing-oversold MR tracking (conservative-tier). Rejects ETFs.

    Routes to the same MR bucket as :class:`MeanReversionStrategy`
    via shared setup_type, but weight=0 triggers the conviction
    research-override → grade=D / verdict=WATCH / sizing=SKIP —
    ungraded tracking rows alongside the real graded entries.
    """

    name: str = "MeanReversionTracking"
    setup_type: SetupType = SetupType.MEAN_REVERSION
    priority: int = 45          # below MeanReversion's 50 — sorts after entries
    production_weight: float = 0.0

    def __init__(
        self,
        params: MeanReversionTrackingParams = MeanReversionTrackingParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        # Core: oversold on WR(30).
        if state.wr_30 >= self._p.wr_30_max:
            return None
        # Below-trend guard — an oversold stock above its SMA_20 is
        # a pullback candidate, not a reversion candidate. The
        # production MR also implicitly filters this via the
        # roc_5<-3 + bbw_pctl<40 combination, so keeping it here
        # preserves semantic consistency.
        if state.above_sma_20:
            return None
        if state.sma_20 <= 0:
            return None

        # De-dupe: if all production gates fire, let the production
        # MeanReversion emit instead (it'll get a real grade).
        primary_fires = (
            state.roc_5 < _PRIMARY_ROC_5_MAX
            and state.bbw_20_2s_pctl < _PRIMARY_BBW_PCTL_MAX
            and contexts.market.vix_high_streak >= _PRIMARY_VIX_STREAK_MIN
        )
        if primary_fires:
            return None

        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "wr_30": state.wr_30,
                "roc_5": state.roc_5,
                "bbw_pctl": state.bbw_20_2s_pctl,
                "vix_streak": contexts.market.vix_high_streak,
                "pct_from_sma_20": state.pct_from_sma_20,
                "kind": "tracking",
            },
        )
