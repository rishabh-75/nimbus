"""nimbus_v3.compute.breadth_regime — market-breadth regime state.

Stateless. Maps a breadth snapshot (or the daily breadth frame) to a
coarse market-regime label, for **display** in the sidebar.

This is the COUNT definition validated in RT-004 (full-universe,
92,291 resolved events): rides fired when more breadth signals are
"on" sustained materially better (RISK_ON 55.8% win / +0.71% vs
RISK_OFF 49.3% / +0.09%, a clean monotonic gradient). The regime is
shown as context — it does NOT gate or score rides. The operator
decides whether to act on a weak tape.

Signals (4 breadth, + optional price-trend when an index is supplied):
    level   : % above SMA50 > 50
    expand  : % above SMA50 rising over the lookback
    ad      : A/D line rising over the lookback
    nhnl    : new highs − new lows > 0
    (price) : index above its own SMA50 — optional 5th signal

Buckets: signals_on >= n-1 → RISK_ON ; <= 1 → RISK_OFF ; else NEUTRAL.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

#: Lookback (trading days) for the "rising / expanding" signals.
#: Matches the value used in the RT-004 validation.
SLOPE_LOOKBACK: int = 10

RISK_ON = "RISK_ON"
NEUTRAL = "NEUTRAL"
RISK_OFF = "RISK_OFF"


@dataclass(frozen=True)
class RegimeState:
    """Latest-bar regime readout."""

    label: str              # RISK_ON / NEUTRAL / RISK_OFF / "—"
    signals_on: int
    n_signals: int
    # individual signal booleans (None when undeterminable)
    level: bool | None
    expand: bool | None
    ad: bool | None
    nhnl: bool | None


def classify_regime(
    breadth: pd.DataFrame, index_close: pd.Series | None = None,
) -> RegimeState:
    """Classify the latest-bar regime from the daily breadth frame.

    Args:
        breadth: output of ``compute_breadth`` (needs ``pct_above_sma50``,
            ``ad_line``, ``nh_nl_diff``).
        index_close: optional index Close series — enables the
            price-trend signal (index > its SMA50).

    Returns:
        A :class:`RegimeState`. Label is ``"—"`` when there's
        insufficient history to evaluate the signals.
    """
    if breadth is None or breadth.empty or len(breadth) <= SLOPE_LOOKBACK:
        return RegimeState("—", 0, 0, None, None, None, None)

    pct50 = breadth["pct_above_sma50"]
    ad_line = breadth["ad_line"]
    nhnl = breadth["nh_nl_diff"]

    level = bool(pct50.iloc[-1] > 50.0) if pct50.iloc[-1] == pct50.iloc[-1] else None
    expand = bool(pct50.iloc[-1] > pct50.iloc[-1 - SLOPE_LOOKBACK]) \
        if pct50.iloc[-1] == pct50.iloc[-1] else None
    ad = bool(ad_line.iloc[-1] > ad_line.iloc[-1 - SLOPE_LOOKBACK])
    nh = bool(nhnl.iloc[-1] > 0)

    signals: list[bool] = [level or False, expand or False, ad, nh]
    n_signals = 4
    if index_close is not None and not index_close.empty:
        idx = index_close.reindex(breadth.index).ffill()
        idx_sma50 = idx.rolling(50, min_periods=50).mean()
        price_on = bool(idx.iloc[-1] > idx_sma50.iloc[-1]) \
            if idx_sma50.iloc[-1] == idx_sma50.iloc[-1] else False
        signals = [price_on] + signals
        n_signals = 5

    on = sum(int(s) for s in signals)
    if on >= n_signals - 1:
        label = RISK_ON
    elif on <= 1:
        label = RISK_OFF
    else:
        label = NEUTRAL

    return RegimeState(
        label=label, signals_on=on, n_signals=n_signals,
        level=level, expand=expand, ad=ad, nhnl=nh,
    )
