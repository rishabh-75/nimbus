#!/usr/bin/env python3
"""
scripts/run_weekly_trend_backtest.py — Does weekly trend improve mean reversion?

Hypothesis: Mean reversion entries in an UPTREND (weekly SMA rising, price > weekly SMA)
should outperform entries in a DOWNTREND (price < weekly SMA, SMA falling).

Tests:
  1. Weekly SMA(50) direction at entry: rising vs flat vs falling
  2. Price vs weekly SMA at entry: above vs below
  3. Combined: rising + above vs everything else
  4. As a grade factor: does adding weekly trend to grade improve correlation?

If weekly trend separates outcomes by >5pp win rate, add it as a conviction factor.

Usage:
    python3 scripts/run_weekly_trend_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd
from scipy import stats

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("weekly_trend")


def compute_weekly_trend(price_df, entry_date, sma_period=50):
    """Compute weekly SMA direction and price position at entry_date."""
    if price_df is None or price_df.empty:
        return None

    mask = price_df.index <= entry_date
    df = price_df.loc[mask]
    if len(df) < sma_period * 5 + 20:  # need enough daily bars for weekly SMA
        return None

    # Resample to weekly
    weekly = df["Close"].resample("W").last().dropna()
    if len(weekly) < sma_period + 5:
        return None

    sma = weekly.rolling(sma_period).mean()
    if pd.isna(sma.iloc[-1]) or pd.isna(sma.iloc[-2]):
        return None

    sma_now = float(sma.iloc[-1])
    sma_prev = float(sma.iloc[-5]) if len(sma) > 5 else float(sma.iloc[-2])
    price_now = float(weekly.iloc[-1])

    # SMA direction (5-week slope)
    sma_slope = (sma_now - sma_prev) / sma_prev * 100 if sma_prev > 0 else 0

    return {
        "weekly_sma": sma_now,
        "weekly_price": price_now,
        "above_weekly_sma": price_now > sma_now,
        "pct_from_weekly_sma": (price_now - sma_now) / sma_now * 100,
        "sma_slope_5w": sma_slope,
        "sma_rising": sma_slope > 0.2,  # >0.2% over 5 weeks = rising
        "sma_falling": sma_slope < -0.2,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="weekly_trend_backtest_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    # Load price cache
    price_cache = {}
    for sym in trades_df["symbol"].unique():
        f = f"data/backtest_cache/{sym}_1d.parquet"
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except: pass
    logger.info("Price data: %d/%d symbols", len(price_cache), len(trades_df["symbol"].unique()))

    # Load VIX for regime matching
    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=60)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    # Compute weekly trend for each trade
    logger.info("Computing weekly trend for each trade...")
    rows = []
    skipped = 0
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in price_cache: skipped += 1; continue
        wt = compute_weekly_trend(price_cache[sym], trade["entry_date"])
        if wt is None: skipped += 1; continue

        # Get VIX at entry
        vmask = vix_series.index <= trade["entry_date"]
        vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0
        vix_regime = "PANIC" if vix > 25 else ("ELEVATED" if vix >= 20 else ("NORMAL" if vix >= 13 else "LOW"))

        rows.append({
            "symbol": sym,
            "entry_date": trade["entry_date"],
            "pnl_pct": trade["pnl_pct"],
            "win": int(trade["pnl_pct"] > 0),
            "vix": vix,
            "vix_regime": vix_regime,
            **wt,
        })
        if (len(rows) + skipped) % 500 == 0:
            logger.info("  %d/%d processed", len(rows), len(trades_df))

    df = pd.DataFrame(rows)
    logger.info("Ready: %d trades (%d skipped)", len(df), skipped)

    report = []
    report.append("=" * 70)
    report.append("WEEKLY TREND FILTER BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)} ({skipped} skipped)")
    report.append("=" * 70)

    # ══════════════════════════════════════════════════════════════════
    # TEST 1: SMA direction at entry
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 1: WEEKLY SMA(50) DIRECTION AT ENTRY")
    report.append("=" * 70)

    for label, mask in [
        ("SMA Rising (slope > 0.2%)", df["sma_rising"]),
        ("SMA Flat (-0.2% to +0.2%)", ~df["sma_rising"] & ~df["sma_falling"]),
        ("SMA Falling (slope < -0.2%)", df["sma_falling"]),
    ]:
        sub = df[mask]
        if len(sub) < 20: continue
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        std = sub["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        report.append(f"  {label:40s} N={len(sub):5d}  Win={wr:.1f}%  Avg={avg:+.3f}%  Sh={sh:.2f}")

    # Significance test
    rising = df[df["sma_rising"]]
    falling = df[df["sma_falling"]]
    if len(rising) >= 20 and len(falling) >= 20:
        t, p = stats.ttest_ind(rising["pnl_pct"], falling["pnl_pct"], equal_var=False)
        report.append(f"\n  Rising vs Falling: t={t:.3f}, p={p:.4f}")
        if p < 0.05:
            report.append("  ✓ SIGNIFICANT — weekly trend predicts outcomes")
        else:
            report.append("  ○ NOT significant")

    # ══════════════════════════════════════════════════════════════════
    # TEST 2: Price vs weekly SMA
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 2: PRICE vs WEEKLY SMA(50)")
    report.append("=" * 70)

    for label, mask in [
        ("Price ABOVE weekly SMA", df["above_weekly_sma"]),
        ("Price BELOW weekly SMA", ~df["above_weekly_sma"]),
    ]:
        sub = df[mask]
        if len(sub) < 20: continue
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        std = sub["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        report.append(f"  {label:40s} N={len(sub):5d}  Win={wr:.1f}%  Avg={avg:+.3f}%  Sh={sh:.2f}")

    above = df[df["above_weekly_sma"]]
    below = df[~df["above_weekly_sma"]]
    if len(above) >= 20 and len(below) >= 20:
        t, p = stats.ttest_ind(above["pnl_pct"], below["pnl_pct"], equal_var=False)
        report.append(f"\n  Above vs Below: t={t:.3f}, p={p:.4f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 3: Combined — uptrend vs downtrend
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 3: UPTREND vs DOWNTREND (combined)")
    report.append("=" * 70)

    uptrend = df[df["sma_rising"] & df["above_weekly_sma"]]
    downtrend = df[df["sma_falling"] & ~df["above_weekly_sma"]]
    other = df[~(df["sma_rising"] & df["above_weekly_sma"]) & ~(df["sma_falling"] & ~df["above_weekly_sma"])]

    for label, sub in [("UPTREND (rising + above)", uptrend),
                        ("NEUTRAL (mixed)", other),
                        ("DOWNTREND (falling + below)", downtrend)]:
        if len(sub) < 10: continue
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        std = sub["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        report.append(f"  {label:40s} N={len(sub):5d}  Win={wr:.1f}%  Avg={avg:+.3f}%  Sh={sh:.2f}")

    if len(uptrend) >= 20 and len(downtrend) >= 20:
        t, p = stats.ttest_ind(uptrend["pnl_pct"], downtrend["pnl_pct"], equal_var=False)
        report.append(f"\n  Uptrend vs Downtrend: t={t:.3f}, p={p:.4f}")
        delta = uptrend["win"].mean() * 100 - downtrend["win"].mean() * 100
        report.append(f"  Win rate delta: {delta:+.1f}pp")

    # ══════════════════════════════════════════════════════════════════
    # TEST 4: By VIX regime
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 4: WEEKLY TREND × VIX REGIME")
    report.append("=" * 70)
    report.append(f"\n  {'VIX Regime':12s} {'Trend':12s} {'N':>5s} {'Win%':>6s} {'Avg':>7s} {'Sh':>6s}")

    for regime in ["PANIC", "ELEVATED", "NORMAL", "LOW"]:
        for trend_label, trend_mask in [("Uptrend", df["sma_rising"] & df["above_weekly_sma"]),
                                         ("Downtrend", df["sma_falling"] & ~df["above_weekly_sma"])]:
            sub = df[(df["vix_regime"] == regime) & trend_mask]
            if len(sub) < 10: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            report.append(f"  {regime:12s} {trend_label:12s} {len(sub):5d} {wr:5.1f}% {avg:+6.3f}% {sh:5.2f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 5: Correlation with PnL
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 5: CORRELATION WITH OUTCOMES")
    report.append("=" * 70)

    for col, label in [("sma_slope_5w", "SMA slope (5w)"),
                        ("pct_from_weekly_sma", "% from weekly SMA"),
                        ("above_weekly_sma", "Above weekly SMA (bool)")]:
        r, p = stats.pearsonr(df[col].astype(float), df["pnl_pct"])
        report.append(f"  {label:30s} r={r:+.4f}  p={p:.4f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 6: Downtrend filter — what if we skip downtrend entries?
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 6: SKIP DOWNTREND ENTRIES — IMPACT")
    report.append("=" * 70)

    all_trades = df
    no_downtrend = df[~(df["sma_falling"] & ~df["above_weekly_sma"])]
    uptrend_only = df[df["sma_rising"] & df["above_weekly_sma"]]

    for label, sub in [("All trades", all_trades),
                        ("Skip downtrend", no_downtrend),
                        ("Uptrend only", uptrend_only)]:
        if len(sub) < 20: continue
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        std = sub["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        report.append(f"  {label:25s} N={len(sub):5d}  Win={wr:.1f}%  Avg={avg:+.3f}%  Sh={sh:.2f}")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
