# NIMBUS v3

PyQt6 trading terminal for NSE (Indian markets). Slim ride-strategy
profile: classifies each bar of every F&O symbol into INIT / RETEST /
CONT / NONE using the BB ride classifier, computes a 0–100 composite
conviction score, and renders the result for both individual symbols
(Dashboard) and industry aggregates (Market Pulse).

## What it does

- **Single-symbol Dashboard** — header with spot + Δ%, candlestick
  chart with BB(20, 1σ) envelope and SMA20 overlay, optional options
  walls (resistance / support / max-pain / HVL) when an F&O chain is
  available, and a right-rail Workflow Analysis column with two
  panels: Options Overlay and Industry Context.
- **Market Pulse** — synthetic-index ride classification grouped by
  any of the four NSE classification levels (Macro-Economic Sector,
  Sector, Industry, Basic Industry). ADTV-weighted aggregate
  produces a Phase + Score per group; the constituent table drills
  into a selected group.
- **Sidebar** — drives Dashboard symbol selection. Header echo,
  four-row Industry classification, BB Ride panel (phase, score,
  bars-since-fire, %B, BBW pctl, vs SMA20, verdict + footer),
  REFRESH.

## Strategy

BB ride classifier — single source of truth at
`nimbus_v3.compute.ride_initiation.RideEngine`:

- **Phase resolution priority**: INITIATION > RETEST > CONTINUATION
  > NONE. Highest-priority detector wins on overlap.
- **Composite Score** (0–100): FRESHNESS 30 + VOLUME 25 + BBW 20 +
  MOMENTUM 15 + BODY 10. NaN where no fire.
- **Industry / universe aggregation**: ADTV-weighted synthetic OHLCV
  series, then `classify()` runs on the synthetic — heavyweights
  dominate naturally, no consensus voting.

## Layout

```
nimbus_v3/
├── docs/                architecture notes
├── data/                runtime cache + industry DB (gitignored, NIMBUS_DATA_DIR-aware)
├── nimbus_v3/           the package
│   ├── core/            shared primitives (types, universe, market_session, fno_symbols)
│   ├── data/            price/options loaders, NSE client, parquet caches, paths
│   ├── compute/         indicator math + slim enrichment engine + ride classifier
│   ├── context/         provider surfaces (market, sector, options, filing)
│   └── ui/              PyQt6 — sidebar, presenters, widgets, main_window
├── scripts/             CLI utilities (build industry DB, download universe)
└── tests/               mirrors the package
```

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
python main.py
```

CLI flags:

```
--auto-refresh-interval N    Re-request price + options every N seconds
                             during NSE market hours (0 disables, default).
--no-panel-prewarm           Skip the eager panel load behind the splash.
                             Market Pulse will then load on first tab open.
--initial-symbol SYMBOL      Symbol to auto-load after the window appears
                             (default: NIFTY).
```

Environment:

- `NIMBUS_DATA_DIR` — root for industry DB, all caches, logs. Defaults
  to the project-relative `./data/`.

## Develop

```bash
pytest
ruff check nimbus_v3 tests scripts
```

The single hard contract: 35 ride_initiation tests must pass after
every change to `compute/ride_initiation/` or `compute/engine.py`:

```bash
pytest tests/compute/ride_initiation/ tests/compute/test_ride_initiation.py
```

## Isolation

This repository has no runtime dependency on `nimbus_oracle` or
`nimbus_v2`. Nothing migrates. The legacy systems are a design
reference only.
