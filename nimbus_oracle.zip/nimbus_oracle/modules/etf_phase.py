"""
modules/etf_phase.py — Phase-aware verdict selection for ETF tab.

Pure logic, no UI dependencies. Determines whether the primary Grade/Verdict
shows momentum (dip) or ride (upper band) based on the ETF's current state.

The key invariant: %B tells you what's happening NOW.
  %B >= 1.0 → riding upper band (present tense) → ride context dominates
  %B < 1.0 + mom entry → dip recovery (present tense) → momentum dominates
  Neither → neutral → momentum default
"""


def apply_phase_logic(row: dict, mom_grade: str, adtv_cr: float,
                      nav_prem: float = None) -> dict:
    """
    Phase-aware primary Grade/Verdict selection.

    Mutates row in-place. Also returns it for convenience.

    Args:
        row: merged dict with momentum + ride fields
        mom_grade: momentum engine's grade (e.g. "A+", "B", "—")
        adtv_cr: ADTV in crores (for sizing)
        nav_prem: NAV premium %. +ve = premium (overpaying), -ve = discount (cheap)
    """
    ride_pctb = row.get("ride_pctb") or 0
    ride_entry = row.get("ride_entry", False)
    ride_grade = row.get("ride_grade", "—")
    mom_active = row.get("entry", False)

    if ride_pctb >= 1.0:
        # ── RIDING: %B above upper band — this is the current state ──
        if ride_grade not in ("—", "D"):
            # Fresh ride entry with valid grade
            row["grade"] = ride_grade
            row["verdict"] = row["ride_verdict"]
            row["sizing"] = {"A+": "FULL", "A": "FULL", "B+": "HALF", "B": "HALF"}.get(
                ride_grade, "SKIP") if adtv_cr >= 1.0 else "SKIP"
            row["entry"] = ride_entry
            if mom_active:
                row["verdict"] += " + dip confirmed"
                row["quality_rank"] = min(100, row["quality_rank"] + 10)
        else:
            # Already riding (no fresh entry trigger) — show ride status
            # Keep momentum grade for ranking since it's the only graded signal
            row["verdict"] = row.get("ride_verdict", f"△ RIDING — at upper band, %B={ride_pctb:.2f}")
            if mom_active:
                row["verdict"] += f" · momentum [{mom_grade}]"
        row["phase"] = "BOTH" if mom_active else "RIDE"

    elif mom_active:
        # ── DIP: below upper band, momentum dip triggered ──
        row["phase"] = "DIP"
        if ride_entry and ride_grade not in ("—", "D"):
            # Rare: ride entry without %B >= 1.0 (edge of band)
            row["verdict"] = f"{row['verdict']} + ride [{ride_grade}]"
            row["quality_rank"] = min(100, row["quality_rank"] + 10)
            row["phase"] = "BOTH"

    else:
        # ── NEUTRAL: no active signal ──
        row["phase"] = "NEUTRAL"

    # ── NAV premium override ─────────────────────────────────
    # ETF trading far above NAV is a trap — the price can snap back
    # to NAV regardless of underlying momentum. Cap sizing accordingly.
    if nav_prem is not None and nav_prem > 1.0:
        prem_str = f"NAV premium {nav_prem:+.1f}%"
        if nav_prem >= 5.0:
            # Extreme premium — force SKIP, this is dangerous
            # Keep entry=True for ranking (signal is real, premium is the risk)
            row["sizing"] = "SKIP"
            row["verdict"] = f"⚠ {prem_str} — avoid, snap-back risk · {row['verdict']}"
            row["quality_rank"] = max(0, row["quality_rank"] - 30)
        elif nav_prem >= 2.0:
            # High premium — cap to HALF max
            if row["sizing"] == "FULL":
                row["sizing"] = "HALF"
            row["verdict"] = f"⚠ {prem_str} — size capped · {row['verdict']}"
            row["quality_rank"] = max(0, row["quality_rank"] - 15)
        else:
            # Mild premium (1-2%) — note but don't override
            row["verdict"] = f"{row['verdict']} · {prem_str}"

    # ── Illiquid override (always last — overrides everything) ──
    if adtv_cr < 1.0:
        row["verdict"] = f"⚠ ILLIQUID ({adtv_cr:.1f} Cr) — avoid"
        row["grade"] = "—"
        row["sizing"] = "SKIP"
        row["entry"] = False
        row["ride_status"] = "—"

    return row
