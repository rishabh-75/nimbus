"""nimbus_v3.ui.widgets.rotation_tab — industry rotation views.

Two sub-tabs:
  - ROC: multi-line composite cumulative-return chart (leaders/laggards)
    rebased to zero, with a sorted leaderboard.
  - RRG: relative rotation graph — a 2D scatter of relative-strength vs
    relative-momentum (vs CNX500), quadrant-coded, with volatility on
    the marker and a short tail showing direction of travel.

Pure renderers — computation lives in ``compute.industry_rotation`` and
``compute.rrg``.
"""
from __future__ import annotations

import colorsys

import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QHBoxLayout, QLabel, QScrollArea, QTabWidget, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.confluence import compute_confluence
from nimbus_v3.compute.horizon_views import compute_horizon_views
from nimbus_v3.compute.market_breadth import pct_members_above_sma50
from nimbus_v3.compute.market_pulse_config import (
    DEFAULT_EDGE_HORIZON,
    RRG_LOOKBACK,
    STRENGTH_LOOKBACK,
)
from nimbus_v3.compute.industry_rotation import (
    IndustryRotation,
    RotationResult,
    compute_industry_rotation,
)
from nimbus_v3.compute.rrg import (
    Quadrant,
    RRGResult,
    compute_rrg,
)
from nimbus_v3.compute.industry_seasonality import compute_industry_seasonality
from nimbus_v3.compute.seasonality import MIN_YEARS
from nimbus_v3.ui.widgets.confluence_tab import ConfluenceTab
from nimbus_v3.ui.widgets.edge_tab import EdgeTab
from nimbus_v3.ui.widgets.seasonality_heatmap import SeasonalityHeatmap
from nimbus_v3.ui.theme import (
    BG, BORDER, BLUE, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED,
    S2, WHITE,
)

#: How many leaders + how many laggards to plot in the ROC view.
TOP_N: int = 15


def _distinct_colors(n: int) -> list[str]:
    """``n`` visually distinct hex colors via evenly-spaced hues."""
    out: list[str] = []
    for i in range(max(n, 1)):
        h = (i / max(n, 1)) % 1.0
        # Alternate lightness/saturation a little so adjacent hues differ.
        s = 0.65 if i % 2 == 0 else 0.85
        v = 0.95 if i % 3 else 0.80
        r, g, b = colorsys.hsv_to_rgb(h, s, v)
        out.append(f"#{int(r*255):02X}{int(g*255):02X}{int(b*255):02X}")
    return out


class _LeaderRow(QWidget):
    """One leaderboard row: colour swatch · industry · ROC%. Clickable —
    emits its industry via the provided callback to highlight the line."""

    def __init__(self, on_click, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._on_click = on_click
        self._industry = ""
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 3, 8, 3)
        lay.setSpacing(9)
        self._swatch = QLabel("■")
        self._swatch.setFont(QFont(FONT_MONO, 10))
        lay.addWidget(self._swatch)
        self._name = QLabel("")
        self._name.setFont(QFont(FONT_MONO, 8))
        self._name.setStyleSheet(f"color: {WHITE};")
        lay.addWidget(self._name, stretch=1)
        self._roc = QLabel("")
        self._roc.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        lay.addWidget(self._roc)

    def set(self, color: str, name: str, roc: float) -> None:
        self._industry = name
        self._swatch.setStyleSheet(f"color: {color};")
        self._name.setText(name)
        self._name.setToolTip(name)    # full name on hover (truncation safe)
        self._roc.setText(f"{roc:+.2f}%")
        self._roc.setStyleSheet(f"color: {GREEN if roc >= 0 else RED};")

    def set_highlighted(self, on: bool) -> None:
        self.setStyleSheet(
            f"background: {BORDER}; border-radius: 3px;" if on else ""
        )

    def mousePressEvent(self, event):    # noqa: ANN001, N802
        if self._industry and self._on_click is not None:
            self._on_click(self._industry)
        super().mousePressEvent(event)


class _ROCView(QWidget):
    """Industry rotation: multi-line composite ROC + leaderboard."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QHBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        # ── Chart (left, takes the space) ───────────────────────────
        chart_col = QVBoxLayout()
        chart_col.setSpacing(4)
        title = QLabel("INDUSTRY ROTATION")
        title.setFont(QFont(FONT_UI, 9, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        chart_col.addWidget(title)
        self._subtitle = QLabel("")
        self._subtitle.setFont(QFont(FONT_MONO, 8))
        self._subtitle.setStyleSheet(f"color: {MUTED};")
        chart_col.addWidget(self._subtitle)

        self._plot_widget = pg.PlotWidget()
        self._plot_widget.setBackground(BG)
        self._plot = self._plot_widget.getPlotItem()
        self._plot.showGrid(x=False, y=True, alpha=0.12)
        self._plot.getAxis("left").setTextPen(MUTED)
        self._plot.getAxis("bottom").setTextPen(MUTED)
        self._plot.getAxis("left").setPen(BORDER)
        self._plot.getAxis("bottom").setPen(BORDER)
        self._plot.getAxis("left").setLabel("cum. return %")
        # Zero baseline.
        self._zero = pg.InfiniteLine(
            pos=0, angle=0,
            pen=pg.mkPen(MUTED, width=1, style=Qt.PenStyle.DashLine),
        )
        self._plot.addItem(self._zero)
        chart_col.addWidget(self._plot_widget, stretch=1)
        root.addLayout(chart_col, stretch=1)

        # ── Leaderboard (right) ─────────────────────────────────────
        board = QWidget()
        board.setFixedWidth(270)
        board.setStyleSheet(
            f"background: {S2}; border: 1px solid {BORDER}; border-radius: 4px;"
        )
        self._board_lay = QVBoxLayout(board)
        self._board_lay.setContentsMargins(4, 6, 4, 6)
        self._board_lay.setSpacing(1)
        board_title = QLabel("LEADERS · LAGGARDS")
        board_title.setFont(QFont(FONT_UI, 7, QFont.Weight.Bold))
        board_title.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        self._board_lay.addWidget(board_title)
        self._board_lay.addSpacing(4)
        self._rows: list[_LeaderRow] = []
        for _ in range(TOP_N * 2):
            r = _LeaderRow(on_click=self._on_row_clicked)
            self._board_lay.addWidget(r)
            self._rows.append(r)
        self._board_lay.addStretch(1)
        root.addWidget(board)

        # Plot state for highlighting.
        self._lines: dict[str, pg.PlotDataItem] = {}
        self._color_of: dict[str, str] = {}
        self._selected: str | None = None

        self._empty = QLabel("No industry data yet")
        self._empty.setFont(QFont(FONT_MONO, 9))
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setVisible(False)
        chart_col.addWidget(self._empty)

    # ── public API ──────────────────────────────────────────────────────────

    def set_data(
        self,
        members_by_industry: dict[str, list],
        panel: dict,
        *,
        lookback: int = STRENGTH_LOOKBACK,
    ) -> None:
        """Compute + render the rotation view from the panel.

        Defaults to the shared STRENGTH lookback so this self-compute path
        matches what the container feeds via ``set_result`` — the ROC view
        never disagrees with the Confluence strength factor."""
        self.set_result(compute_industry_rotation(
            members_by_industry, panel, lookback=lookback))

    def set_result(self, result: RotationResult) -> None:
        """Render a precomputed rotation result (lets the container
        compute once and share the result with the confluence view)."""
        self._last_result = result
        self._render(result)

    # ── internals ─────────────────────────────────────────────────────────

    def _render(self, result: RotationResult) -> None:
        # Clear prior lines (keep the zero baseline).
        self._plot.clear()
        self._plot.addItem(self._zero)

        if not result.has_data:
            self._plot_widget.setVisible(False)
            self._empty.setVisible(True)
            for r in self._rows:
                r.setVisible(False)
            self._subtitle.setText("")
            return
        self._empty.setVisible(False)
        self._plot_widget.setVisible(True)

        leaders = result.top(TOP_N)
        laggards = result.bottom(TOP_N)
        # Plotted set = leaders + laggards (dedup if fewer than 2·N total).
        plotted: list[IndustryRotation] = []
        seen = set()
        for r in (*leaders, *laggards):
            if r.industry not in seen:
                plotted.append(r)
                seen.add(r.industry)

        colors = _distinct_colors(len(plotted))
        color_of = {r.industry: c for r, c in zip(plotted, colors)}
        self._color_of = color_of
        self._lines = {}
        self._selected = None

        n_x = 0
        for r in plotted:
            x = np.arange(len(r.cum_return))
            y = np.array(r.cum_return, dtype=float)
            n_x = max(n_x, len(x))
            line = self._plot.plot(
                x, y, pen=pg.mkPen(color_of[r.industry], width=1.5),
            )
            self._lines[r.industry] = line

        self._subtitle.setText(
            f"{result.lookback}d composite ROC · ADTV-weighted · "
            f"top {len(leaders)} / bottom {len(laggards)} of "
            f"{len(result.industries)} industries"
        )

        # Leaderboard: leaders (desc) then laggards (worst-first), each
        # coloured to match its line. Rows beyond the plotted set hidden.
        board_order = [*leaders, *[r for r in laggards if r.industry not in
                                   {l.industry for l in leaders}]]
        for i, row in enumerate(self._rows):
            if i < len(board_order):
                ind = board_order[i]
                row.set(color_of.get(ind.industry, WHITE),
                        ind.industry, ind.roc)
                row.set_highlighted(False)
                row.setVisible(True)
            else:
                row.setVisible(False)

    # ── interaction ───────────────────────────────────────────────────────

    def _on_row_clicked(self, industry: str) -> None:
        """Toggle highlight for a clicked industry: its line pops, the
        rest dim. Clicking the selected one again clears the highlight."""
        if self._selected == industry:
            self._clear_highlight()
            return
        self._selected = industry
        for ind, line in self._lines.items():
            color = self._color_of.get(ind, WHITE)
            if ind == industry:
                line.setPen(pg.mkPen(color, width=3))
                line.setZValue(10)
            else:
                # Dim non-selected lines to a muted, thin trace.
                dim = QColor(color)
                dim.setAlpha(60)
                line.setPen(pg.mkPen(dim, width=1))
                line.setZValue(0)
        for row in self._rows:
            row.set_highlighted(row._industry == industry)

    def _clear_highlight(self) -> None:
        self._selected = None
        for ind, line in self._lines.items():
            line.setPen(pg.mkPen(self._color_of.get(ind, WHITE), width=1.5))
            line.setZValue(0)
        for row in self._rows:
            row.set_highlighted(False)


# ══════════════════════════════════════════════════════════════════════════════
# RRG view — relative rotation graph
# ══════════════════════════════════════════════════════════════════════════════

#: Quadrant → colour (Leading green, Weakening gold, Lagging red,
#: Improving blue) — the standard RRG palette.
_QUAD_COLOR = {
    Quadrant.LEADING:   GREEN,
    Quadrant.WEAKENING: GOLD,
    Quadrant.LAGGING:   RED,
    Quadrant.IMPROVING: BLUE,
}


class _RRGRow(QWidget):
    """Leaderboard row for the RRG: quadrant dot · industry · maturity ·
    RS. The maturity glyph flags whether the move is fresh, fading
    (Maturing — the pre-Weakening warning), turning up, or flat."""

    #: maturity value → (glyph, colour, words)
    _MATURITY = {
        "Fresh":    ("▲", GREEN, "accelerating"),
        "Turning":  ("↗", BLUE,  "turning up from weakness"),
        "Extended": ("◆", GOLD,  "stretched — top-decile RS, "
                                 "mean-reversion risk"),
        "Maturing": ("▽", GOLD,  "momentum fading — may be late"),
        "Stable":   ("·", MUTED, "steady"),
    }

    def __init__(self, on_click, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._on_click = on_click
        self._industry = ""
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 3, 8, 3)
        lay.setSpacing(7)
        self._dot = QLabel("●")
        self._dot.setFont(QFont(FONT_MONO, 9))
        lay.addWidget(self._dot)
        self._name = QLabel("")
        self._name.setFont(QFont(FONT_MONO, 8))
        self._name.setStyleSheet(f"color: {WHITE};")
        lay.addWidget(self._name, stretch=1)
        self._mat = QLabel("")
        self._mat.setFont(QFont(FONT_MONO, 9, QFont.Weight.Bold))
        self._mat.setFixedWidth(12)
        lay.addWidget(self._mat)
        self._rs = QLabel("")
        self._rs.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        self._rs.setStyleSheet(f"color: {MUTED};")
        lay.addWidget(self._rs)

    def set(self, color: str, name: str, rs: float, vol: float,
            quadrant: str = "", maturity: str = "Stable") -> None:
        self._industry = name
        self._dot.setStyleSheet(f"color: {color};")
        self._name.setText(name)
        glyph, mcol, mwords = self._MATURITY.get(
            maturity, ("·", MUTED, ""))
        self._mat.setText(glyph)
        self._mat.setStyleSheet(f"color: {mcol};")
        self._name.setToolTip(
            f"{name} · {quadrant} · {maturity} ({mwords}) · "
            f"RS {rs:.1f} · vol {vol:.2f}%")
        self._rs.setText(f"{rs:.1f}")
        self._rs.setStyleSheet(f"color: {color};")

    def set_highlighted(self, on: bool) -> None:
        self.setStyleSheet(
            f"background: {BORDER}; border-radius: 3px;" if on else ""
        )

    def mousePressEvent(self, event):    # noqa: ANN001, N802
        if self._industry and self._on_click is not None:
            self._on_click(self._industry)
        super().mousePressEvent(event)


class _RRGView(QWidget):
    """Relative Rotation Graph: RS-Ratio (x) vs RS-Momentum (y), quadrant
    coded, marker size by volatility, short tails for direction."""

    _MAX_ROWS = 60

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QHBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(8)

        chart_col = QVBoxLayout()
        chart_col.setSpacing(4)
        title = QLabel("RELATIVE ROTATION GRAPH")
        title.setFont(QFont(FONT_UI, 9, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        chart_col.addWidget(title)
        self._subtitle = QLabel("")
        self._subtitle.setFont(QFont(FONT_MONO, 8))
        self._subtitle.setStyleSheet(f"color: {MUTED};")
        chart_col.addWidget(self._subtitle)

        self._pw = pg.PlotWidget()
        self._pw.setBackground(BG)
        self._plot = self._pw.getPlotItem()
        self._plot.showGrid(x=True, y=True, alpha=0.10)
        for ax in ("left", "bottom"):
            self._plot.getAxis(ax).setTextPen(MUTED)
            self._plot.getAxis(ax).setPen(BORDER)
        self._plot.getAxis("left").setLabel("RS-Momentum")
        self._plot.getAxis("bottom").setLabel("RS-Ratio")
        chart_col.addWidget(self._pw, stretch=1)
        root.addLayout(chart_col, stretch=1)

        # Leaderboard — title fixed, rows scrollable so ALL industries
        # are reachable (there can be more than fit on screen).
        board = QWidget()
        board.setFixedWidth(270)
        board.setStyleSheet(
            f"background: {S2}; border: 1px solid {BORDER}; border-radius: 4px;"
        )
        board_outer = QVBoxLayout(board)
        board_outer.setContentsMargins(4, 6, 4, 6)
        board_outer.setSpacing(2)
        bt = QLabel("INDUSTRIES · best-odds order")
        bt.setFont(QFont(FONT_UI, 7, QFont.Weight.Bold))
        bt.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        board_outer.addWidget(bt)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        inner = QWidget()
        self._board_lay = QVBoxLayout(inner)
        self._board_lay.setContentsMargins(0, 2, 0, 2)
        self._board_lay.setSpacing(1)
        # Pre-allocate a generous pool; rows beyond the data are hidden.
        self._rows: list[_RRGRow] = []
        for _ in range(self._MAX_ROWS):
            r = _RRGRow(on_click=self._on_row_clicked)
            self._board_lay.addWidget(r)
            self._rows.append(r)
        self._board_lay.addStretch(1)
        scroll.setWidget(inner)
        board_outer.addWidget(scroll, stretch=1)
        root.addWidget(board)

        self._empty = QLabel("No industry data yet")
        self._empty.setFont(QFont(FONT_MONO, 9))
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setVisible(False)
        chart_col.addWidget(self._empty)

        self._items: dict[str, list] = {}    # industry -> plot items
        self._selected: str | None = None

    # ── public API ──────────────────────────────────────────────────────────

    def set_data(
        self,
        members_by_industry: dict,
        panel: dict,
        benchmark_close=None,
        *,
        lookback: int = RRG_LOOKBACK,
    ) -> None:
        """Compute + render the RRG view. Defaults to the shared RRG
        lookback so this self-compute path matches the Confluence direction
        factor (the container normally feeds it via ``set_result``)."""
        self.set_result(compute_rrg(
            members_by_industry, panel, benchmark_close, lookback=lookback))

    def set_result(self, result: RRGResult) -> None:
        """Render a precomputed RRG result (lets the container compute
        once and share the result with the confluence view)."""
        self._last_result = result
        self._render(result)

    def select_industry(self, industry: str) -> None:
        """Programmatically highlight an industry's RRG point + leaderboard
        row (used when the confluence table routes a double-click here).
        Force-selects (never toggles off) and is a no-op if the industry
        isn't present in the current RRG result."""
        if industry not in self._items:
            return
        self._selected = industry
        for ind, items in self._items.items():
            op = 1.0 if ind == industry else 0.18
            for it in items:
                if hasattr(it, "setOpacity"):
                    it.setOpacity(op)
        for row in self._rows:
            row.set_highlighted(row._industry == industry)
        # Bring the highlighted leaderboard row into view.
        for row in self._rows:
            if row._industry == industry:
                row.setVisible(True)
                break

    # ── internals ─────────────────────────────────────────────────────────

    def _render(self, result: RRGResult) -> None:
        self._plot.clear()
        self._items = {}
        self._selected = None

        if not result.has_data:
            self._pw.setVisible(False)
            self._empty.setVisible(True)
            for r in self._rows:
                r.setVisible(False)
            self._subtitle.setText("")
            return
        self._empty.setVisible(False)
        self._pw.setVisible(True)

        pts = result.points
        # Axis ranges padded around 100.
        xs = [p.rs_ratio for p in pts]
        ys = [p.rs_momentum for p in pts]
        for tail_pts in (p.tail for p in pts):
            xs += [t[0] for t in tail_pts]
            ys += [t[1] for t in tail_pts]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        # Symmetric pad around 100.
        xr = max(abs(xmax - 100), abs(xmin - 100), 3) * 1.15
        yr = max(abs(ymax - 100), abs(ymin - 100), 3) * 1.15
        self._plot.setXRange(100 - xr, 100 + xr)
        self._plot.setYRange(100 - yr, 100 + yr)

        # Quadrant background tints + crosshair at (100,100).
        self._draw_quadrants(xr, yr)

        # Volatility → marker size (higher vol = bigger, more "dangerous").
        vols = [p.volatility for p in pts if p.volatility == p.volatility]
        vlo, vhi = (min(vols), max(vols)) if vols else (0.0, 1.0)

        def _size(v: float) -> float:
            if v != v or vhi <= vlo:
                return 12.0
            return 9.0 + (v - vlo) / (vhi - vlo) * 14.0    # 9..23 px

        for p in pts:
            color = _QUAD_COLOR[p.quadrant]
            items = []
            # Tail (faded polyline).
            if len(p.tail) >= 2:
                tx = np.array([t[0] for t in p.tail])
                ty = np.array([t[1] for t in p.tail])
                pen = pg.mkPen(QColor(color), width=1)
                pen.setColor(QColor(color))
                tail_item = self._plot.plot(tx, ty, pen=pg.mkPen(_alpha(color, 90), width=1.5))
                items.append(tail_item)
            # Current marker, sized by volatility.
            sc = pg.ScatterPlotItem(
                [p.rs_ratio], [p.rs_momentum],
                size=_size(p.volatility),
                brush=pg.mkBrush(color), pen=pg.mkPen(BG, width=1),
            )
            self._plot.addItem(sc)
            items.append(sc)
            # Label.
            txt = pg.TextItem(p.industry, color=WHITE, anchor=(0, 1))
            txt.setFont(QFont(FONT_MONO, 7))
            txt.setPos(p.rs_ratio, p.rs_momentum)
            self._plot.addItem(txt)
            items.append(txt)
            self._items[p.industry] = items

        self._subtitle.setText(
            f"{result.lookback}d · RS vs CNX500 · marker size = volatility "
            f"(atr%) · {len(pts)} industries     "
            f"▲ fresh   ↗ turning   ▽ fading   · steady"
        )

        # Leaderboard ordered by best-odds reading (Improving → Leading →
        # Weakening → Lagging, momentum-desc within each) — answers "best
        # forward odds for an early entry", not raw RS. A fading leader
        # (high RS, falling momentum) therefore ranks below a fresh
        # accelerating name, fixing the high-RS-but-Weakening paradox.
        ranked = result.odds_ranked()
        for i, row in enumerate(self._rows):
            if i < len(ranked):
                p = ranked[i]
                row.set(_QUAD_COLOR[p.quadrant], p.industry, p.rs_ratio,
                        p.volatility, p.quadrant.value, p.maturity.value)
                row.set_highlighted(False)
                row.setVisible(True)
            else:
                row.setVisible(False)

    def _draw_quadrants(self, xr: float, yr: float) -> None:
        # Faint quadrant fills.
        x0, x1 = 100 - xr, 100 + xr
        y0, y1 = 100 - yr, 100 + yr
        quads = [
            (100, x1, 100, y1, GREEN),    # leading TR
            (100, x1, y0, 100, GOLD),     # weakening BR
            (x0, 100, y0, 100, RED),      # lagging BL
            (x0, 100, 100, y1, BLUE),     # improving TL
        ]
        for xa, xb, ya, yb, col in quads:
            r = pg.QtWidgets.QGraphicsRectItem(xa, ya, xb - xa, yb - ya)
            r.setPen(pg.mkPen(None))
            r.setBrush(pg.mkBrush(_alpha(col, 18)))
            r.setZValue(-100)
            self._plot.addItem(r)
        # Crosshair at 100/100.
        self._plot.addItem(pg.InfiniteLine(
            pos=100, angle=0, pen=pg.mkPen(MUTED, width=1, style=Qt.PenStyle.DashLine)))
        self._plot.addItem(pg.InfiniteLine(
            pos=100, angle=90, pen=pg.mkPen(MUTED, width=1, style=Qt.PenStyle.DashLine)))

    def _on_row_clicked(self, industry: str) -> None:
        if self._selected == industry:
            self._selected = None
            for items in self._items.values():
                for it in items:
                    it.setOpacity(1.0) if hasattr(it, "setOpacity") else None
            for row in self._rows:
                row.set_highlighted(False)
            return
        self._selected = industry
        for ind, items in self._items.items():
            op = 1.0 if ind == industry else 0.18
            for it in items:
                if hasattr(it, "setOpacity"):
                    it.setOpacity(op)
        for row in self._rows:
            row.set_highlighted(row._industry == industry)


def _alpha(hex_color: str, a: int) -> QColor:
    c = QColor(hex_color)
    c.setAlpha(a)
    return c


# ══════════════════════════════════════════════════════════════════════════════
# Container — ROC / RRG sub-tabs
# ══════════════════════════════════════════════════════════════════════════════

class RotationTab(QWidget):
    """Merged Market Pulse tab: Breadth · ROC · RRG · Seasonality
    sub-tabs.

    The breadth widget is passed in (it owns the CNX500 + breadth panels
    and its own seasonality strip); this container adds the industry
    rotation views (ROC, RRG) and the industry seasonality heatmap.
    Kept named ``RotationTab`` for import stability, but it is the
    top-level "Market Pulse" tab.

    Re-exposes :attr:`symbol_activated(str)` from the seasonality
    constituent table so a double-clicked constituent opens on the
    Dashboard.
    """

    #: Confluence factor lookbacks — sourced from the shared Market Pulse
    #: config so the ROC view, RRG view and Confluence read all agree on the
    #: horizon each factor is measured over (no drift between the ranked
    #: list and the breakdown tabs). Strength and direction are decoupled on
    #: purpose; see :mod:`nimbus_v3.compute.market_pulse_config`.
    CONFLUENCE_STRENGTH_LOOKBACK: int = STRENGTH_LOOKBACK
    CONFLUENCE_RRG_LOOKBACK: int = RRG_LOOKBACK

    symbol_activated = pyqtSignal(str)

    def __init__(
        self, breadth_widget: QWidget | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self._subtabs = QTabWidget()
        self._breadth = breadth_widget
        self._confluence = ConfluenceTab()
        self._edge = EdgeTab()
        self._edge.symbol_activated.connect(self.symbol_activated)
        # ── shared strength horizon ─────────────────────────────────────
        # Owned HERE, not by either tab. Both tabs render the same quantity
        # (Confluence Strength == Edge RS Excess), so a per-tab horizon would
        # let them disagree. Each tab REQUESTS a change; this parent applies
        # it to all of them.
        self._horizon: int = DEFAULT_EDGE_HORIZON
        self._horizon_set = None
        self._edge.horizon_changed.connect(self.set_horizon)
        self._confluence.horizon_changed.connect(self.set_horizon)
        self._roc = _ROCView()
        self._rrg = _RRGView()
        self._seasonality = SeasonalityHeatmap()
        self._seasonality.symbol_activated.connect(self.symbol_activated)
        # Confluence leads; the other tabs are its breakdown. Clicking an
        # industry in the confluence table jumps to the RRG breakdown for
        # that industry (the richest single-industry view).
        self._confluence.industry_activated.connect(
            self._on_confluence_industry)
        self._subtabs.addTab(self._edge, "Edge")
        self._subtabs.addTab(self._confluence, "Confluence")
        self._subtabs.addTab(self._roc, "ROC")
        self._subtabs.addTab(self._rrg, "RRG")
        self._subtabs.addTab(self._seasonality, "Seasonality")
        if self._breadth is not None:
            self._subtabs.addTab(self._breadth, "Breadth")
        lay.addWidget(self._subtabs)

        # Cached results so confluence can be (re)built from the same
        # engine outputs the breakdown tabs already computed.
        self._last_rotation = None
        self._last_rrg = None
        self._last_seasonality = None
        self._last_seasonality_stable = None
        self._last_edge = None
        self._last_confluence = None
        self._last_market_breadth = None
        self._last_universe_size = 0
        self._regime = None

    def set_data(
        self,
        members_by_industry: dict,
        panel: dict,
        benchmark_close=None,
        *,
        strength_lookback: int | None = None,
        rrg_lookback: int | None = None,
        regime=None,
        month: int | None = None,
        market_breadth: float | None = None,
        above_4h_by_symbol: dict | None = None,
    ) -> None:
        """Feed all industry sub-views and build the confluence read.

        Computes the rotation, RRG and seasonality results ONCE here and
        shares them with both the breakdown views (via ``set_result``) and
        the confluence engine, so nothing is computed twice. The breadth
        sub-tab is fed separately (it consumes the breadth dataframe, not
        the panel); ``regime`` is its classified state, passed through for
        the confluence banner — context only, it does not scale scores.

        ``market_breadth`` (0..1, the universe-wide fraction above SMA50) is
        the reference for the confluence breadth gate: per-industry
        participation is judged market-relative, so a narrow move (industry
        breadth well below the tape) discounts the score.

        Strength and direction have SEPARATE lookbacks, because they measure
        different things and want different horizons. Both default to the
        shared Market Pulse config (see
        :mod:`nimbus_v3.compute.market_pulse_config`) so the ROC view, RRG
        view and Confluence read never disagree — override per call only for
        experiments:

        * ``strength_lookback`` — the ROC window for the *strength* factor;
          the rotation-speed dial (shorter = faster/twitchier). Defaults to
          ``STRENGTH_LOOKBACK``.
        * ``rrg_lookback`` — the RS-series window for the *direction* factor;
          held long enough for a stable slope fit. Defaults to
          ``RRG_LOOKBACK``.
        """
        s_lb = (strength_lookback if strength_lookback is not None
                else self.CONFLUENCE_STRENGTH_LOOKBACK)
        r_lb = (rrg_lookback if rrg_lookback is not None
                else self.CONFLUENCE_RRG_LOOKBACK)
        rotation = compute_industry_rotation(
            members_by_industry, panel, lookback=s_lb)
        rrg = compute_rrg(
            members_by_industry, panel, benchmark_close, lookback=r_lb)
        # Two seasonality grids: all-members and ≥3y-members. The
        # confluence view defaults to the ≥3y (stable) grid; both are
        # precomputed so its toggle is a pure pointer swap, no recompute.
        seasonality_all = compute_industry_seasonality(
            members_by_industry, panel, min_member_years=0)
        seasonality_stable = compute_industry_seasonality(
            members_by_industry, panel, min_member_years=MIN_YEARS)

        # Per-industry breadth (fraction of members above own SMA50) — a
        # bottom-up participation read for the confluence breadth gate.
        breadth_by_industry = {
            ind: pct_members_above_sma50(list(members), panel)
            for ind, members in members_by_industry.items()
        }

        self._last_rotation = rotation
        self._last_rrg = rrg
        self._last_seasonality = seasonality_all
        # The report's seasonality section must describe the SAME member set
        # the confluence section's seasonal columns were computed from — the
        # ≥3y-stable grid (the confluence view's default) — so the two
        # sections are internally consistent (matching member counts, same
        # industry set, MIN_MEMBERS applied).
        self._last_seasonality_stable = seasonality_stable
        self._regime = regime

        # Share the precomputed results with the breakdown views.
        self._roc.set_result(rotation)
        self._rrg.set_result(rrg)
        self._seasonality.set_data(members_by_industry, panel)

        # Build BOTH confluence reads (all + ≥3y) from the same rotation/
        # RRG outputs, differing only in which seasonality grid feeds the
        # seasonal factor. The confluence tab swaps between them on toggle.
        if month is None:
            import datetime as _dt
            month = _dt.date.today().month
        self._confluence_month = month

        # ── ONE strength horizon, applied everywhere ────────────────────
        # Confluence "Strength" and Edge "RS Excess" are the SAME quantity
        # (industry_rs_excess over the strength window). They must therefore
        # share one window, or the two tabs would describe different markets.
        #
        # The engine builds every strength-dependent read — rotation, both
        # confluence variants, and the edge — once per horizon, each
        # internally consistent. The views only ever SELECT one; they never
        # assemble a combination, so a mismatched rotation/benchmark pairing
        # is unreachable from the UI.
        #
        # RRG, seasonality and breadth are horizon-INDEPENDENT (direction
        # runs on its own RRG_LOOKBACK; seasonality is a calendar effect;
        # breadth is a latest-bar count), so they are computed once above and
        # reused across every view rather than rebuilt per horizon. The
        # default-horizon rotation is handed in for the same reason — the
        # composite build is the expensive step.
        horizon_set = compute_horizon_views(
            members_by_industry, panel, rrg,
            seasonality_all, seasonality_stable,
            benchmark_close=benchmark_close,
            regime=regime, month=month,
            breadth_by_industry=breadth_by_industry,
            market_breadth=market_breadth,
            rotation_by_horizon={self.CONFLUENCE_STRENGTH_LOOKBACK: rotation},
            above_4h_by_symbol=above_4h_by_symbol,
        )
        self._horizon_set = horizon_set
        self._confluence.set_horizon_set(horizon_set)
        self._edge.set_horizon_set(horizon_set)
        # Re-assert the active horizon on both tabs, so a rebuild does not
        # silently snap the user back to the default window.
        self.set_horizon(self._horizon)

        # The report pins to the DEFAULT horizon, so its numbers never depend
        # on whichever window the tabs happen to be showing.
        default_view = horizon_set.default
        confluence_stable = (default_view.confluence_stable
                             if default_view is not None else None)
        self._last_edge = (default_view.edge
                           if default_view is not None else None)
        # Cache the pieces the research report needs (the report reads the
        # ≥3y-stable confluence, matching the confluence view's default).
        self._last_confluence = confluence_stable
        self._last_market_breadth = market_breadth
        self._last_universe_size = len(panel)

    def build_report(self, data_asof: str | None = None) -> str | None:
        """Assemble the Market Pulse research report from the cached
        results. Returns Markdown, or None if no data has been computed."""
        if (self._last_confluence is None or self._last_edge is None
                or self._last_rotation is None
                or self._last_seasonality is None):
            return None
        from nimbus_v3.compute.market_pulse_report import generate_report
        month = getattr(self, "_confluence_month", None) or 1
        # Use the ≥3y-stable seasonality grid so the report's seasonality
        # section matches the member set the confluence seasonal columns
        # came from (falls back to the all-members grid if absent).
        seas = (self._last_seasonality_stable
                if self._last_seasonality_stable is not None
                else self._last_seasonality)
        return generate_report(
            self._last_confluence,
            self._last_rotation,
            self._last_edge,
            seas,
            month,
            universe_size=self._last_universe_size,
            market_breadth=self._last_market_breadth,
            data_asof=data_asof,
        )

    def update_above_4h(self, flags: dict | None) -> None:
        """Forward warmed 4h flags to the Edge tab (display-only refresh)."""
        self._edge.update_above_4h(flags)

    def set_horizon(self, horizon: int) -> None:
        """Apply a strength horizon to every dependent tab.

        Single point of truth. The tabs' own setters emit nothing, so
        broadcasting here cannot loop back; and because they only ever
        SELECT a precomputed view, this is a pointer swap, not a recompute.
        """
        self._horizon = int(horizon)
        self._confluence.set_horizon(self._horizon)
        self._edge.set_horizon(self._horizon)

    @property
    def horizon(self) -> int:
        """The strength window currently applied across the tabs."""
        return self._horizon

    def _on_confluence_industry(self, industry: str) -> None:
        """Route a confluence-table double-click to the Seasonality
        breakdown: switch to that sub-tab and select the industry's cell
        for the confluence month, so the constituent decomposition and
        average-year path for that exact cell come up. Falls back to no-op
        if the industry has no seasonality row (e.g. dropped below floor)."""
        month = getattr(self, "_confluence_month", None)
        if month is None:
            import datetime as _dt
            month = _dt.date.today().month
        idx = self._subtabs.indexOf(self._seasonality)
        if idx >= 0:
            self._subtabs.setCurrentIndex(idx)
        self._seasonality.select_industry_month(industry, month)
