"""Tests for nimbus_v3.core.types (slim profile).

Covers the surviving enums: ``SectorType``, ``RSRegime``,
``ExpiryRisk``, ``GEXRegime``, ``FilingImpact``. ``SetupType``,
``GradeLetter``, ``Verdict``, ``Sizing``, ``StrategyMode``,
``VolState``, ``FlowSignal``, ``VIXRegime`` were deleted alongside
the strategies / conviction / macro / VIX packages.
"""
from __future__ import annotations

from nimbus_v3.core import types


_ALL_ENUMS = (
    types.SectorType,
    types.RSRegime,
    types.ExpiryRisk,
    types.GEXRegime,
    types.FilingImpact,
)


def test_enums_are_string_subclasses() -> None:
    """Every enum is a str subclass — equality with raw strings must work.

    This is a property downstream code relies on when serializing to JSON,
    persisting to SQLite, or matching against string-valued columns.
    """
    for enum_cls in _ALL_ENUMS:
        for member in enum_cls:
            assert isinstance(member, str)
            assert member == member.value


def test_no_enum_has_unknown_sentinel() -> None:
    """Per docstring contract: absence is represented by None at the field,
    not by an UNKNOWN enum member.
    """
    for enum_cls in (
        types.SectorType,
        types.RSRegime,
        types.ExpiryRisk,
        types.GEXRegime,
    ):
        # FilingImpact legitimately has a NONE value meaning "no filing
        # impact" — that's a valid data point, not a sentinel.
        values = {member.value for member in enum_cls}
        assert "UNKNOWN" not in values, (
            f"{enum_cls.__name__} has an UNKNOWN sentinel"
        )


def test_filing_impact_values_are_stable() -> None:
    assert types.FilingImpact.NONE.value == "NONE"
    assert types.FilingImpact.MINOR.value == "MINOR"
    assert types.FilingImpact.MATERIAL.value == "MATERIAL"
    assert types.FilingImpact.TRAP.value == "TRAP"


def test_expiry_risk_values_are_stable() -> None:
    assert types.ExpiryRisk.LOW.value == "LOW"
    assert types.ExpiryRisk.ELEVATED.value == "ELEVATED"
    assert types.ExpiryRisk.HIGH.value == "HIGH"


def test_gex_regime_values_are_stable() -> None:
    assert types.GEXRegime.TREND_FRIENDLY.value == "TREND_FRIENDLY"
    assert types.GEXRegime.PINNING.value == "PINNING"
