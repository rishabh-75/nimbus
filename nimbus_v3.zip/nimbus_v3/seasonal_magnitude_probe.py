#!/usr/bin/env python3
"""seasonal_magnitude_probe.py — is an industry's NEXT-month seasonal AVERAGE
return, on its own, a forward-looking predictor of member excess return?

WHY THIS PROBE EXISTS (read this — it changes how much to trust the result)
──────────────────────────────────────────────────────────────────────────
This signal FIRST appeared as a CONTROL column in seasonal_gap_probe, where
it scored Q4−Q1 = +2.11%, Welch-t = +4.76 — the strongest thing in any probe
so far. That is exactly the situation where a false positive hides: an effect
that lights up in a column you did NOT pre-register, after the headline
hypothesis (the gap) had already failed. Finding your best signal in a
control is a red flag, not a green light.

So this probe PROMOTES seasonal magnitude from accidental-control to the
pre-registered hypothesis and subjects it to the scrutiny that a
post-hoc-discovered signal must survive before it earns any weight:

  1. TRAIN/TEST SPLIT. The quartile edges and the pass/fail are decided on
     the FIRST half of the panel dates (train), then applied UNCHANGED to the
     SECOND half (test). A real effect survives out of sample; a mirage does
     not. The verdict is the TEST result, not the full-sample one.

  2. PER-INDUSTRY CONTRIBUTION. Prints which industries populate the top
     quartile and how much each contributes, so we can see if the +2% is
     BROAD or just one or two industries whose recent Septembers happened to
     be large (3–5 observations per industry-month — thin).

  3. SEED STABILITY. The random-seasonal control is run over several seeds;
     the real effect must beat ALL of them, not just win one coin-flip.

  4. SECTOR-NEUTRAL VARIANT. Re-runs ranking within macro-sector (demeaned by
     sector-month) to check the effect is not just "sector X is strong in
     month M" — i.e. that it is a security-level seasonal, not a sector bet.

PRE-REGISTERED HYPOTHESIS (fixed before looking at any TEST number)
───────────────────────────────────────────────────────────────────
H1: Forward FWD-day excess return rises with the industry's average return in
    the NEXT calendar month (computed from history strictly before the entry
    date). Top-quartile > bottom-quartile on the HELD-OUT TEST half,
    monotone (≤1 inversion), date-clustered Welch-t > 2.

PASS BAR (all, on the TEST half):
  • Q4 > Q1, ≤1 inversion, Welch-t(dates) > 2.
  • beats random-seasonal across ALL seeds tried.
  • the top-quartile effect is not driven by a single industry (no one
    industry > 40% of the Q4-minus-Q1 contribution).

DISCIPLINE (unchanged): date-clustered t across DATES not trades; no
lookahead (seasonal mean uses only data strictly before asof; forward return
date-grid sliced from asof); shuffle-dates canary must be ~0.

Run (needs the cached panel; run from the dir that contains ./data):
    cd /Users/srishabh/Monarch/nimbus
    python nimbus_v3/seasonal_magnitude_probe.py
    python nimbus_v3/seasonal_magnitude_probe.py --selftest   # no cache
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

FWD = 20
MIN_SEASON_YEARS = 3
SAMPLE_EVERY = 5
UPPER = "bb_20_1s_upper"


# ── seasonal average of an industry's NEXT month, as-of a date ──────────────
def next_month_seasonal_mean(industry_close, asof, *, min_years=MIN_SEASON_YEARS):
    import numpy as np
    import pandas as pd

    from nimbus_v3.compute.seasonality import _monthly_returns

    hist = industry_close.loc[industry_close.index < asof]
    if hist.empty:
        return float("nan"), 0
    monthly = _monthly_returns(hist)
    if monthly.empty:
        return float("nan"), 0
    target = (pd.Timestamp(asof).month % 12) + 1
    vals = monthly[monthly.index.month == target].to_numpy(dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < min_years:
        return float("nan"), len(vals)
    return float(np.mean(vals)), len(vals)


def forward_excess(df, i, market_cum, *, fwd=FWD):
    import numpy as np

    if i + fwd >= len(df):
        return float("nan")
    c = df["Close"].to_numpy(dtype=float)
    r_sym = c[i + fwd] / c[i] - 1.0
    d0, d1 = df.index[i], df.index[i + fwd]
    m0, m1 = market_cum.get(d0), market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan")
    r_mkt = m1 / m0 - 1.0
    if not (np.isfinite(r_sym) and np.isfinite(r_mkt)):
        return float("nan")
    return r_sym - r_mkt


# ── inference ───────────────────────────────────────────────────────────────
def clustered_stats(pairs):
    import numpy as np

    by_date = defaultdict(list)
    for d, x in pairs:
        if x == x:
            by_date[d].append(x)
    dm = [float(np.mean(v)) for v in by_date.values()]
    ntr = sum(len(v) for v in by_date.values())
    if len(dm) < 3:
        return float("nan"), float("nan"), len(dm), ntr
    arr = np.array(dm)
    m = float(arr.mean())
    se = float(arr.std(ddof=1) / np.sqrt(len(arr)))
    return m, (m/se if se > 0 else float("nan")), len(arr), ntr


def welch(top, bot):
    import numpy as np

    def dm(pairs):
        d = defaultdict(list)
        for dt, x in pairs:
            if x == x:
                d[dt].append(x)
        return np.array([np.mean(v) for v in d.values()])
    a, b = dm(top), dm(bot)
    if len(a) < 3 or len(b) < 3:
        return float("nan")
    se = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
    return (a.mean()-b.mean())/se if se > 0 else float("nan")


def edges_from(values):
    import numpy as np

    v = np.array([x for x in values if x == x])
    if len(v) < 4:
        return None
    return [float(np.quantile(v, q)) for q in (0.25, 0.5, 0.75)]


def assign_q(x, edges):
    if x != x or edges is None:
        return None
    return (0 if x <= edges[0] else 1 if x <= edges[1]
            else 2 if x <= edges[2] else 3)


def quartile_report(records, edges, label, *, key=2, shuffle_dates=False,
                    rng=None):
    """records: [date, fwd, seasonal_mean, industry]. Buckets by `edges`
    (supplied, e.g. learned on train) and prints quartiles + Welch."""
    rec = records
    if shuffle_dates and rng is not None:
        ds = [r[0] for r in rec]
        rng.shuffle(ds)
        rec = [[d] + r[1:] for d, r in zip(ds, rec)]
    buckets = defaultdict(list)
    for r in rec:
        q = assign_q(r[key], edges)
        if q is not None:
            buckets[q].append((r[0], r[1]))
    print(f"\n─── {label} " + "─" * max(2, 52 - len(label)))
    qm = {}
    for q in range(4):
        m, t, nd, ntr = clustered_stats(buckets.get(q, []))
        qm[q] = m
        cell = "  nan " if m != m else f"{m*100:+6.2f}%"
        tag = "low" if q == 0 else "high" if q == 3 else "mid"
        print(f"  Q{q+1} ({tag:>4}): {cell}  t {t:+5.2f}  dates {nd:4d}"
              f"  trades {ntr:6d}")
    w = welch(buckets.get(3, []), buckets.get(0, []))
    diff = (qm[3]-qm[0]) if (qm[3] == qm[3] and qm[0] == qm[0]) else float("nan")
    inv = sum(1 for q in range(3)
              if qm[q] == qm[q] and qm[q+1] == qm[q+1] and qm[q] > qm[q+1]+1e-9)
    print(f"  ── Q4 − Q1 = {diff*100:+.2f}%   Welch-t = {w:+.2f}"
          f"   inversions = {inv}")
    return {"diff": diff, "welch": w, "inversions": inv, "buckets": buckets}


# ── per-industry contribution to the top quartile ──────────────────────────
def industry_contribution(records, edges):
    """Which industries populate Q4, and each one's share of Q4's mean."""
    import numpy as np

    q4 = [r for r in records if assign_q(r[2], edges) == 3]
    by_ind = defaultdict(list)
    for r in q4:
        by_ind[r[3]].append(r[1])
    rows = []
    grand = np.mean([r[1] for r in q4]) if q4 else float("nan")
    for ind, xs in by_ind.items():
        rows.append((ind, len(xs), float(np.mean(xs))))
    rows.sort(key=lambda t: -t[1] * abs(t[2]))
    print("\n  Q4 industry contribution (by |weight×mean|):")
    total_w = sum(len(v) for v in by_ind.values())
    top_share = 0.0
    for ind, n, mean in rows[:10]:
        share = (n / total_w) if total_w else 0.0
        contrib = share * mean
        if ind == rows[0][0]:
            top_share = abs(contrib)
        print(f"    {ind[:34]:34} n={n:4d}  mean {mean*100:+6.2f}%"
              f"  contrib {contrib*100:+6.3f}%")
    denom = abs(grand) if grand == grand and grand != 0 else 1.0
    print(f"  top-industry share of Q4 mean: "
          f"{100*top_share/denom:.0f}%  (>40% = concentrated, be wary)")
    return top_share / denom if denom else float("nan")


# ── record construction ─────────────────────────────────────────────────────
def build_records(panel, sym_to_industry, comps, market):
    seasonal_cache = {}
    records = []
    for sym, df in panel.items():
        ind = sym_to_industry.get(sym)
        if ind is None or ind not in comps or "Close" not in df.columns:
            continue
        comp = comps[ind]
        n = len(df)
        for i in range(260, n - FWD - 1, SAMPLE_EVERY):
            asof = df.index[i]
            fexc = forward_excess(df, i, market)
            if fexc != fexc:
                continue
            key = (ind, asof.year, asof.month)
            if key not in seasonal_cache:
                seasonal_cache[key] = next_month_seasonal_mean(comp, asof)[0]
            sm = seasonal_cache[key]
            if sm != sm:
                continue
            records.append([asof, fexc, sm, ind])
    return records


def sector_neutralize(records, sym_to_sector_by_ind):
    """Demean the seasonal key within (macro_sector, month) so the ranking is
    security/industry-level, not 'this sector is strong in this month'."""
    import numpy as np

    groups = defaultdict(list)
    for r in records:
        sector = sym_to_sector_by_ind.get(r[3], "?")
        groups[(sector, r[0].month)].append(r)
    for _, rs in groups.items():
        mu = np.mean([r[2] for r in rs])
        for r in rs:
            r[2] = r[2] - mu
    return records


def build_market_cum(panel, *, min_count=20):
    import numpy as np

    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                sums[idx[i]] += c[i]/c[i-1] - 1.0
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    cum, acc = {}, 1.0
    for d in sorted(daily):
        acc *= 1.0 + daily[d]
        cum[d] = acc
    return cum


def build_composites(panel, sym_to_industry):
    from nimbus_v3.compute.industry_composite import build_industry_composite

    members = defaultdict(list)
    for sym, ind in sym_to_industry.items():
        if sym in panel:
            members[ind].append(sym)
    out = {}
    for ind, syms in members.items():
        comp, _ = build_industry_composite(
            syms, panel, min_members=3, min_bars=250, lookback=None)
        if comp is not None:
            out[ind] = comp
    return out


def split_train_test(records):
    """Split by DATE median so train and test are disjoint time periods."""
    import numpy as np

    dates = sorted({r[0] for r in records})
    if len(dates) < 10:
        return records, []
    cut = dates[len(dates)//2]
    train = [r for r in records if r[0] < cut]
    test = [r for r in records if r[0] >= cut]
    return train, test


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np

    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db
    from strategy_probe import load_panel

    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}
    ind_to_sector = {c.industry: c.macro_sector for c in db.values()}

    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — cache present? run from dir with ./data",
              file=sys.stderr)
        return 1
    print("composites + market...", file=sys.stderr)
    comps = build_composites(panel, sym_to_industry)
    market = build_market_cum(panel)
    records = build_records(panel, sym_to_industry, comps, market)
    print(f"records: {len(records)}", file=sys.stderr)

    train, test = split_train_test(records)
    print(f"train: {len(train)}  test: {len(test)}", file=sys.stderr)

    # ── 1. learn quartile edges on TRAIN, judge on TEST ──────────────────
    train_edges = edges_from([r[2] for r in train])
    print("\n" + "#" * 60)
    print("# TRAIN (edges learned here — in-sample, expect it to look good)")
    print("#" * 60)
    quartile_report(train, train_edges, "TRAIN: seasonal magnitude")

    print("\n" + "#" * 60)
    print("# TEST (edges FROM TRAIN applied here — THIS IS THE VERDICT)")
    print("#" * 60)
    te = quartile_report(test, train_edges, "TEST: seasonal magnitude")
    conc = industry_contribution(test, train_edges)

    # canary + seed-stable random-seasonal, all on TEST with train edges
    rng = np.random.default_rng(args.seed)
    quartile_report(test, train_edges, "TEST ctl:shuffle-dates (≈0)",
                    shuffle_dates=True, rng=rng)

    print("\n  random-seasonal across seeds (each must stay under the real):")
    real_diff = te["diff"]
    beat_all = True
    for s in range(5):
        r2 = np.random.default_rng(1000 + s)
        shuffled = [r[:] for r in test]
        keys = [r[2] for r in shuffled]
        r2.shuffle(keys)
        for r, k in zip(shuffled, keys):
            r[2] = k
        res = quartile_report(shuffled, train_edges,
                              f"  random-seasonal seed {s}")
        if not (real_diff > res["diff"]):
            beat_all = False

    # ── 2. sector-neutral variant ────────────────────────────────────────
    print("\n" + "#" * 60)
    print("# SECTOR-NEUTRAL (demeaned within macro-sector × month)")
    print("#" * 60)
    sn = [r[:] for r in records]
    sector_neutralize(sn, ind_to_sector)
    sn_train, sn_test = split_train_test(sn)
    sn_edges = edges_from([r[2] for r in sn_train])
    sn_res = quartile_report(sn_test, sn_edges, "TEST sector-neutral")

    print("\n" + "=" * 68)
    print("VERDICT (decided on TEST)")
    passed = (te["diff"] > 0 and te["welch"] > 2 and te["inversions"] <= 1
              and beat_all and conc == conc and conc <= 0.40)
    if passed:
        print("  Held out of sample: Q4>Q1, t>2, monotone, beat every random")
        print("  seed, and not one-industry-driven. This is a REAL forward-")
        print("  looking seasonal factor — the first in the system.")
        print(f"  Sector-neutral TEST Welch-t = {sn_res['welch']:+.2f} "
              f"({'survives' if sn_res['welch'] > 2 else 'weakens'} sector-"
              f"neutralisation).")
        print("  → Worth building as a scored factor / a Seasonal-Strength")
        print("    column, keyed to a lead-time window before the strong")
        print("    month. Confirm sign stability on a re-run first.")
    else:
        why = []
        if not (te["welch"] > 2):
            why.append(f"TEST Welch-t {te['welch']:+.2f} ≤ 2")
        if te["inversions"] > 1:
            why.append(f"{te['inversions']} inversions")
        if not beat_all:
            why.append("lost to a random-seasonal seed")
        if conc == conc and conc > 0.40:
            why.append(f"one industry = {conc*100:.0f}% of Q4")
        print("  Does NOT hold out of sample: " + "; ".join(why) + ".")
        print("  → The +4.76 t in the gap-probe control was in-sample /")
        print("    control-column shine. Do NOT build it. Seasonality stays a")
        print("    display lens (the heatmap), not a scored predictor.")
    return 0


def _selftest(args):
    """Two worlds, verdict must be right in each:
      A) REAL out-of-sample seasonal: industries carry a STABLE next-month
         premium present in BOTH halves → must PASS on test.
      B) IN-SAMPLE-ONLY mirage: the premium exists only in the train half
         (random in test) → must FAIL on test (the whole point of the split).
    """
    import numpy as np
    import pandas as pd

    dates = pd.bdate_range("2015-01-01", periods=1600)
    cut = dates[len(dates)//2]

    def synth(stable):
        rng = np.random.default_rng(args.seed)
        recs = []
        ind_premium = {f"Ind{k:02d}": (k-12)/12 * 0.03 for k in range(24)}
        for _ in range(12000):
            d = dates[rng.integers(len(dates))]
            ind = f"Ind{rng.integers(24):02d}"
            prem = ind_premium[ind]
            # seasonal 'mean' the probe will read = the premium + noise
            smean = prem + rng.normal(0, 0.01)
            if stable or d < cut:
                fexc = 0.30 * prem + rng.normal(0, 0.05)   # premium pays
            else:
                fexc = rng.normal(0, 0.05)                 # test = pure noise
            recs.append([d, fexc, smean, ind])
        return recs

    def run(recs, label):
        train, test = split_train_test(recs)
        edges = edges_from([r[2] for r in train])
        print(f"\n########## {label} ##########")
        quartile_report(train, edges, f"{label} TRAIN")
        te = quartile_report(test, edges, f"{label} TEST (verdict)")
        return te

    A = run(synth(stable=True), "A: STABLE seasonal (should PASS test)")
    B = run(synth(stable=False), "B: TRAIN-ONLY mirage (should FAIL test)")

    A_pass = A["diff"] > 0 and A["welch"] > 2 and A["inversions"] <= 1
    B_fail = not (B["welch"] > 2)
    print("\n" + "=" * 68)
    print(f"A stable seasonal PASSES on test:  {A_pass}")
    print(f"B mirage FAILS on test:            {B_fail}  "
          f"(split correctly kills in-sample-only shine)")
    ok = A_pass and B_fail
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
