"""nimbus_v3.ui.widgets.dashboard_tab — single-symbol cockpit.

Slim layout (post-refactor)
───────────────────────────

    ┌─────────────────────────────────────────┬───────────────────────┐
    │ Header strip                             │ Workflow Analysis      │
    │   SYMBOL  SPOT  ±%        timestamp      │ ─ Options Overlay      │
    ├─────────────────────────────────────────┤                        │
    │                                          │ ─ Industry Context     │
    │                                          │                        │
    │              Price chart                 │                        │
    │              (BB envelope, SMA20,        │                        │
    │               options walls overlay)     │                        │
    │                                          │                        │
    │                                          │                        │
    └─────────────────────────────────────────┴───────────────────────┘

Public API (locked)
───────────────────
    :meth:`set_symbol(symbol, *, enriched_df, ride_result, options_ctx,
                       industry, industry_ride_result, member_count, asof_label)`
    :meth:`clear()`

The dashboard receives pre-built domain objects from MainWindow
(enriched dataframe, single-symbol RideResult, OptionsContext,
synthetic-industry RideResult). It does NOT call any provider or
classifier directly — interpretation routing is MainWindow's job;
rendering is the dashboard's.
"""
from __future__ import annotations

import logging

import pandas as pd
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QSizePolicy, QSplitter, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.ride_initiation import (
    RideClassificationCache, RideResult,
)
from nimbus_v3.core.context import OptionsContext
from nimbus_v3.core.types import ExpiryRisk, GEXRegime
from nimbus_v3.core.universe import Universe
from nimbus_v3.ui.presenters import (
    EMPTY_HEADER_VIEW, HeaderView, build_header_view,
)
from nimbus_v3.ui.theme import (
    BLUE, BORDER, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED,
    SURFACE, VIOLET, WHITE,
)
from nimbus_v3.ui.widgets.components import PanelFrame
from nimbus_v3.ui.widgets.industry_context_card import IndustryContextCard
from nimbus_v3.ui.widgets.industry_tables import (
    ConstituentsTable, IndustriesTable,
)
from nimbus_v3.ui.widgets.price_chart import PriceChart


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Local style helpers
# ══════════════════════════════════════════════════════════════════════════════


def _mono(size: int, bold: bool = False) -> QFont:
    f = QFont(FONT_MONO, size)
    f.setBold(bold)
    return f


def _sans(size: int, bold: bool = False) -> QFont:
    f = QFont(FONT_UI, size)
    f.setBold(bold)
    return f


def _format_adtv_m(value_inr: float) -> str:
    """Format Average Daily Traded Value (₹) as straight Millions
    with a thousands separator. Matches Market Pulse formatting so
    the two surfaces speak the same numeric language.

    Examples:
        946M → "946 M"
        65.3B → "65,300 M"
        2.5T → "2,500,000 M"

    NaN or non-positive values render as the em-dash placeholder.
    """
    if value_inr != value_inr or value_inr <= 0:    # NaN or non-positive
        return "—"
    return f"{value_inr / 1_000_000:,.0f} M"


def _kv_row(label: str, *, value_font_size: int = 9) -> tuple[QWidget, QLabel]:
    """Build a label/value row. Returns ``(row_widget, value_label)``
    so the caller can update the value later."""
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(8)
    k = QLabel(label.upper())
    k.setFont(_sans(7))
    k.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
    k.setFixedWidth(96)
    lay.addWidget(k)
    v = QLabel("—")
    v.setFont(_mono(value_font_size, bold=True))
    v.setStyleSheet(f"color: {MUTED};")
    v.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    lay.addWidget(v, stretch=1)
    return w, v


# ══════════════════════════════════════════════════════════════════════════════
# Options Overlay panel — internal helper
# ══════════════════════════════════════════════════════════════════════════════


class _OptionsOverlayPanel(QWidget):
    """Renders the OptionsContext fields the price chart already
    overlays as horizontal lines, plus the three regime cells
    (PCR-OI, NET GEX, GEX regime, IVR/ATM IV, expiry).

    No data fetching here — :meth:`set_context` is called by the
    Dashboard whenever a fresh ``OptionsContext`` arrives.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._build_ui()
        self.clear()

    # ── Public API ────────────────────────────────────────────────────────

    def set_context(self, ctx: OptionsContext | None) -> None:
        if ctx is None:
            self.clear()
            return

        self._set("RESIST",   _fmt_price(ctx.resistance_wall),  RED)
        self._set("SUPPORT",  _fmt_price(ctx.support_wall),     GREEN)
        self._set("MAX PAIN", _fmt_price(ctx.max_pain),         GOLD)
        self._set("HVL",      _fmt_price(ctx.hvl),              VIOLET)

        self._set("PCR OI",   _fmt_ratio(ctx.pcr_oi),           WHITE)
        self._set("NET GEX",  _fmt_signed(ctx.net_gex),
                  GREEN if (ctx.net_gex or 0.0) > 0 else
                  RED if (ctx.net_gex or 0.0) < 0 else WHITE)
        self._set("GEX REG",  _fmt_gex_regime(ctx.gex_regime),
                  _gex_color(ctx.gex_regime))
        self._set("IV ATM",   _fmt_pct(ctx.iv_atm),             WHITE)
        self._set("IVR",      _fmt_pct(ctx.ivr),                WHITE)

        dte_text = "—" if ctx.dte is None else f"{ctx.dte}d"
        self._set("DTE",      dte_text,                         WHITE)
        self._set("EXPIRY",
                  _fmt_expiry_risk(ctx.expiry_risk),
                  _expiry_color(ctx.expiry_risk))

        # Header tint reflects expiry risk — a glanceable cue that
        # this is a hot expiry without scanning the rows.
        self._panel.set_accent(_expiry_color(ctx.expiry_risk))

    def clear(self) -> None:
        self._panel.set_accent(BORDER)
        for v in self._values.values():
            v.setText("—")
            v.setStyleSheet(f"color: {MUTED};")

    # ── Build ─────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self._panel = PanelFrame(title="OPTIONS OVERLAY")
        outer.addWidget(self._panel)
        body = self._panel.content_layout()
        body.setSpacing(4)

        self._values: dict[str, QLabel] = {}
        for label in (
            "RESIST", "SUPPORT", "MAX PAIN", "HVL",
            "PCR OI", "NET GEX", "GEX REG",
            "IV ATM", "IVR", "DTE", "EXPIRY",
        ):
            row, v = _kv_row(label)
            body.addWidget(row)
            self._values[label] = v

    def _set(self, key: str, text: str, color: str) -> None:
        lbl = self._values.get(key)
        if lbl is None:
            return
        lbl.setText(text)
        lbl.setStyleSheet(f"color: {color};")


# ══════════════════════════════════════════════════════════════════════════════
# Formatting helpers
# ══════════════════════════════════════════════════════════════════════════════


def _fmt_price(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    return f"{v:,.2f}"


def _fmt_ratio(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    return f"{v:.2f}"


def _fmt_signed(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    if abs(v) >= 1_000_000:
        return f"{v/1_000_000:+,.1f}M"
    if abs(v) >= 1_000:
        return f"{v/1_000:+,.1f}K"
    return f"{v:+,.0f}"


def _fmt_pct(v: float | None) -> str:
    if v is None or not (v == v):
        return "—"
    return f"{v:.1f}%"


def _fmt_gex_regime(regime: GEXRegime | None) -> str:
    if regime is None:
        return "—"
    return regime.value.replace("_", " ")


def _gex_color(regime: GEXRegime | None) -> str:
    if regime is None:
        return MUTED
    if regime is GEXRegime.TREND_FRIENDLY:
        return GREEN
    return GOLD    # PINNING


def _fmt_expiry_risk(risk: ExpiryRisk) -> str:
    return risk.value if risk is not None else "—"


def _expiry_color(risk: ExpiryRisk) -> str:
    if risk is ExpiryRisk.HIGH:
        return RED
    if risk is ExpiryRisk.ELEVATED:
        return GOLD
    return GREEN


# ══════════════════════════════════════════════════════════════════════════════
# Dashboard tab
# ══════════════════════════════════════════════════════════════════════════════


class DashboardTab(QWidget):
    """Single-symbol trading cockpit + embedded industry/constituents
    tables (unified profile).

    Public API:
        ``set_symbol(symbol, *, enriched_df=None, ride_result=None,
            options_ctx=None, industry=None, industry_ride_result=None,
            member_count=0, asof_label="")`` — render the chart-side
            cockpit for one symbol.

        ``set_panel(panel, universe)`` — push the enriched panel +
            universe down to the embedded Industries table.

        ``clear()`` — return every panel to empty state.

    Signals:
        ``symbol_activated(str)`` — emitted when the operator
            double-clicks a row in the embedded Constituents table.
            MainWindow connects this to the symbol-load pathway.

    Selection model:
        - Sidebar drives the chart only — the tables don't move
          when the user picks a symbol from the combo. This is
          intentional: the operator can keep one symbol on the chart
          while exploring industry context independently below.
        - Click on Industries → repopulate Constituents (chart stays).
        - Double-click on Constituents → emits ``symbol_activated``;
          MainWindow loads the symbol on the chart.

    This widget owns layout and view rendering only. All domain types
    are produced by MainWindow (which talks to compute, classifiers,
    and providers) and passed in.
    """

    symbol_activated = pyqtSignal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._symbol: str = ""
        # Captured by set_panel; used by _on_industry_selected to
        # rebuild the constituents table from the same panel.
        self._panel: dict[str, pd.DataFrame] = {}
        self._universe: Universe | None = None
        # Pre-classified per-symbol + per-industry RideResult cache.
        # Populated by ``set_panel``; consumed by the embedded
        # tables. Single source of truth shared with MainWindow's
        # sidebar driver — both read the same cached classifications.
        self._ride_cache: "RideClassificationCache | None" = None
        # Tracked across set_symbol() calls so set_panel() can
        # default the Constituents table to the active chart
        # symbol's industry — gives the operator a populated
        # bottom strip without requiring a click.
        self._current_industry: str | None = None
        self._build_ui()
        self.clear()

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def set_symbol(
        self,
        symbol: str,
        *,
        enriched_df: pd.DataFrame | None = None,
        ride_result: RideResult | None = None,    # noqa: ARG002 — reserved
        options_ctx: OptionsContext | None = None,
        industry: str | None = None,
        industry_ride_result: RideResult | None = None,
        member_count: int = 0,
        asof_label: str = "",
    ) -> None:
        """Render the dashboard for ``symbol`` from pre-built artefacts.

        Args:
            symbol: ticker text shown in the header.
            enriched_df: indicator-enriched OHLCV. Used for the chart
                and the header's spot/delta. Empty / ``None`` keeps the
                empty placeholder.
            ride_result: single-symbol classifier output. Reserved —
                the sidebar is the canonical surface for the per-symbol
                ride view in the slim profile. Pass it through anyway
                so MainWindow's contract can stay symmetric.
            options_ctx: live :class:`OptionsContext` if the symbol is
                F&O-listed. Drives both the chart's wall overlay and
                the Options Overlay panel on the right rail.
            industry: NSE four-level "industry" string for this symbol
                (the third level — used for synthetic-index grouping).
                ``None`` renders the unavailable state on the
                Industry Context card.
            industry_ride_result: synthetic-index classifier output for
                ``industry``. Computed by MainWindow from the panel.
            member_count: peers contributing to the synthetic.
            asof_label: free-form date/time string for the header.
        """
        self._symbol = symbol or ""
        # Stash for set_panel-driven Constituents auto-select. Updated
        # whether the chart load succeeded or not — operator picked
        # this symbol and that's the industry we should default to.
        self._current_industry = industry

        # Header.
        self.apply_header(
            build_header_view(self._symbol, enriched_df, asof_label=asof_label)
        )
        self._apply_header_stats(enriched_df)

        # Chart.
        self._chart.set_data(enriched_df, options=options_ctx)

        # Sidebar Options Overlay (relocated from the deleted
        # right-rail). Industry Context Card was eliminated — its
        # info is already in the bottom-strip Industries table
        # roll-up + the Industry section of the sidebar.
        # ``industry``, ``industry_ride_result``, ``member_count``
        # are still accepted in the signature for compatibility but
        # only used for the table auto-select logic below.

        # If the panel is already loaded and the operator just
        # switched the chart to a symbol whose industry exists in
        # the table, mirror that selection over to the bottom
        # strip — but ONLY if the operator hasn't manually picked a
        # different industry (we don't want to yank the tables out
        # from under them). A programmatic default counts as
        # un-pinned and is overwriteable.
        if (
            self._panel
            and industry
            and self._industries_table.is_known_industry(industry)
            and not self._industries_table.is_user_pinned()
        ):
            self._industries_table.select_industry(industry)

    def apply_header(self, view: HeaderView) -> None:
        """Apply a pre-built header view (also called directly by
        MainWindow on freshness ticks)."""
        self._h_symbol_lbl.setText(view.symbol)
        self._h_spot_lbl.setText(view.spot_text)
        self._h_change_lbl.setText(view.change_text)
        self._h_change_lbl.setStyleSheet(f"color: {view.change_color};")
        self._h_asof_lbl.setText(view.asof_text)
        self._h_asof_lbl.setStyleSheet(f"color: {view.asof_color};")

    def _apply_header_stats(self, df: pd.DataFrame | None) -> None:
        """Compute and render the stat tiles from an enriched frame.

        Each tile reads directly from the indicator columns produced
        by :class:`StrategyComputeEngine` — no domain interpretation
        here. ``None`` / empty frames clear every tile to em-dash.
        """
        if df is None or df.empty:
            for v in self._h_stats.values():
                v.setText("—")
                v.setStyleSheet(f"color: {MUTED};")
            return

        # ADTV — 20-bar mean of Close × Volume in ₹. Same shape used by
        # Market Pulse so both surfaces show the same number.
        adtv_text = "—"
        adtv_color = MUTED
        if "Volume" in df.columns:
            sub = df[["Close", "Volume"]].tail(20)
            if len(sub) >= 5:
                adtv_inr = float((sub["Close"] * sub["Volume"]).mean())
                adtv_text = _format_adtv_m(adtv_inr)
                adtv_color = WHITE
        self._h_stats["ADTV"].setText(adtv_text)
        self._h_stats["ADTV"].setStyleSheet(f"color: {adtv_color};")

        # ATR% — read straight from the enriched column.
        atr_text = "—"
        atr_color = MUTED
        if "atr_14_pct" in df.columns:
            v = df["atr_14_pct"].iloc[-1]
            if v == v:    # not NaN
                atr_text = f"{float(v):.1f}%"
                atr_color = WHITE
        self._h_stats["ATR%"].setText(atr_text)
        self._h_stats["ATR%"].setStyleSheet(f"color: {atr_color};")

        # 52w position — Close vs trailing 252-bar high/low. 0% = at low,
        # 100% = at high. Coloured GREEN above 80%, RED below 20%.
        pos_text = "—"
        pos_color = MUTED
        if "Close" in df.columns and len(df) >= 30:
            window = df["Close"].tail(252)
            lo = float(window.min())
            hi = float(window.max())
            close = float(df["Close"].iloc[-1])
            if hi > lo:
                pct = 100.0 * (close - lo) / (hi - lo)
                pos_text = f"{pct:.0f}%"
                if pct >= 80.0:
                    pos_color = GREEN
                elif pct <= 20.0:
                    pos_color = RED
                else:
                    pos_color = WHITE
        self._h_stats["52w"].setText(pos_text)
        self._h_stats["52w"].setStyleSheet(f"color: {pos_color};")

        # BBW pctl — read straight from the enriched column.
        bbw_text = "—"
        bbw_color = MUTED
        if "bbw_20_1s_pctl" in df.columns:
            v = df["bbw_20_1s_pctl"].iloc[-1]
            if v == v:
                pct = float(v)
                bbw_text = f"{pct:.0f}"
                if pct >= 80:
                    bbw_color = GOLD    # high expansion
                elif pct <= 20:
                    bbw_color = BLUE    # squeeze
                else:
                    bbw_color = WHITE
        self._h_stats["BBW pctl"].setText(bbw_text)
        self._h_stats["BBW pctl"].setStyleSheet(f"color: {bbw_color};")

    def set_panel(
        self,
        panel: dict[str, pd.DataFrame] | None,
        universe: Universe | None,
        ride_cache: "RideClassificationCache | None" = None,
    ) -> None:
        """Push the enriched panel + universe + ride cache to the
        embedded Industries / Constituents tables.

        Called by MainWindow once the panel finishes loading
        (post-prewarm or first lazy-load). The cache must be the
        same one used to drive the sidebar's chart-symbol
        classification — that's the single-source-of-truth
        contract.

        Args:
            panel: ``{symbol: enriched_df}``.
            universe: source for industry grouping + per-symbol
                metadata.
            ride_cache: pre-built per-symbol + per-industry
                ``RideResult`` cache. ``None`` (typically a unit
                test) makes Phase / Score cells render as em-dash.

        Constituents auto-select rule:
          - If the chart's current industry is one of the visible
            rows, that row is selected (the operator's natural focus
            is the chart symbol's neighbourhood).
          - Otherwise, the pinned ALL row is selected so the bottom
            strip is never empty when there's data on screen.

        Tables don't react to *subsequent* sidebar selections (per
        the agreed model — operators explore industry context
        independently of the chart). The auto-select happens once,
        on panel push.
        """
        self._panel = panel or {}
        self._universe = universe
        self._ride_cache = ride_cache
        self._industries_table.refresh(self._panel, universe, ride_cache)

        # Pick a default industry to populate Constituents.
        target = None
        if (
            self._current_industry
            and self._industries_table.is_known_industry(self._current_industry)
        ):
            target = self._current_industry
        elif self._industries_table.has_all_row():
            target = "ALL"
        if target is not None:
            self._industries_table.select_industry(target)
        else:
            self._constituents_table.clear()

    def clear(self) -> None:
        """Reset every panel to empty state."""
        self._symbol = ""
        self._panel = {}
        self._universe = None
        self._ride_cache = None
        self._current_industry = None
        self.apply_header(EMPTY_HEADER_VIEW)
        self._apply_header_stats(None)
        self._chart.set_data(None, options=None)
        self._industries_table.clear()
        self._constituents_table.clear()

    # ══════════════════════════════════════════════════════════════════════
    # Internal slots
    # ══════════════════════════════════════════════════════════════════════

    def _on_industry_selected(self, industry: str) -> None:
        """Click on an industry row → repopulate the constituents
        table with that industry's members.

        Lookup goes through :meth:`IndustriesTable.members_for` so
        the constituents table stays decoupled from the panel
        grouping logic. Universe + ride cache are passed through —
        no classification happens in the click handler.
        """
        if not industry or not self._panel:
            self._constituents_table.clear()
            return
        members = self._industries_table.members_for(industry)
        self._constituents_table.set_industry(
            industry, members, self._panel, self._universe,
            self._ride_cache,
        )

    # ══════════════════════════════════════════════════════════════════════
    # Build
    # ══════════════════════════════════════════════════════════════════════

    def _build_ui(self) -> None:
        root = QHBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        # ── Centre column: header + (chart over tables) ──────────────
        centre = QWidget()
        centre_lay = QVBoxLayout(centre)
        centre_lay.setContentsMargins(0, 0, 0, 0)
        centre_lay.setSpacing(8)

        centre_lay.addWidget(self._build_header_strip())

        # Vertical splitter — chart on top, tables strip on bottom.
        # Default 70/30 split; the operator can drag the divider.
        v_split = QSplitter(Qt.Orientation.Vertical)
        v_split.setChildrenCollapsible(False)
        v_split.setHandleWidth(6)
        v_split.setStyleSheet(
            f"QSplitter::handle {{ background: {BORDER}; }}"
        )

        self._chart = PriceChart()
        self._chart.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding,
        )
        v_split.addWidget(self._chart)

        # Bottom strip: horizontal splitter for industries | constituents.
        bottom = QWidget()
        bottom_lay = QHBoxLayout(bottom)
        bottom_lay.setContentsMargins(0, 0, 0, 0)
        bottom_lay.setSpacing(0)

        h_split = QSplitter(Qt.Orientation.Horizontal)
        h_split.setChildrenCollapsible(False)
        h_split.setHandleWidth(6)
        h_split.setStyleSheet(
            f"QSplitter::handle {{ background: {BORDER}; }}"
        )

        self._industries_table = IndustriesTable()
        self._constituents_table = ConstituentsTable()
        h_split.addWidget(self._industries_table)
        h_split.addWidget(self._constituents_table)
        # Default split: industries 40%, constituents 60% — the
        # constituents block is denser (more rows, longer Symbol
        # column) and benefits from the extra width.
        h_split.setStretchFactor(0, 2)
        h_split.setStretchFactor(1, 3)
        bottom_lay.addWidget(h_split)
        # Floor the tables strip so the chart can't squeeze it down to
        # a sliver — the operator needs several constituent rows visible
        # at once. The splitter is still draggable above this minimum.
        bottom.setMinimumHeight(240)
        v_split.addWidget(bottom)

        # 60 / 40 chart-to-tables ratio — the previous 70/30 let the
        # chart dominate and squished the Industries / Constituents
        # tables to a couple of rows. 60/40 keeps the chart primary
        # while leaving the tables genuinely usable.
        v_split.setStretchFactor(0, 6)
        v_split.setStretchFactor(1, 4)

        # Wire selection — industry click drives constituent
        # repopulation. Single internal connection; MainWindow can
        # also call set_industry_panel() to push fresh data on
        # refresh.
        self._industries_table.industry_selected.connect(
            self._on_industry_selected,
        )
        # Bubble constituent double-clicks up as the public signal —
        # MainWindow uses this to load the symbol on the chart.
        self._constituents_table.symbol_activated.connect(
            self.symbol_activated,
        )

        centre_lay.addWidget(v_split, stretch=1)
        # Centre column spans the full width — the former Workflow
        # Analysis right rail (OPTIONS OVERLAY + INDUSTRY CONTEXT) was
        # removed; those panels now live in the sidebar. The chart +
        # bottom tables strip own the entire content area.
        root.addWidget(centre, stretch=1)

    def _build_header_strip(self) -> QFrame:
        strip = QFrame()
        strip.setFixedHeight(48)
        strip.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; "
            f"border-radius: 4px;"
        )

        lay = QHBoxLayout(strip)
        lay.setContentsMargins(14, 6, 14, 6)
        lay.setSpacing(18)

        self._h_symbol_lbl = QLabel("—")
        self._h_symbol_lbl.setFont(_mono(14, bold=True))
        self._h_symbol_lbl.setStyleSheet(f"color: {WHITE};")
        lay.addWidget(self._h_symbol_lbl)

        self._h_spot_lbl = QLabel("—")
        self._h_spot_lbl.setFont(_mono(12))
        self._h_spot_lbl.setStyleSheet(f"color: {WHITE};")
        lay.addWidget(self._h_spot_lbl)

        self._h_change_lbl = QLabel("—")
        self._h_change_lbl.setFont(_mono(11, bold=True))
        self._h_change_lbl.setStyleSheet(f"color: {MUTED};")
        lay.addWidget(self._h_change_lbl)

        # Vertical divider before the stat tiles.
        lay.addWidget(self._vbar())

        # Stat tiles — ADTV / ATR% / 52w pos / BBW pctl. Each tile is
        # an inline LABEL value pair so the header reads as a horizontal
        # strip of context that supplements the chart, without forcing
        # the operator to scan the sidebar for at-a-glance numbers.
        self._h_stats: dict[str, QLabel] = {}
        for key, tooltip in (
            ("ADTV",
             "20-bar mean of Close × Volume in ₹ — liquidity context."),
            ("ATR%",
             "ATR(14) as a percentage of latest close — typical daily range."),
            ("52w",
             "Position within the trailing 252-bar high/low range, 0%=low, 100%=high."),
            ("BBW pctl",
             "BBW(20, 1σ) percentile rank against trailing 252-bar history. "
             "Low = squeeze, high = expansion."),
        ):
            tile = self._stat_tile(key, tooltip)
            lay.addWidget(tile["wrapper"])
            self._h_stats[key] = tile["value"]

        lay.addStretch(1)

        self._h_asof_lbl = QLabel("")
        self._h_asof_lbl.setFont(_mono(8))
        self._h_asof_lbl.setStyleSheet(f"color: {MUTED};")
        lay.addWidget(self._h_asof_lbl)

        return strip

    @staticmethod
    def _vbar() -> QFrame:
        bar = QFrame()
        bar.setFrameShape(QFrame.Shape.VLine)
        bar.setFixedWidth(1)
        bar.setStyleSheet(f"background: {BORDER}; border: none;")
        return bar

    @staticmethod
    def _stat_tile(label: str, tooltip: str) -> dict:
        """Build a label/value vertical stack for the header strip.

        Returns ``{"wrapper": QWidget, "value": QLabel}`` so callers
        can update the value at render time without rebuilding.
        """
        wrap = QWidget()
        wrap.setToolTip(tooltip)
        col = QVBoxLayout(wrap)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)

        k = QLabel(label.upper())
        k.setFont(_sans(7))
        k.setStyleSheet(
            f"color: {MUTED}; letter-spacing: 1px;"
        )
        col.addWidget(k)

        v = QLabel("—")
        v.setFont(_mono(11, bold=True))
        v.setStyleSheet(f"color: {MUTED};")
        col.addWidget(v)

        return {"wrapper": wrap, "value": v}

    # Help static analysis — so callers can read this without a typo.
    @property
    def symbol(self) -> str:
        return self._symbol
