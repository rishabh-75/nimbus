"""nimbus_v3.ui.widgets.market_context_tab — industry-level market context.

Shows equal-weighted industry index analysis across all four NSE
classification levels (Macro-Economic Sector, Sector, Industry, Basic
Industry). For each group at the selected level, displays trend,
momentum, and volume metrics computed from the enriched price panel.

Populated by calling ``refresh(panel, universe)`` with the same
enriched panel the scanner uses. Computes EW daily-return indices
per group and derives SMA position, ROC, volume change, and a
composite score.
"""
from __future__ import annotations

import logging
from typing import Final

import pandas as pd
from PyQt6.QtCore import Qt, QRect, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter
from PyQt6.QtWidgets import (
    QComboBox, QHBoxLayout, QHeaderView, QLabel,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

# Ride classification is imported lazily inside _analyze_group /
# _analyze_symbol to keep module-load cheap and to avoid circulars.
# See ``nimbus_v3.compute.ride_initiation`` for the engine.
from nimbus_v3.core.universe import Universe
from nimbus_v3.ui.theme import (
    BLUE, BORDER, EM, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED,
    SURFACE, VIOLET, WHITE,
)


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Column definitions
# ══════════════════════════════════════════════════════════════════════════════

#: Column definitions for the group (top) table.
#:
#: **Post-calibration state.** After empirical OOS testing (see
#: ``scripts/run_phase_calibration.py``), the Snapback/Rank columns
#: from the earlier experiment were dropped:
#:
#: - The "parabolic = snap-back risk" hypothesis didn't hold —
#:   EUPHORIA actually has the highest forward returns on Indian
#:   equities at every horizon tested.
#: - At the user's 10-day horizon, MID phase has the best
#:   return/|drawdown| ratio (0.443 vs 0.415 for EUPHORIA).
#: - Four candidate features (vol_ratio, vol_trend, trend_age,
#:   rs_vs_market) were screened for independent signal; none
#:   produced ≥0.8% spread in ≥2 trending phases, so they were
#:   discarded rather than added to the classifier.
#:
#: Sort order: Composite descending (raw momentum ranking). Phase +
#: Verdict columns provide the operational colour — "where is this
#: setup in its lifecycle, and what should I do with it?".
#: Group table columns. Aligned to the new ride-classification
#: strategy (INIT / RETEST / CONT / NONE) — the old Phase / SMA
#: trend / Tag columns were MR-era artefacts that don't reflect what
#: this screener now optimises for.
#:
#: New default sort: Score descending. Score is the conviction
#: composite from `compute.ride_initiation.score` — combines
#: freshness, volume, BBW quality, momentum, and body cleanness.
#: Phase column shows INIT / RETEST / CONT / —.
_COLUMNS: Final[tuple[str, ...]] = (
    "Group",
    "ADTV",
    "ROC 5d",
    "ROC 10d",
    "%B",
    "Vol",
    "BBW",
    "Phase",
    "Score",
)

#: Constituent table — same columns plus Symbol and Basic Industry.
_CONSTITUENT_COLUMNS: Final[tuple[str, ...]] = (
    "Symbol",
    "Basic Industry",
    "ADTV",
    "ROC 5d",
    "ROC 10d",
    "%B",
    "Vol",
    "BBW",
    "Phase",
    "Score",
)

_LEVEL_MAP: Final[dict[str, str]] = {
    "Macro-Economic Sector": "macro_sector",
    "Sector": "sector",
    "Industry": "industry",
    "Basic Industry": "basic_industry",
}

#: Minimum group size. 1 means every industry / sector with ≥1
#: member appears — including singletons like Aerospace & Defense
#: when only BEL is present in the scanned universe. Previously 3,
#: which silently hid small-but-real industries from the ranking.
_MIN_MEMBERS: int = 1

#: Default pixel widths for the numeric + checkmark columns. Used
#: in Interactive resize mode so the user can drag column dividers
#: to resize (ResizeToContents prevents manual resize). First
#: column ("Group" / "Symbol") always stretches to absorb slack.
_COL_WIDTHS: Final[dict[str, int]] = {
    "Basic Industry": 180,
    "ADTV":           110,
    "ROC 5d":          85,    # fits "-12.34"
    "ROC 10d":         85,
    "%B":              75,    # fits "-0.23" / "1.45"
    "Vol":             80,    # fits "1.45x" with "x" suffix
    "BBW":             80,    # fits "12.45"
    "Phase":           80,    # fits "RETEST"
    "Score":           75,
}

#: Header-tooltip text for the Phase column. Three-phase ride
#: classifier — see ``compute.ride_initiation`` for details and
#: ``docs/research_notes/bb_ride_initiation/`` for empirical context.
_PHASE_TOOLTIP: Final[str] = (
    "Bollinger Band ride classifier — three phases.\n\n"
    "INIT — fresh initiation: body-above today AND yesterday,\n"
    "  yesterday was the FIRST body-above in last 5 bars,\n"
    "  bands expanding from a tight base, volume not below average,\n"
    "  body strong (not a doji).\n\n"
    "RETEST — pullback resumption: body-above today, but earlier\n"
    "  this week price pulled back into the band (held SMA20),\n"
    "  and there was a real ride before the pullback.\n\n"
    "CONT — established continuation: ≥5 of last 10 bars had\n"
    "  %B≥1, body-above today, slope positive, not extended past\n"
    "  %B 1.5, volume not collapsed.\n\n"
    "Priority when multiple match: INIT > RETEST > CONT.\n\n"
    "Group rows roll up over constituents: group's phase is the\n"
    "highest-priority phase appearing in any constituent on the\n"
    "latest bar. If group fires, at least one constituent fires.\n\n"
    "Screener output, no validated forward-return edge — see\n"
    "docs/research_notes/bb_ride_initiation/."
)

#: Per-column content alignment — used for BOTH headers and data
#: cells so they line up visually. Policy (per user request):
#: all columns except the first (Group / Symbol) are centered.
#: Column 0 defaults to left-align via the stretch mode. This gives
#: a uniform tabular look where numeric / text / phase / tag cells
#: all share the same horizontal anchor.
_COL_ALIGNMENT: Final[dict[str, int]] = {
    "ADTV":        int(Qt.AlignmentFlag.AlignCenter),
    "ROC 5d":      int(Qt.AlignmentFlag.AlignCenter),
    "ROC 10d":     int(Qt.AlignmentFlag.AlignCenter),
    "%B":          int(Qt.AlignmentFlag.AlignCenter),
    "Vol":         int(Qt.AlignmentFlag.AlignCenter),
    "BBW":         int(Qt.AlignmentFlag.AlignCenter),
    "Phase":       int(Qt.AlignmentFlag.AlignCenter),
    "Score":       int(Qt.AlignmentFlag.AlignCenter),
}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers — fonts
# ══════════════════════════════════════════════════════════════════════════════

def _sans(size: int, bold: bool = False) -> QFont:
    f = QFont(FONT_UI, size)
    f.setBold(bold)
    return f


def _mono(size: int) -> QFont:
    return QFont(FONT_MONO, size)


def _ride_phase_color(phase: str) -> str:
    """Map ride phase short label to display color.

    Priority-tiered (Option B from operator decision): the highest-
    conviction phase (INIT) gets the brightest neutral colour, RETEST
    gets BLUE (info / second-tier), CONT gets MUTED (lowest tier),
    NONE / em-dash gets MUTED.

    No green/red — these are screener outputs, not validated forward-
    return signals (per walk-forward research). Coloring would imply
    edge that hasn't been demonstrated.
    """
    if phase == "INIT":
        return WHITE
    if phase == "RETEST":
        return BLUE
    if phase == "CONT":
        return MUTED
    return MUTED


#: Numeric sort priority for the ride-phase column. Highest priority
#: (most-conviction) sorts first when the column is sorted descending.
_RIDE_PHASE_SORT_KEY: dict[str, int] = {
    "INIT":   3,
    "RETEST": 2,
    "CONT":   1,
    "—":      0,
}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers — ADTV formatting and riding-upper-BB detection
# ══════════════════════════════════════════════════════════════════════════════

def _format_adtv_m(value_inr: float) -> str:
    """Format Average Daily Traded Value (₹) as straight Millions
    with a thousands separator.

    Examples:
      100 M ₹     → "100 M"
      1 B ₹       → "1,000 M"
      40 B ₹      → "40,000 M"
      2.5 T ₹     → "2,500,000 M"

    NaN or ≤ 0 → "—" (MUTED)

    Straight M (no K/M suffix tiering) is more legible in a table
    where rows at different orders of magnitude sit next to each
    other — "946 M" vs "65,300 M" scans cleanly by eye; "946 M"
    vs "65.3K M" forces mental conversion on every row.
    """
    if value_inr != value_inr or value_inr <= 0:   # NaN or non-positive
        return "—"
    m = value_inr / 1_000_000.0
    return f"{m:,.0f} M"


# ══════════════════════════════════════════════════════════════════════════════
# Regime classification + phase distribution widget
# ══════════════════════════════════════════════════════════════════════════════

#: Per-regime display name + colour. Order here is the order the
#: rule engine checks them in ``_classify_regime`` — most specific
#: first, generic last.
_REGIME_COLORS: dict[str, str] = {
    "RIDE BROAD":   GREEN,  # ≥30% groups firing — broad ride activity
    "RIDE NARROW":  EM,     # 10-30% — selective riders, focused setups
    "RIDE SPARSE":  GOLD,   # 1-10% — only a handful firing, edge cases
    "QUIET":        MUTED,  # 0% — no ride activity in any group
}


def _classify_regime(phase_counts: dict[str, int]) -> str:
    """Classify ride-activity regime from the phase distribution
    across industry groups.

    Counts ANY ride phase (INIT / RETEST / CONT) as activity; the
    "—" (NONE) phase is the inactive baseline. The bands below are
    chosen so the regime label is informative on a typical NIFTY 500
    breakdown (~30-100 industry groups):

      - **RIDE BROAD**  — ≥30% of groups firing.
      - **RIDE NARROW** — 10-30% firing.
      - **RIDE SPARSE** — 1-10% firing.
      - **QUIET**       — 0% firing.
    """
    total = sum(phase_counts.values())
    if total == 0:
        return "QUIET"

    inactive = phase_counts.get("—", 0)
    active = total - inactive
    pct = active / total

    if pct >= 0.30:
        return "RIDE BROAD"
    if pct >= 0.10:
        return "RIDE NARROW"
    if pct >= 0.01:
        return "RIDE SPARSE"
    return "QUIET"


#: Phase display order for the distribution bar. INIT (highest
#: conviction) leftmost so it visually anchors the reader, then
#: RETEST, CONT, and finally "—" (inactive baseline).
_PHASE_BAR_ORDER: tuple[str, ...] = (
    "INIT", "RETEST", "CONT", "—",
)


class PhaseDistributionWidget(QWidget):
    """Compact regime banner: stacked bar + counts + derived label.

    Renders in ~44px of vertical space. Layout::

        [REGIME: LATE-CYCLE]  [====GREEN===|GOLD|==RED==]  EARLY 12 · MID 28 · …

    The regime label is computed via :func:`_classify_regime`;
    colour is looked up from ``_REGIME_COLORS``. The stacked bar
    paints one segment per non-empty phase with width proportional
    to count and colour matching the phase's UI colour. Segments
    with count ≥ 5% of total also carry an inline count label so
    you can read exact numbers without hovering.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._counts: dict[str, int] = {}
        self._total: int = 0
        self._regime: str = "MIXED"
        self.setMinimumHeight(44)

    def update_distribution(self, phase_counts: dict[str, int]) -> None:
        """Recompute regime + repaint from a fresh phase-count map."""
        self._counts = dict(phase_counts)
        self._total = sum(phase_counts.values())
        self._regime = _classify_regime(phase_counts)
        self.update()

    def clear(self) -> None:
        """Reset to empty state (no data)."""
        self._counts = {}
        self._total = 0
        self._regime = "MIXED"
        self.update()

    # ------------------------------------------------------------
    # Paint
    # ------------------------------------------------------------
    def paintEvent(self, event) -> None:  # noqa: ARG002 — Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()

        # Layout regions (horizontal strips):
        #   0           → regime badge (fixed 200 px)
        #   200         → gap 10 px
        #   210 .. w-10 → stacked bar
        #   bottom 16px → count legend
        badge_w = 200
        gap = 10
        bar_x = badge_w + gap
        bar_w = max(0, w - bar_x)
        bar_h = h - 18
        bar_y = 2
        legend_y = bar_y + bar_h + 2
        legend_h = 14

        # ── Regime badge ──────────────────────────────────────
        regime_color = QColor(_REGIME_COLORS.get(self._regime, MUTED))
        painter.setPen(regime_color)
        painter.setFont(_sans(9, bold=True))
        painter.drawText(
            QRect(0, bar_y, badge_w, bar_h),
            int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
            f"REGIME  {self._regime}",
        )

        # ── Stacked bar ───────────────────────────────────────
        if self._total == 0 or bar_w <= 0:
            painter.setPen(QColor(MUTED))
            painter.setFont(_sans(8))
            painter.drawText(
                QRect(bar_x, bar_y, bar_w, bar_h),
                int(Qt.AlignmentFlag.AlignCenter),
                "(no data — run a scan)",
            )
            return

        # Walk phases in conviction order, painting each segment.
        # _PHASE_BAR_ORDER is now a tuple of phase short labels
        # ("INIT", "RETEST", "CONT", "—") — strings, not enums.
        non_empty: list[tuple[str, int]] = [
            (p, self._counts.get(p, 0))
            for p in _PHASE_BAR_ORDER
            if self._counts.get(p, 0) > 0
        ]
        x = bar_x
        for i, (phase_label, count) in enumerate(non_empty):
            if i == len(non_empty) - 1:
                # Fill the remainder so no rounding gap shows.
                seg_w = (bar_x + bar_w) - x
            else:
                seg_w = int(bar_w * count / self._total)
            fill = QColor(_ride_phase_color(phase_label))
            fill.setAlpha(200)
            painter.fillRect(x, bar_y, seg_w, bar_h, fill)
            if seg_w >= 24:
                painter.setPen(QColor(WHITE))
                painter.setFont(_sans(9, bold=True))
                painter.drawText(
                    QRect(x, bar_y, seg_w, bar_h),
                    int(Qt.AlignmentFlag.AlignCenter),
                    str(count),
                )
            x += seg_w

        # ── Legend (phase names below the bar) ────────────────
        x = bar_x
        painter.setFont(_sans(7))
        for i, (phase_label, count) in enumerate(non_empty):
            if i == len(non_empty) - 1:
                seg_w = (bar_x + bar_w) - x
            else:
                seg_w = int(bar_w * count / self._total)
            if seg_w >= 50:
                painter.setPen(QColor(_ride_phase_color(phase_label)))
                painter.drawText(
                    QRect(x, legend_y, seg_w, legend_h),
                    int(Qt.AlignmentFlag.AlignCenter),
                    phase_label,
                )
            x += seg_w


class _NumericTextItem(QTableWidgetItem):
    """A QTableWidgetItem that stores a raw numeric sort key on
    UserRole and uses it for ordering, while the displayed text is
    a separately-formatted string.

    Solves the problem where `setText("65,300 M")` makes Qt sort
    lexicographically ("1,000 M" < "2 M" < "946 M" — all wrong).
    With this item, the caller sets a numeric UserRole value once,
    sets whatever display text they want, and sort comes out right.

    **Missing-value sink**: Items with no UserRole or NaN sort to the
    bottom in BOTH ascending and descending — operators never want
    em-dash rows interleaved among real values regardless of sort
    direction. Implemented by reading the host table's current sort
    order at compare time and flipping the missing-value comparison
    accordingly.
    """

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, QTableWidgetItem):
            return NotImplemented
        a = self.data(Qt.ItemDataRole.UserRole)
        b = other.data(Qt.ItemDataRole.UserRole)
        a_missing = a is None or (isinstance(a, float) and a != a)
        b_missing = b is None or (isinstance(b, float) and b != b)

        if a_missing and b_missing:
            return False
        if a_missing or b_missing:
            # Direction-aware sink: missing rows must end up at the
            # BOTTOM regardless of ascending/descending. Read the
            # current sort order from the host table; flip the
            # "missing > value" relation when descending so Qt's
            # reverse-of-__lt__ still sinks them.
            descending = False
            tw = self.tableWidget()
            if tw is not None:
                hdr = tw.horizontalHeader()
                if hdr is not None:
                    descending = (
                        hdr.sortIndicatorOrder() == Qt.SortOrder.DescendingOrder
                    )
            if descending:
                # In descending: __lt__ True → self comes LATER.
                # Missing self → True (sinks). Missing other → False.
                return a_missing and not b_missing
            else:
                # Ascending: __lt__ True → self comes FIRST.
                # Missing self → False (sinks). Missing other → True.
                return b_missing and not a_missing

        try:
            return float(a) < float(b)
        except (TypeError, ValueError):
            return super().__lt__(other)


# ══════════════════════════════════════════════════════════════════════════════
# Tab widget
# ══════════════════════════════════════════════════════════════════════════════

class MarketContextTab(QWidget):
    """Market context tab — industry-level trend & momentum analysis.

    Public API:
        ``refresh(panel, universe)`` — recompute from enriched data.

    Signals:
        ``symbol_selected(str)`` — user clicked a symbol in the
        constituent table. MainWindow wires this to populate the
        Dashboard + switch to the Dashboard tab.
    """

    symbol_selected = pyqtSignal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._panel: dict[str, pd.DataFrame] = {}
        self._universe: Universe | None = None
        self._current_level: str = "industry"
        self._analysis: pd.DataFrame = pd.DataFrame()
        self._dirty: bool = False
        # Group → member-symbols mapping, refreshed on each recompute.
        # Lets the constituent table populate off the selected group
        # row without rebuilding the grouping from scratch.
        self._group_members: dict[str, list[str]] = {}
        #: Cached industry-relative states keyed by symbol, populated
        #: via ``refresh(industry_relative_states=...)`` from
        #: MainWindow's batched pass. Empty dict means no tag/alpha
        #: columns will render (graceful degradation for legacy
        #: callers that don't supply the cache).
        self._industry_relative_states: dict = {}
        #: Broad-market regime summary (step 3c). When
        #: ``is_broad_decline`` fires, tag cells and the regime
        #: banner at the top of the tab render with a muted warning
        #: treatment.
        from nimbus_v3.compute.market_regime import (
            MarketRegime, evaluate_market_regime,
        )
        self._market_regime: MarketRegime = evaluate_market_regime({})
        #: Current VIX pace regime state. Populated via
        #: :meth:`set_vix_state` from MainWindow once the VIX history
        #: has been loaded. Until then, ``None`` and the header badge
        #: renders as "VIX: —" (same graceful-degradation pattern as
        #: the commodity VOL: — badge).
        self._vix_state: VIXPaceState | None = None
        #: Current correlation regime state. Populated via
        #: :meth:`set_correlation_state` from MainWindow once the
        #: industry returns panel is available. Until then, ``None``
        #: and the header badge renders as "CORR: —".
        self._corr_state: "CorrelationRegimeState | None" = None
        # Loader callable — invoked on first show to populate
        # ``_panel`` + ``_universe`` without requiring a scan. Wired
        # by ``main.py`` after the window is built.
        self._data_loader: "callable | None" = None
        self._loader_attempted: bool = False
        self._build_ui()

    def set_data_loader(self, loader) -> None:
        """Wire a callable that loads panel + universe into this tab.

        The callable should (a) populate its shared cache with the
        enriched panel + universe, and (b) call :meth:`refresh` back
        with the loaded data. Typical impl lives in ``main.py`` and
        is the same function the scanner uses — so Market Context
        and the scanner share state without duplicating the fetch.

        Called once at wiring time. The actual load fires on first
        ``showEvent``.
        """
        self._data_loader = loader

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def refresh(
        self,
        panel: dict[str, pd.DataFrame],
        universe: Universe,
        industry_relative_states: dict | None = None,
        market_regime=None,
    ) -> None:
        """Store the data for deferred computation. The actual
        analysis runs when the tab becomes visible (lazy) to avoid
        blocking the main thread during scan.

        ``industry_relative_states`` is the cached output of the
        industry-analytics batched pass, keyed by symbol. When
        supplied, constituent-table rows render the α-percentile
        and tag columns. When ``None`` (legacy callers), those
        columns show em-dashes / blanks.

        ``market_regime`` is the broad-market summary from the
        same batched pass. When ``is_broad_decline`` is True, tag
        cells render muted as a defensive UX cue. Normalises
        ``None`` to a neutral regime so legacy callers aren't
        forced to supply it.
        """
        from nimbus_v3.compute.market_regime import evaluate_market_regime
        self._panel = panel
        self._universe = universe
        self._industry_relative_states = industry_relative_states or {}
        self._market_regime = (
            market_regime if market_regime is not None
            else evaluate_market_regime({})
        )
        self._dirty = True
        # If already visible, compute now.
        if self.isVisible():
            self._recompute()

    def showEvent(self, event) -> None:    # noqa: N802
        """Compute on first show or when data has changed.

        On the very first show, if no data has been refreshed yet
        and a data loader is wired, invoke it — that's how Market
        Context populates without waiting on a scan. The loader is
        idempotent (shared state with the scanner), so if a scan
        already loaded the panel, this is free.
        """
        super().showEvent(event)

        # First-show path: kick the loader if no data yet.
        if (
            not self._panel
            and self._data_loader is not None
            and not self._loader_attempted
        ):
            self._loader_attempted = True
            if hasattr(self, "_summary"):
                self._summary.setText(
                    "Loading equity panel for industry analysis — this takes "
                    "~30s on a cold cache, then is instant. "
                    "Scanner will also use this data once ready."
                )
            if hasattr(self, "_phase_bar"):
                self._phase_bar.clear()
            # Defer the load one event-loop tick so the 'loading'
            # message paints first — otherwise the tab freezes with
            # its previous content while yfinance fetches run.
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(50, self._run_loader_safely)
            return

        if self._dirty:
            self._recompute()
        elif not self._panel or self._universe is None:
            # No scan data has been provided yet — ensure the empty
            # state hint is visible so the tab doesn't stay blank.
            if hasattr(self, "_summary"):
                self._summary.setText(
                    "Run a scan on the Scanner tab to populate industry analysis. "
                    "Market Context groups all scanned symbols by industry / sector / "
                    "macro and computes EW trend, volume, and ROC per group."
                )
            if hasattr(self, "_phase_bar"):
                self._phase_bar.clear()

    def _run_loader_safely(self) -> None:
        """Invoke the wired data loader with error handling.

        The loader is expected to call :meth:`refresh` back on this
        tab as a side effect — we don't use its return value. Any
        exception is logged and surfaced to the user via the summary
        label so a network-down state is visible rather than silent.
        """
        loader = self._data_loader
        if loader is None:
            return
        try:
            loader()
        except Exception as exc:    # noqa: BLE001
            logger.exception("market_context: data loader failed")
            if hasattr(self, "_summary"):
                self._summary.setText(
                    f"Could not load equity panel: {exc}. "
                    f"Check network (yfinance/NSE reachable?) and try the "
                    f"Scanner tab's SCAN button to retry."
                )
            if hasattr(self, "_phase_bar"):
                self._phase_bar.clear()

    # ══════════════════════════════════════════════════════════════════════
    # UI construction
    # ══════════════════════════════════════════════════════════════════════

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 6, 8, 6)
        root.setSpacing(6)

        # ── Header bar ────────────────────────────────────────────────
        header = QHBoxLayout()

        title = QLabel("MARKET PULSE")
        title.setFont(_sans(11, bold=True))
        title.setStyleSheet(f"color: {EM};")
        header.addWidget(title)

        header.addStretch()

        # Level selector.
        lbl = QLabel("Classification:")
        lbl.setFont(_sans(8))
        lbl.setStyleSheet(f"color: {MUTED};")
        header.addWidget(lbl)

        self._level_combo = QComboBox()
        self._level_combo.setFont(_sans(8))
        for display_name in _LEVEL_MAP:
            self._level_combo.addItem(display_name)
        self._level_combo.setCurrentText("Industry")
        self._level_combo.currentTextChanged.connect(self._on_level_changed)
        self._level_combo.setStyleSheet(
            f"QComboBox {{ background: {SURFACE}; color: {WHITE}; "
            f"border: 1px solid {BORDER}; padding: 3px 8px; }}"
        )
        header.addWidget(self._level_combo)

        root.addLayout(header)

        # ── Regime banner: phase distribution across the universe ────
        # Custom widget: [REGIME badge] [stacked phase bar] with phase
        # labels under the bar. Derived regime ("RISK-ON", "LATE-CYCLE",
        # etc.) is computed from the count distribution — see
        # ``_classify_regime`` for the rules.
        self._phase_bar = PhaseDistributionWidget()
        root.addWidget(self._phase_bar)

        # ── Summary strip ─────────────────────────────────────────────
        self._summary = QLabel("Select a classification level and load data.")
        self._summary.setFont(_sans(8))
        self._summary.setStyleSheet(f"color: {MUTED};")
        root.addWidget(self._summary)

        # ── Tables: groups (top) + constituents (bottom) ─────────────
        # A QSplitter lets the user drag the divider to give more
        # space to whichever table they care about. 60/40 default
        # favours the group view since it's the entry point; the
        # constituent view is the drill-down.
        from PyQt6.QtWidgets import QSplitter
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setChildrenCollapsible(False)
        # 8px handle doubles as visible padding between the two
        # tables — previously the constituent table sat flush against
        # the group table above it. Handle is transparent so it
        # reads as empty space, but the drag-to-resize affordance is
        # preserved.
        splitter.setHandleWidth(8)
        splitter.setStyleSheet(
            "QSplitter::handle { background: transparent; }"
        )

        # ── Group table ───────────────────────────────────────────────
        group_container = QWidget()
        group_lay = QVBoxLayout(group_container)
        group_lay.setContentsMargins(0, 0, 0, 0)
        group_lay.setSpacing(2)

        self._table = QTableWidget()
        self._table.setColumnCount(len(_COLUMNS))
        self._table.setHorizontalHeaderLabels(_COLUMNS)
        # Phase column header tooltip — discloses that the phase
        # classifier is a screener, not validated alpha.
        _phase_idx = _COLUMNS.index("Phase")
        _phase_header_item = self._table.horizontalHeaderItem(_phase_idx)
        if _phase_header_item is not None:
            _phase_header_item.setToolTip(_PHASE_TOOLTIP)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows,
        )
        self._table.setSelectionMode(
            QTableWidget.SelectionMode.SingleSelection,
        )
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        self._table.setFont(_mono(8))
        self._table.setStyleSheet(self._table_stylesheet())

        hdr = self._table.horizontalHeader()
        # Group column stretches to absorb viewport width — long
        # industry names like "Agricultural Commercial & Construction
        # Vehicles" have room to breathe, and the table fills the
        # full width of the tab area. Tradeoff: Stretch blocks manual
        # resize of this specific column. All other columns remain
        # Interactive (user can drag-resize their widths).
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for i in range(1, len(_COLUMNS)):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            self._table.setColumnWidth(i, _COL_WIDTHS.get(_COLUMNS[i], 80))

        # Align each header cell to match its content. Without this,
        # headers default to left and a right-aligned number column
        # looks mismatched with its left-aligned header.
        for i, col_name in enumerate(_COLUMNS):
            align = _COL_ALIGNMENT.get(col_name)
            if align is not None:
                self._table.horizontalHeaderItem(i).setTextAlignment(align)

        # Selection drives the constituent table below.
        self._table.itemSelectionChanged.connect(
            self._on_group_selection_changed,
        )

        group_lay.addWidget(self._table, stretch=1)
        splitter.addWidget(group_container)

        # ── Constituent table ─────────────────────────────────────────
        constituent_container = QWidget()
        cons_lay = QVBoxLayout(constituent_container)
        cons_lay.setContentsMargins(0, 0, 0, 0)
        cons_lay.setSpacing(2)

        self._constituent_header = QLabel("CONSTITUENTS — (select a group above)")
        self._constituent_header.setFont(_sans(9, bold=True))
        self._constituent_header.setStyleSheet(f"color: {EM};")
        cons_lay.addWidget(self._constituent_header)

        self._constituent_table = QTableWidget()
        self._constituent_table.setColumnCount(len(_CONSTITUENT_COLUMNS))
        self._constituent_table.setHorizontalHeaderLabels(_CONSTITUENT_COLUMNS)
        # Phase header tooltip — same disclosure as on the group table.
        _phase_idx_c = _CONSTITUENT_COLUMNS.index("Phase")
        _phase_header_c = self._constituent_table.horizontalHeaderItem(_phase_idx_c)
        if _phase_header_c is not None:
            _phase_header_c.setToolTip(_PHASE_TOOLTIP)
        self._constituent_table.setAlternatingRowColors(True)
        self._constituent_table.setSelectionBehavior(
            QTableWidget.SelectionBehavior.SelectRows,
        )
        self._constituent_table.setSortingEnabled(True)
        self._constituent_table.verticalHeader().setVisible(False)
        self._constituent_table.setFont(_mono(8))
        self._constituent_table.setStyleSheet(self._table_stylesheet())

        cons_hdr = self._constituent_table.horizontalHeader()
        # Symbol column — fixed width, Interactive (draggable).
        # NSE tickers are short; 140px fits "BAJFINANCE" worst case.
        cons_hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self._constituent_table.setColumnWidth(0, 140)
        # Basic Industry — Stretch to absorb viewport slack. Text
        # column, often 20-40 chars long, so letting it grow means
        # long labels like "Commercial Vehicles" render in full.
        cons_hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        for i in range(2, len(_CONSTITUENT_COLUMNS)):
            cons_hdr.setSectionResizeMode(
                i, QHeaderView.ResizeMode.Interactive,
            )
            self._constituent_table.setColumnWidth(
                i, _COL_WIDTHS.get(_CONSTITUENT_COLUMNS[i], 80),
            )

        # Per-column header alignment — same map as the group table.
        for i, col_name in enumerate(_CONSTITUENT_COLUMNS):
            align = _COL_ALIGNMENT.get(col_name)
            if align is not None:
                self._constituent_table.horizontalHeaderItem(i).setTextAlignment(align)

        # Double-click → load the symbol in Dashboard.
        self._constituent_table.cellDoubleClicked.connect(
            self._on_constituent_activated,
        )

        cons_lay.addWidget(self._constituent_table, stretch=1)
        splitter.addWidget(constituent_container)

        # Default 60/40 split — group view gets more room.
        splitter.setSizes([600, 400])

        root.addWidget(splitter, stretch=1)

    @staticmethod
    def _table_stylesheet() -> str:
        """Shared QTableWidget stylesheet for both tables."""
        return (
            f"QTableWidget {{ "
            f"  background: {SURFACE}; color: {WHITE}; "
            f"  gridline-color: {BORDER}; border: 1px solid {BORDER}; "
            f"}} "
            f"QTableWidget::item {{ padding: 4px 8px; }} "
            f"QHeaderView::section {{ "
            f"  background: {SURFACE}; color: {EM}; "
            f"  border: 1px solid {BORDER}; padding: 4px 6px; "
            f"  font-weight: bold; "
            f"}} "
            f"QTableWidget::item:alternate {{ background: rgba(255,255,255,0.02); }}"
        )

    # ══════════════════════════════════════════════════════════════════════
    # Computation — EW industry index analysis
    # ══════════════════════════════════════════════════════════════════════

    def _on_level_changed(self, text: str) -> None:
        attr = _LEVEL_MAP.get(text, "industry")
        self._current_level = attr
        self._recompute()

    def _recompute(self) -> None:
        if not self._panel or self._universe is None:
            # Pre-scan — show a helpful hint instead of staying blank.
            logger.info(
                "market_context: awaiting scan data — panel=%d symbols, "
                "universe=%s",
                len(self._panel), "set" if self._universe is not None else "None",
            )
            if hasattr(self, "_summary"):
                self._summary.setText(
                    "Run a scan on the Scanner tab to populate industry analysis. "
                    "Market Context groups all scanned symbols by industry / sector / "
                    "macro and computes EW trend, volume, and ROC per group."
                )
            if hasattr(self, "_phase_bar"):
                self._phase_bar.clear()
            return

        attr = self._current_level
        # Group symbols by the selected classification level.
        groups: dict[str, list[str]] = {}
        for sym in self._panel:
            meta = self._universe.symbols.get(sym)
            if meta is None or meta.is_etf:
                continue
            group_name = getattr(meta, attr, "Unknown")
            if group_name and group_name != "Unknown":
                groups.setdefault(group_name, []).append(sym)

        rows: list[dict] = []
        kept_groups: dict[str, list[str]] = {}
        for name, members in sorted(groups.items()):
            if len(members) < _MIN_MEMBERS:
                continue
            row = self._analyze_group(name, members)
            if row is not None:
                rows.append(row)
                # Only remember groups that survived the 50-bar gate
                # inside _analyze_group — constituent-lookup must never
                # reference a group that isn't present in the table.
                kept_groups[name] = members

        # ALL row — virtual universe-wide aggregate. Members are every
        # symbol across every retained industry. Computed via
        # _analyze_group with the special name "ALL"; the analyzer
        # handles industry consensus + median Score over the entire
        # universe. Pinned to the top below by separating it from
        # the sort.
        all_members: list[str] = []
        for ms in kept_groups.values():
            all_members.extend(ms)
        all_row: dict | None = None
        if all_members:
            all_row = self._analyze_group("ALL", all_members)
            if all_row is not None:
                kept_groups["ALL"] = all_members

        self._analysis = pd.DataFrame(rows)
        if not self._analysis.empty:
            # Pre-sort regular industry rows by Score descending
            # (NaN sinks to bottom). ALL row is prepended after
            # sorting so it always appears at the top regardless
            # of its score.
            self._analysis = self._analysis.sort_values(
                "Score", ascending=False, na_position="last",
            ).reset_index(drop=True)
            if all_row is not None:
                self._analysis = pd.concat(
                    [pd.DataFrame([all_row]), self._analysis],
                    ignore_index=True,
                )

        self._group_members = kept_groups
        self._dirty = False
        self._render_table()
        self._render_summary()
        # Default to the top-ranked group so the constituent table
        # shows something useful immediately.
        self._auto_select_first_group()

    def _analyze_group(
        self, name: str, members: list[str],
    ) -> dict | None:
        """Compute trend / volume / ROC for one EW industry group.

        Builds an equal-weighted daily-return index across ``members``
        and summarises it via :meth:`_compute_metrics_from_series`.
        Returns ``None`` when fewer than 50 bars of usable data exist.
        """
        closes = pd.DataFrame({
            sym: self._panel[sym]["Close"]
            for sym in members if sym in self._panel
        })
        volumes = pd.DataFrame({
            sym: self._panel[sym]["Volume"]
            for sym in members
            if sym in self._panel and "Volume" in self._panel[sym]
        })

        closes = closes.ffill().dropna(how="all")
        volumes = volumes.ffill().fillna(0).reindex(closes.index)
        if len(closes) < 50:
            return None

        # EW daily return → cumulative index.
        ew_ret = closes.pct_change().mean(axis=1)
        ew_idx = (1 + ew_ret).cumprod() * 100
        total_vol = volumes.sum(axis=1)

        # ADTV for the industry — SUM of each member's 20-day
        # ADTV. Total ₹-liquidity flowing through the industry; the
        # quantity that actually matters when sizing into an
        # industry rotation.
        adtv_sum_inr = 0.0
        for sym in members:
            if sym not in self._panel:
                continue
            df = self._panel[sym]
            if "Volume" not in df.columns:
                continue
            sub = df[["Close", "Volume"]].tail(20)
            if len(sub) < 5:
                continue
            adtv_sum_inr += float((sub["Close"] * sub["Volume"]).mean())

        metrics = self._compute_metrics_from_series(ew_idx, total_vol)
        if metrics is None:
            return None

        # Phase + Score — industry-level ride classifier output.
        # The classifier rolls up per-constituent classifications:
        # group's phase = highest-priority phase appearing in any
        # constituent on this bar; group's score = ADTV-weighted mean
        # of scores at that phase. So if the group fires, at least
        # one constituent is firing — semantics are anchored to the
        # constituent level (no synthetic OHLCV).
        phase_label = "—"
        score_val: float = float("nan")
        is_all_row = (name == "ALL")
        try:
            from nimbus_v3.compute.ride_initiation import RideEngine
            members_panel = {
                sym: self._panel[sym]
                for sym in members
                if sym in self._panel
            }
            eng = RideEngine()
            res = (
                eng.classify_universe(members_panel)
                if is_all_row
                else eng.classify_industry(members_panel)
            )
            if not res.phase.empty:
                phase_label = str(res.phase.iloc[-1])
                last_score = res.score.iloc[-1]
                if last_score == last_score:    # not NaN
                    score_val = float(last_score)
        except Exception:    # noqa: BLE001
            phase_label = "—"
            score_val = float("nan")

        return {
            "Group": name,
            "ADTV": adtv_sum_inr,
            **metrics,
            "Phase": phase_label,
            "Score": score_val,
        }

    def _analyze_symbol(self, sym: str) -> dict | None:
        """Compute the same metric set for a single symbol.

        Same math as :meth:`_analyze_group` but on the symbol's own
        Close + Volume series — no EW roll-up. Returned dict is
        shaped for :data:`_CONSTITUENT_COLUMNS` and additionally
        carries ``α rank`` and ``Tags`` pulled from the cached
        industry-relative state when available.
        """
        df = self._panel.get(sym)
        if df is None or len(df) < 50:
            return None
        closes = df["Close"].ffill()
        volumes = (
            df["Volume"].ffill().fillna(0)
            if "Volume" in df
            else pd.Series(0, index=closes.index)
        )
        metrics = self._compute_metrics_from_series(closes, volumes)
        if metrics is None:
            return None

        # ADTV — 20-bar mean of Close × Volume in ₹.
        if "Volume" in df.columns:
            sub = df[["Close", "Volume"]].tail(20)
            adtv_inr = (
                float((sub["Close"] * sub["Volume"]).mean())
                if len(sub) >= 5 else float("nan")
            )
        else:
            adtv_inr = float("nan")

        # Basic Industry — finest-grained industry label from the
        # NIFTY500 industry DB. Graceful fallback to em-dash when
        # the symbol isn't in the universe (possible if the
        # industry DB was last built before this symbol was added
        # to the index — see docs on refresh cadence).
        basic_ind = "—"
        if self._universe is not None:
            meta = self._universe.symbols.get(sym)
            if meta is not None:
                basic_ind = meta.basic_industry or "—"

        # Phase + Score — symbol-level ride classifier output.
        # Phase is the latest bar's ride phase (INIT / RETEST / CONT
        # / —). Score is the composite conviction (0-100, NaN when
        # phase is —). NOT a validated forward-return signal — see
        # ``compute.ride_initiation`` docstring + research notes.
        phase_label = "—"
        score_val: float = float("nan")
        if self._panel is not None and sym in self._panel:
            try:
                from nimbus_v3.compute.ride_initiation import RideEngine
                res = RideEngine().classify(self._panel[sym])
                if not res.phase.empty:
                    phase_label = str(res.phase.iloc[-1])
                if not res.score.empty:
                    last_score = res.score.iloc[-1]
                    if last_score == last_score:    # not NaN
                        score_val = float(last_score)
            except Exception:    # noqa: BLE001
                phase_label = "—"
                score_val = float("nan")

        return {
            "Symbol": sym,
            "Basic Industry": basic_ind,
            "ADTV": adtv_inr,
            **metrics,
            "Phase": phase_label,
            "Score": score_val,
        }

    @staticmethod
    def _compute_metrics_from_series(
        series: pd.Series, volume: pd.Series,
    ) -> dict | None:
        """Shared price-derived metrics used by both group and symbol
        rows. Phase / Score come from :class:`RideEngine` separately
        (in the analyzer methods) since they need the full enriched
        OHLC dataframe, not a single close series.

        Returns:
          - ``ROC 5d`` / ``ROC 10d`` — short / medium momentum
          - ``%B`` — close %B at last bar (1σ bands)
          - ``Vol`` — volume / 20-bar avg at last bar
          - ``BBW`` — 1σ BBW% at last bar

        ``None`` when <50 bars (insufficient history for SMA50).
        """
        n = len(series)
        if n < 50:
            return None
        last = float(series.iloc[-1])

        roc5 = (last / float(series.iloc[-6]) - 1) * 100 if n >= 6 else 0.0
        roc10 = (last / float(series.iloc[-11]) - 1) * 100 if n >= 11 else 0.0

        # Volume ratio at the last bar — current vol vs 20-bar avg.
        vol_last = float(volume.iloc[-1]) if n >= 1 else 0.0
        vol_sma20 = float(volume.iloc[-20:].mean()) if n >= 20 else 0.0
        vol_ratio = vol_last / vol_sma20 if vol_sma20 > 0 else float("nan")

        # 1σ %B and BBW at the last bar.
        sma20 = float(series.rolling(20).mean().iloc[-1])
        std20 = float(series.rolling(20).std().iloc[-1]) if n >= 20 else 0.0
        bb_upper = sma20 + std20
        bb_lower = sma20 - std20
        band_width = bb_upper - bb_lower
        pct_b = (last - bb_lower) / band_width if band_width > 0 else float("nan")
        bbw = (band_width / sma20 * 100.0) if sma20 > 0 else float("nan")

        return {
            "ROC 5d": round(roc5, 2),
            "ROC 10d": round(roc10, 2),
            "%B": round(pct_b, 2) if pct_b == pct_b else float("nan"),
            "Vol": round(vol_ratio, 2) if vol_ratio == vol_ratio else float("nan"),
            "BBW": round(bbw, 2) if bbw == bbw else float("nan"),
        }

    # ══════════════════════════════════════════════════════════════════════
    # Rendering
    # ══════════════════════════════════════════════════════════════════════

    def _render_table(self) -> None:
        df = self._analysis
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(df))

        for row_idx, (_, row) in enumerate(df.iterrows()):
            is_all_row = (row.get("Group") == "ALL")
            for col_idx, col_name in enumerate(_COLUMNS):
                val = row.get(col_name, "")
                item = QTableWidgetItem()

                if col_name == "Group":
                    group_name = str(val)
                    item.setData(Qt.ItemDataRole.UserRole, group_name)
                    item.setText(group_name)
                    item.setForeground(QColor(WHITE))
                elif col_name == "ADTV":
                    # Liquidity context — MUTED. Numeric sort via UserRole.
                    try:
                        raw = float(val) if val not in ("", None) else float("nan")
                    except (TypeError, ValueError):
                        raw = float("nan")
                    item = _NumericTextItem()
                    item.setData(Qt.ItemDataRole.UserRole, raw)
                    item.setText(_format_adtv_m(raw))
                    item.setForeground(QColor(MUTED))
                elif col_name == "%B":
                    # Single number, color by zone. Above 1.0 (riding) →
                    # GREEN, below 0 (oversold) → RED, in-band → WHITE.
                    try:
                        pct_b = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        pct_b = float("nan")
                    item = _NumericTextItem()
                    if pct_b != pct_b:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, pct_b)
                        item.setText(f"{pct_b:.2f}")
                        if pct_b >= 1.0:
                            item.setForeground(QColor(GREEN))
                        elif pct_b <= 0.0:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                elif col_name == "Vol":
                    # Volume ratio (vol/vol_sma_20). 1.5×+ → GREEN,
                    # below 0.7× → RED, otherwise WHITE.
                    try:
                        vr = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        vr = float("nan")
                    item = _NumericTextItem()
                    if vr != vr:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, vr)
                        item.setText(f"{vr:.2f}x")
                        if vr >= 1.5:
                            item.setForeground(QColor(GREEN))
                        elif vr < 0.7:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                elif col_name == "BBW":
                    # BBW% — uncolored, expansion alone isn't directional.
                    try:
                        bbw = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        bbw = float("nan")
                    item = _NumericTextItem()
                    if bbw != bbw:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, bbw)
                        item.setText(f"{bbw:.2f}")
                        item.setForeground(QColor(WHITE))
                elif col_name == "Phase":
                    # Ride phase: INIT / RETEST / CONT / —. Coloured
                    # by priority tier (Option B). Sort key is priority
                    # (descending) so highest-conviction phases sort
                    # first — operators want INIT rows at the top.
                    phase_str = str(val) if val not in ("", None) else "—"
                    item = _NumericTextItem()
                    item.setText(phase_str)
                    item.setData(
                        Qt.ItemDataRole.UserRole,
                        float(_RIDE_PHASE_SORT_KEY.get(phase_str, 0)),
                    )
                    item.setForeground(QColor(_ride_phase_color(phase_str)))
                elif col_name == "Score":
                    # Composite conviction score (0-100). NaN → "—"
                    # (no fire). White, larger numbers darker shade
                    # would be possible but we keep it neutral.
                    try:
                        score = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        score = float("nan")
                    item = _NumericTextItem()
                    if score != score:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, score)
                        item.setText(f"{score:.0f}")
                        item.setForeground(QColor(WHITE))
                else:
                    # ROC 5d / ROC 10d — colour by sign.
                    try:
                        fval = float(val) if val not in ("", None) else 0.0
                    except (TypeError, ValueError):
                        fval = 0.0
                    item.setData(Qt.ItemDataRole.DisplayRole, fval)
                    if fval > 0:
                        item.setForeground(QColor(GREEN))
                    elif fval < 0:
                        item.setForeground(QColor(RED))
                    else:
                        item.setForeground(QColor(MUTED))

                # Alignment is per _COL_ALIGNMENT — applied uniformly
                # to every non-Group cell (Group stays left via
                # default). Centralising here means future alignment
                # tweaks happen in one place.
                align = _COL_ALIGNMENT.get(col_name)
                if align is not None:
                    item.setTextAlignment(align)

                # ALL row gets bold weight to distinguish it as the
                # universe aggregate. Keeps the colour coding intact
                # so phase/score colors still register, just emphasises
                # the row as semantically different from per-industry.
                if is_all_row:
                    bold_font = item.font()
                    bold_font.setBold(True)
                    item.setFont(bold_font)

                item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
                )
                self._table.setItem(row_idx, col_idx, item)

        self._table.setSortingEnabled(True)
        # Default sort: Score descending. Score is the conviction
        # composite — operators want highest-conviction signals at
        # the top. Phase column priority breaks ties since within
        # the same score INIT > RETEST > CONT.
        score_col = _COLUMNS.index("Score")
        self._table.sortByColumn(
            score_col, Qt.SortOrder.DescendingOrder,
        )

    def _render_summary(self) -> None:
        df = self._analysis
        if df.empty:
            self._phase_bar.clear()
            self._summary.setText("No data — run a scan first.")
            return

        top = df.iloc[0]["Group"] if len(df) else "—"
        bot = df.iloc[-1]["Group"] if len(df) else "—"

        # Feed the regime banner: ride-phase distribution across
        # groups. Maps the ride-phase enum values to the legacy
        # phase-bar colour slots so the banner renders without a
        # widget rewrite. Operators reading the bar get a quick
        # "how many groups are firing, in which phase?" answer.
        # If you change the legacy colours/order, update
        # _PHASE_BAR_ORDER too.
        phase_counts = df["Phase"].value_counts().to_dict()
        self._phase_bar.update_distribution(phase_counts)

        # Text summary: universe totals + leader/laggard by Score.
        base_summary = (
            f"{len(df)} groups across {len(self._panel)} symbols  ·  "
            f"Leader: {top}  ·  Laggard: {bot}"
        )
        if self._market_regime.is_broad_decline:
            self._summary.setText(
                f"⚠ BROAD DECLINE: "
                f"{self._market_regime.pct_declining * 100:.0f}% of "
                f"{self._market_regime.n_industries} industries in DECLINE — "
                f"alpha/beta tags rendered muted (signal reliability "
                f"reduced per 2025-H1 walk-forward).   ·   {base_summary}"
            )
            self._summary.setStyleSheet(f"color: {GOLD};")
        else:
            self._summary.setText(base_summary)
            self._summary.setStyleSheet(f"color: {WHITE};")

    # ══════════════════════════════════════════════════════════════════════
    # Constituent-table wiring
    # ══════════════════════════════════════════════════════════════════════

    def _auto_select_first_group(self) -> None:
        """Select row 0 of the group table so the constituent table
        populates with the top-ranked (highest-composite) group."""
        if self._table.rowCount() == 0:
            self._clear_constituents()
            return
        self._table.selectRow(0)
        # selectRow fires itemSelectionChanged → populates constituents.

    def _on_group_selection_changed(self) -> None:
        """Populate the constituent table from the selected group."""
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return
        row_idx = rows[0].row()
        # The "Group" name is column 0; read the raw industry name
        # from the cell's UserRole. Display text may carry a ↑/↓
        # arrow prefix for stable-11 industries in a classifiable
        # regime, but self._group_members is keyed by raw industry
        # name. Using UserRole decouples display from lookup so
        # future UI tweaks to the cell text can't re-break this.
        cell = self._table.item(row_idx, 0)
        if cell is None:
            return
        group_name = cell.data(Qt.ItemDataRole.UserRole)
        if group_name is None:
            # Defensive fallback for any code path that populates
            # the cell without UserRole. Strip a potential leading
            # arrow + space so we still find the industry.
            text = cell.text()
            if text.startswith("↑ ") or text.startswith("↓ "):
                group_name = text[2:]
            else:
                group_name = text
        members = self._group_members.get(group_name, [])
        self._render_constituents(group_name, members)

    def _render_constituents(
        self, group_name: str, members: list[str],
    ) -> None:
        """Compute per-symbol metrics for every group member and
        render them into the constituent table, sorted by Composite
        descending — same treatment as the group table above."""
        self._constituent_header.setText(
            f"CONSTITUENTS — {group_name}  ({len(members)} symbols)"
        )

        rows: list[dict] = []
        for sym in members:
            row = self._analyze_symbol(sym)
            if row is not None:
                rows.append(row)

        if not rows:
            self._constituent_table.setRowCount(0)
            return

        df = pd.DataFrame(rows).sort_values(
            "Score", ascending=False, na_position="last",
        ).reset_index(drop=True)

        self._constituent_table.setSortingEnabled(False)
        self._constituent_table.setRowCount(len(df))
        for row_idx, (_, r) in enumerate(df.iterrows()):
            for col_idx, col_name in enumerate(_CONSTITUENT_COLUMNS):
                val = r.get(col_name, "")
                item = QTableWidgetItem()
                if col_name == "Symbol":
                    item.setText(str(val))
                    item.setForeground(QColor(WHITE))
                elif col_name == "Basic Industry":
                    item.setText(str(val) if val else "—")
                    item.setForeground(QColor(MUTED))
                elif col_name == "ADTV":
                    try:
                        raw = float(val) if val not in ("", None) else float("nan")
                    except (TypeError, ValueError):
                        raw = float("nan")
                    item = _NumericTextItem()
                    item.setData(Qt.ItemDataRole.UserRole, raw)
                    item.setText(_format_adtv_m(raw))
                    item.setForeground(QColor(MUTED))
                elif col_name == "%B":
                    try:
                        pct_b = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        pct_b = float("nan")
                    item = _NumericTextItem()
                    if pct_b != pct_b:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, pct_b)
                        item.setText(f"{pct_b:.2f}")
                        if pct_b >= 1.0:
                            item.setForeground(QColor(GREEN))
                        elif pct_b <= 0.0:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                elif col_name == "Vol":
                    try:
                        vr = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        vr = float("nan")
                    item = _NumericTextItem()
                    if vr != vr:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, vr)
                        item.setText(f"{vr:.2f}x")
                        if vr >= 1.5:
                            item.setForeground(QColor(GREEN))
                        elif vr < 0.7:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                elif col_name == "BBW":
                    try:
                        bbw = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        bbw = float("nan")
                    item = _NumericTextItem()
                    if bbw != bbw:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, bbw)
                        item.setText(f"{bbw:.2f}")
                        item.setForeground(QColor(WHITE))
                elif col_name == "Phase":
                    phase_str = str(val) if val not in ("", None) else "—"
                    item = _NumericTextItem()
                    item.setText(phase_str)
                    item.setData(
                        Qt.ItemDataRole.UserRole,
                        float(_RIDE_PHASE_SORT_KEY.get(phase_str, 0)),
                    )
                    item.setForeground(QColor(_ride_phase_color(phase_str)))
                elif col_name == "Score":
                    try:
                        score = float(val) if val == val else float("nan")
                    except (TypeError, ValueError):
                        score = float("nan")
                    item = _NumericTextItem()
                    if score != score:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    else:
                        item.setData(Qt.ItemDataRole.UserRole, score)
                        item.setText(f"{score:.0f}")
                        item.setForeground(QColor(WHITE))
                else:
                    # ROC 5d / ROC 10d — colour by sign.
                    try:
                        fval = float(val) if val not in ("", None) else 0.0
                    except (TypeError, ValueError):
                        fval = 0.0
                    item.setData(Qt.ItemDataRole.DisplayRole, fval)
                    if fval > 0:
                        item.setForeground(QColor(GREEN))
                    elif fval < 0:
                        item.setForeground(QColor(RED))
                    else:
                        item.setForeground(QColor(MUTED))

                # Centralised alignment (see _COL_ALIGNMENT docstring).
                align = _COL_ALIGNMENT.get(col_name)
                if align is not None:
                    item.setTextAlignment(align)

                item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
                )
                self._constituent_table.setItem(row_idx, col_idx, item)

        self._constituent_table.setSortingEnabled(True)
        # Default sort: Score descending — highest-conviction symbols
        # first. NaN scores (no fire) sink to the bottom.
        score_col = _CONSTITUENT_COLUMNS.index("Score")
        self._constituent_table.sortByColumn(
            score_col, Qt.SortOrder.DescendingOrder,
        )

    def _clear_constituents(self) -> None:
        self._constituent_header.setText(
            "CONSTITUENTS — (select a group above)"
        )
        self._constituent_table.setRowCount(0)

    def _on_constituent_activated(self, row: int, _col: int) -> None:
        """Double-click on a constituent row → emit symbol_selected.

        MainWindow wires this to populate the Dashboard + switch to
        the Dashboard tab, matching the scanner-table double-click
        navigation pattern.
        """
        if row < 0:
            return
        cell = self._constituent_table.item(row, 0)
        if cell is None:
            return
        symbol = cell.text().strip()
        if symbol:
            self.symbol_selected.emit(symbol)
