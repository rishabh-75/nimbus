"""nimbus_v3.compute.horizon_views — one strength horizon, applied coherently.

Stateless. Builds, for each selectable strength horizon, the complete set of
downstream reads that depend on it: the industry rotation, both confluence
variants (all-members and >=3y-members) and the per-symbol edge.

WHY THIS EXISTS
---------------
"Strength" is one quantity with one window, but it surfaces in two tabs:

    Confluence "Strength"   = industry_rs_excess(rotation.roc, bench_return)
    Edge       "RS Excess"  = industry_rs_excess(rotation.roc, bench_return)

These are not merely similar — they are the SAME number from the SAME shared
helper, and the app relies on that. If each tab owned its own horizon control
they could disagree: Confluence showing a 5-day strength while Edge shrinks a
20-day RS excess by a trust gate derived from the 5-day confluence. Nothing
would error; the two tabs would simply describe different markets, which is
precisely the class of "definitions that could disagree" this codebase treats
as a defect.

So the horizon is set ONCE, here, and every dependent read is rebuilt from
the same window. A view picks a horizon; it never assembles one.

WHAT VARIES WITH THE HORIZON, AND WHAT DOES NOT
-----------------------------------------------
Varies (all are functions of the strength window):
    * rotation composite ROC, and therefore
    * Confluence Strength, Strength Rank and Score
    * Edge RS Excess, Expected Edge and Reward/Risk

Deliberately does NOT vary:
    * DIRECTION (RRG). It runs on its own ``RRG_LOOKBACK`` (50) because a
      slope fit needs a longer, steadier series than a momentum read. The
      architecture has always kept these dials separate.
    * SEASONALITY. A calendar-month effect measured over full history has no
      relationship to a trailing-days window.
    * BREADTH. A latest-bar count of members above their own SMA50.
    * TRUST / confidence. This is the gate product
      ``s_conf * d_gate * seasonal_gate * breadth_gate`` where ``s_conf``
      depends only on strength being PRESENT (non-NaN), never on its value.
      Trust is therefore horizon-invariant by construction, which is what
      makes it safe to compare an edge across horizons at all.

Because RRG, seasonality and breadth are horizon-independent, they are
computed ONCE by the caller and passed in, rather than rebuilt per horizon.
The only per-horizon cost is the rotation composite (the expensive part) plus
two cheap confluence passes and one edge pass.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.compute.confluence import ConfluenceResult, compute_confluence
from nimbus_v3.compute.equity_edge import EdgeResult, compute_equity_edge
from nimbus_v3.compute.industry_rotation import (
    RotationResult,
    compute_industry_rotation,
)
from nimbus_v3.compute.market_pulse_common import window_return_pct
from nimbus_v3.compute.market_pulse_config import (
    DEFAULT_EDGE_HORIZON,
    EDGE_HORIZONS,
)


@dataclass(frozen=True)
class HorizonView:
    """Every strength-dependent read, all built from ONE window."""

    horizon_days: int
    #: Composite industry ROC over this window — the shared RS anchor.
    rotation: RotationResult
    #: Confluence over the all-members seasonality grid.
    confluence_all: ConfluenceResult
    #: Confluence over the >=3y-members ("stable") grid — the default read,
    #: and the one the edge's trust is taken from.
    confluence_stable: ConfluenceResult
    #: Per-symbol edge, expressed over this same window.
    edge: EdgeResult

    def confluence(self, stable_only: bool) -> ConfluenceResult:
        """The confluence variant matching the >=3y-members toggle."""
        return self.confluence_stable if stable_only else self.confluence_all


@dataclass(frozen=True)
class HorizonSet:
    """All computed horizons. Pure data — lookup only, no behaviour."""

    views: tuple[HorizonView, ...]
    default_horizon: int

    @property
    def horizons(self) -> tuple[int, ...]:
        return tuple(sorted(v.horizon_days for v in self.views))

    def get(self, horizon: int) -> HorizonView | None:
        for v in self.views:
            if v.horizon_days == horizon:
                return v
        return None

    @property
    def default(self) -> HorizonView | None:
        """The default-horizon view, falling back to the shortest available
        so a partial set still renders rather than blanking the tabs."""
        v = self.get(self.default_horizon)
        if v is not None:
            return v
        return self.views[0] if self.views else None

    @property
    def has_data(self) -> bool:
        return bool(self.views)


def compute_horizon_views(
    members_by_industry: dict[str, list],
    panel: dict[str, pd.DataFrame],
    rrg,
    seasonality_all,
    seasonality_stable,
    *,
    benchmark_close: pd.Series | None = None,
    regime=None,
    month: int | None = None,
    breadth_by_industry: dict[str, float] | None = None,
    market_breadth: float | None = None,
    horizons: tuple[int, ...] = EDGE_HORIZONS,
    default_horizon: int = DEFAULT_EDGE_HORIZON,
    rotation_by_horizon: dict[int, RotationResult] | None = None,
    above_4h_by_symbol: dict[str, bool | None] | None = None,
) -> HorizonSet:
    """Build every strength-dependent read, for every horizon, coherently.

    The invariant this function exists to enforce: within a
    :class:`HorizonView`, the composite ROC, the benchmark return, the
    confluence strength and the edge's RS excess are ALL measured over the
    same number of trading days. A caller cannot pair a 20-day rotation with
    a 5-day benchmark, because it never supplies the two separately.

    Args:
        members_by_industry: industry -> member symbols.
        panel: ``{symbol: enriched_df}``.
        rrg: the RRG result (direction). Horizon-independent — computed once
            on ``RRG_LOOKBACK`` and reused across every view.
        seasonality_all: all-members seasonality grid. Horizon-independent.
        seasonality_stable: >=3y-members grid. Horizon-independent.
        benchmark_close: benchmark close series; the benchmark return is
            taken over each view's own window.
        regime, month, breadth_by_industry, market_breadth: passed straight
            through to :func:`compute_confluence`.
        horizons: windows to build, in trading days.
        default_horizon: the horizon views should show first.
        rotation_by_horizon: already-built rotations to reuse, keyed by
            lookback. Building industry composites is the expensive step, so
            a caller that already has one should hand it in.

    Returns:
        A :class:`HorizonSet` of frozen, self-consistent views.
    """
    supplied = dict(rotation_by_horizon or {})
    views: list[HorizonView] = []

    for h in sorted({int(x) for x in horizons}):
        rotation = supplied.get(h)
        if rotation is None:
            rotation = compute_industry_rotation(
                members_by_industry, panel, lookback=h)

        # The benchmark is measured over THIS view's window. Pairing it with
        # a rotation from another window is the mismatch this design makes
        # unreachable.
        bench_ret = (window_return_pct(benchmark_close, h)
                     if benchmark_close is not None else 0.0)

        conf_kwargs = dict(
            breadth_by_industry=breadth_by_industry,
            market_breadth=market_breadth,
            benchmark_return=bench_ret,
        )
        conf_all = compute_confluence(
            rotation, rrg, seasonality_all, regime, month, **conf_kwargs)
        conf_stable = compute_confluence(
            rotation, rrg, seasonality_stable, regime, month, **conf_kwargs)

        # Edge trusts the STABLE confluence — the same read the Confluence
        # tab shows by default — so trust values agree across the two tabs.
        # The 4h body-above flag is a per-symbol display fact independent of
        # horizon, so the same map feeds every view.
        edge = compute_equity_edge(
            conf_stable, rotation, members_by_industry, panel,
            benchmark_close, lookback=h,
            above_4h_by_symbol=above_4h_by_symbol)

        views.append(HorizonView(
            horizon_days=h,
            rotation=rotation,
            confluence_all=conf_all,
            confluence_stable=conf_stable,
            edge=edge,
        ))

    return HorizonSet(views=tuple(views),
                      default_horizon=int(default_horizon))
