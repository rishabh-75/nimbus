"""Tests for nimbus_v3.core.context — dataclass immutability + tz normalisation."""
from __future__ import annotations

import dataclasses

import pandas as pd
import pytest

from nimbus_v3.core.context import (
    ContextBundle,
    DealContext,
    EventContext,
    FilingContext,
    FlowContext,
    MarketContext,
    OptionsContext,
    SectorContext,
)
from nimbus_v3.core.types import (
    ExpiryRisk,
    FilingImpact,
    FlowSignal,
    RSRegime,
    VIXRegime,
)


def _market() -> MarketContext:
    return MarketContext(
        asof_date=pd.Timestamp("2024-05-01"),
        vix_value=18.5, vix_regime=VIXRegime.ELEVATED, vix_high_streak=0,
    )


def _sector() -> SectorContext:
    return SectorContext(
        asof_date=pd.Timestamp("2024-05-01"),
        symbol="HDFCBANK", sector_name="Banking", sector_type=None,
        rs_regime=RSRegime.NEUTRAL, rs_20d=0.0, realized_vol_20d=15.0,
    )


def test_every_context_is_frozen() -> None:
    m = _market()
    with pytest.raises(dataclasses.FrozenInstanceError):
        m.vix_value = 20.0  # type: ignore[misc]


def test_asof_date_coerced_to_timestamp() -> None:
    m = MarketContext(
        asof_date="2024-05-01",  # type: ignore[arg-type]
        vix_value=None, vix_regime=None, vix_high_streak=0,
    )
    assert isinstance(m.asof_date, pd.Timestamp)


def test_context_bundle_requires_market_and_sector_only() -> None:
    bundle = ContextBundle(
        symbol="RELIANCE",
        asof_date=pd.Timestamp("2024-05-01"),
        market=_market(),
        sector=_sector(),
    )
    assert bundle.options is None
    assert bundle.filing is None
    assert bundle.flow is None
    assert bundle.event is None
    assert bundle.deal is None
    assert bundle.notes == ()


def test_context_bundle_with_all_fields() -> None:
    bundle = ContextBundle(
        symbol="RELIANCE",
        asof_date=pd.Timestamp("2024-05-01"),
        market=_market(),
        sector=_sector(),
        options=OptionsContext(
            asof_date=pd.Timestamp("2024-05-01"), symbol="RELIANCE",
            spot=2500.0, dte=10, max_pain=2500.0,
            support_wall=None, resistance_wall=None,
            pct_to_support=None, pct_to_resistance=None,
            net_gex=None, hvl=None, gex_regime=None, pcr_oi=None,
            iv_atm=None, ivr=None, expiry_risk=ExpiryRisk.LOW,
        ),
        filing=FilingContext(
            asof_date=pd.Timestamp("2024-05-01"), symbol="RELIANCE",
            latest_impact=FilingImpact.NONE, is_trap=False,
            days_since_latest=None, latest_headline=None,
        ),
        flow=FlowContext(
            asof_date=pd.Timestamp("2024-05-01"),
            fii_net_cr=100.0, dii_net_cr=50.0,
            fii_5d_z=None, dii_5d_z=None,
            signal=FlowSignal.INSTITUTIONAL_TAILWIND,
        ),
        event=EventContext(
            asof_date=pd.Timestamp("2024-05-01"), symbol="RELIANCE",
            earnings_blackout=False, days_to_earnings=14,
            upcoming_action_count_14d=0,
        ),
        deal=DealContext(
            asof_date=pd.Timestamp("2024-05-01"), symbol="RELIANCE",
            block_count_30d=1, bulk_count_30d=0,
            sast_count_30d=0, insider_count_30d=2,
            net_insider_shares_30d=5000.0,
        ),
    )
    assert bundle.options is not None
    assert bundle.flow is not None


def test_sector_context_rs_regime_is_enum() -> None:
    s = _sector()
    assert isinstance(s.rs_regime, RSRegime)
