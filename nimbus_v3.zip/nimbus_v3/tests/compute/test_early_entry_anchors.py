"""Regression anchors for the band-ride + Early-Entry system.

Replaces the retired phase/composite-score anchors (AWL=RETEST 40.9,
etc. — see docs/retired/002). Two invariants guard against silent drift:

1. **Body-above streaks** on the reference parquets — pins the canonical
   band-geometry definition. If band_ride's body_above_band logic or the
   enrichment's upper-band column changes, these move.

2. **Frozen Early-Entry scores** on a fixed synthetic cohort — pins the
   cohort-relative scorer (weights, axis transforms, participation). The
   synthetic frames are deterministic so the scores are reproducible;
   any change to the scoring model will shift them and trip this test,
   forcing a conscious re-baseline.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.band_ride import body_above_streak, last_body_above
from nimbus_v3.compute.early_entry import (
    EarlyEntryFeatures,
    score_cohort,
)
from nimbus_v3.compute.engine import StrategyComputeEngine

_UPLOADS = "/mnt/user-data/uploads"

# Verified body-above streaks on the reference parquets (2y window,
# 500 bars, 2024-04-29 → 2026-05-06).
_STREAK_ANCHORS = {
    "AWL": 2,
    "CLEAN": 16,
    "CIPLA": 8,
    "SUNPHARMA": 5,
}


@pytest.mark.parametrize("symbol,expected", _STREAK_ANCHORS.items())
def test_body_above_streak_anchor(symbol, expected):
    eng = StrategyComputeEngine()
    df = eng.enrich(pd.read_parquet(f"{_UPLOADS}/{symbol}.parquet"), symbol)
    assert body_above_streak(df) == expected
    assert last_body_above(df) is True


# ── Frozen Early-Entry scores on a fixed synthetic cohort ────────────────────

def _synthetic_cohort() -> list[EarlyEntryFeatures]:
    """A deterministic cohort mirroring the validated screenshot set.

    These mirror the real ranking we validated (JIOFIN/SUZLON top,
    KALYANKJIL/PETRONET bottom) but as hand-fixed feature vectors so the
    frozen scores below never depend on parquet data.
    """
    # sym, streak, recent_return%, adtv₹, bbw
    data = [
        ("SUZLON",     2,  9.66, 6338e6,  6.14),
        ("JIOFIN",     2,  7.05, 2719e6,  3.92),
        ("NETWEB",     2, 21.19, 12820e6, 16.96),
        ("360ONE",     3,  7.25, 1049e6,  5.32),
        ("PETRONET",   4, 10.84,  939e6,  6.84),
        ("KALYANKJIL", 3, 15.76, 3612e6,  8.02),
    ]
    return [
        EarlyEntryFeatures(sym, st, r, a, b, industry=None)
        for sym, st, r, a, b in data
    ]


# Frozen outputs — regenerate consciously if the scoring model changes.
_FROZEN_SCORES = {
    "SUZLON": 80.4,
    "JIOFIN": 79.1,
    "NETWEB": 59.5,
    "360ONE": 49.7,
    "KALYANKJIL": 43.7,
    "PETRONET": 32.0,
}


def test_early_entry_frozen_scores():
    feats = _synthetic_cohort()
    scores = score_cohort(feats)
    for sym, expected in _FROZEN_SCORES.items():
        assert sym in scores
        assert scores[sym] == pytest.approx(expected, abs=0.5), (
            f"{sym}: {scores[sym]:.1f} != frozen {expected}"
        )


def test_early_entry_ranking_order():
    """The ranking order is the load-bearing property — pin it
    independently of the absolute values."""
    feats = _synthetic_cohort()
    scores = score_cohort(feats)
    order = [s for s, _ in sorted(scores.items(), key=lambda kv: -kv[1])]
    # SUZLON edges JIOFIN at the top — both streak-2 and un-extended, but
    # SUZLON is more liquid (6,338M vs 2,719M), which matters at the
    # liquidity-22 weighting. PETRONET (streak-4, extended) stays last.
    assert order[0] == "SUZLON"
    assert order[1] == "JIOFIN"
    assert order[-1] == "PETRONET"
