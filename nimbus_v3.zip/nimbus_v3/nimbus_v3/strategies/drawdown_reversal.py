"""nimbus_v3.strategies.drawdown_reversal — research-tier counter-cyclical setup.

⚠ **Research-only signal** — emits trades for SignalTracker but does
not contribute to production conviction grades in v3.0.

Validation summary
──────────────────
Round 1 (no regime filter) on fresh data (April 2026):
- Train (2020-03 → 2024-12): n=7,268, lift −0.07pp, t=−0.84
- Test (2025-01 → 2026-04): n=364, lift +0.78pp, **t=+2.17**
- OOS decay: **+0.85pp** (negative train, positive test — counter-cyclical
  by construction, and the test period included a drawdown phase)

This is the most unusual candidate in the normal-regime study: it
produced negative lift in the mostly-benign 2020-2024 training period
but positive lift in the adverse 2025 OOS period. The "edge" is the
strategy specifically firing during stock-specific drawdowns with
early reversal signs — exactly when the market baseline is weakest.

Round 1 (no regime filter) is the better variant. Round 2 (requiring
market index > 200-SMA) cuts the sample to n=208 and makes the lift
negative. This strategy works BETTER when the broad market is weak.

Entry gates
───────────
- ``state.dd_from_high_50 < -8``   — drawn down ≥8% from 50-bar high
- ``state.green_streak >= 2``      — early reversal signs (2+ up days)
- ``state.mfi_14 > 40``            — money flow not completely exhausted
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


@dataclass(frozen=True)
class DrawdownReversalParams:
    dd_from_high_50_max: float = -8.0    # drawdown threshold (negative)
    green_streak_min: int = 2
    mfi_14_min: float = 40.0


class DrawdownReversalStrategy:
    """Counter-cyclical drawdown-reversal setup. Research-tier.

    Rejects ETFs.
    """

    name: str = "DrawdownReversal"
    setup_type: SetupType = SetupType.DRAWDOWN_REVERSAL
    priority: int = 35     # between MR and Ride — counter-cyclical,
                            # relevant even when MR's VIX gate doesn't fire
    production_weight: float = 0.0   # research-tier (t=+2.17 OOS counter-cyclical)

    def __init__(
        self, params: DrawdownReversalParams = DrawdownReversalParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — state-driven
    ) -> StrategySignal | None:
        if state.dd_from_high_50 >= self._p.dd_from_high_50_max:
            return None
        if state.green_streak < self._p.green_streak_min:
            return None
        if state.mfi_14 <= self._p.mfi_14_min:
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "dd_from_high_50": state.dd_from_high_50,
                "green_streak": state.green_streak,
                "mfi_14": state.mfi_14,
            },
        )
