"""nimbus_v3.core.signal_state — the unified per-bar technical state contract.

``SignalState`` is the single typed object that every downstream layer reads.
It is the output of ``compute/engine.py::StrategyComputeEngine.extract_state``
and the input to strategies, context providers (where they need per-bar
technical features), and the conviction engine.

Design principles
─────────────────
- **Frozen**: once constructed, a ``SignalState`` never changes. This makes it
  safe to share across threads and store in sets / use as dict keys.
- **Comprehensive**: includes every indicator that any current or planned rule
  references. Adding a field later means re-running sweeps, so we err on the
  side of inclusion.
- **Self-describing**: all fields are documented. The dataclass is the
  authoritative schema — ``docs/GRADE_FORMULA.md`` references these field names
  verbatim.
- **No external context**: ``SignalState`` carries only per-symbol, per-bar
  technicals derived from OHLCV. VIX, sector, options, flow, and filings are
  carried separately on ``ContextBundle`` (see ``core/context.py``). This
  separation is what makes the compute layer pure and cacheable.
- **No behaviour**: no methods other than what dataclass gives us. Helpers
  that operate on a state belong in strategies, contexts, or formula
  contributions — not here.

Warmup / data sufficiency
─────────────────────────
The longest-lookback field (``sma_200``, ``bbw_20_2s_pctl``) requires ~220
bars of prior data. Bars before that warmup have NaN in those fields and
``data_sufficient=False``. Strategies and formula contributions MUST check
``data_sufficient`` before trusting any field.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class SignalState:
    """Per-(symbol, bar) technical state. Single source of truth for
    downstream technical reads.

    Field groups are laid out to match the enrichment order in
    ``compute/engine.py::StrategyComputeEngine.enrich`` for readability.
    All numeric fields are native ``float`` (not ``np.float64``) to avoid
    subtle dtype comparison bugs in tests and fixtures.
    """

    # ── Identity ─────────────────────────────────────────────────────────
    symbol: str
    bar_date: pd.Timestamp
    bar_index: int

    # ── Price ────────────────────────────────────────────────────────────
    open: float
    high: float
    low: float
    close: float
    volume: float

    # ── Moving averages ──────────────────────────────────────────────────
    sma_10: float
    sma_20: float
    sma_50: float
    sma_200: float

    # ── Williams %R (multiple periods for cross-strategy use) ────────────
    wr_14: float
    wr_20: float
    wr_30: float
    wr_50: float

    # ── RSI (classic Wilder 14) ──────────────────────────────────────────
    rsi_14: float

    # ── MFI (Money Flow Index) ───────────────────────────────────────────
    mfi_14: float
    mfi_slope_3: float

    # ── ADX (trend strength) ─────────────────────────────────────────────
    adx_14: float

    # ── ATR (volatility; used for stop sizing by strategies) ─────────────
    atr_14: float
    atr_14_pct: float

    # ── Bollinger Bands: 1σ envelope (entries) ───────────────────────────
    bb_20_1s_upper: float
    bb_20_1s_mid: float
    bb_20_1s_lower: float
    bb_20_1s_pct: float

    # ── Bollinger Bands: 2σ envelope (squeeze detection) ─────────────────
    bb_20_2s_upper: float
    bb_20_2s_lower: float
    bbw_20_2s: float
    bbw_20_2s_slope: float
    bbw_20_2s_pctl: float

    # ── Position vs. moving averages ─────────────────────────────────────
    pct_from_sma_20: float
    pct_from_sma_50: float
    pct_from_sma_200: float
    above_sma_20: bool
    above_sma_50: bool
    above_sma_200: bool

    # ── Drawdown and streak context ──────────────────────────────────────
    dd_from_high_20: float
    dd_from_high_50: float
    red_streak: int
    green_streak: int

    # ── Volume context ───────────────────────────────────────────────────
    vol_ratio_20: float

    # ── Rate of change ───────────────────────────────────────────────────
    roc_5: float
    roc_10: float
    roc_20: float

    # ── Data sufficiency flag ────────────────────────────────────────────
    data_sufficient: bool
