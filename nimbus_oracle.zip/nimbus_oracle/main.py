"""
NIMBUS · Emerald Slate v5 · Qt Desktop Dashboard
─────────────────────────────────────────────────
Entry point: logging → pyqtgraph config → splash → imports → MainWindow.

Logging is configured FIRST (before any other imports that might log).
pyqtgraph global config is set BEFORE any ui/ imports (roadmap §0.1).
Splash screen shows BEFORE heavy ui/ imports so the user sees feedback.
"""

from __future__ import annotations

import os
import sys
import logging
import time
from logging.handlers import RotatingFileHandler

# ── Logging (roadmap §0.3 — first 10 lines after imports) ────────────────────
_log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(_log_dir, exist_ok=True)
_log_path = os.path.join(_log_dir, "nimbus.log")

handler = RotatingFileHandler(_log_path, maxBytes=5 * 1024 * 1024, backupCount=3)
logging.basicConfig(
    handlers=[handler, logging.StreamHandler(sys.stdout)],
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("nimbus")
logger.info("NIMBUS starting — log path: %s", _log_path)

# ── pyqtgraph global config (BEFORE any ui/ imports) ─────────────────────────
import pyqtgraph as pg

pg.setConfigOptions(
    background="#0D1117",  # SURFACE
    foreground="#64748B",  # MUTED
    antialias=True,
)

# ── Qt imports (lightweight — no ui/ modules yet) ────────────────────────────
from PyQt6.QtWidgets import QApplication, QSplashScreen
from PyQt6.QtGui import QFontDatabase, QFont, QPixmap, QPainter, QColor
from PyQt6.QtCore import Qt, QTimer, QEventLoop

# NOTE: MainWindow is imported INSIDE main() — after splash is visible.
# The import triggers all ui/ module loading which is the heavy phase.


def _load_fonts():
    """Load bundled JetBrains Mono from assets/ via QFontDatabase."""
    assets_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
    loaded = 0
    for fname in ("JetBrainsMono-Regular.ttf", "JetBrainsMono-Bold.ttf"):
        path = os.path.join(assets_dir, fname)
        if os.path.exists(path):
            fid = QFontDatabase.addApplicationFont(path)
            if fid >= 0:
                families = QFontDatabase.applicationFontFamilies(fid)
                logger.info("Loaded font: %s → %s", fname, families)
                loaded += 1
            else:
                logger.warning("Failed to load font: %s", path)
        else:
            logger.info("Font file not found (optional): %s", path)
    return loaded


def _show_splash(app, font_name: str) -> QSplashScreen:
    """Create and show startup splash. Returns splash for later close."""
    pixmap = QPixmap(420, 140)
    pixmap.fill(QColor("#0D1117"))
    painter = QPainter(pixmap)
    painter.setPen(QColor("#10B981"))
    painter.setFont(QFont(font_name, 18))
    painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "NIMBUS")
    painter.setPen(QColor("#64748B"))
    painter.setFont(QFont(font_name, 9))
    painter.drawText(
        pixmap.rect().adjusted(0, 50, 0, 0),
        Qt.AlignmentFlag.AlignCenter,
        "Loading..."
    )
    painter.end()

    splash = QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    splash.show()
    splash.raise_()
    splash.activateWindow()
    splash.repaint()
    app.processEvents()
    app.processEvents()  # double pump — macOS needs extra event processing
    return splash


def _splash_msg(splash, app, msg: str):
    """Update splash status text."""
    splash.showMessage(
        f"  {msg}",
        Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft,
        QColor("#64748B"),
    )
    splash.repaint()
    app.processEvents()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("NIMBUS")
    app.setOrganizationName("NIMBUS")

    # ── Phase 0: Fonts ────────────────────────────────────────────────────
    _load_fonts()
    mono_available = "JetBrains Mono" in QFontDatabase.families()
    if mono_available:
        logger.info("JetBrains Mono: available ✓")
    else:
        logger.warning("JetBrains Mono: NOT available")
    font_name = "JetBrains Mono" if mono_available else "Courier"

    # ── Phase 1: Splash (visible BEFORE any heavy imports) ────────────────
    splash = _show_splash(app, font_name)
    t0 = time.time()

    # ── Phase 2: Core modules ─────────────────────────────────────────────
    _splash_msg(splash, app, "Loading modules...")
    try:
        from modules import analytics, indicators, data, scanner
        logger.info("modules/ imported successfully ✓")
    except Exception as exc:
        logger.error("modules/ import failed: %s", exc)

    # ── Phase 3: NSE session warm ─────────────────────────────────────────
    _splash_msg(splash, app, "Connecting to NSE...")
    try:
        from modules.nse_client import init_shared_client
        init_shared_client()
        logger.info("NSE session: warmed ✓")
    except Exception as exc:
        logger.warning("NSE session warm failed: %s (will retry lazily)", exc)

    # ── Phase 4: UI modules (heavy — all tabs, widgets, chart) ────────────
    _splash_msg(splash, app, "Building interface...")
    from ui.main_window import MainWindow

    # ── Ensure splash visible for at least 2s total ───────────────────────
    elapsed = time.time() - t0
    remaining = max(0, 2.0 - elapsed)
    if remaining > 0:
        loop = QEventLoop()
        QTimer.singleShot(int(remaining * 1000), loop.quit)
        loop.exec()

    splash.close()

    # ── Phase 5: Launch ───────────────────────────────────────────────────
    window = MainWindow()
    window.show()
    logger.info("MainWindow shown — Phase 0 gate open")

    # ── Phase 6: Auto-resolve mature signals (background) ─────────────────
    # Runs in a daemon thread so it doesn't block the UI. Resolves any
    # signals that have aged into eligibility (≥5 trading days) and updates
    # the strategy regime detector when complete.
    def _auto_resolve():
        import threading, time as _t
        # Small delay so the UI fully settles before we hit the network
        _t.sleep(3.0)
        try:
            from run_resolve import resolve_mature_signals, resolve_mature_ride_signals
            n_mr = resolve_mature_signals()
            n_ride = resolve_mature_ride_signals()
            total = n_mr + n_ride
            if total:
                logger.info(
                    "Auto-resolve: %d MR + %d Ride = %d signals resolved on startup",
                    n_mr, n_ride, total,
                )
                # Refresh the regime label so newly-resolved trades show up
                try:
                    window._update_strategy_regime()
                except Exception:
                    pass
            else:
                logger.info("Auto-resolve: no mature signals to resolve")
        except Exception as exc:
            logger.warning("Auto-resolve failed (non-fatal): %s", exc)

    import threading
    threading.Thread(target=_auto_resolve, daemon=True, name="AutoResolve").start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
