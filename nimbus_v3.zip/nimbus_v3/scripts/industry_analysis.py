"""scripts/industry_analysis.py — NIFTY 200 industry-level analysis.

Fetches NIFTY 200 constituents directly from NSE, uses each stock's
**raw NSE-reported industry** (no mapping, no clubbing), fetches
OHLCV via yfinance, then builds equal-weighted daily return indices
per industry and analyzes:

- **Trend**: SMA20/SMA50 position, ADX proxy
- **Inflow**: cumulative volume change (20d vs. prior 20d)
- **Collective volume change**: rolling volume ratio
- **ROC**: 5d / 10d / 20d rate of change on the EW index

Output: sorted tables printed to console. Industries with <3 members
are excluded (too thin for a meaningful index).

Usage:
    python scripts/industry_analysis.py
    python scripts/industry_analysis.py --min-members 5
    python scripts/industry_analysis.py --top 15
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

# ── Project root on path ────────────────────────────────────────────────────
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE.parent))

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.price_loader import PriceLoader


# ══════════════════════════════════════════════════════════════════════════════
# 1. Load industry DB (built by build_industry_db.py)
# ══════════════════════════════════════════════════════════════════════════════

_CACHE_DIR = Path("data/cache/equity_price")
_INDUSTRY_DB_PATH = Path("data/nifty500_industry_db.json")


def load_industry_db(
    db_path: Path = _INDUSTRY_DB_PATH,
    group_by: str = "industryInfo",
) -> list[tuple[str, str]]:
    """Load [(symbol, industry_group), ...] from the industry DB.

    ``group_by`` selects which classification level to use for grouping:
      - "macro"         (coarsest: ~8 groups)
      - "sector"        (~20 groups)
      - "industryInfo"  (~40 groups, default)
      - "basicIndustry" (finest: ~80 groups)

    The DB is built by ``scripts/build_industry_db.py``. If it doesn't
    exist, prints instructions and returns empty.
    """
    if not db_path.exists():
        print(
            f"ERROR: Industry DB not found at {db_path}\n"
            f"  Run this first:\n"
            f"    python scripts/build_industry_db.py\n"
        )
        return []

    import json
    db = json.loads(db_path.read_text())
    pairs = []
    for sym, entry in db.items():
        group = entry.get(group_by) or ""
        if group:
            pairs.append((sym, group))
    print(f"Industry DB: {len(pairs)} symbols loaded (grouped by {group_by})")
    return pairs


# ══════════════════════════════════════════════════════════════════════════════
# 2. Fetch price data
# ══════════════════════════════════════════════════════════════════════════════


def fetch_prices(
    symbols: list[str], *, years: int = 2,
) -> dict[str, pd.DataFrame]:
    """Fetch OHLCV for all symbols. Caches to parquet."""
    cache = ParquetCache(base_dir=_CACHE_DIR)
    loader = PriceLoader(cache, default_years=years, yfinance_suffix=".NS")

    panel: dict[str, pd.DataFrame] = {}
    n = len(symbols)
    needs = sum(1 for s in symbols if not cache.exists(s))
    if needs:
        print(
            f"Fetching prices: {needs}/{n} symbols not cached "
            f"(~{needs * 2}s one-time)…"
        )

    for i, sym in enumerate(symbols, 1):
        df = loader.load(sym)
        if df.empty or len(df) < 100:
            continue
        panel[sym] = df
        if i % 50 == 0:
            print(f"  [{i}/{n}] loaded…")

    print(f"  → {len(panel)}/{n} symbols loaded with sufficient data")
    return panel


# ══════════════════════════════════════════════════════════════════════════════
# 3. Build equal-weighted industry indices
# ══════════════════════════════════════════════════════════════════════════════

def build_industry_indices(
    constituents: list[tuple[str, str]],
    panel: dict[str, pd.DataFrame],
    *,
    min_members: int = 3,
) -> dict[str, dict]:
    """Build one EW index per NSE industry.

    Returns {industry_name: {
        "members": [sym, ...],
        "index": pd.DataFrame with columns [Close, Volume, Return],
        "member_count": int,
    }}

    Industries with fewer than ``min_members`` stocks with data are
    dropped.
    """
    # Group symbols by raw industry.
    industry_map: dict[str, list[str]] = {}
    for sym, ind in constituents:
        if not ind:
            continue
        industry_map.setdefault(ind, []).append(sym)

    results: dict[str, dict] = {}
    for industry, members in sorted(industry_map.items()):
        # Filter to members we actually have price data for.
        valid = [m for m in members if m in panel]
        if len(valid) < min_members:
            continue

        # Align all members to a common date index.
        closes = pd.DataFrame({
            sym: panel[sym]["Close"] for sym in valid
        })
        volumes = pd.DataFrame({
            sym: panel[sym]["Volume"] for sym in valid
        })

        # Forward-fill gaps (holidays differ per stock), then drop
        # leading NaN rows where some stocks don't exist yet.
        closes = closes.ffill().dropna(how="all")
        volumes = volumes.ffill().fillna(0).loc[closes.index]

        if len(closes) < 100:
            continue

        # Equal-weighted daily return → cumulative index.
        daily_returns = closes.pct_change()
        ew_return = daily_returns.mean(axis=1)     # equal-weight avg
        ew_index = (1 + ew_return).cumprod() * 100   # base = 100

        # Equal-weighted volume (sum across members per day).
        total_volume = volumes.sum(axis=1)

        idx = pd.DataFrame({
            "Close": ew_index,
            "Volume": total_volume,
            "Return": ew_return,
        }).dropna()

        results[industry] = {
            "members": valid,
            "index": idx,
            "member_count": len(valid),
        }

    print(f"  → {len(results)} industries with ≥{min_members} members")
    return results


# ══════════════════════════════════════════════════════════════════════════════
# 4. Analyze each industry index
# ══════════════════════════════════════════════════════════════════════════════

def analyze_industries(
    industries: dict[str, dict],
) -> pd.DataFrame:
    """Compute trend, volume change, and ROC for each industry index.

    Returns a DataFrame with one row per industry, sorted by a
    composite score (trend + momentum + inflow).
    """
    rows = []
    for name, data in industries.items():
        idx = data["index"]
        n = len(idx)
        if n < 50:
            continue

        close = idx["Close"]
        volume = idx["Volume"]

        # ── Trend ─────────────────────────────────────────────────────
        sma20 = close.rolling(20).mean()
        sma50 = close.rolling(50).mean()
        last_close = float(close.iloc[-1])
        last_sma20 = float(sma20.iloc[-1]) if not pd.isna(sma20.iloc[-1]) else last_close
        last_sma50 = float(sma50.iloc[-1]) if not pd.isna(sma50.iloc[-1]) else last_close
        pct_vs_sma20 = (last_close / last_sma20 - 1) * 100
        pct_vs_sma50 = (last_close / last_sma50 - 1) * 100
        above_sma20 = last_close > last_sma20
        above_sma50 = last_close > last_sma50

        # SMA20 slope (is it rising?)
        sma20_slope = (
            (float(sma20.iloc[-1]) - float(sma20.iloc[-5])) / float(sma20.iloc[-5]) * 100
            if not pd.isna(sma20.iloc[-5]) and float(sma20.iloc[-5]) > 0 else 0.0
        )

        # ── Volume inflow (20d vs prior 20d) ─────────────────────────
        vol_20d = float(volume.iloc[-20:].mean()) if n >= 20 else 0.0
        vol_prior_20d = float(volume.iloc[-40:-20].mean()) if n >= 40 else vol_20d
        vol_change_pct = (
            (vol_20d / vol_prior_20d - 1) * 100
            if vol_prior_20d > 0 else 0.0
        )

        # ── Volume ratio (today vs 20d avg) ──────────────────────────
        vol_ratio = (
            float(volume.iloc[-1]) / vol_20d
            if vol_20d > 0 else 0.0
        )

        # ── ROC ──────────────────────────────────────────────────────
        roc_5 = (
            (last_close / float(close.iloc[-6]) - 1) * 100
            if n >= 6 and float(close.iloc[-6]) > 0 else 0.0
        )
        roc_10 = (
            (last_close / float(close.iloc[-11]) - 1) * 100
            if n >= 11 and float(close.iloc[-11]) > 0 else 0.0
        )
        roc_20 = (
            (last_close / float(close.iloc[-21]) - 1) * 100
            if n >= 21 and float(close.iloc[-21]) > 0 else 0.0
        )

        # ── Composite score for sorting ──────────────────────────────
        # Positive trend + positive momentum + volume inflow = interesting.
        trend_score = (
            (1.0 if above_sma20 else -1.0) +
            (1.0 if above_sma50 else -1.0) +
            min(max(sma20_slope, -3), 3) / 3.0    # normalise
        )
        momentum_score = (roc_5 + roc_10 + roc_20) / 3.0
        inflow_score = min(max(vol_change_pct, -50), 50) / 50.0
        composite = trend_score + momentum_score * 0.5 + inflow_score

        rows.append({
            "Industry": name,
            "Members": data["member_count"],
            "Close": round(last_close, 2),
            "vs_SMA20": round(pct_vs_sma20, 2),
            "vs_SMA50": round(pct_vs_sma50, 2),
            "SMA20_slope": round(sma20_slope, 2),
            "Above_SMA20": "✓" if above_sma20 else "✗",
            "Above_SMA50": "✓" if above_sma50 else "✗",
            "Vol_chg_20d%": round(vol_change_pct, 1),
            "Vol_ratio": round(vol_ratio, 2),
            "ROC_5d": round(roc_5, 2),
            "ROC_10d": round(roc_10, 2),
            "ROC_20d": round(roc_20, 2),
            "Composite": round(composite, 2),
        })

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    return df.sort_values("Composite", ascending=False).reset_index(drop=True)


# ══════════════════════════════════════════════════════════════════════════════
# 5. Pretty print
# ══════════════════════════════════════════════════════════════════════════════

def print_results(df: pd.DataFrame, *, top: int | None = None) -> None:
    if df.empty:
        print("No industries to display.")
        return

    if top is not None:
        df = df.head(top)

    # Trend table.
    print("\n" + "═" * 110)
    print("  NIFTY 200 INDUSTRY INDEX ANALYSIS — TREND & MOMENTUM")
    print("═" * 110)
    trend_cols = [
        "Industry", "Members", "vs_SMA20", "vs_SMA50", "SMA20_slope",
        "Above_SMA20", "Above_SMA50", "ROC_5d", "ROC_10d", "ROC_20d",
    ]
    print(df[trend_cols].to_string(index=False))

    # Volume table.
    print("\n" + "═" * 80)
    print("  VOLUME INFLOW & CHANGE")
    print("═" * 80)
    vol_cols = [
        "Industry", "Members", "Vol_chg_20d%", "Vol_ratio",
        "ROC_5d", "Composite",
    ]
    print(df[vol_cols].to_string(index=False))

    # Summary.
    rising_sma = df[df["Above_SMA20"] == "✓"]
    strong = df[(df["Above_SMA20"] == "✓") & (df["Above_SMA50"] == "✓") & (df["ROC_20d"] > 0)]
    weak = df[(df["Above_SMA20"] == "✗") & (df["Above_SMA50"] == "✗")]

    print("\n" + "─" * 60)
    print(f"  Industries above SMA20: {len(rising_sma)} / {len(df)}")
    print(f"  Strong trend (above both SMAs + positive ROC20): {len(strong)}")
    print(f"  Weak (below both SMAs): {len(weak)}")

    if not strong.empty:
        print(f"\n  TOP TRENDING:")
        for _, row in strong.head(5).iterrows():
            print(
                f"    {row['Industry']:<30s}  ROC20 {row['ROC_20d']:+6.2f}%  "
                f"Vol_chg {row['Vol_chg_20d%']:+6.1f}%  "
                f"SMA20_slope {row['SMA20_slope']:+.2f}%"
            )

    if not weak.empty:
        print(f"\n  WEAKEST:")
        for _, row in weak.tail(5).iterrows():
            print(
                f"    {row['Industry']:<30s}  ROC20 {row['ROC_20d']:+6.2f}%  "
                f"Vol_chg {row['Vol_chg_20d%']:+6.1f}%"
            )

    # Volume inflow leaders.
    vol_leaders = df.nlargest(5, "Vol_chg_20d%")
    print(f"\n  VOLUME INFLOW LEADERS (20d vs prior 20d):")
    for _, row in vol_leaders.iterrows():
        print(
            f"    {row['Industry']:<30s}  Vol_chg {row['Vol_chg_20d%']:+6.1f}%  "
            f"Members {row['Members']}"
        )

    print()


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Industry-level trend & volume analysis using the "
                    "NIFTY 500 industry database.",
    )
    parser.add_argument(
        "--min-members", type=int, default=3,
        help="Minimum stocks per industry group to include (default 3).",
    )
    parser.add_argument(
        "--top", type=int, default=None,
        help="Only show top N industries by composite score.",
    )
    parser.add_argument(
        "--group-by", type=str, default="industryInfo",
        choices=["macro", "sector", "industryInfo", "basicIndustry"],
        help="Classification level to group by (default: industryInfo).",
    )
    parser.add_argument(
        "--db", type=str,
        default=str(_INDUSTRY_DB_PATH),
        help="Path to the industry DB JSON (built by build_industry_db.py).",
    )
    args = parser.parse_args()

    t0 = time.perf_counter()

    # 1. Load DB.
    constituents = load_industry_db(
        db_path=Path(args.db), group_by=args.group_by,
    )
    if not constituents:
        return 1

    # Show the group distribution.
    group_counts: dict[str, int] = {}
    for _, grp in constituents:
        group_counts[grp] = group_counts.get(grp, 0) + 1
    print(f"\n  Groups ({args.group_by}): {len(group_counts)}")
    for grp, cnt in sorted(group_counts.items(), key=lambda x: -x[1])[:10]:
        print(f"    {grp:<40s}  {cnt} stocks")
    if len(group_counts) > 10:
        print(f"    … and {len(group_counts) - 10} more")

    # 2. Prices.
    symbols = [sym for sym, _ in constituents]
    panel = fetch_prices(symbols)
    if not panel:
        print("No price data loaded — yfinance unreachable?")
        return 1

    # 3. Industry indices.
    print(f"\nBuilding equal-weighted indices (grouped by {args.group_by})…")
    industries = build_industry_indices(
        constituents, panel, min_members=args.min_members,
    )
    if not industries:
        print("No groups met the minimum-members threshold.")
        return 1

    # 4. Analyze.
    print("Analyzing trend, volume, ROC…")
    results = analyze_industries(industries)

    # 5. Output.
    print_results(results, top=args.top)

    # 6. Export.
    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("data/research")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"industry_trend_{args.group_by}_{ts}.csv"
    results.to_csv(out_path, index=False)
    print(f"  Exported → {out_path}")

    elapsed = time.perf_counter() - t0
    print(f"  Total time: {elapsed:.1f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
