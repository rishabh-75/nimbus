# NIMBUS v3 — Architecture Roadmap

> **HISTORICAL DOCUMENT — pre-slim-refactor (2026-05).** This file
> captures the original five-strategy / scanner / conviction
> architecture. The terminal has since been narrowed to a
> ride-strategy-only profile: strategies, conviction, scanner,
> tracking, macro, and the conservative/aggressive mode toggle were
> all deleted. See `CHANGES.md` for the slim profile, `README.md`
> for the current shape, and `V3_VS_ORACLE_GAP_ANALYSIS.md` for the
> revised posture. Use this document only as a reference for design
> decisions made during the pre-refactor era.
>
> **Research practice:** findings + methodology for every research
> effort live in `docs/research/` (see its `README.md`), not as
> one-off scripts. Capture the finding, keep the reusable code
> snippet, delete the script.

---

**Date:** 2026-04-13
**Status:** Draft for review. No code until approved.
**Scope:** Ground-up rebuild of the NIMBUS trading terminal. Isolated from `nimbus_oracle` and `nimbus_v2`. Consolidates the compute/research discipline of v2 with the operational surface (UI, options analytics, filings, flows) of oracle — reconciled under a single conviction pipeline.
**Out of scope:** Execution/order routing, cost modelling, position-level risk, broker integration. Deferred.

---

## Table of contents

1. [Why a v3, and what's different](#1-why-a-v3-and-whats-different)
2. [Guiding principles](#2-guiding-principles)
3. [What's kept, what's dropped, what's new](#3-whats-kept-whats-dropped-whats-new)
4. [System architecture overview](#4-system-architecture-overview)
5. [Package layout](#5-package-layout)
6. [The unified pipeline: bar → conviction](#6-the-unified-pipeline-bar--conviction)
7. [Single source of truth: `ConvictionEngine`](#7-single-source-of-truth-convictionengine)
8. [Context providers](#8-context-providers)
9. [Strategy plugin model](#9-strategy-plugin-model)
10. [Event bus and UI decoupling](#10-event-bus-and-ui-decoupling)
11. [Research / live parity](#11-research--live-parity)
12. [Data layer: caching, sessions, rate limiting](#12-data-layer-caching-sessions-rate-limiting)
13. [UI layer: tabs, panels, responsibilities](#13-ui-layer-tabs-panels-responsibilities)
14. [SOLID mapping and design patterns](#14-solid-mapping-and-design-patterns)
15. [Test strategy](#15-test-strategy)
16. [Phased build plan](#16-phased-build-plan)
17. [Risk register](#17-risk-register)
18. [Decisions locked](#18-decisions-locked)
19. [Phase 0 readiness checklist](#19-phase-0-readiness-checklist)

---

## 1. Why a v3, and what's different

v2 solved the compute-layer problem: one `SignalState`, one set of canonical indicators, one compute engine. It was deliberately scoped to entry research and never crossed into live trading, exits, sizing, or UI.

`nimbus_oracle` is a functioning terminal, but its scoring pipeline is fragmented. `dual_mode.py` grades mean-reversion. `signal_engine.py` layers IVR / RS / FII-DII bonuses. `setup_classifier.py` emits setup types. `scanner.py` computes its own top-level viability. `conviction.py` does another thing. UI panels read a blend of all of them. When a number on the dashboard is wrong, there is no single place to go to correct it.

**v3's central bet:** every number displayed anywhere — on the dashboard, in a backtest report, in a CLI print, in a persisted signal record — is the output of one function. That function takes a `SignalState`, a set of contexts, and a strategy identity; it returns a `Conviction`. Everything downstream is a read, not a recomputation.

This is the only structural change from v2 that matters. The rest of v3 is:
- extending v2's clean-architecture discipline to the full terminal;
- carrying forward the parts of oracle that have operational value (options analytics, filings detection, flow ingestion, NSE session management);
- discarding parts of oracle that are dead weight (watchlist, market-context tab, ML-conviction stub, duplicate grade logic).

---

## 2. Guiding principles

Non-negotiable. Any proposal in this document that violates one of these is wrong and gets revised.

1. **Single source of truth for every number.** Indicators are computed once. Contexts are built once. Conviction is graded once. No downstream consumer recomputes anything — they read.

2. **Compute once, read many.** Heavy work happens at defined boundaries (indicator enrichment per symbol, per-day VIX classification, per-scan conviction grading). Everything else is a cheap field access.

3. **Explicit dependencies, stateless classes.** Constructor-arg injection. No hidden globals. No singletons-as-classes (v2 taught us the NSE cookie contamination story). The one shared NSE client instance is constructed once at application startup and injected.

4. **Clean layer separation.** Data knows nothing about indicators. Indicators know nothing about contexts. Contexts know nothing about strategies. Strategies know nothing about conviction. Conviction knows nothing about UI. UI knows nothing about computation. A lower layer never imports from a higher layer — enforced by file structure.

5. **Research and live share one code path.** The backtest harness and the live scanner call the same `ConvictionEngine`. The only variable is whether the contexts are live-fetched or historically reconstructed. If we ever find ourselves maintaining two grade functions, we have failed.

6. **No classification before measurement.** Carried from v2. Strategy names (`mean_reversion`, `breakout`, `ride`, `trap`) exist only after a cluster analysis has produced evidence for them. Strategies are the final artifact, not the starting point.

7. **Type hints everywhere.** Every public function, method, and dataclass field. Reviewed manually; no mypy in CI.

8. **No guesswork on external APIs.** Every NSE endpoint used has documented request/response shape, cookie requirements, and rate-limit behaviour validated against v2/oracle experience. If we hit an undocumented case, we write it down and bake it into the client contract before shipping.

9. **Domain logic is framework-free.** No PyQt imports in `core/`, `compute/`, `context/`, `strategies/`, `conviction/`, `research/`, or `classifiers/`. PyQt is confined to `ui/` and the `events/qt_bridge.py` adapter. The whole domain is testable without a display.

10. **Explicit over implicit.** If a grade contribution depends on VIX, the function signature says so. No hidden module-level state, no mutable globals, no "well, it also reads this other thing."

---

## 3. What's kept, what's dropped, what's new

### 3.1 From `nimbus_v2` — kept and extended

| Component | Action |
|---|---|
| `SignalState` dataclass | **Kept verbatim** as the per-bar technical state contract. Extend only with fields justified by a cluster/research discovery — not speculatively. |
| `StrategyComputeEngine` | **Kept**. Stateless enrichment. One call per symbol per scan. |
| `compute/indicators.py` | **Kept as the canonical math module.** Every WR, RSI, MFI, ADX, ATR, BB, BBW in v3 calls these functions. |
| `VIXRegimeClassifier` with streak | **Kept**, promoted to a context provider. |
| `EntryConfiguration` / `EntryEvaluator` / `EntryRule` | **Kept** for research. These are the primitives that let a sweep test thousands of rule combinations against enriched data. |
| `ForwardReturnCalculator` | **Kept** for research. |
| `SweepRunner`, `ClusterAnalyzer`, `ClusterQualityFilter` | **Kept** with light refactoring. The cluster → classifier factory in v2 is the right shape. |
| `ConfigurationClassifier` / `EnsembleClassifier` / `ClassifierRegistry` | **Kept**. Runtime-callable classifiers built from cluster artifacts. |
| `WalkForwardValidator` | **Kept**, upgraded to purged + embargoed (v2's current version is plain non-overlapping windows). |
| `NSEClient` architecture (cookie isolation, endpoint-scoped caching) | **Kept as the reference implementation.** Extended to cover options, filings, and flow endpoints. |
| `DataLoader` (yfinance + parquet cache) | **Kept**. |
| `VIXLoader` | **Kept**. |
| `IndexConstituents` | **Replaced** by `data/universe.py` — see §3.2. |
| `SetupDetector` (as a live adapter over classifiers) | **Replaced** — its responsibility moves into the strategy + conviction layers. |
| `ScannerEngine` | **Replaced** — v3 has a more general scan orchestrator that handles multiple strategies + contexts in one pass. |

### 3.2 From `nimbus_oracle` — kept and refactored

| Component | Action |
|---|---|
| PyQt6 dashboard and splash | **Kept**. Splash-before-imports sequence carries over. |
| `filings_v2.py` (filing fetch + TRAP classification) | **Kept**. Refactored into `data/filings_loader.py` + `context/filing_context.py` + `strategies/trap.py`. The 883-line monolith splits cleanly across these three layers. |
| `analytics.py` options analytics (GEX, HVL, walls, max-pain, PCR, expiry, viability) | **Kept**. Becomes `context/options_context.py`. The `OptionsContext` dataclass is a context output, not a side-effect of `analyze()`. |
| `nse_client.py` shared singleton pattern | **Kept as the foundation** for v3's NSE client. Constructor-injected. |
| `signal_tracker.py` (persistence of signals across sessions) | **Kept**. Simplified. Becomes `tracking/signal_tracker.py` with SQLite storage. |
| `sector_rotation.py` + `sector_map.py` (sector RS regime) | **Kept**. Becomes `context/sector_context.py`. |
| FII/DII flow fetch (from `signal_engine.py`) | **Kept** as `context/flow_context.py`. Flat ±5 bonus is replaced by a z-score-based conviction contribution. |
| Event calendar + earnings-blackout (from `signal_engine.py`) | **Kept** as `context/event_context.py`. Wired to NSE corporate actions API. |
| ETF momentum strategy (`etf_momentum.py`, `etf_ride.py`, `etf_phase.py`, `etf_analyzer.py`, `etf_universe.py`) | **Kept** as `strategies/etf_momentum.py`. Dedup across those five files into one coherent strategy module. |
| BB Ride strategy (`bb_ride.py`) | **Kept** as `strategies/ride.py`. |
| Deal levels (`deal_levels.py`) | **Kept** as `context/deal_context.py` — block/bulk/SAST/insider as context, not a strategy. |
| `index_constituents.py` | **Replaced** by `data/universe.py` — v3's universe builder consumes NSE sectoral + broad-market index endpoints in one pass, dedupes, and emits both the tradable universe and a symbol→sector map. No separate hard-coded sector dictionary. |
| Splash + phase-loading startup | **Kept**. |
| `commentary.py` | **Kept**, simplified. Consumes `Conviction` objects; produces human-readable strings. |

### 3.3 From `nimbus_oracle` — dropped

| Component | Reason |
|---|---|
| Watchlist tab + `watchlist.py` + `ui/watchlist_db.py` | Per your instruction. |
| Market-context tab | Per your instruction. |
| `ml_conviction.py` | 185 lines of ML scaffolding that was never productionised. The sklearn-based score didn't outperform the rule-based grade in cross-validation. Not worth carrying. |
| `setup_classifier.py` | Its job (mapping indicator state → setup type) is absorbed by v3's strategy layer. Setup enums live in `core/types.py`. |
| `dual_mode.py` (the grading path specifically) | The mean-reversion **rules** are preserved in `strategies/mean_reversion.py`. The grade/score/sizing/verdict logic moves to `conviction/`. The file itself is not carried. |
| `signal_engine.py` (the score-composition path) | Replaced by `conviction/grade_engine.py`. The RS / IVR / FII-DII helpers become context providers. |
| `conviction.py` (the current one) | Replaced wholesale. |
| `scanner.py` (the monolith) | Replaced by `scanner/scan_engine.py` which dispatches via the strategy registry. |
| `run_resolve.py`, `run_tests.py`, `main.py` (root-level scripts) | Replaced by `scripts/` entry points. |
| Duplicate backtest scripts (45+ files in `nimbus_oracle/scripts/`) | Most are one-off explorations. Keep only the ones whose findings are now baked into v3. Delete the rest. |
| `strategy_regime.py` | Responsibility absorbed into `context/market_context.py`. |
| `regime.py` | Same — consolidated into `context/market_context.py`. |
| `bb_ride.py` as a separate scoring module | The ride-entry detection is kept; its scoring overlay is removed — scoring goes through conviction. |
| `setup_classifier.py` color map | Moved to `ui/widgets/setup_palette.py` as a pure presentation concern. |

### 3.4 Ground-up, clean-slate — nothing migrates

Per your decision: **nothing from `nimbus_oracle` or `nimbus_v2` is imported, copied, or migrated at runtime.** v3 is developed in complete isolation.

"Kept" in §3.1 and §3.2 above means "the design is a reference point for what v3 reimplements" — not "we copy the file across." Every module is written fresh against v3's interfaces. The validated v2 rules (MR threshold, BO threshold, VIX-streak values) are the starting values for v3's strategies, but the code that uses them is v3 code. Oracle's NSE cookie-isolation pattern informs v3's client design; oracle's `nse_client.py` is not imported.

Data stores do not migrate either:
- No signal-store migration from oracle's SQLite.
- No cache migration from v2's parquet directory.
- v3 starts with an empty `data/` tree and populates it from scratch.

This is the right call. Partial migrations leak old assumptions — bad data in the cache, half-ported schemas in the store, stale cookies in the session. A ground-up build earns the parity guarantees in §11 by construction.

### 3.5 New in v3

| Component | Purpose |
|---|---|
| `core/conviction.py` (the `Conviction` dataclass) | The single, canonical output of the grading pipeline. Everything downstream reads this. |
| `core/context.py` (the context-bundle dataclasses) | Explicit typed context objects, one per provider. Nothing is passed as a dict. |
| `data/universe.py` (NSE-driven universe + sector registry) | One fetch builds both the tradable universe and the symbol→sector mapping. No hard-coded sector dictionaries. |
| `core/events.py` (domain event types) | Framework-agnostic event definitions. Qt adapter translates to signals in `ui/`. |
| `context/` package | New layer. Every external signal (VIX, sector, options, filings, flow, events, deals) is a provider conforming to `ContextProvider` protocol. |
| `conviction/` package | New layer. `ConvictionEngine`, verdict derivation, sizing derivation, formula definitions — all in one place. |
| `strategies/base.py` (`Strategy` protocol) | New abstraction. MR, BO, ETF, ride, trap all implement it. |
| `events/bus.py` | New pub/sub hub. Decouples scanner, tracker, UI, logger. |
| `scripts/validate_grade_formula.py` | New. Pins the grade-formula outputs against a locked test fixture so formula changes can never silently drift. |
| Purged / embargoed walk-forward | New in v3 (v2's WF doesn't purge across the forward-return horizon). |
| Deflated Sharpe reporter | New. Applied to all cluster sweep outputs so we don't ship 25,000-trial Sharpes as if they were significant. |

---

## 4. System architecture overview

Seven layers. Strict dependency direction: each layer imports only from the layers below. No exceptions.

```
┌──────────────────────────────────────────────────────────────────┐
│ Layer 7: UI (PyQt6)                                              │
│   Dashboard, Signals, Filings, Research tabs.                    │
│   Subscribes to events. Never computes. Never grades.            │
└──────────────────────────────────────────────────────────────────┘
                               │ subscribes
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│ Layer 6: Events (framework-agnostic pub/sub)                     │
│   Domain events: ScanStarted, SymbolGraded, ScanComplete, …      │
│   Qt bridge in ui/ translates for UI subscribers.                │
└──────────────────────────────────────────────────────────────────┘
                               │ publishes
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│ Layer 5: Orchestration (Scanner, Tracker, Research harnesses)    │
│   scan_engine, sweep_runner, walk_forward.                       │
│   Composes lower layers; publishes events.                       │
└──────────────────────────────────────────────────────────────────┘
                               │ calls
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│ Layer 4: Conviction + Strategies                                 │
│   ConvictionEngine, Strategy impls, Classifiers.                 │
│   Produces Conviction objects from (state + contexts + strategy) │
└──────────────────────────────────────────────────────────────────┘
                               │ reads
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│ Layer 3: Contexts (external-data enrichment)                     │
│   MarketContext, SectorContext, OptionsContext, FilingContext,   │
│   FlowContext, EventContext, DealContext.                        │
└──────────────────────────────────────────────────────────────────┘
                               │ reads
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│ Layer 2: Compute (per-symbol technical enrichment)               │
│   StrategyComputeEngine, canonical indicators, SignalState.      │
│   Stateless. Pure. Zero external data.                           │
└──────────────────────────────────────────────────────────────────┘
                               │ reads
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│ Layer 1: Data (ingestion + cache)                                │
│   price, options, filings, flow, VIX, corporate actions,         │
│   universe constituents. Parquet cache + shared NSE client.      │
└──────────────────────────────────────────────────────────────────┘
```

**The cardinal rule:** a call graph that violates top-down direction is a bug. Enforced at review time; should eventually be enforceable by `import-linter` or equivalent.

---

## 5. Package layout

```
nimbus_v3/
├── pyproject.toml
├── README.md
├── docs/
│   ├── ARCHITECTURE.md                (this document, as-built)
│   ├── GRADE_FORMULA.md               (authoritative formula spec + worked examples)
│   ├── NSE_ENDPOINTS.md               (endpoint catalog: cookies, rate limits, schemas)
│   └── research_notes/                (dated markdown; one per investigation)
├── data/                              (gitignored runtime)
│   ├── cache/
│   │   ├── price/                     (parquet: OHLCV by symbol)
│   │   ├── options/                   (parquet: option chains by symbol + expiry)
│   │   ├── filings/                   (parquet: filings by symbol)
│   │   ├── vix/                       (parquet: VIX history)
│   │   └── nse_responses/             (short-TTL raw NSE JSON)
│   ├── reports/                       (script outputs: text, CSV)
│   ├── backtest_results/              (sweep / walk-forward outputs)
│   └── signal_store.sqlite            (signal tracker persistence)
│
├── nimbus_v3/                         (the package)
│   ├── __init__.py                    (exports nothing; consumers import subpackages)
│   │
│   ├── core/                          (cross-cutting primitives)
│   │   ├── __init__.py
│   │   ├── signal_state.py            (the per-bar technical state dataclass)
│   │   ├── context.py                 (MarketContext, SectorContext, OptionsContext,
│   │   │                               FilingContext, FlowContext, EventContext,
│   │   │                               DealContext, ContextBundle)
│   │   ├── conviction.py              (Conviction, Contribution, Grade, Verdict, Sizing)
│   │   ├── signal.py                  (StrategySignal — pre-conviction output from a strategy)
│   │   ├── events.py                  (domain event types: ScanStarted, SymbolEnriched,
│   │   │                               ContextsBuilt, StrategyFired, SymbolGraded,
│   │   │                               ScanComplete, ScanFailed, …)
│   │   └── types.py                   (Enums: Regime, SetupType, GradeLetter, Verdict,
│   │                                    Sizing, VolState, ConvictionTier, …)
│   │
│   ├── data/
│   │   ├── __init__.py
│   │   ├── base.py                    (Loader protocol; CacheStore protocol)
│   │   ├── cache.py                   (ParquetCache impl; TTL logic)
│   │   ├── nse_client.py              (shared NSE client; cookie-isolated)
│   │   ├── price_loader.py            (yfinance + cache)
│   │   ├── vix_loader.py              (NSE → yfinance fallback tiers)
│   │   ├── options_loader.py          (NSE option chain via NSEClient)
│   │   ├── filings_loader.py          (NSE announcements via NSEClient)
│   │   ├── flow_loader.py             (FII/DII via NSEClient)
│   │   ├── events_loader.py           (corporate actions: earnings, dividends, splits)
│   │   ├── universe.py                (NSE index-driven universe builder; one fetch
│   │   │                               produces both the symbol universe and the
│   │   │                               symbol→sector map. Supports NIFTY 50/100/200/500,
│   │   │                               F&O, sector indices, and ETF universe.)
│   │   └── deals_loader.py            (block / bulk / SAST / insider)
│   │
│   ├── compute/
│   │   ├── __init__.py
│   │   ├── indicators.py              (canonical stateless math: WR, RSI, MFI, ADX,
│   │   │                               ATR, BB, BBW, ROC, drawdown, streaks,
│   │   │                               vol ratio, SMA, MA position, pct-from-MA)
│   │   ├── engine.py                  (StrategyComputeEngine — one enrichment pass)
│   │   └── vix_regime.py              (VIXRegimeClassifier, with streak; same as v2)
│   │
│   ├── context/
│   │   ├── __init__.py
│   │   ├── base.py                    (ContextProvider[T] protocol)
│   │   ├── market_context.py          (VIX regime, streak, breadth, index trend)
│   │   ├── sector_context.py          (sector RS regime, sector realized vol,
│   │   │                               sector vol z-score, CYCLICAL vs DEFENSIVE)
│   │   ├── options_context.py         (GEX, HVL, walls, max-pain, PCR, IVR, expiry)
│   │   ├── filing_context.py          (filing impact classification, TRAP flag)
│   │   ├── flow_context.py            (FII/DII net flow + z-score)
│   │   ├── event_context.py           (earnings blackout, dividend/split proximity)
│   │   └── deal_context.py            (block/bulk/SAST/insider events)
│   │
│   ├── strategies/
│   │   ├── __init__.py
│   │   ├── base.py                    (Strategy protocol + StrategySignal dataclass)
│   │   ├── registry.py                (strategy registry)
│   │   ├── mean_reversion.py          (MR: roc5<-3 + bbw_pctl<30 + sustained HIGH VIX)
│   │   ├── breakout.py                (BO: roc20>5 + vol≥1.5x + sustained HIGH VIX)
│   │   ├── ride.py                    (BB Ride: riding upper + W%R momentum)
│   │   ├── etf_momentum.py            (ETF: consolidated from five oracle files)
│   │   └── trap.py                    (filing-TRAP: highest-priority override)
│   │
│   ├── classifiers/                   (research-derived runtime patterns)
│   │   ├── __init__.py
│   │   ├── base.py                    (Classifier protocol)
│   │   ├── configuration_classifier.py
│   │   ├── ensemble_classifier.py
│   │   └── registry.py
│   │
│   ├── conviction/
│   │   ├── __init__.py
│   │   ├── formula.py                 (grade formula — pure functions, per-contribution)
│   │   ├── grade_engine.py            (ConvictionEngine — the one entry point)
│   │   ├── verdict.py                 (Conviction → Verdict rules)
│   │   ├── sizing.py                  (Conviction → Sizing rules)
│   │   └── fixtures/                  (locked-in test fixtures for formula regression)
│   │
│   ├── research/
│   │   ├── __init__.py
│   │   ├── entry_config.py            (from v2)
│   │   ├── entry_evaluator.py         (from v2)
│   │   ├── forward_returns.py         (from v2)
│   │   ├── sweep_runner.py            (from v2)
│   │   ├── walk_forward.py            (purged + embargoed)
│   │   ├── deflated_sharpe.py         (new)
│   │   ├── cluster_analyzer.py        (from v2)
│   │   └── cluster_quality_filter.py  (from v2)
│   │
│   ├── scanner/
│   │   ├── __init__.py
│   │   ├── orchestrator.py            (parallelism, rate-limit, sector-batched scanning)
│   │   └── scan_engine.py             (pipeline: data → compute → context → strategy
│   │                                    → conviction; publishes events)
│   │
│   ├── tracking/
│   │   ├── __init__.py
│   │   ├── signal_tracker.py          (subscribes to events; persists signals)
│   │   ├── store.py                   (SQLite-backed repository for signals)
│   │   └── commentary.py              (Conviction → human-readable text)
│   │
│   ├── events/
│   │   ├── __init__.py
│   │   ├── bus.py                     (framework-agnostic EventBus)
│   │   └── qt_bridge.py               (EventBus → Qt signals adapter; only this file
│   │                                    and ui/ import PyQt6)
│   │
│   └── ui/                            (PyQt6 consumer)
│       ├── __init__.py
│       ├── app.py                     (QApplication, splash, MainWindow)
│       ├── styles.py                  (stylesheet constants)
│       ├── dashboard/
│       │   ├── __init__.py
│       │   ├── view.py                (main dashboard)
│       │   ├── panels/
│       │   │   ├── chart_panel.py
│       │   │   ├── conviction_panel.py
│       │   │   ├── key_levels_panel.py      (formerly 'Panel B')
│       │   │   ├── sector_context_panel.py
│       │   │   ├── filings_strip.py
│       │   │   └── workflow_panel.py
│       │   └── row_table.py
│       ├── signals_tab/                     (signal tracker view — kept)
│       ├── filings_tab/                     (filings — kept)
│       ├── research_tab/                    (browse backtest results)
│       └── widgets/
│           ├── setup_palette.py
│           └── grade_pill.py
│
├── scripts/
│   ├── scan.py                        (CLI: one-shot scan, prints and/or writes)
│   ├── run_sweep.py
│   ├── run_walk_forward.py
│   ├── download_universe.py
│   ├── validate_grade_formula.py      (regression-test the formula)
│   └── print_conviction.py            (CLI: grade one symbol, explain every contribution)
│
└── tests/
    ├── __init__.py
    ├── core/
    ├── data/
    ├── compute/
    ├── context/
    ├── conviction/
    ├── strategies/
    ├── classifiers/
    ├── research/
    ├── scanner/
    ├── tracking/
    ├── events/
    └── integration/                   (end-to-end; live contexts stubbed)
```

**Structural decisions worth naming explicitly:**

- **`core/` is the only place cross-layer dataclasses live.** Every layer below UI imports `SignalState`, `Conviction`, `ContextBundle`, etc. from `core/`. This avoids circular dependencies and keeps type definitions discoverable.
- **No layer has a "utils" module.** Utils attract unrelated functions and become the thing everyone depends on. Every helper has a specific home.
- **`data/` fetches; `compute/` computes; `context/` interprets.** An `OptionsContext` is produced by `context/options_context.py`, which consumes raw chain data from `data/options_loader.py`. The loader never classifies; the context provider never fetches.
- **UI is a subscriber.** It imports from `core/` for types and from `events/qt_bridge.py` for signals. It never imports from `scanner/`, `strategies/`, `conviction/`, `context/`, `compute/`, or `data/` directly. If the UI needs to kick off a scan, it calls the orchestrator via a well-defined entry point, not by reaching into it.

---

## 6. The unified pipeline: bar → conviction

This is the single most important diagram in v3. Every live scan, every backtest fire, every CLI invocation flows through these steps in this order.

```
  ┌──────────────────────────────────────────────────────────┐
  │  Step 1  DATA                                            │
  │  PriceLoader.load(symbol) → raw_df                       │
  │  OptionsLoader.load(symbol)?                             │
  │  FilingsLoader.load(symbol)?                             │
  │  (other loaders as required by the scan)                 │
  └──────────────────────────────────────────────────────────┘
                           │
                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │  Step 2  COMPUTE                                         │
  │  engine.enrich(raw_df, symbol) → enriched_df             │
  │  engine.extract_state(enriched_df, bar_index=-1, symbol) │
  │      → SignalState                                       │
  └──────────────────────────────────────────────────────────┘
                           │
                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │  Step 3  CONTEXT                                         │
  │  MarketContextProvider.build(asof_date)                  │
  │  SectorContextProvider.build(symbol, asof_date)          │
  │  OptionsContextProvider.build(symbol, asof_date)?        │
  │  FilingContextProvider.build(symbol, asof_date)?         │
  │  FlowContextProvider.build(asof_date)                    │
  │  EventContextProvider.build(symbol, asof_date)           │
  │  DealContextProvider.build(symbol, asof_date)?           │
  │  → ContextBundle                                         │
  └──────────────────────────────────────────────────────────┘
                           │
                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │  Step 4  STRATEGY DISPATCH                               │
  │  for strategy in registry.enabled():                     │
  │      signal = strategy.evaluate(state, contexts)         │
  │      if signal is None: continue                         │
  │      → StrategySignal                                    │
  └──────────────────────────────────────────────────────────┘
                           │
                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │  Step 5  CONVICTION                                      │
  │  conviction_engine.grade(state, contexts, signal)        │
  │      → Conviction                                        │
  │                                                          │
  │  Conviction bundles: score (0-100),                      │
  │                      grade letter (A/B/C/D),             │
  │                      verdict (TAKE/WATCH/SKIP),          │
  │                      sizing (FULL/HALF/SKIP),            │
  │                      contributions (per-factor breakdown)│
  │                      reasons (human-readable strings),   │
  │                      strategy identity,                  │
  │                      timestamp.                          │
  └──────────────────────────────────────────────────────────┘
                           │
                           ▼
  ┌──────────────────────────────────────────────────────────┐
  │  Step 6  PUBLISH                                         │
  │  event_bus.publish(SymbolGraded(conviction, state, ctx)) │
  │  → Tracker persists. UI updates. Commentary generates.   │
  └──────────────────────────────────────────────────────────┘
```

**This is the contract for v3.** Every number on the dashboard is the output of Step 5 for some symbol, strategy, and timestamp. No number exists that did not come from a `Conviction`.

**Live scan vs backtest, same pipeline, one knob changed:**
- **Live:** context providers fetch fresh data. `asof_date = today`.
- **Backtest:** context providers operate in "historical reconstruction" mode — they build the same context from cached data keyed by `asof_date`. A walk-forward fold just iterates `asof_date` through the in-sample range and calls the identical pipeline.

This requires every context provider to support as-of queries — which is why `build(..., asof_date)` is in the protocol from the start.

---

## 7. Single source of truth: `ConvictionEngine`

### 7.1 Responsibility

`ConvictionEngine` takes a `SignalState`, a `ContextBundle`, and a `StrategySignal`, and produces a `Conviction`. That's the only thing it does. It is called identically by:

- `scanner/scan_engine.py` — the live scanner
- `research/walk_forward.py` — the backtest harness
- `scripts/print_conviction.py` — the CLI explanation tool
- `tests/conviction/test_*.py` — the regression test suite

If a bug in a grade contribution is fixed, every caller picks up the fix automatically. If a formula change lands, every caller sees it atomically. There is no parallel "backtest grade" vs "live grade" — a class of drift bugs is eliminated by construction.

### 7.2 Class sketch

```python
class ConvictionEngine:
    """The single grading authority. Stateless, thread-safe.

    Construct once at application startup with the formula and derivation
    rules that compose a Conviction from the inputs. Call grade(...) from
    anywhere; never instantiate more than one per process (inject it).
    """

    def __init__(
        self,
        formula: GradeFormula,
        verdict_rule: VerdictRule,
        sizing_rule: SizingRule,
    ) -> None:
        self.formula = formula
        self.verdict_rule = verdict_rule
        self.sizing_rule = sizing_rule

    def grade(
        self,
        state: SignalState,
        contexts: ContextBundle,
        signal: StrategySignal,
    ) -> Conviction:
        """Produce a Conviction for one (state, contexts, signal) triple.

        Purely functional: same inputs → same Conviction. No side effects,
        no I/O, no timestamps from wall-clock. The 'timestamp' field in the
        returned Conviction is taken from state.bar_date.
        """
        contributions = self.formula.compute(state, contexts, signal)
        score = sum(c.value for c in contributions)
        score = max(0, min(100, score))
        grade_letter = _score_to_letter(score)
        verdict = self.verdict_rule.derive(score, state, contexts, signal, contributions)
        sizing = self.sizing_rule.derive(score, state, contexts, signal, contributions)
        reasons = _reasons_from_contributions(contributions)
        return Conviction(
            symbol=state.symbol,
            strategy=signal.strategy,
            timestamp=state.bar_date,
            score=score,
            grade=grade_letter,
            verdict=verdict,
            sizing=sizing,
            contributions=tuple(contributions),
            reasons=tuple(reasons),
            signal=signal,
        )
```

### 7.3 The formula as a pure, inspectable composition

`GradeFormula.compute(state, contexts, signal)` returns a list of `Contribution` objects. Each contribution is the output of one pure function that takes exactly what it needs:

```
contributions = [
    mfi_contribution(state),
    volume_contribution(state),
    rsi_contribution(state),
    vix_contribution(contexts.market),
    sector_rs_contribution(contexts.sector, signal),
    sector_vol_contribution(contexts.sector, contexts.market),
    divergence_contribution(state),
    filing_contribution(contexts.filing),
    flow_contribution(contexts.flow),
    event_contribution(contexts.event),           # penalty only
    day_of_week_contribution(state),              # 'Friday penalty'
]
```

**Properties that fall out of this design:**
- Each contribution is independently unit-testable — pass in a constructed state/context, assert the returned value.
- The grade formula document (`docs/GRADE_FORMULA.md`) is directly keyed to these functions; if the doc says `+2 for EXTREME sector vol during PANIC`, it's implemented in `sector_vol_contribution` and tested in `test_sector_vol_contribution.py`.
- Regression testing: a locked fixture file pins 100 `(state, contexts, signal) → Conviction` triples. Any change to the formula that shifts a fixture output is a conscious decision that requires updating the fixture, which requires a reviewer.
- Experimenting with a new contribution is trivial: add a function, add it to the composition list, run the fixture suite to see exactly which historical grades shifted.

### 7.4 Verdict and sizing are separate, small modules

`VerdictRule.derive(score, state, contexts, signal, contributions) -> Verdict`
`SizingRule.derive(score, state, contexts, signal, contributions) -> Sizing`

These take the full context because verdict/sizing decisions aren't pure functions of score. Example rules (lifted from the existing oracle logic, to be validated not transcribed):
- Verdict `SKIP` if earnings are within 2 trading days (hard gate, regardless of score).
- Sizing `HALF` if `OptionsContext.gex_regime == PINNING` and `dte <= 4`, regardless of score.
- Verdict `TAKE` if `score >= 75` AND `contexts.market.regime != PANIC`.

These are small, readable functions. They belong in their own module because they change independently of the score formula and deserve their own test suite.

### 7.5 What `ConvictionEngine` does NOT do

- Does NOT fetch data — that's the data layer.
- Does NOT compute indicators — that's compute.
- Does NOT build contexts — that's context providers.
- Does NOT decide what strategy applies — that's strategy dispatch in the scanner.
- Does NOT persist — that's the tracker subscribing to events.
- Does NOT log — that's the tracker and the event-bus logger.
- Does NOT care about UI — that's the dashboard subscribing to events.

---

## 8. Context providers

### 8.1 The problem v3 solves here

In oracle, "context" is strewn across modules. VIX regime is computed in three places. Sector RS lives in `sector_rotation.py` but is also re-derived in `dual_mode.py`. Options context is buried inside `analytics.py` alongside viability scoring. Earnings blackout is checked inline in `signal_engine.py`. The conviction formula reaches into all of them via module-level imports, and changing one means hunting the codebase.

In v3, **every piece of external context is a provider with one job**. The provider produces a typed context object that the conviction formula consumes. Providers don't call each other; the scan engine composes them into a `ContextBundle`.

### 8.2 The protocol

```python
class ContextProvider(Protocol[T]):
    """Protocol for any provider of per-(symbol, asof_date) context.

    T is the concrete context type the provider returns. Providers are
    stateless or cache-backed, never mutable. build() is idempotent for a
    given asof_date.
    """

    def build(self, *, symbol: str | None, asof_date: pd.Timestamp) -> T | None:
        """Return the context object, or None if unavailable (e.g. no
        options listed for this symbol). Providers must NOT raise on
        'data missing'; they return None and the formula handles it.
        """
        ...
```

- `symbol` is optional because some providers are market-wide (`MarketContext`, `FlowContext`) and take `symbol=None`.
- `asof_date` is always explicit. No provider ever looks at `datetime.now()`.
- Returning `None` is a first-class outcome. The formula composes contributions that each handle the None case explicitly.

### 8.3 Provider inventory

| Provider | Context class | Inputs | Cache policy |
|---|---|---|---|
| `MarketContextProvider` | `MarketContext` (VIX value, regime, high-streak, breadth, index trend) | VIX history, NIFTY index history | Per-day; cache for session |
| `SectorContextProvider` | `SectorContext` (sector name, type, RS regime, realized vol, vol z-score) | Sector index history, symbol→sector map | Per-(sector, day); cache for session |
| `OptionsContextProvider` | `OptionsContext` (GEX, HVL, walls, max-pain, PCR, IVR, DTE, pin-risk, spot-vs-MP) | Option chain for symbol | Per-(symbol, day); refresh during trading hours |
| `FilingContextProvider` | `FilingContext` (latest filings, impact classification, TRAP flag) | Corporate announcements for symbol | Per-(symbol, day); intraday refresh if live |
| `FlowContextProvider` | `FlowContext` (FII net, DII net, z-scores, signal label) | FII/DII daily flow history | Per-day |
| `EventContextProvider` | `EventContext` (earnings blackout flag, days-to-event, dividend/split proximity) | Corporate actions for symbol | Per-(symbol, day); refresh daily |
| `DealContextProvider` | `DealContext` (recent block/bulk/SAST/insider counts + magnitudes) | Deal feeds for symbol | Per-(symbol, day) |

### 8.4 Composition: `ContextBundle`

```python
@dataclass(frozen=True)
class ContextBundle:
    """The complete context for (symbol, asof_date). Assembled by the scan
    engine from the registered providers; passed wholesale to the
    ConvictionEngine.

    All fields are Optional except market, which is always required.
    """
    symbol: str
    asof_date: pd.Timestamp
    market: MarketContext
    sector: SectorContext
    options: OptionsContext | None = None
    filing: FilingContext | None = None
    flow: FlowContext | None = None
    event: EventContext | None = None
    deal: DealContext | None = None
```

The scan engine's contract is: "given a symbol and asof_date, call the relevant providers, assemble a `ContextBundle`, pass it to strategies and conviction." Adding a new provider is three steps: write the provider, add a field to `ContextBundle`, wire it into the scan engine's bundle assembly.

### 8.5 Historical reconstruction = the same code

For backtests, the providers are constructed with cache backends pointed at historical parquet data. `MarketContextProvider.build(asof_date=pd.Timestamp("2023-06-15"))` looks up VIX values on and before that date and returns the same-shaped `MarketContext` it would return live on 2023-06-15. The conviction engine doesn't know or care.

This is the single most important architectural property for research-live parity, and it's cheap to buy: just commit to `asof_date` being mandatory in every provider signature.

---

## 9. Strategy plugin model

### 9.1 The protocol

```python
class Strategy(Protocol):
    """A named entry strategy. Reads SignalState + ContextBundle; emits
    a StrategySignal if it fires, None if it doesn't."""

    name: str                        # 'mean_reversion', 'breakout', 'ride', 'etf_momentum', 'trap'
    setup_type: SetupType            # enum from core/types.py
    priority: int                    # for ranking when multiple fire (TRAP > BO > MR > RIDE)
    required_contexts: frozenset[str]  # {'market'} or {'market', 'options'} etc.

    def evaluate(
        self,
        state: SignalState,
        contexts: ContextBundle,
    ) -> StrategySignal | None:
        ...
```

Every strategy declares which contexts it needs. The scan engine uses this to skip expensive context provisioning when a strategy can't run (e.g. non-F&O stocks skip options context).

### 9.2 `StrategySignal`

```python
@dataclass(frozen=True)
class StrategySignal:
    """A pre-conviction output: the strategy's determination that a
    setup exists, along with its own internal rank/quality indicators
    that the conviction formula may consume."""

    strategy: str
    setup_type: SetupType
    symbol: str
    timestamp: pd.Timestamp
    # Strategy-specific descriptors (e.g. 'roc_5' for MR, 'roc_20' for BO)
    primary_metric: float
    # Free-form extras the formula can peek into via .get('key', default)
    extras: Mapping[str, float | str | bool] = field(default_factory=dict)
```

### 9.3 Strategy impls

- `mean_reversion.py` — MR rule pair from v2's walk-forward (`roc_5 < -3 + bbw_pctl < 30`), gated on sustained HIGH VIX streak ≥ 6.
- `breakout.py` — BO rule pair (`roc_20 > 5 + vol_ratio ≥ 1.5`), gated on streak ≥ 4.
- `ride.py` — BB Ride (riding upper 1σ + W%R > -20), reuses the indicators that are already in the SignalState.
- `etf_momentum.py` — ETF momentum consolidated from oracle's five ETF files.
- `trap.py` — Filing-driven TRAP override. Highest priority. Lives as a strategy so it flows through the same pipeline, but its contribution pattern skews the conviction sharply.

### 9.4 Strategy registry

```python
class StrategyRegistry:
    def register(self, strategy: Strategy) -> None: ...
    def get(self, name: str) -> Strategy: ...
    def enabled(self) -> list[Strategy]: ...
    def for_universe(self, universe: str) -> list[Strategy]: ...
        # e.g. 'etf_momentum' only applies to ETF universe
```

The registry is instantiated once at application startup and injected into the scan engine. Strategies are not auto-discovered via import magic — registration is explicit in `app.py` or CLI entry points.

### 9.5 What strategies do NOT do

- Do NOT compute their own grade. They produce `StrategySignal`; grading is downstream.
- Do NOT fetch data.
- Do NOT call other strategies.
- Do NOT mutate state or contexts.
- Do NOT decide sizing or verdict.

---

## 10. Event bus and UI decoupling

### 10.1 Why an event bus, given oracle uses Qt signals

In oracle, Qt signals are used as the event mechanism, and they work. The problem is that Qt signal definitions leak into `data_manager.py`, which makes that module impossible to use from a headless CLI or a pytest harness without a `QApplication`. Every backtest script has to stub out or avoid the parts of the domain that emit Qt signals.

In v3, the domain emits framework-agnostic events. The `qt_bridge.py` adapter translates them to Qt signals for the UI. CLI scripts subscribe directly to the bus. Tests assert on published events without PyQt in the dependency tree.

### 10.2 `EventBus` sketch

```python
class EventBus:
    def subscribe(self, event_type: type[Event], handler: Callable[[Event], None]) -> Subscription: ...
    def publish(self, event: Event) -> None: ...

# Events are immutable dataclasses.
@dataclass(frozen=True)
class SymbolGraded(Event):
    conviction: Conviction
    state: SignalState
    contexts: ContextBundle
```

Not async. Not multi-threaded by default. Publish calls handlers synchronously in the order subscribed. Qt bridge marshals to the main Qt thread where needed.

### 10.3 Event taxonomy

| Event | Publisher | Subscribers |
|---|---|---|
| `ScanStarted(scan_id, universe, strategies)` | Scanner | UI (progress), Logger |
| `SymbolEnriched(symbol, state)` | Scanner | (diagnostic only) |
| `ContextsBuilt(symbol, contexts)` | Scanner | (diagnostic only) |
| `StrategyFired(symbol, signal)` | Scanner | (diagnostic only) |
| `SymbolGraded(conviction, state, contexts)` | Scanner | Tracker, UI, Commentary |
| `SymbolSkipped(symbol, reason)` | Scanner | Logger |
| `ScanComplete(scan_id, summary)` | Scanner | UI, Tracker, Logger |
| `ScanFailed(scan_id, error)` | Scanner | UI, Logger |

UI subscribes to `SymbolGraded`, `ScanStarted`, `ScanComplete`. Tracker subscribes to `SymbolGraded` and persists. Commentary is a pure transform that the UI may invoke directly on a `Conviction` — it's not actually a subscriber, just a helper that the dashboard panel calls synchronously.

---

## 11. Research / live parity

### 11.1 The parity guarantee

For any historical date `D` and symbol `S`:
```
conviction_live_on_D(S)  ==  conviction_backtest_on_D(S)
```
…where the RHS is computed via the backtest harness with `asof_date=D`.

This is the whole point of the unified pipeline and the `asof_date` context protocol. Research and live call the same `ConvictionEngine.grade()`; they differ only in whether context providers fetch fresh or look up cached history.

### 11.2 Sweep and walk-forward

- `SweepRunner` generates `EntryConfiguration` combinations and evaluates them against enriched DataFrames. Unchanged from v2. Outputs `configuration_performance.csv`.
- `ClusterAnalyzer` clusters the top configurations. Unchanged from v2. Outputs `cluster_details.txt` + `cluster_report.csv`.
- `WalkForwardValidator` is upgraded: **purged** (training fold excludes bars whose forward-return window overlaps the validation fold) and **embargoed** (additional gap to prevent leakage from serial correlation).
- `DeflatedSharpeReporter` is new: given N trials and a best observed Sharpe, compute the probability-deflated Sharpe (López de Prado 2018). Every sweep output gets deflated Sharpe alongside raw Sharpe. You can no longer accidentally ship a 25,000-trial best as a real result.

### 11.3 Live scanner

`scan_engine.py` iterates the universe, per symbol:
1. Price loader loads history (parquet cache).
2. Compute engine enriches → `SignalState`.
3. Required contexts built → `ContextBundle`.
4. Each registered strategy evaluates; non-None `StrategySignal`s are collected.
5. For each `StrategySignal`, `ConvictionEngine.grade(...)` produces a `Conviction`.
6. `SymbolGraded` event is published.
7. Scanner continues to next symbol; UI updates incrementally; tracker persists.

### 11.4 Backtest scanner

`research/walk_forward.py` iterates `asof_date` across the validation range:
1. For each `asof_date`, assemble the universe.
2. Per symbol, slice enriched DataFrame up to `asof_date`; extract `SignalState` at that bar.
3. Build contexts from historical parquet (same providers, `asof_date` passed in).
4. Run strategies → signals.
5. Grade via the same `ConvictionEngine`.
6. Record the `Conviction`, advance `asof_date`, measure forward returns.

**No branches, no duplicate grade functions, no "backtest approximation."** This is the refactor's single highest-value property.

### 11.5 The `validate_grade_formula.py` script

A fixture file (`conviction/fixtures/golden.json`) contains ~100 `(SignalState, ContextBundle, StrategySignal, expected_Conviction)` quadruples. `validate_grade_formula.py` replays them and asserts every field matches. It runs in CI and every time the formula is touched. If you change the formula on purpose, you update the fixture — deliberately, with a reviewer sign-off.

---

## 12. Data layer: caching, sessions, rate limiting

Minimal guesswork; v2 and oracle already taught us most of the shape.

### 12.1 NSE client

`data/nse_client.py` is the canonical NSE HTTP client. Design properties validated in v2:

- **One instance per process.** Constructed at startup; injected wherever needed.
- **No `requests.Session` under the hood.** Per v2's findings, `Session` caused cross-contamination between endpoint groups. Plain `requests` calls with manually-managed cookies per endpoint group.
- **Endpoint-scoped cookie cache.** Each endpoint referer gets its own cookie jar, cached 5 minutes per referer.
- **Base cookies from a `_warm()` call on session start.** Re-warmed if missing.
- **Explicit cooldown on failure.** 5-minute backoff when a fetch fails; `_last_fetch_ts` updated on failure not just success (v2 fix).
- **Per-endpoint rate limiter.** Configurable; default 1.2s spacing inherited from oracle's scanner experience.

### 12.2 Endpoints catalog

`docs/NSE_ENDPOINTS.md` documents each endpoint used:
- URL pattern
- Required cookies (base vs endpoint-scoped)
- Request method, headers, params
- Response schema (ideally a TypedDict)
- Observed rate limit
- Failure modes and retry policy

Endpoints in scope for v3:
- Option chain (equity + index)
- Corporate announcements (filings)
- FII/DII daily cash flow
- Block/bulk deal feed
- Corporate actions (earnings, dividends, splits)
- Index constituents
- Live quote (secondary fallback only)

### 12.3 Cache layer

`data/cache.py` implements `ParquetCache` behind a `CacheStore` protocol:

```python
class CacheStore(Protocol):
    def get(self, key: str) -> pd.DataFrame | None: ...
    def set(self, key: str, df: pd.DataFrame, ttl: timedelta | None = None) -> None: ...
    def exists(self, key: str) -> bool: ...
    def age(self, key: str) -> timedelta | None: ...
    def clear(self, prefix: str | None = None) -> int: ...
```

Each loader owns its cache namespace (`price/`, `options/`, `filings/`, `vix/`). Loaders check TTL; loaders never fetch if cache is fresh and the caller didn't force-refresh.

### 12.4 What's NOT in the data layer

- No indicator computation.
- No context assembly.
- No scoring.
- No classification of filings ("is this a TRAP?"). Loaders return raw filing records; classification happens in `context/filing_context.py`.

---

## 13. UI layer: tabs, panels, responsibilities

### 13.1 Tabs

| Tab | Purpose | Data source |
|---|---|---|
| Dashboard | Primary scanner view with graded rows. Universe-filter dropdown at the top (NIFTY 50/100/200/500, F&O, ETF, any sector index) — all slices of the single `Universe` object from `data/universe.py`. | `SymbolGraded` events |
| Signals | Historical signal tracker, filters, outcomes | `tracking/store.py` |
| Filings | Recent corporate announcements with impact | `FilingContext` from cache |
| Research | Browse backtest outputs, cluster reports, WF results | Filesystem |

**Dropped per your instruction:** Watchlist, Market Context.

### 13.2 Dashboard panels

- **Row table** — one row per symbol that fired, sorted by strategy priority then conviction score. Columns: grade pill, symbol, strategy badge, setup, price, WR(30), MFI(14), VIX regime, sector, key levels summary.
- **Chart panel** — selected symbol's daily chart with BB bands (1σ and 2σ), SMA(20), WR(30) subplot.
- **Conviction panel** — the `Conviction` object rendered as plain text labels. Grade, score, verdict, sizing, top 5 contributions with signs, reasons list. Consumes `Conviction` directly — no recomputation.
- **Key Levels panel** (the former "Panel B") — options-derived levels when present: support wall, resistance wall, max-pain, HVL, GEX regime, DTE, pin-risk.
- **Sector Context panel** — sector name, type (CYCLICAL/DEFENSIVE), RS regime, sector vol state, grade impact (from contributions).
- **Filings strip** — latest filing for the selected symbol with impact label.
- **Workflow panel** — step-by-step explanation of why the conviction ended up where it did; reads `Conviction.reasons`.

### 13.3 UI does not recompute

The UI's entire mental model is: "receive `Conviction` + `ContextBundle`, render." Every panel is a read. The sector context panel does not compute sector RS; it reads `contexts.sector.rs_regime`. The conviction panel does not add numbers; it displays `conviction.score`. If a panel finds itself doing arithmetic, that's a bug.

### 13.4 Signals, Filings, Research tabs

- **Signals tab** — query the signal store (SQLite). Filter by strategy, date range, grade, verdict. Each row shows the stored `Conviction` snapshot plus the realised return if outcomes were backfilled.
- **Filings tab** — table of recent filings. Impact and TRAP flag come from `FilingContext`, not recomputed here.
- **Research tab** — a file browser over `data/backtest_results/`. Renders `walk_forward_report.txt`, `cluster_details.txt`, and `configuration_performance.csv` with minimal formatting. This is a utility, not a research IDE.

---

## 14. SOLID mapping and design patterns

### 14.1 SOLID

- **Single responsibility** — each module has one job, as per layer separation. `price_loader` loads prices; it doesn't compute SMA.
- **Open/closed** — new strategies register with the `StrategyRegistry`; new contexts add to `ContextBundle`; the conviction engine and scan engine don't change. New grade contributions are additions to the formula composition list; existing contribution functions are untouched.
- **Liskov** — all `Strategy` impls are interchangeable via the protocol. All `ContextProvider` impls are interchangeable. The scan engine depends on the protocol, never on concrete types.
- **Interface segregation** — small, focused protocols (`Strategy`, `ContextProvider`, `Classifier`, `Loader`, `CacheStore`). Nothing implements a grab-bag interface with unrelated methods.
- **Dependency inversion** — `ConvictionEngine` depends on `GradeFormula`, `VerdictRule`, `SizingRule` (abstractions), which are injected. The scan engine depends on injected providers and the strategy registry, never on module-level globals.

### 14.2 Design patterns used — and justified

| Pattern | Where | Why |
|---|---|---|
| **Strategy** | `strategies/` | Interchangeable entry logic under one protocol. |
| **Protocol (interface)** | `Strategy`, `ContextProvider`, `Classifier`, `CacheStore`, `Loader` | Structural typing over small interfaces keeps the type surface honest. |
| **Registry** | `StrategyRegistry`, `ClassifierRegistry` | Explicit registration > import-time magic. Makes testing trivial. |
| **Factory** | `ConfigurationClassifier.from_cluster(...)` | Derived-artifact construction with validation. |
| **Repository** | `tracking/store.py`, `data/cache.py` | Storage behind a clean interface; swappable backends. |
| **Specification** | `EntryRule` composition in research layer | Already proven in v2. |
| **Observer / pub-sub** | `events/bus.py` | Decouples scanner from tracker and UI. |
| **Adapter** | `events/qt_bridge.py` | Framework-agnostic events translated into Qt signals at the UI boundary. |
| **Dependency injection** (constructor) | Everywhere | The `NSEClient` lesson from v2. |

### 14.3 Patterns NOT used, deliberately

| Pattern | Reason |
|---|---|
| Singleton-as-class | v2's NSE cookie contamination taught us shared mutable state hurts. One-instance-per-process is a composition concern, not a type concern. |
| Abstract factory | Over-engineered for our construction surface. |
| Visitor | No nested polymorphic structures that need double-dispatch. |
| Chain of responsibility | Conviction formula is a flat composition, not a chain. Easier to reason about. |
| Command | We don't need undoable operations. |
| Decorator chains on domain objects | Adds indirection without buying type safety. |
| Service locator | Explicit DI is clearer. |
| Event sourcing | Overkill; we persist final `Conviction` snapshots, not every intermediate. |
| Async / threading in core | Domain layers are synchronous. The scanner orchestrator uses a thread pool at the I/O boundary only. |

---

## 15. Test strategy

One test module per source module. Integration tests in `tests/integration/`.

**Unit test targets (the ones that matter most):**
- `compute/indicators.py` — each indicator tested against hand-computed expected output on small fixtures.
- `compute/engine.py` — round-trip: input DataFrame → enriched DataFrame has every SignalState column; `extract_state` returns a populated dataclass.
- `context/*` — each provider tested with a mock data source; assert field values for known inputs.
- `strategies/*` — each strategy tested with constructed `SignalState` + `ContextBundle`; assert fire / no-fire across boundary cases.
- `conviction/formula.py` — each contribution function tested independently.
- `conviction/grade_engine.py` — golden fixture replay.
- `conviction/verdict.py`, `sizing.py` — boundary conditions tested exhaustively.
- `data/nse_client.py` — cookie scope isolation, cooldown on failure, rate-limit spacing.

**Integration tests:**
- End-to-end scan on a locked, offline dataset. Fixtures of 10 symbols × 500 bars + cached contexts. Assert the resulting `Conviction` list matches a committed snapshot.
- Live-vs-backtest parity: for a sampled date, build contexts two ways (live providers with cache frozen; backtest providers reading the same cache); assert identical `Conviction`.

**What CI runs:**
- Unit tests.
- Golden fixture replay.
- Integration tests on offline data.
- `validate_grade_formula.py` as a CI step.

**What CI does not run:**
- Live NSE fetches. Those are manual smoke tests after major data-layer changes.

---

## 16. Phased build plan

Each phase produces a working, testable slice. No phase ships without green tests.

### Phase 0 — Scaffolding (half a day)
- Create `nimbus_v3/` skeleton with `pyproject.toml`, package directories, empty `__init__.py` files.
- Copy `.gitignore`, configure pytest.
- Stand up `docs/ARCHITECTURE.md` (this document, committed as the living spec).

### Phase 1 — Core + Compute + Universe (3-4 days)
- Write `core/signal_state.py`, `core/types.py` fresh against v3 interfaces (v2's design is reference only).
- Write `compute/indicators.py`, `compute/engine.py`, `compute/vix_regime.py` fresh.
- Write `data/cache.py`, `data/price_loader.py`, `data/vix_loader.py` fresh.
- Write `data/nse_client.py` fresh, with v2's cookie-isolation and cooldown patterns as the design reference.
- Write `data/universe.py` — the NSE-index-driven universe + sector builder (per §18.1).
- Write `data/deals_loader.py` (block/bulk/SAST/insider feeds).
- Unit tests for every module.
- **Milestone:** can build a `Universe`, enrich a DataFrame for any symbol in it, and extract a `SignalState`.

### Phase 2 — Contexts (4-5 days)
- Write `context/base.py` with `ContextProvider` protocol.
- Implement `MarketContextProvider`, `SectorContextProvider` — both are pure transforms of already-cached data plus the `Universe` object.
- Implement `data/options_loader.py` + `context/options_context.py` (GEX, walls, HVL, max-pain, PCR, IVR, DTE, pin-risk).
- Implement `data/filings_loader.py` + `context/filing_context.py` (fetch is separate from impact classification).
- Implement `FlowContextProvider`, `EventContextProvider`, `DealContextProvider`.
- Tests for each provider, including `asof_date` historical reconstruction.
- **Milestone:** can assemble a `ContextBundle` for any (symbol, asof_date).

### Phase 3 — Strategies (3 days)
- Write `strategies/base.py` protocol and `strategies/registry.py`.
- Implement `mean_reversion.py` using v2's walk-forward-validated rule pair as the starting thresholds.
- Implement `breakout.py` using v2's validated rule pair as the starting thresholds.
- Implement `ride.py` — the BB Ride logic (riding upper 1σ + W%R momentum).
- Implement `etf_momentum.py` — one coherent strategy module (oracle's five ETF files collapse into this one).
- Implement `trap.py` — filing-driven override, highest priority.
- Each strategy declares `required_contexts`.
- Unit tests for fire / no-fire boundaries on every strategy.
- **Milestone:** every registered strategy emits `StrategySignal` correctly from constructed state + contexts.

### Phase 4 — Conviction (3 days) ← the heart of v3
- Write `conviction/formula.py` with each contribution function as a pure, tested unit.
- Write `conviction/grade_engine.py` — `ConvictionEngine` + composition.
- Write `conviction/verdict.py`, `conviction/sizing.py`.
- Build `conviction/fixtures/golden.json` — initial 100 quadruples, hand-reviewed.
- Ship `scripts/validate_grade_formula.py`.
- **Milestone:** `ConvictionEngine.grade(...)` is the single grading authority. `validate_grade_formula.py` is green in CI.

### Phase 5 — Events + Scanner (2 days)
- Write `events/bus.py`.
- Write `scanner/scan_engine.py` orchestrating the full pipeline.
- Write `scripts/scan.py` CLI.
- Write `scripts/print_conviction.py` CLI (grade one symbol, print every contribution).
- **Milestone:** `python -m scripts.scan --universe nifty200` prints graded results for the universe, headless.

### Phase 6 — Tracking + Commentary (1-2 days)
- Write `tracking/store.py` (SQLite).
- Write `tracking/signal_tracker.py` subscribing to `SymbolGraded`.
- Write `tracking/commentary.py`.
- **Milestone:** scans persist signals; historical signals are queryable.

### Phase 7 — Research layer + strategy validation (3-4 days)
- Write `research/entry_config.py`, `entry_evaluator.py`, `forward_returns.py`, `sweep_runner.py`, `cluster_analyzer.py`, `cluster_quality_filter.py` fresh against v3 interfaces.
- Write `walk_forward.py` with purging + embargo (v2's WF is non-purged; v3's is stricter).
- Write `deflated_sharpe.py`.
- **Run walk-forward validation against every shipped strategy** (MR, BO, Ride, ETF, TRAP) on v3's universe. Record per-fold Sharpe, alpha vs benchmark, win rate, decay flags.
- **Validate each grade-formula contribution** carried in spirit from oracle (per §18.8). Contributions that don't replicate on v3's universe get zeroed-out or dropped.
- Publish the Phase 7 research note under `docs/research_notes/`.
- **Milestone:** every strategy and every contribution in the live pipeline has a committed walk-forward result backing it.

### Phase 8 — UI (4-5 days)
- Write `events/qt_bridge.py`.
- Write `ui/app.py`, splash, main window, tab container.
- Implement Dashboard tab with all six panels, consuming `Conviction`.
- Implement Signals tab reading from the tracker store.
- Implement Filings tab.
- Implement Research tab (filesystem browser).
- **Milestone:** end-to-end terminal launches, runs a scan, displays graded rows.

### Phase 9 — Hardening (1 week, rolling)
- Run the full suite on live data daily for a week.
- Fix any drift between live and backtest (there should be zero, but reality tests the assertion).
- Finalize `docs/GRADE_FORMULA.md` and `docs/NSE_ENDPOINTS.md` as living references.

**Total estimate:** 20-25 focused working days to ship a terminal at feature parity with oracle minus the dropped components, plus the unified pipeline and research-live parity guarantees.

---

## 17. Risk register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Grade formula regresses silently during port | High | High | Golden fixture file + CI validation script + per-contribution unit tests. |
| Live/backtest drift re-emerges | Medium | High | Single `ConvictionEngine`; mandatory `asof_date` on every provider; parity integration test in CI. |
| NSE endpoint changes breaking client | Medium | Medium | `docs/NSE_ENDPOINTS.md` as living contract; one client, one place to fix. |
| Port of oracle filings logic introduces bugs | Medium | Medium | Split fetch from classification; unit-test classification against a recorded fixture of known filings. |
| Context-provider explosion (too many providers) | Low | Medium | Each provider must justify its existence with a contribution in the formula. Unused contexts get deleted. |
| UI becomes stateful and starts computing | Medium | High | Code review rule: any UI module importing from `compute/`, `context/`, `strategies/`, `conviction/` below `core/` is rejected. |
| Overfitting via grade-formula tweaks | Ongoing | High | Every formula change runs through the golden fixture + deflated Sharpe check on OOS. Changes land with research notes. |
| Scanner parallelism reintroduces NSE cookie issues | Low | High | Scan orchestrator uses thread pool but all NSE calls serialize through the single client's endpoint-scoped cookie jar, which is already thread-safe per v2. |

---

## 18. Decisions locked

All ten open questions from the review draft are resolved. Locked decisions below; each drives concrete code in the phases that follow.

### 18.1 Universe and sector mapping — resolved

**Decision:** `data/universe.py` is the single builder. It fetches constituent lists from NSE's sectoral-index and broad-market-index endpoints in one coordinated pass, dedupes across indices, and emits a `Universe` object that contains both the tradable symbol set and a symbol→sector map derived from which sectoral index each symbol appears in.

Implications:
- No hard-coded `_INDUSTRY_SECTOR` dictionary anywhere in v3. Oracle's 128-entry map does not migrate.
- Sector membership is data, not code. When NSE adds a stock to NIFTY FMCG, v3 picks it up on the next universe refresh.
- The same builder fetches the ETF universe via NSE's ETF endpoint. ETFs are carried as a separate slice of the `Universe` object with their own metadata (AUM, liquidity, tracking index).
- Cached as a parquet file with a configurable TTL (default: 1 trading day).
- Refreshed on scanner startup and via a manual "reload universe" action in the UI.

The Dashboard scanner has a dropdown to filter to any named slice of the universe: NIFTY 50 / 100 / 200 / 500 / F&O / ETF / any sector index (NIFTY BANK, NIFTY IT, etc.). All slices are views over the same `Universe` object — no parallel universes, no duplicate symbol lists.

**Universe class sketch:**
```python
@dataclass(frozen=True)
class SymbolMeta:
    symbol: str
    sector: str              # from sectoral index membership
    industry: str            # finer-grained if NSE provides it
    indices: frozenset[str]  # which named indices contain this symbol
    is_fno: bool
    is_etf: bool
    etf_meta: ETFMeta | None = None   # AUM, tracking index, ...

@dataclass(frozen=True)
class Universe:
    symbols: Mapping[str, SymbolMeta]
    built_at: pd.Timestamp
    def slice(self, index_name: str) -> list[str]: ...
    def etfs(self) -> list[str]: ...
    def by_sector(self, sector: str) -> list[str]: ...
```

This replaces oracle's `index_constituents.py`, `sector_map.py`, and `etf_universe.py` with one builder.

### 18.2 Multi-strategy fires on the same bar — resolved

**Decision:** the scan produces one `Conviction` per `StrategySignal`. A symbol that fires MR and BO on the same bar appears twice in the graded output — once per strategy, each with its own conviction. The UI can choose to collapse by strategy priority for the default row-table view, but the underlying data preserves every fire.

Rationale:
- More informative for research (cluster analysis can see both signals).
- Prevents silent loss of a lower-priority fire during a cross-strategy overlap.
- Tracker persistence keeps every `Conviction`; outcome analysis later can correlate strategy overlap with realised return.
- UI collapse is a pure presentation rule, easily changed.

### 18.3 Conviction immutability and outcome tracking — resolved

**Decision:** `Conviction` is a frozen dataclass. Once published, it never changes. Realised outcomes live in a separate `SignalOutcome` record keyed by `conviction_id`.

```python
@dataclass(frozen=True)
class Conviction:
    conviction_id: str          # deterministic hash of (symbol, strategy, timestamp)
    symbol: str
    strategy: str
    timestamp: pd.Timestamp
    score: int
    grade: GradeLetter
    verdict: Verdict
    sizing: Sizing
    contributions: tuple[Contribution, ...]
    reasons: tuple[str, ...]
    signal: StrategySignal

@dataclass(frozen=True)
class SignalOutcome:
    conviction_id: str
    observed_at: pd.Timestamp
    forward_return_5d: float
    forward_return_10d: float
    forward_return_20d: float
    peak_20d: float
    trough_20d: float
    realised_sizing: Sizing | None = None   # populated only if paper-tracked
```

The tracker's SQLite schema has two tables: `convictions` (immutable) and `signal_outcomes` (append-only, backfilled as forward returns become measurable).

### 18.4 Formula spec location — resolved

**Decision:** the formula lives in three places, each with a defined role. When they disagree, a specific one wins.

| Artifact | Role | Authority when they disagree |
|---|---|---|
| `conviction/formula.py` | Implementation | The golden fixtures test it |
| `docs/GRADE_FORMULA.md` | Human-readable spec with worked examples | Refreshed from code + fixtures when they change |
| `conviction/fixtures/golden.json` | 100 `(state, contexts, signal) → Conviction` quadruples | **Authoritative** — fixtures are the definition of correct. Changing the formula requires updating fixtures in the same commit. |

Workflow: a proposed formula change updates `formula.py`, regenerates the relevant fixture entries (with manual review), updates the doc. CI fails if `validate_grade_formula.py` finds fixture mismatches or if fixtures are updated without a corresponding code or doc change (enforced by commit-time check).

### 18.5 Store migration — resolved

**Decision:** nothing migrates. v3 starts with empty stores. Already covered in §3.4.

### 18.6 CLI and tracker — resolved

**Decision:** the CLI subscribes to the same event bus as the UI. `scripts/scan.py` instantiates the scanner, the tracker, and a console-logging subscriber; persistence happens identically to the UI path. The tracker is Qt-free (already guaranteed by the event-bus design), so the CLI runs without PyQt installed.

This means a headless nightly scan on a server persists signals into the same SQLite store the UI consumes the next day. Single store, two entry points, same writes.

### 18.7 Drop `publish/` entirely — resolved

**Decision:** removed from v3. Not ported. Research outputs (sweep reports, cluster details, walk-forward reports) are plain CSV/text written by the research harnesses and browsed from the Research tab.

### 18.8 Sector-vol EXTREME contribution — deferred to research

**Decision:** not ported blindly. The contribution function `sector_vol_contribution(sector_ctx, market_ctx)` is written with a placeholder returning zero. During Phase 7 research, the v3 walk-forward harness tests the oracle-derived rule (`+2 for EXTREME sector vol during PANIC/ELEVATED VIX`) against the v3 universe and OOS windows. If the OOS alpha replicates, the contribution lands with golden-fixture coverage. If it doesn't replicate, we drop it rather than carry an unvalidated rule.

Same principle applies to every contribution carried from oracle's grade formula: each gets re-validated on v3's universe and walk-forward. Contributions that don't replicate don't ship.

### 18.9 Intraday bars — out of scope for v3.0

**Decision:** v3 is daily-only. VIX streaks, sector RS windows, filing timestamps, and the walk-forward semantics all assume daily bars. Intraday is a v3.1+ conversation.

### 18.10 Package name — resolved

**Decision:** `nimbus_v3` throughout development and at production release. Isolated from oracle and v2 forever. No rename. When oracle is retired, it's retired; v3 doesn't take its name.

---

## 19. Phase 0 readiness checklist

With all decisions locked, the preconditions for starting Phase 0:

- [ ] This document committed as `nimbus_v3/docs/ARCHITECTURE.md` at first commit.
- [ ] `pyproject.toml` drafted with deps: `numpy`, `pandas`, `pyarrow`, `yfinance`, `requests`, `PyQt6`. No others yet.
- [ ] `.gitignore` for `data/`, `__pycache__`, `.venv`, `*.pyc`.
- [ ] Empty package skeleton created per §5.
- [ ] `tests/` skeleton with pytest config.
- [ ] Golden fixture file `conviction/fixtures/golden.json` committed empty (populated in Phase 4).
- [ ] CI config drafted (lint + pytest on push).

Once these are green, Phase 1 begins: core + compute + basic data layer.

---

*End of roadmap. All decisions locked. Ready to cut scaffolding.*
