"""nimbus_v3.ui.presenters.workflow_presenter — Workflow Analysis panel
view model builder.

The Workflow Analysis rail renders one interpretive sentence per
section combining raw numbers with a short verdict read — matching
the pattern the operator internalised from oracle ("VIX 17.2 →
NORMAL — 68% win rate, choppy zone"). That interpretation is
business logic, not rendering, and lives here.

Structure mirrors :mod:`sidebar_presenter`:
    * A frozen :class:`WorkflowView` dataclass of ``(text, color)``
      pairs — one pair per section.
    * :func:`build_workflow_view` pure function over
      ``(state, contexts, results)``.
    * Threshold constants declared at module top.

Section coverage (oracle parity, in the same order):
    TREND & STATE / VIX REGIME / SECTOR CONTEXT / VOL CONTEXT /
    GEX REGIME / OI WALLS / EXPIRY / WILLIAMS %R / MFI FLOW /
    OPTIONS IMPACT / FILING IMPACT / BB RIDE / RISK NOTES.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.ui.theme import EM, GOLD, GREEN, MUTED, RED, WHITE


# ══════════════════════════════════════════════════════════════════════════════
# Threshold constants — see oracle's study notes where referenced.
# ══════════════════════════════════════════════════════════════════════════════

#: VIX regime → (win-rate string, sharpe string, colour) from oracle
#: backtest notes. Kept here because this is a display interpretation,
#: not an engine threshold.
_VIX_NARRATIVE: dict[str, tuple[str, str, str]] = {
    "PANIC":    ("97% win rate", "Sh 10.15", EM),
    "ELEVATED": ("80% win rate, strong bounce zone", "Sh 2.95", GOLD),
    "LOW":      ("78% win rate, clean orderly MRs", "Sh 2.30", GREEN),
    "NORMAL":   ("68% win rate, choppy zone", "Sh 0.60", MUTED),
}

#: RS regime → colour mapping.
_RS_COLORS: dict[str, str] = {
    "LEADING": EM, "IMPROVING": GREEN,
    "LAGGING": RED, "WEAKENING": GOLD,
}

#: ADX bands for W%R commentary.
_ADX_STRONG = 25

#: BBW percentile bands for vol context verdict.
_BBW_EXPANDED = 70        # > P70 → above-average vol
_BBW_COMPRESSED = 20      # < P20 → compression (watch for breakout)


# ══════════════════════════════════════════════════════════════════════════════
# ViewModel
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class _TextPair:
    text: str
    color: str


_EMPTY = _TextPair("—", MUTED)


@dataclass(frozen=True)
class WorkflowView:
    """Pre-formatted one-pair-per-section view of the Workflow rail."""
    trend_state: _TextPair
    vix_regime: _TextPair
    sector_context: _TextPair
    vol_context: _TextPair
    gex_regime: _TextPair
    oi_walls: _TextPair
    expiry: _TextPair
    williams_r: _TextPair
    mfi_flow: _TextPair
    options_impact: _TextPair
    filing_impact: _TextPair
    bb_ride: _TextPair
    risk_notes: _TextPair


EMPTY_WORKFLOW_VIEW: WorkflowView = WorkflowView(
    trend_state=_EMPTY, vix_regime=_EMPTY, sector_context=_EMPTY,
    vol_context=_EMPTY, gex_regime=_EMPTY, oi_walls=_EMPTY,
    expiry=_EMPTY, williams_r=_EMPTY, mfi_flow=_EMPTY,
    options_impact=_EMPTY, filing_impact=_EMPTY, bb_ride=_EMPTY,
    risk_notes=_EMPTY,
)


# ══════════════════════════════════════════════════════════════════════════════
# Section builders — each returns a _TextPair. Keeping them separate
# makes unit testing straightforward: feed mock state/contexts and
# assert on the generated text per section.
# ══════════════════════════════════════════════════════════════════════════════

def _build_trend_state(state: SignalState | None) -> _TextPair:
    if state is None:
        return _EMPTY
    # Oracle: "Mean reversion · WR(30)=-23 · +4.2% vs SMA · MFI=63 · RSI=67"
    mode = "Mean reversion" if state.wr_30 < -50 else (
        "Oversold" if state.wr_30 < -80 else (
            "Trending up" if state.pct_from_sma_20 > 2 and state.adx_14 >= _ADX_STRONG else "Neutral"
        )
    )
    return _TextPair(
        f"{mode} · WR(30)={state.wr_30:.0f} · {state.pct_from_sma_20:+.1f}% vs SMA · "
        f"MFI={state.mfi_14:.0f} · RSI={state.rsi_14:.0f}",
        WHITE,
    )


def _build_vix_regime(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.market is None:
        return _TextPair("VIX data unavailable — sizing gate disabled", MUTED)
    m = contexts.market
    if m.vix_regime is None:
        return _TextPair("VIX data unavailable — sizing gate disabled", MUTED)
    regime = m.vix_regime.value
    vix_val = m.vix_value
    if vix_val is None:
        return _TextPair(f"VIX — → {regime}", MUTED)
    narrative = _VIX_NARRATIVE.get(regime)
    if narrative is None:
        return _TextPair(f"VIX {vix_val:.1f} → {regime}", MUTED)
    win_rate, sharpe, color = narrative
    extra = ". Low-conviction entries gated" if regime == "NORMAL" else ""
    return _TextPair(
        f"VIX {vix_val:.1f} → {regime} — {win_rate}{extra} ({sharpe})",
        color,
    )


def _build_sector_context(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.sector is None:
        return _TextPair("No sector data — stock not in index", MUTED)
    s = contexts.sector
    industry = s.industry or s.sector_name or "Unknown"
    rotation = s.rs_regime.value if s.rs_regime is not None else "UNKNOWN"
    sector_type = s.sector_type.value if s.sector_type is not None else None
    parts = [industry]
    if sector_type:
        parts.append(sector_type)
    if rotation != "UNKNOWN":
        parts.append(rotation)
    parts.append(f"RS 20d {s.rs_20d:+.2f}%")
    color = _RS_COLORS.get(rotation, MUTED)
    return _TextPair(" · ".join(parts), color)


def _build_vol_context(contexts: ContextBundle | None, state: SignalState | None) -> _TextPair:
    # Oracle blends two signals: sector realised vol + BBW percentile.
    if state is None and (contexts is None or contexts.sector is None):
        return _EMPTY
    pctl = getattr(state, "bbw_20_2s_pctl", None) if state else None
    sector_txt = ""
    if contexts is not None and contexts.sector is not None:
        s = contexts.sector
        vz_str = f"z {s.vol_z_score:+.2f}" if s.vol_z_score is not None else "z —"
        sector_txt = f"sector vol 20d {s.realized_vol_20d:.1f}% ({vz_str})"

    if pctl is None:
        return _TextPair(sector_txt or "—", MUTED) if sector_txt else _EMPTY
    # Normalise pctl — engine outputs 0..1 or 0..100 depending on path.
    pctl_pct = pctl * 100 if 0 <= pctl <= 1.5 else pctl
    if pctl_pct >= _BBW_EXPANDED:
        bbw_verdict = "expanded — above-average vol, healthy MR setup"
        color = GREEN
    elif pctl_pct < _BBW_COMPRESSED:
        bbw_verdict = "compressed — watch for breakout"
        color = GOLD
    else:
        bbw_verdict = "normal"
        color = MUTED
    bbw_txt = f"BBW pctl {pctl_pct:.0f} ({bbw_verdict})"
    text = f"{bbw_txt}  ·  {sector_txt}" if sector_txt else bbw_txt
    return _TextPair(text, color)


def _build_gex_regime(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.options is None:
        return _EMPTY
    o = contexts.options
    if o.gex_regime is None and o.net_gex is None:
        return _TextPair("GEX data unavailable", MUTED)
    regime = o.gex_regime.value if o.gex_regime is not None else "UNKNOWN"
    gex_m = (o.net_gex / 1e6) if o.net_gex is not None else None
    # Oracle: "GEX Positive (88,446M) → Pins toward 24,200 → Momentum dampened, mean reversion favored"
    parts: list[str] = []
    if gex_m is not None:
        sign = "Positive" if gex_m > 0 else "Negative"
        parts.append(f"GEX {sign} ({gex_m:+,.0f}M)")
    if o.max_pain is not None:
        parts.append(f"→ Pins toward {o.max_pain:,.0f}")
    if gex_m is not None:
        verdict = ("Momentum dampened, mean reversion favored" if gex_m > 0
                   else "Momentum amplified, trend continuation")
        parts.append(f"→ {verdict}")
    color = GREEN if (gex_m is not None and gex_m > 0) else RED if gex_m is not None else MUTED
    return _TextPair(" ".join(parts) or regime, color)


def _build_oi_walls(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.options is None:
        return _EMPTY
    o = contexts.options
    parts: list[str] = []
    if o.resistance_wall is not None:
        pct = f" ({o.pct_to_resistance:+.1f}%)" if o.pct_to_resistance is not None else ""
        parts.append(f"Resistance {o.resistance_wall:,.0f}{pct}")
    if o.support_wall is not None:
        pct = f" ({o.pct_to_support:+.1f}%)" if o.pct_to_support is not None else ""
        parts.append(f"Support {o.support_wall:,.0f}{pct}")
    if not parts:
        return _TextPair("No sizable OI walls nearby", MUTED)
    joined = " | ".join(parts)
    # Verdict — do we have room to trade into the level?
    room_ok = (
        (o.pct_to_resistance is None or abs(o.pct_to_resistance) > 1.0) and
        (o.pct_to_support is None or abs(o.pct_to_support) > 1.0)
    )
    verdict = " → Adequate structural room" if room_ok else " → Walls compressed"
    return _TextPair(f"{joined}{verdict}", WHITE if room_ok else GOLD)


def _build_expiry(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.options is None:
        return _EMPTY
    o = contexts.options
    parts = [f"Expiry {o.dte}d"]
    if o.expiry_risk is not None:
        parts.append(f"→ {o.expiry_risk.value} pin risk")
    if o.max_pain is not None:
        parts.append(f"→ max pain {o.max_pain:,.0f}")
    if o.dte <= 2:
        parts.append("→ Wait post-expiry")
        color = GOLD
    elif o.dte <= 5:
        parts.append("→ Compressing into expiry")
        color = GOLD
    else:
        color = WHITE
    return _TextPair(" ".join(parts), color)


def _build_williams_r(state: SignalState | None) -> _TextPair:
    if state is None:
        return _EMPTY
    # Oracle: "WR(30) -23 → Not oversold → Wait for pullback"
    wr = state.wr_30
    if wr < -80:
        verdict, color = "Oversold → MR entry zone", EM
    elif wr < -50:
        verdict, color = "Approaching oversold", GREEN
    elif wr > -20:
        verdict, color = "Overbought → Avoid longs", RED
    else:
        verdict, color = "Not oversold → Wait for pullback", MUTED
    return _TextPair(
        f"WR14 {state.wr_14:.0f}  WR20 {state.wr_20:.0f}  "
        f"WR30 {wr:.0f}  WR50 {state.wr_50:.0f} → {verdict}",
        color,
    )


def _build_mfi_flow(state: SignalState | None) -> _TextPair:
    if state is None:
        return _EMPTY
    mfi = state.mfi_14
    slope = state.mfi_slope_3
    if mfi >= 70:
        verdict, color = "Overbought — distribution risk", RED
    elif mfi >= 50 and slope > 1:
        verdict, color = "Strong flow — high conviction", EM
    elif mfi >= 50:
        verdict, color = "Healthy flow", GREEN
    elif mfi < 30:
        verdict, color = "Capitulation — accumulation zone", GREEN
    else:
        verdict, color = "Weak flow — neutral", MUTED
    arrow = "▲" if slope > 1 else ("▼" if slope < -1 else "→")
    return _TextPair(
        f"MFI {mfi:.0f} {arrow} slope3 {slope:+.1f} — {verdict}",
        color,
    )


def _build_options_impact(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.options is None:
        return _EMPTY
    o = contexts.options
    parts: list[str] = []
    if o.pcr_oi is not None:
        bias = "bullish" if o.pcr_oi < 0.8 else "bearish" if o.pcr_oi > 1.3 else "balanced"
        parts.append(f"PCR {o.pcr_oi:.2f} ({bias})")
    if o.net_gex is not None:
        gex_m = o.net_gex / 1e6
        dealer = "dampened" if gex_m > 0 else "amplified"
        parts.append(f"GEX positive ({dealer})" if gex_m > 0 else f"GEX negative ({dealer})")
    if o.iv_atm is not None:
        parts.append(f"IV {o.iv_atm:.1f}%")
    if not parts:
        return _TextPair("—", MUTED)
    return _TextPair(f"Options → {' | '.join(parts)}", WHITE)


def _build_filing_impact(contexts: ContextBundle | None) -> _TextPair:
    if contexts is None or contexts.filing is None:
        return _TextPair("Filing → No filing", MUTED)
    f = contexts.filing
    blocking = getattr(f, "is_blocking", False) or getattr(f, "blocking_filing", False)
    count = getattr(f, "recent_filings", None) or getattr(f, "count_7d", 0)
    if blocking:
        return _TextPair(f"Filing → ⚠ blocking disclosure pending", RED)
    if isinstance(count, int) and count > 0:
        return _TextPair(f"Filing → {count} in 7d — monitor for surprises", GOLD)
    return _TextPair("Filing → No filing", MUTED)


def _build_bb_ride(state: SignalState | None) -> _TextPair:
    if state is None:
        return _EMPTY
    bb_pct = state.bb_20_1s_pct
    # Oracle: "RIDING — %B=1.29, above trail stop | Trail 22,915 · Mid 23,364 · PT 26,789"
    if bb_pct >= 1.0:
        status, color = "RIDING — at upper band", EM
    elif bb_pct >= 0.85:
        status, color = "NEAR UB — watch for breakout", GOLD
    elif bb_pct >= 0.5:
        status, color = "MID-BAND — no ride setup", MUTED
    else:
        status, color = "LOWER HALF — ride broken", RED
    trail = state.bb_20_1s_mid
    mid = state.bb_20_1s_mid
    ub = state.bb_20_1s_upper
    return _TextPair(
        f"{status}  ·  %B {bb_pct:.2f}  ·  UB {ub:,.0f} / Mid {mid:,.0f}",
        color,
    )


def _build_risk_notes(notes: Iterable[str]) -> _TextPair:
    notes = list(notes)
    if not notes:
        return _TextPair("No blocking risks", MUTED)
    return _TextPair(f"{len(notes)} active risk(s): {' · '.join(notes[:2])}", RED)


# ══════════════════════════════════════════════════════════════════════════════
# Main entry point
# ══════════════════════════════════════════════════════════════════════════════

def build_workflow_view(
    state: SignalState | None,
    contexts: ContextBundle | None,
    results: Iterable[ScanResult] = (),
    risk_notes: Iterable[str] = (),
) -> WorkflowView:
    """Compose all 13 workflow sections from the signal pipeline's
    outputs. ``results`` is accepted for future section additions
    that might branch on strategy-specific grade detail — the
    current sections read only state + contexts + risk_notes."""
    _ = results    # noqa: F841 — reserved for future strategy-specific branches
    return WorkflowView(
        trend_state=_build_trend_state(state),
        vix_regime=_build_vix_regime(contexts),
        sector_context=_build_sector_context(contexts),
        vol_context=_build_vol_context(contexts, state),
        gex_regime=_build_gex_regime(contexts),
        oi_walls=_build_oi_walls(contexts),
        expiry=_build_expiry(contexts),
        williams_r=_build_williams_r(state),
        mfi_flow=_build_mfi_flow(state),
        options_impact=_build_options_impact(contexts),
        filing_impact=_build_filing_impact(contexts),
        bb_ride=_build_bb_ride(state),
        risk_notes=_build_risk_notes(risk_notes),
    )


__all__ = (
    "EMPTY_WORKFLOW_VIEW",
    "WorkflowView",
    "build_workflow_view",
)
