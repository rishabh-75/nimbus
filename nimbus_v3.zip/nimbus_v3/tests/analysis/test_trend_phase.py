"""tests.analysis.test_trend_phase — classifier logic verification.

Each test case is a canonical market scenario a trader would
intuitively classify one particular way. These tests pin the
classifier's agreement with that intuition at the current default
thresholds. If the thresholds are retuned via
``scripts/run_phase_calibration.py``, some edge-case assertions may
need adjusting — but the directional relationships (EUPHORIA riskier
than MID, etc.) should hold.
"""
from __future__ import annotations

from nimbus_v3.analysis.trend_phase import (
    TrendPhase, classify_phase, quality_adjusted_rank,
)


class TestClassifyPhase:

    def test_parabolic_blow_off(self):
        """SUZLON-like state: way above SMA_50, accelerating, BB outside band → EUPHORIA."""
        r = classify_phase(
            close=52.93, sma_20=48.0, sma_50=43.5,    # +21.7% above SMA_50
            roc_5=19.67, roc_20=29.07,                # roc_accel = -9.4 (decelerating)
            bb_pct=1.84,                              # way outside
        )
        # Even with decelerating ROC, BB parabolic triggers EUPHORIA
        assert r.phase == TrendPhase.EUPHORIA
        assert r.snapback_risk >= 7.0, f"risk too low: {r.snapback_risk}"

    def test_late_cycle_stretched(self):
        """Above SMA_50 by 14%, BB stretched but not parabolic → LATE."""
        r = classify_phase(
            close=114.0, sma_20=108.0, sma_50=100.0,  # +14% above SMA_50
            roc_5=8.0, roc_20=10.0,                   # slight decel
            bb_pct=1.05,                              # just outside upper band
        )
        assert r.phase == TrendPhase.LATE
        assert 4.0 <= r.snapback_risk <= 7.5, f"mid-range risk expected: {r.snapback_risk}"

    def test_healthy_mid_trend(self):
        """SIEMENS-like: above both SMAs, ~7% extension, steady ROC, BB inside → MID."""
        r = classify_phase(
            close=107.0, sma_20=104.0, sma_50=100.0,  # +7% above SMA_50
            roc_5=6.0, roc_20=6.5,                    # roc_accel ≈ 0
            bb_pct=0.65,                              # mid-channel
        )
        assert r.phase == TrendPhase.MID
        assert r.snapback_risk <= 3.5, f"mid trend should be low-risk: {r.snapback_risk}"

    def test_fresh_breakout(self):
        """Just crossed both SMAs, tiny extension → EARLY."""
        r = classify_phase(
            close=101.5, sma_20=100.5, sma_50=100.0,  # +1.5% above SMA_50 (below healthy=3%)
            roc_5=4.0, roc_20=1.0,                    # accelerating from lows
            bb_pct=0.75,                              # inside bands
        )
        assert r.phase == TrendPhase.EARLY
        assert r.snapback_risk <= 3.0

    def test_downtrend(self):
        """Below both SMAs → DECLINE regardless of other features."""
        r = classify_phase(
            close=90.0, sma_20=95.0, sma_50=100.0,    # -10%
            roc_5=-2.0, roc_20=-5.0, bb_pct=0.1,
        )
        assert r.phase == TrendPhase.DECLINE
        assert r.snapback_risk == 0.0, "no snap-back risk on downtrends"

    def test_neutral_chop(self):
        """Below SMA_50 but above SMA_20 → NEUTRAL (mixed signals)."""
        r = classify_phase(
            close=99.5, sma_20=99.0, sma_50=100.0,
            roc_5=0.5, roc_20=-0.5, bb_pct=0.55,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_degenerate_zero_sma(self):
        """Zero / negative SMA shouldn't crash — returns NEUTRAL."""
        r = classify_phase(
            close=100.0, sma_20=0.0, sma_50=0.0,
            roc_5=0.0, roc_20=0.0, bb_pct=0.5,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_risk_monotonic_in_extension(self):
        """Holding other features constant, risk should increase with extension."""
        def risk_at(ext_pct: float) -> float:
            return classify_phase(
                close=100 + ext_pct, sma_20=100, sma_50=100,
                roc_5=5.0, roc_20=5.0, bb_pct=0.7,
            ).snapback_risk

        risks = [risk_at(e) for e in (2, 6, 10, 14, 18, 22)]
        # Monotonically non-decreasing
        for a, b in zip(risks, risks[1:]):
            assert b >= a, f"risk should not decrease as extension grows: {risks}"

    def test_phase_progression(self):
        """As extension grows (other features fixed-healthy), phase should walk EARLY→MID→LATE→EUPHORIA."""
        def phase_at(ext_pct: float, accel: float = 2.0, bb: float = 0.7) -> TrendPhase:
            close = 100 + ext_pct
            return classify_phase(
                close=close, sma_20=98, sma_50=100,
                roc_5=5.0 + accel, roc_20=5.0, bb_pct=bb,
            ).phase

        assert phase_at(1.0) == TrendPhase.EARLY
        assert phase_at(6.0) == TrendPhase.MID
        assert phase_at(14.0) == TrendPhase.LATE
        # Euphoria needs ext >= 18 AND (accel>0 OR bb>=1.1) — provide accel
        assert phase_at(20.0, accel=3.0, bb=0.9) == TrendPhase.EUPHORIA


class TestQualityAdjustedRank:

    def test_penalty_is_applied(self):
        """High composite + high snapback should rank LOWER than lower composite + low snapback
        if the delta exceeds the composite gap — this is the whole point."""
        suzlon_like = quality_adjusted_rank(composite=16.89, snapback_risk=7.0)
        siemens_like = quality_adjusted_rank(composite=12.31, snapback_risk=3.0)
        # SUZLON: 9.89, SIEMENS: 9.31 — still close but the gap narrowed from 4.58 → 0.58
        assert suzlon_like > siemens_like       # still wins but barely
        assert (suzlon_like - siemens_like) < (16.89 - 12.31) / 2, \
            "penalty should meaningfully close the gap"

    def test_low_composite_low_risk_can_win(self):
        """A 'boring' stock with a great quality profile should rank ABOVE a parabolic one
        when the risk gap is large enough."""
        parabolic = quality_adjusted_rank(composite=15.0, snapback_risk=9.0)   # 6.0
        healthy = quality_adjusted_rank(composite=9.0, snapback_risk=1.0)      # 8.0
        assert healthy > parabolic



# ═══════════════════════════════════════════════════════════════════════════════
# Quality-gate tests — ablation-validated behaviours only
# ═══════════════════════════════════════════════════════════════════════════════
#
# Tests here pin the FOUR gates that survived empirical validation
# against 569k historical rows (see scripts/run_gate_ablation.py and
# data/gate_ablation.csv):
#
#   - ROC_20 < -3%      on EUPHORIA      (Δ=-1.60pp, t=-1.68)
#   - distribution      on EUPHORIA      (Δ=-2.03pp, t=-2.14)
#   - ROC_20 < -2%      on LATE          (Δ=-1.22pp, t=-5.84, strongest)
#   - v_recovery        on LATE          (Δ=-0.38pp, t=-2.14)
#
# MID and EARLY are PURE EXTENSION assignment — no quality gates. An
# earlier version of this test file encoded six MID gates and five
# EARLY gates derived from chart-reading intuition; ablation showed
# two were actively harmful (flagging future winners at +0.55pp,
# t=+10.33) and the rest were noise. Those tests were deleted along
# with the gates they protected.
#
# This file intentionally INCLUDES negative tests for the dropped
# gates (test_*_stays_mid_post_ablation) — those pin the new
# behaviour and regression-guard against re-introducing rejected
# gates from memory.


class TestSurvivingQualityGates:
    """The four gates the ablation validated as earning real edge."""

    # ── EUPHORIA: ROC_20 < -3% ─────────────────────────────────────────

    def test_euphoria_roc20_grinding_routes_neutral(self):
        """Parabolic stock with ROC_20 < -3% → NEUTRAL.
        Ablation: -1.60pp delta, t=-1.68, n=184. Weak working, kept
        conservatively because the direction and effect size are
        meaningful even at borderline t-stat."""
        r = classify_phase(
            close=120.0, sma_20=118.0, sma_50=100.0,    # ext=20% (euphoric)
            roc_5=-2.0, roc_20=-5.0, bb_pct=1.15,       # parabolic + grinding
            roc_10=-3.0, vol_chg_20=0.0,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_euphoria_mild_dip_stays_euphoria(self):
        """Parabolic stock with ROC_20 between -3% and 0% → still EUPHORIA.
        The gate floor is -3%, not -2% — parabolic stocks tolerate more
        pullback than LATE-tier stocks before the label flips."""
        r = classify_phase(
            close=120.0, sma_20=118.0, sma_50=100.0,
            roc_5=-1.0, roc_20=-2.0, bb_pct=1.15,       # ROC_20 > -3, gate doesn't fire
            roc_10=0.0, vol_chg_20=0.0,
        )
        assert r.phase == TrendPhase.EUPHORIA

    # ── EUPHORIA: distribution ─────────────────────────────────────────
    # The distribution gate prefers vol_chg_60 when supplied because the
    # 60d window carries stronger empirical forward-return edge at the
    # 20d horizon (-0.57pp, t=-8.93) vs vol_chg_20 (-0.32pp, t=-5.60).
    # Tests below pin both the new 60d-preferred behaviour and the
    # legacy 20d fallback for callers that haven't been updated yet.

    def test_euphoria_distribution_vol_chg_60_fires(self):
        """Parabolic stock with ROC_5 < 0 AND vol_chg_60 < -40% → NEUTRAL.
        60d window is the preferred signal per volume research."""
        r = classify_phase(
            close=122.0, sma_20=120.0, sma_50=100.0,
            roc_5=-0.5, roc_20=15.0, bb_pct=1.15,
            roc_10=8.0, vol_chg_20=0.0, vol_chg_60=-50.0,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_euphoria_distribution_vol_chg_60_supersedes_20d(self):
        """When vol_chg_60 is supplied, it supersedes vol_chg_20 — even if
        the 20d window looks distributed, a healthy 60d window keeps the
        label as EUPHORIA. This ensures callers updating to the 60d window
        don't get conflicting-signal false positives from stale 20d data."""
        r = classify_phase(
            close=122.0, sma_20=120.0, sma_50=100.0,
            roc_5=-0.5, roc_20=15.0, bb_pct=1.15,
            roc_10=8.0, vol_chg_20=-60.0,    # would fire under legacy path
            vol_chg_60=+10.0,                 # healthy 60d → keep EUPHORIA
        )
        assert r.phase == TrendPhase.EUPHORIA

    def test_euphoria_distribution_legacy_vol_chg_20_still_fires(self):
        """Legacy callers that pass only vol_chg_20 (not vol_chg_60) still
        get the distribution gate via fallback. Guards backward-compat for
        any code path not yet migrated to supply the 60d window."""
        r = classify_phase(
            close=122.0, sma_20=120.0, sma_50=100.0,
            roc_5=-0.5, roc_20=15.0, bb_pct=1.15,
            roc_10=8.0, vol_chg_20=-50.0,
            # vol_chg_60 omitted — defaults to None → fallback to 20d
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_euphoria_distribution_neither_vol_fires_stays_euphoria(self):
        """Sanity: vol_chg_60 healthy (or absent) AND vol_chg_20 healthy →
        gate silent, label stays EUPHORIA."""
        r = classify_phase(
            close=122.0, sma_20=120.0, sma_50=100.0,
            roc_5=-0.5, roc_20=15.0, bb_pct=1.15,
            roc_10=8.0, vol_chg_20=+10.0, vol_chg_60=+15.0,
        )
        assert r.phase == TrendPhase.EUPHORIA

    # ── LATE: ROC_20 < -2% (strongest gate in the whole classifier) ────

    def test_late_roc20_negative_routes_neutral(self):
        """LATE stock with ROC_20 < -2% → NEUTRAL.
        Ablation: -1.22pp delta, t=-5.84, n=1,949. Strong working —
        this is the single most effective gate. Grinding-lower LATE
        stocks genuinely underperform by 120bps over 10 days."""
        r = classify_phase(
            close=113.0, sma_20=111.0, sma_50=100.0,    # ext=13% (mature)
            roc_5=-1.5, roc_20=-3.0, bb_pct=0.85,
            roc_10=-2.0, vol_chg_20=0.0,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_late_mild_dip_stays_late(self):
        """LATE stock with ROC_20 between -2% and 0% → still LATE.
        The gate floor is -2%; minor cooling is plateau behaviour,
        not a regime change."""
        r = classify_phase(
            close=113.0, sma_20=111.0, sma_50=100.0,
            roc_5=0.5, roc_20=-1.5, bb_pct=0.85,        # ROC_20 > -2, gate silent
            roc_10=1.0, vol_chg_20=0.0,
        )
        assert r.phase == TrendPhase.LATE

    # ── LATE: V-recovery ───────────────────────────────────────────────

    def test_late_v_recovery_routes_neutral(self):
        """SHRIRAMFIN-type: stretched extension but last 10d > 2.5× last 20d → NEUTRAL.
        Ablation: -0.38pp delta, t=-2.14, n=2,945. Weak but real —
        the topology of a bounce off a drawdown, not a trend."""
        r = classify_phase(
            close=1047, sma_20=1021, sma_50=924,    # ext ~13%, mature
            roc_5=4.08, roc_20=4.53, bb_pct=0.6,
            roc_10=15.15, vol_chg_20=61.2,          # ROC_10=15.15>10 AND 3.3×>2.5×
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_late_normal_acceleration_stays_late(self):
        """LATE stock with ROC_10 modestly > ROC_20 (ratio < 2.5×) → stays LATE.
        Regression guard: the V-recovery gate specifically excludes
        normal acceleration."""
        r = classify_phase(
            close=112.0, sma_20=108.0, sma_50=100.0,
            roc_5=5.0, roc_20=5.0, bb_pct=0.9,
            roc_10=8.0, vol_chg_20=10.0,            # ratio 1.6x, gate silent
        )
        assert r.phase == TrendPhase.LATE

    def test_late_small_roc10_stays_late(self):
        """ROC_10 = 5% is under the 10% absolute floor → V-recovery gate doesn't fire
        even if the ratio looks elevated. Regression guard — an earlier version of
        the gate without the magnitude floor killed legitimate breakouts."""
        r = classify_phase(
            close=112.0, sma_20=108.0, sma_50=100.0,
            roc_5=3.0, roc_20=1.5, bb_pct=0.9,
            roc_10=5.0, vol_chg_20=10.0,            # 3.3× but ROC_10 < 10
        )
        assert r.phase == TrendPhase.LATE

    def test_late_strong_trend_accelerating_stays_late(self):
        """ROC_10 > 2.5× ROC_20 but ROC_20 itself > 8% → real trend acceleration.
        Regression guard: the V-recovery gate excludes strong-trend cases."""
        r = classify_phase(
            close=115.0, sma_20=110.0, sma_50=100.0,
            roc_5=5.0, roc_20=10.0, bb_pct=0.9,     # ROC_20 > 8, gate silent
            roc_10=25.0, vol_chg_20=10.0,
        )
        assert r.phase == TrendPhase.LATE


class TestPhasesWithoutQualityGates:
    """MID and EARLY have no quality gates post-ablation.

    The ablation data on 569k historical rows showed every MID and
    EARLY gate was either noise (|t| < 1) or actively harmful
    (flagging future winners). These tests pin the new behaviour and
    prevent regression to intuition-driven gate-reintroduction.

    The topologies tested here LOOK bad to a chart reader (rollover,
    distribution, deceleration) but empirically don't meaningfully
    underperform their base-phase peers on 10-day horizons."""

    def test_tejasnet_rollover_stays_mid(self):
        """TEJASNET topology: ext=3.5% (MID), below SMA_20, ROC_20 -5%.
        Looks like a rollover; data says MID average returns are
        unaffected by this topology. Label follows data."""
        r = classify_phase(
            close=413.85, sma_20=433.50, sma_50=400.0,
            roc_5=-3.35, roc_20=-4.99, bb_pct=0.2,
            roc_10=1.07, vol_chg_20=-84.8,
        )
        # Previously NEUTRAL under the above_20 + ROC_5 floor gates.
        # Post-ablation: pure MID.
        assert r.phase == TrendPhase.MID

    def test_household_distribution_stays_mid(self):
        """Household Products topology: ROC_5 -0.21, ROC_20 +11.77, vol -80%.
        Distribution gate on MID had +0.18pp delta, t=+1.78 — noise."""
        r = classify_phase(
            close=104.0, sma_20=101.5, sma_50=100.0,
            roc_5=-0.21, roc_20=11.77, bb_pct=0.6,
            roc_10=1.98, vol_chg_20=-80.1,
        )
        assert r.phase == TrendPhase.MID

    def test_telecom_divergent_aggregation_stays_mid(self):
        """Telecom Equipment topology: aggregate of divergent constituents.
        ROC_5 floor on MID had +0.55pp delta, t=+10.33 — HARMFUL."""
        r = classify_phase(
            close=104.0, sma_20=102.0, sma_50=100.0,
            roc_5=-1.65, roc_20=1.32, bb_pct=0.55,
            roc_10=8.71, vol_chg_20=-59.8,
        )
        assert r.phase == TrendPhase.MID

    def test_oil_decelerating_stays_early(self):
        """Oil topology: ROC_5 -0.84, ROC_10 -0.99, ROC_20 +5.65.
        Deceleration gate on EARLY had +0.14pp delta, t=+2.34 — noise."""
        r = classify_phase(
            close=102.0, sma_20=101.5, sma_50=100.0,
            roc_5=-0.84, roc_20=5.65, bb_pct=0.5,
            roc_10=-0.99, vol_chg_20=-12.8,
        )
        # Extension 2% < ext_healthy(3%) → EARLY tier
        assert r.phase == TrendPhase.EARLY

    def test_mid_with_v_recovery_stays_mid(self):
        """V-recovery topology at MID extension. Ablation: -0.24pp delta,
        t=-0.55, n=382 — noise. Previously NEUTRAL, now stays MID."""
        r = classify_phase(
            close=110.0, sma_20=108.0, sma_50=100.0,
            roc_5=3.0, roc_20=4.0, bb_pct=0.6,
            roc_10=14.0, vol_chg_20=5.0,
        )
        assert r.phase == TrendPhase.MID

    def test_mid_below_sma20_stays_mid(self):
        """Above SMA_50 but below SMA_20 at MID extension. Ablation:
        +0.27pp delta, t=+4.67 — weakly harmful. Drop."""
        r = classify_phase(
            close=107.0, sma_20=109.0, sma_50=100.0,
            roc_5=1.0, roc_20=3.0, bb_pct=0.4,
            roc_10=2.0, vol_chg_20=0.0,
        )
        assert r.phase == TrendPhase.MID

    def test_mid_negative_roc20_stays_mid(self):
        """ROC_20 < -2% floor at MID. Ablation: +0.03pp delta, t=+0.27 — pure noise."""
        r = classify_phase(
            close=107.0, sma_20=105.0, sma_50=100.0,
            roc_5=-1.0, roc_20=-3.0, bb_pct=0.5,
            roc_10=-2.0, vol_chg_20=5.0,
        )
        assert r.phase == TrendPhase.MID

    def test_healthy_mid_preserved(self):
        """Clean MID: must stay MID. Sanity check."""
        r = classify_phase(
            close=107.0, sma_20=104.0, sma_50=100.0,
            roc_5=3.0, roc_20=5.0, bb_pct=0.7,
            roc_10=4.0, vol_chg_20=10.0,
        )
        assert r.phase == TrendPhase.MID

    def test_healthy_early_preserved(self):
        """Clean EARLY: must stay EARLY. Sanity check."""
        r = classify_phase(
            close=101.5, sma_20=100.5, sma_50=100.0,
            roc_5=1.5, roc_20=1.8, bb_pct=0.5,
            roc_10=1.7, vol_chg_20=5.0,
        )
        assert r.phase == TrendPhase.EARLY


class TestUngatedPhaseStructure:
    """Basic phase-assignment invariants that the simplification
    shouldn't change — DECLINE/NEUTRAL routing, boundary behaviour,
    degenerate inputs."""

    def test_below_both_smas_routes_decline(self):
        """Below SMA_50 AND below SMA_20 → DECLINE (unchanged)."""
        r = classify_phase(
            close=90.0, sma_20=95.0, sma_50=100.0,
            roc_5=-2.0, roc_20=-5.0, bb_pct=0.1,
        )
        assert r.phase == TrendPhase.DECLINE

    def test_below_sma50_only_routes_neutral(self):
        """Below SMA_50 but above SMA_20 → NEUTRAL (unchanged)."""
        r = classify_phase(
            close=99.5, sma_20=99.0, sma_50=100.0,
            roc_5=0.5, roc_20=-0.5, bb_pct=0.55,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_degenerate_zero_sma_routes_neutral(self):
        """sma_50 == 0 → NEUTRAL (no crash, unchanged)."""
        r = classify_phase(
            close=100.0, sma_20=0.0, sma_50=0.0,
            roc_5=0.0, roc_20=0.0, bb_pct=0.5,
        )
        assert r.phase == TrendPhase.NEUTRAL

    def test_all_zeros_routes_sensibly(self):
        """Flat data at SMA levels: close == sma_50 → not above_50 → DECLINE (strict >)."""
        r = classify_phase(
            close=100.0, sma_20=100.0, sma_50=100.0,
            roc_5=0.0, roc_20=0.0, bb_pct=0.5,
            roc_10=0.0, vol_chg_20=0.0,
        )
        assert r.phase in (TrendPhase.DECLINE, TrendPhase.NEUTRAL, TrendPhase.EARLY)

    def test_ext_exactly_at_healthy_boundary(self):
        """Extension at 3% boundary → MID or EARLY (doesn't crash, no gates apply)."""
        r = classify_phase(
            close=103.0, sma_20=101.0, sma_50=100.0,
            roc_5=2.0, roc_20=3.0, bb_pct=0.6,
            roc_10=2.5, vol_chg_20=0.0,
        )
        assert r.phase in (TrendPhase.MID, TrendPhase.EARLY)
