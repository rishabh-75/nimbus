"""
ui/dashboard_tab.py — Each intelligence panel individually scrollable.
Regime name wraps (no fixedHeight). Viability score properly aligned.
"""

from __future__ import annotations
import logging
from typing import Optional
import pandas as pd
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QFrame,
    QScrollArea,
)
from PyQt6.QtGui import QFont
from ui.theme import (
    SURFACE,
    BORDER,
    EM,
    RED,
    GOLD,
    MUTED,
    WHITE,
    GREEN,
    BLUE,
    VIOLET,
    FONT_MONO,
    FONT_UI,
    score_color,
    wr_color,
    GRADE_STYLES,
    SIZING_STYLES,
)
from ui.chart_widget import NimbusChart
from ui.components import KPITile, PanelFrame, Badge, ChecklistRow, LevelRow, RiskNote
from modules.analytics import OptionsContext
from modules.etf_analyzer import ETFContext
from modules.indicators import PriceSignals

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# DISPLAY MODE — eliminates all if/else ETF conditionals in rendering
# ══════════════════════════════════════════════════════════════════════════════

class _DisplayMode:
    """Configuration for equity vs ETF display differences.
    Set once when symbol type is known, read everywhere."""
    __slots__ = ("is_etf", "mr_label", "trend_label", "rv_word",
                 "preserve_wf", "has_options", "badge_from_ride")

    def __init__(self, *, is_etf, mr_label, trend_label, rv_word,
                 preserve_wf, has_options, badge_from_ride):
        self.is_etf = is_etf
        self.mr_label = mr_label
        self.trend_label = trend_label
        self.rv_word = rv_word
        self.preserve_wf = preserve_wf
        self.has_options = has_options
        self.badge_from_ride = badge_from_ride


_EQUITY_MODE = _DisplayMode(
    is_etf=False,
    mr_label="MR",
    trend_label="Mean reversion",
    rv_word="reversion",
    preserve_wf=frozenset(),
    has_options=True,
    badge_from_ride=False,
)

_ETF_MODE = _DisplayMode(
    is_etf=True,
    mr_label="DIP",
    trend_label="Dip-in-trend",
    rv_word="pullback",
    preserve_wf=frozenset({"TREND & STATE", "WILLIAMS %R"}),
    has_options=False,
    badge_from_ride=True,
)


def _h(t, c=MUTED, s=7):
    l = QLabel(t.upper())
    l.setFont(QFont(FONT_UI, s))
    l.setStyleSheet(f"color: {c}; letter-spacing: 0.8px;")
    return l


def _t(t="", c=WHITE, s=8, mono=False, bold=False):
    l = QLabel(t)
    f = QFont(FONT_MONO if mono else FONT_UI, s)
    f.setBold(bold)
    l.setFont(f)
    l.setStyleSheet(f"color: {c};")
    l.setWordWrap(True)
    return l


def _sep():
    s = QFrame()
    s.setFixedHeight(1)
    s.setStyleSheet(f"background: {BORDER};")
    return s


def _make_scroll_panel(widget: QWidget, height: int = 280, stretch: bool = False) -> QScrollArea:
    """Wrap a widget in a thin-scrollbar QScrollArea."""
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    if not stretch:
        sa.setFixedHeight(height)
    else:
        sa.setMinimumHeight(height)

    # allow horizontal scroll when content is wider than viewport
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    sa.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

    sa.setStyleSheet(
        "QScrollArea { border: none; background: transparent; }"
        "QScrollBar:vertical { background: #0D1117; width: 5px; border: none; }"
        "QScrollBar::handle:vertical { background: #1E2937; border-radius: 2px; min-height: 20px; }"
        "QScrollBar::handle:vertical:hover { background: #10B981; }"
        "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
    )

    sa.setWidget(widget)

    from PyQt6.QtWidgets import QSizePolicy

    widget.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
    widget.setMinimumWidth(0)
    sa.viewport().setSizePolicy(
        QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred
    )

    return sa


class DashboardTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._symbol = ""
        self._spot = 0.0
        self._price_df: Optional[pd.DataFrame] = None
        self._ps: Optional[PriceSignals] = None
        self._ctx: Optional[OptionsContext] = None
        self._fv = None
        self._vix_value = None
        self._vix_regime = "UNKNOWN"
        self._current_grade = "—"
        self._current_verdict = ""
        self._current_conv = None
        self._current_ride = None
        self._mode = _EQUITY_MODE
        self._is_friday = False
        self._effective_sizing = "SKIP"
        self._build_ui()

    def _build_ui(self):
        outer = QHBoxLayout(self)
        outer.setContentsMargins(6, 4, 6, 4)
        outer.setSpacing(5)

        # ══════════════════════════════════════════════════════════════════
        # CENTER COLUMN (chart + KPIs + strips + levels + viability/checklist)
        # ══════════════════════════════════════════════════════════════════
        center = QVBoxLayout()
        center.setSpacing(4)

        # ── Header ────────────────────────────────────────────────────────
        hdr = QFrame()
        hdr.setFixedHeight(28)
        hdr.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 4px;"
        )
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(10, 0, 10, 0)
        self._sym = _t("--", WHITE, 12, mono=True, bold=True)
        hl.addWidget(self._sym)
        hl.addSpacing(8)
        self._spot_lbl = _t("", WHITE, 11, mono=True)
        hl.addWidget(self._spot_lbl)
        hl.addSpacing(6)
        self._chg = _t("", MUTED, 9, mono=True)
        hl.addWidget(self._chg)
        hl.addStretch(1)
        self._ts = _t("", MUTED, 7, mono=True)
        hl.addWidget(self._ts)
        center.addWidget(hdr)

        # ── Badge row ─────────────────────────────────────────────────────
        br = QHBoxLayout()
        br.setSpacing(4)
        self._badges = {}
        for k in ("TIER", "WR", "MFI", "SMA", "DD", "REGIME"):
            b = Badge("--")
            br.addWidget(b)
            self._badges[k] = b
        br.addStretch(1)
        center.addLayout(br)

        # ── Chart ─────────────────────────────────────────────────────────
        self._chart = NimbusChart()
        center.addWidget(self._chart, stretch=1)

        # ── KPI tiles (single row, compact) ───────────────────────────────
        self._kpi = {}
        kr = QHBoxLayout(); kr.setSpacing(3)
        for k in ("SPOT", "WR(30)", "MFI", "vs SMA", "BB %B", "PCR OI", "NET GEX", "TO EXPIRY", "VOL STATE"):
            t = KPITile(k); kr.addWidget(t); self._kpi[k] = t
        center.addLayout(kr)

        # ── Filing + Signal strip (combined) ──────────────────────────────
        fstrip = QFrame()
        fstrip.setFixedHeight(26)
        fstrip.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 3px;"
        )
        fl = QHBoxLayout(fstrip)
        fl.setContentsMargins(6, 0, 6, 0)
        fl.setSpacing(4)
        self._setup_badge = Badge("SETUP: —")
        self._filing_badge = Badge("NO FILING")
        fl.addWidget(self._setup_badge)
        fl.addWidget(self._filing_badge)
        self._conviction_lbl = QLabel("○○○○○○○○○○")
        self._conviction_lbl.setFont(QFont(FONT_MONO, 7))
        self._conviction_lbl.setStyleSheet(f"color: {MUTED};")
        fl.addWidget(self._conviction_lbl)
        fl.addSpacing(4)
        self._filing_detail_lbl = QLabel("Fetching filings…")
        self._filing_detail_lbl.setFont(QFont(FONT_UI, 7))
        self._filing_detail_lbl.setStyleSheet(f"color: {MUTED};")
        self._filing_detail_lbl.setWordWrap(False)
        fl.addWidget(self._filing_detail_lbl, stretch=1)
        self._filing_recency_lbl = QLabel("—")
        self._filing_recency_lbl.setFont(QFont(FONT_MONO, 7))
        self._filing_recency_lbl.setStyleSheet(f"color: {MUTED};")
        fl.addWidget(self._filing_recency_lbl)
        center.addWidget(fstrip)

        # ── MR Verdict strip ───────────────────────────────────────────
        vstrip = QFrame()
        vstrip.setFixedHeight(26)
        vstrip.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 3px;"
        )
        vl = QHBoxLayout(vstrip)
        vl.setContentsMargins(6, 0, 6, 0)
        vl.setSpacing(4)
        self._mr_tag = _t("MR", GREEN, 7, mono=True, bold=True)
        vl.addWidget(self._mr_tag)
        self._verdict_action = _t("—", WHITE, 9, mono=True, bold=True)
        self._verdict_action.setWordWrap(False)
        self._verdict_action.setMinimumWidth(80)
        vl.addWidget(self._verdict_action)
        self._verdict_detail = _t("", MUTED, 7)
        self._verdict_detail.setWordWrap(False)
        vl.addWidget(self._verdict_detail, stretch=1)
        self._verdict_exit = _t("", MUTED, 7, mono=True)
        self._verdict_exit.setWordWrap(False)
        self._verdict_exit.setMinimumWidth(120)
        vl.addWidget(self._verdict_exit)
        vl.addSpacing(4)
        self._dm_wr_lbl = _t("WR(30)=—", MUTED, 7, mono=True)
        vl.addWidget(self._dm_wr_lbl)
        self._dm_adx_lbl = _t("MFI=—", MUTED, 7, mono=True)
        vl.addWidget(self._dm_adx_lbl)
        center.addWidget(vstrip)

        # Entry reason stored as attribute only (not in layout — used by on_conviction_updated)
        self._dm_entry_lbl = _t("", MUTED, 7)
        self._dm_entry_lbl.setVisible(False)

        # ── RIDE Verdict strip ────────────────────────────────────────────
        rstrip = QFrame()
        rstrip.setFixedHeight(26)
        rstrip.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 3px;"
        )
        rl = QHBoxLayout(rstrip)
        rl.setContentsMargins(6, 0, 6, 0)
        rl.setSpacing(4)
        rl.addWidget(_t("RIDE", BLUE, 7, mono=True, bold=True))
        self._ride_action = _t("—", WHITE, 9, mono=True, bold=True)
        self._ride_action.setWordWrap(False)
        self._ride_action.setMinimumWidth(80)
        rl.addWidget(self._ride_action)
        self._ride_detail = _t("", MUTED, 7)
        self._ride_detail.setWordWrap(False)
        rl.addWidget(self._ride_detail, stretch=1)
        self._ride_targets = _t("", MUTED, 7, mono=True)
        self._ride_targets.setWordWrap(False)
        self._ride_targets.setMinimumWidth(140)
        rl.addWidget(self._ride_targets)
        rl.addSpacing(4)
        self._ride_pctb = _t("%B=—", MUTED, 7, mono=True)
        rl.addWidget(self._ride_pctb)
        self._ride_vol = _t("Vol=—", MUTED, 7, mono=True)
        rl.addWidget(self._ride_vol)
        center.addWidget(rstrip)

        # ── Bottom row: Trade Viability + Checklist (equal width) ─────────
        bottom = QHBoxLayout()
        bottom.setSpacing(5)

        pb_widget = QWidget()
        self._build_panel_b(pb_widget)
        bottom.addWidget(_make_scroll_panel(pb_widget, 200), 50)

        pc_widget = QWidget()
        self._build_panel_c(pc_widget)
        bottom.addWidget(_make_scroll_panel(pc_widget, 200), 50)

        center.addLayout(bottom)

        outer.addLayout(center, stretch=1)

        # ══════════════════════════════════════════════════════════════════
        # RIGHT COLUMN: Workflow Analysis (full height, scrollable)
        # ══════════════════════════════════════════════════════════════════
        pa_widget = QWidget()
        self._build_panel_a(pa_widget)
        right_scroll = _make_scroll_panel(pa_widget, 200, stretch=True)
        right_scroll.setMinimumWidth(380)
        right_scroll.setMaximumWidth(480)
        outer.addWidget(right_scroll)

    # ── Panel A: Regime + Workflow ────────────────────────────────────────────
    def _build_panel_a(self, container):
        self._pa = PanelFrame("", accent=EM)
        pa = self._pa.content_layout()
        pa.setSpacing(4)

        # Regime tile — NO fixedHeight so name wraps naturally
        rt = QFrame()
        rt.setStyleSheet(
            f"background: rgba(16,185,129,0.06); border-left: 3px solid {EM}; "
            f"border-radius: 4px; padding: 4px 8px;"
        )
        self._regime_frame = rt
        rl = QVBoxLayout(rt)
        rl.setContentsMargins(4, 2, 4, 2)
        rl.setSpacing(2)
        rh = QHBoxLayout()
        self._regime_lbl = _t("REGIME: --", EM, 8, bold=True)
        self._regime_lbl.setWordWrap(True)
        rh.addWidget(self._regime_lbl, stretch=1)
        rl.addLayout(rh)
        self._regime_detail = _t("", MUTED, 7)
        self._regime_detail.setWordWrap(True)
        rl.addWidget(self._regime_detail)
        pa.addWidget(rt)

        pa.addWidget(_sep())

        wh = QHBoxLayout()
        wh.addWidget(_h("Workflow Analysis"))
        wh.addStretch(1)
        pa.addLayout(wh)

        self._wf = {}
        self._wf_titles = {}
        for key in (
            "TREND & STATE",
            "VIX REGIME",
            "SECTOR CONTEXT",
            "VOL CONTEXT",
            "GEX REGIME",
            "OI WALLS",
            "EXPIRY",
            "WILLIAMS %R",
            "MFI FLOW",
            "OPTIONS IMPACT",
            "FILING IMPACT",
            "BB RIDE",
        ):
            title_lbl = _h(key, MUTED, 6)
            pa.addWidget(title_lbl)
            body = _t("", WHITE, 7)
            body.setWordWrap(True)
            pa.addWidget(body)
            self._wf[key] = body
            self._wf_titles[key] = title_lbl

        self._verdict = QLabel("")
        self._verdict.setFont(QFont(FONT_UI, 7))
        self._verdict.setWordWrap(True)
        self._verdict.setStyleSheet(
            f"background: rgba(16,185,129,0.06); color: {WHITE}; "
            f"border-left: 3px solid {EM}; border-radius: 3px; padding: 5px 8px;"
        )
        pa.addWidget(self._verdict)

        pa.addWidget(_sep())
        pa.addWidget(_h("Filing Intelligence"))
        sh = QHBoxLayout()
        self._filing_setup_lbl = _t("SETUP: —", MUTED, 7, bold=True)
        sh.addWidget(self._filing_setup_lbl, stretch=1)
        self._filing_conv_badge = Badge("CONV —")
        sh.addWidget(self._filing_conv_badge)
        pa.addLayout(sh)
        self._filing_subject_lbl = _t("", MUTED, 7)
        self._filing_subject_lbl.setWordWrap(True)
        self._filing_deal_lbl = _t("", WHITE, 7)
        self._filing_deal_lbl.setWordWrap(True)
        pa.addWidget(self._filing_subject_lbl)
        pa.addWidget(self._filing_deal_lbl)

        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._pa)

    # ── Panel B: Viability + Levels ───────────────────────────────────────────
    def _build_panel_b(self, container):
        self._pb = PanelFrame("Key Levels", accent=GOLD)
        pb = self._pb.content_layout()
        pb.setSpacing(4)

        self._risk_container = QVBoxLayout()
        self._risk_container.setSpacing(2)
        pb.addLayout(self._risk_container)

        self._levels: list[LevelRow] = []
        for _ in range(7):
            lr = LevelRow()
            lr.setVisible(False)
            pb.addWidget(lr)
            self._levels.append(lr)

        bb = QHBoxLayout()
        bb.setSpacing(3)
        self._bot = {}
        for k in ("PCR", "PIN", "GEX", "DTE"):
            b = Badge("--")
            b.setFixedHeight(16)
            bb.addWidget(b)
            self._bot[k] = b
        bb.addStretch(1)
        pb.addLayout(bb)

        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._pb)

    # ── Panel C: Checklist ────────────────────────────────────────────────────
    def _build_panel_c(self, container):
        self._pc = PanelFrame("Pre-Trade Checklist", accent=BORDER)
        pc = self._pc.content_layout()
        pc.setSpacing(2)
        self._checks: list[ChecklistRow] = []
        for _ in range(16):  # 12 MR + 4 ride
            cr = ChecklistRow()
            cr.setVisible(False)
            pc.addWidget(cr)
            self._checks.append(cr)

        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._pc)

    # ══════════════════════════════════════════════════════════════════════════
    # DATA SLOTS (same as before — compact)
    # ══════════════════════════════════════════════════════════════════════════
    def on_price_updated(self, symbol, df):
        try:
            self._symbol = symbol
            self._mode = _EQUITY_MODE  # reset until context_updated confirms
            self._fv = None
            self._refresh_filing()
            self._price_df = df
            self._sym.setText(symbol)
            if df is not None and not df.empty:
                last = df.iloc[-1]
                self._spot = float(last["Close"])
                self._spot_lbl.setText(f"{self._spot:,.2f}")
                # Daily change: current close vs previous day's close
                if len(df) >= 2:
                    prev_close = float(df["Close"].iloc[-2])
                    if prev_close > 0:
                        ch = self._spot - prev_close
                        p = ch / prev_close * 100
                        c = EM if ch >= 0 else RED
                        self._chg.setText(f"{ch:+,.2f} ({p:+.2f}%)")
                        self._chg.setStyleSheet(f"color: {c};")
                try:
                    ts = df.index[-1]
                    if hasattr(ts, "strftime"):
                        # Daily data: show date only. Intraday: show time.
                        if hasattr(ts, "hour") and ts.hour == 0 and ts.minute == 0:
                            self._ts.setText(ts.strftime("%d %b %Y"))
                        else:
                            self._ts.setText(ts.strftime("%d %b %H:%M IST"))
                except Exception:
                    pass
            self._update_chart()
        except Exception as exc:
            logger.exception("Dashboard price update failed: %s", exc)

    def on_ps_updated(self, symbol, ps):
        try:
            self._ps = ps
            self._refresh_kpi()
            self._refresh_badges()
            self._update_chart()
            if self._fv:
                self._refresh_filing()
        except Exception as exc:
            logger.exception("Dashboard ps update failed: %s", exc)

    def on_context_updated(self, symbol, ctx):
        try:
            self._ctx = ctx
            self._refresh_kpi()

            from modules.etf_analyzer import ETFContext

            self._mode = _ETF_MODE if isinstance(ctx, ETFContext) else _EQUITY_MODE
            if self._mode.is_etf:
                self._refresh_intel_etf(ctx)
            else:
                self._refresh_intel()
            self._update_chart()
            if self._fv:
                self._refresh_filing()
        except Exception as exc:
            logger.exception("Dashboard context update failed: %s", exc)

    def on_spot_updated(self, symbol, spot):
        self._spot = spot
        self._spot_lbl.setText(f"{spot:,.2f}")

    def set_price_df(self, df):
        self._price_df = df

    def on_filing_updated(self, symbol: str, fv):
        if symbol != self._symbol:
            return
        self._fv = fv
        self._refresh_filing()

    def on_conviction_updated(self, symbol: str, dm_sig, conv):
        """
        Update dashboard from pre-computed conviction result.

        data_manager computes conviction ONCE, emits here.
        Dashboard READS only — zero recomputation.
        """
        if symbol != self._symbol:
            return

        from modules.dual_mode import DualModeSignal
        if not isinstance(dm_sig, DualModeSignal):
            return
        if not dm_sig.data_sufficient:
            return

        # Relabel MR strip for ETFs (same underlying WR/MFI/SMA analysis,
        # but "MR" language is misleading — it's pullback-in-trend for ETFs)
        self._mr_tag.setText(self._mode.mr_label)

        try:
            self._apply_conviction(dm_sig, conv)
        except Exception as exc:
            logger.exception("Dashboard conviction update failed: %s", exc)

    def on_ride_updated(self, symbol: str, ride_result):
        """
        Update BB Ride verdict strip from pre-computed ride result.

        data_manager computes via compute_ride() ONCE, emits BBRideResult here.
        Dashboard READS only — zero recomputation.
        """
        if symbol != self._symbol:
            return
        try:
            self._apply_ride(ride_result)
        except Exception as exc:
            logger.debug("Dashboard ride update failed: %s", exc)

    def _apply_conviction(self, dm_sig, conv):
        """Apply conviction data to all dashboard panels."""

        # Store conviction outputs for use across the dashboard
        vix_regime = conv.vix_regime
        self._vix_regime = vix_regime
        self._vix_value = conv.vix_value  # for VIX workflow display
        self._is_friday = conv.is_friday
        self._effective_sizing = conv.effective_sizing
        self._current_grade = conv.grade
        self._current_verdict = conv.verdict
        self._current_conv = conv  # full result for targets, checklist, etc.
        effective_sizing = conv.effective_sizing
        effective_label = conv.effective_label
        grade = conv.grade

        # ── Header badges (dual-mode-aware) ──────────────────────────────
        self._refresh_badges_dual(dm_sig)

        if dm_sig.entry_triggered:
            self._dm_entry_lbl.setText(f"▶ {dm_sig.entry_reason}")
            self._dm_entry_lbl.setStyleSheet(f"color: {EM};")
        else:
            parts = []
            if dm_sig.wr_30 >= -30: parts.append(f"WR={dm_sig.wr_30:.0f}")
            if dm_sig.above_sma: parts.append("above SMA")
            if dm_sig.mfi < 30: parts.append(f"MFI={dm_sig.mfi:.0f}")
            self._dm_entry_lbl.setText(
                f"Waiting: {', '.join(parts)}" if parts else "Conditions not met"
            )
            self._dm_entry_lbl.setStyleSheet(f"color: {MUTED};")

        # WR and MFI on strip
        wr_c = EM if dm_sig.wr_30 < -50 else (GREEN if dm_sig.wr_30 < -30 else MUTED)
        self._dm_wr_lbl.setText(f"WR(30)={dm_sig.wr_30:.0f}")
        self._dm_wr_lbl.setStyleSheet(f"color: {wr_c};")

        mfi_c = EM if dm_sig.mfi >= 50 else (GREEN if dm_sig.mfi >= 30 else RED)
        self._dm_adx_lbl.setText(f"MFI={dm_sig.mfi:.0f}")
        self._dm_adx_lbl.setStyleSheet(f"color: {mfi_c};")

        # ── Verdict strip ─────────────────────────────────────────────────
        self._update_verdict_strip(dm_sig)

        # ── KPI tiles ─────────────────────────────────────────────────────
        wr_c = EM if dm_sig.wr_30 < -50 else (GREEN if dm_sig.wr_30 < -30 else MUTED)
        self._kpi["WR(30)"].set_value(f"{dm_sig.wr_30:.0f}", wr_c)
        zone = "DEEP" if dm_sig.wr_30 < -50 else ("IN ZONE" if dm_sig.wr_30 < -30 else "—")
        self._kpi["WR(30)"].set_delta(zone, wr_c)

        mfi_c = EM if dm_sig.mfi >= 50 else (GREEN if dm_sig.mfi >= 30 else RED)
        self._kpi["MFI"].set_value(f"{dm_sig.mfi:.0f}", mfi_c)
        mfi_d = "Strong" if dm_sig.mfi >= 50 else ("OK" if dm_sig.mfi >= 30 else "Weak")
        self._kpi["MFI"].set_delta(mfi_d, mfi_c)

        sma_c = RED if not dm_sig.above_sma else EM
        bias = "BELOW" if not dm_sig.above_sma else "ABOVE"
        self._kpi["vs SMA"].set_value(bias, sma_c)
        self._kpi["vs SMA"].set_delta(f"{dm_sig.pct_from_sma:+.1f}% vs SMA", sma_c)

        # ── Panel B: Key Levels ────────────────────────────────────────
        _GRADE_COLORS = {"A+": EM, "A": GREEN, "B+": GOLD, "B": GOLD,
                         "C+": MUTED, "C": MUTED, "D": RED}
        gc = _GRADE_COLORS.get(grade, MUTED)
        self._pb.set_accent(gc)

        # Risk notes
        while self._risk_container.count():
            w = self._risk_container.takeAt(0).widget()
            if w:
                w.deleteLater()
        from ui.components import RiskNote
        risk_notes = []
        if dm_sig.is_trap:
            risk_notes.append("⚠ TRAP: Bearish filing vs pullback setup")
        if dm_sig.options_overlay <= -3:
            risk_notes.append(f"! Options: extreme complacency ({dm_sig.options_detail})")
        if dm_sig.mfi < 30:
            risk_notes.append(f"MFI={dm_sig.mfi:.0f} — weak money flow")
        if dm_sig.above_sma:
            ride = self._current_ride
            if ride and ride.data_sufficient and ride.bb_pct >= 0.75:
                risk_notes.append(f"Above SMA — ride active (%B={ride.bb_pct:.2f})")
            else:
                tag = self._mode.mr_label
                risk_notes.append(f"Above SMA — not a pullback ({tag})")
        if dm_sig.vol_ratio < 0.5:
            risk_notes.append(f"Dry volume ({dm_sig.vol_ratio:.1f}x avg)")
        # Ride-specific risk notes
        ride = self._current_ride
        if ride and ride.data_sufficient:
            if ride.trail_stop > 0 and ride.close < ride.trail_stop and ride.bb_pct >= 0.5:
                risk_notes.append(f"⚠ RIDE: Below trail stop ({ride.trail_stop:,.0f})")
            if ride.entry_triggered and ride.vol_ratio < 1.0:
                risk_notes.append(f"⚠ RIDE: Low volume at touch ({ride.vol_ratio:.1f}x)")
        for note in risk_notes[:4]:
            self._risk_container.addWidget(RiskNote(note))

        # Key levels: always-available price levels + options when present
        all_levels = []

        # Slot 0: Daily SMA (always available from dual-mode)
        if dm_sig.sma_20 > 0:
            sma_lbl_c = EM if dm_sig.above_sma else RED
            all_levels.append(("DAILY SMA", dm_sig.sma_20, sma_lbl_c, f"{dm_sig.pct_from_sma:+.1f}%"))

        # Price-derived levels from BB bands (always available)
        ps = self._ps
        if ps:
            if getattr(ps, "upper", 0) > 0:
                pct = (dm_sig.close / ps.upper - 1) * 100 if dm_sig.close > 0 else 0
                all_levels.append(("BB UPPER", round(ps.upper, 2), GOLD, f"{pct:+.1f}%"))
            if getattr(ps, "lower", 0) > 0:
                pct = (dm_sig.close / ps.lower - 1) * 100 if dm_sig.close > 0 else 0
                all_levels.append(("BB LOWER", round(ps.lower, 2), GREEN, f"{pct:+.1f}%"))

        # BB Ride levels (trail stop + PT when ride is active)
        ride = self._current_ride
        if ride and ride.data_sufficient and ride.trail_stop > 0:
            above = dm_sig.close > ride.trail_stop if dm_sig.close > 0 else False
            trail_c = GREEN if above else RED
            pct = (dm_sig.close / ride.trail_stop - 1) * 100 if ride.trail_stop > 0 else 0
            all_levels.append(("TRAIL 3×ATR", round(ride.trail_stop, 2), trail_c, f"{pct:+.1f}%"))
            if ride.entry_triggered or ride.bb_pct >= 0.75:
                pct_pt = (ride.pt_price / dm_sig.close - 1) * 100 if dm_sig.close > 0 else 0
                all_levels.append(("RIDE PT", round(ride.pt_price, 2), EM, f"+{pct_pt:.1f}%"))

        # Options-derived levels (when available — market hours only)
        ctx = self._ctx
        if ctx and hasattr(ctx, "walls"):
            w = ctx.walls
            if getattr(w, "resistance", None):
                all_levels.append(("OI RESIST", w.resistance, RED, f"{w.resistance_pct:+.1f}%"))
            if getattr(w, "support", None):
                all_levels.append(("OI SUPPORT", w.support, GREEN, f"{w.support_pct:+.1f}%"))
            if getattr(w, "max_pain", None):
                all_levels.append(("MAX PAIN", w.max_pain, GOLD, ""))
        if ctx and hasattr(ctx, "gex") and getattr(ctx.gex, "hvl", None):
            all_levels.append(("GEX HVL", ctx.gex.hvl, VIOLET, ""))

        for i, lr in enumerate(self._levels):
            if i < len(all_levels):
                lr.set_data(*all_levels[i])
                lr.setVisible(True)
            else:
                lr.setVisible(False)

        # Bottom badges — only show real options data
        has_real_opts = (
            ctx and hasattr(ctx, "walls")
            and getattr(ctx.walls, "pcr_oi", None) is not None
            and ctx.walls.pcr_oi != 1.0
        )
        if has_real_opts:
            self._bot["PCR"].set_badge(f"PCR {ctx.walls.pcr_oi:.2f}", "NEUTRAL")
        else:
            self._bot["PCR"].set_badge("PCR —", "NEUTRAL")
        if has_real_opts and hasattr(ctx, "gex"):
            self._bot["GEX"].set_badge(
                f"GEX {ctx.gex.regime.upper()}",
                {"Positive": "BEARISH", "Negative": "BULLISH", "Neutral": "NEUTRAL"}.get(
                    ctx.gex.regime, "NEUTRAL"
                ),
            )

        # ── Panel A: Regime tile ──────────────────────────────────────────
        entry_status = "Entry" if dm_sig.entry_triggered else "No Entry"
        grade_tag = f" · Grade {grade}" if grade != "—" else ""
        vix_regime = getattr(self, "_vix_regime", "UNKNOWN")
        vix_val = getattr(self, "_vix_value", None)
        vix_str = f" · VIX {vix_val:.1f} ({vix_regime})" if vix_val else ""

        ride = self._current_ride
        ride_tag = ""
        if ride and ride.data_sufficient:
            if ride.entry_triggered:
                ride_tag = f" | RIDE: Entry [{ride.grade}]"
            elif ride.bb_pct >= 1.0:
                ride_tag = " | RIDE: Riding"
            elif ride.bb_pct >= 0.75:
                ride_tag = " | RIDE: Near UB"

        mr_label = self._mode.mr_label
        self._regime_lbl.setText(f"{mr_label}: {entry_status}{grade_tag}{ride_tag}{vix_str}")
        self._regime_lbl.setStyleSheet(f"color: {gc}; font-weight: bold;")

        detail = (
            f"WR(30)={dm_sig.wr_30:.0f} | SMA {dm_sig.pct_from_sma:+.1f}% | "
            f"MFI={dm_sig.mfi:.0f} | DD={dm_sig.dd_from_high:.1f}% | "
            f"{dm_sig.red_streak}d red | Vol={dm_sig.vol_ratio:.1f}x"
        )
        self._regime_detail.setText(detail)

        frame_c = gc
        self._regime_frame.setStyleSheet(
            f"background: rgba(16,185,129,0.06); border-left: 3px solid {frame_c}; "
            f"border-radius: 4px; padding: 4px 8px;"
        )

        # Workflow lines
        # For ETFs: sections in preserve_wf are already set by _refresh_intel_etf
        if "TREND & STATE" in self._wf and "TREND & STATE" not in self._mode.preserve_wf:
            rsi = getattr(dm_sig, "rsi", None)
            rsi_str = f" · RSI={rsi:.0f}" if rsi is not None else ""
            self._wf["TREND & STATE"].setText(
                f"{self._mode.trend_label} · WR(30)={dm_sig.wr_30:.0f} · "
                f"{dm_sig.pct_from_sma:+.1f}% vs SMA · MFI={dm_sig.mfi:.0f}{rsi_str}"
            )
        if "WILLIAMS %R" in self._wf and "WILLIAMS %R" not in self._mode.preserve_wf:
            if dm_sig.wr_30 < -70:
                self._wf["WILLIAMS %R"].setText(
                    f"WR(30) {dm_sig.wr_30:.0f} → Extreme — entry met but extended, watch for trend break"
                )
            elif dm_sig.wr_30 < -50:
                self._wf["WILLIAMS %R"].setText(
                    f"WR(30) {dm_sig.wr_30:.0f} → Oversold — entry condition met"
                )
            elif dm_sig.wr_30 < -30:
                self._wf["WILLIAMS %R"].setText(
                    f"WR(30) {dm_sig.wr_30:.0f} → Moderate pullback — clean reversion zone (best win rate)"
                )
            else:
                self._wf["WILLIAMS %R"].setText(
                    f"WR(30) {dm_sig.wr_30:.0f} → Not oversold → Wait for pullback"
                )
        if "MFI FLOW" in self._wf:
            if dm_sig.mfi >= 55:
                self._wf["MFI FLOW"].setText(
                    f"MFI {dm_sig.mfi:.0f} → Strong flow — high conviction (r=+0.039)"
                )
            elif dm_sig.mfi >= 45:
                self._wf["MFI FLOW"].setText(
                    f"MFI {dm_sig.mfi:.0f} → Flow confirming — acceptable conviction"
                )
            elif dm_sig.mfi >= 30:
                self._wf["MFI FLOW"].setText(
                    f"MFI {dm_sig.mfi:.0f} → Weak flow — reduced conviction, manage size"
                )
            else:
                self._wf["MFI FLOW"].setText(
                    f"MFI {dm_sig.mfi:.0f} → No buying pressure — high risk of continued decline"
                )

        # VIX regime workflow
        if "VIX REGIME" in self._wf:
            vix_val = getattr(self, "_vix_value", None)
            vix_regime = getattr(self, "_vix_regime", "UNKNOWN")
            rv = self._mode.rv_word
            _VIX_CONTEXT = {
                "PANIC": f"VIX {vix_val:.1f} → PANIC — 97% win rate, high-prob {rv} (backtest Sh 10.15)",
                "ELEVATED": f"VIX {vix_val:.1f} → ELEVATED — 80% win rate, strong bounce zone (Sh 2.95)",
                "LOW": f"VIX {vix_val:.1f} → LOW — 78% win rate, clean orderly {rv}s (Sh 2.30)",
                "NORMAL": f"VIX {vix_val:.1f} → NORMAL — 68% win rate, choppy zone. Low-conviction entries gated (Sh 0.60)",
            } if vix_val else {}
            self._wf["VIX REGIME"].setText(
                _VIX_CONTEXT.get(vix_regime, "VIX data unavailable — sizing gate disabled")
            )
            vc = {
                "PANIC": EM, "ELEVATED": GOLD, "LOW": GREEN, "NORMAL": MUTED,
            }.get(vix_regime, MUTED)
            self._wf["VIX REGIME"].setStyleSheet(f"color: {vc};")

        # Sector context workflow
        if "SECTOR CONTEXT" in self._wf:
            if not self._mode.has_options:
                # ETFs ARE sectors — this section doesn't apply
                self._wf["SECTOR CONTEXT"].setText("")
                self._wf_titles["SECTOR CONTEXT"].setVisible(False)
                self._wf["SECTOR CONTEXT"].setVisible(False)
            elif conv.sector_name:
                self._wf_titles["SECTOR CONTEXT"].setVisible(True)
                self._wf["SECTOR CONTEXT"].setVisible(True)
                parts = [conv.sector_name]
                if conv.sector_type:
                    parts.append(conv.sector_type)
                if conv.sector_rotation and conv.sector_rotation != "UNKNOWN":
                    parts.append(conv.sector_rotation)
                # Grade impact summary
                impacts = []
                if conv.sector_rs_impact > 0:
                    impacts.append(f"RS +{conv.sector_rs_impact}")
                elif conv.sector_rs_impact < 0:
                    impacts.append(f"RS {conv.sector_rs_impact}")
                if conv.sector_vol_impact > 0:
                    impacts.append(f"vol +{conv.sector_vol_impact} (z={conv.sector_vol_z:.1f})")
                if conv.div_impact > 0:
                    impacts.append(f"catch-up +{conv.div_impact}")
                impact_str = f" → grade {', '.join(impacts)}" if impacts else ""
                text = " · ".join(parts) + impact_str
                # Color by RS regime
                sc = {
                    "LEADING": EM, "IMPROVING": GREEN,
                    "LAGGING": RED, "WEAKENING": GOLD,
                }.get(conv.sector_rotation, MUTED)
                self._wf["SECTOR CONTEXT"].setText(text)
                self._wf["SECTOR CONTEXT"].setStyleSheet(f"color: {sc};")
            else:
                self._wf_titles["SECTOR CONTEXT"].setVisible(True)
                self._wf["SECTOR CONTEXT"].setVisible(True)
                self._wf["SECTOR CONTEXT"].setText("No sector data — stock not in index")
                self._wf["SECTOR CONTEXT"].setStyleSheet(f"color: {MUTED};")

        # Vol context workflow — BBW percentile risk note
        # Based on study: compression (P0-10) underperforms MR by 8.6pp win rate.
        # Surfaced as risk note, NOT a grade factor (signal too weak: d=-0.15).
        if "VOL CONTEXT" in self._wf:
            pctl = getattr(dm_sig, "bbw_pctl", None)
            if pctl is None or not self._mode.has_options:
                # Hide for ETFs and when no data
                self._wf_titles["VOL CONTEXT"].setVisible(False)
                self._wf["VOL CONTEXT"].setVisible(False)
            else:
                self._wf_titles["VOL CONTEXT"].setVisible(True)
                self._wf["VOL CONTEXT"].setVisible(True)
                if pctl < 15:
                    text = f"BBW pctl {pctl:.0f} (very compressed) — quiet stock, MR may fizzle"
                    color = RED
                elif pctl < 30:
                    text = f"BBW pctl {pctl:.0f} (compressed) — below-average vol, weaker MR edge"
                    color = GOLD
                elif pctl > 85:
                    text = f"BBW pctl {pctl:.0f} (very expanded) — active vol, MR has fuel to revert"
                    color = EM
                elif pctl > 70:
                    text = f"BBW pctl {pctl:.0f} (expanded) — above-average vol, healthy MR setup"
                    color = GREEN
                else:
                    text = f"BBW pctl {pctl:.0f} (normal range) — typical vol regime"
                    color = MUTED
                self._wf["VOL CONTEXT"].setText(text)
                self._wf["VOL CONTEXT"].setStyleSheet(f"color: {color};")

        # Options impact workflow
        if "OPTIONS IMPACT" in self._wf:
            if not self._mode.has_options:
                self._wf["OPTIONS IMPACT"].setText("Options → N/A (ETF — no options chain)")
                self._wf["OPTIONS IMPACT"].setStyleSheet(f"color: {MUTED};")
            else:
                ov = dm_sig.options_overlay
                detail = dm_sig.options_detail or "No options data"
                if ov >= 3:
                    self._wf["OPTIONS IMPACT"].setText(f"Options → {detail}")
                    self._wf["OPTIONS IMPACT"].setStyleSheet(f"color: {EM};")
                elif ov <= -3:
                    self._wf["OPTIONS IMPACT"].setText(f"Options → {detail}")
                    self._wf["OPTIONS IMPACT"].setStyleSheet(f"color: {RED};")
                else:
                    self._wf["OPTIONS IMPACT"].setText(f"Options → {detail}")
                    self._wf["OPTIONS IMPACT"].setStyleSheet(f"color: {MUTED};")

        # Filing impact workflow
        if "FILING IMPACT" in self._wf:
            fov = dm_sig.filing_overlay
            fdetail = dm_sig.filing_detail or "No actionable filing"
            if dm_sig.is_trap:
                self._wf["FILING IMPACT"].setText(f"⚠ TRAP: {fdetail} → Score capped at 30, AVOID")
                self._wf["FILING IMPACT"].setStyleSheet(f"color: {RED};")
            elif fov > 3:
                self._wf["FILING IMPACT"].setText(f"Filing +{fov} → {fdetail} → Adds conviction")
                self._wf["FILING IMPACT"].setStyleSheet(f"color: {EM};")
            elif fov < -3:
                self._wf["FILING IMPACT"].setText(f"Filing {fov} → {fdetail} → Reduces conviction")
                self._wf["FILING IMPACT"].setStyleSheet(f"color: {RED};")
            else:
                self._wf["FILING IMPACT"].setText(f"Filing → {fdetail}")
                self._wf["FILING IMPACT"].setStyleSheet(f"color: {MUTED};")

        # Verdict (from conviction engine — single source of truth)
        eff_sizing = getattr(self, "_effective_sizing", dm_sig.dual_sizing)

        if dm_sig.entry_triggered:
            base_verdict = conv.verdict
            # Add overlay context if present
            if conv.overlay_str and conv.overlay_str not in base_verdict:
                base_verdict += f" {conv.overlay_str}"
            # Build exit text from dynamic targets
            if conv.target_pct and conv.stop_pct:
                atr_note = f" ({conv.stop_atr_mult:.1f}× ATR)" if conv.stop_atr_mult else ""
                exit_str = f"PT +{conv.target_pct}% · SL {conv.stop_pct}%{atr_note} · BBW · 30d"
            else:
                exit_str = "Exit: BBW contraction or 30d max"
            verdict = base_verdict + f". {exit_str}"

            if eff_sizing == "SKIP":
                vc = BLUE; vrgb = "59,130,246"
            elif eff_sizing == "FULL":
                vc = EM; vrgb = "16,185,129"
            else:
                vc = GOLD; vrgb = "245,158,11"
        elif dm_sig.core_met:
            vrgb = "245,158,11"; vc = GOLD
            missing = []
            if dm_sig.dd_from_high > -5: missing.append(f"DD={dm_sig.dd_from_high:.1f}% (need <-5%)")
            if dm_sig.red_streak < 2: missing.append(f"{dm_sig.red_streak}d red (need ≥2)")
            if dm_sig.vol_ratio < 0.5: missing.append(f"Vol={dm_sig.vol_ratio:.1f}x (need ≥0.5)")
            verdict = (
                f"Core conditions met (WR+SMA+MFI). Entry triggered — grade determines sizing."
            )
        else:
            vrgb = "239,68,68"; vc = RED
            if dm_sig.is_trap:
                verdict = "⚠ TRAP: Bearish filing conflicts with setup. SKIP."
            else:
                missing = []
                if dm_sig.wr_30 >= -30: missing.append(f"WR={dm_sig.wr_30:.0f} (need <-30)")
                if dm_sig.above_sma: missing.append("above SMA")
                if dm_sig.mfi < 30: missing.append(f"MFI={dm_sig.mfi:.0f} (need >30)")
                verdict = f"No entry. {'; '.join(missing)}. Wait for pullback."

        self._verdict.setText(verdict)
        self._verdict.setStyleSheet(
            f"background: rgba({vrgb},0.06); color: {WHITE}; "
            f"border-left: 3px solid {vc}; border-radius: 3px; padding: 5px 8px;"
        )

        # ── Panel C: Checklist from conviction engine ────────────────
        checks = conv.checklist
        self._mr_checklist_count = len(checks)
        for i, cr in enumerate(self._checks):
            if i < len(checks):
                cr.set_data(*checks[i])
                cr.setVisible(True)
            else:
                cr.setVisible(False)

    def _refresh_filing(self):
        from modules.setup_classifier import (
            classify_setup_v3,
            OptionsSignalState,
            MomentumState,
            SETUP_COLORS,
        )

        fv, ctx, ps = self._fv, self._ctx, self._ps
        badge_c = {"BULLISH": EM, "BEARISH": RED}.get(
            getattr(fv, "badge_color", None), MUTED
        )

        # Strip
        if fv is None:
            self._filing_badge.set_badge("NO FILING", "NEUTRAL")
            self._filing_detail_lbl.setText("No actionable filing in past 72h")
            self._filing_detail_lbl.setStyleSheet(f"color: {MUTED};")
            self._conviction_lbl.setText("-")
            self._filing_recency_lbl.setText("—")
            self._filing_setup_lbl.setText("SETUP: —")
            self._filing_subject_lbl.setText("")
            self._filing_deal_lbl.setText("")
            self._filing_conv_badge.set_badge("CONV —", "NEUTRAL")
            return

        self._filing_badge.set_badge(fv.badge_text, fv.badge_color)
        self._filing_detail_lbl.setText(fv.detail_line)
        self._filing_detail_lbl.setStyleSheet(f"color: {badge_c};")
        h = fv.recency_h
        rec_str = (
            f"fresh {h:.1f}h"
            if h < 6
            else (f"recent {h:.1f}h" if h < 24 else f"{h:.0f}h ago")
        )
        self._filing_recency_lbl.setText(rec_str)
        self._filing_recency_lbl.setStyleSheet(
            f"color: {EM if h < 6 else (GOLD if h < 24 else MUTED)};"
        )
        filled = "●" * fv.conviction + "○" * (10 - fv.conviction)
        conv_c = EM if fv.conviction >= 7 else (GOLD if fv.conviction >= 4 else MUTED)
        self._conviction_lbl.setText(filled)
        self._conviction_lbl.setStyleSheet(f"color: {conv_c};")

        # Setup re-classification
        setup_label, setup_color = "—", MUTED
        if ctx and hasattr(ctx, "regime") and ps:
            try:
                opts = OptionsSignalState(
                    gex_regime=ctx.regime.regime,
                    gex_rising=getattr(ctx.gex, "gex_rising", False),
                    pcr=getattr(ctx.walls, "pcr_oi", 1.0) or 1.0,
                    pcr_trending="FLAT",
                    iv_skew="FLAT",
                    delta_bias="NEUTRAL",
                    call_oi_wall_pct=0.0,
                    pct_to_resistance=getattr(ctx.walls, "resistance_pct", None),
                    pcroi=getattr(ctx.walls, "pcr_oi", 1.0) or 1.0,
                )
                mom = MomentumState(
                    bb_position=ps.bb_position,
                    position_state=ps.position_state,
                    vol_state=ps.vol_state,
                    wr_phase=ps.wr_phase,
                    wr_value=ps.wr_value,
                    wr_in_momentum=ps.wr_in_momentum,
                )
                st, _ = classify_setup_v3(
                    viability_score=ctx.viability.score,
                    filing_variance=fv.variance,
                    filing_direction=fv.badge_color,
                    filing_conviction=fv.conviction,
                    filing_category=fv.category.value,
                    opts=opts,
                    mom=mom,
                )
                setup_label = st.value
                setup_color = SETUP_COLORS.get(st, MUTED)
            except Exception:
                setup_label = fv.badge_text.split()[0]

        self._setup_badge.set_badge(f"SETUP: {setup_label}", setup_label)
        self._filing_setup_lbl.setText(f"SETUP: {setup_label}")
        self._filing_setup_lbl.setStyleSheet(
            f"color: {setup_color}; font-weight: bold;"
        )
        self._filing_subject_lbl.setText(f"↳ {fv.raw_subject}")
        self._filing_deal_lbl.setText(fv.detail_line)
        self._filing_deal_lbl.setStyleSheet(f"color: {badge_c};")
        conv_text = f"CONV {fv.conviction}/10" + (" ✓" if fv.confirmed else "")
        self._filing_conv_badge.set_badge(
            conv_text,
            (
                "BULLISH"
                if fv.conviction >= 7
                else ("NEUTRAL" if fv.conviction >= 4 else "BEARISH")
            ),
        )

    def _update_chart(self):
        df = self._price_df
        if df is not None and not df.empty:
            self._chart.update_data(df, self._ctx, self._ps, self._symbol)

    def _apply_ride(self, r):
        """
        Apply pre-computed BB Ride result to the ride verdict strip.

        DataManager computes via compute_ride() ONCE, emits BBRideResult here.
        This method READS only — zero recomputation.
        Same pattern as _apply_conviction for MR.
        """
        self._current_ride = r
        if not r.data_sufficient:
            self._ride_action.setText("—")
            self._ride_action.setStyleSheet(f"color: {MUTED};")
            self._ride_detail.setText("insufficient data")
            self._ride_detail.setStyleSheet(f"color: {MUTED};")
            self._ride_targets.setText("")
            self._ride_pctb.setText("%B=—")
            self._ride_pctb.setStyleSheet(f"color: {MUTED};")
            self._ride_vol.setText("Vol=—")
            self._ride_vol.setStyleSheet(f"color: {MUTED};")
            if "BB %B" in self._kpi:
                self._kpi["BB %B"].set_value("—", MUTED)
                self._kpi["BB %B"].set_delta("—", MUTED)
            return

        pctb = r.bb_pct

        # KPI tile: BB %B
        if "BB %B" in self._kpi:
            pctb_c = GREEN if pctb >= 1.0 else (GOLD if pctb >= 0.75 else MUTED)
            self._kpi["BB %B"].set_value(f"{pctb:.2f}", pctb_c)
            if pctb >= 1.0:
                self._kpi["BB %B"].set_delta("AT UPPER", GREEN)
            elif pctb >= 0.75:
                self._kpi["BB %B"].set_delta("NEAR UB", GOLD)
            elif pctb >= 0.5:
                self._kpi["BB %B"].set_delta("MID BAND", MUTED)
            else:
                self._kpi["BB %B"].set_delta("BELOW MID", RED)

        # %B and Vol on strip
        pctb_c = GREEN if pctb >= 1.0 else (GOLD if pctb >= 0.75 else MUTED)
        self._ride_pctb.setText(f"%B={pctb:.2f}")
        self._ride_pctb.setStyleSheet(f"color: {pctb_c};")
        vol_c = EM if r.vol_ratio >= 1.5 else (GREEN if r.vol_ratio >= 1.0 else MUTED)
        self._ride_vol.setText(f"Vol={r.vol_ratio:.1f}x")
        self._ride_vol.setStyleSheet(f"color: {vol_c};")

        # Options/filing overlay
        overlay_parts = []
        try:
            ctx = self._ctx
            if ctx and hasattr(ctx, "pcr_oi") and ctx.pcr_oi is not None:
                if ctx.pcr_oi > 1.2: overlay_parts.append("PCR bullish")
                elif ctx.pcr_oi < 0.6: overlay_parts.append("PCR bearish ⚠")
            if ctx and hasattr(ctx, "call_oi_wall_pct") and ctx.call_oi_wall_pct:
                if ctx.call_oi_wall_pct < 3: overlay_parts.append(f"call wall {ctx.call_oi_wall_pct:.1f}% ⚠")
        except Exception:
            pass
        try:
            fv = getattr(self, "_fv", None)
            if fv and hasattr(fv, "conviction") and fv.conviction >= 7: overlay_parts.append("filing bullish")
            elif fv and hasattr(fv, "conviction") and fv.conviction <= 2: overlay_parts.append("filing bearish ⚠")
        except Exception:
            pass
        overlay_str = f" · {', '.join(overlay_parts)}" if overlay_parts else ""

        # State → action + detail + targets
        if r.entry_triggered:
            grade_c = GREEN if r.grade.startswith("A") else (GOLD if r.grade.startswith("B") else MUTED)
            action = r.verdict.split("—")[0].strip() if "—" in r.verdict else r.verdict
            self._ride_action.setText(action)
            self._ride_action.setStyleSheet(f"color: {grade_c};")
            detail = r.verdict.split("—")[1].strip() if "—" in r.verdict else ""
            self._ride_detail.setText(f"{detail}{overlay_str}")
            self._ride_detail.setStyleSheet(f"color: {grade_c};")
            self._ride_targets.setText(f"PT {r.pt_price:,.0f} (+10%) · Trail {r.trail_stop:,.0f} (-{r.trail_pct:.1f}%)")
            self._ride_targets.setStyleSheet(f"color: {EM};")

        elif pctb >= 1.0:
            above_trail = r.close > r.trail_stop
            if above_trail:
                self._ride_action.setText("△ HOLD RIDE")
                self._ride_action.setStyleSheet(f"color: {EM};")
                self._ride_detail.setText(f"above trail stop · above UB ({r.bb_upper:,.0f}){overlay_str}")
                self._ride_detail.setStyleSheet(f"color: {EM};")
            else:
                self._ride_action.setText("⚠ EXIT RIDE")
                self._ride_action.setStyleSheet(f"color: {RED};")
                self._ride_detail.setText(f"trail stop hit{overlay_str}")
                self._ride_detail.setStyleSheet(f"color: {RED};")
            self._ride_targets.setText(f"PT {r.pt_price:,.0f} · Trail {r.trail_stop:,.0f} · Mid {r.bb_mid:,.0f}")
            self._ride_targets.setStyleSheet(f"color: {GOLD if above_trail else RED};")

        elif pctb >= 0.5:
            above_trail = r.close > r.trail_stop
            if pctb >= 0.75 and above_trail:
                self._ride_action.setText("▽ HOLD WEAK")
                self._ride_action.setStyleSheet(f"color: {GOLD};")
                self._ride_detail.setText(f"dipped below UB, still above trail{overlay_str}")
                self._ride_detail.setStyleSheet(f"color: {GOLD};")
            else:
                self._ride_action.setText("⚠ EXIT WEAK")
                self._ride_action.setStyleSheet(f"color: {RED};")
                self._ride_detail.setText(f"below UB and trail stop{overlay_str}")
                self._ride_detail.setStyleSheet(f"color: {RED};")
            self._ride_targets.setText(f"Mid {r.bb_mid:,.0f} · Trail {r.trail_stop:,.0f}")
            self._ride_targets.setStyleSheet(f"color: {MUTED};")

        else:
            self._ride_action.setText("✕ NO RIDE")
            self._ride_action.setStyleSheet(f"color: {RED};")
            self._ride_detail.setText(f"mid-band broken{overlay_str}")
            self._ride_detail.setStyleSheet(f"color: {MUTED};")
            self._ride_targets.setText("")

        # ── Workflow Analysis: BB RIDE section ─────────────────
        if "BB RIDE" in self._wf:
            if r.entry_triggered:
                # Works for both BBRideResult (sector_type) and ETFRideResult (etf_type)
                ctx_label = getattr(r, "etf_type", None) or getattr(r, "sector_type", "")
                rs_label = getattr(r, "rs_bucket", "")
                ctx_str = f"{ctx_label} · {rs_label}" if rs_label else ctx_label
                ride_text = (
                    f"{r.verdict}\n"
                    f"%B={r.bb_pct:.2f} · Vol={r.vol_ratio:.1f}x · "
                    f"{ctx_str}\n"
                    f"PT {r.pt_price:,.0f} (+10%) · Trail {r.trail_stop:,.0f} "
                    f"(-{r.trail_pct:.1f}%) · Mid {r.bb_mid:,.0f}"
                )
                rc = GREEN if r.grade.startswith("A") else (GOLD if r.grade.startswith("B") else MUTED)
            elif pctb >= 1.0:
                above = r.close > r.trail_stop
                ride_text = (
                    f"RIDING — %B={pctb:.2f}, {'above' if above else 'BELOW'} trail stop\n"
                    f"Trail {r.trail_stop:,.0f} · Mid {r.bb_mid:,.0f} · PT {r.pt_price:,.0f}"
                )
                rc = EM if above else RED
            elif pctb >= 0.5:
                ride_text = f"Near upper band — %B={pctb:.2f}, watching for touch"
                rc = GOLD
            else:
                ride_text = f"No ride — below mid-band, %B={pctb:.2f}"
                rc = MUTED
            self._wf["BB RIDE"].setText(ride_text)
            self._wf["BB RIDE"].setStyleSheet(f"color: {rc};")

        # ── Pre-trade checklist: ride items (appended after MR) ───
        ride_checks = []
        if r.data_sufficient:
            # %B position
            if pctb >= 1.0:
                ride_checks.append(("pass", f"%B={pctb:.2f}", "At/above upper band"))
            elif pctb >= 0.75:
                ride_checks.append(("warn", f"%B={pctb:.2f}", "Near upper band"))
            else:
                ride_checks.append(("fail", f"%B={pctb:.2f}", "Below upper band"))

            # Trail stop
            if r.trail_stop > 0:
                above = r.close > r.trail_stop
                ride_checks.append(
                    ("pass" if above else "fail",
                     f"Trail {r.trail_stop:,.0f}",
                     f"{'Above' if above else 'BELOW'} 3×ATR stop")
                )

            # Volume
            if r.vol_ratio >= 1.3:
                ride_checks.append(("pass", f"Vol {r.vol_ratio:.1f}x", "Volume confirming"))
            elif r.vol_ratio >= 0.8:
                ride_checks.append(("warn", f"Vol {r.vol_ratio:.1f}x", "Average volume"))
            else:
                ride_checks.append(("fail", f"Vol {r.vol_ratio:.1f}x", "Low volume"))

            # Sector/ETF type context
            ctx_type = getattr(r, "etf_type", None) or getattr(r, "sector_type", "UNKNOWN")
            rs = getattr(r, "rs_bucket", "")
            if ctx_type == "CYCLICAL":
                ride_checks.append(("pass", "CYCLICAL", f"Sector {rs.lower()}" if rs else "Cyclical ETF"))
            elif ctx_type in ("BROAD", "THEMATIC"):
                ride_checks.append(("pass", ctx_type, "Favorable ETF type"))
            elif ctx_type == "DEFENSIVE":
                ride_checks.append(("warn", "DEFENSIVE", "Lower ride persistence"))
            elif ctx_type == "COMMODITY":
                ride_checks.append(("warn", "COMMODITY", "Commodity — mixed ride results"))
            # VIX gate (ETF ride only)
            if getattr(r, "vix_gated", False):
                ride_checks.append(("fail", "VIX NORMAL", "ETF ride unprofitable in this regime"))

        offset = getattr(self, "_mr_checklist_count", 0)
        for i, item in enumerate(ride_checks):
            idx = offset + i
            if idx < len(self._checks):
                self._checks[idx].set_data(*item)
                self._checks[idx].setVisible(True)
        # Hide remaining
        for j in range(offset + len(ride_checks), len(self._checks)):
            self._checks[j].setVisible(False)

    # ══════════════════════════════════════════════════════════════════════════
    def _refresh_badges(self):
        """Legacy badge refresh from PriceSignals — will be overwritten by dual-mode."""
        ps = self._ps
        if not ps:
            return
        # These are placeholders until dual-mode updates arrive
        bias = ps.daily_bias
        self._badges["SMA"].set_badge(
            f"{bias} {ps.daily_bias_pct:+.1f}%" if ps.daily_bias_pct else bias,
            {"BULLISH": "BULLISH", "BEARISH": "BEARISH", "NEUTRAL": "NEUTRAL"}.get(bias, "NEUTRAL"),
        )

    def _update_verdict_strip(self, dm_sig):
        """Populate the verdict strip with rich, differentiated guidance."""
        sc = dm_sig.dual_score
        mfi = dm_sig.mfi
        wr = dm_sig.wr_30
        dd = dm_sig.dd_from_high
        streak = dm_sig.red_streak
        bbw_slope = dm_sig.bbw_slope
        pct_sma = dm_sig.pct_from_sma
        opt_ov = dm_sig.options_overlay
        fil_ov = dm_sig.filing_overlay
        is_trap = dm_sig.is_trap

        # Build grade from available data (reuse from Panel B)
        grade = getattr(self, "_current_grade", "—")
        vix_regime = getattr(self, "_vix_regime", "UNKNOWN")
        is_friday = getattr(self, "_is_friday", False)

        # ── TRAP ──
        if sc <= 30 or is_trap:
            action = "⚠ AVOID"
            ac = RED
            reasons = []
            if is_trap: reasons.append("filing TRAP")
            if mfi < 20: reasons.append("no money flow")
            if wr > -20: reasons.append("not oversold")
            detail = ", ".join(reasons) if reasons else "weak setup"
            exit_txt = ""

        # ── Entry triggered ──
        elif dm_sig.entry_triggered:
            # Use centralized verdict from compute_conviction
            full_verdict = getattr(self, "_current_verdict", "")

            # Split verdict into action + detail
            if " — " in full_verdict:
                action, detail = full_verdict.split(" — ", 1)
            else:
                action = full_verdict
                detail = ""

            # ETF language fix: "reversion" → "pullback" (same signal, better label)
            if self._mode.rv_word != "reversion":
                action = action.replace("reversion", self._mode.rv_word).replace("Reversion", self._mode.rv_word.capitalize())
                detail = detail.replace("reversion", self._mode.rv_word).replace("Reversion", self._mode.rv_word.capitalize())

            # Add overlay info
            overlay_parts = []
            if opt_ov > 0: overlay_parts.append(f"Opt+{opt_ov}")
            elif opt_ov < 0: overlay_parts.append(f"Opt{opt_ov}")
            if fil_ov > 0: overlay_parts.append(f"Fil+{fil_ov}")
            elif fil_ov < 0: overlay_parts.append(f"Fil{fil_ov}")
            if overlay_parts:
                detail = f"{detail} ({', '.join(overlay_parts)})" if detail else ", ".join(overlay_parts)

            # Color by grade
            if "[A" in action: ac = GREEN
            elif "[B" in action: ac = GOLD
            elif "WATCH" in action or "SKIP" in action: ac = BLUE
            else: ac = MUTED

            conv = getattr(self, "_current_conv", None)
            if conv and conv.target_pct and conv.stop_pct:
                exit_txt = f"PT +{conv.target_pct}% · SL {conv.stop_pct}% · BBW · 30d"
            else:
                exit_txt = "BBW · 30d"

        # ── No entry ──
        else:
            exit_txt = ""
            if mfi < 30:
                if wr < -50 and dd < -10:
                    action = "⏳ CAPITULATION"
                    ac = BLUE
                    detail = f"WR={wr:.0f} DD={dd:.1f}% — deep dip, wait MFI > 30"
                elif wr < -30:
                    action = "⏳ OVERSOLD"
                    ac = GOLD
                    detail = f"WR={wr:.0f} MFI={mfi:.0f} — wait for accumulation"
                else:
                    action = "—"
                    ac = MUTED
                    detail = f"WR={wr:.0f} — not oversold enough"
            elif wr >= -30:
                action = "—"
                ac = MUTED
                detail = f"WR={wr:.0f} — needs < -30"
            elif sc >= 60:
                action = "⏳ FORMING"
                ac = GOLD
                detail = "approaching entry zone"
            else:
                action = "—"
                ac = MUTED
                detail = "conditions not met"

        self._verdict_action.setText(action)
        self._verdict_action.setStyleSheet(f"color: {ac}; font-weight: bold;")
        self._verdict_detail.setText(detail)
        self._verdict_detail.setStyleSheet(f"color: {WHITE};")
        self._verdict_exit.setText(exit_txt)
        self._verdict_exit.setStyleSheet(f"color: {MUTED};")

    def _refresh_badges_dual(self, dm_sig):
        """Update header badges — raw technical state, strategy-neutral."""
        # Grade: show both MR and Ride grades
        mr_grade = getattr(self, "_current_grade", "—")
        ride = self._current_ride
        ride_grade = ride.grade if ride and ride.data_sufficient else "—"
        # Color by the stronger signal
        if mr_grade not in ("—", "D") and ride_grade not in ("—", "D"):
            grade_style = "FRESH"  # both active
        elif mr_grade not in ("—", "C+", "C", "D"):
            grade_style = {"A+": "FRESH", "A": "BULLISH", "B+": "LATE", "B": "LATE"}.get(mr_grade, "NEUTRAL")
        elif ride_grade not in ("—", "C+", "C", "D"):
            grade_style = {"A+": "FRESH", "A": "BULLISH", "B+": "LATE", "B": "LATE"}.get(ride_grade, "NEUTRAL")
        else:
            grade_style = "NEUTRAL"
        mr_label = self._mode.mr_label
        self._badges["TIER"].set_badge(
            f"{mr_label}:{mr_grade} RIDE:{ride_grade}",
            grade_style,
        )

        # WR(30) — raw indicator, no strategy bias
        wr = dm_sig.wr_30
        if wr < -70:
            self._badges["WR"].set_badge(f"WR(30) {wr:.0f} EXTREME", "LATE")
        elif wr < -50:
            self._badges["WR"].set_badge(f"WR(30) {wr:.0f} OVERSOLD", "BULLISH")
        elif wr < -30:
            self._badges["WR"].set_badge(f"WR(30) {wr:.0f} ZONE", "FRESH")
        else:
            self._badges["WR"].set_badge(f"WR(30) {wr:.0f}", "NEUTRAL")

        # MFI — raw indicator
        mfi = dm_sig.mfi
        if mfi >= 50:
            self._badges["MFI"].set_badge(f"MFI {mfi:.0f} STRONG", "BULLISH")
        elif mfi >= 30:
            self._badges["MFI"].set_badge(f"MFI {mfi:.0f} OK", "FRESH")
        else:
            self._badges["MFI"].set_badge(f"MFI {mfi:.0f} WEAK", "BEARISH")

        # SMA — show position, color by ride context (above = good for ride, below = good for MR)
        pctb = ride.bb_pct if ride and ride.data_sufficient else 0
        if not dm_sig.above_sma:
            # Below SMA: good for MR, bad for ride
            style = "BULLISH" if mr_grade not in ("—", "D") else "NEUTRAL"
            self._badges["SMA"].set_badge(f"BELOW SMA {dm_sig.pct_from_sma:+.1f}%", style)
        else:
            # Above SMA: bad for MR, good for ride
            style = "BULLISH" if pctb >= 0.75 else "NEUTRAL"
            self._badges["SMA"].set_badge(f"ABOVE SMA {dm_sig.pct_from_sma:+.1f}%", style)

        # DD from high — raw
        dd = dm_sig.dd_from_high
        streak = dm_sig.red_streak
        if dd <= -10:
            self._badges["DD"].set_badge(f"DD {dd:.0f}% {streak}d red", "FRESH")
        elif dd <= -5:
            self._badges["DD"].set_badge(f"DD {dd:.0f}% {streak}d red", "BULLISH")
        else:
            self._badges["DD"].set_badge(f"DD {dd:.0f}%", "NEUTRAL")

    def _refresh_kpi(self):
        ps, ctx = self._ps, self._ctx
        is_etf = isinstance(ctx, ETFContext) if ctx else False
        if is_etf:
            self._kpi["PCR OI"].set_title("VSR")  # Volume Surge Ratio
            self._kpi["NET GEX"].set_title("VOL TREND")
            self._kpi["TO EXPIRY"].set_title("POC DIST")
        else:
            self._kpi["PCR OI"].set_title("PCR OI")
            self._kpi["NET GEX"].set_title("NET GEX")
            self._kpi["TO EXPIRY"].set_title("TO EXPIRY")

        if self._spot > 0:
            self._kpi["SPOT"].set_value(f"{self._spot:,.2f}", WHITE)
        if ps and ps.wr_value is not None:
            wc = wr_color(ps.wr_value)
            self._kpi["WR(30)"].set_value(f"{ps.wr_value:.1f}", wc)
            self._kpi["WR(30)"].set_delta(ps.wr_phase, wc)
        if ps:
            # MFI tile placeholder (will be overwritten by dual-mode)
            if ps.mfi_value is not None:
                mc = EM if ps.mfi_value >= 50 else (GREEN if ps.mfi_value >= 30 else RED)
                self._kpi["MFI"].set_value(f"{ps.mfi_value:.0f}", mc)
            bc = {"BULLISH": EM, "BEARISH": RED, "NEUTRAL": GOLD}.get(
                ps.daily_bias, MUTED
            )
            self._kpi["vs SMA"].set_value(ps.daily_bias, bc)
            if ps.daily_bias_pct:
                self._kpi["vs SMA"].set_delta(
                    f"{ps.daily_bias_pct:+.1f}% vs SMA", bc
                )
        # Options-derived KPIs — show real or cached data, indicate staleness
        has_real_opts = (
            ctx and hasattr(ctx, "walls")
            and getattr(ctx.walls, "pcr_oi", None) is not None
            and ctx.walls.pcr_oi != 1.0  # default/empty value
        )
        if has_real_opts:
            pcr = ctx.walls.pcr_oi
            self._kpi["PCR OI"].set_value(
                f"{pcr:.3f}", EM if pcr >= 1.1 else (RED if pcr < 0.7 else WHITE)
            )
            sentiment = getattr(ctx.walls, "pcr_sentiment", "")
            self._kpi["PCR OI"].set_delta(sentiment, MUTED)
        else:
            self._kpi["PCR OI"].set_value("—", MUTED)
            self._kpi["PCR OI"].set_delta("no data", MUTED)

        if has_real_opts and hasattr(ctx, "gex"):
            g = ctx.gex.net_gex
            self._kpi["NET GEX"].set_value(
                f"{g:+,.0f}M", EM if g < 0 else (RED if g > 0 else MUTED)
            )
            self._kpi["NET GEX"].set_delta(ctx.gex.regime, MUTED)
        else:
            self._kpi["NET GEX"].set_value("—", MUTED)
            self._kpi["NET GEX"].set_delta("", MUTED)
        if has_real_opts and ctx and hasattr(ctx, "expiry") and ctx.expiry.days_remaining < 99:
            d = ctx.expiry.days_remaining
            self._kpi["TO EXPIRY"].set_value(
                f"{d}d", RED if d <= 2 else (GOLD if d <= 4 else WHITE)
            )
            self._kpi["TO EXPIRY"].set_delta(f"{ctx.expiry.pin_risk} pin", MUTED)
        else:
            self._kpi["TO EXPIRY"].set_value("—", MUTED)
            self._kpi["TO EXPIRY"].set_delta("", MUTED)
        if ps:
            vc = {"SQUEEZE": VIOLET, "EXPANDED": GOLD, "NORMAL": WHITE}.get(
                ps.vol_state, MUTED
            )
            self._kpi["VOL STATE"].set_value(ps.vol_state, vc)
            self._kpi["VOL STATE"].set_delta(f"{ps.bb_width_pctl:.0f}th pctl", MUTED)

    def _refresh_intel(self):
        ctx, ps = self._ctx, self._ps
        if ctx is None:
            return

        # ── ETFContext: no F&O panels — show viability + ETF badge only ──
        if not hasattr(ctx, "regime"):
            v = ctx.viability
            sc = score_color(v.score)
            self._pb.set_accent(sc)
            self._regime_lbl.setText("REGIME: ETF — No options chain")
            self._regime_lbl.setStyleSheet(f"color: {BLUE}; font-weight: bold;")
            for lr in self._levels:
                lr.setVisible(False)
            return  # skip all F&O-specific panel logic below

        r = ctx.regime
        rc = {
            "TREND-FRIENDLY": EM,
            "PINNING": RED,
            "GEX POSITIVE": GOLD,
            "GEX NEG / EXPIRY RISK": GOLD,
            "NEUTRAL": GOLD,
        }.get(r.regime, MUTED)
        self._pa.set_accent(rc)
        self._regime_lbl.setText(f"REGIME: {r.regime}")
        self._regime_lbl.setStyleSheet(f"color: {rc}; font-weight: bold;")
        self._regime_detail.setText(r.detail)
        tint = {
            "TREND-FRIENDLY": "16,185,129",
            "PINNING": "239,68,68",
            "GEX POSITIVE": "245,158,11",
            "GEX NEG / EXPIRY RISK": "245,158,11",
            "NEUTRAL": "245,158,11",
        }
        rgb = tint.get(r.regime, "100,116,139")
        self._regime_frame.setStyleSheet(
            f"background: rgba({rgb},0.06); border-left: 3px solid {rc}; "
            f"border-radius: 4px; padding: 4px 8px;"
        )

        v = ctx.viability
        _regime_badge_state = {
            "TREND-FRIENDLY": "BULLISH",
            "PINNING": "BEARISH",
            "GEX POSITIVE": "LATE",
            "GEX NEG / EXPIRY RISK": "LATE",
            "NEUTRAL": "NEUTRAL",
        }
        self._badges.get("REGIME", Badge()).set_badge(
            f"REGIME: {r.regime}", _regime_badge_state.get(r.regime, "NEUTRAL")
        )

        try:
            from modules.commentary import get_commentary

            comm = get_commentary(ctx, ps, self._symbol, self._price_df)
        except Exception as _e:
            logger.exception("get_commentary failed: %s", _e)  # ← shows real error
            comm = {}
        for key, ck in {
            "TREND & STATE": "bias_line",
            "GEX REGIME": "gex_line",
            "OI WALLS": "wall_line",
            "EXPIRY": "expiry_line",
            "WILLIAMS %R": "wr_line",
            "MFI FLOW": "mfi_line",
        }.items():
            if key in self._wf:
                self._wf[key].setText(comm.get(ck, ""))

        # Options verdict — shown as context, NOT as trade action
        # (conviction engine owns the real verdict in Panel A)
        opts_verdict = comm.get("verdict", "")
        if opts_verdict:
            self._wf.get("OPTIONS IMPACT", self._verdict).setText(
                f"Options context: {opts_verdict}"
            )

        # Risk notes from options viability (informational, not sizing)
        while self._risk_container.count():
            w = self._risk_container.takeAt(0).widget()
            if w:
                w.deleteLater()
        for note in v.risk_notes[:3]:
            self._risk_container.addWidget(RiskNote(note))

        w = ctx.walls
        level_data = []
        if w.resistance:
            level_data.append(
                ("RESISTANCE", w.resistance, RED, f"{w.resistance_pct:+.1f}%")
            )
        if w.support:
            level_data.append(("SUPPORT", w.support, GREEN, f"{w.support_pct:+.1f}%"))
        if w.max_pain:
            level_data.append(("MAX PAIN", w.max_pain, GOLD, ""))
        if ctx.gex.hvl:
            level_data.append(("GEX HVL", ctx.gex.hvl, VIOLET, ""))
        if ps and ps.daily_sma:
            level_data.append(
                (
                    "DAILY SMA",
                    ps.daily_sma,
                    EM if ps.daily_bias == "BULLISH" else RED,
                    "",
                )
            )
        for i, lr in enumerate(self._levels):
            if i < len(level_data):
                lr.set_data(*level_data[i])
                lr.setVisible(True)
            else:
                lr.setVisible(False)

        if ctx.walls.pcr_oi:
            self._bot["PCR"].set_badge(f"PCR {ctx.walls.pcr_oi:.2f}", "NEUTRAL")
        self._bot["PIN"].set_badge(
            f"PIN {ctx.expiry.pin_risk}",
            {"HIGH": "BEARISH", "MODERATE": "LATE", "LOW": "BULLISH"}.get(
                ctx.expiry.pin_risk, "NEUTRAL"
            ),
        )
        self._bot["GEX"].set_badge(
            f"GEX {ctx.gex.regime.upper()}",
            {"Positive": "BEARISH", "Negative": "BULLISH", "Neutral": "NEUTRAL"}.get(
                ctx.gex.regime, "NEUTRAL"
            ),
        )
        if ctx.expiry.days_remaining < 99:
            self._bot["DTE"].set_badge(f"+{ctx.expiry.days_remaining}D", "NEUTRAL")

        for i, cr in enumerate(self._checks):
            if i < len(v.checklist):
                ci = v.checklist[i]
                cr.set_data(ci.status, ci.item, ci.detail, ci.implication)
                cr.setVisible(True)
            else:
                cr.setVisible(False)

    def _refresh_intel_etf(self, ctx) -> None:
        """Render all three intelligence panels for ETFContext."""
        from ui.theme import (
            EM,
            RED,
            GOLD,
            MUTED,
            WHITE,
            GREEN,
            BLUE,
            VIOLET,
            score_color,
        )
        from ui.components import RiskNote, ChecklistRow

        v = ctx.viability
        info = ctx.info
        vp = ctx.volume_profile
        ev = ctx.etf_volume
        et = ctx.etf_trend
        nav = ctx.etf_nav

        # ── ETF-specific workflow headings ───────────────────────────────────
        if hasattr(self, "_wf_titles"):
            title_map = {
                "TREND & STATE": "TREND & STATE",
                "GEX REGIME": "VOLUME & VSR",
                "OI WALLS": "VWAP & POC",
                "EXPIRY": "UNDERLYING",
                "WILLIAMS %R": "NAV & PREMIUM",
            }
            for old, new in title_map.items():
                if old in self._wf_titles:
                    self._wf_titles[old].setText(new.upper())

        # ── KPI overrides ─────────────────────────────────────────────────────
        if ev:
            vsr_c = EM if ev.vsr >= 2.5 else (GOLD if ev.vsr >= 1.5 else MUTED)
            self._kpi["PCR OI"].set_value(f"{ev.vsr:.1f}x", vsr_c)
            self._kpi["PCR OI"].set_delta(f"{ev.surge_label} · {ev.trend}", vsr_c)
        else:
            self._kpi["PCR OI"].set_value("—", MUTED)
            self._kpi["PCR OI"].set_delta("VSR N/A", MUTED)

        if nav and nav.available:
            nav_c = (
                EM
                if nav.premium_pct <= -0.25
                else (RED if nav.premium_pct >= 1.0 else WHITE)
            )
            self._kpi["NET GEX"].set_value(f"{nav.premium_pct:+.2f}%", nav_c)
            self._kpi["NET GEX"].set_delta(nav.label, nav_c)
        else:
            self._kpi["NET GEX"].set_value("—", MUTED)
            self._kpi["NET GEX"].set_delta("NAV N/A", MUTED)

        aum_str = (
            f"₹{info.aum_cr/1000:.0f}kCr"
            if info.aum_cr >= 1000
            else f"₹{info.aum_cr:.0f}Cr"
        )
        self._kpi["TO EXPIRY"].set_value(aum_str, WHITE)
        self._kpi["TO EXPIRY"].set_delta(info.category.replace("_", " ").title(), MUTED)

        # MFI
        ps = self._ps

        if ps and ps.mfi_value is not None:
            mv = ps.mfi_value
            if not ps.mfi_reliable:
                mfi_line = f"MFI {mv:.0f} — volume too thin, signal unreliable"
            elif ps.mfi_diverge:
                mfi_line = (
                    f"MFI {mv:.0f} ⚠ BEARISH DIVERGENCE — "
                    f"price near high but money leaving → SIZE capped HALF"
                )
            else:
                desc = {
                    "STRONG": "strong buying pressure — volume confirming upside",
                    "RISING": "money flowing in — volume supporting price",
                    "NEUTRAL": "neutral money flow — no volume edge",
                    "FALLING": "money flow softening — watch for continuation",
                    "WEAK": "heavy selling pressure — distribution in progress",
                }.get(ps.mfi_state, "")
                mfi_line = f"MFI {mv:.0f} {ps.mfi_state} — {desc}"
        else:
            mfi_line = "MFI — volume data unavailable"

        # ── Panel A — ETF Momentum + Workflow ─────────────────────────────────
        sc = score_color(v.score)
        self._pa.set_accent(sc)
        lbl_col = {"STRONG": EM, "MODERATE": GOLD, "WEAK": GOLD, "AVOID": RED}.get(
            v.label, MUTED
        )
        self._regime_lbl.setText(f"ETF MOMENTUM: {v.label}")
        self._regime_lbl.setStyleSheet(f"color: {lbl_col}; font-weight: bold;")
        self._regime_detail.setText(f"{info.name}  ·  {info.underlying}")
        tint = {
            "STRONG": "16,185,129",
            "MODERATE": "245,158,11",
            "WEAK": "245,158,11",
            "AVOID": "239,68,68",
        }.get(v.label, "100,116,139")
        self._regime_frame.setStyleSheet(
            f"background: rgba({tint},0.06); border-left: 3px solid {lbl_col}; "
            f"border-radius: 4px; padding: 4px 8px;"
        )

        if "REGIME" in self._badges:
            # Override viability label when ride is active
            ride = self._current_ride
            ride_active = (ride and ride.data_sufficient and
                           ride.bb_pct >= 1.0 and ride.grade not in ("—", "D"))
            if ride_active:
                badge_label = f"ETF: RIDE {ride.grade}"
                badge_style = "BULLISH" if ride.grade.startswith("A") else "NEUTRAL"
            else:
                badge_label = f"ETF: {v.label}"
                badge_style = (
                    "BULLISH"
                    if v.label == "STRONG"
                    else "NEUTRAL" if v.label in ("MODERATE", "WEAK") else "BEARISH"
                )
            self._badges["REGIME"].set_badge(badge_label, badge_style)

        trend_line = (
            f"Daily {ctx.daily_bias}  ·  BB: {ctx.bb_state.replace('_', ' ')}  ·  "
            f"W%R {ctx.wr_value:.0f} ({'in zone' if ctx.wr_in_momentum else 'NOT in zone'})"
        )
        vol_line = (
            f"VSR {ev.vsr:.1f}x → {ev.surge_label}  ·  Volume {ev.trend}"
            if ev
            else "Volume data unavailable"
        )
        vwap_line = (
            f"{'Above' if et.above_vwap else 'Below'} VWAP ({et.pct_from_vwap:+.1f}%)"
            f"  ·  VWAP: {et.vwap:.2f}"
            if et and et.vwap > 0
            else "VWAP unavailable"
        )
        underlying_line = (
            f"{info.underlying}: {et.underlying_bias}  ({et.underlying_pct:+.1f}% 20d)"
            if et
            else "Underlying data unavailable"
        )
        nav_line = (
            f"NAV: {nav.nav:.2f}  ·  Spot: {nav.spot:.2f}  ·  "
            f"{nav.label} ({nav.premium_pct:+.2f}%)"
            if nav and nav.available
            else "NAV unavailable"
        )
        wf_map = {
            "TREND & STATE": trend_line,
            "GEX REGIME": vol_line,
            "OI WALLS": vwap_line,
            "EXPIRY": underlying_line,
            "WILLIAMS %R": nav_line,
            "MFI FLOW": mfi_line,
        }
        for key, line in wf_map.items():
            if key in self._wf:
                self._wf[key].setText(line)

        bd = v.breakdown
        breakdown_str = "  ·  ".join(f"{k} {pts}pt" for k, pts in bd.items())
        verdict_text = (
            f"Score {v.score}/100 → {v.label}  ·  SIZE {v.sizing}\n"
            f"{breakdown_str}\n"
            f"{'; '.join(v.reasons[:4])}"
        )
        v_rgb = {"SKIP": "239,68,68", "HALF": "245,158,11"}.get(v.sizing, "16,185,129")
        v_col = {"SKIP": RED, "HALF": GOLD}.get(v.sizing, EM)
        self._verdict.setText(verdict_text)
        self._verdict.setStyleSheet(
            f"background: rgba({v_rgb},0.06); color: {WHITE}; "
            f"border-left: 3px solid {v_col}; border-radius: 3px; padding: 5px 8px;"
        )

        # ── Panel B — ETF Levels ─────────────────────────────────────────────
        self._pb.set_accent(sc)

        while self._risk_container.count():
            w = self._risk_container.takeAt(0).widget()
            if w:
                w.deleteLater()
        for r in v.reasons[:3]:
            self._risk_container.addWidget(RiskNote(r))

        level_data = []
        if vp:
            level_data.append(("VAH", vp.vah, RED, "val area"))
            level_data.append(("POC", vp.poc, GOLD, "vol node"))
            level_data.append(("VAL", vp.val, GREEN, "val area"))
        if et and et.vwap > 0:
            level_data.append(
                (
                    "VWAP",
                    et.vwap,
                    BLUE,
                    f"{et.pct_from_vwap:+.1f}%",
                )
            )
        if self._ps and self._ps.daily_sma:
            level_data.append(
                (
                    "DAILY SMA",
                    self._ps.daily_sma,
                    EM if self._ps.daily_bias == "BULLISH" else RED,
                    "",
                )
            )
        for i, lr in enumerate(self._levels):
            if i < len(level_data):
                lr.set_data(*level_data[i])
                lr.setVisible(True)
            else:
                lr.setVisible(False)

        # Bottom badges: VSR / SURGE / UNDERLYING / AUM
        if ev:
            self._bot["PCR"].set_badge(f"VSR {ev.vsr:.1f}x", "NEUTRAL")
            self._bot["PIN"].set_badge(
                ev.surge_label,
                {
                    "SURGE": "BULLISH",
                    "ELEVATED": "BULLISH",
                    "NORMAL": "NEUTRAL",
                    "DRY": "BEARISH",
                }.get(ev.surge_label, "NEUTRAL"),
            )
        if et:
            self._bot["GEX"].set_badge(
                et.underlying_bias[:4],
                {"BULLISH": "BULLISH", "BEARISH": "BEARISH", "NEUTRAL": "NEUTRAL"}.get(
                    et.underlying_bias, "NEUTRAL"
                ),
            )
        aum_badge = (
            f"AUM {info.aum_cr/1000:.0f}kCr"
            if info.aum_cr >= 1000
            else f"AUM {info.aum_cr:.0f}Cr"
        )
        self._bot["DTE"].set_badge(aum_badge, "NEUTRAL")

        # ── Panel C — ETF Checklist ───────────────────────────────────────────
        for i, cr in enumerate(self._checks):
            if i < len(v.checklist):
                ci = v.checklist[i]
                cr.set_data(ci.status, ci.item, ci.detail, ci.implication)
                cr.setVisible(True)
            else:
                cr.setVisible(False)
