"""nimbus_v3.data.earnings_calendar — NSE earnings event calendar.

Purpose
───────
Surface "EARNINGS in N session(s)" as a caution flag on the
sidebar when an NSE listed company is about to publish quarterly
results. Earnings announcements produce sharp same-day / prior-day
reactions that the BB-ride momentum strategy is not equipped to
handle — entering 1-2 sessions before results is precisely the
trade the operator wants to avoid.

This module is the domain layer:
  - Fetches the universe-wide forthcoming-events JSON from NSE's
    ``/api/event-calendar`` endpoint.
  - Filters to results-bearing board meetings (the endpoint also
    returns dividend declarations, AGMs, postal ballots, etc.).
  - Caches the parsed table to parquet so subsequent symbol
    clicks don't re-hit NSE.
  - Answers the per-symbol question "is this symbol within N
    trading sessions of its next earnings announcement?".

The HTTP fetch composes :class:`NSEClient.fetch`, which already
handles the warm/seed/cookie/retry/cooldown handshake. We pass
the right URL + referer + params and let the client do the rest.

Failure modes
─────────────
This is advisory data; failure modes degrade rather than break:

  - NSE endpoint returns ``None`` (404 / WAF block / cooldown):
    the cache is consulted; if the cache is stale or absent, the
    predicate returns ``None`` ("we don't know") and the sidebar
    renders a muted "—".
  - Malformed payload (unexpected fields / dates): the offending
    row is logged and dropped; remaining rows continue.
  - Symbol not present in the calendar: predicate returns
    ``None`` — most NSE symbols don't have a *forthcoming* event
    at any given moment, so absence is the normal case.

Trading-day arithmetic
──────────────────────
The "within N sessions" check walks calendar days forward from
today, skipping weekends. NSE holidays are NOT considered (we
don't have a holiday calendar in NIMBUS); on a holiday the
window may be off by one day, which is acceptable for an
advisory flag — the operator still sees a caution, possibly one
session early. False positives on the side of caution are fine.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Final

import pandas as pd

from nimbus_v3.data.nse_client import NSEClient
from nimbus_v3.data.paths import cache_dir


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════════════

#: NSE endpoint that returns the forthcoming-events list. Query params
#: ``index=equities`` restricts to listed equities (the endpoint also
#: serves SME and debt segments). ``from_date`` / ``to_date`` accept
#: ``DD-MM-YYYY``; omitting them gives the all-forthcoming list which
#: is usually ~30 days ahead.
_EVENT_CALENDAR_URL: Final[str] = (
    "https://www.nseindia.com/api/event-calendar"
)

#: Referer NSE expects for this endpoint. Different referers get
#: different cookie jars in :class:`NSEClient`; this URL matches the
#: page that opens the event-calendar UI in the browser.
_EVENT_CALENDAR_REFERER: Final[str] = (
    "https://www.nseindia.com/companies-listing/corporate-filings-event-calendar"
)

#: Default lookahead window when the operator doesn't specify one.
#: 2 trading sessions = today + the next NSE session. Matches the
#: operator's stated preference: "next 2 sessions".
DEFAULT_LOOKAHEAD_SESSIONS: Final[int] = 2

#: Default lookahead horizon for the universe-wide fetch (calendar
#: days, not trading days). 30 days covers the full quarterly results
#: window so a single morning fetch captures every imminent earnings
#: event across the universe.
_FETCH_HORIZON_DAYS: Final[int] = 30

#: Cache filename. One file holds the full upcoming-events table —
#: no per-symbol fan-out, since the endpoint serves the universe in
#: a single response. Refresh cadence: once per day; the cache age
#: is checked against ``DEFAULT_CACHE_TTL`` below.
_CACHE_FILENAME: Final[str] = "earnings_calendar.parquet"

#: Stale threshold. Earnings dates can shift (companies postpone
#: board meetings); 12 hours is short enough that any movement
#: published over a workday is reflected on the next app open.
DEFAULT_CACHE_TTL: Final[timedelta] = timedelta(hours=12)

#: Purpose strings that count as "earnings" — i.e. the board meeting
#: agenda explicitly includes financial results. NSE writes the
#: ``purpose`` field as a free-text description, so we match
#: case-insensitively on these substrings rather than requiring an
#: exact equality. Anything not matching is dropped (we don't care
#: about dividend-only meetings, share buybacks, etc.).
_RESULTS_KEYWORDS: Final[tuple[str, ...]] = (
    "financial result",      # most common — "Financial Results"
    "quarterly result",      # rarer variant
    "audited financial",     # year-end variant
    "unaudited financial",   # interim variant
)

#: Field-name candidates seen across NSE's response shape over time.
#: Defensive parsing: read whichever name is present. Order matters —
#: first match wins. The endpoint has been stable for years but
#: unofficial wrappers report variations, so we tolerate them.
_SYMBOL_FIELDS: Final[tuple[str, ...]] = ("symbol", "Symbol")
_DATE_FIELDS: Final[tuple[str, ...]] = (
    "bm_date", "boardMeetingDate", "date", "Date",
)
_PURPOSE_FIELDS: Final[tuple[str, ...]] = (
    "purpose", "Purpose", "subject", "Subject",
)
_COMPANY_FIELDS: Final[tuple[str, ...]] = (
    "company", "Company", "companyName",
)

#: Date format NSE serves in the JSON. Defensive parsing tries this
#: format first, then falls back to pandas' general parser.
_NSE_DATE_FORMAT: Final[str] = "%d-%b-%Y"    # e.g. "15-May-2026"


# ══════════════════════════════════════════════════════════════════════════════
# Public data types
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class EarningsCaution:
    """Result of a per-symbol earnings-window check.

    Holds enough information for the UI to render a precise
    caution string without needing to re-query the calendar.

    Fields:
        symbol:           NSE symbol the caution applies to.
        next_event_date:  Date of the upcoming earnings announcement.
        sessions_away:    Number of trading sessions between today
                          and the event date. 0 = today; 1 = next
                          session; etc.
        purpose:          The raw NSE ``purpose`` string for the
                          board meeting (e.g. "Financial Results").
                          Useful for tooltips / debug.
    """
    symbol: str
    next_event_date: date
    sessions_away: int
    purpose: str


# ══════════════════════════════════════════════════════════════════════════════
# Trading-day arithmetic
# ══════════════════════════════════════════════════════════════════════════════


def _sessions_between(today: date, target: date) -> int:
    """Number of weekday-sessions from ``today`` (inclusive) to
    ``target`` (inclusive), in calendar order.

    Examples (assuming today=Wed 2026-05-13):
        target=Wed 2026-05-13 → 0  (today)
        target=Thu 2026-05-14 → 1  (next session)
        target=Fri 2026-05-15 → 2
        target=Mon 2026-05-18 → 3  (weekend skipped)
        target=Tue 2026-05-19 → 4

    Negative for past dates (rare, but we don't crash).
    Holidays are NOT considered — see module docstring.
    """
    if target < today:
        # Past event — return a negative count for completeness;
        # callers should treat this as "not a caution".
        return -_sessions_between(target, today)

    # Walk day-by-day counting weekdays. The forward direction
    # keeps the algorithm trivially correct even for short ranges.
    sessions = 0
    cursor = today
    while cursor < target:
        cursor = cursor + timedelta(days=1)
        if cursor.weekday() < 5:    # Mon=0..Fri=4
            sessions += 1
    return sessions


# ══════════════════════════════════════════════════════════════════════════════
# EarningsCalendar
# ══════════════════════════════════════════════════════════════════════════════


class EarningsCalendar:
    """Universe-wide forthcoming-earnings table with caching.

    Composes :class:`NSEClient` for the HTTP fetch. The single
    public predicate is :meth:`check_symbol`, which answers "is
    this symbol within N trading sessions of its next earnings
    announcement?".

    Lifecycle
    ─────────
    The recommended usage is one instance per process, constructed
    at app startup and held by MainWindow. The cache is loaded
    lazily on first ``check_symbol`` call; refreshed in the
    background via ``refresh()`` (called explicitly by MainWindow
    on the panel-load cycle, or daily by an auto-refresh tick).
    """

    def __init__(
        self,
        client: NSEClient,
        *,
        cache_path: Path | None = None,
        cache_ttl: timedelta = DEFAULT_CACHE_TTL,
    ) -> None:
        """Args:
            client: Shared :class:`NSEClient` (the singleton from
                ``nse_client.get_shared_client()``).
            cache_path: Override path for the cache parquet.
                Defaults to ``<data>/cache/earnings_calendar/<file>``.
            cache_ttl: Age beyond which the cache is considered
                stale and a fresh fetch is attempted.
        """
        self._client = client
        self._cache_path = (
            cache_path
            if cache_path is not None
            else cache_dir("earnings_calendar") / _CACHE_FILENAME
        )
        self._cache_ttl = cache_ttl
        # Indexed lookup: ``{symbol: (date, purpose)}``. Built on
        # first access from the parquet; rebuilt whenever ``refresh``
        # writes a fresh table.
        self._index: dict[str, tuple[date, str]] = {}
        self._index_loaded: bool = False

    # ── Public API ──────────────────────────────────────────────────────

    def check_symbol(
        self,
        symbol: str,
        *,
        sessions: int = DEFAULT_LOOKAHEAD_SESSIONS,
        today: date | None = None,
    ) -> EarningsCaution | None:
        """Return an :class:`EarningsCaution` if ``symbol`` has an
        upcoming earnings event within ``sessions`` trading days,
        else ``None``.

        Args:
            symbol: NSE ticker (case-insensitive; canonicalised
                upstream).
            sessions: Lookahead window in trading sessions.
                ``2`` (the default) means today + the next session.
            today: Override for testing. Defaults to ``date.today()``
                in the local timezone (effectively IST when running
                on the operator's laptop).

        Returns:
            :class:`EarningsCaution` if a forthcoming event lies in
            the window, else ``None``. ``None`` covers three cases
            (the operator can't distinguish them, by design):
              - Symbol not in the calendar (no event ahead).
              - Event ahead but outside the window.
              - Calendar unavailable / fetch failed (degrade silently).
        """
        if not symbol:
            return None
        sym = symbol.upper().strip()

        self._ensure_index()
        entry = self._index.get(sym)
        if entry is None:
            return None
        event_date, purpose = entry

        ref = today if today is not None else date.today()
        n = _sessions_between(ref, event_date)
        if n < 0:
            # Past event — shouldn't happen if the cache is
            # forthcoming-only, but guard regardless.
            return None
        if n > sessions:
            return None
        return EarningsCaution(
            symbol=sym,
            next_event_date=event_date,
            sessions_away=n,
            purpose=purpose,
        )

    def refresh(self, *, force: bool = False) -> bool:
        """Fetch a fresh calendar from NSE and rewrite the cache.

        Args:
            force: When True, bypass the cache-age check and refetch
                unconditionally. Used by an explicit "refresh
                earnings" trigger.

        Returns:
            True if a refresh succeeded and the index was rebuilt;
            False if NSE was unreachable or returned no usable
            rows (the prior cache, if any, is left intact).
        """
        if not force and self._cache_is_fresh():
            self._ensure_index()
            return True

        df = self._fetch_from_nse()
        if df is None or df.empty:
            # Keep whatever cache we have. Caller's predicate will
            # serve from the stale cache if any, else return None.
            logger.info(
                "earnings_calendar: fetch returned no rows; cache untouched"
            )
            self._ensure_index()
            return False

        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            df.to_parquet(self._cache_path, index=False)
        except OSError:
            logger.exception(
                "earnings_calendar: failed to write cache at %s",
                self._cache_path,
            )
            # Index still gets built in-memory.
        self._rebuild_index(df)
        return True

    # ── Internal helpers ────────────────────────────────────────────────

    def _ensure_index(self) -> None:
        """Lazy-load the on-disk cache into the in-memory index.

        Called by every read path. Idempotent: subsequent calls
        after a successful load are no-ops. A missing or unreadable
        cache leaves the index empty, which makes ``check_symbol``
        return None universally — the safe default.
        """
        if self._index_loaded:
            return
        self._index_loaded = True    # set even on failure to avoid retry storms
        if not self._cache_path.is_file():
            return
        try:
            df = pd.read_parquet(self._cache_path)
        except Exception:    # noqa: BLE001
            logger.exception(
                "earnings_calendar: failed to read cache at %s",
                self._cache_path,
            )
            return
        self._rebuild_index(df)

    def _rebuild_index(self, df: pd.DataFrame) -> None:
        """Rebuild the symbol→(date, purpose) lookup from a parsed
        dataframe.

        Multiple events per symbol can appear when a company has
        more than one upcoming meeting (rare). We keep the
        chronologically earliest forthcoming one — that's the
        relevant signal for the caution flag.
        """
        new_index: dict[str, tuple[date, str]] = {}
        for row in df.itertuples(index=False):
            sym = str(getattr(row, "symbol", "")).upper().strip()
            event_date = getattr(row, "event_date", None)
            purpose = str(getattr(row, "purpose", "") or "")
            if not sym or event_date is None:
                continue
            # Normalise to plain ``date`` regardless of pandas dtype.
            if hasattr(event_date, "to_pydatetime"):
                event_date = event_date.to_pydatetime().date()
            elif isinstance(event_date, datetime):
                event_date = event_date.date()
            if not isinstance(event_date, date):
                continue
            existing = new_index.get(sym)
            if existing is None or event_date < existing[0]:
                new_index[sym] = (event_date, purpose)
        self._index = new_index
        self._index_loaded = True

    def _cache_is_fresh(self) -> bool:
        """True iff the cache file exists and is within the TTL."""
        if not self._cache_path.is_file():
            return False
        mtime = datetime.fromtimestamp(
            self._cache_path.stat().st_mtime, tz=timezone.utc,
        )
        age = datetime.now(tz=timezone.utc) - mtime
        return age < self._cache_ttl

    def _fetch_from_nse(self) -> pd.DataFrame | None:
        """Hit the event-calendar endpoint and return a parsed
        dataframe restricted to results-bearing rows.

        Returns ``None`` when the endpoint is unreachable, returns
        malformed data, or the parsed result is empty.
        """
        today = date.today()
        from_str = today.strftime("%d-%m-%Y")
        to_str = (today + timedelta(days=_FETCH_HORIZON_DAYS)).strftime(
            "%d-%m-%Y"
        )
        payload = self._client.fetch(
            _EVENT_CALENDAR_URL,
            referer=_EVENT_CALENDAR_REFERER,
            params={
                "index": "equities",
                "from_date": from_str,
                "to_date": to_str,
            },
        )
        if payload is None:
            return None
        # NSE returns a JSON list of event records. We tolerate the
        # rare case where the response is wrapped in a dict with a
        # ``data`` key.
        if isinstance(payload, dict):
            payload = payload.get("data") or payload.get("rows") or []
        if not isinstance(payload, list):
            logger.warning(
                "earnings_calendar: unexpected payload shape (%s)",
                type(payload).__name__,
            )
            return None

        return _parse_event_payload(payload)


# ══════════════════════════════════════════════════════════════════════════════
# Payload parser
# ══════════════════════════════════════════════════════════════════════════════


def _parse_event_payload(rows: list) -> pd.DataFrame:
    """Convert raw NSE event records into a clean dataframe.

    Output columns:
        symbol:      str (upper-cased)
        event_date:  ``datetime.date``
        purpose:     str (verbatim from NSE)
        company:     str (when present; "" otherwise)

    Only results-bearing rows are kept. Anything else is dropped
    silently — there's no UI surface for non-results events.
    """
    parsed: list[dict] = []
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        symbol = _first_present(raw, _SYMBOL_FIELDS)
        purpose = _first_present(raw, _PURPOSE_FIELDS)
        date_str = _first_present(raw, _DATE_FIELDS)
        company = _first_present(raw, _COMPANY_FIELDS) or ""

        if not symbol or not purpose or not date_str:
            continue
        if not _is_results_purpose(purpose):
            continue

        event_date = _parse_event_date(date_str)
        if event_date is None:
            continue

        parsed.append({
            "symbol":     str(symbol).upper().strip(),
            "event_date": event_date,
            "purpose":    str(purpose).strip(),
            "company":    str(company).strip(),
        })

    if not parsed:
        return pd.DataFrame(
            columns=["symbol", "event_date", "purpose", "company"]
        )
    return pd.DataFrame(parsed)


def _first_present(d: dict, keys: tuple[str, ...]) -> str | None:
    """Return the first non-empty value among ``keys`` in ``d``."""
    for k in keys:
        v = d.get(k)
        if v is not None and str(v).strip() != "":
            return v
    return None


def _is_results_purpose(purpose: object) -> bool:
    """Case-insensitive substring match against
    :data:`_RESULTS_KEYWORDS`."""
    s = str(purpose).lower()
    return any(kw in s for kw in _RESULTS_KEYWORDS)


def _parse_event_date(raw: object) -> date | None:
    """Parse NSE's date string into ``datetime.date``.

    Tries the canonical ``%d-%b-%Y`` format first (e.g.
    ``"15-May-2026"``) then falls back to pandas' general parser.
    Returns ``None`` on total failure.
    """
    s = str(raw).strip()
    try:
        return datetime.strptime(s, _NSE_DATE_FORMAT).date()
    except ValueError:
        pass
    try:
        ts = pd.to_datetime(s, errors="raise")
        return ts.date() if isinstance(ts, pd.Timestamp) else None
    except Exception:    # noqa: BLE001
        return None
