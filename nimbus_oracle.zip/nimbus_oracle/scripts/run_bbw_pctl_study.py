#!/usr/bin/env python3
"""
scripts/run_bbw_pctl_study.py — Stock-level BBW percentile predictive power.

HYPOTHESIS:
  A stock's BBW percentile relative to its OWN recent history (not absolute,
  not vs other stocks) should predict mean reversion outcomes — especially
  in NORMAL VIX where the existing grade has the weakest signal.

  Tight-window BBW percentile measures volatility compression vs the stock's
  own normal range. The bottom decile = unusually compressed = squeeze setup.
  The top decile = unusually expanded = exhausted move (potential reversion).

DESIGN:
  For each OOS trade (4,511):
    1. Fetch the stock's price history up to entry_date
    2. Compute BBW (BB(20, 2σ)) for each bar
    3. Compute BBW percentile within multiple lookback windows (40/60/80/100d)
    4. Bucket trade outcome by (BBW pctl, VIX regime, window length)
  Output: matrix of win-rate × avg-PnL across all dimensions

DECISION CRITERIA:
  Add as grade factor IF:
    - Clear monotonic separation in at least one window length
    - Survives in NORMAL VIX (the noisy regime where edge is weakest)
    - Doesn't break grade monotonicity when added on top of existing factors
    - Cohen's d > 0.15 between top and bottom buckets

Usage:
    python3 scripts/run_bbw_pctl_study.py
    python3 scripts/run_bbw_pctl_study.py --windows 40,60,80
    python3 scripts/run_bbw_pctl_study.py --max-symbols 50  # for fast iteration
"""
import argparse
import datetime
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("bbw_pctl_study")


# ══════════════════════════════════════════════════════════════════════════════
# DATA LOADING
# ══════════════════════════════════════════════════════════════════════════════

def load_oos_trades(path: str = "data/backtest_results/wf_oos_trades.csv") -> pd.DataFrame:
    """Load OOS trade data with all necessary fields."""
    candidate_paths = [
        path,
        "data/backtest_results/wf_oos_trades.csv",
        "data/oos_trades.csv",
        "/mnt/user-data/uploads/sector_regime_trades.csv",
    ]
    found = None
    for p in candidate_paths:
        if os.path.exists(p):
            found = p
            break
    if found is None:
        logger.error(f"OOS trades CSV not found. Tried: {candidate_paths}")
        sys.exit(1)

    df = pd.read_csv(found)
    df["entry_date"] = pd.to_datetime(df["entry_date"])

    # Derive `win` if missing (raw walkforward output doesn't have it)
    if "win" not in df.columns:
        if "pnl_pct" not in df.columns:
            logger.error(f"CSV missing both 'win' and 'pnl_pct': {df.columns.tolist()}")
            sys.exit(1)
        df["win"] = df["pnl_pct"] > 0
        logger.info("Derived 'win' from pnl_pct > 0")

    # vix_regime is needed for the NORMAL VIX slice — derive if missing
    if "vix_regime" not in df.columns:
        if "vix_at_entry" in df.columns:
            def _vix_bucket(v):
                if pd.isna(v): return "UNKNOWN"
                if v >= 25: return "PANIC"
                if v >= 20: return "ELEVATED"
                if v < 13: return "LOW"
                return "NORMAL"
            df["vix_regime"] = df["vix_at_entry"].apply(_vix_bucket)
            logger.info("Derived 'vix_regime' from vix_at_entry")
        else:
            df["vix_regime"] = "UNKNOWN"
            logger.warning("No vix_regime or vix_at_entry — NORMAL VIX slice will be empty")

    logger.info(f"Loaded {len(df)} OOS trades from {found}")
    logger.info(f"  Date range: {df['entry_date'].min().date()} to {df['entry_date'].max().date()}")
    logger.info(f"  Unique symbols: {df['symbol'].nunique()}")
    logger.info(f"  Columns: {len(df.columns)} (win={df['win'].mean()*100:.1f}%)")
    return df


def fetch_price_history(symbol: str, end_date: pd.Timestamp,
                         lookback_days: int = 250) -> pd.DataFrame:
    """
    Fetch daily OHLC for a symbol up to end_date.
    Uses yfinance with cache to avoid re-fetching.
    """
    start_date = end_date - pd.Timedelta(days=int(lookback_days * 1.6))
    return fetch_price_history_range(symbol, start_date, end_date)


def fetch_price_history_range(symbol: str, start_date: pd.Timestamp,
                               end_date: pd.Timestamp) -> pd.DataFrame:
    """
    Fetch daily OHLC for a symbol over an explicit date range.
    """
    import yfinance as yf

    if not symbol.endswith(".NS") and not symbol.startswith("^"):
        ticker = f"{symbol}.NS"
    else:
        ticker = symbol

    try:
        df = yf.download(
            ticker,
            start=start_date.strftime("%Y-%m-%d"),
            end=end_date.strftime("%Y-%m-%d"),
            progress=False,
            auto_adjust=True,
        )
        if df is None or df.empty:
            return pd.DataFrame()
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        return df[["Open", "High", "Low", "Close", "Volume"]].dropna()
    except Exception as exc:
        logger.debug(f"Fetch failed {symbol}: {exc}")
        return pd.DataFrame()


# ══════════════════════════════════════════════════════════════════════════════
# BBW COMPUTATION
# ══════════════════════════════════════════════════════════════════════════════

def compute_bbw(df: pd.DataFrame, period: int = 20, std_dev: float = 2.0) -> pd.Series:
    """
    Compute Bollinger Band Width as percentage of mid-band.
    BBW = (upper - lower) / mid * 100
    """
    if df.empty or len(df) < period:
        return pd.Series(dtype=float)
    close = df["Close"]
    mid = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = mid + std_dev * std
    lower = mid - std_dev * std
    bbw = ((upper - lower) / mid.replace(0, np.nan)) * 100
    return bbw


def compute_bbw_pctl(bbw: pd.Series, window: int) -> pd.Series:
    """
    Compute BBW percentile within rolling window.
    Returns 0-100 (5 = bottom 5%, 95 = top 5%).
    """
    if bbw.empty:
        return pd.Series(dtype=float)
    return bbw.rolling(window, min_periods=int(window * 0.6)).apply(
        lambda x: pd.Series(x).rank(pct=True).iloc[-1] * 100,
        raw=False,
    )


# ══════════════════════════════════════════════════════════════════════════════
# ENRICHMENT
# ══════════════════════════════════════════════════════════════════════════════

def enrich_trades_with_bbw(
    trades: pd.DataFrame,
    windows: list[int],
    cache_dir: str = "data/bbw_pctl_cache",
) -> pd.DataFrame:
    """
    For each trade, compute BBW percentile at entry across multiple windows.
    Caches per-symbol price data to avoid refetching.
    """
    os.makedirs(cache_dir, exist_ok=True)
    cache: dict[str, dict] = {}
    enriched_rows = []
    skipped = 0
    t0 = time.time()

    symbols = sorted(trades["symbol"].unique())
    logger.info(f"Enriching {len(trades)} trades across {len(symbols)} symbols")
    logger.info(f"Windows: {windows}")

    # Need full date range so every trade has price history available.
    # Earliest trade - max(window) days for BBW warmup, latest trade + 5 days buffer.
    earliest = trades["entry_date"].min() - pd.Timedelta(days=max(windows) + 30)
    latest = trades["entry_date"].max() + pd.Timedelta(days=5)
    logger.info(f"  Fetch range: {earliest.date()} → {latest.date()}")

    for i, sym in enumerate(symbols):
        if i % 25 == 0:
            elapsed = time.time() - t0
            rate = i / elapsed if elapsed > 0 else 0
            eta = (len(symbols) - i) / rate if rate > 0 else 0
            logger.info(f"  [{i}/{len(symbols)}] {sym} (eta {eta:.0f}s)")

        cache_path = os.path.join(cache_dir, f"{sym}.parquet")
        if os.path.exists(cache_path):
            try:
                df = pd.read_parquet(cache_path)
                # Validate: must cover the full date range needed
                if df.empty or df.index.min() > earliest or df.index.max() < latest - pd.Timedelta(days=5):
                    df = pd.DataFrame()  # stale cache, refetch
            except Exception:
                df = pd.DataFrame()
        else:
            df = pd.DataFrame()

        if df.empty:
            df = fetch_price_history_range(sym, earliest, latest)
            if not df.empty:
                try:
                    df.to_parquet(cache_path)
                except Exception:
                    pass

        if df.empty or len(df) < 100:
            skipped += len(trades[trades["symbol"] == sym])
            continue

        # Compute BBW once for this symbol
        bbw = compute_bbw(df, period=20, std_dev=2.0)

        # Compute percentile for each window
        pctl_series = {w: compute_bbw_pctl(bbw, w) for w in windows}

        cache[sym] = {"bbw": bbw, "pctl": pctl_series}

    logger.info(f"Pre-fetch done: {len(cache)} symbols cached, {skipped} trades skipped")

    # Now enrich trades
    for _, trade in trades.iterrows():
        sym = trade["symbol"]
        if sym not in cache:
            continue
        entry_date = trade["entry_date"]
        sym_data = cache[sym]

        bbw_series = sym_data["bbw"]
        try:
            idx = bbw_series.index.get_indexer([entry_date], method="ffill")[0]
            if idx < 0:
                continue
        except Exception:
            continue

        bbw_at_entry = bbw_series.iloc[idx]
        if pd.isna(bbw_at_entry):
            continue

        row = trade.to_dict()
        row["bbw_at_entry"] = float(bbw_at_entry)
        for w in windows:
            pctl = sym_data["pctl"][w].iloc[idx] if idx < len(sym_data["pctl"][w]) else np.nan
            row[f"bbw_pctl_{w}"] = float(pctl) if not pd.isna(pctl) else np.nan

        enriched_rows.append(row)

    enriched = pd.DataFrame(enriched_rows)
    logger.info(f"Enriched: {len(enriched)}/{len(trades)} trades have BBW data")
    return enriched


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def cohens_d(x: pd.Series, y: pd.Series) -> float:
    """Effect size between two groups."""
    if len(x) < 2 or len(y) < 2:
        return 0.0
    nx, ny = len(x), len(y)
    vx, vy = x.var(), y.var()
    pooled_std = np.sqrt(((nx - 1) * vx + (ny - 1) * vy) / (nx + ny - 2))
    if pooled_std == 0:
        return 0.0
    return (x.mean() - y.mean()) / pooled_std


def analyze_window(df: pd.DataFrame, window: int) -> dict:
    """
    Analyze BBW percentile predictive power for a single window length.
    Returns metrics dict.
    """
    col = f"bbw_pctl_{window}"
    if col not in df.columns:
        return {}
    d = df.dropna(subset=[col, "pnl_pct", "win"])
    if len(d) < 100:
        return {"window": window, "n": len(d), "error": "insufficient data"}

    # Bucket by percentile decile
    buckets = [
        (0, 10, "P0-10 (compressed)"),
        (10, 25, "P10-25"),
        (25, 50, "P25-50"),
        (50, 75, "P50-75"),
        (75, 90, "P75-90"),
        (90, 100, "P90-100 (expanded)"),
    ]

    overall_results = []
    for lo, hi, label in buckets:
        s = d[(d[col] >= lo) & (d[col] < hi)]
        if len(s) < 20:
            continue
        overall_results.append({
            "bucket": label,
            "n": len(s),
            "win_pct": s["win"].mean() * 100,
            "avg_pnl": s["pnl_pct"].mean(),
            "med_pnl": s["pnl_pct"].median(),
        })

    # NORMAL VIX only (the regime where we need help)
    normal = d[d["vix_regime"] == "NORMAL"]
    normal_results = []
    for lo, hi, label in buckets:
        s = normal[(normal[col] >= lo) & (normal[col] < hi)]
        if len(s) < 15:
            continue
        normal_results.append({
            "bucket": label,
            "n": len(s),
            "win_pct": s["win"].mean() * 100,
            "avg_pnl": s["pnl_pct"].mean(),
            "med_pnl": s["pnl_pct"].median(),
        })

    # Correlation
    corr = d[col].corr(d["pnl_pct"])

    # Effect size: bottom decile vs middle 50%
    bottom = d[d[col] < 10]["pnl_pct"]
    middle = d[(d[col] >= 25) & (d[col] < 75)]["pnl_pct"]
    top = d[d[col] >= 90]["pnl_pct"]

    d_bot = cohens_d(bottom, middle) if len(bottom) >= 5 else 0
    d_top = cohens_d(top, middle) if len(top) >= 5 else 0

    return {
        "window": window,
        "n": len(d),
        "corr": corr,
        "d_bottom_vs_mid": d_bot,
        "d_top_vs_mid": d_top,
        "overall": overall_results,
        "normal_vix": normal_results,
    }


def print_results(results: list[dict]):
    """Format and print analysis results."""
    print("\n" + "=" * 78)
    print("  BBW PERCENTILE PREDICTIVE POWER — STOCK-LEVEL")
    print("=" * 78)

    for r in results:
        if "error" in r:
            print(f"\n  Window {r['window']}d: SKIPPED ({r['error']})")
            continue
        print(f"\n  ── WINDOW = {r['window']} days ──")
        print(f"  N={r['n']}  corr={r['corr']:+.3f}")
        print(f"  Effect size: bottom vs mid d={r['d_bottom_vs_mid']:+.3f}  |  top vs mid d={r['d_top_vs_mid']:+.3f}")

        print(f"\n  ALL TRADES:")
        print(f"  {'Bucket':>22s}  {'N':>5s}  {'Win%':>6s}  {'Avg PnL':>8s}  {'Med PnL':>8s}")
        for b in r["overall"]:
            print(f"  {b['bucket']:>22s}  {b['n']:5d}  {b['win_pct']:5.1f}%  {b['avg_pnl']:+7.2f}%  {b['med_pnl']:+7.2f}%")

        if r["normal_vix"]:
            print(f"\n  NORMAL VIX ONLY (where we need help most):")
            print(f"  {'Bucket':>22s}  {'N':>5s}  {'Win%':>6s}  {'Avg PnL':>8s}  {'Med PnL':>8s}")
            for b in r["normal_vix"]:
                print(f"  {b['bucket']:>22s}  {b['n']:5d}  {b['win_pct']:5.1f}%  {b['avg_pnl']:+7.2f}%  {b['med_pnl']:+7.2f}%")

    # Cross-window summary
    print("\n" + "=" * 78)
    print("  CROSS-WINDOW SUMMARY")
    print("=" * 78)
    print(f"\n  {'Window':>8s}  {'Corr':>8s}  {'d(bot)':>8s}  {'d(top)':>8s}  {'Verdict':>30s}")
    for r in results:
        if "error" in r:
            continue
        verdict = "no signal"
        if max(abs(r["d_bottom_vs_mid"]), abs(r["d_top_vs_mid"])) >= 0.15:
            verdict = "WEAK signal"
        if max(abs(r["d_bottom_vs_mid"]), abs(r["d_top_vs_mid"])) >= 0.25:
            verdict = "MEANINGFUL signal"
        if max(abs(r["d_bottom_vs_mid"]), abs(r["d_top_vs_mid"])) >= 0.4:
            verdict = "STRONG signal"
        print(f"  {r['window']:>6d}d  {r['corr']:+7.3f}  {r['d_bottom_vs_mid']:+7.3f}  {r['d_top_vs_mid']:+7.3f}  {verdict:>30s}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--windows", default="40,60,80,100",
                    help="Comma-separated rolling window sizes")
    ap.add_argument("--max-symbols", type=int, default=None,
                    help="Limit to top N symbols by trade count (for fast iteration)")
    args = ap.parse_args()

    windows = [int(w) for w in args.windows.split(",")]

    # Load OOS trades
    trades = load_oos_trades()

    # Optionally limit symbols
    if args.max_symbols:
        top_syms = trades["symbol"].value_counts().head(args.max_symbols).index
        trades = trades[trades["symbol"].isin(top_syms)]
        logger.info(f"Limited to top {args.max_symbols} symbols: {len(trades)} trades")

    # Enrich with BBW percentiles
    enriched = enrich_trades_with_bbw(trades, windows)

    if enriched.empty:
        logger.error("No trades enriched. Check yfinance access.")
        sys.exit(1)

    # Save enriched data
    out_path = f"data/bbw_pctl_trades_{datetime.datetime.now():%Y%m%d_%H%M}.csv"
    enriched.to_csv(out_path, index=False)
    logger.info(f"Saved enriched trades to {out_path}")

    # Analyze each window
    results = [analyze_window(enriched, w) for w in windows]

    # Print results
    print_results(results)

    print("\n" + "=" * 78)
    print("  DECISION GUIDANCE")
    print("=" * 78)
    print("""
  ADD AS GRADE FACTOR if:
    - At least one window shows |Cohen's d| >= 0.25 (MEANINGFUL signal)
    - The bottom or top bucket shows >= 5pp win rate edge vs middle
    - Effect persists in NORMAL VIX (not just panic regimes)

  REJECT if:
    - All windows show |d| < 0.15 (no real edge)
    - Effect only shows up in NORMAL/PANIC where existing factors already cover

  Window length recommendation:
    - 40d: catches very recent vol regime (last ~2 months)
    - 60d: ~3 months, balances recency with statistical robustness
    - 80d: ~4 months, smoothest signal but slowest to react
    - 100d: original setting (rejected by earlier factor backtest)
""")


if __name__ == "__main__":
    main()
