"""Edge sub-tab: per-symbol momentum-implied expected edge + reward-to-risk.

A ranked table over the :class:`~nimbus_v3.compute.equity_edge.EdgeResult`.
Pure display — all computation is in the stateless edge engine; this widget
only renders and sorts. Double-clicking a row emits ``symbol_activated`` so
the container can open the symbol on the Dashboard.
"""
from __future__ import annotations

from PyQt6.QtCore import QAbstractTableModel, QModelIndex, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QTableView, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.equity_edge import EdgeHorizonSet, EdgeResult
from nimbus_v3.compute.market_pulse_config import (
    DEFAULT_EDGE_HORIZON,
    EDGE_HORIZONS,
)
from nimbus_v3.ui.theme import (
    BLUE, BORDER, EM, FONT_MONO, GOLD, GREEN, MUTED, RED, S2, WHITE,
)
from nimbus_v3.ui.widgets.formatters import format_adtv_cr

#: "Fresh breakout" filter. A view-only cohort — the body has just cleared
#: the band on the DAILY frame and the ride is still young. This does NOT
#: touch any score: the probes found streak does not predict forward return
#: (entry_probe: flat-to-rising, not decaying), so promoting fresh names in
#: the RANKING would fit an intuition the panel rejected. Isolating them for
#: the eye is a different, safe thing.
#:
#: Max trailing body-above-band run to count as "fresh". 2 = the breakout
#: day and the one after.
_FRESH_MAX_STREAK: int = 2
#: When True, the 4h body-above flag must ALSO be set (confirmed on the
#: secondary timeframe) for a row to pass the Fresh filter. When False, 4h
#: is shown but not required. Toggled in the UI; this is the default.
_FRESH_REQUIRE_4H: bool = False

_TOGGLE_QSS = f"""
QPushButton {{
    background: {S2};
    color: {MUTED};
    border: 1px solid {BORDER};
    border-radius: 3px;
    padding: 3px 10px;
}}
QPushButton:checked {{
    color: {EM};
    border: 1px solid {EM};
}}
QPushButton:hover {{ color: {WHITE}; }}
"""


_QCOLOR_CACHE: dict[str, QColor] = {}


def _qcolor(name) -> QColor:
    """QColor for a palette entry, memoised.

    A full repaint touches ~8.6k cells but draws from a palette of about six
    colours, so constructing a QColor per cell was pure waste. QColor is only
    ever handed straight to setForeground here, never mutated, so sharing
    instances is safe.

    Accepts either a colour string or an already-built QColor (the gradient
    helpers below return the latter), so callers need not care which.
    """
    if isinstance(name, QColor):
        return name
    c = _QCOLOR_CACHE.get(name)
    if c is None:
        c = QColor(name)
        _QCOLOR_CACHE[name] = c
    return c


def _signed_color(v: float) -> QColor:
    # Returns SHARED instances — this is called once per numeric cell.
    if v != v:
        return _qcolor(MUTED)
    return _qcolor(GREEN) if v >= 0 else _qcolor(RED)


def _chg_txt(v: float) -> str:
    return "\u2014" if v != v else f"{v:+.2f}"


_TRUST_RAMP: dict[int, QColor] = {}


#: z at/below which a name is flagged a reversion candidate (cheap for its
#: own RS). Two tiers so the strong candidates stand out at a glance.
_RS_REV_CHEAP: float = -0.75
_RS_REV_STRONG: float = -1.5


def _rs_rev_cell(z: "float | None"):
    """Render the RS-Rev cell as a (text, sortval, color, left) tuple.

    DISPLAY ONLY. Negative z = cheap-for-its-own-RS = reversion-long
    candidate. Blue (informational) marks the cheap end; the strong tier is
    shown as ``◄◄`` and the mild tier ``◄`` prefixed to the value, so the
    candidates read at a glance without implying rank. Neutral/rich are
    muted. Blank (em dash) when the signal is unavailable.

    Sort value is ``-z`` so that sorting DESCENDING puts the cheapest
    (most-negative z, best candidates) on top — consistent with every other
    column where "descending = most interesting first".
    """
    if z is None or z != z:
        return ("\u2014", float("-inf"), _qcolor(MUTED), False)
    if z <= _RS_REV_STRONG:
        txt, col = f"\u25c4\u25c4 {z:+.1f}", _qcolor(BLUE)
    elif z <= _RS_REV_CHEAP:
        txt, col = f"\u25c4 {z:+.1f}", _qcolor(BLUE)
    else:
        txt, col = f"{z:+.1f}", _qcolor(MUTED)
    return (txt, -z, col, False)


def _trust_color(t: float) -> QColor:
    """Grey (low) → blue (high) — how much confluence backs the edge.

    Memoised on the quantised value: the ramp is only distinguishable to
    ~100 steps on screen, and this is called once per row on every repaint.
    """
    if t != t:
        return _qcolor(MUTED)
    t = max(0.0, min(1.0, t))
    q = int(t * 100)
    c = _TRUST_RAMP.get(q)
    if c is None:
        f = q / 100.0
        base, tgt = QColor(MUTED), QColor(BLUE)
        c = QColor(
            int(base.red() + (tgt.red() - base.red()) * f),
            int(base.green() + (tgt.green() - base.green()) * f),
            int(base.blue() + (tgt.blue() - base.blue()) * f))
        _TRUST_RAMP[q] = c
    return c


_TABLE_QSS = f"""
QTableView {{
    background: transparent;
    border: none;
    gridline-color: {BORDER};
    color: {WHITE};
}}
QHeaderView::section {{
    background: {S2};
    color: {MUTED};
    border: none;
    border-bottom: 1px solid {BORDER};
    /* Header and cell left-padding are deliberately identical, so the
       left-aligned identity columns share one left edge. Any residual
       1-4px difference in where the GLYPHS appear to start is font side-
       bearing (the '#' has a wider natural left margin than a digit), not
       a layout error — compensating for it per-column would be fragile. */
    padding: 6px 5px;
    font-weight: bold;
}}
QTableView::item {{ padding: 5px 5px; }}
QTableView::item:selected {{ background: {BORDER}; color: {WHITE}; }}
"""


class _EdgeModel(QAbstractTableModel):
    """Lazy table model over the frozen edge rows.

    WHY A MODEL AND NOT A QTableWidget
    ----------------------------------
    QTableWidget materialises EVERY cell as a QTableWidgetItem: 481 symbols
    x 18 columns = ~8.6k widget objects, rebuilt on every horizon switch,
    when only ~25 rows are ever on screen. That cost is structural — no
    amount of caching removes it, because the items must exist.

    A model builds nothing up front. Qt asks for the cells it is about to
    paint, so switching horizon costs the visible viewport, not the
    universe. Row specs are memoised per row index and dropped whenever the
    row list changes, so scrolling back over a row does not rebuild it.
    """

    def __init__(self, cols, spec_fn, parent=None):
        super().__init__(parent)
        self._cols = cols
        self._spec_fn = spec_fn          # row -> (cells, tooltip)
        self._rows: tuple = ()
        self._cache: dict[int, tuple] = {}
        self._rank_c = cols.index("#")

    # ---- population ---------------------------------------------------
    def set_rows(self, rows: tuple) -> None:
        """Swap the visible row set. O(1) — no cells are built here."""
        self.beginResetModel()
        self._rows = tuple(rows)
        self._cache.clear()
        self.endResetModel()

    def row_at(self, r: int):
        return self._rows[r] if 0 <= r < len(self._rows) else None

    def _specs(self, r: int) -> tuple:
        got = self._cache.get(r)
        if got is None:
            got = self._spec_fn(self._rows[r])
            self._cache[r] = got
        return got

    # ---- QAbstractTableModel ------------------------------------------
    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._cols)

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        r, c = index.row(), index.column()
        if r >= len(self._rows):
            return None
        # The rank column is POSITIONAL: it is the row's place in the
        # current ordering, so it is derived here rather than stored. That
        # removes the old renumber-after-every-sort pass entirely.
        if c == self._rank_c:
            if role == Qt.ItemDataRole.DisplayRole:
                return str(r + 1)
            if role == Qt.ItemDataRole.ForegroundRole:
                return _qcolor(MUTED)
            if role == Qt.ItemDataRole.TextAlignmentRole:
                return int(Qt.AlignmentFlag.AlignLeft
                           | Qt.AlignmentFlag.AlignVCenter)
            return None
        cells, tip = self._specs(r)
        text, key, color, left = cells[c]
        if role == Qt.ItemDataRole.DisplayRole:
            return text
        if role == Qt.ItemDataRole.ForegroundRole:
            return _qcolor(color)
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return int((Qt.AlignmentFlag.AlignLeft
                        | Qt.AlignmentFlag.AlignVCenter) if left
                       else Qt.AlignmentFlag.AlignCenter)
        if role == Qt.ItemDataRole.ToolTipRole:
            return tip
        if role == Qt.ItemDataRole.UserRole:
            return key
        return None

    def headerData(self, section: int, orientation,
                   role=Qt.ItemDataRole.DisplayRole):
        if orientation != Qt.Orientation.Horizontal:
            return None
        if role == Qt.ItemDataRole.DisplayRole:
            name = self._cols[section]
            # Leading space nudges the left-aligned identity headers to sit
            # flush with the cell text beneath them.
            return f" {name}" if name in ("#", "Symbol", "Industry") else name
        if role == Qt.ItemDataRole.TextAlignmentRole:
            left = self._cols[section] in ("#", "Symbol", "Industry")
            return int((Qt.AlignmentFlag.AlignLeft
                        | Qt.AlignmentFlag.AlignVCenter) if left
                       else Qt.AlignmentFlag.AlignCenter)
        return None


class EdgeTab(QWidget):
    """Ranked per-symbol edge table (expected edge % + reward-to-risk)."""

    #: Emitted with the symbol when a row is double-clicked, so the
    #: container can open it on the Dashboard.
    symbol_activated = pyqtSignal(str)
    #: Emitted when the user picks a horizon HERE. The parent owns the
    #: horizon and applies it to every tab, so the tabs can never disagree
    #: about what "current strength" means.
    horizon_changed = pyqtSignal(int)

    _COLS = (
        "#", "Symbol", "Industry",
        "Vol", "Vol vs Peers", "Chg", "Chg 5d%", "Chg 10d%",
        "Exp. Edge %", "Reward / Risk", "Above", "4h", "RS-Rev", "Streak",
        "ADTV \u20b9cr", "ATR %", "RS Excess %", "Member Shift %", "Trust",
        "Conf",
    )

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 10)
        root.setSpacing(6)

        title = QLabel("EDGE · momentum-implied expected excess return")
        title.setFont(QFont(FONT_MONO, 11, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {WHITE}; letter-spacing: 1px;")

        # Horizon toggle (5 / 10 / 20d). The horizon is NOT cosmetic: it is
        # the window RS_excess is measured over AND the period the edge is
        # expressed over. Each option is a fully recomputed edge — the
        # industry composite ROC and the benchmark return are both taken
        # over the SAME window, so RS_excess never mixes horizons.
        #
        # All three are precomputed upstream, so flipping is a pure pointer
        # swap with no recompute (the same pattern as the confluence tab's
        # ≥3y-members toggle).
        self._horizon = DEFAULT_EDGE_HORIZON
        self._btn_horizon: dict[int, QPushButton] = {}
        horizon_row = QHBoxLayout()
        horizon_row.setContentsMargins(0, 0, 0, 0)
        horizon_row.setSpacing(4)
        for h in EDGE_HORIZONS:
            b = QPushButton(f"{h}d")
            b.setFont(QFont(FONT_MONO, 9))
            b.setCheckable(True)
            b.setChecked(h == self._horizon)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(_TOGGLE_QSS)
            b.setToolTip(
                f"Express the edge over a {h}-day horizon: RS excess and the "
                f"benchmark return are both measured over {h} days. "
                f"Shorter = faster and twitchier.")
            b.clicked.connect(
                lambda _checked=False, hh=h: self._request_horizon(hh))
            self._btn_horizon[h] = b
            horizon_row.addWidget(b)

        # Fresh-breakout filter. Isolates young rides (body just above the
        # band, short streak) — a scanning aid, NOT a ranking change. See
        # _FRESH_MAX_STREAK. Checkable; off by default.
        self._btn_fresh = QPushButton("Fresh")
        self._btn_fresh.setFont(QFont(FONT_MONO, 9))
        self._btn_fresh.setCheckable(True)
        self._btn_fresh.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_fresh.setStyleSheet(_TOGGLE_QSS)
        self._btn_fresh.setToolTip(
            f"Show only FRESH breakouts: body above the band with a streak "
            f"of {_FRESH_MAX_STREAK} or less — a young ride, not an extended "
            f"one. A view filter, not a score change (streak was not found "
            f"to predict forward return). Sort by Streak ascending to line "
            f"the freshest up.")
        self._btn_fresh.toggled.connect(self._on_fresh_toggled)
        #: When True, Fresh additionally requires the 4h flag confirmed.
        self._fresh_require_4h = _FRESH_REQUIRE_4H

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.addWidget(title)
        title_row.addStretch(1)
        title_row.addWidget(self._btn_fresh)
        title_row.addSpacing(10)
        title_row.addLayout(horizon_row)
        root.addLayout(title_row)

        self._subtitle = QLabel("")
        self._subtitle.setFont(QFont(FONT_MONO, 8))
        self._subtitle.setStyleSheet(f"color: {MUTED};")
        self._subtitle.setWordWrap(True)
        root.addWidget(self._subtitle)

        # Filter box — matches symbol OR industry, case-insensitive.
        self._search = QLineEdit()
        self._search.setPlaceholderText("filter symbol or industry…")
        self._search.setClearButtonEnabled(True)
        self._search.setStyleSheet(
            f"QLineEdit {{ background: {S2}; color: {WHITE}; "
            f"border: 1px solid {BORDER}; border-radius: 4px; "
            f"padding: 5px 9px; font-family: '{FONT_MONO}'; }}"
            f"QLineEdit:focus {{ border-color: {BLUE}; }}")
        self._search.textChanged.connect(self._apply_filter)
        root.addWidget(self._search)

        self._empty = QLabel("No edge data — load a panel.")
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(self._empty)

        self._model = _EdgeModel(self._COLS, self._row_specs, self)
        self._table = QTableView()
        self._table.setModel(self._model)
        self._table.setStyleSheet(_TABLE_QSS)
        self._table.setShowGrid(False)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.verticalHeader().setVisible(False)
        # Uniform row heights lets the view skip per-row measurement — a
        # required setting for a large table to scroll and repaint cheaply.
        self._table.setWordWrap(False)
        hh = self._table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hh.setMinimumSectionSize(56)
        _rank_c = self._COLS.index("#")
        _sym_c = self._COLS.index("Symbol")
        _ind_c = self._COLS.index("Industry")
        self._table.setColumnWidth(_rank_c, 44)
        self._table.setColumnWidth(_sym_c, 130)
        self._table.setColumnWidth(_ind_c, 200)
        self._FIXED_COLS = frozenset({_rank_c, _sym_c, _ind_c})
        #: Column index -> the row attribute its sort key is taken from.
        #: MUST mirror the values _row_specs emits as sort keys, or a header
        #: click and a horizon switch would order the table differently.
        #: "#" is excluded: it is positional, so sorting by it is undefined.
        _C = self._COLS.index
        self._SORT_KEYS = {
            _C("Symbol"): lambda r: r.symbol,
            _C("Industry"): lambda r: r.industry,
            _C("Vol"): lambda r: getattr(r, "vol_ratio", float("nan")),
            _C("Vol vs Peers"): lambda r: getattr(r, "vol_shift",
                                                  float("nan")),
            _C("Chg"): lambda r: r.chg_1d,
            _C("Chg 5d%"): lambda r: r.chg_5d,
            _C("Chg 10d%"): lambda r: r.chg_10d,
            _C("Exp. Edge %"): lambda r: r.expected_edge,
            _C("Reward / Risk"): lambda r: r.reward_to_risk,
            _C("Above"): lambda r: 1.0 if getattr(r, "above", False) else 0.0,
            _C("4h"): lambda r: (
                -1.0 if self._above_4h_of(r) is None
                else (1.0 if self._above_4h_of(r) else 0.0)),
            _C("RS-Rev"): lambda r: (
                -getattr(r, "rs_rev_z", None)
                if getattr(r, "rs_rev_z", None) is not None
                and getattr(r, "rs_rev_z") == getattr(r, "rs_rev_z")
                else float("-inf")),
            _C("Streak"): lambda r: float(getattr(r, "streak", 0)),
            _C("ADTV \u20b9cr"): lambda r: getattr(r, "adtv", float("nan")),
            _C("ATR %"): lambda r: r.atr_pct,
            _C("RS Excess %"): lambda r: r.industry_rs_excess,
            _C("Member Shift %"): lambda r: r.member_shift,
            _C("Trust"): lambda r: r.trust,
            _C("Conf"): lambda r: getattr(r, "confirmation", 1.0),
        }
        # Sorting is ours: rows are ordered in Python and handed to the
        # model already sorted. Qt's own sort is never engaged.
        hh.setSectionsClickable(True)
        hh.setSortIndicatorShown(True)
        hh.sectionClicked.connect(self._on_header_clicked)
        hh.setSortIndicator(self._COLS.index("Reward / Risk"),
                            Qt.SortOrder.DescendingOrder)
        self._table.doubleClicked.connect(self._on_double_clicked)
        self._table.setVisible(False)
        root.addWidget(self._table, stretch=1)

        self._rows_cache: tuple = ()
        #: Overrides for the 4h flag, keyed by symbol, filled asynchronously
        #: after the background 4h cache warm completes. Consulted BEFORE the
        #: row's own ``above_4h`` so the column can update without a recompute
        #: (the flag is display-only). Only known (non-None) values are stored,
        #: so a later cache miss never wipes a flag already shown.
        self._above_4h_override: dict[str, bool] = {}
        #: The engine's multi-horizon result. The toggle only chooses which
        #: member of it to render — this view computes nothing.
        self._horizon_set: EdgeHorizonSet | None = None
        #: Row count currently materialised in the table. Item widgets are
        #: REUSED across renders whenever this matches, which is the single
        #: biggest win on a horizon switch (see _render).


    def _above_4h_of(self, row) -> bool | None:
        """The 4h flag to display for ``row``: an async override if present,
        else the value baked into the row at compute time."""
        if row.symbol in self._above_4h_override:
            return self._above_4h_override[row.symbol]
        return getattr(row, "above_4h", None)

    def update_above_4h(self, flags: dict | None) -> None:
        """Update the 4h column from a freshly warmed flag map, no recompute.

        Called on the GUI thread after the background 4h cache warm finishes.
        Only known (non-None) flags are merged, so a symbol that failed to
        load this pass keeps whatever was already shown rather than reverting
        to "?". Re-renders the current view so the column repaints.
        """
        if not flags:
            return
        changed = False
        for sym, val in flags.items():
            if val is not None and self._above_4h_override.get(sym) is not val:
                self._above_4h_override[sym] = val
                changed = True
        if changed and self._rows_cache:
            self._refresh_view()

    def set_horizon_set(self, edge_set: EdgeHorizonSet | None) -> None:
        """Display an engine-computed multi-horizon edge result.

        The view is a pure consumer: it does not compute, combine or
        validate horizons. The engine guarantees each member pairs its
        rotation window with its benchmark window, so switching is only ever
        a choice of which frozen result to paint.
        """
        self._horizon_set = edge_set
        available = set(edge_set.horizons) if edge_set else set()
        # Prefer the engine's default; fall back to any available horizon so
        # a partial set still renders rather than showing an empty tab.
        if edge_set is not None and self._horizon not in available:
            self._horizon = (edge_set.default_horizon
                             if edge_set.default_horizon in available
                             else next(iter(sorted(available)), self._horizon))
        self._sync_buttons()
        self._render(self._edge_for(self._horizon))

    def _request_horizon(self, horizon: int) -> None:
        """A horizon button was clicked.

        The click is a REQUEST, not an action: it is announced and the parent
        applies it here and to the other tabs. Applying it locally as well
        would let this tab move while a sibling stayed behind.
        """
        if horizon == self._horizon:
            self._sync_buttons()       # re-assert; the click may have
            return                     # unchecked the active button
        self.horizon_changed.emit(horizon)

    def set_horizon(self, horizon: int) -> None:
        """Apply a horizon chosen elsewhere.

        Pure pointer swap — repaints an already-computed frozen result. No
        recompute happens here or anywhere downstream. Emits nothing, so a
        parent broadcasting to several tabs cannot cause a signal loop.
        """
        if horizon == self._horizon:
            self._sync_buttons()
            return
        self._horizon = horizon
        self._sync_buttons()
        if self._horizon_set is not None:
            self._render(self._edge_for(horizon))

    # Back-compat alias for the previous private name.
    _set_horizon = set_horizon

    def _edge_for(self, horizon: int):
        """The EdgeResult for ``horizon``.

        Accepts either engine entry point: a ``HorizonSet`` (whose members
        are ``HorizonView``s bundling rotation + confluence + edge, used when
        the horizon is shared with the Confluence tab) or a plain
        ``EdgeHorizonSet`` of bare results. Both guarantee the same
        invariant; only the packaging differs.
        """
        if self._horizon_set is None:
            return None
        got = self._horizon_set.get(horizon)
        if got is None:
            return None
        return getattr(got, "edge", got)

    def _sync_buttons(self) -> None:
        """Keep the toggle group exclusive and reflect the active horizon.

        Set explicitly rather than relying on the click that triggered it:
        the buttons are independently checkable, so the previously-active one
        must be un-checked or two would read as active at once.
        """
        available = (set(self._horizon_set.horizons)
                     if self._horizon_set is not None else set())
        for h, b in self._btn_horizon.items():
            b.setChecked(h == self._horizon)
            b.setEnabled(h in available)

    def set_result(self, result: EdgeResult | None) -> None:
        """Render a single edge result (back-compatible single-horizon path).

        Retained so existing callers and tests keep working. The toggle is
        inert here — there is only one result — so the buttons disable
        rather than implying a choice that does not exist.
        """
        self._horizon_set = None
        self._sync_buttons()
        self._render(result)

    def _render(self, result: EdgeResult | None) -> None:
        """Show an edge result. Pure display, no computation.

        Ordering and filtering happen on the frozen rows; the model is then
        handed the finished list. Nothing is materialised here — the view
        pulls only the cells it paints, so the cost of a horizon switch is
        the visible viewport rather than the whole universe.
        """
        if result is None or not result.has_data:
            self._table.setVisible(False)
            self._empty.setVisible(True)
            self._subtitle.setText("")
            self._rows_cache = ()
            self._model.set_rows(())
            return
        self._table.setVisible(True)
        self._empty.setVisible(False)
        self._subtitle.setText(
            f"expected {result.horizon_days}d excess return, ranked by "
            f"reward-to-risk \u00b7 momentum estimate, not a valuation "
            f"premium \u00b7 double-click to open")
        self._rows_cache = tuple(result.rows)
        self._refresh_view()

    def _refresh_view(self) -> None:
        """Sort + filter the cached rows and push them to the model."""
        header = self._table.horizontalHeader()
        section = header.sortIndicatorSection()
        order = header.sortIndicatorOrder()
        if section < 0:
            section = self._COLS.index("Reward / Risk")
            order = Qt.SortOrder.DescendingOrder
        rows = self._filtered_rows(self._rows_cache, self._search.text())
        if self._btn_fresh.isChecked():
            rows = tuple(r for r in rows if self._is_fresh(r))
        self._model.set_rows(self._sorted_rows(rows, section, order))

    def _is_fresh(self, row) -> bool:
        """A fresh breakout: body above the band on a still-young ride.

        ``above`` (daily body-above-band) must be set and the trailing
        streak must be at most ``_FRESH_MAX_STREAK``. When 4h confirmation is
        required, the 4h flag must also be True (an unknown "?" does not
        count — a fresh signal should be confirmed, not merely un-refuted).
        """
        if not getattr(row, "above", False):
            return False
        if getattr(row, "streak", 0) > _FRESH_MAX_STREAK:
            return False
        if self._fresh_require_4h and self._above_4h_of(row) is not True:
            return False
        return True

    def _on_fresh_toggled(self, _checked: bool) -> None:
        """Re-filter when the Fresh toggle flips.

        On ENABLING, save the current sort and default to REWARD/RISK
        descending so the fresh cohort is ordered by edge quality — the
        best fresh setups on top — rather than merely by recency. On
        DISABLING, RESTORE the sort the user had before, so undoing Fresh
        returns the board to where it was.
        """
        header = self._table.horizontalHeader()
        if self._btn_fresh.isChecked():
            # Remember where we were, then impose the fresh-reading sort.
            self._pre_fresh_sort = (header.sortIndicatorSection(),
                                    header.sortIndicatorOrder())
            header.blockSignals(True)
            header.setSortIndicator(self._COLS.index("Reward / Risk"),
                                    Qt.SortOrder.DescendingOrder)
            header.blockSignals(False)
        elif getattr(self, "_pre_fresh_sort", None) is not None:
            section, order = self._pre_fresh_sort
            self._pre_fresh_sort = None
            header.blockSignals(True)
            header.setSortIndicator(section, order)
            header.blockSignals(False)
        if self._rows_cache:
            self._refresh_view()

    def _filtered_rows(self, rows: tuple, text: str) -> tuple:
        """Rows whose symbol or industry contains ``text``.

        Filtering the DATA (rather than hiding widget rows one by one) means
        the rank column stays a simple 1..n over what is actually shown, so
        no renumber pass is needed at all.
        """
        needle = text.strip().lower()
        if not needle:
            return rows
        return tuple(r for r in rows
                     if needle in r.symbol.lower()
                     or needle in r.industry.lower())

    def _apply_filter(self, text: str) -> None:
        """Re-filter on search input."""
        if self._rows_cache:
            self._refresh_view()

    def _on_double_clicked(self, index) -> None:
        row = self._model.row_at(index.row())
        if row is not None and row.symbol:
            self.symbol_activated.emit(row.symbol)

    def _on_header_clicked(self, section: int) -> None:
        """Re-order on a header click.

        We own sorting, so a click is: choose the column, flip direction if
        it was already active, then repaint. First click on a new column
        sorts DESCENDING — for this table (edge, reward/risk, strength)
        "best first" is the useful default, not alphabetical-ascending.
        """
        if section not in self._SORT_KEYS:
            return                       # "#" is positional, not sortable
        header = self._table.horizontalHeader()
        cur = header.sortIndicatorSection()
        if cur == section:
            order = (Qt.SortOrder.AscendingOrder
                     if header.sortIndicatorOrder()
                     == Qt.SortOrder.DescendingOrder
                     else Qt.SortOrder.DescendingOrder)
        else:
            order = Qt.SortOrder.DescendingOrder
        header.blockSignals(True)
        header.setSortIndicator(section, order)
        header.blockSignals(False)
        if self._rows_cache:
            self._refresh_view()

    def _sorted_rows(self, rows, section: int, order) -> tuple:
        """Order rows by a display column, in Python.

        Mirrors what the table's own sort would do, using the same values
        that get written as sort keys — so a header click and a horizon
        switch always agree on ordering. NaNs sink to the bottom regardless
        of direction (an unknown is never a top-ranked candidate).
        """
        key = self._SORT_KEYS.get(section)
        if key is None:
            return tuple(rows)
        desc = order == Qt.SortOrder.DescendingOrder

        def sort_key(row):
            v = key(row)
            if isinstance(v, str):
                return (0, v)
            # NaN -> always last: flip the sentinel with the direction.
            if v != v:
                return (1, float("-inf") if desc else float("inf"))
            return (0, v)

        return tuple(sorted(rows, key=sort_key, reverse=desc))

    def _row_specs(self, row) -> tuple:
        """Describe one row as cell DATA, building no widgets.

        Returns ``(cells, tooltip)`` where cells is one
        ``(text, sort_key, colour, left_aligned)`` tuple per column. The
        model calls this lazily for rows the user can actually see, so a
        481-name universe costs ~25 rows of work to paint, not 481.
        """
        def txt(s, color=WHITE):
            return (s, s, color, True)

        def num(s, v, color=WHITE):
            return (s, v if v == v else float("-inf"), color, False)

        edge = row.expected_edge
        rr = row.reward_to_risk
        # ADTV in ₹ crore (bare number; header carries the unit); coloured
        # gold when the liquidity gate bit (thin name), muted when liquid.
        adtv = getattr(row, "adtv", float("nan"))
        liq = getattr(row, "liquidity_gate", 1.0)
        adtv_txt = format_adtv_cr(adtv)
        adtv_col = MUTED if liq >= 0.999 else GOLD
        vol = getattr(row, "vol_ratio", float("nan"))
        vshift = getattr(row, "vol_shift", float("nan"))
        above = getattr(row, "above", False)
        streak = getattr(row, "streak", 0)
        # Participation haircut. Gold when it bit (this name is not moving
        # with its industry, so its edge was discounted).
        conf = getattr(row, "confirmation", 1.0)
        cells = [
            # Rank placeholder. The model derives the real number from the
            # row's position AFTER sorting/filtering, so it always reads
            # 1,2,3... down the visible rows rather than travelling with a
            # row. Nothing is stored here.
            txt("", MUTED),
            txt(row.symbol, WHITE),
            txt(row.industry, MUTED),
            # Vol — SELF-relative ("busier than IT usually is"). Gold above
            # 3x: measured, that is where volume flips from confirmation to
            # DISTRIBUTION (>=5x: -0.85% forward excess, t=-5.1). It is a
            # caution flag, not a buy signal.
            num(f"{vol:.2f}x" if vol == vol else "\u2014",
                vol if vol == vol else float("-inf"),
                RED if (vol == vol and vol >= 3.0)
                else (GREEN if (vol == vol and vol >= 1.0) else MUTED)),
            # Vol vs Peers — PEER-relative. A name at 3x its own average on
            # a day its whole sector is also at 3x is a SECTOR event, not a
            # stock event; only this column separates the two. Context only
            # — the scoring uses the self-relative measure, which is what the
            # blowoff effect was actually measured on.
            num(f"{vshift:.2f}x" if vshift == vshift else "\u2014",
                vshift if vshift == vshift else float("-inf"),
                RED if (vshift == vshift and vshift >= 3.0)
                else (GOLD if (vshift == vshift and vshift >= 1.5)
                      else MUTED)),
            num(_chg_txt(row.chg_1d), row.chg_1d, _signed_color(row.chg_1d)),
            num(_chg_txt(row.chg_5d), row.chg_5d, _signed_color(row.chg_5d)),
            num(_chg_txt(row.chg_10d), row.chg_10d,
                _signed_color(row.chg_10d)),
            num(f"{edge:+.2f}", edge, _signed_color(edge)),
            num(f"{rr:+.3f}", rr, _signed_color(rr)),
            num("\u25b2" if above else "\u2014", 1.0 if above else 0.0,
                GREEN if above else MUTED),
            # 4h confirmation: body above upper BB on the secondary 4h
            # timeframe too. Tri-state — a filled triangle when confirmed,
            # a dash when not, and "?" (muted) when 4h data was unavailable,
            # so an absent feed never reads as a real "not above".
            (lambda a4: num(
                "?" if a4 is None else ("\u25b2" if a4 else "\u2014"),
                -1.0 if a4 is None else (1.0 if a4 else 0.0),
                MUTED if a4 is None else (GREEN if a4 else MUTED)))(
                self._above_4h_of(row)),
            # RS-Rev: reversion candidacy, DISPLAY ONLY (never scored). The
            # per-date-demeaned own-history z of price/own-RS-norm. NEGATIVE =
            # cheap for its own relative strength = a reversion-long candidate;
            # BLUE (informational, a DIFFERENT kind of signal from the green
            # momentum flags) marks the cheap end so it never reads as "better
            # rank". Neutral/rich are muted. Blank when history is too short.
            _rs_rev_cell(getattr(row, "rs_rev_z", None)),
            num(str(streak) if streak else "\u2014", float(streak),
                GREEN if streak > 0 else MUTED),
            num(adtv_txt, adtv if adtv == adtv else float("-inf"), adtv_col),
            num(f"{row.atr_pct:.2f}", row.atr_pct, MUTED),
            num(f"{row.industry_rs_excess:+.1f}", row.industry_rs_excess,
                _signed_color(row.industry_rs_excess)),
            num(f"{row.member_shift:+.2f}", row.member_shift,
                _signed_color(row.member_shift)),
            num(f"{row.trust*100:.0f}", row.trust, _trust_color(row.trust)),
            num(f"{conf*100:.0f}", conf, MUTED if conf >= 0.999 else GOLD),
        ]
        tip = (
            f"{row.symbol} · {row.industry}\n"
            f"expected edge {edge:+.2f}% over horizon "
            f"(reward/risk {rr:+.3f})\n"
            f"industry RS excess {row.industry_rs_excess:+.1f}% "
            f"× trust {row.trust*100:.0f}% × \u03ba\n"
            f"member shift {row.member_shift:+.2f}% · ATR {row.atr_pct:.2f}%\n"
            f"ADTV {adtv_txt}\u20b9cr"
            f"{f' · liquidity gate ×{liq:.2f}' if liq < 0.999 else ' · liquid'}")
        return cells, tip
