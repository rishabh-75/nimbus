#!/usr/bin/env python3
"""
publish/vix.py — India VIX & Volatility Regime Dashboard.

Factual volatility structure:
  - VIX 60-day history with regime bands
  - VIX percentile rank (where are we historically?)
  - FII/DII net flows
  - Universe breadth stats by VIX regime context

Usage:
    python3 publish/vix.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter

from publish.common import (
    nimbus_style, export_figure, add_title, add_timestamp,
    COLORS,
)

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("publish_vix")


def fetch_vix_history(days=120):
    """Fetch India VIX daily close history. Tries multiple tickers."""
    import yfinance as yf
    import pandas as pd
    end = datetime.datetime.now()
    start = end - datetime.timedelta(days=days)
    for ticker in ["^INDIAVIX", "INDIAVIX.NS"]:
        try:
            vix = yf.download(ticker, start=start.strftime("%Y-%m-%d"),
                              end=end.strftime("%Y-%m-%d"), progress=False)
            if vix is None or vix.empty:
                continue
            if isinstance(vix.columns, pd.MultiIndex):
                vix.columns = vix.columns.get_level_values(0)
            vix.index = pd.to_datetime(vix.index)
            if hasattr(vix.index, "tz") and vix.index.tz is not None:
                vix.index = vix.index.tz_localize(None)
            if len(vix) > 10:
                # Overlay live VIX if available (yfinance daily lags by 1 day)
                try:
                    from modules.data import fetch_india_vix
                    live_vix = fetch_india_vix()
                    if live_vix and live_vix > 0:
                        today = pd.Timestamp(datetime.date.today())
                        if today not in vix.index:
                            # Add today's row with live VIX
                            last_row = vix.iloc[-1].copy()
                            last_row["Close"] = live_vix
                            last_row["High"] = max(live_vix, last_row.get("High", live_vix))
                            last_row["Low"] = min(live_vix, last_row.get("Low", live_vix))
                            vix.loc[today] = last_row
                        else:
                            vix.loc[today, "Close"] = live_vix
                except Exception:
                    pass
                return vix
        except Exception:
            continue
    return None


def fetch_fii_dii():
    """Fetch FII/DII data from NSE."""
    try:
        from modules.nse_client import NSEClient
        client = NSEClient(timeout=15, retry=2)
        data = client.fetch_fii_dii()
        return data
    except Exception as e:
        logger.warning("FII/DII fetch failed: %s", e)
        return None


def render_vix_dashboard(vix_df, fii_dii=None):
    """Render the VIX volatility dashboard."""
    import pandas as pd

    if vix_df is None or vix_df.empty:
        logger.error("No VIX data")
        return None

    closes = vix_df["Close"].dropna()
    dates = closes.index
    vals = closes.values.astype(float)
    current = float(vals[-1])

    # 1-year percentile (use all available data)
    pctl = (vals < current).sum() / len(vals) * 100

    # 20-day rolling average
    sma20 = pd.Series(vals, index=dates).rolling(20).mean()

    # Regime classification (matches regime.py thresholds)
    if current > 25: regime = "PANIC"
    elif current >= 20: regime = "ELEVATED"
    elif current >= 13: regime = "NORMAL"
    else: regime = "LOW"

    regime_colors = {"PANIC": COLORS["red"], "ELEVATED": COLORS["gold"],
                     "NORMAL": COLORS["muted"], "LOW": COLORS["emerald"]}

    with nimbus_style():
        fig = plt.figure(figsize=(13, 7))
        gs = fig.add_gridspec(2, 3, hspace=0.4, wspace=0.35,
                              top=0.88, bottom=0.08, left=0.07, right=0.96)

        now_str = datetime.datetime.now().strftime("%d %b %Y")
        add_title(fig, "INDIA VIX — VOLATILITY REGIME",
                  f"Implied volatility from NIFTY 50 options · {now_str}")
        add_timestamp(fig)

        # ── Panel 1: VIX line chart (top, spans 2 cols) ─────────────────
        ax1 = fig.add_subplot(gs[0, :2])

        # Conditional fill by regime
        ax1.fill_between(dates, vals, 0,
                        where=(vals < 13), color=COLORS["emerald"], alpha=0.08)
        ax1.fill_between(dates, vals, 0,
                        where=((vals >= 13) & (vals < 20)), color=COLORS["muted"], alpha=0.05)
        ax1.fill_between(dates, vals, 0,
                        where=((vals >= 20) & (vals < 25)), color=COLORS["gold"], alpha=0.08)
        ax1.fill_between(dates, vals, 0,
                        where=(vals >= 25), color=COLORS["red"], alpha=0.10)

        ax1.plot(dates, vals, color=COLORS["white"], linewidth=1.8, zorder=3)
        ax1.plot(dates, sma20, color=COLORS["gold"], linewidth=0.8,
                linestyle="--", alpha=0.7, zorder=2, label="20D avg")

        # Regime bands (aligned with regime.py)
        for level, label, color in [(13, "Low fear", COLORS["emerald"]),
                                     (20, "Elevated", COLORS["gold"]),
                                     (25, "Panic", COLORS["red"])]:
            ax1.axhline(y=level, color=color, linewidth=0.6, linestyle=":", alpha=0.5)
            ax1.text(dates[-1], level + 0.3, f"  {label} ({level})",
                    fontsize=6.5, color=color, va="bottom")

        # Current value annotation
        ax1.annotate(f"VIX {current:.1f}",
                    xy=(dates[-1], current),
                    xytext=(dates[-1] - datetime.timedelta(days=8), current + 2),
                    fontsize=11, fontweight=600, color=regime_colors[regime],
                    arrowprops=dict(arrowstyle="->", color=regime_colors[regime], lw=1.2),
                    bbox=dict(boxstyle="round,pad=0.3", facecolor=COLORS["surface"],
                             edgecolor=regime_colors[regime], alpha=0.9))

        ax1.set_ylabel("India VIX")
        ax1.set_title("India VIX — 60 day history", fontsize=10, pad=8)
        ax1.xaxis.set_major_formatter(DateFormatter("%d %b"))
        ax1.legend(loc="upper left", fontsize=7)

        # Use last 60 days for display
        if len(dates) > 60:
            ax1.set_xlim(dates[-60], dates[-1] + datetime.timedelta(days=2))

        # ── Panel 2: VIX Stats (top-right) ──────────────────────────────
        ax2 = fig.add_subplot(gs[0, 2])
        ax2.axis("off")

        stats = [
            ("Current VIX", f"{current:.1f}", regime_colors[regime]),
            ("Regime", regime, regime_colors[regime]),
            ("20D average", f"{float(sma20.iloc[-1]):.1f}" if not pd.isna(sma20.iloc[-1]) else "—", COLORS["gold"]),
            ("Percentile", f"{pctl:.0f}th", COLORS["white"]),
            ("60D high", f"{vals[-60:].max():.1f}" if len(vals) >= 60 else f"{vals.max():.1f}", COLORS["red"]),
            ("60D low", f"{vals[-60:].min():.1f}" if len(vals) >= 60 else f"{vals.min():.1f}", COLORS["emerald"]),
        ]

        for i, (label, value, color) in enumerate(stats):
            y = 0.90 - i * 0.14
            ax2.text(0.05, y, label, fontsize=8, color=COLORS["muted"],
                    transform=ax2.transAxes, va="center")
            ax2.text(0.95, y, value, fontsize=12, fontweight=600, color=color,
                    transform=ax2.transAxes, va="center", ha="right",
                    fontfamily="monospace")

        # ── Panel 3: VIX Distribution (bottom-left) ─────────────────────
        ax3 = fig.add_subplot(gs[1, 0])
        hist_data = vals[-60:] if len(vals) >= 60 else vals
        bins = np.arange(8, 35, 1.5)
        n_bins, _, patches = ax3.hist(hist_data, bins=bins, edgecolor="none", alpha=0.8)
        for patch, left_edge in zip(patches, bins):
            if left_edge >= 25: patch.set_facecolor(COLORS["red"])
            elif left_edge >= 20: patch.set_facecolor(COLORS["gold"])
            elif left_edge >= 13: patch.set_facecolor(COLORS["muted"])
            else: patch.set_facecolor(COLORS["emerald"])
        ax3.axvline(x=current, color=COLORS["white"], linewidth=1.5, linestyle="-", zorder=5)
        ax3.text(current + 0.3, max(n_bins) * 0.9, f"Now\n{current:.1f}",
                fontsize=7, color=COLORS["white"], va="top")
        ax3.set_title("VIX distribution (60d)", fontsize=10, pad=8)
        ax3.set_xlabel("VIX level")
        ax3.set_ylabel("Days")

        # ── Panel 4: Daily VIX change (bottom-center) ───────────────────
        ax4 = fig.add_subplot(gs[1, 1])
        recent = closes.tail(20)
        changes = recent.pct_change().dropna() * 100
        bar_colors = [COLORS["red"] if c > 0 else COLORS["emerald"] for c in changes.values]
        ax4.bar(range(len(changes)), changes.values, color=bar_colors, edgecolor="none", width=0.7)
        ax4.axhline(y=0, color=COLORS["muted"], linewidth=0.5)
        ax4.set_title("Daily VIX change % (20d)", fontsize=10, pad=8)
        ax4.set_ylabel("Change %")
        ax4.set_xticks(range(0, len(changes), 5))
        ax4.set_xticklabels([d.strftime("%d %b") for d in changes.index[::5]], fontsize=7)

    return fig


def main():
    parser = argparse.ArgumentParser(description="NIMBUS VIX Dashboard")
    parser.add_argument("--no-export", action="store_true")
    args = parser.parse_args()

    logger.info("Fetching VIX history...")
    vix_df = fetch_vix_history(days=120)
    if vix_df is None:
        logger.error("VIX data unavailable")
        return

    logger.info("VIX data: %d days", len(vix_df))

    fii_dii = fetch_fii_dii()

    fig = render_vix_dashboard(vix_df, fii_dii)

    if fig and not args.no_export:
        export_figure(fig, "vix_regime")

    if fig:
        plt.close(fig)

    logger.info("Done.")


if __name__ == "__main__":
    main()
