"""nimbus_v3.research.harness — strategy validation harness.

Produces forward-return-conditioned trade lists for any strategy across
a panel of (symbol, date) observations. Designed to answer two
questions before we lock parameters into production:

1. **Gate value**: for each entry gate, does enforcing it actually
   improve the forward-return distribution of triggered trades, or does
   it just restrict trade count without value?
2. **Parameter sensitivity**: when we move a threshold ±20-50% around
   its baseline, does the win rate / mean return move meaningfully or
   stay flat?

What the harness does NOT do:
- It does not compute portfolio Sharpe with costs (trading costs are
  out of scope per the user's direction).
- It does not optimise parameters — that's the next step *after* we
  understand which parameters matter.
- It does not size positions — the dependent variable is the raw
  forward return per trade.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

import numpy as np
import pandas as pd


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# 1. Forward returns
# ══════════════════════════════════════════════════════════════════════════════

def add_forward_returns(
    df: pd.DataFrame, *, horizons: tuple[int, ...] = (5, 10, 20),
) -> pd.DataFrame:
    """Append ``fwd_ret_{H}d`` columns to ``df``.

    Each ``fwd_ret_Hd`` is the log return from ``Close[t]`` to
    ``Close[t+H]``. Bars without a full forward window get NaN.
    """
    out = df.copy()
    for h in horizons:
        out[f"fwd_ret_{h}d"] = np.log(out["Close"].shift(-h) / out["Close"])
    return out


# ══════════════════════════════════════════════════════════════════════════════
# 2. VIX proxy
# ══════════════════════════════════════════════════════════════════════════════

def build_vix_proxy(
    panel: dict[str, pd.DataFrame], *, smoothing: int = 5,
) -> pd.DataFrame:
    """Synthesise a daily India-VIX proxy series from a price panel.

    Method: cross-sectional median of |daily log return| across all
    symbols, smoothed by ``smoothing`` bars, scaled to typical India
    VIX magnitudes (≈ ann. realised vol × 100).

    Returns a DataFrame with columns ``Open/High/Low/Close/Volume``
    (Close is the proxy value); shape mimics ``yfinance`` so the rest
    of the codebase consumes it identically.
    """
    daily_abs_returns = []
    for sym, df in panel.items():
        if len(df) < 30:
            continue
        log_ret = np.log(df["Close"] / df["Close"].shift(1)).abs()
        daily_abs_returns.append(log_ret.rename(sym))
    if not daily_abs_returns:
        return pd.DataFrame()
    cross = pd.concat(daily_abs_returns, axis=1)
    cross_median = cross.median(axis=1)
    smoothed = cross_median.rolling(window=smoothing, min_periods=smoothing).mean()
    # Annualise and scale to VIX-like units.
    proxy = (smoothed * np.sqrt(252) * 100).dropna()
    out = pd.DataFrame({
        "Open": proxy, "High": proxy, "Low": proxy, "Close": proxy,
        "Volume": 0,
    })
    return out


def compute_vix_streaks(
    vix_df: pd.DataFrame, *, high_threshold: float = 16.0,
) -> pd.Series:
    """Per-bar consecutive-HIGH-day count ending at that bar.

    A day counts as HIGH when ``Close >= high_threshold``. The streak
    resets to 0 the moment a non-HIGH day appears.
    """
    is_high = (vix_df["Close"] >= high_threshold).astype(int)
    # Cumulative count that resets on each 0.
    grouper = (is_high == 0).cumsum()
    streak = is_high.groupby(grouper).cumsum()
    return streak


# ══════════════════════════════════════════════════════════════════════════════
# 3. Loading equity panels — see ``nimbus_v3.research.equity_universe``
# ══════════════════════════════════════════════════════════════════════════════
#
# The previous ``load_v2_cache()`` reader was removed. All equity panel
# loading now flows through ``research/equity_universe.py::load_equity_panel``,
# which auto-fetches on cache miss via ``PriceLoader``. This means
# validation scripts have a single zero-config entry point and operators
# never edit a hard-coded path.


# ══════════════════════════════════════════════════════════════════════════════
# 4. Bar-by-bar evaluation
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class TriggeredTrade:
    """One signal triggered by a strategy at one bar, with its forward returns."""
    strategy_name: str
    symbol: str
    bar_date: pd.Timestamp
    fwd_ret_5d: float
    fwd_ret_10d: float
    fwd_ret_20d: float


# A vectorised predicate accepts the enriched DataFrame and the aligned
# vix_streak Series and returns a boolean mask of the same length.
VectorPredicate = Callable[[pd.DataFrame, pd.Series], pd.Series]


def evaluate_vector_predicate_panel(
    *,
    strategy_name: str,
    enriched_panel: dict[str, pd.DataFrame],
    vix_streak: pd.Series,
    predicate: VectorPredicate,
    min_bar_index: int = 250,
) -> list[TriggeredTrade]:
    """Vectorised predicate evaluation across an enriched panel.

    The predicate receives the full DataFrame + an aligned
    ``vix_streak`` Series and returns a boolean Series (or scalar
    True/False) indicating which bars fire. This skips per-bar
    ``SignalState`` construction — two orders of magnitude faster
    for gates that can be expressed as column comparisons, which is
    every gate in v3's strategies (each reads a single
    ``SignalState`` field and compares to a constant).

    Each enriched DataFrame must carry the indicator columns produced
    by ``StrategyComputeEngine.enrich`` AND the forward-return
    columns produced by :func:`add_forward_returns`.

    Returns a list of ``TriggeredTrade``s — one per (symbol, bar)
    where the predicate returned True and at least one forward
    return is available.
    """
    trades: list[TriggeredTrade] = []
    for symbol, df in enriched_panel.items():
        if len(df) < min_bar_index + 1:
            continue
        # Align vix_streak to this symbol's index, fill gaps with zero.
        streak = vix_streak.reindex(df.index).fillna(0).astype(int)
        mask_raw = predicate(df, streak)
        # Coerce scalar (e.g. ``True``) to full-True Series.
        if isinstance(mask_raw, bool):
            mask = pd.Series(mask_raw, index=df.index)
        else:
            mask = mask_raw
        # Mask out bars before the warm-up cutoff.
        mask.iloc[:min_bar_index] = False
        # Mask out bars without forward returns.
        for col in ("fwd_ret_5d", "fwd_ret_10d", "fwd_ret_20d"):
            if col in df.columns:
                # Keep bars where AT LEAST one forward return exists.
                pass
        # Forward returns must exist at the 10d horizon (the primary metric).
        if "fwd_ret_10d" in df.columns:
            mask = mask & df["fwd_ret_10d"].notna()

        hit_idx = df.index[mask]
        if len(hit_idx) == 0:
            continue
        sub = df.loc[hit_idx, ["fwd_ret_5d", "fwd_ret_10d", "fwd_ret_20d"]]
        for date, row in sub.iterrows():
            trades.append(TriggeredTrade(
                strategy_name=strategy_name, symbol=symbol, bar_date=date,
                fwd_ret_5d=float(row["fwd_ret_5d"]) if not pd.isna(row["fwd_ret_5d"]) else float("nan"),
                fwd_ret_10d=float(row["fwd_ret_10d"]) if not pd.isna(row["fwd_ret_10d"]) else float("nan"),
                fwd_ret_20d=float(row["fwd_ret_20d"]) if not pd.isna(row["fwd_ret_20d"]) else float("nan"),
            ))
    return trades


# ══════════════════════════════════════════════════════════════════════════════
# 5. Trade summary statistics
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class TradeStats:
    n: int
    mean_5d: float
    mean_10d: float
    mean_20d: float
    median_10d: float
    win_rate_10d: float        # P(fwd_ret_10d > 0)
    std_10d: float
    t_stat_10d: float          # mean / (std / sqrt(n))  — vs H0: mean = 0
    #: Paired-test t-statistic of (returns − baseline_mean) against zero.
    #: This is the methodologically-correct significance test for "does
    #: the strategy beat the universe baseline?" — particularly important
    #: in regimes where universe baseline is non-zero (e.g. the 2025
    #: correction had baseline = −1.84%).
    t_stat_lift_10d: float = float("nan")


def summarise(
    trades: list[TriggeredTrade],
    *,
    baseline_mean_10d: float | None = None,
) -> TradeStats:
    """Reduce a trade list to its summary statistics.

    Args:
        trades: List of triggered trades.
        baseline_mean_10d: Optional 10-day universe baseline mean. When
            provided, ``t_stat_lift_10d`` measures whether the strategy's
            mean return statistically differs from this baseline (paired
            test). When omitted, ``t_stat_lift_10d`` is NaN.
    """
    if not trades:
        return TradeStats(n=0, mean_5d=float("nan"), mean_10d=float("nan"),
                            mean_20d=float("nan"), median_10d=float("nan"),
                            win_rate_10d=float("nan"), std_10d=float("nan"),
                            t_stat_10d=float("nan"),
                            t_stat_lift_10d=float("nan"))
    fwd5 = np.array([t.fwd_ret_5d for t in trades])
    fwd10 = np.array([t.fwd_ret_10d for t in trades])
    fwd20 = np.array([t.fwd_ret_20d for t in trades])
    fwd5 = fwd5[~np.isnan(fwd5)]
    fwd10 = fwd10[~np.isnan(fwd10)]
    fwd20 = fwd20[~np.isnan(fwd20)]
    if len(fwd10) == 0:
        return TradeStats(n=len(trades), mean_5d=float("nan"),
                            mean_10d=float("nan"), mean_20d=float("nan"),
                            median_10d=float("nan"), win_rate_10d=float("nan"),
                            std_10d=float("nan"), t_stat_10d=float("nan"),
                            t_stat_lift_10d=float("nan"))
    std_10 = float(fwd10.std(ddof=1)) if len(fwd10) > 1 else float("nan")
    t_stat = (
        float(fwd10.mean() / (std_10 / np.sqrt(len(fwd10))))
        if std_10 and not np.isnan(std_10) and std_10 > 0 else float("nan")
    )
    # Paired-test t-stat against baseline. (returns − baseline) has the
    # same std as (returns) since baseline is a constant.
    t_stat_lift = float("nan")
    if baseline_mean_10d is not None and std_10 and std_10 > 0:
        diff = fwd10.mean() - baseline_mean_10d
        t_stat_lift = float(diff / (std_10 / np.sqrt(len(fwd10))))
    return TradeStats(
        n=len(trades),
        mean_5d=float(fwd5.mean()) if len(fwd5) else float("nan"),
        mean_10d=float(fwd10.mean()),
        mean_20d=float(fwd20.mean()) if len(fwd20) else float("nan"),
        median_10d=float(np.median(fwd10)),
        win_rate_10d=float((fwd10 > 0).mean()),
        std_10d=std_10,
        t_stat_10d=t_stat,
        t_stat_lift_10d=t_stat_lift,
    )


# ══════════════════════════════════════════════════════════════════════════════
# 7. Out-of-sample split
# ══════════════════════════════════════════════════════════════════════════════

def split_panel_by_date(
    enriched_panel: dict[str, pd.DataFrame],
    *,
    cutoff: pd.Timestamp,
) -> tuple[dict[str, pd.DataFrame], dict[str, pd.DataFrame]]:
    """Split each symbol's history into train (date < cutoff) and test (>=).

    Used for genuinely-OOS validation: parameters tuned on ``train``
    must replicate their lift on ``test``, otherwise we are overfitting.

    A symbol that has fewer than ``min_bar_index`` bars in EITHER side
    is dropped from that side. The two returned dicts are independent.
    """
    cutoff = pd.Timestamp(cutoff)
    if cutoff.tz is not None:
        cutoff = cutoff.tz_localize(None)
    train: dict[str, pd.DataFrame] = {}
    test: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        idx_naive = df.index.tz_localize(None) if df.index.tz is not None else df.index
        train_mask = idx_naive < cutoff
        test_mask = ~train_mask
        if train_mask.sum() >= 250:
            train[sym] = df[train_mask]
        if test_mask.sum() >= 30:    # need at least a month of test bars
            test[sym] = df[test_mask]
    return train, test


def split_streak_by_date(
    streak: pd.Series, *, cutoff: pd.Timestamp,
) -> tuple[pd.Series, pd.Series]:
    """Split a streak series the same way as ``split_panel_by_date``."""
    cutoff = pd.Timestamp(cutoff)
    if cutoff.tz is not None:
        cutoff = cutoff.tz_localize(None)
    return streak[streak.index < cutoff], streak[streak.index >= cutoff]


# ══════════════════════════════════════════════════════════════════════════════
# 8. Real-VIX integration helper
# ══════════════════════════════════════════════════════════════════════════════

def streaks_from_real_vix(
    vix_history: pd.DataFrame,
    *,
    high_threshold: float | None = None,
    high_quantile: float = 0.65,
) -> pd.Series:
    """Compute the HIGH-day streak series from a real ``VIXLoader`` history.

    Use this in any of the validation scripts in place of the
    ``build_vix_proxy`` + ``compute_vix_streaks`` pair when you have
    actual VIX data. The threshold can be specified directly or
    inferred as a quantile of the history.

    Example::

        from nimbus_v3.data.cache import ParquetCache
        from nimbus_v3.data.nse_client import NSEClient
        from nimbus_v3.data.vix_loader import VIXLoader
        from nimbus_v3.research.harness import streaks_from_real_vix

        loader = VIXLoader(NSEClient(), ParquetCache(Path('data/cache/vix')))
        history = loader.load_history(years=6)
        streak = streaks_from_real_vix(history)
    """
    if vix_history is None or vix_history.empty or "Close" not in vix_history.columns:
        return pd.Series(dtype=int)
    if high_threshold is None:
        high_threshold = float(vix_history["Close"].quantile(high_quantile))
    return compute_vix_streaks(vix_history, high_threshold=high_threshold)


# ══════════════════════════════════════════════════════════════════════════════
# 9. Walk-forward lift analysis
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class WalkForwardPoint:
    """One (cutoff, train_stats, test_stats) observation in a walk-forward analysis."""
    cutoff: pd.Timestamp
    train_n: int
    train_mean_10d: float
    train_universe_mean_10d: float
    train_lift_pp: float
    test_n: int
    test_mean_10d: float
    test_universe_mean_10d: float
    test_lift_pp: float
    test_t_stat_lift: float


def walk_forward_lift(
    *,
    enriched_panel: dict[str, pd.DataFrame],
    vix_streak: pd.Series,
    predicate,
    cutoffs: list[pd.Timestamp],
    min_train_bars: int = 250,
    min_test_bars: int = 30,
) -> list[WalkForwardPoint]:
    """Evaluate ``predicate`` at many train/test split points.

    For each ``cutoff`` in ``cutoffs``: split the panel at the cutoff,
    run the predicate against train and test halves independently,
    compute train-period and test-period lift over each half's own
    universe baseline, produce a point.

    Use this to verify that a strategy's OOS lift is stable across
    different choices of train/test boundary. Sliding the cutoff
    monthly and plotting the ``test_lift_pp`` series produces a
    "robustness profile" of the strategy — a flat-ish line means the
    edge is real regardless of where you cut; a line that spikes or
    collapses at particular cutoffs reveals regime dependence.

    Args:
        enriched_panel: Dict of symbol → enriched DataFrame (must
            include ``fwd_ret_10d``).
        vix_streak: Aligned streak series.
        predicate: Vectorised predicate ``(df, streak) → bool mask``.
        cutoffs: List of dates at which to split. Each produces one
            point in the returned series.
        min_train_bars: Skip cutoffs where the symbol has fewer than
            this many train bars.
        min_test_bars: Skip cutoffs where the symbol has fewer than
            this many test bars.
    """
    points: list[WalkForwardPoint] = []
    for cutoff in cutoffs:
        cutoff_ts = pd.Timestamp(cutoff)
        if cutoff_ts.tz is not None:
            cutoff_ts = cutoff_ts.tz_localize(None)
        # Split the panel at this cutoff.
        train_panel: dict[str, pd.DataFrame] = {}
        test_panel: dict[str, pd.DataFrame] = {}
        for sym, df in enriched_panel.items():
            idx_naive = (
                df.index.tz_localize(None)
                if df.index.tz is not None else df.index
            )
            train_mask = idx_naive < cutoff_ts
            test_mask = ~train_mask
            if train_mask.sum() >= min_train_bars:
                train_panel[sym] = df[train_mask]
            if test_mask.sum() >= min_test_bars:
                test_panel[sym] = df[test_mask]

        if not train_panel or not test_panel:
            continue

        # Compute each half's universe baseline.
        train_uni = summarise(evaluate_vector_predicate_panel(
            strategy_name="u", enriched_panel=train_panel,
            vix_streak=vix_streak, predicate=lambda df, st: True,
        )).mean_10d
        test_uni = summarise(evaluate_vector_predicate_panel(
            strategy_name="u", enriched_panel=test_panel,
            vix_streak=vix_streak, predicate=lambda df, st: True,
        )).mean_10d

        train_stats = summarise(evaluate_vector_predicate_panel(
            strategy_name="s", enriched_panel=train_panel,
            vix_streak=vix_streak, predicate=predicate,
        ), baseline_mean_10d=train_uni)
        test_stats = summarise(evaluate_vector_predicate_panel(
            strategy_name="s", enriched_panel=test_panel,
            vix_streak=vix_streak, predicate=predicate,
        ), baseline_mean_10d=test_uni)

        points.append(WalkForwardPoint(
            cutoff=cutoff_ts,
            train_n=train_stats.n,
            train_mean_10d=train_stats.mean_10d,
            train_universe_mean_10d=float(train_uni),
            train_lift_pp=(
                (train_stats.mean_10d - train_uni) * 100.0
                if train_stats.n > 0 else float("nan")
            ),
            test_n=test_stats.n,
            test_mean_10d=test_stats.mean_10d,
            test_universe_mean_10d=float(test_uni),
            test_lift_pp=(
                (test_stats.mean_10d - test_uni) * 100.0
                if test_stats.n > 0 else float("nan")
            ),
            test_t_stat_lift=test_stats.t_stat_lift_10d,
        ))
    return points
