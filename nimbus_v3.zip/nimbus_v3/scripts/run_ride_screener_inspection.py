"""Diagnostic inspection: per-bar criterion values for RIDE screener
on the operator's positive example symbols.

This is a diagnostic script. It produces values per (symbol, bar)
showing exactly what the 8 fire criteria evaluated against, around
the operator-marked transition date for each positive example.

Output is purely informational — NO parameter changes, NO
suggestions, NO conclusions about what to adjust. The point is to
answer "which criterion (or criteria) is blocking the fire on each
chart?" — nothing more.

Decisions about whether to adjust anything happen AFTER reading
the output, in conversation, with full awareness that adjusting
parameters based on these specific charts (which were already used
for the original calibration) is methodologically suspect and
should be limited to "drop a filter that's not doing useful work"
rather than "tighten/loosen thresholds."

Output: scripts/output/ride_screener_inspection.txt
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import (
    BBW_LOOKBACK,
    CROSS_LOOKBACK,
    DETACHED_PCTB_MAX,
    OPEN_PCTB_MAX,
    OPEN_PCTB_MIN,
    SLOPE_LOOKBACK,
    SMA_SLOPE_WINDOW,
    compute_ride_init_active,
)
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.research.equity_universe import load_equity_panel

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("ride_screener_inspection")


_EQ_CACHE_DIR: Path = _ROOT / "data" / "cache" / "enriched"
_OUT_PATH: Path = _ROOT / "scripts" / "output" / "ride_screener_inspection.txt"


# ══════════════════════════════════════════════════════════════════════
# Inspection set — same positive examples as validation script,
# but with widened window so we can see the full transition zone
# ══════════════════════════════════════════════════════════════════════

_POSITIVE_EXAMPLES: tuple[tuple[str, str], ...] = (
    ("MOSCHIP",   "2026-04-01"),
    ("DATAPATTNS", "2026-04-15"),
    ("TATACONSUM", "2026-04-15"),
    ("BEML",      "2026-04-01"),
)

#: Look ±30 calendar days around marked date — wide enough that
#: we capture the full transition zone even if the operator's
#: marked date was a few days off.
_INSPECTION_WINDOW_DAYS: int = 30

_DIV_WIDE: str = "═" * 100
_DIV_THIN: str = "─" * 100


# ══════════════════════════════════════════════════════════════════════
# Data prep — load just what we need (these specific symbols)
# ══════════════════════════════════════════════════════════════════════

def _prepare_data() -> dict[str, pd.DataFrame]:
    """Load enriched panel — same pattern as other scripts."""
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    if not raw_panel:
        raise RuntimeError("Equity panel empty — no cached data")

    log.info("Enriching (cache-first)...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched: %d symbols", len(enriched_panel))
    return enriched_panel


# ══════════════════════════════════════════════════════════════════════
# Per-symbol diagnostic table
# ══════════════════════════════════════════════════════════════════════

def _inspect_symbol(
    sym: str, marked_date: str,
    panel: dict[str, pd.DataFrame], emit,
) -> None:
    """Print per-bar criterion values around marked_date."""
    emit(_DIV_WIDE)
    emit(f"SYMBOL: {sym}    Marked transition: {marked_date}")
    emit(_DIV_WIDE)

    df = panel.get(sym)
    if df is None:
        emit(f"  Symbol not in enriched panel — cannot inspect")
        emit("")
        return

    target = pd.Timestamp(marked_date)
    window_start = target - pd.Timedelta(days=_INSPECTION_WINDOW_DAYS)
    window_end = target + pd.Timedelta(days=_INSPECTION_WINDOW_DAYS)
    in_window = (df.index >= window_start) & (df.index <= window_end)
    sub = df.loc[in_window]
    if sub.empty:
        emit(f"  No bars in window ±{_INSPECTION_WINDOW_DAYS}d around target")
        emit("")
        return

    # Compute per-bar criterion components on the FULL dataframe
    # (need history before window_start for lookbacks), then slice.
    # CRITICAL: must use the SAME body-above semantics as the
    # shipped screener, otherwise the diagnostic columns lie.
    open_ = df.get("Open", df["Close"])    # fall back if absent
    close = df["Close"]
    upper = df["bb_20_1s_upper"]
    sma = df["sma_20"]
    bbw = df["bbw_20_1s"]

    # Body-above: both Open and Close > upper. THIS is what the
    # screener uses. The lower wick (Low) can pierce.
    body_above = (open_ > upper) & (close > upper)

    # Diagnostic columns also report close-only-above, so the
    # operator can SEE the difference (close-above bars where
    # body-above is False = momentum bars excluded by body check).
    close_above_only = (close > upper) & ~body_above

    # Criterion 2: body above yesterday (hold check)
    body_above_yesterday = body_above.shift(1)

    # Criterion 3: fresh body-above at T-1 (no body-above bars in
    # CROSS_LOOKBACK bars ending at T-2)
    prior_body_above_count = (
        body_above.shift(2).rolling(CROSS_LOOKBACK, min_periods=1).sum()
    )
    fresh_body_above_t_minus_1 = body_above.shift(1) & (
        prior_body_above_count == 0
    )

    lower = df["bb_20_1s_lower"]

    # %B for the detached check — both close and open
    band_width = (upper - lower).replace(0.0, np.nan)
    pct_b = (close - lower) / band_width
    pct_b_open = (open_ - lower) / band_width

    # The COMBINED detached check that the screener actually applies
    # (matches _compute_fire_series): bar is detached if close %B
    # exceeds threshold OR open %B is outside [min, max] zone.
    close_detached = pct_b > DETACHED_PCTB_MAX
    open_out_of_zone = (
        (pct_b_open < OPEN_PCTB_MIN) | (pct_b_open > OPEN_PCTB_MAX)
    )
    detached_today = close_detached | open_out_of_zone
    close_over_upper_pct_today = (close - upper) / upper * 100    # cosmetic

    # Same combined check on yesterday
    close_detached_y = pct_b.shift(1) > DETACHED_PCTB_MAX
    open_out_of_zone_y = (
        (pct_b_open.shift(1) < OPEN_PCTB_MIN)
        | (pct_b_open.shift(1) > OPEN_PCTB_MAX)
    )
    detached_yesterday = close_detached_y | open_out_of_zone_y

    # Criterion 6: open at T-1 not below SMA20 (gap-through filter)
    open_at_t_minus_1 = open_.shift(1)
    sma_at_t_minus_1 = sma.shift(1)
    gap_through = open_at_t_minus_1 < sma_at_t_minus_1

    # Criterion 7: slope acceleration
    slope_now = (sma - sma.shift(SMA_SLOPE_WINDOW)) / SMA_SLOPE_WINDOW
    slope_then = slope_now.shift(SLOPE_LOOKBACK)
    slope_positive = slope_now > 0
    slope_accelerating = slope_now > slope_then

    # Criterion 8: BBW expanding
    bbw_then = bbw.shift(BBW_LOOKBACK)
    bbw_expanding = bbw > bbw_then

    # Active output (for reference)
    active = compute_ride_init_active(df)

    # Slice to window for printing
    sub_idx = sub.index
    sub_open = open_.loc[sub_idx]
    sub_close = close.loc[sub_idx]
    sub_upper = upper.loc[sub_idx]
    sub_body_above = body_above.loc[sub_idx]
    sub_close_above_only = close_above_only.loc[sub_idx]
    sub_body_above_yest = body_above_yesterday.loc[sub_idx]
    sub_fresh = fresh_body_above_t_minus_1.loc[sub_idx]
    sub_detached_today = detached_today.loc[sub_idx]
    sub_detached_yest = detached_yesterday.loc[sub_idx]
    sub_close_pct_today = close_over_upper_pct_today.loc[sub_idx]
    sub_pctb = pct_b.loc[sub_idx]
    sub_pctb_open = pct_b_open.loc[sub_idx]
    sub_gap = gap_through.loc[sub_idx]
    sub_slope_now = slope_now.loc[sub_idx]
    sub_slope_then = slope_then.loc[sub_idx]
    sub_slope_pos = slope_positive.loc[sub_idx]
    sub_slope_acc = slope_accelerating.loc[sub_idx]
    sub_bbw = bbw.loc[sub_idx]
    sub_bbw_then = bbw_then.loc[sub_idx]
    sub_bbw_exp = bbw_expanding.loc[sub_idx]
    sub_active = active.loc[sub_idx]

    # ── Print summary first ──────────────────────────────────────────
    emit("")
    emit(f"  Bars in window: {len(sub)} "
         f"({sub_idx.min().date()} → {sub_idx.max().date()})")
    n_close_above = int((sub_close > sub_upper).sum())
    n_body_above = int(sub_body_above.sum())
    emit(f"  Bars where Close > upper BB:        {n_close_above}")
    emit(f"  Bars where BODY-ABOVE upper BB:     {n_body_above} "
         f"(Open > upper AND Close > upper — what the screener checks)")
    n_active = int(sub_active.sum())
    emit(f"  Bars where RIDE active:             {n_active}")
    emit("")

    # ── Print per-bar criterion values ────────────────────────────────
    # Show ALL bars where close > upper, so we can see body-above
    # (the actual screener check) AND close-only-above (momentum
    # bars excluded by the screener) side-by-side. Body-above bars
    # have BODY=T; close-only-above bars have BODY=F.
    emit("Bars where Close > upper BB (sorted by date):")
    emit("(BODY=T means body-above i.e. screener sees this as a ride bar.")
    emit(" BODY=F means close above but open below upper — momentum bar,")
    emit(" excluded by screener.)")
    emit("")
    if n_close_above == 0:
        emit("  None — Close never exceeded upper BB in window.")
        emit("")
        return

    # Header — added BODY + %B (close) + %B-OPN columns
    emit(f"  {'DATE':<12} {'OPEN':>9} {'CLOSE':>9} {'UPPER':>9} "
         f"{'OVER%':>6} {'%Bcl':>5} {'%Bop':>5}  "
         f"{'BODY':>4} {'B-1':>3} {'FRESH':>5} {'DET-T':>5} {'DET-1':>5} {'GAP':>5}  "
         f"{'SLPNOW':>8} {'SLPTHN':>8} {'SLPOK':>5}  "
         f"{'BBWNOW':>7} {'BBW-5':>7} {'BBWUP':>5}  "
         f"{'ACTIVE':>6}")
    emit(f"  {'─' * 12} {'─' * 9} {'─' * 9} {'─' * 9} {'─' * 6} {'─' * 5} {'─' * 5}  "
         f"{'─' * 4} {'─' * 3} {'─' * 5} {'─' * 5} {'─' * 5} {'─' * 5}  "
         f"{'─' * 8} {'─' * 8} {'─' * 5}  "
         f"{'─' * 7} {'─' * 7} {'─' * 5}  "
         f"{'─' * 6}")

    for date in sub_idx:
        if not (sub_close.loc[date] > sub_upper.loc[date]):
            continue
        o = sub_open.loc[date]
        c = sub_close.loc[date]
        u = sub_upper.loc[date]
        over_pct = sub_close_pct_today.loc[date]
        pb = sub_pctb.loc[date]
        pb_open = sub_pctb_open.loc[date]
        body = sub_body_above.loc[date]
        body_yest = sub_body_above_yest.loc[date]
        fr = sub_fresh.loc[date]
        dt = sub_detached_today.loc[date]
        dy = sub_detached_yest.loc[date]
        gp = sub_gap.loc[date]
        sn = sub_slope_now.loc[date]
        st = sub_slope_then.loc[date]
        slpok = (sub_slope_pos.loc[date] and sub_slope_acc.loc[date])
        bw = sub_bbw.loc[date]
        bt = sub_bbw_then.loc[date]
        bwup = sub_bbw_exp.loc[date]
        act = sub_active.loc[date]

        def _b(v):
            if pd.isna(v):
                return "  ?"
            return "  T" if bool(v) else "  F"

        def _f(v, fmt):
            if pd.isna(v):
                return "    nan"
            return f"{v:{fmt}}"

        emit(f"  {date.date()!s:<12} "
             f"{_f(o, '9.2f')} {_f(c, '9.2f')} {_f(u, '9.2f')} "
             f"{_f(over_pct, '5.2f')}% {_f(pb, '5.3f')} {_f(pb_open, '5.3f')}  "
             f"{_b(body)} {_b(body_yest)} {_b(fr)} {_b(dt)} {_b(dy)} {_b(gp)}  "
             f"{_f(sn, '8.4f')} {_f(st, '8.4f')} {_b(slpok)}  "
             f"{_f(bw, '7.3f')} {_f(bt, '7.3f')} {_b(bwup)}  "
             f"{_b(act)}")

    emit("")
    emit("  Column key:")
    emit("    OPEN    = bar's open price")
    emit("    CLOSE   = bar's close price")
    emit("    OVER%   = (close - upper) / upper × 100  (cosmetic context)")
    emit("    %Bcl    = (close - lower) / (upper - lower); "
         f"detached when > {DETACHED_PCTB_MAX}")
    emit(f"    %Bop    = (open - lower) / (upper - lower); "
         f"must be in [{OPEN_PCTB_MIN}, {OPEN_PCTB_MAX}]")
    emit("              %B = 1.0 means at upper band")
    emit("              %B = 1.5 means half a band-width above upper")
    emit("              %B = 2.0 means one full band-width above upper")
    emit("    BODY    = body-above today (Open > upper AND Close > upper)")
    emit("              T = the screener sees this as a ride bar")
    emit("              F = close is above but open is below — momentum")
    emit("                  bar, body straddles band, NOT a ride bar")
    emit("    B-1     = body-above YESTERDAY (hold check)")
    emit("    FRESH   = no body-above bars in prior "
         f"{CROSS_LOOKBACK} bars (fresh-ride check)")
    emit(f"    DET-T   = detached today (close %B > {DETACHED_PCTB_MAX}")
    emit(f"              OR open %B not in [{OPEN_PCTB_MIN}, {OPEN_PCTB_MAX}])")
    emit("    DET-1   = same checks on YESTERDAY's bar (cross-init)")
    emit("    DET-T   = detached TODAY (close >> upper today)")
    emit("    DET-1   = detached YESTERDAY (close >> upper at ride-init bar)")
    emit("    GAP     = single-bar gap-through "
         "(open below SMA20 yesterday)")
    emit("    SLPNOW  = SMA20 5-bar slope now")
    emit(f"    SLPTHN  = SMA20 5-bar slope {SLOPE_LOOKBACK} bars ago")
    emit("    SLPOK   = slope_now > 0 AND slope_now > slope_then")
    emit("    BBWNOW  = BBW now")
    emit(f"    BBW-5   = BBW {BBW_LOOKBACK} bars ago")
    emit("    BBWUP   = BBW expanding (BBWNOW > BBW-5)")
    emit("    ACTIVE  = RIDE screener active on this bar")
    emit("")
    emit("  Fire requires: BODY=T AND B-1=T AND FRESH=T AND DET-T=F AND")
    emit("                 DET-1=F AND GAP=F AND SLPOK=T AND BBWUP=T")
    emit("")


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data...")
    try:
        panel = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("RIDE SCREENER — DIAGNOSTIC INSPECTION")
        emit(_DIV_WIDE)
        emit("Per-bar criterion values for the 4 positive example")
        emit("symbols, around their operator-marked transition dates.")
        emit("")
        emit("This is DIAGNOSTIC ONLY. No conclusions, no parameter")
        emit("suggestions. The point is to identify which criterion")
        emit("(or criteria) blocks the fire on each chart so we can")
        emit("have an honest conversation about what to do.")
        emit("")
        emit(f"Inspection window: ±{_INSPECTION_WINDOW_DAYS} calendar days")
        emit("around marked transition date.")
        emit("")
        emit("Shipped parameters (FROM compute/ride_initiation.py):")
        emit(f"  CROSS_LOOKBACK    = {CROSS_LOOKBACK}")
        emit(f"  DETACHED_PCTB_MAX = {DETACHED_PCTB_MAX}  (close %B ceiling)")
        emit(f"  OPEN_PCTB_MIN     = {OPEN_PCTB_MIN}  (open %B floor)")
        emit(f"  OPEN_PCTB_MAX     = {OPEN_PCTB_MAX}  (open %B ceiling)")
        emit(f"  SLOPE_LOOKBACK    = {SLOPE_LOOKBACK}")
        emit(f"  SMA_SLOPE_WINDOW  = {SMA_SLOPE_WINDOW}")
        emit(f"  BBW_LOOKBACK      = {BBW_LOOKBACK}")
        emit("")

        for sym, marked in _POSITIVE_EXAMPLES:
            _inspect_symbol(sym, marked, panel, emit)

        emit(_DIV_WIDE)
        emit("END OF INSPECTION")
        emit(_DIV_WIDE)
        emit("Read this output to identify which criterion is")
        emit("blocking the fire on each chart. The honest")
        emit("post-inspection options are:")
        emit("")
        emit("  1. Drop a filter that's not doing useful work")
        emit("     (consider only if ALL 4 charts are blocked by")
        emit("     the SAME filter — that's evidence the filter")
        emit("     was wrongly conceived, not evidence we should")
        emit("     'tune' it to fit).")
        emit("")
        emit("  2. Roll back the screener entirely if the")
        emit("     pattern can't be implemented mechanically the")
        emit("     way the criteria attempt.")
        emit("")
        emit("  3. Accept that ALL 4 chart dates are wrong and")
        emit("     re-mark them — but that decision must come from")
        emit("     YOU re-examining your screenshots, not from me")
        emit("     fitting dates to the criteria.")
        emit("")
        emit("Adjusting threshold values (e.g. DETACHED_PCTB_MAX 1.5 → 2.0)")
        emit("based on what we see here remains methodologically")
        emit("tainted and is not on the menu.")
        emit(_DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
