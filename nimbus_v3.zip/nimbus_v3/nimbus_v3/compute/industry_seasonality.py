"""nimbus_v3.compute.industry_seasonality — month × industry grid.

Stateless. For each industry, builds an ADTV-weighted composite price
series over FULL available history (not the rotation 60-day window —
seasonality needs years), then runs the per-symbol seasonality compute
on that composite. The result is a grid the heatmap renders: one row per
industry, 12 month columns, cell = average monthly return.

Composite-first (matching the rotation engine's philosophy): the
industry is treated as one ADTV-weighted entity, so a small illiquid
member can't distort the industry's seasonal read.

Honesty about history depth: seasonality needs multiple years to mean
anything (``seasonality.MIN_YEARS``). Industries whose composite has
fewer years are returned with ``has_data=False`` and their cells should
be greyed out by the renderer rather than painted as confident signal.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from nimbus_v3.compute.indicators import adtv_latest
from nimbus_v3.compute.industry_composite import build_industry_composite
from nimbus_v3.compute.industry_rotation import MIN_MEMBERS
from nimbus_v3.compute.seasonality import (
    compute_seasonality,
    seasonal_reliability,
)


#: Per-industry overrides of the composite floor (default MIN_MEMBERS).
#: A few tracked industries sit one member below the floor but are still
#: worth showing with REAL aggregated numbers, so their floor is lowered
#: explicitly here. This is a hand-maintained exception, NOT a change to
#: the global floor: a lowered floor means a thinner composite (each
#: member is a larger share of the weight), so those cells' σ/avg and
#: reliability will reflect the smaller base — read them accordingly.
#:
#: Keys are matched by NORMALISED name (see ``_norm_industry``): lower-
#: cased, hyphens treated as spaces, and runs of whitespace collapsed.
#: This makes the match robust to NSE's punctuation/spacing variants —
#: e.g. the data's "Non - Ferrous Metals", "Non-Ferrous Metals" and
#: "Non-ferrous Metals" all normalise to the same key. Add/remove entries
#: here only; write keys in the same normalised form.
_MIN_MEMBERS_OVERRIDES: dict[str, int] = {
    "non ferrous metals": 4,
}


def _norm_industry(industry: str) -> str:
    """Normalise an industry name for override matching: lowercase, treat
    hyphens as spaces, and collapse whitespace. So "Non - Ferrous Metals",
    "Non-Ferrous Metals" and "non-ferrous  metals" all map to the same
    key, insulating the override from NSE's spacing/punctuation quirks."""
    return " ".join(industry.lower().replace("-", " ").split())


def _floor_for(industry: str) -> int:
    """Composite floor (min members) for ``industry`` — the global
    ``MIN_MEMBERS`` unless explicitly overridden."""
    return _MIN_MEMBERS_OVERRIDES.get(_norm_industry(industry), MIN_MEMBERS)


@dataclass(frozen=True)
class IndustrySeasonality:
    """One industry's monthly seasonality row."""

    industry: str
    #: 12 average monthly returns (%, Jan..Dec); NaN where no data.
    avg_returns: tuple[float, ...]
    #: 12 hit rates (% years positive, Jan..Dec); NaN where no data.
    hit_rates: tuple[float, ...]
    #: 12 dispersions (std of monthly returns across years, %); NaN where
    #: fewer than 2 observations.
    std_returns: tuple[float, ...]
    #: 12 standard errors of the mean (%, Jan..Dec) = std/sqrt(n_years).
    #: The sampling uncertainty on each cell's avg_return; NaN where std is.
    std_errs: tuple[float, ...]
    #: Cumulative average 12-month path (%, Jan..Dec) — the running sum of
    #: avg_returns, i.e. the "if every year were the average year" equity
    #: walk for this industry's composite. Already produced by
    #: ``compute_seasonality``; carried here so the heatmap can draw the
    #: per-industry average-year curve without recomputing the composite.
    cumulative_path: tuple[float, ...]
    #: Per-month count of members that actually backed each cell (Jan..Dec).
    #: A cell is blank when this is below the composite floor (MIN_MEMBERS):
    #: 0 means no usable members at all (a true data gap), while a value in
    #: 1..MIN_MEMBERS-1 means the industry has members but too few to form a
    #: reliable composite — a deliberate "too few to aggregate" blank, not a
    #: glitch. The UI uses this to mark and explain the empty cell.
    cell_n_members: tuple[int, ...]
    #: Per-month weight-aware seasonal QUALITY (0..1, Jan..Dec) — the
    #: composite reliability blended with a member-level read that accounts
    #: for heavy-but-lumpy members and dependable-but-underweight members
    #: (see :func:`_seasonal_quality_from_cache`). This is what the
    #: confluence seasonal factor discounts by, so an industry whose
    #: headline reliability looks fine but whose guts are lumpy is
    #: correctly demoted. NaN where the cell has no data.
    seasonal_quality: tuple[float, ...]
    n_years: int
    n_members: int
    has_data: bool


@dataclass(frozen=True)
class SeasonalityGrid:
    """All industries' monthly seasonality, ready for a heatmap."""

    rows: tuple[IndustrySeasonality, ...]
    #: Per-month cross-industry return (%, Jan..Dec), member-count-
    #: WEIGHTED across the industries that have data — the "market-wide"
    #: seasonal baseline. Weighting (vs a plain mean) keeps a handful of
    #: tiny industries from swinging the baseline as much as the broad
    #: market. The Relative-to-market view subtracts this from each cell
    #: so the uniform market pattern cancels and only industry-specific
    #: seasonality remains. NaN for a month no industry has data for.
    market_baseline: tuple[float, ...] = (float("nan"),) * 12

    @property
    def has_data(self) -> bool:
        return any(r.has_data for r in self.rows)

    @property
    def market_baseline_path(self) -> tuple[float, ...]:
        """Cumulative average 12-month path (%, Jan..Dec) of the market
        baseline — the running sum of ``market_baseline``, the "average
        year" walk for the market as a whole. NaN months contribute 0 to
        the walk (flat) so the line stays continuous, matching how
        ``compute_seasonality`` builds a per-series path. Drawn faint
        behind a selected industry's path for context."""
        cum: list[float] = []
        running = 0.0
        for v in self.market_baseline:
            if v == v:    # not NaN
                running += v
            cum.append(running)
        return tuple(cum)


@dataclass(frozen=True)
class MemberContribution:
    """One member's contribution to a single (industry, month) cell."""

    symbol: str
    weight: float              # ADTV weight within the industry (0..1)
    member_avg: float          # member's own avg return for that month, %
    member_std: float          # member's own dispersion that month, %
    member_hit: float          # member's own hit rate that month, %
    #: weight × member_avg — the member's additive share of the industry's
    #: composite avg return for the month (sums ≈ the cell magnitude).
    magnitude_contribution: float
    #: Signed reliability impact: positive = this member STEADIES the cell
    #: (consistent, low own-dispersion), negative = this member is an
    #: outlier source DRAGGING reliability down (erratic that month).
    reliability_impact: float
    n_years: int
    #: Compact human-readable caveat for this member's stats — the
    #: subtlety the raw numbers don't make obvious (thin sample, erratic,
    #: steady, outlier-driven, etc.). Computed in the engine so the UI
    #: just renders it.
    remark: str = ""


@dataclass(frozen=True)
class CellContribution:
    """Decomposition of one (industry, month) cell into member impacts."""

    industry: str
    month: int                 # 1..12
    cell_avg: float            # the industry cell's avg return (%)
    cell_reliability: float    # the cell's reliability score (0..1)
    members: tuple[MemberContribution, ...]

    @property
    def has_data(self) -> bool:
        return len(self.members) > 0


def compute_cell_contributions(
    industry: str,
    month: int,
    members: list[str],
    panel: dict[str, pd.DataFrame],
    min_member_years: int = 0,
) -> CellContribution:
    """Decompose an (industry, month) seasonality cell into the member
    symbols that drive its magnitude and reliability.

    Magnitude is additive: each member contributes ``weight × its own
    average return for that month``, and these sum to (approximately) the
    industry composite's average for the month. Reliability impact is a
    signed read of whether a member steadies the cell (consistent in that
    month) or is the outlier source inflating one year — a member can be
    the top magnitude contributor while being the worst for reliability.

    Args:
        industry: industry name (for labelling).
        month: calendar month, 1..12.
        members: member symbols.
        panel: ``{symbol: enriched_df}``.
        min_member_years: when > 0, restrict the decomposition to members
            with at least this many observations of THIS month — so the
            members, weights, cell_avg and reliability match the per-month
            stable grid cell exactly (same set builds both, and no
            single-year members leak in). 0 (default) uses all usable
            members, matching the all-members grid.
    """
    members = _members_with_min_years_in_month(
        members, panel, month, min_member_years)
    raw: list[tuple[str, float, pd.Series]] = []
    for sym in members:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        s = df["Close"].dropna()
        if len(s) < 2:
            continue
        adtv = adtv_latest(df)
        w = adtv if (adtv == adtv and adtv > 0) else 0.0
        raw.append((sym, w, s))

    if not raw:
        return CellContribution(industry, month, float("nan"),
                                float("nan"), ())

    wsum = sum(w for _, w, _ in raw)
    if wsum <= 0:
        eq = 1.0 / len(raw)
        weights = {sym: eq for sym, _, _ in raw}
    else:
        weights = {sym: w / wsum for sym, w, _ in raw}

    mi = month - 1
    contribs: list[MemberContribution] = []
    cell_avg_acc = 0.0
    for sym, _, close in raw:
        res = compute_seasonality(close)
        stat = res.months[mi]
        avg = stat.avg_return
        std = stat.std_return
        hit = stat.hit_rate
        w = weights[sym]
        mag_contrib = (w * avg) if avg == avg else float("nan")
        if mag_contrib == mag_contrib:
            cell_avg_acc += mag_contrib

        own_rel = _member_reliability(avg, std)
        # Centre at 0.5: above → steadying, below → destabilising; scale
        # by weight so trivial members don't dominate the read.
        reliability_impact = w * (own_rel - 0.5) * 2.0 \
            if own_rel == own_rel else float("nan")

        contribs.append(MemberContribution(
            symbol=sym,
            weight=w,
            member_avg=avg,
            member_std=std,
            member_hit=hit,
            magnitude_contribution=mag_contrib,
            reliability_impact=reliability_impact,
            n_years=stat.n_years,
            remark=_member_remark(avg, std, hit, w, mag_contrib,
                                  reliability_impact, stat.n_years),
        ))

    # Default sort: biggest movers first, by absolute magnitude share.
    contribs.sort(
        key=lambda c: (abs(c.magnitude_contribution)
                       if c.magnitude_contribution == c.magnitude_contribution
                       else -1.0),
        reverse=True)

    return CellContribution(
        industry=industry, month=month,
        cell_avg=cell_avg_acc if contribs else float("nan"),
        cell_reliability=float("nan"),
        members=tuple(contribs))


def _member_remark(avg: float, std: float, hit: float, weight: float,
                   mag: float, rel_impact: float, n_years: int) -> str:
    """A compact caveat string for a member's seasonal stats — the
    subtlety the raw numbers don't make obvious. Priority: sample size
    first (it invalidates everything else), then the magnitude/dispersion
    character. Returns '' when nothing notable stands out."""
    if avg != avg:
        return "no data this month"
    # Sample size dominates — a great-looking stat off 1-2 years is noise.
    if n_years <= 1:
        return "single year — not a pattern"
    if n_years == 2:
        return "only 2 yrs — thin sample"

    big_weight = weight >= 0.15
    dominant = weight >= 0.35
    strong_mag = abs(mag) >= 1.0
    # Dispersion relative to the move: >1 means the year-to-year swing is
    # bigger than the average itself (lumpy); <0.4 means tight/consistent.
    noisy = (std == std and abs(avg) > 1e-9 and std / abs(avg) >= 1.0)
    tight = (std == std and abs(avg) > 1e-9 and std / abs(avg) <= 0.4)
    moderate_disp = (std == std and abs(avg) > 1e-9
                     and 0.4 < std / abs(avg) < 1.0)
    steady_hit = hit == hit and hit >= 80
    perfect_hit = hit == hit and hit >= 100
    steadies = rel_impact == rel_impact and rel_impact > 0.02

    # The most useful flags, in order of what an operator cares about.
    if strong_mag and rel_impact == rel_impact and rel_impact < 0:
        return "drives the number but destabilises it"
    if big_weight and noisy:
        return "heavyweight but erratic — watch"
    if noisy:
        return "lumpy — high yr-to-yr swing"
    # The cell's ANCHOR: a dominant-weight member that also steadies the
    # cell (positive reliability impact) and isn't a loss. This is the
    # most important row — recognise it explicitly rather than leaving it
    # blank just because its dispersion sits in the middle band.
    if dominant and avg >= 0 and steadies:
        return "anchor — drives & steadies"
    # Tight dispersion = a dependable PATTERN — but the sign decides
    # whether that pattern is a tailwind (good) or a headwind (a reliable
    # drag you'd want to avoid that month). "Consistent" must never read
    # as reassuring when the consistent thing is a loss.
    if tight and avg >= 0:
        return "steady & dependable" if steady_hit else "consistent gain"
    if tight and avg < 0:
        return ("reliably weak — steady drag" if (hit == hit and hit <= 20)
                else "consistently negative")
    # Up EVERY year (perfect hit) with positive return — dependable even
    # if the magnitude is modest and the dispersion only moderate.
    if perfect_hit and avg > 0:
        return "up every year — dependable"
    if avg < 0:
        return "seasonal drag"
    if 0 < abs(mag) < 0.2:
        return "minor contributor"
    # In-between: positive, moderate everything, nothing extreme. Name it
    # so a BLANK remark only ever means genuinely unremarkable.
    if avg > 0 and moderate_disp:
        return "solid — moderate swing" if steadies else "moderate, mixed"
    return ""


def _member_reliability(avg: float, std: float) -> float:
    """A single member's month reliability. Thin alias for the canonical
    :func:`seasonal_reliability` so the SNR formula lives in one place."""
    return seasonal_reliability(avg, std)


#: Blend weight: the seasonal QUALITY that discounts the confluence
#: seasonal factor is 0.6 × weight-aware member quality + 0.4 × the
#: composite reliability. Member-quality leads because the composite
#: reliability can look smoother than its parts — an industry whose heavy
#: members are individually lumpy (large yr-to-yr swing) but happen to
#: aggregate into a moderate composite would otherwise read as more
#: dependable than it truly is. Weighting member-quality higher surfaces
#: that hidden lumpiness.
_QUALITY_MEMBER_WEIGHT: float = 0.6
_QUALITY_COMPOSITE_WEIGHT: float = 0.4

#: A member counts as "dependable" for the concentration check when its
#: own-month reliability is at least this. The concentration factor asks:
#: how much of the industry's WEIGHT sits in dependable members? If the
#: steady names are underweight and the lumpy ones dominate, the seasonal
#: read is fragile regardless of the aggregate — so the quality is scaled
#: down toward this floor.
_DEPENDABLE_RELIABILITY: float = 0.5
_CONCENTRATION_FLOOR: float = 0.35    # min concentration multiplier


def _member_month_stats(
    member_weights: list[tuple[str, float]],
    panel: dict[str, pd.DataFrame],
) -> list[tuple[str, float, object]]:
    """Compute each member's FULL 12-month seasonality exactly ONCE and
    return ``[(symbol, weight, MonthlySeasonality)]``.

    This is the cache that makes the per-month quality cheap: previously
    the quality function recomputed every member's full seasonality once
    *per month* (12× redundant work — the dominant startup cost). Building
    it once here and reading months out of it collapses that to a single
    ``compute_seasonality`` per member.
    """
    out: list[tuple[str, float, object]] = []
    for sym, w in member_weights:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        seas = compute_seasonality(df["Close"].dropna())
        out.append((sym, w, seas))
    return out


def _seasonal_quality_from_cache(
    member_stats: list[tuple[str, float, object]],
    month: int,
    composite_reliability: float,
) -> float:
    """Weight-aware seasonal QUALITY for one month, reading each member's
    already-computed seasonality (see :func:`_member_month_stats`). Same
    formula as before — weight-aware member reliability × concentration,
    blended with the composite reliability — just without recomputing
    member seasonality per month."""
    mi = month - 1
    tot_w = 0.0
    wr_sum = 0.0
    dependable_w = 0.0
    have_any = False
    for _sym, w, seas in member_stats:
        stat = seas.months[mi]
        own = _member_reliability(stat.avg_return, stat.std_return)
        if own != own:
            continue
        have_any = True
        tot_w += w
        wr_sum += w * own
        if own >= _DEPENDABLE_RELIABILITY:
            dependable_w += w

    if not have_any or tot_w <= 0:
        return composite_reliability if composite_reliability == composite_reliability else 0.0

    weight_aware_rel = wr_sum / tot_w
    dependable_share = dependable_w / tot_w
    concentration = _CONCENTRATION_FLOOR + \
        (1.0 - _CONCENTRATION_FLOOR) * dependable_share
    member_quality = weight_aware_rel * concentration

    comp = composite_reliability if composite_reliability == composite_reliability else member_quality
    return (_QUALITY_MEMBER_WEIGHT * member_quality
            + _QUALITY_COMPOSITE_WEIGHT * comp)


def _members_with_min_years(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    min_years: int,
) -> list[str]:
    """Subset of ``members`` whose OWN price history spans at least
    ``min_years`` distinct calendar years of monthly returns.

    Year-counting goes through ``compute_seasonality`` (the canonical
    source of a series' year depth) rather than re-deriving it here, so
    "how many years does this symbol have" has exactly one definition.
    ``min_years <= 0`` is a no-op (returns members unchanged) — the
    all-members grid path.
    """
    if min_years <= 0:
        return members
    kept: list[str] = []
    for sym in members:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        if compute_seasonality(df["Close"].dropna()).n_years >= min_years:
            kept.append(sym)
    return kept


def _members_with_min_years_in_month(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    month: int,
    min_years: int,
) -> list[str]:
    """Subset of ``members`` with at least ``min_years`` observations of
    a SPECIFIC ``month`` (1..12).

    This is stricter — and more honest — than whole-history filtering for
    a per-cell view: a stock can span 3+ calendar years overall yet have
    only one July (e.g. a recent listing whose history hasn't crossed a
    third July). Whole-history filtering would admit it and the July cell
    would still rest on a single year. Filtering on the month's own
    observation count guarantees the cell genuinely has ``min_years`` of
    that month behind it. Per-month counts come from
    ``compute_seasonality`` (single source of month-level year depth).
    ``min_years <= 0`` is a no-op.
    """
    if min_years <= 0:
        return members
    mi = month - 1
    kept: list[str] = []
    for sym in members:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        if compute_seasonality(df["Close"].dropna()).months[mi].n_years \
                >= min_years:
            kept.append(sym)
    return kept


def _composite_close(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    min_members: int = MIN_MEMBERS,
) -> tuple[pd.Series | None, int, int, list[tuple[str, float]]]:
    """ADTV-weighted composite close over FULL history.

    Returns ``(series, n_used, n_eligible, member_weights)``:
      * ``series`` — the composite, or None when fewer than
        ``min_members`` usable members exist (the composite floor; may be
        lowered per-industry via ``_floor_for``).
      * ``n_used`` — members actually in the composite (0 when None).
      * ``n_eligible`` — members that HAD usable data, independent of the
        floor. This distinguishes "no data at all" (0) from "has members
        but below the floor" (1..floor-1) so a blank cell can say WHY it's
        blank rather than surfacing a bare NaN.
      * ``member_weights`` — the ``(symbol, normalised_weight)`` list the
        composite was built from (empty when None), so callers can compute
        weight-aware member statistics using the SAME weights.

    Thin wrapper over the shared ``build_industry_composite`` (full
    history, MIN_YEARS-agnostic; seasonality needs every year available).
    """
    # Count members with usable data up front, so we can report the reason
    # a composite couldn't form rather than just None.
    n_eligible = 0
    for sym in members:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        if df["Close"].dropna().shape[0] >= 2:
            n_eligible += 1
    composite, member_weights = build_industry_composite(
        members, panel, min_members=min_members, min_bars=2, lookback=None)
    if composite is None:
        return None, 0, n_eligible, []
    return composite, len(member_weights), n_eligible, member_weights


def _build_row(
    industry: str,
    members: list[str],
    panel: dict[str, pd.DataFrame],
    min_member_years: int = 0,
) -> IndustrySeasonality | None:
    """Build one industry's seasonality row, or None when no composite can
    be formed.

    When ``min_member_years <= 0`` (all-members grid) this builds a single
    composite over every usable member and reads all 12 cells from it.

    When ``min_member_years > 0`` (stable grid) the member set is filtered
    PER MONTH: each cell is built from the composite of members that have
    at least ``min_member_years`` observations of *that* month. A member
    may qualify for some months and not others (a recent listing can have
    3 Aprils but only 2 Julys), so the composite — and ``n_members`` — can
    differ cell to cell. This is what makes the stable view's promise
    literally true: every shown cell rests on ≥N years of that month, with
    no single-year cells leaking through. ``n_members``/``n_years`` are
    reported for the month with the most members so the row carries a
    representative count.
    """
    floor = _floor_for(industry)
    if min_member_years <= 0:
        comp, n_members, n_eligible, mweights = _composite_close(
            members, panel, floor)
        if comp is None:
            # Couldn't form a composite (fewer than `floor` members). An
            # all-blank row clutters the grid, so drop it entirely — both
            # the genuine-gap case and the below-floor case. (Industries
            # that must stay visible get a lowered floor via
            # _MIN_MEMBERS_OVERRIDES so they aggregate real numbers
            # instead of showing as blank.)
            return None
        result = compute_seasonality(comp)
        # Weight-aware seasonal quality per month. Compute each member's
        # full seasonality ONCE (the cache), then read all 12 months from
        # it — avoids recomputing member seasonality per month (the old
        # 12× hot path that dominated startup).
        mstats = _member_month_stats(mweights, panel)
        quality = tuple(
            _seasonal_quality_from_cache(
                mstats, m + 1,
                seasonal_reliability(result.months[m].avg_return,
                                     result.months[m].std_return))
            if result.months[m].avg_return == result.months[m].avg_return
            else float("nan")
            for m in range(12))
        return IndustrySeasonality(
            industry=industry,
            avg_returns=tuple(m.avg_return for m in result.months),
            hit_rates=tuple(m.hit_rate for m in result.months),
            std_returns=tuple(m.std_return for m in result.months),
            std_errs=tuple(m.std_err for m in result.months),
            cumulative_path=tuple(result.cumulative_path),
            cell_n_members=(n_members,) * 12,
            seasonal_quality=quality,
            n_years=result.n_years,
            n_members=n_members,
            has_data=result.has_data,
        )

    # Stable grid: independent per-month member set + composite.
    # Precompute each member's 12 per-month year-counts ONCE (one
    # compute_seasonality per member, not per member-per-month), then the
    # month loop is a cheap lookup. Avoids the 12× recomputation that
    # calling the per-month filter helper inside the loop would incur.
    # One member-seasonality cache for the whole stable path: used both to
    # derive each member's per-month year depth AND (below) the weight-
    # aware quality — so each member's seasonality is computed exactly once.
    _seas_cache: dict[str, object] = {}

    def _seas_for(sym: str):
        seas = _seas_cache.get(sym)
        if seas is None:
            df = panel.get(sym)
            if df is None or df.empty or "Close" not in df.columns:
                return None
            seas = compute_seasonality(df["Close"].dropna())
            _seas_cache[sym] = seas
        return seas

    month_year_counts: dict[str, tuple[int, ...]] = {}
    for sym in members:
        res = _seas_for(sym)
        if res is None:
            continue
        month_year_counts[sym] = tuple(m.n_years for m in res.months)

    avg, hit, std, sem = [], [], [], []
    members_per_month: list[int] = []
    years_per_month: list[int] = []
    cell_members: list[int] = []
    quality: list[float] = []
    any_data = False

    def _member_stats_for(mw: list[tuple[str, float]]):
        rows = []
        for sym, w in mw:
            seas = _seas_for(sym)
            if seas is not None:
                rows.append((sym, w, seas))
        return rows

    for month in range(1, 13):
        mi = month - 1
        elig = [sym for sym in members
                if month_year_counts.get(sym, (0,) * 12)[mi]
                >= min_member_years]
        comp, n_members, n_eligible, mweights = _composite_close(
            elig, panel, floor)
        # cell_members records HOW MANY members backed this cell — the
        # count the UI reads to tell "too few to aggregate" (1..floor-1)
        # from a true gap (0).
        cell_members.append(n_eligible)
        if comp is None:
            avg.append(float("nan")); hit.append(float("nan"))
            std.append(float("nan")); sem.append(float("nan"))
            members_per_month.append(0); years_per_month.append(0)
            quality.append(float("nan"))
            continue
        stat = compute_seasonality(comp).months[mi]
        avg.append(stat.avg_return); hit.append(stat.hit_rate)
        std.append(stat.std_return); sem.append(stat.std_err)
        members_per_month.append(n_members)
        years_per_month.append(stat.n_years)
        comp_rel = seasonal_reliability(stat.avg_return, stat.std_return)
        quality.append(
            _seasonal_quality_from_cache(
                _member_stats_for(mweights), month, comp_rel)
            if stat.avg_return == stat.avg_return else float("nan"))
        if stat.avg_return == stat.avg_return:
            any_data = True

    # Drop a row that never aggregated any month — an all-blank, fully
    # dotted row just clutters the grid. (Industries that must stay
    # visible get a lowered floor via _MIN_MEMBERS_OVERRIDES so at least
    # some months aggregate.)
    if not any_data:
        return None

    # Cumulative walk from the per-month averages (NaN months flat).
    cum, running = [], 0.0
    for v in avg:
        if v == v:
            running += v
        cum.append(running)

    return IndustrySeasonality(
        industry=industry,
        avg_returns=tuple(avg),
        hit_rates=tuple(hit),
        std_returns=tuple(std),
        std_errs=tuple(sem),
        cumulative_path=tuple(cum),
        cell_n_members=tuple(cell_members),
        seasonal_quality=tuple(quality),
        n_years=max(years_per_month) if years_per_month else 0,
        n_members=max(members_per_month) if members_per_month else 0,
        has_data=any_data,
    )


def _grid_from_rows(rows: list[IndustrySeasonality]) -> SeasonalityGrid:
    """Sort rows (populated first, then alphabetical), derive the
    per-month cross-industry baseline, and wrap into a grid.

    The baseline (which the vs-Market view subtracts) is a member-count-
    WEIGHTED mean across industries, not a plain average: a 40-member
    industry should define "the market's month" far more than a 3-member
    one. An unweighted mean lets a couple of tiny, noisy industries swing
    the baseline as much as the broad market, which inflates the
    differential and makes the vs-Market edge read noisier than it is.
    Weighting by ``n_members`` makes the baseline track the broad market
    so the residual is genuine industry-specific seasonality.
    """
    rows = sorted(rows, key=lambda r: (not r.has_data, r.industry))
    baseline: list[float] = []
    data_rows = [r for r in rows if r.has_data]
    for m in range(12):
        pairs = [(r.avg_returns[m], float(max(r.n_members, 0)))
                 for r in data_rows if r.avg_returns[m] == r.avg_returns[m]]
        wsum = sum(w for _, w in pairs)
        if pairs and wsum > 0:
            baseline.append(sum(v * w for v, w in pairs) / wsum)
        elif pairs:    # all-zero weights → fall back to a plain mean
            baseline.append(float(np.mean([v for v, _ in pairs])))
        else:
            baseline.append(float("nan"))
    return SeasonalityGrid(rows=tuple(rows), market_baseline=tuple(baseline))


def compute_industry_seasonality(
    members_by_industry: dict[str, list[str]],
    panel: dict[str, pd.DataFrame],
    min_member_years: int = 0,
) -> SeasonalityGrid:
    """Build the month × industry seasonality grid.

    Args:
        members_by_industry: ``{industry: [symbols]}`` — same grouping
            the Industries table and rotation engine use.
        panel: ``{symbol: enriched_df}``.
        min_member_years: when > 0, the "stable members only" view: each
            cell is built only from members with at least this many
            observations of THAT month, so no single-year cells leak
            through and the headline isn't inflated by thin-history
            symbols. Filtering is per-month (see :func:`_build_row`).
            0 (default) uses all usable members.

    Returns:
        A :class:`SeasonalityGrid`; rows sorted by data-availability then
        name so populated industries surface first.
    """
    rows: list[IndustrySeasonality] = []
    for industry, members in members_by_industry.items():
        if industry in ("ALL", "Unknown", ""):
            continue
        # _build_row owns the member filtering (per-month when stable),
        # so we hand it the full member list and the threshold.
        row = _build_row(industry, members, panel, min_member_years)
        if row is not None:
            rows.append(row)
    return _grid_from_rows(rows)
