"""Tests for the collapsible Dashboard watchlist panel."""
import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.ui.widgets.dashboard_tab import DashboardTab
from nimbus_v3.ui.widgets.watchlist_panel import PANEL_WIDTH, WatchlistPanel


@pytest.fixture
def panel():
    eng = StrategyComputeEngine()
    idx = pd.date_range("2024-01-01", periods=200, freq="B")
    out = {}
    for i, sym in enumerate(("AAA", "BBB", "CCC")):
        c = 100 * np.cumprod(
            1 + np.random.default_rng(i).normal(0.001, 0.015, 200))
        out[sym] = eng.enrich(pd.DataFrame({
            "Open": c, "High": c * 1.01, "Low": c * 0.99, "Close": c,
            "Volume": np.full(200, 3e6),
        }, index=idx), sym)
    return out


def test_panel_has_exactly_three_columns(qapp):    # noqa: ARG001
    """Symbol | Chg | Vol. The panel is for at-a-glance monitoring while
    looking at a chart, not analysis — depth belongs in the Constituents
    table or the Edge tab."""
    p = WatchlistPanel()
    cols = [p._table.horizontalHeaderItem(c).text()
            for c in range(p._table.columnCount())]
    assert cols == ["Symbol", "Chg", "Vol"]


def test_panel_collapsed_by_default(qapp):    # noqa: ARG001
    p = WatchlistPanel()
    assert p.collapsed is True
    assert p._body.isVisible() is False


def test_collapsed_panel_does_not_reserve_width(qapp):    # noqa: ARG001
    """A hidden-but-fixed-width widget still eats its space in the parent
    layout. Collapsed, the panel must be the spine ONLY — otherwise it goes
    on stealing 220px of chart while claiming to be closed."""
    d = DashboardTab()
    d.resize(1500, 900)
    d.show()
    qapp.processEvents()
    assert d.watchlist_panel.width() < 30       # the spine


def test_toggle_round_trips(qapp):    # noqa: ARG001
    """Expand → collapse → expand must return to the same widths. Setting
    the width on an already-hidden widget leaves the parent layout holding
    a stale hint, and the panel then refuses to shrink back."""
    d = DashboardTab()
    d.resize(1500, 900)
    d.show()
    qapp.processEvents()
    wp = d.watchlist_panel

    collapsed_w = wp.width()
    wp.set_expanded(True)
    qapp.processEvents()
    assert wp.collapsed is False
    assert wp.width() >= PANEL_WIDTH - 10

    wp.set_expanded(False)
    qapp.processEvents()
    assert wp.collapsed is True
    assert wp.width() == collapsed_w        # shrank all the way back


def test_chart_toolbar_has_four_controls(qapp):    # noqa: ARG001
    """OPT | VP | + WATCH | [icon] — all chart-level concerns, parked on the
    chart's own tab bar rather than scattered down the sidebar. The
    watchlist control is an ICON (TradingView-style), not text."""
    d = DashboardTab()
    d.show()
    qapp.processEvents()
    lay = d._chart_controls.layout()
    assert lay.count() == 4
    labels = [lay.itemAt(i).widget().text() for i in range(3)]
    assert labels == ["OPT", "VP", "+ WATCH"]
    assert d._watch_toggle.text() == ""
    assert not d._watch_toggle.icon().isNull()


def test_watchlist_icon_repaints_on_state_change(qapp):    # noqa: ARG001
    """The icon is a painted pixmap, so it does NOT inherit the QSS
    :checked colour the way text does — without an explicit repaint the
    button's ON state would be invisible."""
    d = DashboardTab()
    d.show()
    qapp.processEvents()
    before = d._watch_toggle.icon().pixmap(16, 16).toImage()
    d._watch_toggle.setChecked(True)
    qapp.processEvents()
    after = d._watch_toggle.icon().pixmap(16, 16).toImage()
    assert before != after


def test_watchlist_button_drives_the_panel(qapp):    # noqa: ARG001
    """The panel has NO handle of its own — an edge sliver was tried and was
    effectively invisible against the dark theme. The toolbar button is the
    single affordance."""
    d = DashboardTab()
    d.resize(1500, 900)
    d.show()
    qapp.processEvents()

    assert d.watchlist_panel.collapsed is True
    d._watch_toggle.setChecked(True)
    qapp.processEvents()
    assert d.watchlist_panel.collapsed is False
    d._watch_toggle.setChecked(False)
    qapp.processEvents()
    assert d.watchlist_panel.collapsed is True


def test_add_to_watchlist_button_emits_charted_symbol(qapp):   # noqa: ARG001
    d = DashboardTab()
    got = []
    d.add_to_watchlist.connect(got.append)
    d._symbol = "LUPIN"
    d._on_add_to_watchlist()
    assert got == ["LUPIN"]


def test_options_overlay_toggle_readable(qapp):    # noqa: ARG001
    """MainWindow polls this before loading a symbol — OFF means skip the
    options fetch entirely."""
    d = DashboardTab()
    assert d.options_overlay_enabled() is False
    d._options_toggle.setChecked(True)
    assert d.options_overlay_enabled() is True


def test_panel_tracks_the_chart_height(qapp):    # noqa: ARG001
    """The panel shares the splitter's TOP pane with the chart, so when the
    bottom tables expand it must shrink WITH the chart — staying exactly
    chart-height rather than running past the tables."""
    d = DashboardTab()
    d.resize(1500, 900)
    d.show()
    qapp.processEvents()
    wp = d.watchlist_panel
    wp.set_expanded(True)       # expand it so it has a height to compare
    qapp.processEvents()

    assert abs(wp.height() - d._top_tabs.height()) <= 2

    d._toggle_tables()          # open the bottom tables
    qapp.processEvents()
    assert abs(wp.height() - d._top_tabs.height()) <= 2

    d._toggle_tables()          # close them again
    qapp.processEvents()
    assert abs(wp.height() - d._top_tabs.height()) <= 2


def test_renders_symbols_with_chg_and_vol(qapp, panel):    # noqa: ARG001
    p = WatchlistPanel()
    p.set_data(list(panel), panel)
    assert p._table.rowCount() == 3
    for r in range(3):
        assert p._table.item(r, 0).text() in panel
        assert p._table.item(r, 1).text() != ""     # Chg rendered
        assert p._table.item(r, 2).text() != ""     # Vol rendered


def test_hover_delete_removes_the_hovered_row(qapp, panel):    # noqa: ARG001
    """TradingView-style: a ✕ follows the mouse down the rows and removes
    the row it is sitting on. Replaces the checkbox column + DELETE SELECTED
    footer — which cost a whole column of chrome in a 250px panel and made
    the operator check a box, look away to a footer, then click."""
    from PyQt6.QtCore import QPoint

    p = WatchlistPanel()
    p.set_data(["AAA", "BBB", "CCC"], panel)
    p.set_expanded(True)
    p.resize(260, 300)
    p.show()
    qapp.processEvents()

    got = []
    p.remove_requested.connect(got.append)

    rect = p._table.visualItemRect(p._table.item(1, 0))
    p._place_delete_button(QPoint(10, rect.y() + rect.height() // 2))
    assert p._del_btn.isVisible()

    p._on_hover_delete()
    assert got == [["BBB"]]         # only the hovered row


def test_hover_delete_hides_off_rows(qapp, panel):    # noqa: ARG001
    """Below the last row there is nothing to delete — the button must not
    linger there offering to remove a row that isn't under the cursor."""
    from PyQt6.QtCore import QPoint

    p = WatchlistPanel()
    p.set_data(["AAA"], panel)
    p.set_expanded(True)
    p.resize(260, 300)
    p.show()
    qapp.processEvents()

    p._place_delete_button(QPoint(10, 9999))     # far below any row
    assert p._del_btn.isVisible() is False
    assert p._hover_row == -1


def test_no_checkbox_column(qapp, panel):    # noqa: ARG001
    """The checkbox is gone — it was eating width that Symbol and Vol needed
    (both were truncating to an ellipsis)."""
    p = WatchlistPanel()
    p.set_data(["AAA"], panel)
    # Nothing sets a check state, so nothing renders.
    from PyQt6.QtCore import Qt as _Qt
    assert p._table.item(0, 0).checkState() == _Qt.CheckState.Unchecked
    assert not hasattr(p, "_delete_btn")        # no DELETE SELECTED footer


def test_columns_wide_enough_for_real_content(qapp, panel):    # noqa: ARG001
    """Long NSE tickers (DATAPATTNS, HINDUNILVR) and a 3-char Vol ('3.01x')
    must fit without an ellipsis."""
    p = WatchlistPanel()
    p.set_data(["DATAPATTNS"], panel)
    fm = p._table.fontMetrics()
    need = fm.horizontalAdvance("DATAPATTNS")
    assert p._table.columnWidth(0) > need + 10
    assert p._table.columnWidth(2) > fm.horizontalAdvance("3.01x") + 10


def test_double_click_activates_symbol(qapp, panel):    # noqa: ARG001
    p = WatchlistPanel()
    p.set_data(["AAA", "BBB"], panel)
    got = []
    p.symbol_activated.connect(got.append)
    p._on_double_click(1, 0)
    assert got == ["BBB"]


def test_missing_panel_data_renders_em_dashes(qapp):    # noqa: ARG001
    """A watchlisted symbol absent from the panel must render, not crash —
    the watchlist is persisted and can outlive a symbol's data."""
    p = WatchlistPanel()
    p.set_data(["GHOST"], {})
    assert p._table.rowCount() == 1
    assert p._table.item(0, 0).text() == "GHOST"
    assert p._table.item(0, 1).text() == "—"
