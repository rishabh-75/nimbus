#!/usr/bin/env python3
"""
scripts/run_us_overnight_study.py — US Overnight Impact on Indian Markets

Tests whether US market data (S&P 500, VIX) adds predictive power
beyond India VIX for NIMBUS MR/ride entries.

The blind spot: Indian markets close 3:30 PM IST. US opens 9:30 PM IST.
18-hour gap where US events happen but India VIX can't update.

HYPOTHESES:
  H1: Overnight S&P move predicts India's next-day gap and direction
  H2: US VIX level/change adds signal beyond India VIX alone
  H3: Filtering MR entries on US overnight move improves Sharpe
  H4: US market crash overnight → India opens into panic → best MR entries?

Data: S&P 500, US VIX (^GSPC, ^VIX), NIFTY 50, India VIX (^INDIAVIX)
Period: 7 years daily

Usage:
    python3 scripts/run_us_overnight_study.py
    python3 scripts/run_us_overnight_study.py --years 10
"""
import argparse, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("us_overnight")


def fetch(ticker, years=7):
    """Fetch daily OHLCV from yfinance."""
    import yfinance as yf
    try:
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", ticker, exc)
        return pd.DataFrame()


def sharpe(returns, ann=252):
    """Annualized Sharpe ratio."""
    if len(returns) < 5:
        return 0
    m = np.nanmean(returns)
    s = np.nanstd(returns, ddof=1)
    return (m / s * np.sqrt(ann)) if s > 0 else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--years", type=int, default=7)
    args = parser.parse_args()

    print(f"\n{'='*72}")
    print(f"  US OVERNIGHT IMPACT ON INDIAN MARKETS")
    print(f"  Period: {args.years} years")
    print(f"{'='*72}")

    # ══════════════════════════════════════════════════════════
    # SECTION 1: FETCH DATA
    # ══════════════════════════════════════════════════════════
    print(f"\n[1/8] Fetching data...")

    sp500 = fetch("^GSPC", args.years)
    us_vix = fetch("^VIX", args.years)
    nifty = fetch("^NSEI", args.years)
    india_vix = fetch("^INDIAVIX", args.years)

    for name, df in [("S&P 500", sp500), ("US VIX", us_vix),
                     ("NIFTY", nifty), ("India VIX", india_vix)]:
        if df.empty:
            print(f"  ✗ {name}: FAILED")
        else:
            print(f"  ✓ {name}: {len(df)} bars ({df.index[0].date()} to {df.index[-1].date()})")

    if sp500.empty or nifty.empty:
        print("\n  FATAL: Missing S&P 500 or NIFTY data. Cannot proceed.")
        return

    # ══════════════════════════════════════════════════════════
    # SECTION 2: BUILD ALIGNED DATASET
    # ══════════════════════════════════════════════════════════
    print(f"\n[2/8] Building aligned dataset...")

    # S&P overnight return = S&P close (US day T) to next India open (day T+1)
    # Proxy: S&P daily return on day T → India daily return on next trading day
    sp_ret = sp500["Close"].pct_change(fill_method=None).dropna() * 100
    sp_ret.name = "sp_ret"

    nifty_ret = nifty["Close"].pct_change(fill_method=None).dropna() * 100
    nifty_ret.name = "nifty_ret"

    # India gap = Open vs previous Close
    nifty_gap = ((nifty["Open"] - nifty["Close"].shift(1)) / nifty["Close"].shift(1) * 100).dropna()
    nifty_gap.name = "nifty_gap"

    # India intraday = Close vs Open (same day)
    nifty_intra = ((nifty["Close"] - nifty["Open"]) / nifty["Open"] * 100).dropna()
    nifty_intra.name = "nifty_intra"

    # Align: for each India trading day, find the most recent US trading day BEFORE it
    # India trades Mon-Fri 9:15-15:30 IST. US trades Mon-Fri 21:00-04:00 IST (prev night).
    # So India day T is influenced by US day T-1 (for Mon-Thu) or US day T-1,T-2,T-3 (for Mon after weekend)

    aligned = []
    sp_dates = sp_ret.index.date
    nifty_dates = nifty_ret.index

    for i, nifty_date in enumerate(nifty_dates):
        nd = nifty_date.date() if hasattr(nifty_date, "date") else nifty_date
        # Find most recent US trading day strictly before this India date
        mask = sp_dates < nd
        if not mask.any():
            continue
        us_idx = np.where(mask)[0][-1]
        us_date = sp_ret.index[us_idx]

        row = {
            "india_date": nifty_date,
            "us_date": us_date,
            "gap_days": (nd - us_date.date()).days if hasattr(us_date, "date") else 0,
            "sp_ret": sp_ret.iloc[us_idx],
            "nifty_ret": nifty_ret.iloc[i],
            "nifty_gap": nifty_gap.iloc[i] if nifty_date in nifty_gap.index else np.nan,
            "nifty_intra": nifty_intra.iloc[i] if nifty_date in nifty_intra.index else np.nan,
        }

        # US VIX on that day
        if not us_vix.empty:
            vix_mask = us_vix.index.date == us_date.date() if hasattr(us_date, "date") else None
            if vix_mask is not None and vix_mask.any():
                row["us_vix"] = float(us_vix.loc[vix_mask, "Close"].iloc[-1])
                # US VIX change
                if us_idx > 0:
                    prev_vix_date = sp_ret.index[us_idx - 1]
                    prev_mask = us_vix.index.date == prev_vix_date.date()
                    if prev_mask.any():
                        row["us_vix_chg"] = row["us_vix"] - float(us_vix.loc[prev_mask, "Close"].iloc[-1])

        # India VIX on India date
        if not india_vix.empty:
            iv_mask = india_vix.index.date == nd
            if iv_mask.any():
                row["india_vix"] = float(india_vix.loc[iv_mask, "Close"].iloc[-1])

        aligned.append(row)

    df = pd.DataFrame(aligned).dropna(subset=["sp_ret", "nifty_ret"])
    print(f"  Aligned rows: {len(df)}")
    print(f"  Date range: {df['india_date'].iloc[0].date()} to {df['india_date'].iloc[-1].date()}")

    # ══════════════════════════════════════════════════════════
    # SECTION 3: H1 — OVERNIGHT S&P → INDIA GAP
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [3/8] H1: OVERNIGHT S&P → INDIA NEXT-DAY GAP")
    print(f"{'='*72}")

    valid = df.dropna(subset=["nifty_gap"])
    corr_gap = valid["sp_ret"].corr(valid["nifty_gap"])
    corr_full = valid["sp_ret"].corr(valid["nifty_ret"])
    corr_intra = valid.dropna(subset=["nifty_intra"])["sp_ret"].corr(
        valid.dropna(subset=["nifty_intra"])["nifty_intra"])

    print(f"\n  Correlation (S&P daily → India next day):")
    print(f"    S&P ret → India GAP (open vs prev close):  r = {corr_gap:.3f}")
    print(f"    S&P ret → India FULL DAY return:           r = {corr_full:.3f}")
    print(f"    S&P ret → India INTRADAY (close vs open):  r = {corr_intra:.3f}")
    print(f"\n  Interpretation:")
    print(f"    Gap correlation {corr_gap:.3f} = {'STRONG' if abs(corr_gap) > 0.4 else 'MODERATE' if abs(corr_gap) > 0.2 else 'WEAK'}")
    print(f"    Intraday {corr_intra:.3f} = US impact {'persists' if corr_intra > 0.1 else 'fades'} after open")

    # Bucketed analysis
    print(f"\n  S&P overnight move → India next-day response:")
    print(f"  {'S&P Move':>15s}  {'N':>5s}  {'Avg Gap':>8s}  {'Avg Full':>8s}  {'Avg Intra':>9s}  {'Gap>0%':>7s}")
    for lo, hi, label in [(-99, -2, "Crash (<-2%)"), (-2, -1, "Drop (-2/-1%)"),
                           (-1, -0.5, "Dip (-1/-0.5%)"), (-0.5, 0.5, "Flat (±0.5%)"),
                           (0.5, 1, "Up (+0.5/1%)"), (1, 2, "Rally (+1/2%)"),
                           (2, 99, "Surge (>+2%)")]:
        s = valid[(valid["sp_ret"] >= lo) & (valid["sp_ret"] < hi)]
        if len(s) >= 5:
            g = s["nifty_gap"].mean()
            f = s["nifty_ret"].mean()
            intra = s["nifty_intra"].dropna().mean()
            pct_pos = (s["nifty_gap"] > 0).mean() * 100
            print(f"  {label:>15s}  {len(s):5d}  {g:+7.3f}%  {f:+7.3f}%  {intra:+8.3f}%  {pct_pos:6.1f}%")

    # ══════════════════════════════════════════════════════════
    # SECTION 4: H2 — US VIX vs INDIA VIX
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [4/8] H2: US VIX vs INDIA VIX RELATIONSHIP")
    print(f"{'='*72}")

    both_vix = df.dropna(subset=["us_vix", "india_vix"])
    if len(both_vix) > 50:
        corr_vix = both_vix["us_vix"].corr(both_vix["india_vix"])
        print(f"\n  US VIX vs India VIX correlation: r = {corr_vix:.3f}")
        print(f"  US VIX mean: {both_vix['us_vix'].mean():.1f}  India VIX mean: {both_vix['india_vix'].mean():.1f}")
        print(f"  US VIX std:  {both_vix['us_vix'].std():.1f}  India VIX std:  {both_vix['india_vix'].std():.1f}")

        # Does US VIX spike predict India VIX spike next day?
        us_vix_chg = both_vix["us_vix_chg"].dropna() if "us_vix_chg" in both_vix else pd.Series()
        if len(us_vix_chg) > 50:
            # Compute India VIX change
            iv = india_vix["Close"].pct_change(fill_method=None).dropna() * 100
            iv_aligned = []
            for _, row in both_vix.iterrows():
                nd = row["india_date"]
                if nd in iv.index:
                    iv_aligned.append(iv.loc[nd])
                else:
                    iv_aligned.append(np.nan)
            both_vix = both_vix.copy()
            both_vix["india_vix_chg"] = iv_aligned
            bv = both_vix.dropna(subset=["us_vix_chg", "india_vix_chg"])
            if len(bv) > 50:
                corr_chg = bv["us_vix_chg"].corr(bv["india_vix_chg"])
                print(f"  US VIX daily change → India VIX daily change: r = {corr_chg:.3f}")

        # Regime comparison
        print(f"\n  US VIX regime → India VIX regime alignment:")
        print(f"  {'US VIX':>12s}  {'N':>5s}  {'India VIX avg':>14s}  {'India PANIC%':>13s}")
        for lo, hi, label in [(0, 15, "<15 (calm)"), (15, 20, "15-20 (normal)"),
                               (20, 30, "20-30 (elevated)"), (30, 99, ">30 (panic)")]:
            s = both_vix[(both_vix["us_vix"] >= lo) & (both_vix["us_vix"] < hi)]
            if len(s) >= 10:
                iv_avg = s["india_vix"].mean()
                panic_pct = (s["india_vix"] > 22).mean() * 100
                print(f"  {label:>12s}  {len(s):5d}  {iv_avg:13.1f}  {panic_pct:12.1f}%")
    else:
        print(f"\n  Insufficient VIX data ({len(both_vix)} rows)")

    # ══════════════════════════════════════════════════════════
    # SECTION 5: H3 — US OVERNIGHT AS MR FILTER
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [5/8] H3: US OVERNIGHT AS MR ENTRY FILTER")
    print(f"{'='*72}")

    # Simulate: if you had an MR entry signal at India close on day T-1,
    # would filtering on overnight S&P improve outcomes?
    # Proxy: India's daily return on day T, conditioned on S&P on day T-1

    # Classify India VIX regime
    df_vix = df.dropna(subset=["india_vix"]).copy()
    df_vix["vix_regime"] = "UNKNOWN"
    df_vix.loc[df_vix["india_vix"] > 22, "vix_regime"] = "PANIC"
    df_vix.loc[(df_vix["india_vix"] >= 18) & (df_vix["india_vix"] <= 22), "vix_regime"] = "ELEVATED"
    df_vix.loc[(df_vix["india_vix"] >= 13) & (df_vix["india_vix"] < 18), "vix_regime"] = "NORMAL"
    df_vix.loc[df_vix["india_vix"] < 13, "vix_regime"] = "LOW"

    # MR proxy: days when India was down (negative return = mean reversion opportunity)
    # Forward return: India's return on day T+1 after signal on day T
    df_vix["fwd_1d"] = df_vix["nifty_ret"].shift(-1)
    df_vix["fwd_5d"] = df_vix["nifty_ret"].rolling(5).sum().shift(-5)

    print(f"\n  MR filter test: skip entry if US overnight < threshold")
    print(f"  (Simulates: had MR signal yesterday, US dropped overnight, should I skip?)")
    print(f"\n  {'Filter':>25s}  {'N':>5s}  {'Avg 1d':>7s}  {'Avg 5d':>7s}  {'Win 1d':>7s}  {'Sh 1d':>6s}")

    for threshold, label in [(None, "No filter (baseline)"),
                              (-2.0, "Skip if S&P < -2%"),
                              (-1.5, "Skip if S&P < -1.5%"),
                              (-1.0, "Skip if S&P < -1%"),
                              (-0.5, "Skip if S&P < -0.5%")]:
        if threshold is None:
            s = df_vix
        else:
            s = df_vix[df_vix["sp_ret"] >= threshold]
        v = s["fwd_1d"].dropna()
        v5 = s["fwd_5d"].dropna()
        if len(v) >= 20:
            print(f"  {label:>25s}  {len(v):5d}  {v.mean():+6.3f}%  {v5.mean():+6.3f}%  "
                  f"{(v>0).mean()*100:6.1f}%  {sharpe(v.values):5.2f}")

    # Inverse: ONLY enter when US dropped (contrarian)
    print(f"\n  Contrarian: ONLY enter when US dropped overnight")
    print(f"  {'Filter':>25s}  {'N':>5s}  {'Avg 1d':>7s}  {'Win 1d':>7s}  {'Sh 1d':>6s}")
    for threshold, label in [(-0.5, "Enter if S&P < -0.5%"),
                              (-1.0, "Enter if S&P < -1%"),
                              (-1.5, "Enter if S&P < -1.5%"),
                              (-2.0, "Enter if S&P < -2%")]:
        s = df_vix[df_vix["sp_ret"] < threshold]
        v = s["fwd_1d"].dropna()
        if len(v) >= 10:
            print(f"  {label:>25s}  {len(v):5d}  {v.mean():+6.3f}%  "
                  f"{(v>0).mean()*100:6.1f}%  {sharpe(v.values):5.2f}")

    # ══════════════════════════════════════════════════════════
    # SECTION 6: H3 CROSS — US OVERNIGHT × INDIA VIX REGIME
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [6/8] H3 CROSS: US OVERNIGHT × INDIA VIX REGIME")
    print(f"{'='*72}")

    print(f"\n  India next-day return by US overnight × India VIX regime:")
    print(f"  {'US Overnight':>15s}  {'VIX':>10s}  {'N':>5s}  {'Avg 1d':>7s}  {'Win 1d':>7s}  {'Sh':>5s}")

    for sp_lo, sp_hi, sp_label in [(-99, -1, "S&P < -1%"), (-1, 0, "S&P -1/0%"),
                                     (0, 1, "S&P 0/+1%"), (1, 99, "S&P > +1%")]:
        for vr in ["PANIC", "ELEVATED", "NORMAL", "LOW"]:
            s = df_vix[(df_vix["sp_ret"] >= sp_lo) & (df_vix["sp_ret"] < sp_hi)
                       & (df_vix["vix_regime"] == vr)]
            v = s["fwd_1d"].dropna()
            if len(v) >= 10:
                print(f"  {sp_label:>15s}  {vr:>10s}  {len(v):5d}  {v.mean():+6.3f}%  "
                      f"{(v>0).mean()*100:6.1f}%  {sharpe(v.values):4.2f}")

    # ══════════════════════════════════════════════════════════
    # SECTION 7: H4 — US CRASH → INDIA PANIC ENTRIES
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [7/8] H4: US CRASH OVERNIGHT → INDIA PANIC MR ENTRIES")
    print(f"{'='*72}")

    # Best MR pocket: India VIX PANIC. Does US crash amplify or dilute it?
    panic = df_vix[df_vix["vix_regime"] == "PANIC"].copy()
    if len(panic) >= 10:
        print(f"\n  PANIC days: {len(panic)}")
        print(f"\n  US overnight move on India PANIC days:")
        print(f"  {'US Move':>15s}  {'N':>5s}  {'India Avg 1d':>13s}  {'Win':>5s}  {'India Avg 5d':>13s}")

        for sp_lo, sp_hi, label in [(-99, -2, "US crash <-2%"),
                                     (-2, -1, "US drop -2/-1%"),
                                     (-1, 0, "US down 0/-1%"),
                                     (0, 99, "US flat/up")]:
            s = panic[(panic["sp_ret"] >= sp_lo) & (panic["sp_ret"] < sp_hi)]
            v1 = s["fwd_1d"].dropna()
            v5 = s["fwd_5d"].dropna()
            if len(v1) >= 3:
                print(f"  {label:>15s}  {len(v1):5d}  {v1.mean():+12.3f}%  {(v1>0).mean()*100:4.1f}%  "
                      f"{v5.mean():+12.3f}%" if len(v5) >= 3 else f"  {label:>15s}  {len(v1):5d}  {v1.mean():+12.3f}%  {(v1>0).mean()*100:4.1f}%  N/A")
    else:
        print(f"\n  Only {len(panic)} PANIC days — insufficient for analysis")

    # ══════════════════════════════════════════════════════════
    # SECTION 8: INCREMENTAL VALUE TEST
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  [8/8] INCREMENTAL VALUE: US DATA vs INDIA VIX ALONE")
    print(f"{'='*72}")

    # Linear regression: India fwd_1d = α + β₁·India_VIX + β₂·SP_ret + ε
    # Does β₂ add significant predictive power?
    reg_df = df_vix.dropna(subset=["india_vix", "sp_ret", "fwd_1d"]).copy()

    if len(reg_df) > 100:
        from numpy.linalg import lstsq

        y = reg_df["fwd_1d"].values
        X1 = np.column_stack([reg_df["india_vix"].values, np.ones(len(reg_df))])
        X2 = np.column_stack([reg_df["india_vix"].values, reg_df["sp_ret"].values, np.ones(len(reg_df))])

        beta1, _, _, _ = lstsq(X1, y, rcond=None)
        beta2, _, _, _ = lstsq(X2, y, rcond=None)

        resid1 = y - X1 @ beta1
        resid2 = y - X2 @ beta2
        r2_vix_only = 1 - np.sum(resid1**2) / np.sum((y - y.mean())**2)
        r2_combined = 1 - np.sum(resid2**2) / np.sum((y - y.mean())**2)
        r2_lift = r2_combined - r2_vix_only

        print(f"\n  Regression: India fwd_1d = f(predictors)")
        print(f"    Model 1 (India VIX only):     R² = {r2_vix_only:.4f}")
        print(f"    Model 2 (India VIX + S&P):    R² = {r2_combined:.4f}")
        print(f"    Incremental R² from S&P:      {r2_lift:.4f}")
        print(f"\n    India VIX coef:  {beta2[0]:.4f} (per VIX point)")
        print(f"    S&P ret coef:    {beta2[1]:.4f} (per % S&P move)")

        # Practical test: does US filter improve a simple MR strategy?
        # MR proxy: enter when India VIX > 18 (ELEVATED+PANIC), measure fwd_1d
        mr_proxy = reg_df[reg_df["india_vix"] >= 18].copy()
        if len(mr_proxy) >= 30:
            base_sh = sharpe(mr_proxy["fwd_1d"].values)
            # Filter: skip when S&P < -1.5% (overnight crash → gap down risk)
            filtered = mr_proxy[mr_proxy["sp_ret"] >= -1.5]
            filt_sh = sharpe(filtered["fwd_1d"].values)
            # Contrarian: only enter when S&P < -1% (US panic → India overshoots)
            contra = mr_proxy[mr_proxy["sp_ret"] < -1]
            contra_sh = sharpe(contra["fwd_1d"].values) if len(contra) >= 10 else 0

            print(f"\n  Practical MR test (entry when India VIX ≥ 18):")
            print(f"    Baseline:              N={len(mr_proxy):4d}  Avg={mr_proxy['fwd_1d'].mean():+.3f}%  Sh={base_sh:.2f}")
            print(f"    Skip S&P < -1.5%:      N={len(filtered):4d}  Avg={filtered['fwd_1d'].mean():+.3f}%  Sh={filt_sh:.2f}")
            if len(contra) >= 10:
                print(f"    Only S&P < -1%:        N={len(contra):4d}  Avg={contra['fwd_1d'].mean():+.3f}%  Sh={contra_sh:.2f}")

    # ══════════════════════════════════════════════════════════
    # CONCLUSION
    # ══════════════════════════════════════════════════════════
    print(f"\n{'='*72}")
    print(f"  CONCLUSION")
    print(f"{'='*72}")

    print(f"\n  H1 (S&P → India gap): r = {corr_gap:.3f}")
    if abs(corr_gap) > 0.4:
        print(f"      STRONG — US overnight move reliably predicts India's gap")
    elif abs(corr_gap) > 0.2:
        print(f"      MODERATE — US has signal but India VIX captures most of it")
    else:
        print(f"      WEAK — US overnight adds little beyond noise")

    if len(reg_df) > 100:
        print(f"\n  H2 (US VIX adds value): incremental R² = {r2_lift:.4f}")
        if r2_lift > 0.01:
            print(f"      YES — US VIX adds meaningful prediction beyond India VIX")
        else:
            print(f"      NO — India VIX already captures the signal")

    print(f"\n  H3 (US filter improves MR):")
    if len(mr_proxy) >= 30:
        delta = filt_sh - base_sh
        if delta > 0.1:
            print(f"      YES — filtering on S&P improves Sharpe by {delta:.2f}")
            print(f"      Implement: skip MR entry if US overnight < -1.5%")
        elif delta > -0.1:
            print(f"      MARGINAL — Sharpe delta {delta:+.2f}, not worth the complexity")
        else:
            print(f"      NO — filtering hurts (removes best panic entries)")
            print(f"      US crash overnight → India gap down → better MR entries, don't skip")

    print(f"\n  Recommendation:")
    if abs(corr_gap) > 0.4 and r2_lift > 0.01:
        print(f"      ✓ WORTH IMPLEMENTING — US overnight is a meaningful signal")
        print(f"      Add S&P overnight change as a conviction factor (+1/-1 pts)")
    else:
        print(f"      ✗ NOT WORTH IT — India VIX already captures the US signal")
        print(f"      The 18-hour gap concern is real but India VIX at open absorbs it")
        print(f"      Adding US data adds complexity without meaningful Sharpe improvement")

    print(f"\n{'='*72}\n")


if __name__ == "__main__":
    main()
