#!/usr/bin/env python3
"""
scripts/run_strategy_correlation_study.py — Are MR and Ride the same alpha?

CONTEXT:
  Per-fold breakdown shows MR and Ride performing similarly across all 5 folds:
    fold=2  MR: 84.2%/+2.51%   Ride: 84.0%/+2.20%   ← both excellent
    fold=3  MR: 73.7%/+2.10%   Ride: 72.4%/+1.60%   ← both good
    fold=4  MR: 80.5%/+2.63%   Ride: 78.6%/+2.45%   ← both excellent
    fold=5  MR: 60.9%/-0.73%   Ride: 60.9%/+0.25%   ← both broken

  The two strategies have completely different entry filters (mean reversion
  vs momentum continuation) but their fold-level aggregates move together.
  This study asks the deeper question: do they win and lose on the SAME WEEKS,
  or do their wins/losses just happen to balance to similar averages?

HYPOTHESIS:
  H1 (same alpha):  MR and Ride weekly PnLs are highly correlated (>0.6).
                    They're both proxies for "directional alpha is paying out."
                    Position sizing across both is fake diversification.
  H2 (real diversification):  Weekly PnLs are independent (<0.3). They capture
                              different conditions and partially offset.
  H3 (in between):  Correlation 0.3-0.6. Some shared alpha, some independence.

DESIGN — uses ONLY wf_oos_trades.csv columns:
  1. Group all trades by week (Monday start) and tier
  2. Compute mean weekly PnL per strategy
  3. Compute Pearson correlation overall and per fold
  4. Check sign-agreement: how often are both strategies on the same side
  5. Print fold-5 weekly comparison (the interesting case)
  6. Verdict block with decision rule

OUTPUT:
  Plain text, one screen, makes the answer obvious.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd


CSV_PATH = "data/backtest_results/wf_oos_trades.csv"


def header(text: str, char: str = "="):
    print("\n" + char * 78)
    print(f"  {text}")
    print(char * 78)


def section(text: str):
    print("\n" + "─" * 78)
    print(f"  {text}")
    print("─" * 78)


def weekly_aggregate(df: pd.DataFrame) -> pd.DataFrame:
    """
    Group trades by week-start and tier. Returns a DataFrame indexed by week
    with columns mr_pnl, ride_pnl, mr_n, ride_n.
    """
    d = df.copy()
    d["week"] = d["entry_date"].dt.to_period("W").apply(lambda r: r.start_time)

    grouped = d.groupby(["week", "tier"]).agg(
        mean_pnl=("pnl_pct", "mean"),
        n=("pnl_pct", "size"),
    ).reset_index()

    pivot = grouped.pivot(index="week", columns="tier", values="mean_pnl")
    n_pivot = grouped.pivot(index="week", columns="tier", values="n")

    out = pd.DataFrame(index=pivot.index)
    out["mr_pnl"] = pivot.get("PRIMARY")
    out["ride_pnl"] = pivot.get("SECONDARY")
    out["mr_n"] = n_pivot.get("PRIMARY")
    out["ride_n"] = n_pivot.get("SECONDARY")

    # Drop weeks where either strategy has no trades — can't correlate nothing
    return out.dropna(subset=["mr_pnl", "ride_pnl"])


def correlation_stats(weekly: pd.DataFrame) -> dict:
    """Pearson + sign-agreement + magnitude correlation."""
    if len(weekly) < 5:
        return {"n_weeks": len(weekly), "pearson": np.nan,
                "sign_agreement": np.nan, "spearman": np.nan}

    pearson = weekly[["mr_pnl", "ride_pnl"]].corr().iloc[0, 1]
    spearman = weekly[["mr_pnl", "ride_pnl"]].corr(method="spearman").iloc[0, 1]

    # Sign agreement: % of weeks where both are positive OR both negative
    same_sign = ((weekly["mr_pnl"] > 0) == (weekly["ride_pnl"] > 0)).sum()
    sign_agreement = same_sign / len(weekly) * 100

    return {
        "n_weeks": len(weekly),
        "pearson": float(pearson),
        "spearman": float(spearman),
        "sign_agreement": float(sign_agreement),
    }


def per_fold_correlation(df: pd.DataFrame):
    """Correlation per fold."""
    print(f"\n  {'Fold':<7s}  {'Weeks':>6s}  {'Pearson':>9s}  {'Spearman':>9s}  "
          f"{'Sign agreement':>16s}")
    print(f"  {'-'*7}  {'-'*6}  {'-'*9}  {'-'*9}  {'-'*16}")

    for fold in sorted(df["fold"].unique()):
        f = df[df["fold"] == fold]
        weekly = weekly_aggregate(f)
        stats = correlation_stats(weekly)
        print(f"  fold={fold}  {stats['n_weeks']:>6d}  "
              f"{stats['pearson']:>+8.2f}   "
              f"{stats['spearman']:>+8.2f}   "
              f"{stats['sign_agreement']:>14.1f}%")


def overall_correlation(df: pd.DataFrame) -> dict:
    weekly = weekly_aggregate(df)
    stats = correlation_stats(weekly)
    print(f"\n  Overall (all folds combined)")
    print(f"    Weeks compared:    {stats['n_weeks']}")
    print(f"    Pearson r:         {stats['pearson']:+.3f}")
    print(f"    Spearman ρ:        {stats['spearman']:+.3f}")
    print(f"    Sign agreement:    {stats['sign_agreement']:.1f}%")
    return stats


def fold5_weekly_table(df: pd.DataFrame):
    """Print the weekly MR vs Ride series for fold 5."""
    f5 = df[df["fold"] == 5]
    weekly = weekly_aggregate(f5)
    if weekly.empty:
        print("  No fold 5 data")
        return

    print(f"\n  {'Week':<14s}  {'MR n':>5s}  {'MR pnl':>10s}  "
          f"{'Ride n':>7s}  {'Ride pnl':>10s}  {'Both side?':>12s}")
    print(f"  {'-'*14}  {'-'*5}  {'-'*10}  {'-'*7}  {'-'*10}  {'-'*12}")

    for week, row in weekly.iterrows():
        mr_pnl = row["mr_pnl"]
        ride_pnl = row["ride_pnl"]
        same = "yes" if (mr_pnl > 0) == (ride_pnl > 0) else "NO"
        marker = "" if same == "yes" else "  ←"
        print(f"  {week.strftime('%Y-%m-%d'):<14s}  "
              f"{int(row['mr_n']):>5d}  {mr_pnl:>+9.2f}%  "
              f"{int(row['ride_n']):>7d}  {ride_pnl:>+9.2f}%  "
              f"{same:>12s}{marker}")


def trade_level_correlation(df: pd.DataFrame):
    """
    Same-day correlation: when MR and Ride both trade on the same date,
    how often do their PnLs agree in sign?
    """
    d = df.copy()
    same_day = d.groupby(["entry_date", "tier"]).agg(
        mean_pnl=("pnl_pct", "mean"),
        n=("pnl_pct", "size"),
    ).reset_index()

    pivot = same_day.pivot(index="entry_date", columns="tier", values="mean_pnl")
    pivot = pivot.dropna(subset=["PRIMARY", "SECONDARY"])

    if len(pivot) < 10:
        print(f"\n  Not enough same-day overlap ({len(pivot)} days)")
        return

    pearson = pivot[["PRIMARY", "SECONDARY"]].corr().iloc[0, 1]
    same_sign = ((pivot["PRIMARY"] > 0) == (pivot["SECONDARY"] > 0)).sum()
    sign_agreement = same_sign / len(pivot) * 100

    print(f"\n  Same-day correlation (when both strategies have entries on the same day)")
    print(f"    Days with both:     {len(pivot)}")
    print(f"    Pearson r:          {pearson:+.3f}")
    print(f"    Sign agreement:     {sign_agreement:.1f}%")


def verdict(overall_stats: dict):
    header("VERDICT")

    p = overall_stats["pearson"]
    s = overall_stats["sign_agreement"]
    print(f"\n  Pearson correlation: {p:+.3f}")
    print(f"  Sign agreement:      {s:.1f}%")
    print()

    if p > 0.6:
        print("  → SAME ALPHA (high correlation)")
        print("    MR and Ride are essentially measuring the same underlying market")
        print("    condition. Position sizing across both is FAKE diversification —")
        print("    when one fails, the other fails. Treat them as one strategy for")
        print("    risk management.")
        print()
        print("    Implications:")
        print("      1. Cap combined exposure across both strategies at single-strategy size")
        print("      2. Regime detector should show a COMBINED verdict, not per-strategy focus")
        print("      3. Don't expect Ride to 'take over' when MR fails — both will fail together")
    elif p > 0.3:
        print("  → PARTIAL CORRELATION")
        print("    MR and Ride share some underlying alpha but also have independent")
        print("    components. There's some real diversification benefit, but they")
        print("    won't fully offset each other. Treat as 1.5 strategies for sizing,")
        print("    not 2.")
        print()
        print("    Implications:")
        print("      1. Cap combined exposure at ~1.5x single-strategy size")
        print("      2. Regime detector per-strategy focus is partially valid")
        print("      3. Some weeks one will help when the other hurts")
    else:
        print("  → INDEPENDENT ALPHAS (low correlation)")
        print("    MR and Ride capture genuinely different market conditions. Real")
        print("    diversification benefit. Trade both at full size — when one")
        print("    struggles, the other often picks up the slack.")
        print()
        print("    Implications:")
        print("      1. Combined exposure can be 2x single-strategy size")
        print("      2. Regime detector per-strategy focus is fully valid")
        print("      3. The 'sit out' state should be rare since both rarely fail at once")

    print()
    print(f"  Sign agreement check: in {s:.0f}% of weeks, both strategies were on the")
    if s > 70:
        print(f"    same side (both winning or both losing). This is HIGH — confirms they're")
        print(f"    moving together in real time, not just averaging to similar fold-level results.")
    elif s > 55:
        print(f"    same side. This is moderate — they often agree but not always.")
    else:
        print(f"    same side. This is near random — they really are independent.")


def main():
    if not os.path.exists(CSV_PATH):
        print(f"ERROR: {CSV_PATH} not found")
        sys.exit(1)

    df = pd.read_csv(CSV_PATH)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    print(f"\nLoaded {len(df):,} trades from {CSV_PATH}")
    print(f"  PRIMARY (MR):    {len(df[df['tier']=='PRIMARY']):>5d}")
    print(f"  SECONDARY (Ride):{len(df[df['tier']=='SECONDARY']):>5d}")

    header("WEEKLY CORRELATION BY FOLD")
    per_fold_correlation(df)

    header("OVERALL WEEKLY CORRELATION")
    overall = overall_correlation(df)

    header("SAME-DAY TRADE CORRELATION")
    trade_level_correlation(df)

    header("FOLD 5 WEEKLY DETAIL — DO THEY MOVE TOGETHER WHEN BROKEN?")
    fold5_weekly_table(df)

    verdict(overall)


if __name__ == "__main__":
    main()
