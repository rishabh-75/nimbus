"""Tests for nimbus_v3.compute.industry_rotation."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.industry_rotation import (
    DEFAULT_LOOKBACK,
    MIN_MEMBERS,
    SMOOTH_WINDOW,
    compute_industry_rotation,
)


def _frame(start: float, daily_drift: float, n: int = 70,
           vol: float = 100000.0) -> pd.DataFrame:
    idx = pd.date_range("2025-01-01", periods=n, freq="D")
    close = start * (1 + daily_drift) ** np.arange(n)
    return pd.DataFrame(
        {"Open": close, "High": close * 1.01, "Low": close * 0.99,
         "Close": close, "Volume": np.full(n, vol)}, index=idx)


def _industry(panel, prefix, drift, n_members=5):
    syms = []
    for i in range(n_members):
        sym = f"{prefix}{i}"
        panel[sym] = _frame(100, drift)
        syms.append(sym)
    return syms


def test_empty_when_no_members():
    res = compute_industry_rotation({}, {})
    assert not res.has_data


def test_min_members_filter():
    panel = {}
    big = _industry(panel, "BIG", 0.01, n_members=MIN_MEMBERS)
    small = _industry(panel, "SML", 0.01, n_members=MIN_MEMBERS - 1)
    res = compute_industry_rotation({"Big": big, "Small": small}, panel, lookback=60)
    inds = [r.industry for r in res.industries]
    assert "Big" in inds
    assert "Small" not in inds


def test_rebased_to_zero_at_start():
    panel = {}
    mem = _industry(panel, "X", 0.01)
    res = compute_industry_rotation({"X": mem}, panel, lookback=60)
    assert res.has_data
    r = res.industries[0]
    # Smoothing (centered) shifts the very first point slightly off 0;
    # it should still START near zero, not jump.
    assert abs(r.cum_return[0]) < 2.0
    assert r.roc > 0


def test_sorted_leaders_first():
    panel = {}
    mbi = {"Strong": _industry(panel, "UP", 0.02),
           "Weak": _industry(panel, "DN", -0.01),
           "Mid": _industry(panel, "FL", 0.0)}
    res = compute_industry_rotation(mbi, panel, lookback=60)
    order = [r.industry for r in res.industries]
    assert order[0] == "Strong"
    assert order[-1] == "Weak"


def test_top_and_bottom_split():
    panel = {}
    mbi = {f"Ind{i}": _industry(panel, f"S{i}_", 0.001 * i) for i in range(-3, 4)}
    res = compute_industry_rotation(mbi, panel, lookback=60)
    top2, bot2 = res.top(2), res.bottom(2)
    assert len(top2) == 2 and len(bot2) == 2
    assert top2[0].roc >= top2[1].roc
    assert bot2[0].roc <= bot2[1].roc


def test_all_and_unknown_skipped():
    panel = {}
    real = _industry(panel, "R", 0.01)
    res = compute_industry_rotation(
        {"ALL": real, "Unknown": real, "Real": real}, panel, lookback=60)
    inds = [r.industry for r in res.industries]
    assert "ALL" not in inds
    assert "Unknown" not in inds
    assert "Real" in inds


def test_no_cliff_with_mixed_history():
    panel = {}
    mem = _industry(panel, "X", 0.005)
    g = panel[mem[0]].copy()
    g.iloc[-20:-10, g.columns.get_loc("Close")] = np.nan
    panel[mem[0]] = g
    res = compute_industry_rotation({"X": mem}, panel, lookback=60)
    assert res.has_data
    jumps = np.abs(np.diff(res.industries[0].cum_return))
    assert jumps.max() < 15.0


def test_smoothing_does_not_break():
    assert SMOOTH_WINDOW >= 1
    panel = {}
    rng = np.random.default_rng(0)
    syms = []
    for i in range(5):
        idx = pd.date_range("2025-01-01", periods=70, freq="D")
        close = 100 * (1 + rng.normal(0, 0.03, 70)).cumprod()
        panel[f"N{i}"] = pd.DataFrame(
            {"Open": close, "High": close, "Low": close,
             "Close": close, "Volume": np.full(70, 1e5)}, index=idx)
        syms.append(f"N{i}")
    res = compute_industry_rotation({"Noisy": syms}, panel, lookback=60)
    assert res.has_data


def test_default_constants():
    assert DEFAULT_LOOKBACK == 60
    assert MIN_MEMBERS == 5
