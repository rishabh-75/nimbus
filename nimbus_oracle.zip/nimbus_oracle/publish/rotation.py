#!/usr/bin/env python3
"""
publish/rotation.py — NSE Sector Rotation Matrix.

RS quadrant scatter plot — purely relative strength mathematics.
"IT sector is in LEADING quadrant" is a factual observation, not a recommendation.

Usage:
    python3 publish/rotation.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from publish.common import (
    nimbus_style, export_figure, add_title, add_timestamp,
    COLORS, SECTOR_COLORS,
)

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("publish_rotation")


def fetch_sector_data():
    """Fetch sector rotation data from sector_rotation module."""
    from modules.sector_rotation import fetch_sector_data as _fetch
    rows = _fetch(force=True)
    if not rows:
        logger.warning("No sector data — trying cached...")
        rows = _fetch(force=False)
    return rows


def render_rotation(rows):
    """Render the RS quadrant scatter plot."""
    if not rows:
        logger.error("No sector data available")
        return None

    with nimbus_style():
        fig, ax = plt.subplots(figsize=(10, 9))
        fig.subplots_adjust(top=0.88, bottom=0.10, left=0.12, right=0.95)

        now_str = datetime.datetime.now().strftime("%d %b %Y")
        add_title(fig, "NSE SECTOR ROTATION MATRIX",
                  f"Price-ratio RS methodology · Weighted: 50% 10D / 30% 1M / 20% 3M · {now_str}")
        add_timestamp(fig)

        # ── Quadrant backgrounds ────────────────────────────────────────
        xlim = max(abs(min(r.get("rs_10d", 0) or 0 for r in rows)),
                   abs(max(r.get("rs_10d", 0) or 0 for r in rows)), 3) * 1.3
        ylim = max(abs(min(r.get("rs_3m", 0) or 0 for r in rows)),
                   abs(max(r.get("rs_3m", 0) or 0 for r in rows)), 5) * 1.3

        ax.axhspan(0, ylim, 0, 0.5, color=COLORS["blue"], alpha=0.03, zorder=0)      # top-left: IMPROVING
        ax.axhspan(0, ylim, 0.5, 1.0, color=COLORS["emerald"], alpha=0.03, zorder=0) # top-right: LEADING
        ax.axhspan(-ylim, 0, 0, 0.5, color=COLORS["red"], alpha=0.03, zorder=0)      # bottom-left: LAGGING
        ax.axhspan(-ylim, 0, 0.5, 1.0, color=COLORS["gold"], alpha=0.03, zorder=0)   # bottom-right: WEAKENING

        # Quadrant labels (large, faint, behind data)
        label_alpha = 0.08
        ax.text(xlim * 0.7, ylim * 0.85, "LEADING", fontsize=18, fontweight=700,
                color=COLORS["emerald"], alpha=label_alpha, ha="center", va="center", zorder=0)
        ax.text(-xlim * 0.7, ylim * 0.85, "IMPROVING", fontsize=18, fontweight=700,
                color=COLORS["blue"], alpha=label_alpha, ha="center", va="center", zorder=0)
        ax.text(-xlim * 0.7, -ylim * 0.85, "LAGGING", fontsize=18, fontweight=700,
                color=COLORS["red"], alpha=label_alpha, ha="center", va="center", zorder=0)
        ax.text(xlim * 0.7, -ylim * 0.85, "WEAKENING", fontsize=18, fontweight=700,
                color=COLORS["gold"], alpha=label_alpha, ha="center", va="center", zorder=0)

        # ── Zero lines ─────────────────────────────────────────────────
        ax.axhline(y=0, color=COLORS["muted"], linewidth=0.8, zorder=1)
        ax.axvline(x=0, color=COLORS["muted"], linewidth=0.8, zorder=1)

        # ── Plot sectors ───────────────────────────────────────────────
        ROTATION_COLORS = {
            "LEADING": COLORS["emerald"],
            "IMPROVING": COLORS["blue"],
            "WEAKENING": COLORS["gold"],
            "LAGGING": COLORS["red"],
        }

        for r in rows:
            x = r.get("rs_10d") or 0
            y = r.get("rs_3m") or 0
            label = r.get("name", r.get("ticker", "?"))
            rotation = r.get("rotation", "LAGGING")
            adj_score = r.get("adj_score", 0)
            color = ROTATION_COLORS.get(rotation, COLORS["muted"])

            # Size by adj_score magnitude
            size = max(80, min(250, 80 + abs(adj_score) * 15))

            ax.scatter(x, y, s=size, c=color, edgecolors=color,
                      linewidths=1.2, alpha=0.8, zorder=5)

            # Label offset to avoid overlap
            offset_x = 0.15 if x >= 0 else -0.15
            offset_y = 0.3
            ha = "left" if x >= 0 else "right"

            ax.annotate(
                f"{label}",
                (x, y), (x + offset_x, y + offset_y),
                fontsize=8, color=COLORS["white"], fontweight=500,
                ha=ha, va="bottom",
                arrowprops=dict(arrowstyle="-", color=COLORS["border"], lw=0.5),
                zorder=6,
            )

            # Score annotation for top performers
            if abs(adj_score) > 3:
                ax.text(x + offset_x, y + offset_y - 0.5, f"RS {adj_score:+.1f}",
                       fontsize=6.5, color=color, ha=ha, alpha=0.8, zorder=6)

        # ── Axis formatting ────────────────────────────────────────────
        ax.set_xlim(-xlim, xlim)
        ax.set_ylim(-ylim, ylim)
        ax.set_xlabel("10-Day RS vs Nifty50  →  (short-term momentum)", fontsize=9)
        ax.set_ylabel("3-Month RS vs Nifty50  ↑  (long-term trend)", fontsize=9)

        # ── Methodology footnote ───────────────────────────────────────
        fig.text(0.12, 0.02,
                 "RS = (sector_now / sector_N) / (bench_now / bench_N) − 1  ·  Source: NSE / yfinance",
                 fontsize=6.5, color=COLORS["dim"], style="italic")

    return fig


def main():
    parser = argparse.ArgumentParser(description="NIMBUS Sector Rotation Matrix")
    parser.add_argument("--no-export", action="store_true")
    args = parser.parse_args()

    logger.info("Fetching sector rotation data...")
    rows = fetch_sector_data()

    if not rows:
        logger.error("No sector data — cannot generate chart")
        return

    logger.info("Got %d sectors, rendering...", len(rows))
    fig = render_rotation(rows)

    if fig and not args.no_export:
        export_figure(fig, "sector_rotation")

    if fig:
        plt.close(fig)

    logger.info("Done.")


if __name__ == "__main__":
    main()
