"""Tests for TrackerStatsPanel — the rolling-lift UI over SignalTracker."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.conviction.formula import Contribution
from nimbus_v3.conviction.grade_engine import Conviction
from nimbus_v3.core.types import GradeLetter, SetupType, Sizing, Verdict
from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.tracking.tracker import SignalTracker
from nimbus_v3.ui.widgets.tracker_stats_panel import TrackerStatsPanel


_ASOF = pd.Timestamp("2024-05-15")


@dataclass
class _FakeStrategy:
    name: str = "MeanReversion"
    priority: int = 50
    production_weight: float = 1.0


def _mk_result(symbol="X", strategy_name="MeanReversion",
                 production_weight=1.0, grade=GradeLetter.A,
                 asof=_ASOF, close_price=100.0):
    return ScanResult(
        symbol=symbol, asof_date=asof,
        strategy=_FakeStrategy(
            name=strategy_name, production_weight=production_weight,
        ),
        conviction=Conviction(
            symbol=symbol, asof_date=asof, strategy_name=strategy_name,
            setup_type=SetupType.MEAN_REVERSION,
            raw_score=3.0, score=3.0 * production_weight,
            grade=grade, verdict=Verdict.TAKE, sizing=Sizing.FULL,
            contributions=(Contribution("mfi", 0.5, "neutral"),),
            production_weight=production_weight,
            override_reason=(
                "research-only strategy (production_weight=0)"
                if production_weight == 0.0 else None
            ),
        ),
        close_price=close_price,
    )


def _price_panel_with_drift(symbol: str, asof: pd.Timestamp) -> dict:
    idx = pd.bdate_range(asof - pd.Timedelta(days=10), periods=50)
    closes = 100.0 * np.exp(np.arange(len(idx)) * 0.01)   # +1% log per bar
    df = pd.DataFrame(
        {"Open": closes, "High": closes, "Low": closes,
         "Close": closes, "Volume": 1e6},
        index=idx,
    )
    return {symbol: df}


@pytest.fixture
def populated_db(tmp_path: Path) -> Path:
    """Create a tracker DB with 2 strategies × 3 signals, backfilled returns."""
    db = tmp_path / "signals.db"
    with SignalTracker(db) as t:
        panel = {}
        for i, sym in enumerate(("A", "B", "C")):
            asof = _ASOF - pd.Timedelta(days=i)
            p = _price_panel_with_drift(sym, asof)
            panel.update(p)
            close = float(p[sym].loc[p[sym].index <= asof]["Close"].iloc[-1])
            # MR signal (production).
            t.record(_mk_result(
                symbol=sym, strategy_name="MR",
                production_weight=1.0, asof=asof, close_price=close,
            ))
            # DR signal (research).
            t.record(_mk_result(
                symbol=sym, strategy_name="DrawdownReversal",
                production_weight=0.0, asof=asof, close_price=close,
            ))
        t.backfill_returns(price_panel=panel)
    return db


# ══════════════════════════════════════════════════════════════════════════════
# Construction
# ══════════════════════════════════════════════════════════════════════════════

def test_panel_disabled_without_factory(qapp) -> None:    # noqa: ARG001
    panel = TrackerStatsPanel(None)
    assert panel._refresh_button.isEnabled() is False
    assert panel._from_edit.isEnabled() is False
    assert "No tracker configured" in panel._status_label.text()


def test_panel_enabled_with_factory(qapp, populated_db: Path) -> None:    # noqa: ARG001
    factory = lambda: SignalTracker(populated_db)
    panel = TrackerStatsPanel(factory)
    assert panel._refresh_button.isEnabled() is True
    assert "Click Refresh" in panel._status_label.text()


# ══════════════════════════════════════════════════════════════════════════════
# Refresh path
# ══════════════════════════════════════════════════════════════════════════════

def test_refresh_populates_strategy_table(
    qapp, populated_db: Path,    # noqa: ARG001
) -> None:
    factory = lambda: SignalTracker(populated_db)
    panel = TrackerStatsPanel(factory)
    # Set date range wide enough to capture the fixture signals.
    from PyQt6.QtCore import QDate
    panel._from_edit.setDate(QDate(2024, 5, 1))
    panel._to_edit.setDate(QDate(2024, 5, 31))
    panel.refresh()
    # Expect 2 strategy rows — MR + DR.
    assert panel._strategy_table.rowCount() == 2
    names = {
        panel._strategy_table.item(i, 0).text()
        for i in range(panel._strategy_table.rowCount())
    }
    assert names == {"MR", "DrawdownReversal"}


def test_refresh_production_only_filter(
    qapp, populated_db: Path,    # noqa: ARG001
) -> None:
    factory = lambda: SignalTracker(populated_db)
    panel = TrackerStatsPanel(factory)
    from PyQt6.QtCore import QDate
    panel._from_edit.setDate(QDate(2024, 5, 1))
    panel._to_edit.setDate(QDate(2024, 5, 31))
    panel._prod_only_checkbox.setChecked(True)
    panel.refresh()
    # Only MR (production_weight=1.0) should appear.
    assert panel._strategy_table.rowCount() == 1
    assert panel._strategy_table.item(0, 0).text() == "MR"


def test_refresh_empty_db_shows_zero_rows(qapp, tmp_path: Path) -> None:    # noqa: ARG001
    db = tmp_path / "empty.db"
    with SignalTracker(db):
        pass   # creates empty schema
    factory = lambda: SignalTracker(db)
    panel = TrackerStatsPanel(factory)
    panel.refresh()
    assert panel._strategy_table.rowCount() == 0


# ══════════════════════════════════════════════════════════════════════════════
# Selection → regime breakdown
# ══════════════════════════════════════════════════════════════════════════════

def test_selecting_strategy_populates_grade_table(
    qapp, populated_db: Path,    # noqa: ARG001
) -> None:
    factory = lambda: SignalTracker(populated_db)
    panel = TrackerStatsPanel(factory)
    from PyQt6.QtCore import QDate
    panel._from_edit.setDate(QDate(2024, 5, 1))
    panel._to_edit.setDate(QDate(2024, 5, 31))
    panel.refresh()

    # Pick MR's row.
    target_row = None
    for i in range(panel._strategy_table.rowCount()):
        if panel._strategy_table.item(i, 0).text() == "MR":
            target_row = i
            break
    assert target_row is not None
    panel._strategy_table.selectRow(target_row)
    qapp.processEvents()

    # Grade table now populated with 1+ rows (all A in our fixtures).
    assert panel._grade_table.rowCount() >= 1
    grade_texts = {
        panel._grade_table.item(i, 0).text()
        for i in range(panel._grade_table.rowCount())
    }
    assert "A" in grade_texts


def test_selection_emits_strategy_selected_signal(
    qapp, populated_db: Path,    # noqa: ARG001
) -> None:
    factory = lambda: SignalTracker(populated_db)
    panel = TrackerStatsPanel(factory)
    from PyQt6.QtCore import QDate
    panel._from_edit.setDate(QDate(2024, 5, 1))
    panel._to_edit.setDate(QDate(2024, 5, 31))
    panel.refresh()

    captured: list[str] = []
    panel.strategy_selected.connect(captured.append)
    panel._strategy_table.selectRow(0)
    qapp.processEvents()
    assert len(captured) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Runtime factory swap
# ══════════════════════════════════════════════════════════════════════════════

def test_set_tracker_factory_enables_and_clears(
    qapp, populated_db: Path,   # noqa: ARG001
) -> None:
    panel = TrackerStatsPanel(None)
    # Initially disabled.
    assert panel._refresh_button.isEnabled() is False

    # Swap in a real factory → controls enable.
    panel.set_tracker_factory(lambda: SignalTracker(populated_db))
    assert panel._refresh_button.isEnabled() is True

    # Refresh and confirm rows.
    from PyQt6.QtCore import QDate
    panel._from_edit.setDate(QDate(2024, 5, 1))
    panel._to_edit.setDate(QDate(2024, 5, 31))
    panel.refresh()
    assert panel._strategy_table.rowCount() > 0

    # Swap back to None → table cleared, controls disabled.
    panel.set_tracker_factory(None)
    assert panel._refresh_button.isEnabled() is False
    assert panel._strategy_table.rowCount() == 0


# ══════════════════════════════════════════════════════════════════════════════
# Error handling
# ══════════════════════════════════════════════════════════════════════════════

def test_refresh_handles_tracker_error_gracefully(qapp, tmp_path: Path) -> None:   # noqa: ARG001
    """If the factory throws, the panel surfaces the error — doesn't crash."""
    bogus_path = tmp_path / "does_not_exist" / "fake.db"

    def failing_factory():
        raise RuntimeError("disk on fire")

    panel = TrackerStatsPanel(failing_factory)
    import nimbus_v3.ui.widgets.tracker_stats_panel as mod
    captured: list = []
    orig = mod.QMessageBox.critical
    mod.QMessageBox.critical = lambda *a, **kw: captured.append((a, kw))
    try:
        panel.refresh()
    finally:
        mod.QMessageBox.critical = orig
    assert "disk on fire" in panel._status_label.text()
    assert len(captured) == 1
