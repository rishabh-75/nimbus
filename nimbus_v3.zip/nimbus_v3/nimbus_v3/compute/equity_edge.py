"""Momentum-implied expected excess edge, derived from confluence.

This turns the Confluence read into two per-symbol numbers:

* **expected excess edge** (μ̂, in horizon-period %): an estimate of a
  symbol's return *in excess of the benchmark* over the strength horizon,
  implied by momentum confluence.
* **reward-to-risk** (μ̂ / risk): a Sharpe-like rotation rank — expected
  edge per unit of realised volatility.

**What this is NOT.** This is *not* an equity risk premium in the
valuation sense. A true ERP is a forward, cash-flow / discount-rate
quantity (dividend yield + growth − risk-free, or an implied premium from
prices and earnings). Confluence contains no valuation data — only
momentum, direction, seasonality and breadth. So the honest object here is
a *momentum-implied* expected edge, not a risk premium. The label is chosen
to match the math.

── Derivation ──────────────────────────────────────────────────────────
Confluence scores INDUSTRIES, so a symbol's edge is its industry's edge,
adjusted for where the symbol sits within its industry:

    industry_edge   = κ · RS_excess · trust
    member_shift    = κ · tilt · (member_RS − industry_RS) · trust
    μ̂(symbol)       = (industry_edge + member_shift)
                      · liquidity_gate · confirmation_gate
    reward_to_risk  = μ̂(symbol) / max(ATR%, floor)

where

* ``RS_excess`` — the industry composite's return over the horizon MINUS
  the benchmark's return over the same horizon (a real excess-return
  number, the magnitude anchor).
* ``trust`` — the confluence GATE PRODUCT (direction × seasonal × breadth
  gates), i.e. ``ConfluenceRow.confidence``. A strong-but-narrow-and-fading
  industry has high RS_excess but low trust, so its edge is shrunk toward
  zero: "the trailing outperformance is real, but we don't expect it to
  persist."
* ``κ`` (kappa) — the persistence haircut. Trailing momentum mean-reverts
  hard, so raw RS massively overstates forward return; κ (well under 1)
  shrinks it so calling the output "expected" is defensible rather than a
  naive extrapolation. This is the single biggest dial and it is what makes
  the "expected" label honest.
* ``member_shift`` — an ADDITIVE adjustment by the symbol's own strength
  relative to its industry composite, so a leader within the group is
  shifted up and a laggard down. Additive (not a multiplier on the
  industry edge) so a strong member in a WEAK industry is made *less bad*,
  not amplified downward — the member's own strength is independent
  information that should move its edge the same direction regardless of
  the industry's sign. Scaled by the same κ and trust; the tilt strength
  is kept modest because within-industry RS is noisier than the industry
  signal.
* risk denominator — the symbol's ATR% (realised short-term vol), floored
  so a freakishly-low-vol name can't blow up the ratio.
* ``liquidity_gate`` — an executability haircut ∈ [floor, 1]. An edge you
  can't trade at size is a phantom, so a thin name (low ADTV) has its edge
  shrunk toward the floor. ABSOLUTE (log-ADTV clamped between the
  Dashboard's floor/ceiling), because tradeability is a hard fact about
  rupees/day, not a ranking. Kept separate from the ATR% denominator: ATR%
  is price risk, liquidity is executability — conflating them double-counts.
* ``confirmation_gate`` — a participation haircut ∈ [floor, 1]. Because
  ``industry_edge`` is identical for every member, a member sitting still
  would otherwise inherit the full industry edge and — being low-volatility
  — rank ABOVE the names actually making the move. This discounts members
  showing no band-ride streak, no volume surge, and no short-term thrust.
  **NOT VALIDATED as a predictive signal** (see the empirical-status note in
  ``market_pulse_config``): it makes the board a more honest description of
  what is moving, but walk-forward tests showed no improvement in forward
  returns. Disable with ``EDGE_CONFIRMATION_ENABLED = False``.

All tunables live in :mod:`nimbus_v3.compute.market_pulse_config`.

The engine is stateless and returns a frozen result; it consumes the
already-computed confluence / rotation / rrg outputs plus the panel — it
recomputes none of them.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import log

import pandas as pd

from nimbus_v3.compute.confluence import ConfluenceResult
from nimbus_v3.compute.constituent_features import (
    extract_constituent_features,
)
from nimbus_v3.compute.indicators import adtv_latest
from nimbus_v3.compute.industry_rotation import (
    RotationResult,
    compute_industry_rotation,
)
from nimbus_v3.compute.market_pulse_common import (
    industry_rs_excess,
    window_return_pct,
)
from nimbus_v3.compute.market_pulse_config import (
    DEFAULT_EDGE_HORIZON,
    EDGE_ADTV_CEILING,
    EDGE_HORIZONS,
    EDGE_ADTV_FLOOR,
    EDGE_BLOWOFF_ENABLED,
    EDGE_BLOWOFF_FLOOR,
    EDGE_BLOWOFF_SPAN,
    EDGE_BLOWOFF_START,
    EDGE_CONFIRM_VOL_CAP,
    EDGE_CONFIRM_FLOOR,
    EDGE_CONFIRM_STREAK_FULL,
    EDGE_CONFIRM_THRUST_FULL,
    EDGE_CONFIRM_VOL_BASE,
    EDGE_CONFIRM_VOL_SPAN,
    EDGE_CONFIRMATION_ENABLED,
    EDGE_LIQUIDITY_FLOOR,
    EDGE_MEMBER_TILT,
    EDGE_MIN_ATR_PCT,
    EDGE_PERSISTENCE_KAPPA,
    STRENGTH_LOOKBACK,
)


@dataclass(frozen=True)
class SymbolEdge:
    """One symbol's momentum-implied edge read — fully auditable."""
    symbol: str
    industry: str
    #: Expected excess edge over the benchmark, in horizon-period % (the
    #: strength lookback window). Persistence- and trust-shrunk.
    expected_edge: float
    #: Reward-to-risk: expected_edge / ATR%. Sharpe-like rotation rank.
    reward_to_risk: float
    #: The pieces, surfaced for inspection.
    industry_rs_excess: float   # industry composite return − benchmark, %
    trust: float                # confluence gate product 0..1
    member_shift: float         # additive within-industry adjustment, %
    atr_pct: float              # risk denominator used
    adtv: float                 # avg daily traded value (₹), raw
    liquidity_gate: float       # executability haircut applied, 0..1
    chg_1d: float = float("nan")    # latest 1-bar % change
    chg_5d: float = float("nan")    # 5-bar % change
    chg_10d: float = float("nan")   # 10-bar % change
    vol_ratio: float = float("nan")  # latest volume / 20-bar mean volume
    vol_shift: float = float("nan")  # vol_ratio / industry MEDIAN vol_ratio
    above: bool = False              # body-above-band flag
    #: Body-above-upper-band on the SECONDARY 4h timeframe. Tri-state:
    #: True/False when 4h data was available, None when it was not — the
    #: renderer shows "unknown" distinctly so a data gap is never read as a
    #: real "not above". Purely a display confirmation; does not enter any
    #: score.
    above_4h: bool | None = None
    #: RS-reversion signal (DISPLAY ONLY, never scored). The per-date-demeaned
    #: own-history z-score of price / (its own trailing RS norm): how cheap
    #: this name is versus its OWN relative-strength history, relative to how
    #: cheap the whole panel is right now. Negative = "cheap for its own RS" =
    #: a reversion-long candidate. Validated out-of-sample (t≈4.1) but
    #: regime-dependent and unproven pre-2023 on a 5y sample, so it is a
    #: WATCH flag, not a score input. None when history is too short.
    rs_rev_z: float | None = None
    streak: int = 0                  # trailing body-above run length
    confirmation: float = 1.0        # member-participation haircut, 0..1


@dataclass(frozen=True)
class EdgeResult:
    """All symbols' edges, ranked by reward-to-risk descending."""
    rows: tuple[SymbolEdge, ...]
    horizon_days: int
    kappa: float

    @property
    def has_data(self) -> bool:
        return len(self.rows) > 0


@dataclass(frozen=True)
class EdgeHorizonSet:
    """The same edge computed over several horizons — one frozen result each.

    Exists so a view can offer a horizon switch without owning any of the
    computation. The engine guarantees the invariant that makes the switch
    meaningful: within each entry, the industry composite ROC and the
    benchmark return are measured over the SAME window (see
    :func:`compute_equity_edge_multi`). A consumer therefore cannot
    accidentally pair a 20-day industry return with a 5-day benchmark.

    Pure data: no behaviour beyond lookup, so it stays trivially cacheable
    and testable.
    """
    results: tuple[EdgeResult, ...]
    default_horizon: int

    @property
    def horizons(self) -> tuple[int, ...]:
        """Available horizons, ascending."""
        return tuple(sorted(r.horizon_days for r in self.results))

    def get(self, horizon: int) -> EdgeResult | None:
        """The result for ``horizon``, or None if it was not computed."""
        for r in self.results:
            if r.horizon_days == horizon:
                return r
        return None

    @property
    def default(self) -> EdgeResult | None:
        """The result at :attr:`default_horizon`, falling back to the
        shortest available so a partial set still renders."""
        r = self.get(self.default_horizon)
        if r is not None:
            return r
        return self.results[0] if self.results else None

    @property
    def has_data(self) -> bool:
        return any(r.has_data for r in self.results)


def _liquidity_gate(
    adtv: float,
    floor_adtv: float,
    ceil_adtv: float,
    gate_floor: float,
) -> float:
    """Executability haircut ∈ [gate_floor, 1] from a symbol's ADTV.

    Log-scaled between an absolute floor and ceiling (tradeability is an
    absolute fact, not a ranking): at/above the ADTV ceiling → 1.0 (no
    discount); at/below the floor → gate_floor (edge crushed). NaN ADTV is
    treated as fully thin (gate_floor) — we can't confirm it's tradeable,
    so we don't give it the benefit of the doubt.
    """
    if adtv != adtv or adtv <= 0:
        return gate_floor
    lo, hi = log(floor_adtv), log(ceil_adtv)
    x = (log(adtv) - lo) / (hi - lo) if hi > lo else 1.0
    x = max(0.0, min(1.0, x))
    return gate_floor + (1.0 - gate_floor) * x


def _confirmation_gate(
    streak: int,
    vol_ratio: float,
    chg_5d: float,
    atr_pct: float,
    *,
    floor: float = EDGE_CONFIRM_FLOOR,
    streak_full: float = EDGE_CONFIRM_STREAK_FULL,
    vol_base: float = EDGE_CONFIRM_VOL_BASE,
    vol_span: float = EDGE_CONFIRM_VOL_SPAN,
    vol_cap: float = EDGE_CONFIRM_VOL_CAP,
    thrust_full: float = EDGE_CONFIRM_THRUST_FULL,
) -> float:
    """Member-participation haircut ∈ [floor, 1].

    Asks: is this symbol ACTUALLY participating in its industry's move, or
    is it merely a member of a hot industry sitting still?

    The industry edge is identical for every member, so without this the
    within-industry ranking degenerates to ``1/ATR%`` — it promotes the
    quietest name in a hot sector. A stock that isn't moving shouldn't
    inherit the full industry edge just because its neighbours are.

    Three independent tells, combined with ``max`` because participation
    has two distinct faces and a name needs only ONE of them:

    * **streak** — sustained band-ride: the slow, orderly rider.
    * **vol_ratio** — volume surge: the fresh breakout.
    * **thrust** — 5-day move in ATR units: short-term impulse.

    A name with none of the three is not participating and is cut to
    ``floor``. NaNs contribute 0 — absence of evidence is not confirmation.

    NOT VALIDATED as a predictive signal; see the empirical status note in
    :mod:`nimbus_v3.compute.market_pulse_config`. This reorders the board to
    surface names that are actually moving; it is not demonstrated to
    improve forward returns.
    """
    s = (min(1.0, max(0.0, streak / streak_full))
         if streak and streak_full > 0 else 0.0)

    # Volume CONFIRMS only up to a point. Measured: a mild pickup
    # (1.25-1.5x) is genuinely positive (+0.13%, t=2.2), but the sign turns
    # over around 2-3x and a blowoff is strongly NEGATIVE (>=5x: -0.85%,
    # t=-5.1). Past `vol_cap` the volume is no longer evidence the name is
    # participating — it is evidence someone is distributing, and that is
    # priced by the SEPARATE blowoff penalty below. Counting it as
    # confirmation here would mean rewarding the worst cohort on the board.
    if vol_ratio == vol_ratio and vol_span > 0 and vol_ratio < vol_cap:
        v = min(1.0, max(0.0, (vol_ratio - vol_base) / vol_span))
    else:
        v = 0.0

    if (chg_5d == chg_5d and atr_pct == atr_pct
            and atr_pct > 0 and thrust_full > 0):
        t = min(1.0, max(0.0, (chg_5d / atr_pct) / thrust_full))
    else:
        t = 0.0

    return floor + (1.0 - floor) * max(s, v, t)


def _blowoff_penalty(
    vol_ratio: float,
    *,
    start: float = EDGE_BLOWOFF_START,
    span: float = EDGE_BLOWOFF_SPAN,
    floor: float = EDGE_BLOWOFF_FLOOR,
) -> float:
    """Haircut for a volume BLOWOFF ∈ [floor, 1].

    A stock printing many times its own average volume is, in this universe,
    more likely being DISTRIBUTED than accumulated. Measured over 1,242
    trading days / 481 symbols, 5-day forward EXCESS return by vol_ratio
    band:

        1.25-1.50x   +0.13%  (t  2.2 *)    <- mild pickup: genuinely good
        2.00-3.00x   -0.03%  (t -0.4)      <- turns over
        3.00-5.00x   -0.27%  (t -2.3 *)
        >= 5.00x     -0.85%  (t -5.1 *)    <- heavy distribution

    The dose-response is monotonic, which is what makes it credible: a
    data-mined artefact has no reason to line up in order of intensity.

    SEPARATE from the confirmation gate on purpose. A blowoff name may also
    have a long band-ride streak or strong thrust, and ``max(s, v, t)`` would
    then keep its confirmation high regardless. The penalty has to bite the
    edge independently of what the other tells are saying.

    Measured on vol_ratio (SELF-relative: "busier than IT usually is"),
    because that is the quantity the effect was measured on. The peer-
    relative version (vol_shift) shows the same SHAPE but weaker numbers, so
    it is surfaced as a COLUMN for context rather than used for scoring.

    NB the effect is real but SMALL (-0.85% over 5d). This exists to stop the
    board PROMOTING blowoffs, not to create a tradeable short.
    """
    if vol_ratio != vol_ratio or span <= 0:
        return 1.0
    x = (vol_ratio - start) / span
    x = min(1.0, max(0.0, x))
    return 1.0 - (1.0 - floor) * x


def compute_equity_edge(
    confluence: ConfluenceResult,
    rotation: RotationResult,
    members_by_industry: dict[str, list],
    panel: dict[str, pd.DataFrame],
    benchmark_close: pd.Series | None = None,
    *,
    lookback: int = STRENGTH_LOOKBACK,
    above_4h_by_symbol: dict[str, bool | None] | None = None,
    kappa: float = EDGE_PERSISTENCE_KAPPA,
    member_tilt: float = EDGE_MEMBER_TILT,
    min_atr_pct: float = EDGE_MIN_ATR_PCT,
    adtv_floor: float = EDGE_ADTV_FLOOR,
    adtv_ceiling: float = EDGE_ADTV_CEILING,
    liquidity_floor: float = EDGE_LIQUIDITY_FLOOR,
    confirmation_enabled: bool = EDGE_CONFIRMATION_ENABLED,
    blowoff_enabled: bool = EDGE_BLOWOFF_ENABLED,
) -> EdgeResult:
    """Derive per-symbol momentum-implied expected edge + reward-to-risk.

    Args:
        confluence: the confluence result (its ``confidence`` field is the
            gate product used as ``trust``).
        rotation: the rotation result (industry composite ``roc`` is the
            RS magnitude anchor, over the same ``lookback``).
        members_by_industry: industry → member symbols.
        panel: enriched OHLCV+indicator frames (needs ``Close`` and
            ``atr_14_pct``).
        benchmark_close: benchmark close series; its window return is
            subtracted to make RS an EXCESS return. If None, the excess is
            taken vs 0 (absolute return) — less correct, so pass it.
        lookback: horizon (days) the edge is expressed over; matches the
            strength window so RS_excess and the edge share a horizon.
        kappa: persistence haircut (see module docstring).
        member_tilt: within-industry RS tilt strength.
        min_atr_pct: floor on the risk denominator.

    Returns:
        An :class:`EdgeResult`, symbols ranked by reward-to-risk desc.
    """
    # Trust (gate product) and industry composite return, keyed by industry.
    trust_by_ind = {r.industry: r.confidence for r in confluence.rows}
    roc_by_ind = {r.industry: r.roc for r in rotation.industries}

    # Benchmark-relative RS per industry — the SAME shared definition the
    # Confluence strength factor uses, so the two tabs agree.
    bench_ret = (window_return_pct(benchmark_close, lookback)
                 if benchmark_close is not None else 0.0)
    rs_excess_by_ind = industry_rs_excess(roc_by_ind, bench_ret)

    # RS-reversion display signal (never scored) — computed from the same
    # panel + benchmark already in hand. Fail-soft to all-None.
    from nimbus_v3.compute.rs_reversion import compute_rs_reversion_z
    rs_rev_by_symbol = compute_rs_reversion_z(panel, benchmark_close)

    rows: list[SymbolEdge] = []
    for industry, members in members_by_industry.items():
        trust = trust_by_ind.get(industry, float("nan"))
        ind_roc = roc_by_ind.get(industry, float("nan"))
        # An industry must have BOTH a confluence trust and a composite
        # return to carry an edge — otherwise it isn't a ranked candidate.
        if trust != trust or ind_roc != ind_roc:
            continue

        rs_excess = rs_excess_by_ind.get(industry, float("nan"))
        industry_edge = kappa * rs_excess * trust

        # Extract each member's features ONCE, then derive the industry's
        # MEDIAN vol_ratio from them. The median (not the mean) because a
        # single 20x blowoff would drag a mean upward and make every other
        # member look quiet by comparison — the exact distortion the peer
        # measure exists to avoid.
        feats_by_sym = {}
        for sym in members:
            df = panel.get(sym)
            if df is None or df.empty or "Close" not in df.columns:
                continue
            f = extract_constituent_features(sym, df)
            if f is not None:
                feats_by_sym[sym] = f
        peer_vols = sorted(
            f.vol_ratio for f in feats_by_sym.values()
            if f.vol_ratio == f.vol_ratio and f.vol_ratio > 0)
        if peer_vols:
            m = len(peer_vols) // 2
            median_vol = (peer_vols[m] if len(peer_vols) % 2
                          else 0.5 * (peer_vols[m - 1] + peer_vols[m]))
        else:
            median_vol = float("nan")

        for sym in members:
            df = panel.get(sym)
            if df is None or df.empty or "Close" not in df.columns:
                continue
            sym_ret = window_return_pct(df["Close"], lookback)
            if sym_ret != sym_ret:
                continue

            # Member shift: the symbol's own strength relative to its
            # industry composite, as an ADDITIVE adjustment. A member
            # outperforming its group is a better prospect than one
            # lagging it — regardless of whether the industry itself is hot
            # or cold — so this must shift the edge in a consistent
            # direction (up for leaders, down for laggards), not multiply
            # the industry edge (which would wrongly amplify a strong
            # member DOWNWARD inside a weak industry). Scaled by the same
            # κ and trust as the industry edge, since within-group
            # dispersion deserves no more trust than the industry signal.
            member_excess = sym_ret - ind_roc
            member_shift = kappa * member_tilt * member_excess * trust

            raw_edge = industry_edge + member_shift

            # Per-symbol display features (adtv, chg 1/5/10d, vol ratio,
            # body-above flag, streak) come from the SHARED constituent-
            # feature extractor — the same one the Dashboard tables use — so
            # the Edge tab and Dashboard never disagree on a symbol's numbers
            # and nothing is recomputed in two places. ADTV from here also
            # feeds the liquidity gate.
            feats = feats_by_sym.get(sym)
            adtv = feats.adtv if feats is not None else adtv_latest(df)

            # PEER-relative volume: is this name busier than ITS PEERS right
            # now, or is the whole sector simply active? A stock at 3x its
            # own average on a day its sector is also at 3x is a SECTOR
            # event, not a stock event — and only this column separates the
            # two. Surfaced for context; the SCORING uses vol_ratio, which is
            # the quantity the blowoff effect was actually measured on.
            vshift = float("nan")
            if (feats is not None and median_vol == median_vol
                    and median_vol > 0
                    and feats.vol_ratio == feats.vol_ratio):
                vshift = feats.vol_ratio / median_vol

            # ATR% (risk denominator) is needed BEFORE the confirmation
            # gate, since the thrust component measures the 5d move in ATR
            # units.
            atr = float("nan")
            if "atr_14_pct" in df.columns:
                a = df["atr_14_pct"].dropna()
                if a.shape[0]:
                    atr = float(a.iloc[-1])
            atr_used = max(min_atr_pct, atr) if atr == atr else min_atr_pct

            # Liquidity gate: an edge you can't trade at size is a phantom.
            # Shrink the edge toward zero for thin names (executability
            # haircut) — kept separate from the ATR% denominator, which is
            # price risk, not tradeability.
            liq_gate = _liquidity_gate(
                adtv, adtv_floor, adtv_ceiling, liquidity_floor)

            # Confirmation gate: the industry edge is identical for every
            # member, so a member sitting still would otherwise inherit the
            # full industry edge and — being low-vol — rank ABOVE the names
            # actually making the move. Discount members showing no
            # participation. See the empirical-status note in
            # market_pulse_config: this is a descriptive improvement, NOT a
            # validated predictive one.
            if confirmation_enabled and feats is not None:
                conf_gate = _confirmation_gate(
                    feats.streak, feats.vol_ratio, feats.chg_5d, atr_used)
            else:
                conf_gate = 1.0

            # Volume-blowoff penalty. SEPARATE from the confirmation gate:
            # a blowoff name may also carry a long streak or strong thrust,
            # and max(s, v, t) would keep its confirmation high regardless.
            # This bites the edge independently.
            if blowoff_enabled and feats is not None:
                blow = _blowoff_penalty(feats.vol_ratio)
            else:
                blow = 1.0

            edge = raw_edge * liq_gate * conf_gate * blow

            rr = edge / atr_used if atr_used > 0 else float("nan")

            rows.append(SymbolEdge(
                symbol=sym,
                industry=industry,
                expected_edge=edge,
                reward_to_risk=rr,
                industry_rs_excess=rs_excess,
                trust=trust,
                member_shift=member_shift,
                atr_pct=atr_used,
                adtv=adtv,
                liquidity_gate=liq_gate,
                chg_1d=feats.chg_1d if feats else float("nan"),
                chg_5d=feats.chg_5d if feats else float("nan"),
                chg_10d=feats.chg_10d if feats else float("nan"),
                vol_ratio=feats.vol_ratio if feats else float("nan"),
                vol_shift=vshift,
                above=feats.above if feats else False,
                above_4h=(above_4h_by_symbol.get(sym)
                          if above_4h_by_symbol is not None else None),
                rs_rev_z=rs_rev_by_symbol.get(sym),
                streak=feats.streak if feats else 0,
                confirmation=conf_gate,
            ))

    # Rank by reward-to-risk desc; NaN sinks. Ties break by symbol for
    # deterministic ordering.
    rows.sort(key=lambda r: (
        r.reward_to_risk != r.reward_to_risk,
        -(r.reward_to_risk if r.reward_to_risk == r.reward_to_risk else 0.0),
        r.symbol))

    return EdgeResult(
        rows=tuple(rows),
        horizon_days=lookback,
        kappa=kappa,
    )


def compute_equity_edge_multi(
    confluence: ConfluenceResult,
    members_by_industry: dict[str, list],
    panel: dict[str, pd.DataFrame],
    benchmark_close: pd.Series | None = None,
    *,
    horizons: tuple[int, ...] = EDGE_HORIZONS,
    default_horizon: int = DEFAULT_EDGE_HORIZON,
    rotation_by_horizon: dict[int, RotationResult] | None = None,
    **kwargs,
) -> EdgeHorizonSet:
    """Compute the edge over several horizons in one stateless pass.

    WHY THIS LIVES IN THE ENGINE, NOT THE VIEW
    ------------------------------------------
    ``compute_equity_edge`` derives its RS excess as::

        rs_excess = rotation.roc  -  window_return_pct(benchmark, lookback)

    The first term comes from the ``rotation`` argument; the second from
    ``lookback``. They are two independent inputs that MUST describe the
    same window. Pass a 20-day rotation with ``lookback=5`` and the result
    is a 20-day industry return minus a 5-day benchmark return — not an
    excess return at all, and enough to flip the sign of RS for a majority
    of industries.

    Leaving that pairing to a caller makes it a convention enforced by a
    comment. Doing it here makes it an invariant enforced by the type: a
    view asks for horizons and receives coherent results, and cannot
    construct the mismatched combination at all.

    ``trust`` is deliberately shared across horizons rather than recomputed.
    It is a quality gate (direction × seasonal × breadth), not a
    horizon-scaled return, and the architecture already runs direction on
    its own ``RRG_LOOKBACK`` independent of the strength window — so holding
    the gate fixed while varying the RS window follows the existing
    separation rather than introducing a new inconsistency.

    Args:
        confluence: the confluence result supplying ``trust`` per industry.
        members_by_industry: industry → member symbols.
        panel: enriched OHLCV+indicator frames.
        benchmark_close: benchmark close series (see
            :func:`compute_equity_edge`).
        horizons: windows to compute, in trading days.
        default_horizon: the horizon a consumer should show first.
        rotation_by_horizon: already-computed rotations, keyed by lookback.
            Any horizon present is reused instead of recomputed — the caller
            has usually already built the default-horizon rotation for other
            views, and rebuilding industry composites is the expensive step.
        **kwargs: forwarded verbatim to :func:`compute_equity_edge`
            (``kappa``, ``member_tilt``, ``min_atr_pct``), so the two entry
            points cannot drift in behaviour.

    Returns:
        An :class:`EdgeHorizonSet` with one frozen result per horizon.
    """
    supplied = dict(rotation_by_horizon or {})
    results: list[EdgeResult] = []
    for h in sorted({int(x) for x in horizons}):
        rot = supplied.get(h)
        if rot is None:
            # Built at THIS horizon, so the composite ROC and the benchmark
            # window below always agree. This is the invariant.
            rot = compute_industry_rotation(
                members_by_industry, panel, lookback=h)
        results.append(compute_equity_edge(
            confluence, rot, members_by_industry, panel, benchmark_close,
            lookback=h, **kwargs))       # type: ignore[arg-type]
    return EdgeHorizonSet(
        results=tuple(results),
        default_horizon=int(default_horizon),
    )
