#!/usr/bin/env python3
"""
scripts/run_sector_regime.py — Does sector context predict MR trade outcomes?

Hypothesis: Mean reversion works differently when a stock's sector is:
  - Leading (strong RS vs NIFTY) → trend-following territory?
  - Lagging (weak RS) → deep value, better MR?
  - In drawdown → defensive rotation, better MR in panics?

Uses 4,511 OOS walk-forward trades + sector index prices to test.

Metrics per sector regime:
  1. Sector drawdown from 52w high (deep DD = distressed)
  2. Sector relative strength vs NIFTY 50 (20d momentum ratio)
  3. Sector above/below 50-day SMA (trend proxy)

Run:
    python3 scripts/run_sector_regime.py
"""
import os, sys, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger("sector_regime")

# ══════════════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════════════

TRADES_CSV = "data/backtest_results/wf_oos_trades.csv"

# Stock → sector mapping (broad categories)
# We'll map dynamically using index_constituents, with fallback
SECTOR_TYPE = {
    "Banks": "cyclical", "Finance": "cyclical", "Auto": "cyclical",
    "Metals": "cyclical", "Infra": "cyclical", "Cement": "cyclical",
    "Consumer": "cyclical", "Industrials": "cyclical", "Telecom": "cyclical",
    "IT": "defensive", "Pharma": "defensive", "FMCG": "defensive",
    "Healthcare": "defensive", "Energy": "defensive",
}

# NSE sector index tickers for yfinance
SECTOR_TICKERS = {
    "Banks": "^NSEBANK",
    "IT": "^CNXIT",
    "Pharma": "^CNXPHARMA",
    "Auto": "^CNXAUTO",
    "FMCG": "^CNXFMCG",
    "Metals": "^CNXMETAL",
    "Energy": "^CNXENERGY",
    "Finance": "^CNXFINANCE",
    "Infra": "^CNXINFRA",
    "Consumer": "^CNXCONSUMPTION",
}


# ══════════════════════════════════════════════════════════════════════════════
# DATA
# ══════════════════════════════════════════════════════════════════════════════

def load_trades():
    df = pd.read_csv(TRADES_CSV)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    df["exit_date"] = pd.to_datetime(df["exit_date"])
    log.info(f"Loaded {len(df)} OOS trades ({df.symbol.nunique()} symbols)")
    return df


def map_sectors(symbols: list) -> dict:
    """Map each symbol to a broad sector."""
    try:
        from modules.index_constituents import get_sector
        mapping = {}
        for s in symbols:
            sector = get_sector(s)
            mapping[s] = sector if sector else "Unknown"
        known = sum(1 for v in mapping.values() if v != "Unknown")
        log.info(f"Sector mapping: {known}/{len(symbols)} symbols mapped")
        return mapping
    except Exception as e:
        log.warning(f"Dynamic sector mapping failed: {e}, using fallback")
        return {s: "Unknown" for s in symbols}


def fetch_sector_prices(start: str = "2022-01-01") -> dict:
    """Fetch daily prices for all sector indices."""
    import yfinance as yf
    sector_data = {}
    for name, ticker in SECTOR_TICKERS.items():
        for t in [ticker, ticker.replace("^CNX", "NIFTY_").replace("^NSE", "NIFTY_") + ".NS"]:
            try:
                df = yf.download(t, start=start, progress=False, auto_adjust=True)
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = df.columns.get_level_values(0)
                if not df.empty and len(df) > 100:
                    sector_data[name] = df["Close"].dropna()
                    break
            except Exception:
                continue
    log.info(f"Fetched prices for {len(sector_data)}/{len(SECTOR_TICKERS)} sector indices")
    return sector_data


def fetch_nifty(start: str = "2022-01-01") -> pd.Series:
    """Fetch NIFTY 50 as benchmark."""
    import yfinance as yf
    for ticker in ["^NSEI", "NIFTY_50.NS"]:
        try:
            df = yf.download(ticker, start=start, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if not df.empty and len(df) > 100:
                return df["Close"].dropna()
        except Exception:
            continue
    return pd.Series(dtype=float)


def fetch_vix(start: str = "2022-01-01") -> pd.Series:
    """Fetch India VIX."""
    import yfinance as yf
    for ticker in ["^INDIAVIX", "INDIAVIX.NS"]:
        try:
            df = yf.download(ticker, start=start, progress=False, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if not df.empty:
                return df["Close"].dropna()
        except Exception:
            continue
    return pd.Series(dtype=float)


# ══════════════════════════════════════════════════════════════════════════════
# SECTOR METRICS AT EACH TRADE ENTRY
# ══════════════════════════════════════════════════════════════════════════════

def compute_sector_metrics(
    trades: pd.DataFrame,
    sector_map: dict,
    sector_prices: dict,
    nifty: pd.Series,
    vix: pd.Series,
) -> pd.DataFrame:
    """
    For each trade, compute the sector's state at entry:
      - sector_dd: drawdown from 252d high (%)
      - sector_rs: 20d relative strength vs NIFTY
      - sector_above_sma: above 50d SMA?
      - sector_type: cyclical/defensive
      - vix_regime: from VIX level
    """
    records = []
    for _, t in trades.iterrows():
        sym = t["symbol"]
        sector = sector_map.get(sym, "Unknown")
        entry = t["entry_date"]

        rec = {
            "symbol": sym,
            "sector": sector,
            "sector_type": SECTOR_TYPE.get(sector, "unknown"),
            "entry_date": entry,
            "pnl_pct": t["pnl_pct"],
            "tier": t.get("tier", ""),
            "win": 1 if t["pnl_pct"] > 0 else 0,
        }

        # Sector metrics
        if sector in sector_prices:
            sp = sector_prices[sector]
            mask = sp.index <= entry
            if mask.sum() >= 50:
                sp_slice = sp[mask]
                close = float(sp_slice.iloc[-1])
                high_252 = float(sp_slice.tail(252).max())
                sma_50 = float(sp_slice.tail(50).mean())
                rec["sector_dd"] = (close / high_252 - 1) * 100
                rec["sector_above_sma"] = close > sma_50

                # RS vs NIFTY (20d momentum ratio)
                nifty_mask = nifty.index <= entry
                if nifty_mask.sum() >= 20:
                    ns = nifty[nifty_mask]
                    sec_ret = close / float(sp_slice.iloc[-21]) - 1 if len(sp_slice) > 20 else 0
                    nif_ret = float(ns.iloc[-1]) / float(ns.iloc[-21]) - 1 if len(ns) > 20 else 0
                    rec["sector_rs"] = (sec_ret - nif_ret) * 100
                else:
                    rec["sector_rs"] = np.nan
            else:
                rec["sector_dd"] = np.nan
                rec["sector_above_sma"] = np.nan
                rec["sector_rs"] = np.nan
        else:
            rec["sector_dd"] = np.nan
            rec["sector_above_sma"] = np.nan
            rec["sector_rs"] = np.nan

        # VIX at entry
        if not vix.empty:
            vix_mask = vix.index <= entry
            if vix_mask.any():
                vix_val = float(vix[vix_mask].iloc[-1])
                rec["vix"] = vix_val
                if vix_val > 25:
                    rec["vix_regime"] = "PANIC"
                elif vix_val > 20:
                    rec["vix_regime"] = "ELEVATED"
                elif vix_val < 13:
                    rec["vix_regime"] = "LOW"
                else:
                    rec["vix_regime"] = "NORMAL"
            else:
                rec["vix"] = np.nan
                rec["vix_regime"] = "UNKNOWN"
        else:
            rec["vix"] = np.nan
            rec["vix_regime"] = "UNKNOWN"

        records.append(rec)

    return pd.DataFrame(records)


# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def _report(df, label, group_col):
    """Print a grouped summary table."""
    if group_col not in df.columns or df[group_col].isna().all():
        log.info(f"  {label}: no data for {group_col}")
        return

    g = df.groupby(group_col).agg(
        trades=("pnl_pct", "count"),
        win_rate=("win", "mean"),
        avg_pnl=("pnl_pct", "mean"),
        med_pnl=("pnl_pct", "median"),
        sharpe=("pnl_pct", lambda x: x.mean() / x.std() * np.sqrt(252) if x.std() > 0 else 0),
    ).sort_values("avg_pnl", ascending=False)

    g["win_rate"] = (g["win_rate"] * 100).round(1)
    g["avg_pnl"] = g["avg_pnl"].round(2)
    g["med_pnl"] = g["med_pnl"].round(2)
    g["sharpe"] = g["sharpe"].round(2)

    log.info(f"\n{'═' * 70}")
    log.info(f"  {label}")
    log.info(f"{'═' * 70}")
    log.info(f"{'':>20} {'Trades':>7} {'WR%':>7} {'Avg':>7} {'Med':>7} {'Sharpe':>7}")
    log.info(f"{'─' * 56}")
    for idx, row in g.iterrows():
        log.info(f"{str(idx):>20} {row.trades:>7.0f} {row.win_rate:>7.1f} {row.avg_pnl:>7.2f} {row.med_pnl:>7.2f} {row.sharpe:>7.2f}")
    log.info("")


def analyze(df: pd.DataFrame):
    """Run all sector regime analyses."""
    log.info(f"\nTotal trades with sector data: {len(df)}")
    log.info(f"Sectors: {df.sector.value_counts().to_dict()}")

    # 1. By sector
    _report(df, "MR PERFORMANCE BY SECTOR", "sector")

    # 2. By sector type (cyclical vs defensive)
    _report(df, "MR PERFORMANCE: CYCLICAL vs DEFENSIVE", "sector_type")

    # 3. By sector drawdown bucket
    df["dd_bucket"] = pd.cut(
        df["sector_dd"], bins=[-100, -15, -10, -5, 0],
        labels=["Deep DD (<-15%)", "Moderate DD (-15 to -10%)", "Mild DD (-10 to -5%)", "Near High (>-5%)"]
    )
    _report(df, "MR BY SECTOR DRAWDOWN", "dd_bucket")

    # 4. By sector relative strength
    df["rs_bucket"] = pd.cut(
        df["sector_rs"], bins=[-100, -2, 0, 2, 100],
        labels=["Lagging (<-2%)", "Slightly Weak", "Slightly Strong", "Leading (>+2%)"]
    )
    _report(df, "MR BY SECTOR RELATIVE STRENGTH (20d vs NIFTY)", "rs_bucket")

    # 5. By sector above/below SMA
    df["sma_label"] = df["sector_above_sma"].map({True: "Sector ABOVE SMA50", False: "Sector BELOW SMA50"})
    _report(df, "MR BY SECTOR TREND (above/below 50d SMA)", "sma_label")

    # 6. Cross: sector type × VIX regime
    if "vix_regime" in df.columns:
        df["cross"] = df["sector_type"] + " × " + df["vix_regime"]
        _report(df, "CROSS: SECTOR TYPE × VIX REGIME", "cross")

    # 7. Cross: sector DD × VIX regime
    if "vix_regime" in df.columns and "dd_bucket" in df.columns:
        df["dd_vix"] = df["dd_bucket"].astype(str) + " × " + df["vix_regime"]
        _report(df, "CROSS: SECTOR DD × VIX REGIME", "dd_vix")

    # 8. Key finding: best and worst combos
    if "cross" in df.columns:
        cross_g = df.groupby("cross").agg(
            trades=("pnl_pct", "count"),
            wr=("win", "mean"),
            avg=("pnl_pct", "mean"),
        )
        cross_g = cross_g[cross_g.trades >= 20]
        if not cross_g.empty:
            best = cross_g.sort_values("avg", ascending=False).iloc[0]
            worst = cross_g.sort_values("avg").iloc[0]
            log.info(f"\n{'═' * 70}")
            log.info(f"  KEY FINDINGS (min 20 trades)")
            log.info(f"{'═' * 70}")
            log.info(f"  Best:  {best.name} → WR {best.wr:.0%}, Avg {best.avg:+.2f}% ({best.trades:.0f} trades)")
            log.info(f"  Worst: {worst.name} → WR {worst.wr:.0%}, Avg {worst.avg:+.2f}% ({worst.trades:.0f} trades)")


def main():
    trades = load_trades()

    log.info("Mapping symbols to sectors...")
    symbols = trades["symbol"].unique().tolist()
    sector_map = map_sectors(symbols)

    log.info("Fetching sector index prices...")
    sector_prices = fetch_sector_prices("2022-01-01")

    log.info("Fetching NIFTY 50 benchmark...")
    nifty = fetch_nifty("2022-01-01")

    log.info("Fetching India VIX...")
    vix = fetch_vix("2022-01-01")

    log.info("Computing sector metrics at each trade entry...")
    enriched = compute_sector_metrics(trades, sector_map, sector_prices, nifty, vix)

    # Drop rows with no sector data
    has_data = enriched[enriched["sector_dd"].notna()]
    log.info(f"Trades with sector data: {len(has_data)}/{len(enriched)}")

    analyze(has_data)

    # Save enriched data
    out = "data/backtest_results/sector_regime_analysis.csv"
    enriched.to_csv(out, index=False)
    log.info(f"\nSaved enriched trade data → {out}")


if __name__ == "__main__":
    main()
