"""Tests for the momentum-implied equity edge engine."""
import numpy as np
import pandas as pd

from nimbus_v3.compute.confluence import (
    ConfluenceResult,
    ConfluenceRow,
    FactorRead,
)
from nimbus_v3.compute.industry_rotation import (
    IndustryRotation,
    RotationResult,
)
from nimbus_v3.compute.equity_edge import compute_equity_edge


def _fr(v=0.0, p=50.0, c=1.0):
    return FactorRead(value=v, percentile=p, confidence=c, detail="")


def _conf(rows):
    """rows: list of (industry, trust)."""
    crows = tuple(
        ConfluenceRow(
            industry=ind, score=50.0, confidence=trust,
            strength=_fr(), direction=_fr(), seasonal=_fr(),
            n_members=6)
        for ind, trust in rows)
    return ConfluenceResult(
        rows=crows, month=7, regime_label="—",
        regime_signals_on=0, regime_n_signals=0)


def _rot(rows):
    """rows: list of (industry, roc)."""
    inds = tuple(
        IndustryRotation(industry=ind, dates=(), cum_return=(),
                         roc=roc, n_members=6)
        for ind, roc in rows)
    return RotationResult(industries=inds, lookback=20)


def _series(total_ret_pct, n=30, lookback=20, adtv=5e10):
    """A close series whose return over the trailing ``lookback`` bars is
    exactly ``total_ret_pct``. Flat before the window so the engine's
    trailing-window read matches the stated number. ``adtv`` sets the
    average daily traded value (default ₹5,000cr — well above the liquidity
    ceiling, so the liquidity gate is 1.0 and doesn't perturb edge-math
    tests unless a test deliberately lowers it)."""
    pre = n - lookback
    end = 100.0 * (1 + total_ret_pct / 100.0)
    ramp = np.linspace(100.0, end, lookback)
    c = np.concatenate([np.full(pre, 100.0), ramp])
    idx = pd.date_range("2025-01-01", periods=n, freq="B")
    # Volume chosen so Close×Volume ≈ adtv (Close ~100 in the flat region).
    vol = np.full(n, adtv / 100.0)
    return pd.DataFrame({
        "Close": c,
        "Volume": vol,
        "atr_14_pct": np.full(n, 2.0),
    }, index=idx)


def test_edge_shrunk_by_kappa_and_trust():
    """The industry edge = κ · RS_excess · trust. A high-trust strong
    industry produces a positive edge well below its raw RS (shrunk)."""
    conf = _conf([("Hot", 0.8)])
    rot = _rot([("Hot", 10.0)])          # +10% over window
    mbi = {"Hot": ["A"]}
    panel = {"A": _series(10.0)}
    bench = _series(2.0)["Close"]         # benchmark +2%
    # confirmation_enabled=False: this test pins the CORE arithmetic
    # (kappa x RS_excess x trust). The confirmation gate multiplies the
    # edge and is exercised by its own tests below.
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, kappa=0.30, member_tilt=0.0,
                              confirmation_enabled=False)
    r = res.rows[0]
    # RS_excess = 10 - 2 = 8; edge = 0.30 * 8 * 0.8 = 1.92
    assert abs(r.industry_rs_excess - 8.0) < 1e-6
    assert abs(r.expected_edge - 0.30 * 8.0 * 0.8) < 1e-6
    # Shrunk well below the raw 8% excess.
    assert r.expected_edge < r.industry_rs_excess


def test_low_trust_shrinks_edge_toward_zero():
    """Same raw RS but low trust (narrow/fading confluence) → much
    smaller edge. Trust is the shrinkage that says 'we don't expect this
    to persist'."""
    rot = _rot([("X", 10.0)])
    mbi = {"X": ["A"]}
    panel = {"A": _series(10.0)}
    bench = _series(0.0)["Close"]
    hi = compute_equity_edge(_conf([("X", 0.9)]), rot, mbi, panel, bench,
                             lookback=20, member_tilt=0.0).rows[0]
    lo = compute_equity_edge(_conf([("X", 0.2)]), rot, mbi, panel, bench,
                             lookback=20, member_tilt=0.0).rows[0]
    assert hi.expected_edge > lo.expected_edge
    assert lo.expected_edge < 0.5 * hi.expected_edge


def test_member_shift_is_sign_correct_in_weak_industry():
    """A strong member in a WEAK (negative-edge) industry must be made
    LESS bad, not amplified downward — the additive member shift lifts it
    above a weak member of the same industry."""
    conf = _conf([("Weak", 0.4)])
    rot = _rot([("Weak", -6.0)])          # industry down 6%
    mbi = {"Weak": ["Leader", "Laggard"]}
    panel = {
        "Leader": _series(2.0),           # outperforms its -6% group
        "Laggard": _series(-12.0),        # underperforms
    }
    bench = _series(0.0)["Close"]
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, member_tilt=0.5)
    by = {r.symbol: r for r in res.rows}
    # Leader's within-group shift is positive, laggard's negative.
    assert by["Leader"].member_shift > 0
    assert by["Laggard"].member_shift < 0
    # And the leader ends up strictly better than the laggard.
    assert by["Leader"].expected_edge > by["Laggard"].expected_edge


def test_reward_to_risk_divides_by_atr():
    """Reward-to-risk = edge / ATR%. Two identical-edge symbols with
    different vol rank by the lower-vol one first."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["LowVol", "HighVol"]}
    lo = _series(10.0); lo["atr_14_pct"] = 1.0
    hi = _series(10.0); hi["atr_14_pct"] = 4.0
    panel = {"LowVol": lo, "HighVol": hi}
    bench = _series(0.0)["Close"]
    # Gate off: this test isolates the ATR denominator. With the gate on,
    # the two names' identical tapes would confirm identically anyway, but
    # pinning it keeps the test about ONE thing.
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, member_tilt=0.0,
                              confirmation_enabled=False)
    by = {r.symbol: r for r in res.rows}
    # Same edge, but low-vol has higher reward-to-risk.
    assert abs(by["LowVol"].expected_edge
               - by["HighVol"].expected_edge) < 1e-9
    assert by["LowVol"].reward_to_risk > by["HighVol"].reward_to_risk
    # And it ranks first.
    assert res.rows[0].symbol == "LowVol"


def test_atr_floor_prevents_blowup():
    """A near-zero-vol symbol is floored so reward-to-risk can't explode."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["A"]}
    df = _series(10.0); df["atr_14_pct"] = 0.01   # absurdly low
    res = compute_equity_edge(conf, rot, mbi, {"A": df},
                              _series(0.0)["Close"], lookback=20,
                              member_tilt=0.0, min_atr_pct=0.5)
    assert res.rows[0].atr_pct == 0.5     # floored


def test_industry_without_trust_excluded():
    """An industry with no confluence trust (not a ranked candidate) is
    excluded — its members carry no edge."""
    conf = _conf([("Ranked", 0.7)])       # only Ranked has trust
    rot = _rot([("Ranked", 8.0), ("Orphan", 5.0)])
    mbi = {"Ranked": ["A"], "Orphan": ["B"]}
    panel = {"A": _series(8.0), "B": _series(5.0)}
    res = compute_equity_edge(conf, rot, mbi, panel,
                              _series(0.0)["Close"], lookback=20)
    syms = {r.symbol for r in res.rows}
    assert "A" in syms
    assert "B" not in syms


def test_liquidity_gate_crushes_thin_names():
    """A thin name (low ADTV) has its edge shrunk toward the liquidity
    floor, while a liquid name of identical momentum is untouched — the
    executability haircut, separate from ATR%."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["Liquid", "Thin"]}
    panel = {
        "Liquid": _series(10.0, adtv=5e10),   # ₹5,000cr — above ceiling
        "Thin": _series(10.0, adtv=2e8),      # ₹20cr — below floor
    }
    bench = _series(0.0)["Close"]
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, member_tilt=0.0)
    by = {r.symbol: r for r in res.rows}
    assert by["Liquid"].liquidity_gate == 1.0
    assert by["Thin"].liquidity_gate < 0.5
    assert by["Thin"].expected_edge < by["Liquid"].expected_edge
    # member_tilt=0 so the only difference is the gate.
    assert abs(by["Thin"].expected_edge
               - by["Liquid"].expected_edge * by["Thin"].liquidity_gate) < 1e-9
    assert res.rows[0].symbol == "Liquid"


def test_nan_adtv_treated_as_thin():
    """A symbol with no volume data can't be confirmed tradeable, so it is
    treated as fully thin (gated to the floor), not given the benefit of
    the doubt."""
    from nimbus_v3.compute.market_pulse_config import EDGE_LIQUIDITY_FLOOR
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    df = _series(10.0).drop(columns=["Volume"])   # no volume → NaN ADTV
    res = compute_equity_edge(conf, rot, {"I": ["A"]}, {"A": df},
                              _series(0.0)["Close"], lookback=20,
                              member_tilt=0.0)
    r = res.rows[0]
    assert r.adtv != r.adtv                        # NaN
    assert abs(r.liquidity_gate - EDGE_LIQUIDITY_FLOOR) < 1e-9


def test_deterministic_across_seeds():
    """Ranking is deterministic (sorted with a symbol tiebreak)."""
    conf = _conf([("I", 0.6)])
    rot = _rot([("I", 7.0)])
    mbi = {"I": [f"S{i}" for i in range(8)]}
    panel = {f"S{i}": _series(7.0 + i * 0.1) for i in range(8)}
    bench = _series(1.0)["Close"]
    order1 = [r.symbol for r in compute_equity_edge(
        conf, rot, mbi, panel, bench, lookback=20).rows]
    order2 = [r.symbol for r in compute_equity_edge(
        conf, rot, mbi, panel, bench, lookback=20).rows]
    assert order1 == order2


# ── Member-confirmation gate ────────────────────────────────────────────
# NOTE: the gate is NOT a validated predictive signal (see the empirical
# status note in market_pulse_config). These tests pin its MECHANICS — that
# it discounts non-participants and can be switched off — not its efficacy.

def test_confirmation_gate_helper_scores():
    """The gate saturates on ANY one of the three tells, and floors when
    none is present."""
    from nimbus_v3.compute.equity_edge import _confirmation_gate
    from nimbus_v3.compute.market_pulse_config import EDGE_CONFIRM_FLOOR

    # No participation at all -> floored.
    dead = _confirmation_gate(0, 0.4, 0.0, 3.0)
    assert abs(dead - EDGE_CONFIRM_FLOOR) < 1e-9

    # Any ONE tell saturating is enough (max, not average):
    rider = _confirmation_gate(12, 0.4, 0.0, 3.0)     # streak alone
    spiker = _confirmation_gate(0, 2.5, 0.0, 3.0)     # MILD volume alone
    thruster = _confirmation_gate(0, 0.4, 20.0, 3.0)  # thrust alone
    for g in (rider, spiker, thruster):
        assert abs(g - 1.0) < 1e-9

    # Bounded in [floor, 1].
    for g in (dead, rider, spiker, thruster):
        assert EDGE_CONFIRM_FLOOR - 1e-9 <= g <= 1.0 + 1e-9


def test_confirmation_gate_nan_inputs_do_not_confirm():
    """Absence of evidence is not confirmation: NaN tells contribute 0."""
    from nimbus_v3.compute.equity_edge import _confirmation_gate
    from nimbus_v3.compute.market_pulse_config import EDGE_CONFIRM_FLOOR
    nan = float("nan")
    g = _confirmation_gate(0, nan, nan, 3.0)
    assert abs(g - EDGE_CONFIRM_FLOOR) < 1e-9


def test_confirmation_gate_demotes_the_non_participant():
    """Two members of the SAME industry (identical industry edge): the one
    showing no participation is discounted below the one that is riding.

    This is the pathology the gate exists for — without it the quiet name
    ranks ABOVE the mover purely because its ATR is lower.
    """
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["RIDER", "DEAD"]}

    rider = _series(10.0)
    rider["Volume"] = 5e8
    # DEAD: flat tape, volume dried up -> no streak, no vol, no thrust.
    dead = _series(10.0)
    dead["Close"] = 100.0
    dead["Volume"] = 1e6

    res = compute_equity_edge(
        conf, rot, mbi, {"RIDER": rider, "DEAD": dead},
        _series(0.0)["Close"], lookback=20, member_tilt=0.0)
    by = {r.symbol: r for r in res.rows}
    assert by["DEAD"].confirmation < by["RIDER"].confirmation
    assert by["DEAD"].confirmation < 1.0


def test_confirmation_gate_can_be_disabled():
    """The master switch restores the pre-gate ranking exactly."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    df = _series(10.0)
    df["Close"] = 100.0          # dead tape -> gate would bite
    df["Volume"] = 1e6

    on = compute_equity_edge(
        conf, rot, {"I": ["A"]}, {"A": df}, _series(0.0)["Close"],
        lookback=20, member_tilt=0.0, confirmation_enabled=True)
    off = compute_equity_edge(
        conf, rot, {"I": ["A"]}, {"A": df}, _series(0.0)["Close"],
        lookback=20, member_tilt=0.0, confirmation_enabled=False)

    assert off.rows[0].confirmation == 1.0
    assert on.rows[0].confirmation < 1.0
    # With the gate off the edge is strictly larger (nothing discounted).
    assert off.rows[0].expected_edge > on.rows[0].expected_edge



# ── Volume blowoff ──────────────────────────────────────────────────────
# Measured over 1,242 trading days / 481 symbols: a MILD volume pickup is
# genuinely positive (1.25-1.5x: +0.13%, t=2.2) but a BLOWOFF predicts
# UNDERperformance (>=5x: -0.85%, t=-5.1), with a clean monotonic dose-
# response. The old gate treated every level as confirmation — actively
# rewarding the worst cohort on the board.

def test_volume_stops_confirming_past_the_cap():
    """Volume confirms a mild pickup but NOT a blowoff. Past the cap it is
    no longer evidence of participation — it is evidence of distribution,
    and counting it as confirmation would reward exactly the wrong names."""
    from nimbus_v3.compute.equity_edge import _confirmation_gate
    from nimbus_v3.compute.market_pulse_config import (
        EDGE_CONFIRM_FLOOR, EDGE_CONFIRM_VOL_CAP,
    )
    # Mild pickup, no other tells -> volume alone confirms fully.
    mild = _confirmation_gate(0, EDGE_CONFIRM_VOL_CAP - 0.5, 0.0, 3.0)
    assert mild > 0.9

    # Blowoff, no other tells -> volume contributes NOTHING.
    blow = _confirmation_gate(0, EDGE_CONFIRM_VOL_CAP + 3.0, 0.0, 3.0)
    assert abs(blow - EDGE_CONFIRM_FLOOR) < 1e-9


def test_blowoff_penalty_curve():
    """Nothing below the start; ramps to the floor; never below it."""
    from nimbus_v3.compute.equity_edge import _blowoff_penalty
    from nimbus_v3.compute.market_pulse_config import (
        EDGE_BLOWOFF_FLOOR, EDGE_BLOWOFF_SPAN, EDGE_BLOWOFF_START,
    )
    assert _blowoff_penalty(1.0) == 1.0
    assert _blowoff_penalty(EDGE_BLOWOFF_START) == 1.0
    mid = _blowoff_penalty(EDGE_BLOWOFF_START + EDGE_BLOWOFF_SPAN / 2)
    assert EDGE_BLOWOFF_FLOOR < mid < 1.0
    full = _blowoff_penalty(EDGE_BLOWOFF_START + EDGE_BLOWOFF_SPAN * 3)
    assert abs(full - EDGE_BLOWOFF_FLOOR) < 1e-9        # clamped, not below
    assert _blowoff_penalty(float("nan")) == 1.0        # NaN -> no penalty


def test_blowoff_penalty_is_independent_of_confirmation():
    """The penalty must bite EVEN when the name has a long streak.

    This is why it is separate from the gate: max(streak, vol, thrust) would
    keep a blowoff's confirmation high on the strength of its streak alone,
    and the penalty would never land.
    """
    from nimbus_v3.compute.equity_edge import _blowoff_penalty
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])

    df = _series(10.0)
    df["Volume"] = 1e6
    df.loc[df.index[-1], "Volume"] = 1e6 * 8      # 8x blowoff

    on = compute_equity_edge(
        conf, rot, {"I": ["A"]}, {"A": df}, _series(0.0)["Close"],
        lookback=20, member_tilt=0.0, blowoff_enabled=True)
    off = compute_equity_edge(
        conf, rot, {"I": ["A"]}, {"A": df}, _series(0.0)["Close"],
        lookback=20, member_tilt=0.0, blowoff_enabled=False)

    assert on.rows[0].expected_edge < off.rows[0].expected_edge
    assert _blowoff_penalty(on.rows[0].vol_ratio) < 1.0


def test_vol_shift_is_peer_relative():
    """vol_shift answers a DIFFERENT question from vol_ratio: 'busier than
    my PEERS' vs 'busier than I usually am'. A stock at 3x its own average
    on a day its whole sector is at 3x is a SECTOR event, not a stock one —
    and only the peer measure can tell them apart."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])

    quiet = _series(10.0)
    quiet["Volume"] = 1e6
    loud = _series(10.0)
    loud["Volume"] = 1e6
    loud.loc[loud.index[-1], "Volume"] = 1e6 * 4     # 4x its own average

    panel = {"Q1": quiet, "Q2": quiet.copy(), "Q3": quiet.copy(),
             "LOUD": loud}
    res = compute_equity_edge(
        conf, rot, {"I": list(panel)}, panel, _series(0.0)["Close"],
        lookback=20, member_tilt=0.0)
    by = {r.symbol: r for r in res.rows}

    # LOUD is loud both ways: vs itself AND vs its quiet peers.
    assert by["LOUD"].vol_ratio > 3.0
    assert by["LOUD"].vol_shift > 3.0
    # The quiet names sit at the peer median.
    assert abs(by["Q1"].vol_shift - 1.0) < 0.2


# ── multi-horizon engine ────────────────────────────────────────────────
def _multi_fixture():
    """Panel + members + benchmark large enough for a 20-day window."""
    import numpy as np
    import pandas as pd
    rng = np.random.default_rng(11)
    dates = pd.bdate_range("2022-01-03", periods=400)
    panel, members = {}, {}
    for ind, drift in (("Alpha", 0.0020), ("Beta", 0.0000),
                       ("Gamma", -0.0015)):
        members[ind] = []
        for k in range(6):
            close = 1000 * np.exp(np.cumsum(
                rng.normal(drift, 0.011, len(dates))))
            panel[f"{ind[:2].upper()}{k}"] = pd.DataFrame({
                "Open": close, "High": close * 1.01, "Low": close * 0.99,
                "Close": close,
                "Volume": np.full(len(dates), 250000.0),
                "atr_14_pct": np.full(len(dates), 2.0),
            }, index=dates)
            members[ind].append(f"{ind[:2].upper()}{k}")
    bench = pd.Series(
        1000 * np.exp(np.cumsum(rng.normal(0.0005, 0.007, len(dates)))),
        index=dates)
    return panel, members, bench


def _confluence_for(rotation, panel, members, bench, lookback):
    from nimbus_v3.compute.confluence import compute_confluence
    from nimbus_v3.compute.industry_seasonality import (
        compute_industry_seasonality,
    )
    from nimbus_v3.compute.market_pulse_common import window_return_pct
    from nimbus_v3.compute.rrg import compute_rrg
    rrg = compute_rrg(members, panel, bench, lookback=50)
    seas = compute_industry_seasonality(members, panel, min_member_years=0)
    return compute_confluence(
        rotation, rrg, seas, None, month=6,
        benchmark_return=window_return_pct(bench, lookback))


def test_multi_horizon_returns_one_result_per_horizon():
    from nimbus_v3.compute.equity_edge import compute_equity_edge_multi
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    panel, members, bench = _multi_fixture()
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    conf = _confluence_for(rot20, panel, members, bench, 20)
    hs = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(5, 10, 20),
        default_horizon=20)
    assert hs.horizons == (5, 10, 20)
    for h in (5, 10, 20):
        assert hs.get(h).horizon_days == h
    assert hs.get(7) is None
    assert hs.default.horizon_days == 20


def test_multi_horizon_rs_excess_matches_single_call():
    """Each member must equal what a correctly-paired single call produces.

    This is the invariant the multi entry point exists to guarantee: the
    industry composite ROC and the benchmark return share a window.
    """
    from nimbus_v3.compute.equity_edge import (
        compute_equity_edge,
        compute_equity_edge_multi,
    )
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    panel, members, bench = _multi_fixture()
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    conf = _confluence_for(rot20, panel, members, bench, 20)
    hs = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(5, 10, 20))
    for h in (5, 10, 20):
        rot_h = compute_industry_rotation(members, panel, lookback=h)
        ref = compute_equity_edge(
            conf, rot_h, members, panel, bench, lookback=h)
        got = {r.symbol: r.industry_rs_excess for r in hs.get(h).rows}
        exp = {r.symbol: r.industry_rs_excess for r in ref.rows}
        assert got == exp, f"horizon {h} diverged from a paired single call"


def test_multi_horizon_horizons_actually_differ():
    """A shorter window must change the reading, not merely relabel it."""
    from nimbus_v3.compute.equity_edge import compute_equity_edge_multi
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    panel, members, bench = _multi_fixture()
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    conf = _confluence_for(rot20, panel, members, bench, 20)
    hs = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(5, 20))
    rs5 = {r.symbol: r.industry_rs_excess for r in hs.get(5).rows}
    rs20 = {r.symbol: r.industry_rs_excess for r in hs.get(20).rows}
    assert rs5 and rs20
    assert rs5 != rs20, "horizon toggle is cosmetic — RS excess unchanged"


def test_multi_horizon_reuses_supplied_rotation():
    """A supplied rotation is used as-is (the expensive step is skipped)."""
    from nimbus_v3.compute.equity_edge import compute_equity_edge_multi
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    panel, members, bench = _multi_fixture()
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    conf = _confluence_for(rot20, panel, members, bench, 20)
    a = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(20,),
        rotation_by_horizon={20: rot20})
    b = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(20,))
    assert ({r.symbol: r.industry_rs_excess for r in a.get(20).rows}
            == {r.symbol: r.industry_rs_excess for r in b.get(20).rows})


# ── 4h body-above flag threading ────────────────────────────────────────
def test_above_4h_flag_threads_onto_rows():
    """The 4h map, when supplied, lands on each SymbolEdge as a tri-state.

    Symbols absent from the map get None (unknown), never a guessed False.
    """
    from nimbus_v3.compute.equity_edge import compute_equity_edge_multi
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    panel, members, bench = _multi_fixture()
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    conf = _confluence_for(rot20, panel, members, bench, 20)

    all_syms = [s for syms in members.values() for s in syms]
    flags = {}
    for i, s in enumerate(all_syms):
        flags[s] = (True if i % 3 == 0 else False) if i % 5 != 0 else None
    # leave one symbol entirely out of the map -> must read as None
    dropped = all_syms[-1]
    flags.pop(dropped, None)

    hs = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(10, 20),
        above_4h_by_symbol=flags)

    for h in (10, 20):
        got = {r.symbol: r.above_4h for r in hs.get(h).rows}
        for s in got:
            if s == dropped or flags.get(s) is None:
                assert got[s] is None, f"{s} should be unknown"
            else:
                assert got[s] == flags[s], f"{s} flag mismatch"


def test_above_4h_defaults_to_none_when_no_map():
    """Without a 4h map, every row's flag is None — the column shows '?'."""
    from nimbus_v3.compute.equity_edge import compute_equity_edge_multi
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    panel, members, bench = _multi_fixture()
    rot20 = compute_industry_rotation(members, panel, lookback=20)
    conf = _confluence_for(rot20, panel, members, bench, 20)
    hs = compute_equity_edge_multi(
        conf, members, panel, bench, horizons=(10, 20))
    assert all(r.above_4h is None for r in hs.get(10).rows)
