#!/usr/bin/env python3
"""
scripts/run_vix_grade_sweep.py — Backtest VIX weighting in the grade system.

Instead of assuming VIX multipliers, test them against 4,612 OOS trades.
Compares three grade systems:
  A. NO VIX:        Grade from stock quality only (baseline)
  B. FLAT VIX:      Old system — VIX adds fixed +0/+2/+3/+4 pts
  C. PROPORTIONAL:  New system — VIX adds % of quality pts

For each system, compute grade for every OOS trade at entry, then measure:
  - Does higher grade → higher win rate? (monotonicity)
  - Does grade predict PnL? (correlation)
  - Separation: how different is A+ win rate from D win rate?
  - Calibration: is the grade ordering honest?

The winner is whichever system has the best grade→outcome correlation
WITHOUT inflating weak trades during high VIX.

Usage:
    python3 scripts/run_vix_grade_sweep.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("vix_grade_sweep")

GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6, "—": 7}


def compute_quality_pts(sc, wr, mfi, dd, streak, vol, mfi_slope, bbw_pctl, tier):
    """Stock quality points (VIX-independent)."""
    pts = 0
    if sc >= 80: pts += 4
    elif sc >= 70: pts += 3
    elif sc >= 60: pts += 2
    elif sc >= 50: pts += 1

    if wr is not None:
        if wr < -70: pts += 3
        elif wr < -50: pts += 2
        elif wr < -30: pts += 1

    if mfi >= 55 and mfi_slope > 3: pts += 2
    elif mfi >= 45: pts += 1

    if dd < -10 and streak >= 3: pts += 2
    elif dd < -5 or streak >= 3: pts += 1

    if bbw_pctl < 25: pts += 1
    if vol >= 1.5: pts += 1
    if tier == "PRIMARY": pts += 1
    return pts


def grade_no_vix(quality_pts):
    """Grade A: stock quality only, no VIX influence."""
    pts = quality_pts
    if pts >= 14: return "A+"
    if pts >= 12: return "A"
    if pts >= 10: return "B+"
    if pts >= 8: return "B"
    if pts >= 6: return "C+"
    if pts >= 4: return "C"
    return "D"


def grade_flat_vix(quality_pts, vix_regime):
    """Grade B: old system — flat VIX points."""
    flat = {"PANIC": 4, "ELEVATED": 3, "LOW": 2, "NORMAL": 0}
    pts = quality_pts + flat.get(vix_regime, 0)
    if pts >= 14: return "A+"
    if pts >= 12: return "A"
    if pts >= 10: return "B+"
    if pts >= 8: return "B"
    if pts >= 6: return "C+"
    if pts >= 4: return "C"
    return "D"


def grade_proportional(quality_pts, vix_regime):
    """Grade C: new system — proportional VIX bonus."""
    mult = {"PANIC": 0.25, "ELEVATED": 0.15, "LOW": 0.10, "NORMAL": 0.0}
    bonus = round(quality_pts * mult.get(vix_regime, 0))
    pts = quality_pts + bonus
    if pts >= 14: return "A+"
    if pts >= 12: return "A"
    if pts >= 10: return "B+"
    if pts >= 8: return "B"
    if pts >= 6: return "C+"
    if pts >= 4: return "C"
    return "D"


def sweep_multipliers(features_df):
    """Sweep VIX multiplier values to find optimal."""
    logger.info("\n" + "=" * 70)
    logger.info("MULTIPLIER SWEEP — finding optimal VIX weighting")
    logger.info("=" * 70)

    best_corr = -1
    best_params = {}

    for panic_m in [0.0, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]:
        for elev_m in [0.0, 0.05, 0.10, 0.15, 0.20, 0.25]:
            for low_m in [0.0, 0.05, 0.10, 0.15]:
                mults = {"PANIC": panic_m, "ELEVATED": elev_m, "LOW": low_m, "NORMAL": 0.0}
                grades = []
                for _, row in features_df.iterrows():
                    bonus = round(row["quality_pts"] * mults.get(row["vix_regime"], 0))
                    pts = row["quality_pts"] + bonus
                    grades.append(pts)

                # Correlation with PnL
                corr = np.corrcoef(grades, features_df["pnl_pct"].values)[0, 1]
                if not np.isnan(corr) and corr > best_corr:
                    best_corr = corr
                    best_params = mults.copy()
                    best_params["_corr"] = corr

    logger.info(f"\n  Best multipliers (max corr with PnL):")
    logger.info(f"    PANIC:    {best_params.get('PANIC', 0):.2f}")
    logger.info(f"    ELEVATED: {best_params.get('ELEVATED', 0):.2f}")
    logger.info(f"    LOW:      {best_params.get('LOW', 0):.2f}")
    logger.info(f"    Correlation: {best_params.get('_corr', 0):.4f}")
    return best_params


def evaluate_system(features_df, grade_col, system_name):
    """Evaluate a grade system's predictive quality."""
    grades = features_df[grade_col]
    wins = features_df["win"]
    pnls = features_df["pnl_pct"]

    # Grade → win rate table
    results = []
    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        mask = grades == g
        n = mask.sum()
        if n < 5:
            continue
        wr = wins[mask].mean() * 100
        avg = pnls[mask].mean()
        sh = avg / pnls[mask].std() * np.sqrt(252/10) if pnls[mask].std() > 0 else 0
        results.append({"grade": g, "n": n, "win_rate": wr, "avg_pnl": avg, "sharpe": sh})

    df_results = pd.DataFrame(results)

    # Monotonicity: higher grade → higher win rate?
    wrs = df_results["win_rate"].values
    monotonic_breaks = 0
    for i in range(len(wrs) - 1):
        if wrs[i] < wrs[i+1]:  # lower grade has higher win rate = break
            monotonic_breaks += 1

    # Separation: A+/A win rate vs C/D win rate
    top = features_df[grades.isin(["A+", "A"])]
    bot = features_df[grades.isin(["C", "D"])]
    if len(top) >= 10 and len(bot) >= 10:
        separation = top["win"].mean() * 100 - bot["win"].mean() * 100
    else:
        separation = 0

    # Correlation: grade ordinal → PnL
    grade_nums = grades.map(GRADE_ORD).fillna(7)
    corr = -np.corrcoef(grade_nums, pnls)[0, 1]  # negative because lower ordinal = better

    logger.info(f"\n  {system_name}:")
    logger.info(f"  {'Grade':5s} {'N':>5s} {'Win%':>6s} {'Avg':>8s} {'Sharpe':>7s}")
    for _, r in df_results.iterrows():
        logger.info(f"  {r['grade']:5s} {r['n']:5.0f} {r['win_rate']:5.1f}% {r['avg_pnl']:+7.3f}% {r['sharpe']:6.2f}")
    logger.info(f"  Monotonic breaks: {monotonic_breaks}")
    logger.info(f"  Separation (A/A+ vs C/D): {separation:+.1f}pp")
    logger.info(f"  Grade→PnL correlation: {corr:.4f}")

    return {
        "name": system_name,
        "breaks": monotonic_breaks,
        "separation": separation,
        "correlation": corr,
        "n_grades": len(df_results),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="vix_grade_sweep_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt):
                args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    # ── Reconstruct features ────────────────────────────────────────────
    logger.info("Reconstructing entry features...")
    from modules.dual_mode import compute_dual_mode

    price_cache = {}
    cache_dir = "data/backtest_cache"
    for sym in trades_df["symbol"].unique():
        f = os.path.join(cache_dir, f"{sym}_1d.parquet")
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except Exception:
                pass

    # Fetch VIX
    logger.info("Fetching VIX history...")
    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    rows = []
    skipped = 0
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        entry_date = trade["entry_date"]

        if sym not in price_cache:
            skipped += 1; continue

        pdf = price_cache[sym]
        mask = pdf.index <= entry_date
        if mask.sum() < 40:
            skipped += 1; continue

        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient:
                skipped += 1; continue

            # Match VIX
            vmask = vix_series.index <= entry_date
            vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0

            if vix > 22: vr = "PANIC"
            elif vix >= 18: vr = "ELEVATED"
            elif vix >= 13: vr = "NORMAL"
            else: vr = "LOW"

            qp = compute_quality_pts(
                sig.dual_score, sig.wr_30, sig.mfi, sig.dd_from_high,
                sig.red_streak, sig.vol_ratio, sig.mfi_slope, sig.bbw_pctl, trade["tier"]
            )

            rows.append({
                "symbol": sym,
                "entry_date": entry_date,
                "pnl_pct": trade["pnl_pct"],
                "win": 1 if trade["pnl_pct"] > 0 else 0,
                "tier": trade["tier"],
                "vix": vix,
                "vix_regime": vr,
                "quality_pts": qp,
                "score": sig.dual_score,
                "wr": sig.wr_30,
                "mfi": sig.mfi,
                "dd": sig.dd_from_high,
            })
        except Exception:
            skipped += 1

        if (len(rows) + skipped) % 500 == 0:
            logger.info("  %d/%d processed", len(rows), len(trades_df))

    features_df = pd.DataFrame(rows)
    logger.info("Features: %d trades (%d skipped)", len(features_df), skipped)

    # ── Compute grades for all three systems ─────────────────────────────
    features_df["grade_no_vix"] = features_df["quality_pts"].apply(grade_no_vix)
    features_df["grade_flat"] = features_df.apply(
        lambda r: grade_flat_vix(r["quality_pts"], r["vix_regime"]), axis=1)
    features_df["grade_prop"] = features_df.apply(
        lambda r: grade_proportional(r["quality_pts"], r["vix_regime"]), axis=1)

    # ── Evaluate all three ───────────────────────────────────────────────
    report = []
    report.append("=" * 70)
    report.append("VIX GRADE WEIGHTING BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(features_df)} | Symbols: {features_df['symbol'].nunique()}")
    report.append("=" * 70)

    import io
    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)

    report.append("\n" + "=" * 70)
    report.append("SYSTEM COMPARISON")
    report.append("=" * 70)

    results = []
    results.append(evaluate_system(features_df, "grade_no_vix", "A. NO VIX (quality only)"))
    results.append(evaluate_system(features_df, "grade_flat", "B. FLAT VIX (+0/+2/+3/+4)"))
    results.append(evaluate_system(features_df, "grade_prop", "C. PROPORTIONAL (×1.0/×1.10/×1.15/×1.25)"))

    report.append(buf.getvalue())
    logger.removeHandler(handler)

    # ── Summary comparison ───────────────────────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("SUMMARY")
    report.append("=" * 70)
    report.append(f"\n  {'System':45s} {'Breaks':>7s} {'Sep':>8s} {'Corr':>7s}")
    for r in results:
        report.append(f"  {r['name']:45s} {r['breaks']:7d} {r['separation']:+7.1f}pp {r['correlation']:6.4f}")

    best = max(results, key=lambda r: r["correlation"])
    report.append(f"\n  WINNER (highest grade→PnL correlation): {best['name']}")

    # ── Multiplier sweep ─────────────────────────────────────────────────
    buf2 = io.StringIO()
    handler2 = logging.StreamHandler(buf2)
    handler2.setLevel(logging.INFO)
    handler2.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler2)

    optimal = sweep_multipliers(features_df)

    report.append(buf2.getvalue())
    logger.removeHandler(handler2)

    # ── VIX regime × grade cross-tab ─────────────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("CROSS-TAB: Win rate by VIX regime × Proportional grade")
    report.append("=" * 70)

    for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
        vr_mask = features_df["vix_regime"] == vr
        report.append(f"\n  {vr}:")
        for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
            mask = vr_mask & (features_df["grade_prop"] == g)
            n = mask.sum()
            if n < 5:
                continue
            wr = features_df.loc[mask, "win"].mean() * 100
            avg = features_df.loc[mask, "pnl_pct"].mean()
            report.append(f"    {g:3s}: N={n:4d}  win={wr:.1f}%  avg={avg:+.3f}%")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
