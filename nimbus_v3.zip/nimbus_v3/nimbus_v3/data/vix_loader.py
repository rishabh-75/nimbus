"""nimbus_v3.data.vix_loader — India VIX loader with three-tier fallback.

India VIX is the single most important market-wide input for the grade
formula (VIX regime, high-streak gating for MR/BO). Availability therefore
matters more than fetch speed or freshness — the loader tries three
sources in order, accepting the first that produces a usable value.

Fallback tiers for the **current** VIX value
────────────────────────────────────────────
1. **NSE live endpoint**. Fastest and most authoritative. Uses the shared
   ``NSEClient`` (subject to cookie isolation and cooldown policy).
2. **yfinance intraday 5-minute** (``^INDIAVIX``). Returned as the latest
   close. ~15-minute lag during market hours.
3. **yfinance daily close** (``^INDIAVIX``). Yesterday's close if today's
   isn't populated yet.

If all three fail, :meth:`load_current` returns ``None``. Callers (the
``MarketContextProvider``) treat ``None`` as "VIX unknown → regime
undefined" rather than falling back to a stale cached value for the
current bar, because a grade computed with a stale VIX is a grade that
will desync between the live scanner and the research harness.

Fallback for VIX **history**
────────────────────────────
History is used for regime classification, the HIGH-streak counter, and
the sector-vol z-score baseline. Only yfinance daily is reliable enough
for this at scale — NSE's history endpoint has been flaky in probing.
History is cached as parquet with a 24-hour TTL. Callers needing a
specific ``asof_date`` slice the returned frame themselves.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Final

import pandas as pd
import yfinance as yf

from nimbus_v3.data.base import CacheStore
from nimbus_v3.data.nse_client import NSEClient


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Endpoints + defaults
# ══════════════════════════════════════════════════════════════════════════════

#: NSE live VIX endpoint. Returns a JSON payload whose shape includes a
#: top-level "Value" field or an "allIndices" array containing an entry
#: with symbol "INDIA VIX". The parser handles both shapes.
_NSE_VIX_ENDPOINT: Final[str] = "https://www.nseindia.com/api/allIndices"
_NSE_VIX_REFERER: Final[str] = "https://www.nseindia.com/market-data/live-market-indices"

#: yfinance symbol for India VIX.
_YF_SYMBOL: Final[str] = "^INDIAVIX"

#: Cache key for the history parquet. Single-key namespace scoped by the
#: injected CacheStore's base directory.
_HISTORY_CACHE_KEY: Final[str] = "history"

#: Default TTL for cached VIX history.
_DEFAULT_HISTORY_TTL: Final[timedelta] = timedelta(hours=24)

#: Default history depth.
_DEFAULT_HISTORY_YEARS: Final[int] = 5


# ══════════════════════════════════════════════════════════════════════════════
# Loader
# ══════════════════════════════════════════════════════════════════════════════

class VIXLoader:
    """India VIX loader with three-tier current-value fallback and
    cached history.

    Thread-safe for independent calls to :meth:`load_current` and
    :meth:`load_history`. Concurrent calls to :meth:`load_history` that
    both miss the cache will both hit yfinance — acceptable cost, not
    worth adding a second lock here.
    """

    def __init__(
        self,
        nse_client: NSEClient,
        cache: CacheStore,
        *,
        default_history_years: int = _DEFAULT_HISTORY_YEARS,
        default_history_ttl: timedelta = _DEFAULT_HISTORY_TTL,
    ) -> None:
        """Args:
            nse_client: Shared NSE client.
            cache: CacheStore scoped to the VIX namespace (e.g.
                ``ParquetCache(Path("data/cache/vix"))``).
            default_history_years: History depth for the first fetch.
            default_history_ttl: Refetch threshold for cached history.
        """
        self._nse = nse_client
        self._cache = cache
        self._default_years = default_history_years
        self._default_ttl = default_history_ttl

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def load_current(self) -> float | None:
        """Return the most recent VIX value, or ``None`` if all tiers fail.

        Tries the three fallback tiers in order. The first tier to return
        a finite value wins.
        """
        # Tier 1: NSE live.
        value = self._try_nse_live()
        if value is not None:
            return value

        # Tier 2: yfinance intraday (5-min bars).
        value = self._try_yfinance_intraday()
        if value is not None:
            return value

        # Tier 3: yfinance daily.
        value = self._try_yfinance_daily()
        if value is not None:
            return value

        logger.warning("vix_loader: all three tiers failed for current VIX")
        return None

    def load_history(
        self,
        *,
        years: int | None = None,
        cache_ttl: timedelta | None = None,
        force_refresh: bool = False,
    ) -> pd.DataFrame:
        """Return the full India VIX daily history as a DataFrame.

        Columns: ``Open``, ``High``, ``Low``, ``Close``, ``Volume``
        (``Volume`` is typically zero for an index, kept for schema
        symmetry with the price loader's output). Index is a tz-naive,
        ascending ``DatetimeIndex``.

        Args:
            years: History depth on a fresh fetch. Defaults to the
                constructor value.
            cache_ttl: Max age before cache is considered stale.
            force_refresh: Bypass the cache.

        Returns:
            DataFrame. Empty if yfinance fails and no cache is available.
        """
        years = years if years is not None else self._default_years
        ttl = cache_ttl if cache_ttl is not None else self._default_ttl

        if not force_refresh and self._cache_is_fresh(ttl):
            cached = self._cache.get(_HISTORY_CACHE_KEY)
            if cached is not None:
                return cached

        fetched = self._download_history(years=years)
        if fetched.empty:
            cached = self._cache.get(_HISTORY_CACHE_KEY)
            if cached is not None:
                logger.info(
                    "vix_loader: yfinance history empty; falling back to stale cache"
                )
                return cached
            logger.warning("vix_loader: no VIX history available (yfinance empty, no cache)")
            return fetched

        self._cache.set(_HISTORY_CACHE_KEY, fetched)
        return fetched

    def load_value_on(
        self,
        asof_date: pd.Timestamp,
        *,
        years: int | None = None,
    ) -> float | None:
        """Return the VIX close on or immediately before ``asof_date``.

        Used by the research harness for historical reconstruction. The
        bar returned is the most recent daily close at-or-before the
        requested date (to avoid forward-peeking at an intraday value
        that wouldn't have been observable on ``asof_date``).

        Returns ``None`` if no bar exists at or before ``asof_date``.
        """
        history = self.load_history(years=years)
        if history.empty:
            return None
        # Ensure tz-naive for comparison.
        asof = pd.Timestamp(asof_date)
        if asof.tz is not None:
            asof = asof.tz_localize(None)
        eligible = history.loc[:asof]
        if eligible.empty:
            return None
        value = float(eligible["Close"].iloc[-1])
        if pd.isna(value):
            return None
        return value

    # ══════════════════════════════════════════════════════════════════════
    # Tier 1: NSE live
    # ══════════════════════════════════════════════════════════════════════

    def _try_nse_live(self) -> float | None:
        payload = self._nse.fetch(
            _NSE_VIX_ENDPOINT, referer=_NSE_VIX_REFERER,
        )
        if not payload:
            return None
        value = _extract_nse_vix_value(payload)
        if value is None:
            logger.debug("vix_loader: NSE payload had no India VIX row")
        return value

    # ══════════════════════════════════════════════════════════════════════
    # Tier 2: yfinance intraday
    # ══════════════════════════════════════════════════════════════════════

    def _try_yfinance_intraday(self) -> float | None:
        try:
            df = yf.download(
                tickers=_YF_SYMBOL,
                period="1d",
                interval="5m",
                auto_adjust=False,
                progress=False,
                threads=False,
            )
        except Exception as exc:
            logger.debug("vix_loader: yfinance intraday failed: %s", exc)
            return None
        return _last_close(df)

    # ══════════════════════════════════════════════════════════════════════
    # Tier 3: yfinance daily
    # ══════════════════════════════════════════════════════════════════════

    def _try_yfinance_daily(self) -> float | None:
        try:
            df = yf.download(
                tickers=_YF_SYMBOL,
                period="10d",
                interval="1d",
                auto_adjust=False,
                progress=False,
                threads=False,
            )
        except Exception as exc:
            logger.debug("vix_loader: yfinance daily failed: %s", exc)
            return None
        return _last_close(df)

    # ══════════════════════════════════════════════════════════════════════
    # History helpers
    # ══════════════════════════════════════════════════════════════════════

    def _cache_is_fresh(self, ttl: timedelta) -> bool:
        age = self._cache.age(_HISTORY_CACHE_KEY)
        if age is None:
            return False
        return age < ttl

    def _download_history(self, *, years: int) -> pd.DataFrame:
        # IST-aware end boundary so we don't miss today's VIX close.
        # See price_loader._download_from_yfinance for the full
        # rationale — same bug, same fix.
        ist = timezone(timedelta(hours=5, minutes=30))
        today_ist = datetime.now(tz=ist).date()
        end = today_ist + timedelta(days=1)
        start = today_ist - timedelta(days=years * 365 + 7)
        try:
            raw = yf.download(
                tickers=_YF_SYMBOL,
                start=start.isoformat(),
                end=end.isoformat(),
                interval="1d",
                auto_adjust=False,
                progress=False,
                threads=False,
            )
        except Exception as exc:
            logger.warning("vix_loader: yfinance history fetch raised: %s", exc)
            return pd.DataFrame()
        return _normalize_history(raw)


# ══════════════════════════════════════════════════════════════════════════════
# Payload parsing — isolated for unit testing
# ══════════════════════════════════════════════════════════════════════════════

def _extract_nse_vix_value(payload: dict | list) -> float | None:
    """Pull the India VIX last price from NSE's allIndices payload.

    NSE's ``allIndices`` response contains a ``data`` array of index
    snapshots. Each has ``index`` (or ``indexSymbol``) and ``last``
    (or ``lastPrice``) fields. India VIX's row has ``index="INDIA VIX"``
    and ``last=<current value>``. The parser tolerates both naming
    conventions NSE has shipped over the years.
    """
    if not isinstance(payload, dict):
        return None
    rows = payload.get("data")
    if not isinstance(rows, list):
        return None
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = (row.get("index") or row.get("indexSymbol") or "").upper()
        if "INDIA VIX" not in name:
            continue
        raw_value = row.get("last")
        if raw_value is None:
            raw_value = row.get("lastPrice")
        value = _safe_float(raw_value)
        if value is not None and value > 0:
            return value
    return None


def _last_close(df: pd.DataFrame) -> float | None:
    """Return the last non-NaN ``Close`` from a yfinance frame, or None."""
    if df is None or df.empty:
        return None
    # Handle MultiIndex columns (yfinance wraps single-symbol results).
    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = df.columns.get_level_values(0)
    if "Close" not in df.columns:
        return None
    closes = df["Close"].dropna()
    if closes.empty:
        return None
    value = float(closes.iloc[-1])
    if pd.isna(value) or value <= 0:
        return None
    return value


def _normalize_history(raw: pd.DataFrame) -> pd.DataFrame:
    """Normalise the yfinance history frame to the project contract.

    Same shape as ``PriceLoader._normalize`` but tolerates the missing
    ``Volume`` column for index tickers: if absent, we insert a zero
    column rather than failing, because the compute engine's contract
    requires it.
    """
    if raw is None or raw.empty:
        return pd.DataFrame()
    df = raw.copy()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    if "Volume" not in df.columns:
        df["Volume"] = 0.0
    wanted = [c for c in ("Open", "High", "Low", "Close", "Volume") if c in df.columns]
    df = df[wanted]
    if df.index.tz is not None:
        df.index = df.index.tz_localize(None)
    df = df.sort_index()
    df = df[~df.index.duplicated(keep="last")]
    price_cols = [c for c in ("Open", "High", "Low", "Close") if c in df.columns]
    if price_cols:
        df = df.dropna(subset=price_cols, how="all")
    return df


def _safe_float(value: object) -> float | None:
    if value is None:
        return None
    try:
        if isinstance(value, str):
            value = value.replace(",", "").strip()
            if not value or value == "-":
                return None
        return float(value)
    except (TypeError, ValueError):
        return None
