"""nimbus_v3.core.industry_relative_state — per-(symbol, bar) state
of a stock relative to its industry.

This is the join output: a stock's own metrics + its industry's state
+ derived quantities (beta, alpha) that only make sense relative to
the industry. Produced by ``IndustryAnalyticsEngine`` and consumed by
the UI (Market Pulse constituent table, Dashboard sidebar, ranking
penalties / bonuses).

Design principles
─────────────────
- **Frozen**: safe across threads, usable as dict keys.
- **Self-describing**: every field is documented with the research
  finding that justifies its presence. Fields that aren't backed by
  a validated signal should NOT be added without running the
  ablation harness first.
- **No behaviour**: same pattern as ``SignalState`` and
  ``IndustryState``. Helpers live in consumers, not here.
- **Composite tags pre-computed**: boolean flags like
  ``is_alpha_leader`` are baked in rather than computed at read
  time. The thresholds come from ablation, not from consumer
  preference — so the producer is the right place to apply them.
  This means UI code reads a bool, not a threshold.

Thresholds baked in (from research)
───────────────────────────────────
- ``is_alpha_leader``: alpha_60d > +0.416%/day (panel top 10%,
  fwd_20d delta +2.00pp, t=+27.58, n=49,273)
- ``is_high_beta_rider``: beta_60d > 1.5 AND industry_phase in
  {"MID", "LATE"} (fwd_20d delta +0.62pp, t=+4.03, n=7,368)
- ``is_low_beta_quality``: beta_60d < 0.8 AND industry_phase in
  {"MID", "LATE"} (CONTRA direction: fwd_20d delta +1.45pp,
  t=+39.99, n=148,491 — the largest effect in the research,
  interpreted as a quality-factor proxy)
- ``is_industry_declining``: industry_phase == "DECLINE"
  (for position-sizing warnings — not a forward-return signal
  per se but a risk flag)

Warmup
──────
Requires ≥60 bars of stock history aligned to the industry index,
so ``data_sufficient`` is ``False`` for early bars even when the
underlying ``SignalState`` has warmed up.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class IndustryRelativeState:
    """Per-(symbol, bar) state relative to the stock's industry.

    All numeric fields are native ``float``. Boolean composite tags
    are computed by the engine at construction time using thresholds
    documented in this module's docstring.
    """

    # ── Identity ─────────────────────────────────────────────────────────
    symbol: str                         #: ticker (no .NS suffix)
    bar_date: pd.Timestamp              #: the date this state applies to
    industry: str                       #: symbol's industry on this bar

    # ── Core signals (the research winners) ──────────────────────────────
    #: 60-day rolling β vs leave-one-out industry EW return. Measures
    #: how sensitive the stock is to its industry's moves. β > 1.0 =
    #: amplifier, β < 1.0 = dampener, β < 0 = contrarian within sector.
    beta_60d: float
    #: 60-day mean residual return (%/day). Computed as
    #: ``mean(stock_ret - β × industry_ret)`` over the window. Positive
    #: = stock outperforming its industry-implied return (this is the
    #: signal that earned +2.00pp/20d at t=27.58 for top decile).
    alpha_60d: float
    #: Where this stock's ``alpha_60d`` ranks in the panel at this bar,
    #: expressed as a percentile (0.0-100.0). Pre-computed to save
    #: consumers the cost of re-ranking. Panel-wide, not
    #: industry-internal — the research validated against the panel
    #: distribution.
    alpha_percentile: float

    # ── Industry context (mirror of IndustryState.phase) ─────────────────
    #: Industry phase at this bar, mirrored here for convenience so
    #: UI code doesn't need a second lookup. One of ``"EARLY"``,
    #: ``"MID"``, ``"LATE"``, ``"EUPHORIA"``, ``"NEUTRAL"``,
    #: ``"DECLINE"``.
    industry_phase: str
    #: Industry's 20-day rate-of-change on its EW close (%). Context
    #: for the phase label — "LATE with ROC_20 +4%" is very different
    #: from "LATE with ROC_20 -1%". Not a signal on its own.
    industry_roc_20: float
    #: Fraction of industry members above their 20-day SMA on this
    #: bar, 0.0-1.0. Breadth context: LATE with 80% above SMA_20
    #: means the move is broad-based; LATE with 40% breadth means
    #: a few names are carrying the index. Not a signal on its own.
    industry_breadth_pct: float
    #: Number of industry members that produced a valid 60d return
    #: at this bar. Passed through from IndustryState for statistical
    #: honesty — an industry with 6 peers deserves lower confidence
    #: than one with 30.
    peer_count_in_industry: int
    #: The stock's rank by 60-day return within its industry, 1-based
    #: (1 = best performer, N = worst). Answers "is this stock leading
    #: or lagging its peers?" directly, complementing β (sensitivity)
    #: and α (residual). Computed in ``analyze_symbol`` via a
    #: per-industry sort — see the engine's docstring. Value is 0
    #: when peer_count_in_industry < 2 (rank is ill-defined).
    peer_rank_in_industry: int

    # ── Composite tags (ablation-validated) ──────────────────────────────
    #: ``True`` when ``alpha_60d > +0.00416`` (panel top 10%, ~0.42%/day).
    #: Forward 20d edge: +2.00pp, t=+27.58. The strongest signal in
    #: the relative-state research.
    is_alpha_leader: bool
    #: ``True`` when ``beta_60d > 1.5 AND industry_phase in {"MID","LATE"}``.
    #: Forward 20d edge: +0.62pp, t=+4.03. Small sample (n=7,368) but
    #: the directional hypothesis was confirmed.
    is_high_beta_rider: bool
    #: ``True`` when ``beta_60d < 0.8 AND industry_phase in {"MID","LATE"}``.
    #: Forward 20d edge: +1.45pp, t=+39.99 (CONTRA direction — we
    #: expected negative, got strongly positive). Interpreted as
    #: low-beta = quality-factor proxy rather than sector laggard.
    is_low_beta_quality: bool
    #: ``True`` when ``industry_phase == "DECLINE"``. Not a forward-return
    #: signal on its own — a risk flag for position sizing. Research
    #: showed low-β defensives in declining industries actually
    #: UNDERPERFORM (fwd 20d -1.18pp, t=-29.90), contrary to the
    #: "defensives hold up" intuition.
    is_industry_declining: bool
    #: ``True`` when the stock shows a volume-accumulation pattern:
    #: ``vol_chg_60 > +30% AND roc_5 > 0 AND close > sma_20 AND
    #: close < 1.15 × sma_50`` (basing topology near 60d low region).
    #: Forward 20d edge: **+0.76pp, t=+12.25, n=39,918** on the full
    #: 535K-row panel (463 symbols, 6 years) — STRONG working per
    #: the research script's verdict rules. The 10d edge is weak
    #: (+0.20pp, t=+4.60) so this is a 2-week holding-period signal.
    #: Formula matches ``accumulation_signature`` in
    #: ``scripts/run_volume_feature_research.py``. Computed here
    #: despite being stock-level not industry-relative because the
    #: UI tag pipeline already reads this state object — placing it
    #: elsewhere would require plumbing. See
    #: ``IndustryAnalyticsEngine.enrich_symbol_relative``.
    is_accumulating: bool
    #: ``True`` when the stock is an ALPHA leader (top-decile panel
    #: alpha) BUT its current close is below its own 20-day SMA —
    #: i.e. the cumulative outperformance is still real but the
    #: current trend structure is breaking down. The "momentum
    #: fading on an outperformer" pattern.
    #:
    #: Forward 20d edge on the ALPHA cohort: **-1.25pp, t=-8.21,
    #: n=12,457 warned fires** on the 491K-row panel. ALPHA-specific:
    #: the non-ALPHA cohort with the same warning only sees -0.75pp,
    #: so ALPHA stocks get an additional -0.5pp of punishment when
    #: they break their sma_20 vs the broad panel (1.7× amplification).
    #:
    #: Decile report within ALPHA shows a clean monotonic progression:
    #: ALPHA stocks 3-35% BELOW their sma_20 earn +1.67pp fwd-20d,
    #: stocks 16-92% ABOVE earn +5.10pp — a +3.43pp spread. The
    #: warning doesn't just flag the negative tail; it measures a
    #: continuum where "below sma_20" is the breakpoint.
    #:
    #: Research: ``scripts/run_alpha_warning_research.py``. Formula:
    #: ``is_alpha_leader AND close < sma_20``. Intentionally fires
    #: ONLY on ALPHA stocks — the warning is about ALPHA
    #: degradation specifically, not a general bearish signal.
    is_alpha_fading: bool

    # ── Data quality ─────────────────────────────────────────────────────
    #: ``True`` when all fields have reliable values. Requires at least
    #: 60 bars of stock history aligned to a valid industry series
    #: (which itself needs its own warmup).
    data_sufficient: bool


@dataclass(frozen=True)
class ThinPeerContext:
    """Partial industry context rendered when peer-relative analytics
    can't be computed.

    Fires when the symbol's industry has fewer than
    ``IndustryAnalyticsEngine.MIN_INDUSTRY_SIZE`` (=5) members in the
    loaded panel. Beta / alpha / peer rank are undefined without a
    meaningful peer group, so the UI shows only the industry
    identity + member count — the operator sees WHY the context is
    missing rather than a generic "unavailable" placeholder.

    Example render:
        "INDUSTRY  Healthcare Equipment & Supplies · 1 member ·
         peer analytics require ≥5"
    """

    #: Industry name. Always populated.
    industry: str

    #: Number of peers present in the loaded panel. ``1`` when the
    #: symbol is the only member; 0 isn't really possible (the
    #: symbol itself is a member).
    n_members: int

    #: Minimum required for peer analytics. Included so the UI
    #: message is self-documenting — if ``MIN_INDUSTRY_SIZE``
    #: changes we don't have to edit the card's label text.
    min_required: int
