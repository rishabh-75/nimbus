"""Universe-wide CONT continuation model.

Trains a logistic regression on the feature set extracted by
:mod:`extract` for every CONT-bar fire across the panel.

Target
──────
Per the operator spec, the positive label is "the ride
continues for ≥ N more bars after this CONT bar", where N is
the symbol-specific historical median ride-hold duration. The
median is computed from that symbol's resolved INIT/RETEST/CONT
fires by :mod:`aggregate` and threaded through.

So a CONT bar at index t is positive iff there exists some bar
t+k (k ≥ N) where the ride was still active. Concretely: the
ride exit (Close < bb_upper) must occur at index t + N_sym or
later. If the ride exits sooner, label is 0. If the ride is
still open at end-of-history, the bar is excluded from training
(can't observe the outcome).

Training
────────
Walk-forward split: for each symbol, the chronologically first
70% of CONT bars are train, last 30% are test. That respects
look-ahead-safety at the corpus level — we never train on a
CONT bar that's later than a test bar in the same symbol.

Logistic regression with L2 regularisation, fit via
scipy.optimize.minimize. Standardisation parameters
(feature_means, feature_stds) are saved so predict-time can
re-standardise with the training distribution.

Calibration is reported via Brier score on the held-out test
set — lower is better, perfect = 0.
"""
from __future__ import annotations

import json
import logging
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.optimize import minimize    # type: ignore[import-untyped]

from .schema import (
    ContModelMetadata,
    FireEvent,
    PhaseWinRateStats,
)


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Feature names — order is the contract; coefficients align to this.
# ══════════════════════════════════════════════════════════════════════════════

CONT_MODEL_FEATURES: tuple[str, ...] = (
    "pct_b_at_trigger",
    "sma20_slope_pct",
    "sma50_slope_pct",
    "bb_width_pctile",
    "vol_ratio_20",
    "atr_14_pct",
    "bars_since_sma20_above_sma50",
    "body_above_count_prior_5",
)

#: L2 regularisation strength for logistic regression. Mild —
#: we have ~1000s of CONT events so regularisation is more
#: about numerical stability than overfitting protection.
L2_LAMBDA: float = 0.01

#: Train/test split fraction (per-symbol walk-forward).
TRAIN_FRAC: float = 0.70


# ══════════════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════════════


def build_cont_training_set(
    cont_events: Iterable[FireEvent],
    horizons: dict[str, int] | int,
) -> pd.DataFrame:
    """Build a labelled dataframe for CONT model training.

    Args:
        cont_events: only events with ``phase == "CONT"``.
        horizons: either
            - ``dict[symbol, N]`` for per-symbol horizons (the
              "median_hold" label kind), or
            - a single ``int`` for the universe-wide
              "fixed_horizon" label kind.

            Open rides (no observable outcome) are excluded.
            For the dict variant, symbols missing from the
            mapping are excluded.

    Returns:
        DataFrame with columns: feature columns, ``y`` (0/1
        label), ``symbol``, ``trigger_idx``.
    """
    is_int_horizon = isinstance(horizons, int)
    rows = []
    for ev in cont_events:
        if ev.phase != "CONT":
            continue
        if not ev.is_resolved or ev.hold_bars is None:
            continue

        if is_int_horizon:
            n_horizon = horizons    # type: ignore[assignment]
        else:
            n_horizon = horizons.get(ev.symbol)    # type: ignore[union-attr]
            if n_horizon is None:
                continue
        if n_horizon <= 0:
            continue

        label = 1 if ev.hold_bars >= n_horizon else 0
        row = {f: getattr(ev, f) for f in CONT_MODEL_FEATURES}
        row["y"] = label
        row["symbol"] = ev.symbol
        row["trigger_idx"] = ev.trigger_idx
        rows.append(row)
    return pd.DataFrame(rows)


def walk_forward_split(
    df: pd.DataFrame, *, train_frac: float = TRAIN_FRAC,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Per-symbol walk-forward split.

    For each symbol, the chronologically first ``train_frac``
    of its CONT events go to train, the rest to test. Done at
    symbol level rather than corpus level to ensure every
    symbol contributes both train and test data — gives a
    fair calibration measurement.

    Symbols with fewer than 2 events are pushed entirely into
    train (no point splitting 1 event).
    """
    train_parts: list[pd.DataFrame] = []
    test_parts: list[pd.DataFrame] = []
    for sym, sub in df.groupby("symbol", sort=False):
        sub = sub.sort_values("trigger_idx")
        n = len(sub)
        if n < 2:
            train_parts.append(sub)
            continue
        n_train = max(1, int(np.floor(n * train_frac)))
        train_parts.append(sub.iloc[:n_train])
        test_parts.append(sub.iloc[n_train:])
    train_df = pd.concat(train_parts, ignore_index=True)
    test_df = (
        pd.concat(test_parts, ignore_index=True)
        if test_parts else pd.DataFrame(columns=df.columns)
    )
    return train_df, test_df


def fit_logistic(
    X_train: np.ndarray,
    y_train: np.ndarray,
    *,
    l2: float = L2_LAMBDA,
) -> tuple[np.ndarray, float]:
    """Fit a logistic regression by direct optimization.

    Minimises NLL + L2 penalty on coefficients (intercept
    excluded from penalty, as is conventional).

    Args:
        X_train: standardised feature matrix, shape (n, k).
        y_train: 0/1 labels, shape (n,).
        l2: regularisation strength.

    Returns:
        ``(coefficients, intercept)`` — coefficients shape (k,).
    """
    n, k = X_train.shape

    def loss(theta: np.ndarray) -> float:
        b = theta[0]
        w = theta[1:]
        logits = X_train @ w + b
        # Numerically stable log(1 + exp(z)).
        log1pexp = np.logaddexp(0.0, logits)
        nll = (log1pexp - y_train * logits).mean()
        reg = 0.5 * l2 * (w @ w)
        return float(nll + reg)

    def grad(theta: np.ndarray) -> np.ndarray:
        b = theta[0]
        w = theta[1:]
        logits = X_train @ w + b
        p = 1.0 / (1.0 + np.exp(-logits))
        diff = (p - y_train)
        gb = diff.mean()
        gw = (X_train.T @ diff) / n + l2 * w
        return np.concatenate([[gb], gw])

    theta0 = np.zeros(k + 1)
    result = minimize(loss, theta0, jac=grad, method="L-BFGS-B")
    if not result.success:
        logger.warning(
            "fit_logistic: optimizer reported failure: %s", result.message,
        )
    theta = result.x
    return theta[1:], float(theta[0])


def predict_proba(
    X: np.ndarray, coefficients: np.ndarray, intercept: float,
) -> np.ndarray:
    """Logistic predictions in [0, 1] for a standardised X."""
    logits = X @ coefficients + intercept
    return 1.0 / (1.0 + np.exp(-logits))


def train_cont_model(
    cont_events: Iterable[FireEvent],
    init_retest_stats: list[PhaseWinRateStats],
    *,
    universe_p_win_init: float,
    universe_p_win_retest: float,
    universe_p_win_cont: float,
    label_kind: str = "median_hold",
    fixed_horizon: int | None = None,
) -> tuple[ContModelMetadata, pd.DataFrame, pd.DataFrame]:
    """End-to-end: build training set, split, standardise, fit,
    evaluate.

    Args:
        cont_events: every CONT-phase :class:`FireEvent`.
        init_retest_stats: per-symbol stats — used to compute
            symbol horizons for ``label_kind="median_hold"``.
        universe_p_win_*: the three universe rates baked into
            metadata for downstream interpretation.
        label_kind:
            - ``"median_hold"``: positive iff the ride continues
              for ≥ the symbol's overall median ride-hold bars
              (taken across all phases the symbol has stats for).
              Original operator spec; tends to give a roughly
              50/50 label balance per symbol.
            - ``"fixed_horizon"``: positive iff the ride
              continues for ≥ ``fixed_horizon`` bars. Uniform
              meaning across the universe; lets the operator
              compare AUROC against the median variant.
        fixed_horizon: required when ``label_kind ==
            "fixed_horizon"``.

    Returns:
        ``(metadata, train_df, test_df)`` for inspection /
        saving. The train/test dataframes include features,
        labels, ``symbol``, and ``trigger_idx``.
    """
    if label_kind not in ("median_hold", "fixed_horizon"):
        raise ValueError(
            f"label_kind must be 'median_hold' or 'fixed_horizon', "
            f"got {label_kind!r}"
        )
    if label_kind == "fixed_horizon" and not fixed_horizon:
        raise ValueError(
            "fixed_horizon must be a positive int when "
            "label_kind='fixed_horizon'"
        )

    if label_kind == "median_hold":
        # Per-symbol horizon = median of that symbol's
        # phase-medians. If a symbol has CONT stats
        # median_hold_bars=4 and RETEST median=6 we use the
        # median of [4, 6] = 5.
        by_sym: dict[str, list[int]] = {}
        for s in init_retest_stats:
            if s.median_hold_bars > 0:
                by_sym.setdefault(s.symbol, []).append(s.median_hold_bars)
        horizons: dict[str, int] | int = {
            sym: int(np.median(holds)) for sym, holds in by_sym.items()
        }
        horizon_value = 0
    else:
        horizons = int(fixed_horizon)    # type: ignore[arg-type]
        horizon_value = int(fixed_horizon)    # type: ignore[arg-type]

    df = build_cont_training_set(cont_events, horizons)
    if df.empty:
        raise ValueError(
            "no usable CONT events after horizon filtering — "
            "train_cont_model can't fit"
        )

    train_df, test_df = walk_forward_split(df)

    X_train_raw = train_df[list(CONT_MODEL_FEATURES)].to_numpy(dtype=float)
    y_train = train_df["y"].to_numpy(dtype=int)
    means = X_train_raw.mean(axis=0)
    stds = X_train_raw.std(axis=0)
    stds = np.where(stds < 1e-9, 1.0, stds)
    X_train = (X_train_raw - means) / stds

    coef, intercept = fit_logistic(X_train, y_train)

    p_train = predict_proba(X_train, coef, intercept)
    train_acc = float(((p_train >= 0.5) == y_train.astype(bool)).mean())
    train_auroc = _auroc(y_train, p_train)
    train_pos_rate = float(y_train.mean()) if len(y_train) else float("nan")

    if not test_df.empty:
        X_test_raw = test_df[list(CONT_MODEL_FEATURES)].to_numpy(dtype=float)
        y_test = test_df["y"].to_numpy(dtype=int)
        X_test = (X_test_raw - means) / stds
        p_test = predict_proba(X_test, coef, intercept)
        test_acc = float(((p_test >= 0.5) == y_test.astype(bool)).mean())
        test_auroc = _auroc(y_test, p_test)
        test_brier = float(((p_test - y_test) ** 2).mean())
        test_pos_rate = float(y_test.mean())
    else:
        test_acc = float("nan")
        test_auroc = float("nan")
        test_brier = float("nan")
        test_pos_rate = float("nan")

    meta = ContModelMetadata(
        label_kind=label_kind,
        horizon_value=horizon_value,
        feature_names=tuple(CONT_MODEL_FEATURES),
        coefficients=tuple(float(c) for c in coef),
        intercept=intercept,
        n_train=len(train_df),
        n_test=len(test_df),
        train_accuracy=train_acc,
        test_accuracy=test_acc,
        train_auroc=train_auroc,
        test_auroc=test_auroc,
        test_brier=test_brier,
        train_pos_rate=train_pos_rate,
        test_pos_rate=test_pos_rate,
        feature_means=tuple(float(m) for m in means),
        feature_stds=tuple(float(s) for s in stds),
        universe_p_win_init=universe_p_win_init,
        universe_p_win_retest=universe_p_win_retest,
        universe_p_win_cont=universe_p_win_cont,
    )

    return meta, train_df, test_df


def predict_with_metadata(
    feature_row: dict, meta: ContModelMetadata,
) -> float:
    """Apply a saved ContModelMetadata to a fresh feature row.

    Used at scoring time: take the latest CONT fire's features
    and produce its win probability. Standardisation uses the
    training means/stds saved in the metadata so the model is
    self-contained — no need to re-fit or load training data.
    """
    x = np.array(
        [feature_row[f] for f in meta.feature_names], dtype=float,
    )
    x_std = (x - np.array(meta.feature_means)) / np.array(meta.feature_stds)
    logit = float(x_std @ np.array(meta.coefficients) + meta.intercept)
    return float(1.0 / (1.0 + np.exp(-logit)))


def save_model_metadata(meta: ContModelMetadata, path: Path) -> None:
    """Serialise ContModelMetadata to JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        json.dump(asdict(meta), f, indent=2)


def load_model_metadata(path: Path) -> ContModelMetadata:
    """Deserialise from JSON."""
    with path.open() as f:
        d = json.load(f)
    return ContModelMetadata(
        label_kind=str(d.get("label_kind", "median_hold")),
        horizon_value=int(d.get("horizon_value", 0)),
        feature_names=tuple(d["feature_names"]),
        coefficients=tuple(d["coefficients"]),
        intercept=float(d["intercept"]),
        n_train=int(d["n_train"]),
        n_test=int(d["n_test"]),
        train_accuracy=float(d["train_accuracy"]),
        test_accuracy=float(d["test_accuracy"]),
        train_auroc=float(d["train_auroc"]),
        test_auroc=float(d["test_auroc"]),
        test_brier=float(d["test_brier"]),
        train_pos_rate=float(d.get("train_pos_rate", float("nan"))),
        test_pos_rate=float(d.get("test_pos_rate", float("nan"))),
        feature_means=tuple(d["feature_means"]),
        feature_stds=tuple(d["feature_stds"]),
        universe_p_win_init=float(d["universe_p_win_init"]),
        universe_p_win_retest=float(d["universe_p_win_retest"]),
        universe_p_win_cont=float(d["universe_p_win_cont"]),
    )


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════


def _auroc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """Area under ROC curve via the Mann-Whitney U statistic.

    Equivalent to sklearn's roc_auc_score for the binary case.
    NaN when only one class is present (AUC undefined).
    """
    pos_mask = y_true == 1
    n_pos = int(pos_mask.sum())
    n_neg = len(y_true) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    pos_scores = y_score[pos_mask]
    neg_scores = y_score[~pos_mask]
    # Tally positives ranked above negatives, with ties counted half.
    n_correct = 0.0
    for ps in pos_scores:
        n_correct += float(np.sum(ps > neg_scores))
        n_correct += 0.5 * float(np.sum(ps == neg_scores))
    return float(n_correct / (n_pos * n_neg))
