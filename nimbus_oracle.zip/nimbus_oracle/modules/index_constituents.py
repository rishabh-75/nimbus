"""
modules/index_constituents.py — NSE index constituents (dynamic).

Fetches NIFTY 50 / NIFTY 100 constituents from NSE API via nse_client.
Caches to disk (data/index_cache.json) for offline / rate-limit fallback.

Usage:
    from modules.index_constituents import get_nifty50, get_nifty100, get_sector

    symbols = get_nifty50()          # ['ADANIENT', 'AXISBANK', ...]
    all100  = get_nifty100()         # NIFTY 50 + NEXT 50
    sector  = get_sector("RELIANCE") # "Energy"
"""
from __future__ import annotations

import json
import logging
import os
import time
from typing import Optional

logger = logging.getLogger(__name__)

_CACHE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "data", "index_cache.json"
)
_CACHE_TTL = 86400  # 24 hours


# ══════════════════════════════════════════════════════════════════════════════
# INDUSTRY → SECTOR MAPPING
# ══════════════════════════════════════════════════════════════════════════════

_INDUSTRY_SECTOR = {
    # ── Banks (split by ownership — PSU vs Private rotate independently) ──
    "Private Sector Bank": "Private Bank",
    "Public Sector Bank": "PSU Bank",
    "Other Bank": "Private Bank",  # small finance banks behave like private
    # ── IT ─────────────────────────────────────────────────────────────────
    "IT Consulting & Software": "IT", "IT - Software": "IT",
    "IT Services & Consulting": "IT", "Internet & Catalogue Retail": "IT",
    # ── Finance (non-bank: NBFCs, insurance, AMCs) ────────────────────────
    "Non Banking Financial Company (NBFC)": "Finance",
    "Housing Finance Company": "Finance", "Life Insurance": "Finance",
    "General Insurance": "Finance", "Financial Institution": "Finance",
    "Stock/Commodity Brokers": "Finance", "Asset Management Co.": "Finance",
    "Investment Company": "Finance", "Holding Company": "Finance",
    "Diversified Financials": "Finance", "Financial Services": "Finance",
    "Finance": "Finance",
    # ── Auto ───────────────────────────────────────────────────────────────
    "Passenger Cars & Utility Vehicles": "Auto", "2/3 Wheelers": "Auto",
    "Commercial Vehicles": "Auto", "Auto Components & Equipments": "Auto",
    "Auto Components": "Auto", "Automobile": "Auto", "Automobiles": "Auto",
    # ── Pharma (drug manufacturing) ───────────────────────────────────────
    "Pharmaceuticals": "Pharma", "Pharmaceuticals & Drugs": "Pharma",
    "Pharma & Drugs": "Pharma",
    # ── Healthcare (hospitals, diagnostics — separate rotation from drugs) ─
    "Healthcare": "Healthcare", "Hospital & Healthcare Services": "Healthcare",
    "Hospitals & Diagnostics": "Healthcare",
    # ── Metals ─────────────────────────────────────────────────────────────
    "Iron & Steel": "Metals", "Aluminium": "Metals", "Copper": "Metals",
    "Zinc": "Metals", "Mining": "Metals", "Diversified Metals": "Metals",
    "Non Ferrous Metals": "Metals",
    # ── Oil & Gas (upstream, refining, marketing, gas distribution) ───────
    "Oil Exploration & Production": "Oil & Gas",
    "Petroleum Products": "Oil & Gas", "Refineries": "Oil & Gas",
    "Oil Marketing & Distribution": "Oil & Gas",
    "Gas Transmission/Marketing": "Oil & Gas", "Gas Distribution": "Oil & Gas",
    # ── Energy / Power (generation, transmission — distinct from oil) ─────
    "Power Generation": "Power", "Power Generation & Distribution": "Power",
    "Power - Transmission": "Power", "Power Transmission": "Power",
    # ── Coal (commodity, PSU-heavy) ───────────────────────────────────────
    "Coal": "PSE",
    # ── FMCG ───────────────────────────────────────────────────────────────
    "FMCG": "FMCG", "Edible Oil": "FMCG", "Tea & Coffee": "FMCG",
    "Cigarettes/Tobacco": "FMCG", "Personal Products": "FMCG",
    "Household Products": "FMCG", "Consumer Food": "FMCG",
    "Packaged Foods": "FMCG", "Beverages": "FMCG", "Food Products": "FMCG",
    # ── Infra / Engineering ───────────────────────────────────────────────
    "Civil Construction": "Infra", "Construction": "Infra",
    "Infrastructure Developers": "Infra", "Ports": "Infra",
    "Railways": "Infra",
    "Heavy Electrical Equipment": "Industrials",
    "Electrical Equipment": "Industrials", "Engineering": "Industrials",
    "Industrial Manufacturing": "Industrials",
    "Industrial Conglomerates": "Industrials", "Capital Goods": "Industrials",
    "Capital Goods - Electrical Equipment": "Industrials",
    # ── Defence (separate rotation cycle from generic infra) ──────────────
    "Defence": "Defence", "Aerospace & Defense": "Defence",
    # ── Cement ─────────────────────────────────────────────────────────────
    "Cement": "Cement", "Cement & Cement Products": "Cement",
    # ── Consumer Discretionary (separate rotation from FMCG staples) ──────
    "Gems Jewellery And Watches": "Consumer", "Jewellery": "Consumer",
    "Retailing": "Consumer", "Department Stores": "Consumer",
    "Speciality Retail": "Consumer", "Hotels & Restaurants": "Consumer",
    "Hotels": "Consumer", "Paints": "Consumer",
    "Consumer Durables": "Consumer", "Consumer Electronics": "Consumer",
    "Household Appliances": "Consumer",
    "E-Commerce/App based Aggregator": "Consumer",
    # ── Telecom ────────────────────────────────────────────────────────────
    "Telecom - Cellular & Fixed line Services": "Telecom",
    "Telecom": "Telecom", "Telecommunications": "Telecom",
    # ── Other ──────────────────────────────────────────────────────────────
    "Agrochemicals": "Chemicals", "Specialty Chemicals": "Chemicals",
    "Chemicals": "Chemicals", "Real Estate Development": "Realty",
    "Realty": "Realty", "Entertainment": "Media",
    "Media & Entertainment": "Media", "Airlines": "Airlines",
    "Air Transport Service": "Airlines",
    # ── Additional (NIFTY 500 coverage) ──────────────────────────────────
    "Fertilizers": "Chemicals", "Pesticides & Agrochemicals": "Chemicals",
    "Dyes & Pigments": "Chemicals", "Petrochemicals": "Chemicals",
    "Sugar": "Consumer", "Textiles": "Consumer", "Apparels": "Consumer",
    "Footwear": "Consumer", "Leather": "Consumer",
    "Paper & Paper Products": "Industrials", "Packaging": "Industrials",
    "Plastic Products": "Industrials", "Rubber": "Industrials",
    "Glass": "Industrials", "Abrasives": "Industrials",
    "Tyres": "Auto", "Auto Ancillaries": "Auto",
    "Trading": "Finance", "Diversified": "Finance",
    "Logistics": "Infra", "Shipping": "Infra",
    "Renewable Energy": "Power", "Solar Energy": "Power",
    "Healthcare Services": "Healthcare", "Diagnostics": "Healthcare",
    "Education": "Consumer", "Digital Entertainment": "Media",
    "Fintech": "Finance", "Microfinance Institutions": "Finance",
}


def _map_industry_to_sector(industry: str) -> str:
    """Map NSE industry string to broad sector."""
    if not industry:
        return "Other"
    if industry in _INDUSTRY_SECTOR:
        return _INDUSTRY_SECTOR[industry]
    # Fuzzy: substring match
    il = industry.lower()
    for key, sector in _INDUSTRY_SECTOR.items():
        if key.lower() in il or il in key.lower():
            return sector
    return "Other"


# ══════════════════════════════════════════════════════════════════════════════
# CACHE
# ══════════════════════════════════════════════════════════════════════════════

def _load_cache() -> Optional[dict]:
    try:
        if not os.path.exists(_CACHE_PATH):
            return None
        with open(_CACHE_PATH) as f:
            cache = json.load(f)
        if time.time() - cache.get("timestamp", 0) > _CACHE_TTL:
            return None
        return cache
    except Exception:
        return None


def _load_stale_cache() -> Optional[dict]:
    """Load cache ignoring TTL — last resort fallback."""
    try:
        if not os.path.exists(_CACHE_PATH):
            return None
        with open(_CACHE_PATH) as f:
            return json.load(f)
    except Exception:
        return None


def _save_cache(data: dict):
    try:
        data["timestamp"] = time.time()
        os.makedirs(os.path.dirname(_CACHE_PATH), exist_ok=True)
        with open(_CACHE_PATH, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as exc:
        logger.warning("Could not save index cache: %s", exc)


# ══════════════════════════════════════════════════════════════════════════════
# CORE FETCHER
# ══════════════════════════════════════════════════════════════════════════════

def _get_index_data(index_name: str, cache_key: str) -> list[dict]:
    """Fetch index constituents with cache. Returns list of dicts."""
    # 1. Fresh cache
    cache = _load_cache()
    if cache and cache_key in cache:
        records = cache[cache_key]
        if records and len(records) >= 10:
            return records

    # 2. Live fetch from NSE
    try:
        from modules.nse_client import get_shared_client
        client = get_shared_client()
        records = client.fetch_index_with_meta(index_name)
        if records and len(records) >= 10:
            cache = _load_stale_cache() or {}
            cache[cache_key] = records
            _save_cache(cache)
            logger.info("Index %s: %d symbols from NSE", index_name, len(records))
            return records
    except Exception as exc:
        logger.warning("Index %s fetch failed: %s", index_name, exc)

    # 3. Stale cache (ignore TTL)
    stale = _load_stale_cache()
    if stale and cache_key in stale:
        records = stale[cache_key]
        if records:
            logger.info("Index %s: %d symbols from stale cache", index_name, len(records))
            return records

    return []


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

def get_nifty50() -> list[str]:
    """Current NIFTY 50 symbols. Fetches from NSE, caches 24h."""
    records = _get_index_data("NIFTY 50", "nifty50")
    return sorted(set(r["symbol"] for r in records)) if records else []


def get_nifty100() -> list[str]:
    """Current NIFTY 100 symbols. Fetches from NSE, caches 24h."""
    records = _get_index_data("NIFTY 100", "nifty100")
    return sorted(set(r["symbol"] for r in records)) if records else []


def get_nifty_next50() -> list[str]:
    """Current NIFTY NEXT 50 symbols."""
    records = _get_index_data("NIFTY NEXT 50", "nifty_next50")
    return sorted(set(r["symbol"] for r in records)) if records else []


def get_index_symbols(index_name: str) -> list[str]:
    """Get symbols for any NSE index by name."""
    cache_key = index_name.lower().replace(" ", "_")
    records = _get_index_data(index_name, cache_key)
    return sorted(set(r["symbol"] for r in records)) if records else []


def get_sector(symbol: str) -> str:
    """
    Get broad sector for a symbol from cached index data.

    Search order: industry_db (NIFTY 500) → nifty100 → nifty50 → nifty_next50.
    Triggers a background build of industry_db on first miss.
    """
    sym = symbol.upper().replace(".NS", "")
    for source in (_load_cache(), _load_stale_cache()):
        if not source:
            continue
        # 1. Comprehensive industry DB (built from NIFTY 500)
        idb = source.get("industry_db", {})
        if sym in idb:
            return _map_industry_to_sector(idb[sym].get("industry", ""))
        # 2. Index-specific records (backward compat)
        for key in ("nifty500", "nifty200", "nifty100", "nifty50", "nifty_next50"):
            for r in source.get(key, []):
                if r.get("symbol") == sym:
                    return _map_industry_to_sector(r.get("industry", ""))
    return "Other"


def get_industry(symbol: str) -> str:
    """Get raw NSE industry string for a symbol (e.g. 'Private Sector Bank')."""
    sym = symbol.upper().replace(".NS", "")
    for source in (_load_cache(), _load_stale_cache()):
        if not source:
            continue
        idb = source.get("industry_db", {})
        if sym in idb:
            return idb[sym].get("industry", "")
        for key in ("nifty500", "nifty200", "nifty100", "nifty50", "nifty_next50"):
            for r in source.get(key, []):
                if r.get("symbol") == sym:
                    return r.get("industry", "")
    return ""


def build_industry_db(force: bool = False) -> dict:
    """
    Build comprehensive symbol → industry database from NIFTY 500.

    Fetches NIFTY 500 constituents from NSE, extracts industry for each,
    and caches as a flat dict: {symbol: {industry, company, sector}}.

    Called automatically on first get_sector() miss, or manually via
    scripts/build_industry_db.py. Cached for 24h.

    Returns: {symbol: {industry: str, company: str, sector: str}}
    """
    # Check cache first
    if not force:
        cache = _load_cache()
        if cache and "industry_db" in cache and len(cache["industry_db"]) >= 100:
            return cache["industry_db"]

    logger.info("Building industry DB from NIFTY 500...")
    db = {}

    # Fetch NIFTY 500 — covers essentially all liquid / F&O stocks
    for index_name, cache_key in [
        ("NIFTY 500", "nifty500"),
        ("NIFTY 200", "nifty200"),
    ]:
        try:
            records = _get_index_data(index_name, cache_key)
            for r in records:
                sym = r.get("symbol", "")
                ind = r.get("industry", "")
                if sym and ind:
                    db[sym] = {
                        "industry": ind,
                        "company": r.get("company", ""),
                        "sector": _map_industry_to_sector(ind),
                    }
        except Exception as exc:
            logger.warning("Industry DB: %s fetch failed: %s", index_name, exc)

    if db:
        cache = _load_stale_cache() or {}
        cache["industry_db"] = db
        _save_cache(cache)
        logger.info("Industry DB: %d stocks cached", len(db))
    else:
        logger.warning("Industry DB: no data fetched")

    return db


def get_sector_map() -> dict[str, list[str]]:
    """
    Build sector → [symbols] mapping from NIFTY 100 constituents.
    Dynamically built from NSE industry data.
    """
    records = _get_index_data("NIFTY 100", "nifty100")
    sector_map: dict[str, list[str]] = {}
    for r in records:
        sector = _map_industry_to_sector(r.get("industry", ""))
        if sector not in sector_map:
            sector_map[sector] = []
        sector_map[sector].append(r["symbol"])
    for k in sector_map:
        sector_map[k] = sorted(sector_map[k])
    return sector_map


# ══════════════════════════════════════════════════════════════════════════════
# BACKWARD COMPATIBILITY
# ══════════════════════════════════════════════════════════════════════════════
# Lazy proxies for code that imports NIFTY_50 / NIFTY_100 / SECTOR_MAP_N100.

class _LazyList:
    """List that fetches on first access."""
    def __init__(self, fetcher):
        self._f = fetcher
        self._d = None
    def _e(self):
        if self._d is None: self._d = self._f()
    def __iter__(self): self._e(); return iter(self._d)
    def __len__(self): self._e(); return len(self._d)
    def __contains__(self, x): self._e(); return x in self._d
    def __getitem__(self, i): self._e(); return self._d[i]
    def __repr__(self): self._e(); return repr(self._d)
    def __add__(self, o): self._e(); return self._d + list(o)


class _LazyDict:
    """Dict that fetches on first access."""
    def __init__(self, fetcher):
        self._f = fetcher
        self._d = None
    def _e(self):
        if self._d is None: self._d = self._f()
    def __iter__(self): self._e(); return iter(self._d)
    def __getitem__(self, k): self._e(); return self._d[k]
    def __contains__(self, x): self._e(); return x in self._d
    def items(self): self._e(); return self._d.items()
    def keys(self): self._e(); return self._d.keys()
    def values(self): self._e(); return self._d.values()
    def get(self, k, d=None): self._e(); return self._d.get(k, d)


NIFTY_50 = _LazyList(get_nifty50)
NIFTY_100 = _LazyList(get_nifty100)
SECTOR_MAP_N100 = _LazyDict(get_sector_map)
