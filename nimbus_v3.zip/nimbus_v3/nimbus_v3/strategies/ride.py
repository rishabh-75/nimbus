"""nimbus_v3.strategies.ride — Bollinger-band ride with trend-quality + industry gates.

Industry-conditioned Ride (April 2026 OOS validation)
─────────────────────────────────────────────────────
Ride's *aggregate* OOS edge did not replicate (test lift −0.12pp).
However, per-industry validation (``scripts/run_ride_industry_validation.py``)
showed the edge is **alive in specific commodity-linked and capital-intensive
cyclical industries** where upper-band breakouts have structural follow-through
from underlying business/commodity cycles:

    Non - Ferrous Metals    10d lift +3.4%   WR 61%   n=36
    Fertilizers & Agrochem  10d lift +4.0%   WR 58%   n=26
    Power                   10d lift +0.6%   WR 51%   n=51
    Telecom - Services      5d lift  +1.1%   WR 50%   n=34
    Minerals & Mining       5d lift  +0.5%   WR 50%   n=10
    Construction            5d lift  +0.4%   WR 52%   n=69
    Textiles & Apparels     5d lift  +0.1%   WR 39%   n=13

Non-whitelisted industries showed aggregate negative lift. The industry
gate filters out ~84% of fires (1,691 of 2,012 test fires) that had
zero or negative edge, keeping the ~321 fires with demonstrated OOS lift.

``production_weight`` is set to 0.5 (industry-conditioned OOS edge
confirmed but sample sizes are moderate — track forward for 6 months
before promoting to 1.0).

Entry gates:
- ``bb_20_1s_upper <= state.close <= bb_20_2s_upper``
- ``state.green_streak >= 3``
- ``state.adx_14 > 25``
- ``symbol_meta.industry in _RIDE_EDGE_INDUSTRIES``  (NEW)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Industry whitelist — OOS-validated April 2026
# ══════════════════════════════════════════════════════════════════════════════

#: Industries where Ride showed positive OOS lift at both 5d and 10d horizons
#: in the run_ride_industry_validation.py study. Reviewed and accepted based on:
#:   - Positive test lift at BOTH 5d and 10d
#:   - Test N ≥ 10 (minimum sample for credibility)
#:   - Economic rationale (commodity/capex cycle → persistent momentum)
#:
#: Industries NOT in this set showed aggregate negative lift and are excluded.
#: This gate filters ~84% of Ride fires that had no edge.
_RIDE_EDGE_INDUSTRIES: Final[frozenset[str]] = frozenset({
    "Non - Ferrous Metals",         # 10d +3.4%, WR 61%, n=36
    "Fertilizers & Agrochemicals",  # 10d +4.0%, WR 58%, n=26
    "Power",                        # 10d +0.6%, WR 51%, n=51
    "Telecom - Services",           # 5d +1.1%, WR 50%, n=34
    "Minerals & Mining",            # 5d +0.5%, WR 50%, n=10
    "Construction",                 # 5d +0.4%, WR 52%, n=69
    "Textiles & Apparels",          # 5d +0.1%, WR 39%, n=13
    "Aerospace & Defense",          # 10d +1.4%, WR 66%, n=29
    "Personal Products",            # 10d +0.7%, WR 67%, n=18
})


@dataclass(frozen=True)
class RideParams:
    green_streak_min: int = 3
    adx_14_min: float = 25.0


class RideStrategy:
    """BB ride continuation setup with trend-quality + industry gates.

    Industry-conditioned: only fires for industries in
    ``_RIDE_EDGE_INDUSTRIES`` where OOS edge was validated. Non-
    whitelisted industries return ``None`` from ``accepts()``.
    """

    name: str = "Ride"
    setup_type: SetupType = SetupType.RIDE
    priority: int = 40
    production_weight: float = 0.5   # Industry-conditioned OOS edge — track 6mo

    def __init__(self, params: RideParams = RideParams()) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        if symbol_meta.is_etf:
            return False
        # Industry gate: only evaluate symbols in OOS-validated industries.
        return symbol_meta.industry in _RIDE_EDGE_INDUSTRIES

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — purely state-driven
    ) -> StrategySignal | None:
        # "Riding upper 1σ" — close must sit between 1σ and 2σ upper bands.
        if not (state.bb_20_1s_upper <= state.close <= state.bb_20_2s_upper):
            return None
        if state.green_streak < self._p.green_streak_min:
            return None
        if state.adx_14 <= self._p.adx_14_min:
            return None
        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "close": state.close,
                "bb_1s_upper": state.bb_20_1s_upper,
                "bb_2s_upper": state.bb_20_2s_upper,
                "green_streak": state.green_streak,
                "adx_14": state.adx_14,
                "industry": contexts.sector.industry if contexts.sector else "Unknown",
            },
        )
