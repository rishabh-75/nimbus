"""Research-only package: phase win-rate analysis.

Computes historical p_win per symbol per phase (INIT/RETEST) +
a universe-wide CONT continuation model. **Not** wired into the
live cockpit — this is a one-time research exercise, run via
``scripts/research/compute_phase_p_win.py`` and consumed by the
operator offline.

See module docstrings for individual contracts.
"""
