#!/usr/bin/env python3
"""
tests/test_etf_bb_ride.py — Unit tests for ETF BB ride strategy.

Tests the backtest engine + BBRideEngine on synthetic ETF-like data.
No network calls — all data is fabricated to test specific scenarios.
"""
import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))
import numpy as np, pandas as pd


def _make_etf_df(n=200, base=500, vol=0.008, trend=0.0005, seed=42):
    """Create synthetic ETF-like price data (low vol, tight bands)."""
    np.random.seed(seed)
    dates = pd.bdate_range("2023-01-01", periods=n)
    rets = np.random.randn(n) * vol + trend
    prices = base * np.exp(np.cumsum(rets))
    df = pd.DataFrame({
        "Open": prices * (1 - np.random.rand(n) * 0.002),
        "High": prices * (1 + np.random.rand(n) * 0.005),
        "Low": prices * (1 - np.random.rand(n) * 0.005),
        "Close": prices,
        "Volume": np.random.randint(50000, 500000, n),
    }, index=dates)
    return df


def _make_spike_df(n=200, base=500, spike_bar=150, spike_pct=3.0, seed=42):
    """Create ETF data with a spike above BB upper at bar spike_bar."""
    df = _make_etf_df(n, base, vol=0.006, seed=seed)
    # Force a clear spike above upper band
    for i in range(spike_bar, min(spike_bar + 3, n)):
        df.iloc[i, df.columns.get_loc("Close")] *= (1 + spike_pct / 100)
        df.iloc[i, df.columns.get_loc("High")] *= (1 + spike_pct / 100 * 1.2)
    return df


class TestBBRideEngine(unittest.TestCase):
    """Test BBRideEngine.compute() on ETF-like data."""

    def test_insufficient_data(self):
        from modules.bb_ride import compute_ride
        df = _make_etf_df(n=30)
        r = compute_ride(df, "TESTBEES")
        self.assertFalse(r.data_sufficient)
        self.assertEqual(r.grade, "—")

    def test_normal_etf_no_entry(self):
        """Normal low-vol ETF data should rarely trigger entries."""
        from modules.bb_ride import compute_ride
        df = _make_etf_df(n=200, vol=0.005, seed=100)
        r = compute_ride(df, "NIFTYBEES")
        self.assertTrue(r.data_sufficient)
        # With very low vol, entry may or may not trigger
        # Just verify the engine doesn't crash
        self.assertIn(r.grade, ["A+", "A", "B+", "B", "C+", "C", "D", "—"])

    def test_spike_triggers_entry(self):
        """A clear spike above BB upper should trigger entry."""
        from modules.bb_ride import compute_ride
        df = _make_spike_df(n=200, spike_bar=150, spike_pct=4.0)
        r = compute_ride(df, "BANKBEES", vix_regime="ELEVATED",
                         sector_ctx={"sector": "Private Bank", "adj_score": 3.0})
        self.assertTrue(r.data_sufficient)
        # Spike should push close above BB upper
        if r.entry_triggered:
            self.assertNotEqual(r.grade, "—")
            self.assertIn("RIDE", r.verdict)
            self.assertGreater(r.bb_pct, 0.5)
            self.assertGreater(r.trail_stop, 0)
            self.assertGreater(r.pt_price, r.close)

    def test_grade_factors(self):
        """Grade should reflect VIX + sector + volume."""
        from modules.bb_ride import BBRideEngine, BBRideSignal
        engine = BBRideEngine()

        # High context: ELEVATED + CYCLICAL + LEADING + high vol
        df = _make_spike_df(spike_pct=5.0, seed=77)
        r1 = engine.compute(df, "BANKBEES", vix_regime="ELEVATED",
                            sector_ctx={"sector": "Private Bank", "adj_score": 5.0})

        # Low context: NORMAL + DEFENSIVE + no sector ctx
        r2 = engine.compute(df, "ITBEES", vix_regime="NORMAL",
                            sector_ctx={"sector": "IT", "adj_score": 0.5})

        # If both trigger, high context should have higher grade points
        if r1.entry_triggered and r2.entry_triggered:
            self.assertGreaterEqual(r1.grade_pts, r2.grade_pts)

    def test_result_has_all_fields(self):
        """BBRideResult should have all required fields for UI."""
        from modules.bb_ride import compute_ride, BBRideResult
        df = _make_spike_df(spike_pct=4.0)
        r = compute_ride(df, "TEST", vix_regime="PANIC")
        self.assertIsInstance(r, BBRideResult)
        # Check all UI-facing fields exist
        for field in ["grade", "verdict", "sizing", "bb_pct", "vol_ratio",
                      "trail_stop", "trail_pct", "pt_price", "close",
                      "bb_upper", "bb_mid", "atr", "quality_rank",
                      "sector_type", "rs_bucket", "vix_regime"]:
            self.assertTrue(hasattr(r, field), f"Missing field: {field}")

    def test_non_entry_verdict(self):
        """Non-entry should get descriptive verdict."""
        from modules.bb_ride import compute_ride
        df = _make_etf_df(n=200, vol=0.003, seed=99)  # very low vol
        r = compute_ride(df, "GOLDBEES")
        self.assertTrue(r.data_sufficient)
        if not r.entry_triggered:
            self.assertIn("—", r.grade)
            # Verdict should describe %B position
            self.assertTrue(any(x in r.verdict for x in ["SKIP", "WATCH", "RIDING", "NEUTRAL"]))

    def test_classify_vix_regime(self):
        """classify_vix_regime should use validated thresholds."""
        from modules.conviction import classify_vix_regime
        self.assertEqual(classify_vix_regime(None), "UNKNOWN")
        self.assertEqual(classify_vix_regime(10), "LOW")
        self.assertEqual(classify_vix_regime(15), "NORMAL")
        self.assertEqual(classify_vix_regime(19), "ELEVATED")
        self.assertEqual(classify_vix_regime(23), "PANIC")
        # Boundary tests
        self.assertEqual(classify_vix_regime(13), "NORMAL")  # >= 13
        self.assertEqual(classify_vix_regime(12.9), "LOW")
        self.assertEqual(classify_vix_regime(18), "ELEVATED")  # >= 18
        self.assertEqual(classify_vix_regime(22), "ELEVATED")  # <= 22
        self.assertEqual(classify_vix_regime(22.01), "PANIC")  # > 22


class TestBacktestEngine(unittest.TestCase):
    """Test the simulate_trades function from the backtest script."""

    def test_spike_generates_trades(self):
        """A spike above BB upper should generate at least one trade."""
        from run_etf_bb_ride_backtest import simulate_trades, compute_indicators

        df = _make_spike_df(n=200, spike_bar=120, spike_pct=5.0, seed=42)
        trades = simulate_trades(df, "BANKBEES")
        # With a 5% spike, should get at least one trade
        self.assertGreater(len(trades), 0, "Spike should trigger at least one trade")
        t = trades[0]
        self.assertEqual(t["symbol"], "BANKBEES")
        self.assertIn("exit_reason", t)
        self.assertIn(t["exit_reason"], ["PT", "SL", "MAX_HOLD", "MID_BREAK",
                                          "UPPER_BREAK", "TRAIL_STOP", "SMA10_BREAK"])

    def test_exit_rules_differ(self):
        """Different exit rules should produce different results."""
        from run_etf_bb_ride_backtest import simulate_trades

        df = _make_spike_df(n=250, spike_bar=100, spike_pct=4.0, seed=55)

        trades_mid = simulate_trades(df, "TEST", params={"exit_rule": "mid_break"})
        trades_trail = simulate_trades(df, "TEST", params={"exit_rule": "trailing", "trailing_atr": 2.0})

        # Both should have trades, but bars_held may differ
        if trades_mid and trades_trail:
            avg_mid = np.mean([t["bars_held"] for t in trades_mid])
            avg_trail = np.mean([t["bars_held"] for t in trades_trail])
            # They should differ (mid-break exits faster)
            # Just check both produce results
            self.assertGreater(len(trades_mid), 0)
            self.assertGreater(len(trades_trail), 0)

    def test_no_trades_on_flat_data(self):
        """Very flat data (tiny vol) should produce few/no trades."""
        from run_etf_bb_ride_backtest import simulate_trades

        df = _make_etf_df(n=200, vol=0.0001, seed=77)  # nearly flat
        trades = simulate_trades(df, "FLAT")
        # Might get 0 or a few trades, but not many
        self.assertLess(len(trades), 10, "Flat data shouldn't generate many trades")

    def test_bb_std_affects_entry_count(self):
        """Lower BB std should produce more entries (touches) than higher.
        Trade count may vary due to exit/cooldown interaction."""
        from run_etf_bb_ride_backtest import compute_indicators

        df = _make_etf_df(n=300, vol=0.01, seed=33)
        # Count raw touches, not trades (avoids exit/cooldown interference)
        for bb_std, label in [(0.5, "0.5σ"), (1.0, "1.0σ"), (2.0, "2.0σ")]:
            d = compute_indicators(df, bb_period=20, bb_std=bb_std)
            c = d["Close"].values
            upper = d["BB_Upper"].values
            touches = 0
            was_below = True
            for i in range(35, len(c)):
                if np.isnan(upper[i]): continue
                if was_below and c[i] >= upper[i]:
                    touches += 1; was_below = False
                elif c[i] < upper[i]:
                    was_below = True
            # Just verify: lower σ should have MORE raw touches
            if bb_std == 0.5:
                touches_05 = touches
            elif bb_std == 2.0:
                touches_20 = touches
        self.assertGreater(touches_05, touches_20,
                           "BB(0.5σ) should have more touches than BB(2.0σ)")

    def test_trade_fields_complete(self):
        """Each trade dict should have all required fields."""
        from run_etf_bb_ride_backtest import simulate_trades

        df = _make_spike_df(n=200, spike_bar=100, spike_pct=5.0)
        trades = simulate_trades(df, "BANKBEES")
        if trades:
            t = trades[0]
            required = ["symbol", "entry_date", "exit_date", "entry_price", "exit_price",
                        "pnl_pct", "bars_held", "exit_reason", "win",
                        "entry_pctb", "entry_vol", "entry_mfi", "entry_rsi",
                        "vix_regime", "etf_type"]
            for field in required:
                self.assertIn(field, t, f"Missing trade field: {field}")

    def test_vix_regime_in_trades(self):
        """Trades should include VIX regime when VIX series provided."""
        from run_etf_bb_ride_backtest import simulate_trades

        df = _make_spike_df(n=200, spike_bar=100, spike_pct=5.0)
        # Fake VIX series
        vix_dates = pd.bdate_range("2023-01-01", periods=200)
        vix = pd.Series(20.0, index=vix_dates)  # constant ELEVATED
        trades = simulate_trades(df, "BANKBEES", vix_series=vix)
        if trades:
            self.assertEqual(trades[0]["vix_regime"], "ELEVATED")

    def test_etf_type_assignment(self):
        """Trades should have correct ETF type."""
        from run_etf_bb_ride_backtest import simulate_trades

        df = _make_spike_df(spike_pct=5.0)
        trades = simulate_trades(df, "BANKBEES")
        if trades:
            self.assertEqual(trades[0]["etf_type"], "CYCLICAL")

        trades2 = simulate_trades(df, "ITBEES")
        if trades2:
            self.assertEqual(trades2[0]["etf_type"], "DEFENSIVE")


class TestETFRideEngine(unittest.TestCase):
    """Test ETFRideEngine — separate grading from equities."""

    def test_basic_compute(self):
        from modules.etf_ride import compute_etf_ride, ETFRideResult
        df = _make_spike_df(spike_pct=4.0)
        r = compute_etf_ride(df, "BANKBEES", vix_regime="ELEVATED")
        self.assertIsInstance(r, ETFRideResult)
        self.assertTrue(r.data_sufficient)
        self.assertEqual(r.etf_type, "CYCLICAL")

    def test_vix_normal_gate(self):
        """VIX NORMAL should gate ETF rides (Sh -0.31 over 7yr)."""
        from modules.etf_ride import compute_etf_ride
        df = _make_spike_df(spike_pct=5.0)
        r = compute_etf_ride(df, "BANKBEES", vix_regime="NORMAL")
        if r.entry_triggered:
            self.assertTrue(r.vix_gated, "NORMAL VIX should gate ETF rides")
            self.assertEqual(r.grade, "D")
            self.assertEqual(r.sizing, "SKIP")
            self.assertIn("NORMAL", r.verdict)

    def test_elevated_not_gated(self):
        """VIX ELEVATED should NOT be gated."""
        from modules.etf_ride import compute_etf_ride
        df = _make_spike_df(spike_pct=5.0)
        r = compute_etf_ride(df, "BANKBEES", vix_regime="ELEVATED")
        if r.entry_triggered:
            self.assertFalse(r.vix_gated)
            self.assertNotEqual(r.grade, "D")

    def test_etf_type_auto_detection(self):
        """ETF type should be auto-detected from symbol."""
        from modules.etf_ride import compute_etf_ride
        df = _make_spike_df(spike_pct=4.0)
        r = compute_etf_ride(df, "GOLDBEES")
        self.assertEqual(r.etf_type, "COMMODITY")
        r2 = compute_etf_ride(df, "NIFTYBEES")
        self.assertEqual(r2.etf_type, "BROAD")
        r3 = compute_etf_ride(df, "ITBEES")
        self.assertEqual(r3.etf_type, "DEFENSIVE")

    def test_different_grade_from_equity(self):
        """ETF ride should use ADX/BBW/RSI, not Volume for grading."""
        from modules.etf_ride import ETFRideEngine
        from modules.bb_ride import BBRideEngine
        # Both use same signal extraction, but grade differently
        engine_etf = ETFRideEngine()
        engine_eq = BBRideEngine()
        df = _make_spike_df(spike_pct=5.0, seed=88)
        r_etf = engine_etf.compute(df, "BANKBEES", vix_regime="ELEVATED", etf_type="CYCLICAL")
        r_eq = engine_eq.compute(df, "BANKBEES", vix_regime="ELEVATED",
                                  sector_ctx={"sector": "Private Bank", "adj_score": 3.0})
        # Both should have data
        self.assertTrue(r_etf.data_sufficient)
        self.assertTrue(r_eq.data_sufficient)
        # Grade points may differ (different factors)
        # Just verify both compute without error

    def test_mh40_targets(self):
        """ETF ride should have max_hold=40 (not 30 like equities)."""
        from modules.etf_ride import compute_etf_ride
        df = _make_spike_df(spike_pct=4.0)
        r = compute_etf_ride(df, "BANKBEES")
        self.assertEqual(r.max_hold, 40)
        self.assertEqual(r.trailing_atr_mult, 3.0)

    def test_result_fields(self):
        """ETFRideResult should have all required fields."""
        from modules.etf_ride import compute_etf_ride, ETFRideResult
        df = _make_spike_df(spike_pct=4.0)
        r = compute_etf_ride(df, "BANKBEES", vix_regime="ELEVATED")
        for field in ["grade", "verdict", "sizing", "bb_pct", "vol_ratio",
                      "trail_stop", "pt_price", "close", "adx", "rsi", "bbw",
                      "etf_type", "vix_regime", "vix_gated", "quality_rank", "max_hold"]:
            self.assertTrue(hasattr(r, field), f"Missing field: {field}")

    def test_singleton(self):
        from modules.etf_ride import _etf_ride_engine, ETFRideEngine
        self.assertIsInstance(_etf_ride_engine, ETFRideEngine)

    def test_compute_etf_returns_result(self):
        from modules.etf_momentum import compute_etf, ETFMomentumResult
        df = _make_etf_df(n=200)
        r = compute_etf(df, "NIFTYBEES", vix=15.0)
        self.assertIsInstance(r, ETFMomentumResult)
        self.assertTrue(r.data_sufficient)

    def test_compute_etf_insufficient(self):
        from modules.etf_momentum import compute_etf
        df = _make_etf_df(n=20)
        r = compute_etf(df, "TEST")
        self.assertFalse(r.data_sufficient)

    def test_quality_rank_bounded(self):
        from modules.etf_momentum import compute_etf
        df = _make_etf_df(n=200)
        r = compute_etf(df, "TEST")
        if r.data_sufficient:
            self.assertGreaterEqual(r.quality_rank, 0)
            self.assertLessEqual(r.quality_rank, 100)


class TestSingleSourceOfTruth(unittest.TestCase):
    """Verify engine singletons and architecture."""

    def test_conviction_singleton(self):
        from modules.conviction import _engine, ConvictionEngine
        self.assertIsInstance(_engine, ConvictionEngine)

    def test_bb_ride_singleton(self):
        from modules.bb_ride import _engine, BBRideEngine
        self.assertIsInstance(_engine, BBRideEngine)

    def test_etf_momentum_singleton(self):
        from modules.etf_momentum import _etf_engine, ETFMomentumEngine
        self.assertIsInstance(_etf_engine, ETFMomentumEngine)

    def test_etf_ride_singleton(self):
        from modules.etf_ride import _etf_ride_engine, ETFRideEngine
        self.assertIsInstance(_etf_ride_engine, ETFRideEngine)

    def test_compute_ride_uses_singleton(self):
        """compute_ride() should delegate to _engine.compute()."""
        from modules.bb_ride import compute_ride, _engine
        df = _make_etf_df(n=100)
        r1 = compute_ride(df, "TEST")
        r2 = _engine.compute(df, "TEST")
        self.assertEqual(r1.bb_pct, r2.bb_pct)
        self.assertEqual(r1.grade, r2.grade)


if __name__ == "__main__":
    results = unittest.main(exit=False, verbosity=0)
    r = results.result
    passed = r.testsRun - len(r.failures) - len(r.errors)
    print(f"\n{'='*60}")
    print(f"RESULTS: {passed} passed, {len(r.failures) + len(r.errors)} failed")
    print(f"{'='*60}")
    if r.failures:
        for t, tb in r.failures:
            print(f"\nFAILED: {t}")
            print(tb)
    if r.errors:
        for t, tb in r.errors:
            print(f"\nERROR: {t}")
            print(tb)
