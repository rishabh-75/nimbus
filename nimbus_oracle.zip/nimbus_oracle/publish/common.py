"""
publish/common.py — Shared chart styling and export for NIMBUS PUBLISH.

Every publish script imports this for consistent Goldman-Sachs-dark-terminal aesthetic.
No matplotlib global state — always use nimbus_style() context manager.

Usage:
    from publish.common import nimbus_style, export_figure, COLORS

    with nimbus_style():
        fig, ax = plt.subplots(figsize=(12, 7))
        # ... build chart ...
        export_figure(fig, "nifty50_breadth")
"""
import os, datetime, io
from contextlib import contextmanager

# ── NIMBUS color palette (matches ui/theme.py) ───────────────────────────────

COLORS = {
    "bg": "#0D1117",
    "surface": "#161B22",
    "border": "#1E2937",
    "emerald": "#10B981",
    "red": "#EF4444",
    "gold": "#F59E0B",
    "blue": "#3B82F6",
    "violet": "#8B5CF6",
    "muted": "#64748B",
    "white": "#E6EDF3",
    "dim": "#475569",
    "surface2": "#1E2937",
}

# Sector colors (consistent across all publish charts)
SECTOR_COLORS = {
    "Banks": "#3B82F6",
    "IT": "#8B5CF6",
    "Finance": "#06B6D4",
    "Auto": "#F59E0B",
    "Pharma": "#10B981",
    "Metals": "#EF4444",
    "Energy": "#F97316",
    "FMCG": "#34D399",
    "Infra": "#6366F1",
    "Consumer": "#EC4899",
    "Cement": "#94A3B8",
    "Healthcare": "#14B8A6",
    "Telecom": "#A78BFA",
    "Industrials": "#78716C",
    "Other": "#64748B",
}

# WR zone colors
WR_COLORS = {
    "extreme_oversold": "#10B981",   # WR < -70
    "oversold": "#34D399",           # -70 to -50
    "zone": "#F59E0B",               # -50 to -30
    "neutral": "#64748B",            # -30 to -20
    "overbought": "#EF4444",         # > -20
}

WATERMARK = "© Nimbus | Emerald Slate · NSE Data · Educational · Not Investment Advice"
EXPORT_DIR = os.path.expanduser("~/nimbus/exports")


@contextmanager
def nimbus_style():
    """Context manager for NIMBUS dark-terminal matplotlib style."""
    import matplotlib
    import matplotlib.pyplot as plt

    style = {
        "figure.facecolor": COLORS["bg"],
        "axes.facecolor": COLORS["surface"],
        "axes.edgecolor": COLORS["border"],
        "axes.labelcolor": COLORS["muted"],
        "axes.titlesize": 13,
        "axes.titleweight": 600,
        "axes.titlecolor": COLORS["white"],
        "axes.grid": True,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.color": COLORS["border"],
        "grid.linewidth": 0.4,
        "grid.alpha": 0.6,
        "grid.linestyle": "--",
        "xtick.color": COLORS["muted"],
        "ytick.color": COLORS["muted"],
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "text.color": COLORS["white"],
        "font.size": 9,
        "legend.framealpha": 0.0,
        "legend.labelcolor": COLORS["muted"],
        "legend.fontsize": 7,
        "savefig.facecolor": COLORS["bg"],
        "savefig.edgecolor": "none",
    }

    with matplotlib.rc_context(style):
        yield


def add_watermark(fig):
    """Add anti-crop watermark — multiple positions across the figure."""
    brand = "© Nimbus | Emerald Slate"
    disclaimer = "NSE Data · Educational · Not Investment Advice"

    # 1. Bottom-right — primary branding (visible)
    fig.text(0.98, 0.014, brand,
             fontsize=7, color=COLORS["emerald"], fontweight=600,
             ha="right", va="bottom", alpha=0.8)
    fig.text(0.98, 0.003, disclaimer,
             fontsize=5.5, color=COLORS["dim"], style="italic",
             ha="right", va="bottom", alpha=0.6)

    # 2. Diagonal center watermark — large, faint, across chart area
    fig.text(0.50, 0.50, "Nimbus",
             fontsize=42, color=COLORS["white"], alpha=0.03,
             ha="center", va="center", rotation=30,
             fontweight=700, transform=fig.transFigure, zorder=0)

    # 3. Top-left subtle brand (hard to crop without losing title)
    fig.text(0.02, 0.006, brand,
             fontsize=5.5, color=COLORS["muted"],
             ha="left", va="bottom", alpha=0.5)


def add_title(fig, title, subtitle=None):
    """Add title + optional subtitle at the top of the figure."""
    fig.text(0.02, 0.97, title,
             fontsize=14, fontweight=600, color=COLORS["white"],
             ha="left", va="top")
    if subtitle:
        fig.text(0.02, 0.935, subtitle,
                 fontsize=9, color=COLORS["muted"],
                 ha="left", va="top")


def add_timestamp(fig, x=0.98, y=0.97):
    """Add timestamp in top-right corner."""
    now = datetime.datetime.now().strftime("%d %b %Y · %H:%M IST")
    fig.text(x, y, now,
             fontsize=8, color=COLORS["muted"],
             ha="right", va="top")


def export_figure(fig, series_slug, dpi=200):
    """
    Save figure to ~/nimbus/exports/ and return the filepath.
    Also adds watermark automatically.
    """
    add_watermark(fig)

    os.makedirs(EXPORT_DIR, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M")
    filename = f"nimbus_{series_slug}_{ts}.png"
    filepath = os.path.join(EXPORT_DIR, filename)

    fig.savefig(filepath, dpi=dpi, bbox_inches="tight",
                facecolor=fig.get_facecolor(), edgecolor="none")
    print(f"Exported: {filepath}")
    return filepath


def format_inr(val, decimals=0):
    """Format number in Indian notation (₹22,450)."""
    if val is None:
        return "—"
    if abs(val) >= 1e7:
        return f"₹{val/1e7:.1f}Cr"
    if abs(val) >= 1e5:
        return f"₹{val/1e5:.1f}L"
    return f"₹{val:,.{decimals}f}"
