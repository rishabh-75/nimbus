"""nimbus_v3.compute.industry_analytics — IndustryAnalyticsEngine.

The single orchestrator for industry-relative enrichment. Parallel to
``StrategyComputeEngine`` — same compute-once, read-many pattern.

See ``docs/ARCHITECTURE.md §2`` for the compute-once principle.

What the engine produces
────────────────────────
Two layers of output:

1. **Industry layer** — ``enrich_industry(industry_panel)`` returns
   a DataFrame per industry: EW close + volume series, features,
   phase label per bar. Feed ``extract_industry_state(frame, bar)``
   to get a frozen ``IndustryState`` for any bar.

2. **Symbol-relative layer** — ``enrich_symbol_relative(raw_df,
   industry, industry_frame)`` returns a DataFrame per symbol:
   rolling β and α vs the leave-one-out industry return, panel
   percentiles, and composite tags. Feed
   ``extract_relative_state(frame, bar, symbol, industry)`` to get a
   frozen ``IndustryRelativeState`` at any bar.

Why a class and not free functions
──────────────────────────────────
Same reasons as ``StrategyComputeEngine``: future configuration
(alternate windows, weight schemes), explicit construction (DI
pattern), stable identity for logging. Stateless — constructor takes
no arguments, every public method is pure.

Leave-one-out contract
──────────────────────
The industry EW index is computed from ALL members. The leave-one-out
return used for a specific stock's β / α is derived algebraically
(not by recomputing the index without the stock) using the identity:

    r_ind_loo(stock j) = (n × r_ind - r_j) / (n - 1)

This is exact when the EW index is the simple mean of member prices,
and O(1/n) approximate for other weighting schemes. On industries
with n ≥ 5 the approximation error is smaller than the 60-day
rolling-beta standard error, so this is the right trade-off.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd

from nimbus_v3.analysis.trend_phase import (
    DEFAULT_THRESHOLDS, TrendPhase, classify_phase,
)
from nimbus_v3.core.industry_relative_state import IndustryRelativeState
from nimbus_v3.core.industry_state import IndustryState


# ══════════════════════════════════════════════════════════════════════════════
# Thresholds (ablation-derived, see docstrings on the dataclasses)
# ══════════════════════════════════════════════════════════════════════════════

#: Alpha threshold for ``is_alpha_leader``. Value expressed in
#: percent-per-day terms to match ``alpha_60d`` units. The
#: research identified +0.416%/day as the panel's 90th percentile of
#: alpha and the cohort above that level delivered +2.00pp forward
#: 20d edge (t=+27.58). We round to 0.4%/day (40bps/day) as a slightly
#: cleaner threshold that captures the same population.
_ALPHA_LEADER_THRESHOLD_PCT_DAY: Final[float] = 0.40

#: Beta thresholds for the rider/quality tags. Tight thresholds
#: because the research showed the effect concentrates at the
#: extremes — β > 1.5 not β > 1.2, β < 0.8 AND in-trend.
_HIGH_BETA_THRESHOLD: Final[float] = 1.5
_LOW_BETA_THRESHOLD: Final[float] = 0.8

#: Industry phases that count as "healthy trend" for the beta tags.
_HEALTHY_PHASES: Final[frozenset[str]] = frozenset({"MID", "LATE"})

#: Accumulation tag threshold — ``vol_chg_60`` above this value is
#: the "sustained volume pickup" signal. Research validation at +30%
#: produced +0.76pp fwd-20d edge, t=+12.25, n=39,918 (STRONG working)
#: per scripts/run_volume_feature_research.py.
_ACCUM_VOL_THRESHOLD_PCT: Final[float] = 30.0
#: Accumulation tag basing proxy — stock must be below
#: ``multiplier × sma_50`` to still count as "near the base" rather
#: than "stretched extension of a trend." Matches the research
#: script's 1.15 factor exactly.
_ACCUM_BASE_MULTIPLIER: Final[float] = 1.15


# ══════════════════════════════════════════════════════════════════════════════
# Engine
# ══════════════════════════════════════════════════════════════════════════════

class IndustryAnalyticsEngine:
    """Compute-once / read-many engine for industry-relative analytics.

    Usage::

        engine = IndustryAnalyticsEngine()

        # Industry-level pass
        ind_frame = engine.enrich_industry(industry_panel)
        ind_state = engine.extract_industry_state(ind_frame, bar=-1,
                                                  industry="Banks")

        # Symbol-relative pass (requires the industry_frame above)
        rel_frame = engine.enrich_symbol_relative(
            raw_df, symbol="HDFCBANK",
            industry="Banks", industry_frame=ind_frame,
        )
        rel_state = engine.extract_relative_state(
            rel_frame, bar=-1, symbol="HDFCBANK", industry="Banks",
        )

    The two passes are independent: an app can enrich industries once
    per scan and then enrich each symbol's relative frame on demand.
    """

    #: Rolling window for β and α computation. 60 trading days ≈ 3
    #: months — short enough to reflect current regime, long enough
    #: for coefficient stability.
    BETA_WINDOW: Final[int] = 60

    #: Minimum industry size before β-vs-industry is meaningful.
    #: Below this, the industry return is dominated by 1-2 stocks
    #: and leave-one-out loses statistical power.
    MIN_INDUSTRY_SIZE: Final[int] = 5

    #: Minimum bars required for industry-level data sufficiency.
    #: Need 120 bars for the 60d-vs-prior-60d volume window.
    MIN_INDUSTRY_BARS: Final[int] = 120

    #: Minimum bars required for symbol-relative data sufficiency.
    #: Need 60 aligned bars for a single β/α estimate.
    MIN_RELATIVE_BARS: Final[int] = 60

    def __init__(self) -> None:
        """Stateless — no constructor arguments."""

    @classmethod
    def analytics_schema_hash(cls) -> str:
        """Stable hash of the engine's tunable constants + the output
        dataclass's field structure.

        Used by the on-disk industry-states cache to namespace cached
        pickles by engine version. If any of the four constants
        (``BETA_WINDOW``, ``MIN_INDUSTRY_SIZE``, ``MIN_INDUSTRY_BARS``,
        ``MIN_RELATIVE_BARS``) change, OR if the
        ``IndustryRelativeState`` dataclass gains/loses a field (e.g.
        a new tag is added), the hash changes — old caches become
        unreachable by path and fresh compute runs populate a new
        namespace.

        This is paired with ``StrategyComputeEngine.enrichment_schema_hash``
        in the cache invalidation strategy: the industry states
        cache is also sensitive to the underlying enrichment recipe,
        so callers should compose both hashes when keying their cache.
        """
        import dataclasses
        import hashlib
        from nimbus_v3.core.industry_relative_state import (
            IndustryRelativeState,
        )
        constants = (
            cls.BETA_WINDOW,
            cls.MIN_INDUSTRY_SIZE,
            cls.MIN_INDUSTRY_BARS,
            cls.MIN_RELATIVE_BARS,
        )
        # Include the dataclass field names + types so a schema change
        # (new tag, renamed field) forces a fresh namespace.
        fields = tuple(
            (f.name, str(f.type))
            for f in dataclasses.fields(IndustryRelativeState)
        )
        payload = repr((constants, fields)).encode("utf-8")
        return hashlib.md5(payload).hexdigest()[:8]

    # ══════════════════════════════════════════════════════════════════════
    # Industry-level pass
    # ══════════════════════════════════════════════════════════════════════

    def enrich_industry(
        self, industry_panel: dict[str, pd.DataFrame],
    ) -> pd.DataFrame:
        """Build the industry-level enriched frame from a member panel.

        Args:
            industry_panel: ``{symbol: DataFrame}`` for all members of
                ONE industry. Each DataFrame must have ``Close`` and
                ``Volume`` columns on a DatetimeIndex. Not mutated.

        Returns:
            A DataFrame indexed by date. Columns include the EW
            aggregates (``ew_close``, ``ew_sma_20``, ``ew_sma_50``,
            ``ew_bb_pct``, ``ew_roc_5``, ``ew_roc_10``, ``ew_roc_20``,
            ``ew_vol_chg_20``, ``ew_vol_chg_60``), breadth stats
            (``pct_above_sma_20``, ``pct_above_sma_50``), the phase
            label per bar (``phase``), the member count per bar
            (``member_count``), and ``data_sufficient``.

        Raises:
            ValueError: if ``industry_panel`` has fewer than
                ``MIN_INDUSTRY_SIZE`` members — consumers are expected
                to filter small industries before calling.
        """
        if len(industry_panel) < self.MIN_INDUSTRY_SIZE:
            raise ValueError(
                f"Industry has {len(industry_panel)} members, "
                f"need >= {self.MIN_INDUSTRY_SIZE}"
            )

        # Stack member closes + volumes into aligned DataFrames.
        closes = pd.DataFrame({
            m: df["Close"] for m, df in industry_panel.items()
            if "Close" in df.columns
        })
        vols = pd.DataFrame({
            m: df["Volume"] for m, df in industry_panel.items()
            if "Volume" in df.columns
        })
        # Forward-fill small gaps (weekend / single missing bar) but
        # don't mask longer gaps that indicate a stock genuinely
        # wasn't in the panel. 5 bars is a reasonable cap.
        closes = closes.ffill(limit=5)
        vols = vols.ffill(limit=5)

        out = pd.DataFrame(index=closes.index)

        # Member count per bar — how many closes aren't NaN at each
        # timestamp. Varies over history as stocks list / delist.
        out["member_count"] = closes.notna().sum(axis=1).astype(int)

        # Equal-weight close = mean of member closes that day.
        out["ew_close"] = closes.mean(axis=1)

        # Total volume = sum of member volumes (not mean — total
        # matches the Market Pulse convention and is more intuitive).
        total_vol = vols.sum(axis=1) if len(vols.columns) else None

        # Basic technicals on the EW close.
        out["ew_sma_20"] = out["ew_close"].rolling(20).mean()
        out["ew_sma_50"] = out["ew_close"].rolling(50).mean()

        # Bollinger %B on the EW close (1σ bands, matches
        # classify_phase's expectation).
        std20 = out["ew_close"].rolling(20).std()
        bb_upper = out["ew_sma_20"] + std20
        bb_lower = out["ew_sma_20"] - std20
        out["ew_bb_pct"] = (
            (out["ew_close"] - bb_lower)
            / (bb_upper - bb_lower).replace(0, np.nan)
        )

        # Momentum windows.
        out["ew_roc_5"] = out["ew_close"].pct_change(5) * 100
        out["ew_roc_10"] = out["ew_close"].pct_change(10) * 100
        out["ew_roc_20"] = out["ew_close"].pct_change(20) * 100

        # Volume regime. Two windows: 20d for display continuity and
        # 60d for the classifier's preferred distribution gate.
        if total_vol is not None:
            v20 = total_vol.rolling(20).mean()
            v_prior_20 = total_vol.shift(20).rolling(20).mean()
            out["ew_vol_chg_20"] = (v20 / v_prior_20 - 1) * 100

            v60 = total_vol.rolling(60).mean()
            v_prior_60 = total_vol.shift(60).rolling(60).mean()
            out["ew_vol_chg_60"] = (v60 / v_prior_60 - 1) * 100
        else:
            out["ew_vol_chg_20"] = 0.0
            out["ew_vol_chg_60"] = 0.0

        # Breadth: fraction of members above each MA. Computed per-bar
        # from each member's own SMA vs close.
        member_sma_20 = closes.rolling(20).mean()
        member_sma_50 = closes.rolling(50).mean()
        above_20 = (closes > member_sma_20).astype(float)
        above_50 = (closes > member_sma_50).astype(float)
        out["pct_above_sma_20"] = above_20.mean(axis=1)
        out["pct_above_sma_50"] = above_50.mean(axis=1)

        # Data sufficiency — need the longest lookback (60d vol window
        # + 60 prior) before every field has a real value.
        out["data_sufficient"] = (
            out["ew_sma_50"].notna()
            & out["ew_vol_chg_60"].notna()
            & out["ew_roc_20"].notna()
        )

        # Phase per bar: run classify_phase on the EW series. Can't
        # vectorise because classify_phase is scalar — but the number
        # of bars per industry is small (<= panel length) and this
        # only runs once per refresh, so per-row is fine.
        phases: list[str] = []
        for idx in out.index:
            row = out.loc[idx]
            if not row["data_sufficient"]:
                phases.append(TrendPhase.NEUTRAL.value)
                continue
            try:
                result = classify_phase(
                    close=float(row["ew_close"]),
                    sma_20=float(row["ew_sma_20"]),
                    sma_50=float(row["ew_sma_50"]),
                    roc_5=float(row["ew_roc_5"]),
                    roc_20=float(row["ew_roc_20"]),
                    bb_pct=float(row["ew_bb_pct"]),
                    thresholds=DEFAULT_THRESHOLDS,
                    roc_10=float(row["ew_roc_10"]),
                    vol_chg_20=float(row["ew_vol_chg_20"]),
                    vol_chg_60=float(row["ew_vol_chg_60"]),
                )
                phases.append(result.phase.value)
            except (ValueError, TypeError):
                phases.append(TrendPhase.NEUTRAL.value)

        out["phase"] = phases
        return out

    def extract_industry_state(
        self, enriched: pd.DataFrame, bar_index: int, industry: str,
    ) -> IndustryState:
        """Extract an ``IndustryState`` from an enriched industry frame.

        Args:
            enriched: output of ``enrich_industry``.
            bar_index: integer position (``-1`` for most recent bar,
                ``0`` for oldest, etc.) into ``enriched``.
            industry: industry name — stored on the returned state.

        Returns:
            Frozen ``IndustryState``. Fields that are ``NaN`` in the
            underlying frame return as ``float("nan")`` on the state,
            and ``data_sufficient`` reflects the frame's flag.
        """
        row = enriched.iloc[bar_index]
        bar_date = pd.Timestamp(enriched.index[bar_index])

        return IndustryState(
            industry=industry,
            bar_date=bar_date,
            member_count=int(row["member_count"]),
            ew_close=float(row["ew_close"]),
            ew_sma_20=float(row["ew_sma_20"]),
            ew_sma_50=float(row["ew_sma_50"]),
            ew_bb_pct=float(row["ew_bb_pct"]),
            ew_roc_5=float(row["ew_roc_5"]),
            ew_roc_10=float(row["ew_roc_10"]),
            ew_roc_20=float(row["ew_roc_20"]),
            ew_vol_chg_20=float(row["ew_vol_chg_20"]),
            ew_vol_chg_60=float(row["ew_vol_chg_60"]),
            phase=str(row["phase"]),
            pct_above_sma_20=float(row["pct_above_sma_20"]),
            pct_above_sma_50=float(row["pct_above_sma_50"]),
            data_sufficient=bool(row["data_sufficient"]),
        )

    # ══════════════════════════════════════════════════════════════════════
    # Symbol-relative pass
    # ══════════════════════════════════════════════════════════════════════

    def enrich_symbol_relative(
        self,
        raw_df: pd.DataFrame,
        symbol: str,
        industry: str,
        industry_frame: pd.DataFrame,
        alpha_panel_threshold: float | None = None,
    ) -> pd.DataFrame:
        """Compute β / α / industry phase for a single symbol.

        Args:
            raw_df: symbol's OHLCV DataFrame. Must have ``Close``.
            symbol: for error messages and output annotation.
            industry: which industry this symbol belongs to.
            industry_frame: output of ``enrich_industry`` for
                ``industry``. Used to (a) derive the leave-one-out
                industry return and (b) align phase labels.
            alpha_panel_threshold: absolute alpha cutoff (percent/day)
                for the ``is_alpha_leader`` tag. When ``None``, the
                module-default is used. Callers that have computed a
                per-scan panel threshold (e.g. actual 90th percentile
                of today's panel) can pass it here; otherwise the
                baked-in default applies.

        Returns:
            DataFrame aligned to ``raw_df``'s index with columns:
            ``beta_60d``, ``alpha_60d``, ``industry_phase``, and the
            four composite bool columns. Does NOT include
            ``alpha_percentile`` — that requires a panel-wide rank
            which only the caller can compute; see
            ``attach_alpha_percentile``.
        """
        del symbol  # currently only used in error messages (none raised)
        threshold = (
            alpha_panel_threshold
            if alpha_panel_threshold is not None
            else _ALPHA_LEADER_THRESHOLD_PCT_DAY
        )

        out = pd.DataFrame(index=raw_df.index)

        # Stock daily returns.
        stock_ret = raw_df["Close"].pct_change()

        # Industry EW return. Reconstruct from industry_frame's
        # ew_close (the engine's primary output).
        ind_ew_ret = industry_frame["ew_close"].pct_change()

        # Leave-one-out industry return: r_loo = (n * r_ind - r_j) / (n - 1)
        # Use the per-bar member_count from industry_frame so the LOO
        # math adapts to historical listings / delistings.
        member_count = industry_frame["member_count"].astype(float)
        aligned_stock, aligned_ind, aligned_n = stock_ret.align(
            ind_ew_ret, join="inner",
        )[0], ind_ew_ret.reindex(stock_ret.index), member_count.reindex(stock_ret.index)

        # Guard against n=1 which would divide by zero. When the
        # symbol is alone in its industry today, r_loo is undefined —
        # set to NaN so downstream β / α for that bar are NaN.
        with np.errstate(divide="ignore", invalid="ignore"):
            r_loo = np.where(
                aligned_n > 1,
                (aligned_n * aligned_ind - aligned_stock) / (aligned_n - 1),
                np.nan,
            )
        r_loo = pd.Series(r_loo, index=aligned_stock.index)

        # Rolling β = cov(stock, ind_loo) / var(ind_loo), 60-day.
        cov = aligned_stock.rolling(self.BETA_WINDOW).cov(r_loo)
        var = r_loo.rolling(self.BETA_WINDOW).var()
        beta = cov / var.replace(0, np.nan)
        out["beta_60d"] = beta

        # α = mean(stock_ret - β * r_loo) over the same 60d window.
        # Use the contemporaneous β (computed above) for
        # self-consistency — same convention as the research script.
        residual = aligned_stock - beta * r_loo
        # Convert to percent/day for human-readable units (matches
        # the dataclass doc and the research output).
        out["alpha_60d"] = residual.rolling(self.BETA_WINDOW).mean() * 100

        # Industry phase at each bar — forward-fill onto the symbol's
        # index in case industry_frame has slightly different dates.
        out["industry_phase"] = (
            industry_frame["phase"]
            .reindex(out.index, method="ffill")
            .fillna(TrendPhase.NEUTRAL.value)
        )

        # Industry context fields — forwarded from the industry frame
        # so the card can render regime context (ROC_20 for trend
        # magnitude, breadth for "is the move broad?", member_count
        # for statistical honesty). These are NOT signals on their
        # own; they're interpretive context for the phase label.
        out["industry_roc_20"] = (
            industry_frame["ew_roc_20"].reindex(out.index, method="ffill")
        )
        out["industry_breadth_pct"] = (
            industry_frame["pct_above_sma_20"].reindex(out.index, method="ffill")
        )
        out["peer_count_in_industry"] = (
            industry_frame["member_count"]
            .reindex(out.index, method="ffill")
            .fillna(0).astype(int)
        )
        # Peer rank is cross-symbol within the industry — set to 0
        # here as a sentinel. ``analyze_symbol`` overwrites this
        # column after running the engine. Callers that use
        # ``enrich_symbol_relative`` directly (batched paths, tests)
        # can either ignore the field or compute their own ranks.
        out["peer_rank_in_industry"] = 0

        # Composite tags.
        out["is_alpha_leader"] = out["alpha_60d"] > threshold
        is_healthy = out["industry_phase"].isin(_HEALTHY_PHASES)
        out["is_high_beta_rider"] = (
            (out["beta_60d"] > _HIGH_BETA_THRESHOLD) & is_healthy
        )
        out["is_low_beta_quality"] = (
            (out["beta_60d"] < _LOW_BETA_THRESHOLD) & is_healthy
        )
        out["is_industry_declining"] = out["industry_phase"] == "DECLINE"

        # ── Accumulation tag (volume research, +0.76pp t=+12.25 @ 20d) ────
        # Formula from scripts/run_volume_feature_research.py::
        # accumulation_signature. All four conditions must hold:
        #
        #   1. vol_chg_60 > +30%  — sustained volume pickup
        #   2. roc_5 > 0          — last week up (not falling into it)
        #   3. close > sma_20     — short-term trend flipped positive
        #   4. close < 1.15×sma_50 — still near the base (not stretched)
        #
        # Condition 4 is what distinguishes accumulation from blow-off:
        # a stock can have high volume and rising price and still be
        # extended. The ``close < 1.15*sma_50`` clause keeps the
        # signal on early-cycle stocks.
        close = raw_df["Close"]
        volume = raw_df.get("Volume")

        # Need at least 20 bars for sma_20 (used by fading tag) and
        # 121 bars for the full accumulation formula (vol_chg_60 needs
        # two 60-bar windows). Compute sma_20 outside the gated block
        # so it's available for fading even when volume history is thin.
        if len(close) >= 20:
            sma_20 = close.rolling(20).mean()
        else:
            sma_20 = None

        if volume is not None and len(close) >= 121 and len(volume) >= 121:
            # vol_chg_60: (mean last 60) / (mean prior 60) - 1
            v60 = volume.rolling(60).mean()
            v60_prior = volume.shift(60).rolling(60).mean()
            vol_chg_60 = (v60 / v60_prior - 1) * 100

            roc_5 = close.pct_change(5) * 100
            sma_50 = close.rolling(50).mean()

            accum_mask = (
                (vol_chg_60 > _ACCUM_VOL_THRESHOLD_PCT)
                & (roc_5 > 0)
                & (close > sma_20)
                & (close < _ACCUM_BASE_MULTIPLIER * sma_50)
            )
            out["is_accumulating"] = (
                accum_mask.reindex(out.index, method="ffill").fillna(False)
                .astype(bool)
            )
        else:
            # Too few bars — signal can't be computed. NOT firing is
            # the correct default (empty tag, not a false positive).
            out["is_accumulating"] = False

        # ── Alpha-fading tag (alpha warning research, -1.25pp fwd-20d) ────
        # An ALPHA leader whose current close has fallen below its own
        # sma_20 is showing the "cumulative outperformance intact but
        # current trend breaking" pattern. Research shows this specific
        # subset of ALPHA stocks earns -1.25pp fwd-20d vs unwarned ALPHA
        # (t=-8.21, n=12,457) on the 491K-row panel, ALPHA-specific
        # (non-ALPHA cohort only loses -0.75pp on the same warning).
        #
        # Formula: ``is_alpha_leader AND close < sma_20``. Intentionally
        # fires ONLY on ALPHA stocks — this is an ALPHA-degradation flag,
        # not a general bearish signal. Non-ALPHA stocks below their
        # sma_20 don't get this tag (they can get other signals, but
        # "ALPHA fading" only applies to current ALPHA leaders).
        if sma_20 is not None:
            below_sma20 = (close < sma_20).reindex(
                out.index, method="ffill",
            ).fillna(False).astype(bool)
            out["is_alpha_fading"] = out["is_alpha_leader"] & below_sma20
        else:
            out["is_alpha_fading"] = False

        # Data sufficiency: β / α require the rolling window to be
        # full AND the industry frame's own sufficiency flag.
        ind_ok = industry_frame["data_sufficient"].reindex(
            out.index, method="ffill",
        ).fillna(False)
        out["data_sufficient"] = out["beta_60d"].notna() & ind_ok.astype(bool)

        # Annotate constants for the extractor.
        out["industry"] = industry
        return out

    def attach_alpha_percentile(
        self, frames: dict[str, pd.DataFrame],
    ) -> dict[str, pd.DataFrame]:
        """Add ``alpha_percentile`` to each frame by panel-wide rank.

        Alpha percentiles are computed across the full panel — all
        stocks' ``alpha_60d`` values at a given bar are ranked
        together, then each stock's value maps to its rank percentile.
        This matches the research's convention (the +2pp/20d edge was
        measured against panel deciles, not industry deciles).

        Args:
            frames: ``{symbol: enrich_symbol_relative output}``. Each
                frame is expected to have ``alpha_60d`` and share a
                compatible date index with the others (inner-aligned).

        Returns:
            Same keys, with ``alpha_percentile`` added as a new column
            (float, 0.0 to 100.0). Original frames are not mutated.
        """
        if not frames:
            return frames

        # Build a wide DataFrame of alphas: rows = dates, cols = symbols.
        alpha_wide = pd.DataFrame({
            sym: f["alpha_60d"] for sym, f in frames.items()
        })
        # Rank along each row (date), normalise to 0-100 percentile.
        ranks = alpha_wide.rank(axis=1, pct=True) * 100

        # Write back to each symbol's frame as a new column.
        result: dict[str, pd.DataFrame] = {}
        for sym, frame in frames.items():
            new_frame = frame.copy()
            new_frame["alpha_percentile"] = ranks[sym]
            result[sym] = new_frame
        return result

    def extract_relative_state(
        self,
        enriched: pd.DataFrame,
        bar_index: int,
        symbol: str,
    ) -> IndustryRelativeState:
        """Extract an ``IndustryRelativeState`` from an enriched
        symbol-relative frame.

        Args:
            enriched: output of ``enrich_symbol_relative``, ideally
                after ``attach_alpha_percentile`` has added the
                panel-rank column. If ``alpha_percentile`` is missing
                (caller didn't attach it), the returned state has
                ``float("nan")`` for that field.
            bar_index: integer position (``-1`` = most recent).
            symbol: for output annotation.

        Returns:
            Frozen ``IndustryRelativeState``.
        """
        row = enriched.iloc[bar_index]
        bar_date = pd.Timestamp(enriched.index[bar_index])

        alpha_pct = (
            float(row["alpha_percentile"])
            if "alpha_percentile" in enriched.columns
            else float("nan")
        )

        # New context fields — same graceful-default pattern as
        # alpha_percentile so frames that don't carry them (e.g.
        # forged test frames) still extract successfully.
        def _col(name: str, default: float) -> float:
            if name not in enriched.columns:
                return default
            val = row[name]
            return default if val != val else float(val)    # NaN guard

        def _col_int(name: str, default: int) -> int:
            if name not in enriched.columns:
                return default
            val = row[name]
            if val != val:      # NaN
                return default
            return int(val)

        return IndustryRelativeState(
            symbol=symbol,
            bar_date=bar_date,
            industry=str(row["industry"]),
            beta_60d=float(row["beta_60d"]),
            alpha_60d=float(row["alpha_60d"]),
            alpha_percentile=alpha_pct,
            industry_phase=str(row["industry_phase"]),
            industry_roc_20=_col("industry_roc_20", float("nan")),
            industry_breadth_pct=_col("industry_breadth_pct", float("nan")),
            peer_count_in_industry=_col_int("peer_count_in_industry", 0),
            peer_rank_in_industry=_col_int("peer_rank_in_industry", 0),
            is_alpha_leader=bool(row["is_alpha_leader"]),
            is_high_beta_rider=bool(row["is_high_beta_rider"]),
            is_low_beta_quality=bool(row["is_low_beta_quality"]),
            is_industry_declining=bool(row["is_industry_declining"]),
            is_accumulating=(
                bool(row["is_accumulating"])
                if "is_accumulating" in enriched.columns
                else False
            ),
            is_alpha_fading=(
                bool(row["is_alpha_fading"])
                if "is_alpha_fading" in enriched.columns
                else False
            ),
            data_sufficient=bool(row["data_sufficient"]),
        )

    # ══════════════════════════════════════════════════════════════════════
    # High-level convenience
    # ══════════════════════════════════════════════════════════════════════

    def analyze_symbol(
        self,
        panel: dict[str, pd.DataFrame],
        symbol: str,
        industry_map: dict[str, str],
    ) -> IndustryRelativeState | None:
        """Produce an ``IndustryRelativeState`` for one symbol, end-to-end.

        This is the ergonomic entry point for UI code. Internally:
        1. Looks up the symbol's industry.
        2. Collects the industry's member panel from ``panel``.
        3. Runs ``enrich_industry`` on that panel.
        4. Runs ``enrich_symbol_relative`` for the symbol.
        5. Extracts the state at the most recent bar.

        Args:
            panel: the full ``{symbol: DataFrame}`` panel. Usually the
                shared scan / dashboard cache.
            symbol: the symbol to analyze.
            industry_map: ``{symbol: industry_name}`` — typically
                built from ``load_industry_db()`` by the caller.

        Returns:
            ``IndustryRelativeState`` at the most recent bar, OR
            ``None`` in any of these recoverable cases:
              - symbol not present in ``panel``
              - symbol's industry isn't in ``industry_map``
              - industry has fewer than ``MIN_INDUSTRY_SIZE`` members
                in the panel
              - underlying DataFrame is too short for the engine to
                produce a valid state

        Does NOT compute ``alpha_percentile`` — that requires a
        panel-wide cross-section which is too expensive for a
        per-symbol call. The returned state has ``alpha_percentile``
        as ``NaN`` and consumers should handle that. A future scheduled
        pass can populate the percentile for all symbols at once via
        ``attach_alpha_percentile`` on the batched frames.
        """
        if symbol not in panel:
            return None
        industry = industry_map.get(symbol)
        if industry is None:
            return None

        # Gather the industry's peers from the panel.
        industry_panel = {
            sym: df for sym, df in panel.items()
            if industry_map.get(sym) == industry and "Close" in df.columns
        }
        if len(industry_panel) < self.MIN_INDUSTRY_SIZE:
            return None

        try:
            ind_frame = self.enrich_industry(industry_panel)
        except ValueError:
            return None

        rel_frame = self.enrich_symbol_relative(
            raw_df=panel[symbol],
            symbol=symbol,
            industry=industry,
            industry_frame=ind_frame,
        )
        # Need at least one bar of valid β/α data.
        if rel_frame["data_sufficient"].sum() == 0:
            return None

        # Peer rank: where does this symbol sit among its industry
        # peers by 60d return? Cheap (~30 peers × 2 lookups), done
        # once at the tail of analyze_symbol so the UI path gets a
        # concrete rank rather than the sentinel 0 that
        # enrich_symbol_relative leaves behind. Batched consumers
        # (step 3b) will compute the same rank across their pass and
        # overwrite in place.
        peer_returns: list[tuple[str, float]] = []
        for peer_sym, peer_df in industry_panel.items():
            close = peer_df["Close"]
            if len(close) < 61:
                continue
            last = float(close.iloc[-1])
            ref = float(close.iloc[-61])
            if ref <= 0:
                continue
            peer_returns.append((peer_sym, last / ref - 1.0))
        if peer_returns:
            # Sort descending by 60d return — rank 1 = best performer.
            peer_returns.sort(key=lambda t: t[1], reverse=True)
            rank_map = {
                p_sym: idx + 1 for idx, (p_sym, _) in enumerate(peer_returns)
            }
            rank = rank_map.get(symbol, 0)
            # Write to the frame's last row so extract picks it up.
            rel_frame.loc[rel_frame.index[-1], "peer_rank_in_industry"] = rank

        # Extract at the most recent bar — that's what the UI wants.
        return self.extract_relative_state(rel_frame, -1, symbol)

    def batch_analyze(
        self,
        panel: dict[str, pd.DataFrame],
        industry_map: dict[str, str],
    ) -> dict[str, IndustryRelativeState]:
        """Produce ``IndustryRelativeState`` for every symbol in
        ``panel`` in a single pass.

        Unlike ``analyze_symbol`` which computes for one symbol at
        a time and leaves ``alpha_percentile`` as NaN (because
        cross-panel ranking requires all symbols), this method:

        1. Groups the panel by industry and runs ``enrich_industry``
           once per industry.
        2. Runs ``enrich_symbol_relative`` once per symbol against
           the industry frame built in step 1.
        3. Runs ``attach_alpha_percentile`` across all per-symbol
           frames so every state carries a real 0-100 percentile.
        4. Computes peer ranks per industry (same logic as
           ``analyze_symbol`` but vectorised across all members of
           each industry).
        5. Extracts the latest-bar state for each symbol.

        Call this once per scan cycle; cache the result on the
        caller. Typical cost: 2-3s on a 463-symbol panel with 34
        industries.

        Args:
            panel: full ``{symbol: DataFrame}`` panel.
            industry_map: ``{symbol: industry_name}``.

        Returns:
            ``{symbol: IndustryRelativeState}`` for every symbol
            that produced a valid state. Symbols that fail any
            validity check (too few peers, insufficient history,
            no industry classification) are omitted from the
            result — callers should treat absence as equivalent
            to the None return of ``analyze_symbol``.
        """
        # ── 1. Group by industry, keep only industries with enough members ─
        industries: dict[str, dict[str, pd.DataFrame]] = {}
        for sym, df in panel.items():
            ind = industry_map.get(sym)
            if ind is None or "Close" not in df.columns:
                continue
            industries.setdefault(ind, {})[sym] = df
        industries = {
            ind: members for ind, members in industries.items()
            if len(members) >= self.MIN_INDUSTRY_SIZE
        }
        if not industries:
            return {}

        # ── 2. Enrich each industry once ──────────────────────────────────
        industry_frames: dict[str, pd.DataFrame] = {}
        for ind, members in industries.items():
            try:
                industry_frames[ind] = self.enrich_industry(members)
            except ValueError:
                continue      # industry too small — already filtered, but safety

        # ── 3. Enrich each symbol relative to its industry ────────────────
        rel_frames: dict[str, pd.DataFrame] = {}
        for ind, members in industries.items():
            if ind not in industry_frames:
                continue
            ind_frame = industry_frames[ind]
            for sym, df in members.items():
                try:
                    rel_frames[sym] = self.enrich_symbol_relative(
                        raw_df=df,
                        symbol=sym,
                        industry=ind,
                        industry_frame=ind_frame,
                    )
                except Exception:      # noqa: BLE001 — skip degenerate symbols
                    continue

        # ── 4. Peer rank within each industry at the latest bar ──────────
        # Done per-industry so ranks reflect only same-industry peers.
        # Each symbol's 60d return measured from its own frame, then
        # sorted within its industry cohort.
        for ind, members in industries.items():
            peer_returns: list[tuple[str, float]] = []
            for sym, df in members.items():
                if sym not in rel_frames:
                    continue
                close = df["Close"]
                if len(close) < 61:
                    continue
                last = float(close.iloc[-1])
                ref = float(close.iloc[-61])
                if ref <= 0:
                    continue
                peer_returns.append((sym, last / ref - 1.0))
            if not peer_returns:
                continue
            peer_returns.sort(key=lambda t: t[1], reverse=True)
            for rank_idx, (sym, _) in enumerate(peer_returns, start=1):
                rel_frames[sym].loc[
                    rel_frames[sym].index[-1],
                    "peer_rank_in_industry",
                ] = rank_idx

        # ── 5. Attach panel-wide α percentile ─────────────────────────────
        # This is what ``analyze_symbol`` can't do alone — only a
        # cross-panel pass knows where each symbol's alpha ranks in
        # the full distribution. Matches the research methodology
        # (panel deciles, not industry deciles).
        ranked = self.attach_alpha_percentile(rel_frames)

        # ── 6. Extract latest-bar state for each symbol ──────────────────
        out: dict[str, IndustryRelativeState] = {}
        for sym, frame in ranked.items():
            # Skip symbols with no valid data at the latest bar.
            if frame.empty or not bool(frame["data_sufficient"].iloc[-1]):
                continue
            try:
                out[sym] = self.extract_relative_state(frame, -1, sym)
            except Exception:     # noqa: BLE001 — best-effort
                continue
        return out
