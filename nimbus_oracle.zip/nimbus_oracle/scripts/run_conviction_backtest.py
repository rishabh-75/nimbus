#!/usr/bin/env python3
"""
scripts/run_conviction_backtest.py — Full conviction engine backtest.

Tests the ACTUAL impact of using conviction grades as trade filters:
  1. Baseline: take ALL entry signals (current system)
  2. Grade filter: only take grade >= threshold (A+, A, B+, etc.)
  3. Sizing by grade: FULL for A+/A, HALF for B+/B, SKIP for C/D
  4. Combined: grade filter + VIX gate + Friday gate
  5. Parameter sweep: optimize grade threshold for max Sharpe

Also measures:
  - Equity curve for each strategy
  - Maximum drawdown
  - Win rate, Sharpe, profit factor
  - Capital efficiency (return per trade taken)

Usage:
    python3 scripts/run_conviction_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("conviction_bt")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="conviction_backtest_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["exit_date"] = pd.to_datetime(trades_df["exit_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    # ── Reconstruct features ────────────────────────────────────────
    logger.info("Reconstructing entry features + conviction grades...")
    from modules.dual_mode import compute_dual_mode
    from modules.conviction import ConvictionEngine

    engine = ConvictionEngine()

    price_cache = {}
    for sym in trades_df["symbol"].unique():
        f = f"data/backtest_cache/{sym}_1d.parquet"
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except: pass

    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    rows = []
    skipped = 0
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in price_cache: skipped += 1; continue
        pdf = price_cache[sym]
        mask = pdf.index <= trade["entry_date"]
        if mask.sum() < 40: skipped += 1; continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient: skipped += 1; continue

            vmask = vix_series.index <= trade["entry_date"]
            vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0

            conv = engine.compute(sig, vix=vix)

            rows.append({
                "symbol": sym,
                "entry_date": trade["entry_date"],
                "exit_date": trade["exit_date"],
                "pnl_pct": trade["pnl_pct"],
                "win": int(trade["pnl_pct"] > 0),
                "exit_reason": trade["exit_reason"],
                "tier": trade["tier"],
                "score": sig.dual_score,
                "vix": vix,
                "vix_regime": conv.vix_regime,
                "is_friday": int(trade["entry_date"].weekday() == 4),
                "grade": conv.grade,
                "effective_sizing": conv.effective_sizing,
                "mfi": sig.mfi,
                "rsi": sig.rsi,
                "wr": sig.wr_30,
                "vol_ratio": sig.vol_ratio,
                "dd": sig.dd_from_high,
            })
        except: skipped += 1

        if (len(rows) + skipped) % 500 == 0:
            logger.info("  %d/%d processed", len(rows), len(trades_df))

    df = pd.DataFrame(rows)
    df = df.sort_values("entry_date").reset_index(drop=True)
    logger.info("Features: %d trades (%d skipped)", len(df), skipped)

    GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6}
    df["grade_num"] = df["grade"].map(GRADE_ORD).fillna(7)

    report = []
    report.append("=" * 70)
    report.append("CONVICTION ENGINE BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)} | Symbols: {df['symbol'].nunique()}")
    report.append(f"Period: {df['entry_date'].min().date()} to {df['entry_date'].max().date()}")
    report.append("=" * 70)

    def compute_stats(subset, name):
        n = len(subset)
        if n < 10:
            return {"name": name, "n": n, "win": 0, "avg": 0, "sh": 0, "pf": 0,
                    "mdd": 0, "pt_pct": 0, "max_pct": 0}
        wr = subset["win"].mean() * 100
        avg = subset["pnl_pct"].mean()
        sh = avg / subset["pnl_pct"].std() * np.sqrt(252/10) if subset["pnl_pct"].std() > 0 else 0
        wins = subset[subset["pnl_pct"] > 0]["pnl_pct"].sum()
        losses = abs(subset[subset["pnl_pct"] < 0]["pnl_pct"].sum())
        pf = wins / losses if losses > 0 else 999
        pt_pct = (subset["exit_reason"] == "PT").mean() * 100
        max_pct = (subset["exit_reason"] == "MAX").mean() * 100

        # Max drawdown on equity curve
        eq = (1 + subset["pnl_pct"] / 100).cumprod()
        peak = eq.cummax()
        dd = ((eq - peak) / peak * 100)
        mdd = dd.min()

        return {"name": name, "n": n, "win": wr, "avg": avg, "sh": sh, "pf": pf,
                "mdd": mdd, "pt_pct": pt_pct, "max_pct": max_pct}

    # ══════════════════════════════════════════════════════════════════
    # TEST 1: BASELINE vs GRADE FILTERS
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 1: GRADE AS TRADE FILTER")
    report.append("=" * 70)
    report.append("  Only take trades at or above a grade threshold.")
    report.append("")
    report.append(f"  {'Strategy':25s} {'N':>5s} {'Win%':>6s} {'Avg':>8s} {'Sh':>6s} {'PF':>5s} {'MDD':>7s} {'PT%':>5s} {'MAX%':>5s}")

    strategies = [
        ("All trades (baseline)", df),
        ("Grade >= D  (all graded)", df[df["grade"].isin(GRADE_ORD.keys())]),
        ("Grade >= C", df[df["grade_num"] <= 5]),
        ("Grade >= C+", df[df["grade_num"] <= 4]),
        ("Grade >= B", df[df["grade_num"] <= 3]),
        ("Grade >= B+", df[df["grade_num"] <= 2]),
        ("Grade >= A", df[df["grade_num"] <= 1]),
        ("Grade A+ only", df[df["grade"] == "A+"]),
    ]

    for name, subset in strategies:
        s = compute_stats(subset, name)
        report.append(f"  {s['name']:25s} {s['n']:5d} {s['win']:5.1f}% {s['avg']:+7.3f}% {s['sh']:5.2f} {s['pf']:4.2f} {s['mdd']:+6.1f}% {s['pt_pct']:4.0f}% {s['max_pct']:4.0f}%")

    # ══════════════════════════════════════════════════════════════════
    # TEST 2: GRADE-BASED SIZING
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 2: GRADE-BASED SIZING")
    report.append("=" * 70)
    report.append("  Apply position size multiplier by grade.")
    report.append("")

    sizing_configs = [
        ("Equal weight (1x all)", {"A+": 1, "A": 1, "B+": 1, "B": 1, "C+": 1, "C": 1, "D": 1}),
        ("Grade sizing (1.5/1/0.5/0)", {"A+": 1.5, "A": 1.5, "B+": 1.0, "B": 1.0, "C+": 0.5, "C": 0.5, "D": 0}),
        ("Aggressive (2/1/0.5/0)", {"A+": 2.0, "A": 2.0, "B+": 1.0, "B": 1.0, "C+": 0.5, "C": 0, "D": 0}),
        ("Conservative (1/1/0.5/0)", {"A+": 1.0, "A": 1.0, "B+": 1.0, "B": 0.5, "C+": 0, "C": 0, "D": 0}),
        ("Top grades only (1/0)", {"A+": 1.0, "A": 1.0, "B+": 0, "B": 0, "C+": 0, "C": 0, "D": 0}),
    ]

    report.append(f"  {'Config':30s} {'Wtd Avg':>8s} {'Wtd Sh':>7s} {'Trades':>7s}")
    for name, weights in sizing_configs:
        graded = df[df["grade"].isin(weights.keys())].copy()
        graded["weight"] = graded["grade"].map(weights)
        graded = graded[graded["weight"] > 0]
        if len(graded) < 20:
            report.append(f"  {name:30s}  (N<20, skipped)")
            continue
        wtd_pnl = (graded["pnl_pct"] * graded["weight"]).sum() / graded["weight"].sum()
        wtd_std = np.sqrt(((graded["pnl_pct"] * graded["weight"])**2).sum() / graded["weight"].sum())
        wtd_sh = wtd_pnl / wtd_std * np.sqrt(252/10) if wtd_std > 0 else 0
        report.append(f"  {name:30s} {wtd_pnl:+7.3f}% {wtd_sh:6.2f}  {len(graded):6d}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 3: VIX GATE + GRADE FILTER COMBINED
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 3: VIX GATE + GRADE COMBINED")
    report.append("=" * 70)
    report.append("")

    combos = [
        ("All trades", df),
        ("VIX gate only (skip Normal+SEC)", df[~((df["vix_regime"] == "NORMAL") & (df["tier"] == "SECONDARY"))]),
        ("Grade >= B only", df[df["grade_num"] <= 3]),
        ("Grade >= B + VIX gate", df[(df["grade_num"] <= 3) & ~((df["vix_regime"] == "NORMAL") & (df["tier"] == "SECONDARY"))]),
        ("Grade >= B+ + VIX gate", df[(df["grade_num"] <= 2) & ~((df["vix_regime"] == "NORMAL") & (df["tier"] == "SECONDARY"))]),
        ("Skip Friday + stressed VIX", df[~((df["is_friday"] == 1) & (df["vix_regime"].isin(["ELEVATED", "PANIC"])))]),
        ("Full combo (B+ + VIX + Fri)", df[(df["grade_num"] <= 2) &
                                            ~((df["vix_regime"] == "NORMAL") & (df["tier"] == "SECONDARY")) &
                                            ~((df["is_friday"] == 1) & (df["vix_regime"].isin(["ELEVATED", "PANIC"])))]),
    ]

    report.append(f"  {'Strategy':35s} {'N':>5s} {'Win%':>6s} {'Avg':>8s} {'Sh':>6s} {'PF':>5s} {'MDD':>7s}")
    for name, subset in combos:
        s = compute_stats(subset, name)
        report.append(f"  {s['name']:35s} {s['n']:5d} {s['win']:5.1f}% {s['avg']:+7.3f}% {s['sh']:5.2f} {s['pf']:4.2f} {s['mdd']:+6.1f}%")

    # ══════════════════════════════════════════════════════════════════
    # TEST 4: GRADE × VIX REGIME CROSS-TAB
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 4: WIN RATE BY GRADE × VIX REGIME")
    report.append("=" * 70)

    header = f"\n  {'':5s}"
    for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
        header += f"  {vr:14s}"
    header += f"  {'ALL':14s}"
    report.append(header)

    for g in ["A+", "A", "B+", "B", "C+", "C", "D"]:
        row_str = f"  {g:5s}"
        for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            mask = (df["grade"] == g) & (df["vix_regime"] == vr)
            n = mask.sum()
            if n < 5:
                row_str += f"  {'—':14s}"
            else:
                wr = df.loc[mask, "win"].mean() * 100
                avg = df.loc[mask, "pnl_pct"].mean()
                row_str += f"  {wr:.0f}% N={n:4d}   "
        # All regimes
        mask_all = df["grade"] == g
        n_all = mask_all.sum()
        if n_all >= 5:
            wr_all = df.loc[mask_all, "win"].mean() * 100
            row_str += f"  {wr_all:.0f}% N={n_all:4d}   "
        report.append(row_str)

    # ══════════════════════════════════════════════════════════════════
    # TEST 5: FACTOR CONTRIBUTION TO GRADE PERFORMANCE
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 5: WHAT MAKES A+/A TRADES WIN?")
    report.append("=" * 70)

    top = df[df["grade_num"] <= 1]
    bot = df[df["grade_num"] >= 5]
    report.append(f"\n  A+/A profile (N={len(top)}) vs C/D profile (N={len(bot)}):")
    for col, label in [("mfi", "MFI"), ("rsi", "RSI"), ("vol_ratio", "Vol ratio"),
                        ("wr", "WR"), ("dd", "DD%"), ("vix", "VIX"), ("score", "Score")]:
        t_avg = top[col].mean()
        b_avg = bot[col].mean()
        report.append(f"  {label:12s}: A/A+ avg={t_avg:+7.1f}   C/D avg={b_avg:+7.1f}   diff={t_avg-b_avg:+7.1f}")

    report.append(f"\n  Exit reason distribution:")
    for reason in ["PT", "BBW", "MAX"]:
        t_pct = (top["exit_reason"] == reason).mean() * 100
        b_pct = (bot["exit_reason"] == reason).mean() * 100
        report.append(f"    {reason:4s}: A/A+={t_pct:.0f}%   C/D={b_pct:.0f}%")

    # ══════════════════════════════════════════════════════════════════
    # TEST 6: OPTIMAL GRADE THRESHOLD (SHARPE MAXIMIZER)
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 6: OPTIMAL GRADE THRESHOLD")
    report.append("=" * 70)
    report.append("  Which minimum grade maximizes risk-adjusted returns?")
    report.append("")

    best_sh = -999
    best_thresh = None
    for thresh in range(7):  # 0=A+ to 6=D
        mask = df["grade_num"] <= thresh
        subset = df[mask]
        if len(subset) < 50: continue
        s = compute_stats(subset, f"grade_num <= {thresh}")
        grade_name = [g for g, v in GRADE_ORD.items() if v == thresh][0]
        report.append(f"  >= {grade_name:3s}: N={s['n']:5d}  Win={s['win']:.1f}%  Avg={s['avg']:+.3f}%  Sh={s['sh']:.2f}  PF={s['pf']:.2f}  Trades/yr≈{s['n']/3:.0f}")
        if s["sh"] > best_sh:
            best_sh = s["sh"]
            best_thresh = grade_name

    report.append(f"\n  OPTIMAL threshold: >= {best_thresh} (Sharpe={best_sh:.2f})")
    report.append(f"  This means: skip trades graded below {best_thresh}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 7: TIME-SERIES VALIDATION (yearly breakdown)
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 7: YEARLY BREAKDOWN — GRADE >= B+")
    report.append("=" * 70)

    df["year"] = df["entry_date"].dt.year
    filtered = df[df["grade_num"] <= 2]  # B+ and above

    report.append(f"\n  {'Year':6s} {'All N':>6s} {'Filt N':>7s} {'All Win':>8s} {'Filt Win':>9s} {'All Sh':>7s} {'Filt Sh':>8s}")
    for year in sorted(df["year"].unique()):
        all_yr = df[df["year"] == year]
        filt_yr = filtered[filtered["year"] == year]
        sa = compute_stats(all_yr, "all")
        sf = compute_stats(filt_yr, "filt")
        report.append(f"  {year:6d} {sa['n']:6d} {sf['n']:7d} {sa['win']:7.1f}% {sf['win']:8.1f}% {sa['sh']:6.2f}  {sf['sh']:7.2f}")

    # ══════════════════════════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("SUMMARY")
    report.append("=" * 70)

    all_s = compute_stats(df, "All")
    opt_s = compute_stats(df[df["grade_num"] <= GRADE_ORD.get(best_thresh, 3)], f">= {best_thresh}")
    aa_s = compute_stats(df[df["grade_num"] <= 1], "A+/A only")

    report.append(f"""
  Baseline (all signals):    {all_s['n']:4d} trades  Win={all_s['win']:.1f}%  Sh={all_s['sh']:.2f}  PF={all_s['pf']:.2f}
  Optimal (>= {best_thresh}):            {opt_s['n']:4d} trades  Win={opt_s['win']:.1f}%  Sh={opt_s['sh']:.2f}  PF={opt_s['pf']:.2f}
  A+/A only:                 {aa_s['n']:4d} trades  Win={aa_s['win']:.1f}%  Sh={aa_s['sh']:.2f}  PF={aa_s['pf']:.2f}

  Trade reduction: {(1 - opt_s['n']/all_s['n'])*100:.0f}% fewer trades for optimal threshold
  Sharpe improvement: {all_s['sh']:.2f} → {opt_s['sh']:.2f} ({(opt_s['sh']-all_s['sh'])/all_s['sh']*100:+.0f}%)
  Win rate improvement: {all_s['win']:.1f}% → {opt_s['win']:.1f}% ({opt_s['win']-all_s['win']:+.1f}pp)
""")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
