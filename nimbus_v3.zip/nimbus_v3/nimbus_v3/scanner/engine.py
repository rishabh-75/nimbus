"""nimbus_v3.scanner.engine — scan orchestration.

Composes every layer below it — ``PriceLoader`` (equity + index
panels), context providers, ``StrategyRegistry``, and
``ConvictionEngine`` — into a single pass that produces scored
``ScanResult`` rows for a universe of symbols.

Design invariants
─────────────────

1. **Stateless orchestrator.** The Scanner holds only its injected
   components. Running two scans back-to-back with the same Scanner
   instance must produce the same results given the same inputs.

2. **All data sources injected.** The Scanner does not construct
   loaders, providers, or strategies. A composition root (factory,
   main script, test fixture) wires the graph. This keeps the
   Scanner trivially testable with fakes.

3. **No re-grading.** Each firing signal is graded exactly once by
   ``ConvictionEngine.grade``. The ``Conviction`` is passed through
   unchanged.

4. **Failure mode is partial output, not exception.** If a single
   symbol fails (indicator extraction raises, provider returns an
   error), the Scanner logs and continues. A scan returns a list of
   successes; the caller decides how to treat the skips.

The Scanner is layer-N-1 of the architecture: below it are pure
components (loaders, strategies, engine); above it sit the UI and
SignalTracker. Phase 6 will hook SignalTracker.record() onto the
Scanner's emit path.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable, Iterable

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.context.base import ContextProvider
from nimbus_v3.conviction.grade_engine import Conviction, ConvictionEngine
from nimbus_v3.core.context import (
    ContextBundle,
    FilingContext,
    MarketContext,
    OptionsContext,
    SectorContext,
)
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.strategies.base import Strategy
from nimbus_v3.strategies.registry import StrategyRegistry


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Output shape
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class ScanResult:
    """One graded signal produced by a scan.

    Carries the strategy that fired plus the authoritative ``Conviction``.
    Downstream consumers (UI, SignalTracker) read from this record; they
    do not regrade.

    ``close_price`` is the unadjusted closing price on ``asof_date``,
    captured at scan time so the signal tracker can compute realised
    forward returns later without needing to refetch the price panel
    for this exact date.
    """
    symbol: str
    asof_date: pd.Timestamp
    strategy: Strategy
    conviction: Conviction
    close_price: float

    @property
    def score(self) -> float:
        """Convenience accessor — proxies ``self.conviction.score``."""
        return self.conviction.score


# ══════════════════════════════════════════════════════════════════════════════
# Providers bundle
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class ContextProviders:
    """Bundled context provider registrations injected into the Scanner.

    Every provider field is optional — a Scanner constructed with
    ``providers=ContextProviders(market=m, sector=s)`` simply omits
    the absent contexts from the resulting ``ContextBundle``. The
    conviction formula tolerates missing contexts (returns 0 for
    contributions that need data they don't have).
    """
    market: ContextProvider[MarketContext] | None = None
    sector: ContextProvider[SectorContext] | None = None
    options: ContextProvider[OptionsContext] | None = None
    filing: ContextProvider[FilingContext] | None = None


# ══════════════════════════════════════════════════════════════════════════════
# Rich scan output (Phase 11C — Dashboard consumer only)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class ScanSnapshot:
    """Rich snapshot of one scan pass, suitable for UI consumption.

    Carries the lean ``results`` list plus per-symbol ``SignalState``
    and ``ContextBundle`` dicts. The Dashboard tab uses these to
    populate KPI tiles, badge rows, level grids, and the Workflow
    Analysis panel without recomputing anything — preserving the
    "UI never recomputes" invariant from Phase 4.

    Only symbols that produced at least one ``ScanResult`` are
    captured in the per-symbol dicts. Symbols that failed or didn't
    fire are skipped (callers can fall back to scanner re-run if they
    need state for a non-firing symbol).

    Tracker / CSV / research harness continue to consume the lean
    ``list[ScanResult]`` returned by ``scan()``. ``ScanSnapshot`` is
    purpose-built for the UI and isn't threaded through those paths.
    """
    results: list[ScanResult]
    state_by_symbol: dict[str, SignalState]
    contexts_by_symbol: dict[str, ContextBundle]
    enriched_panel: dict[str, pd.DataFrame]
    asof_date: pd.Timestamp


# ══════════════════════════════════════════════════════════════════════════════
# Scanner
# ══════════════════════════════════════════════════════════════════════════════

class Scanner:
    """Top-level scan orchestrator.

    A single shared instance is expected across all scans in a given
    process. Not thread-safe for concurrent ``scan()`` calls on the
    same instance — clone the Scanner per worker if parallelising.
    """

    def __init__(
        self,
        *,
        compute_engine: StrategyComputeEngine,
        registry: StrategyRegistry,
        providers: ContextProviders,
        conviction_engine: ConvictionEngine,
        universe: Universe,
    ) -> None:
        self._compute = compute_engine
        self._registry = registry
        self._providers = providers
        self._conviction = conviction_engine
        self._universe = universe

    # ── Public accessors ─────────────────────────────────────────────────

    @property
    def universe(self) -> Universe:
        """The composed :class:`Universe`. Exposed so the UI can slice
        by index membership (``"NIFTY 50"``, ``"NIFTY BANK"``, …) to
        scope a scan — callers should prefer this over reaching for
        the underscore-prefixed attribute."""
        return self._universe

    def with_registry(self, new_registry: StrategyRegistry) -> "Scanner":
        """Return a new :class:`Scanner` that reuses this one's
        compute engine, providers, conviction engine, and universe,
        but uses a different strategy registry.

        This is the canonical entry point for strategy-mode swaps at
        runtime (see ``MainWindow.set_strategy_mode``). It preserves
        the encapsulation boundary: callers don't need to know which
        collaborators the Scanner holds, only that "same data
        pipeline, different strategies" is a supported operation.

        The original scanner is unchanged — this is a clone, not a
        mutation. Both instances remain usable, which means an
        in-flight scan on the old scanner can complete normally while
        the new scanner starts serving subsequent requests.
        """
        return Scanner(
            compute_engine=self._compute,
            registry=new_registry,
            providers=self._providers,
            conviction_engine=self._conviction,
            universe=self._universe,
        )

    def with_universe(
        self,
        new_universe: Universe,
        new_providers: "ContextProviders | None" = None,
    ) -> "Scanner":
        """Return a new :class:`Scanner` that reuses this one's
        registry, compute engine, and conviction engine, but uses a
        different universe (and optionally different providers).

        Companion to :meth:`with_registry`. Used by the scan-path
        enrichment step: ``ensure_enriched_state`` loads the live
        universe + sector provider on first scan, and needs to build
        a scanner that has that universe *while preserving whatever
        registry the user has toggled to* (conservative vs aggressive).

        Before this method existed, ``ensure_enriched_state`` built a
        Scanner from module-scope ``registry`` which was frozen at
        startup — runtime mode toggles didn't survive the first scan.
        That bug is closed by routing through here instead.

        ``new_providers=None`` preserves the current provider set,
        which is the right default when only the universe changed.
        """
        return Scanner(
            compute_engine=self._compute,
            registry=self._registry,
            providers=new_providers if new_providers is not None else self._providers,
            conviction_engine=self._conviction,
            universe=new_universe,
        )

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def scan(
        self,
        *,
        enriched_panel: dict[str, pd.DataFrame],
        asof_date: pd.Timestamp,
        symbols: Iterable[str] | None = None,
    ) -> list[ScanResult]:
        """Run a scan across ``symbols``.

        Args:
            enriched_panel: Dict of ``symbol → DataFrame`` already enriched
                with indicators (via ``StrategyComputeEngine.enrich``).
                Pre-computing this outside the Scanner lets the same
                panel be reused across many scans without re-enrichment.
            asof_date: Bar date for the scan. All contexts are built as
                of this date. Strict requirement — never defaults to
                ``datetime.now()``.
            symbols: Restrict the scan to a subset of the universe. If
                ``None``, scan every symbol present in ``enriched_panel``
                that is also in the universe.

        Returns:
            Sorted list of ``ScanResult`` (highest conviction.score first).
            Empty list if no symbol fires a signal.
        """
        asof = self._normalise(asof_date)
        target_symbols = self._resolve_symbols(symbols, enriched_panel)
        results: list[ScanResult] = []

        for symbol in target_symbols:
            try:
                symbol_results = self._scan_symbol(
                    symbol=symbol,
                    enriched_df=enriched_panel[symbol],
                    asof_date=asof,
                )
            except Exception:     # noqa: BLE001
                logger.exception(
                    "scanner: unexpected failure on symbol %r — skipping", symbol,
                )
                continue
            results.extend(symbol_results)

        # Sort: highest score first, stable on ties via strategy priority
        # and strategy name (matching the registry's tiebreak order).
        results.sort(
            key=lambda r: (
                -r.conviction.score,
                -r.strategy.priority,
                r.strategy.name,
            ),
        )
        return results

    # ══════════════════════════════════════════════════════════════════════
    # Per-symbol scan
    # ══════════════════════════════════════════════════════════════════════

    def evaluate_symbol(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,
        asof_date: pd.Timestamp,
        symbol_meta: SymbolMeta | None = None,
    ) -> list[ScanResult]:
        """Evaluate every registered strategy against
        ``(state, contexts)`` for a single symbol and grade each
        firing signal.

        This is the public, symbol-granular entry point for the
        evaluate → grade pipeline. Both the internal scan loop
        (:meth:`_scan_symbol`) and dashboard-style single-symbol
        callers (``MainWindow._run_strategies_for_symbol``) go
        through this method — DRY over a duplicated pipeline that
        previously lived in both places.

        Parameters
        ----------
        symbol
            Ticker string; used for logging and ``ScanResult.symbol``.
        state
            Pre-computed ``SignalState`` for the symbol at ``asof_date``.
            The caller is responsible for extracting state from its
            own source (enriched panel for scan, dashboard's provider
            set for single-symbol loads).
        contexts
            Pre-built ``ContextBundle``. Same responsibility split.
            Different call paths may build this from different
            provider sets (scanner strips options for scan speed;
            dashboard includes them for full overlay).
        asof_date
            Stamped onto every emitted ``ScanResult``.
        symbol_meta
            Optional — when the caller has already resolved it (as
            the scan loop has), pass it in to skip the redundant
            lookup. Dashboard-style callers can leave it as ``None``
            and rely on the stub fallback below.

        Stub fallback
        -------------
        If ``symbol_meta`` is omitted and the symbol isn't in the
        universe, a default-valued :class:`SymbolMeta` is constructed.
        This is safe because :meth:`Strategy.accepts` only reads
        ``is_etf`` / ``is_fno`` fields, both of which default to
        False on the stub — effectively "treat this symbol as a
        generic equity". Necessary for the dashboard use case where
        the operator may load a symbol before the universe is fully
        built (first run, pre-scan).

        Returns
        -------
        list[ScanResult]
            One entry per firing strategy. Empty when nothing fires.
            Results are NOT sorted here — the scan path does its own
            canonical sort on the accumulated list; dashboard callers
            don't need sorted output.
        """
        if symbol_meta is None:
            symbol_meta = (
                self._universe.symbols.get(symbol)
                or SymbolMeta(symbol=symbol)
            )

        signals = self._registry.evaluate_all(
            symbol=symbol, symbol_meta=symbol_meta,
            state=state, contexts=contexts,
        )
        if not signals:
            return []

        out: list[ScanResult] = []
        for signal in signals:
            strategy = self._lookup_strategy(signal.strategy_name)
            if strategy is None:
                logger.warning(
                    "evaluate_symbol: signal from unknown strategy %r — "
                    "skipping grade", signal.strategy_name,
                )
                continue
            conviction = self._conviction.grade(
                state=state, contexts=contexts,
                signal=signal, strategy=strategy,
            )
            out.append(ScanResult(
                symbol=symbol,
                asof_date=asof_date,
                strategy=strategy,
                conviction=conviction,
                close_price=float(state.close),
            ))
        return out

    def _scan_symbol(
        self,
        *,
        symbol: str,
        enriched_df: pd.DataFrame,
        asof_date: pd.Timestamp,
        snapshot_accumulator: dict[str, dict] | None = None,
    ) -> list[ScanResult]:
        """Run the full per-symbol pipeline at ``asof_date``.

        Thin wrapper that handles the scan-specific concerns
        (state extraction from the enriched DataFrame, context
        building from the scanner's own provider set, snapshot
        accumulator population) and delegates the evaluate+grade
        core to :meth:`evaluate_symbol`.

        When ``snapshot_accumulator`` is supplied, the per-symbol
        ``SignalState`` and ``ContextBundle`` are captured into its
        ``"state"`` and ``"contexts"`` sub-dicts iff the symbol fired
        at least one signal. Callers use this to build a
        ``ScanSnapshot`` without a second orchestration loop.
        """
        meta = self._universe.symbols.get(symbol)
        if meta is None:
            return []

        bar_index = self._resolve_bar_index(enriched_df, asof_date)
        if bar_index is None:
            return []

        state = self._compute.extract_state(enriched_df, bar_index, symbol)
        contexts = self.build_context_bundle(symbol=symbol, asof_date=asof_date)

        out = self.evaluate_symbol(
            symbol=symbol, state=state, contexts=contexts,
            asof_date=asof_date, symbol_meta=meta,
        )

        # Capture state + contexts for the UI snapshot if requested.
        # Only done when the symbol actually fired — non-firing symbols
        # are uninteresting to the Dashboard.
        if out and snapshot_accumulator is not None:
            snapshot_accumulator["state"][symbol] = state
            snapshot_accumulator["contexts"][symbol] = contexts

        return out

    # ══════════════════════════════════════════════════════════════════════
    # Rich scan output (Phase 11C)
    # ══════════════════════════════════════════════════════════════════════

    def scan_with_snapshot(
        self,
        *,
        enriched_panel: dict[str, pd.DataFrame],
        asof_date: pd.Timestamp,
        symbols: Iterable[str] | None = None,
        progress_callback: Callable[[int, int, str], None] | None = None,
        result_callback: Callable[
            [list[ScanResult], "SignalState | None"], None
        ] | None = None,
    ) -> ScanSnapshot:
        """Run a scan and capture the per-symbol ``SignalState`` +
        ``ContextBundle`` that drove each result.

        Produces a ``ScanSnapshot`` containing the same sorted results
        list as ``scan()`` plus two per-symbol dicts for UI consumption.
        Symbols that didn't fire a signal are NOT captured in the
        per-symbol dicts.

        Used by the Dashboard tab to populate KPI tiles / badge row /
        levels / workflow panels without recomputing context. Other
        consumers (CSV export, SignalTracker) should continue to use
        ``scan()`` for the lean list return.

        ``progress_callback(done, total, symbol)`` is invoked **after**
        each symbol is processed (success or handled failure). The
        callback runs on the calling thread; UI consumers should wrap
        it in a thread-safe signal emit. Never raises — callback
        exceptions are logged and swallowed so a broken UI observer
        cannot kill the scan.

        ``result_callback(symbol_results, state)`` is invoked per
        firing symbol **only when** ``symbol_results`` is non-empty,
        immediately after the symbol is scanned. The state is the
        per-symbol ``SignalState`` already extracted by
        ``_scan_symbol`` (passed through so the UI can render rows
        without re-extracting). Enables progressive row streaming to
        the scanner tables — rows appear live instead of waiting for
        the full snapshot. Same defensive error-swallowing as the
        progress callback.
        """
        asof = self._normalise(asof_date)
        target_symbols = self._resolve_symbols(symbols, enriched_panel)
        total = len(target_symbols)

        snapshot_acc: dict[str, dict] = {"state": {}, "contexts": {}}
        results: list[ScanResult] = []

        for i, symbol in enumerate(target_symbols, start=1):
            try:
                symbol_results = self._scan_symbol(
                    symbol=symbol,
                    enriched_df=enriched_panel[symbol],
                    asof_date=asof,
                    snapshot_accumulator=snapshot_acc,
                )
            except Exception:    # noqa: BLE001
                logger.exception(
                    "scanner: unexpected failure on symbol %r — skipping", symbol,
                )
                symbol_results = []
            results.extend(symbol_results)
            # Streaming emit: fire the per-symbol result callback only
            # when the symbol actually produced signals. This is what
            # makes scanner rows appear live during scan instead of
            # batch-dumping at the end. State lookup is cheap — it was
            # just stashed in snapshot_acc by _scan_symbol.
            if symbol_results and result_callback is not None:
                state = snapshot_acc["state"].get(symbol)
                try:
                    result_callback(symbol_results, state)
                except Exception:    # noqa: BLE001
                    logger.exception(
                        "scanner: result_callback raised — ignoring",
                    )
            if progress_callback is not None:
                try:
                    progress_callback(i, total, symbol)
                except Exception:    # noqa: BLE001
                    logger.exception(
                        "scanner: progress_callback raised — ignoring",
                    )

        results.sort(
            key=lambda r: (
                -r.conviction.score,
                -r.strategy.priority,
                r.strategy.name,
            ),
        )

        return ScanSnapshot(
            results=results,
            state_by_symbol=snapshot_acc["state"],
            contexts_by_symbol=snapshot_acc["contexts"],
            enriched_panel=enriched_panel,
            asof_date=asof,
        )

    # ══════════════════════════════════════════════════════════════════════
    # Helpers
    # ══════════════════════════════════════════════════════════════════════

    def _resolve_symbols(
        self,
        symbols: Iterable[str] | None,
        enriched_panel: dict[str, pd.DataFrame],
    ) -> list[str]:
        if symbols is None:
            return sorted(
                s for s in enriched_panel
                if s in self._universe.symbols
            )
        return [s for s in symbols if s in enriched_panel
                and s in self._universe.symbols]

    @staticmethod
    def _resolve_bar_index(
        df: pd.DataFrame, asof_date: pd.Timestamp,
    ) -> int | None:
        """Return the integer index of the last bar at or before
        ``asof_date``. None if no such bar exists."""
        idx = df.index
        if len(idx) == 0:
            return None
        # Reduce to tz-naive for comparison safety.
        if idx.tz is not None:
            idx = idx.tz_localize(None)
        mask = idx <= asof_date
        if not mask.any():
            return None
        return int(mask.sum()) - 1   # last True index, 0-based

    def build_context_bundle(
        self, *, symbol: str, asof_date: pd.Timestamp,
    ) -> ContextBundle:
        """Compose a :class:`ContextBundle` for a single symbol.

        Public so the Dashboard / main window can populate one symbol
        without running a full scan: given a sidebar selection, call
        this with the selected symbol and the enriched frame's last
        index, hand the bundle to ``DashboardTab.set_symbol``, and
        every panel below the chart (KPIs, badges, Workflow Analysis,
        Key Levels) populates.

        Each provider is called independently — if a provider is
        absent (e.g. no options provider is wired yet) that field is
        ``None`` and downstream renderers fall back to their empty
        states.  The ``MarketContext`` is synthesised as a neutral
        VIX-NORMAL stub when no market provider is available, because
        the grade formula requires a non-null market context.
        """
        p = self._providers
        market = (
            p.market.build(symbol=None, asof_date=asof_date)
            if p.market is not None else None
        )
        sector = (
            p.sector.build(symbol=symbol, asof_date=asof_date)
            if p.sector is not None else None
        )
        options = (
            p.options.build(symbol=symbol, asof_date=asof_date)
            if p.options is not None else None
        )
        filing = (
            p.filing.build(symbol=symbol, asof_date=asof_date)
            if p.filing is not None else None
        )

        # MarketContext is required by the formula; synthesise a neutral
        # one if no provider supplied it (graceful degradation).
        if market is None:
            from nimbus_v3.core.types import VIXRegime
            market = MarketContext(
                asof_date=asof_date, vix_value=None,
                vix_regime=VIXRegime.NORMAL, vix_high_streak=0,
            )

        return ContextBundle(
            symbol=symbol, asof_date=asof_date,
            market=market, sector=sector, options=options,
            filing=filing,
        )

    def _lookup_strategy(self, name: str) -> Strategy | None:
        for strat in self._registry:
            if strat.name == name:
                return strat
        return None

    @staticmethod
    def _normalise(ts: pd.Timestamp) -> pd.Timestamp:
        t = pd.Timestamp(ts)
        if t.tz is not None:
            t = t.tz_localize(None)
        return t.normalize()
