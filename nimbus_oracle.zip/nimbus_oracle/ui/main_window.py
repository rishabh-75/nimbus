"""
ui/main_window.py
─────────────────
NIMBUS QMainWindow: sidebar (fixed 220px) + QTabWidget (3 tabs).

Phase 1: DataManager wired, sidebar signals connected, status bar live.
Symbol change → immediate pipeline execution (Lesson 8.6).
"""

from __future__ import annotations

import datetime
import logging
from PyQt6.QtCore import Qt, QSize, QSettings
from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QHBoxLayout,
    QTabWidget,
    QLabel,
    QStatusBar,
)
from PyQt6.QtGui import QShortcut, QKeySequence

from ui.theme import EM, RED, GOLD, MUTED, BLUE, FONT_MONO, QSS
from ui.sidebar import Sidebar
from ui.data_manager import DataManager
from ui.dashboard_tab import DashboardTab
from ui.scanner_tab import ScannerTab
from ui.watchlist_tab import WatchlistTab
from ui.market_context_tab import MarketContextTab
from ui.etf_tab import ETFMomentumTab
from ui.watchlist_db import init_watchlist
# KiteTicker removed — yfinance polling is the sole data source

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    """
    Top-level window for NIMBUS Qt.

    Layout:
        ┌────────────┬────────────────────────────────────────┐
        │  Sidebar    │  QTabWidget                            │
        │  (220px)    │    Tab 0: Dashboard                    │
        │             │    Tab 1: Scanner                      │
        │             │    Tab 2: Watchlist                     │
        └────────────┴────────────────────────────────────────┘
        │  Status bar                                          │
        └──────────────────────────────────────────────────────┘
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("NIMBUS · Emerald Slate · Qt")
        self.setMinimumSize(QSize(1200, 760))
        self.resize(1480, 900)

        # Apply master stylesheet
        self.setStyleSheet(QSS)

        # ── Data manager ──────────────────────────────────────────────────────
        self.data_mgr = DataManager(parent=self)

        # ── Watchlist SQLite init ─────────────────────────────────────────────
        init_watchlist()

        # ── Signal tracker init ────────────────────────────────────────────────
        from modules.signal_tracker import init_tracker
        init_tracker()

        self._build_ui()
        self._connect_signals()

        # ── Fetch universe on startup ─────────────────────────────────────────
        self.data_mgr.fetch_universe()

        # ── Auto-load initial symbol after window shows ───────────────────────
        from PyQt6.QtCore import QTimer

        QTimer.singleShot(500, self._auto_load_initial)

        # ── Keyboard shortcuts (§6.2) ─────────────────────────────────────────
        self._setup_shortcuts()

        # ── Restore window geometry ───────────────────────────────────────────
        self._restore_state()

        logger.info("MainWindow initialised — yfinance polling active")

    def _auto_load_initial(self):
        """Trigger pipeline for the default symbol on startup."""
        symbol = self.sidebar.current_symbol()
        if symbol:
            logger.info("Auto-loading initial symbol: %s", symbol)
            self._on_symbol_changed(symbol)

    # ──────────────────────────────────────────────────────────────────────────
    # UI CONSTRUCTION
    # ──────────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Sidebar ───────────────────────────────────────────────────────────
        self.sidebar = Sidebar(self)
        root.addWidget(self.sidebar)

        # ── Tab widget ────────────────────────────────────────────────────────
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        self.tabs.setDocumentMode(True)
        # Prevent Qt from truncating tab labels
        self.tabs.tabBar().setElideMode(Qt.TextElideMode.ElideNone)
        self.tabs.tabBar().setExpanding(False)

        # Phase 2: real Dashboard tab
        self._dashboard_tab = DashboardTab(self)
        self._scanner_tab = ScannerTab(self)
        self._watchlist_tab = WatchlistTab(self)
        self._context_tab = MarketContextTab(self)
        self._etf_tab = ETFMomentumTab(self)

        self.tabs.addTab(self._dashboard_tab, "Dashboard")
        self.tabs.addTab(self._scanner_tab, "Scanner")
        self.tabs.addTab(self._etf_tab, "ETF Momentum")
        self.tabs.addTab(self._watchlist_tab, "Watchlist")
        self.tabs.addTab(self._context_tab, "Market Context")

        root.addWidget(self.tabs, stretch=1)

        # ── Status bar ────────────────────────────────────────────────────────
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)

        self._status_dot = QLabel("●")
        self._status_dot.setStyleSheet(
            f"color: {MUTED}; font-size: 10px; padding: 0 4px;"
        )
        self._status_bar.addWidget(self._status_dot)

        self._status_label = QLabel("Ready · Select a symbol to begin")
        self._status_label.setStyleSheet(
            f"color: {MUTED}; font-size: 11px; font-family: '{FONT_MONO}';"
        )
        self._status_bar.addWidget(self._status_label, stretch=1)

        # Strategy regime indicator (right side, before VIX)
        self._strategy_regime_label = QLabel("regime: loading…")
        self._strategy_regime_label.setStyleSheet(
            f"color: {MUTED}; font-size: 11px; font-family: '{FONT_MONO}'; padding: 0 8px;"
        )
        self._status_bar.addPermanentWidget(self._strategy_regime_label)

        # VIX regime indicator (rightmost)
        self._regime_label = QLabel("")
        self._regime_label.setStyleSheet(
            f"color: {MUTED}; font-size: 11px; font-family: '{FONT_MONO}'; padding: 0 8px;"
        )
        self._status_bar.addPermanentWidget(self._regime_label)

        # Initial regime computation + 5-min refresh timer
        self._update_strategy_regime()
        from PyQt6.QtCore import QTimer
        self._strategy_regime_timer = QTimer(self)
        self._strategy_regime_timer.setInterval(5 * 60 * 1000)  # 5 minutes
        self._strategy_regime_timer.timeout.connect(self._update_strategy_regime)
        self._strategy_regime_timer.start()

    # ──────────────────────────────────────────────────────────────────────────
    # SIGNAL WIRING
    # ──────────────────────────────────────────────────────────────────────────

    def _connect_signals(self):
        """Wire sidebar → DataManager → status bar."""

        # Sidebar → pipeline
        self.sidebar.symbol_changed.connect(self._on_symbol_changed)
        self.sidebar.refresh_clicked.connect(self._on_refresh)

        # Sidebar → DataManager indicator params
        self.sidebar.bb_period_changed.connect(self.data_mgr.set_bb_period)
        self.sidebar.bb_std_changed.connect(self.data_mgr.set_bb_std)
        self.sidebar.wr_period_changed.connect(self.data_mgr.set_wr_period)
        self.sidebar.wr_thresh_changed.connect(self.data_mgr.set_wr_threshold)

        # DataManager → status bar
        self.data_mgr.freshness_changed.connect(self._on_freshness_changed)
        self.data_mgr.error_occurred.connect(self._on_error)
        self.data_mgr.spot_updated.connect(self._on_spot_updated)

        # DataManager → universe → sidebar
        self.data_mgr.universe_ready.connect(self._on_universe_ready)

        # DataManager → dashboard tab
        self.data_mgr.price_updated.connect(self._on_price_for_dashboard)
        self.data_mgr.context_updated.connect(self._dashboard_tab.on_context_updated)
        self.data_mgr.ps_updated.connect(self._dashboard_tab.on_ps_updated)
        self.data_mgr.spot_updated.connect(self._dashboard_tab.on_spot_updated)
        self.data_mgr.filing_ready.connect(self._dashboard_tab.on_filing_updated)

        # DataManager → conviction signal (single computation, fan out to UI)
        self.data_mgr.conviction_updated.connect(self._dashboard_tab.on_conviction_updated)
        self.data_mgr.conviction_updated.connect(
            lambda sym, dm_sig, conv: self.sidebar.on_conviction_updated(dm_sig, conv)
        )

        # DataManager → BB Ride signal (computed alongside conviction)
        self.data_mgr.ride_updated.connect(self._dashboard_tab.on_ride_updated)
        self.data_mgr.ride_updated.connect(
            lambda sym, ride_r: self.sidebar.on_ride_updated(ride_r)
        )

        # DataManager → regime (VIX-based strategy allocation)
        self.data_mgr.regime_updated.connect(self._on_regime_updated)

        # New signal logged → refresh strategy regime label (debounced)
        # We don't recompute on every signal — instead we kick a 5s debounce
        # timer that coalesces bursts of signals into a single recompute.
        from PyQt6.QtCore import QTimer as _QT
        self._regime_debounce_timer = _QT(self)
        self._regime_debounce_timer.setSingleShot(True)
        self._regime_debounce_timer.setInterval(5 * 1000)  # 5s debounce
        self._regime_debounce_timer.timeout.connect(self._update_strategy_regime)
        self.data_mgr.signal_logged.connect(self._regime_debounce_timer.start)

        # DataManager → analytics complete (logged)
        self.data_mgr.context_updated.connect(self._on_context_updated)
        self.data_mgr.ps_updated.connect(self._on_ps_updated)

        # Scanner → Dashboard navigation (Lesson 8.7)
        self._scanner_tab.row_clicked.connect(self.open_symbol_in_dashboard)

        # Scanner → populate sidebar (single click, no tab switch)
        self._scanner_tab.symbol_selected.connect(
            lambda sym: self.sidebar._symbol_combo.setCurrentText(sym)
        )

        # ETF tab → Dashboard navigation
        self._etf_tab.symbol_selected.connect(self.open_symbol_in_dashboard)

        # Watchlist → Dashboard navigation
        self._watchlist_tab.view_symbol.connect(self.open_symbol_in_dashboard)

        # Market Context → Dashboard navigation
        self._context_tab.view_symbol.connect(self.open_symbol_in_dashboard)

    # ──────────────────────────────────────────────────────────────────────────
    # SLOTS: Sidebar actions
    # ──────────────────────────────────────────────────────────────────────────

    def _on_symbol_changed(self, symbol: str):
        """
        CRITICAL (Lesson 8.6): Symbol change → immediate pipeline execution.
        (1) Clear cached DataFrames
        (2) Set needs_refresh flag
        (3) Directly trigger PriceWorker and OptionsWorker
        Never rely on a timer or passive state check.
        """
        logger.info("Symbol changed → immediate pipeline: %s", symbol)
        self.sidebar.set_refresh_enabled(False)
        self._set_status("LIVE", f"Loading {symbol}…")

        # IMMEDIATE pipeline execution
        self.data_mgr.refresh(symbol, fetch_options=True)

    def _on_refresh(self):
        symbol = self.sidebar.current_symbol()
        if not symbol:
            return
        logger.info("Manual refresh: %s", symbol)
        self.sidebar.set_refresh_enabled(False)
        self._set_status("LIVE", f"Refreshing {symbol}…")
        self.data_mgr.refresh(symbol, fetch_options=True)

    # ──────────────────────────────────────────────────────────────────────────
    # SLOTS: DataManager callbacks
    # ──────────────────────────────────────────────────────────────────────────

    def _on_freshness_changed(self, state: str):
        """Update status bar per §3.2 format strings."""
        symbol = self.data_mgr.active_symbol
        spot = self.data_mgr.spot

        if state == "LIVE":
            ts = self.data_mgr.last_refresh_time()
            nxt = self.data_mgr.next_refresh_time()
            ts_str = ts.strftime("%H:%M:%S") if ts else "—"
            nxt_str = nxt.strftime("%H:%M:%S") if nxt else "—"
            spot_str = f"{spot:,.2f}" if spot > 0 else "—"
            self._set_status(
                "LIVE",
                f"LIVE  |  {symbol} {spot_str}  |  "
                f"Last refresh: {ts_str}  |  Next: {nxt_str}",
            )
            self.sidebar.set_refresh_enabled(True)

        elif state == "CACHED":
            spot_str = f"{spot:,.2f}" if spot > 0 else "—"
            self._set_status(
                "CACHED",
                f"CACHED  |  {symbol} {spot_str}  |  Market closed — using last available data",
            )
            self.sidebar.set_refresh_enabled(True)

        elif state == "STALE":
            ts = self.data_mgr.last_refresh_time()
            if ts:
                ago = datetime.datetime.now() - ts
                mins = int(ago.total_seconds() // 60)
                self._set_status(
                    "STALE",
                    f"STALE · {mins}m ago  |  {symbol}  |  Retry available",
                )
            else:
                self._set_status("STALE", f"STALE  |  {symbol}")
            self.sidebar.set_refresh_enabled(True)

        elif state == "ERROR":
            self._set_status("ERROR", f"ERROR  |  Fetch failed for {symbol}  |  Retry")
            self.sidebar.set_refresh_enabled(True)

    def _on_error(self, symbol: str, msg: str):
        logger.error("Error for %s: %s", symbol, msg)
        self.sidebar.set_refresh_enabled(True)

    def _on_spot_updated(self, symbol: str, spot: float):
        logger.info("Spot updated: %s = %.2f", symbol, spot)

    def _on_price_for_dashboard(self, symbol: str, df):
        """Feed price data to dashboard header + chart."""
        self._dashboard_tab.on_price_updated(symbol, df)
        self._dashboard_tab.set_price_df(df)

    def _on_universe_ready(self, symbols: list):
        """Populate sidebar combo with fetched universe."""
        logger.info("Universe loaded: %d symbols", len(symbols))
        self.sidebar.set_symbols(symbols)

    def _on_context_updated(self, symbol: str, ctx):
        """Analytics complete — log summary. Dashboard wiring in Phase 3."""
        v = ctx.viability
        regime_str = getattr(getattr(ctx, "regime", None), "regime", "ETF")
        logger.info(
            "Context ready: %s — score=%d sizing=%s label=%s regime=%s",
            symbol,
            v.score,
            v.sizing,
            v.label,
            regime_str,
        )
        self.sidebar.set_refresh_enabled(True)

    def _on_ps_updated(self, symbol: str, ps):
        """PriceSignals ready — log summary. Dashboard wiring in Phase 3."""
        logger.info(
            "PriceSignals ready: %s — WR=%.1f bias=%s pos=%s vol=%s",
            symbol,
            ps.wr_value if ps.wr_value is not None else -999,
            ps.daily_bias,
            ps.position_state,
            ps.vol_state,
        )

    def _on_regime_updated(self, regime):
        """Update status bar with current regime and strategy allocation."""
        from modules.regime import RegimeResult
        if not isinstance(regime, RegimeResult):
            return

        # Strategy badge colors
        _colors = {
            "PANIC": EM,
            "ELEVATED": GOLD,
            "NORMAL": EM,
            "LOW": EM,
            "UNKNOWN": MUTED,
        }
        color = _colors.get(regime.vix_regime, MUTED)

        vix_str = f"VIX {regime.vix_value:.1f}" if regime.vix_value else "VIX —"
        self._regime_label.setText(
            f"{vix_str} {regime.vix_regime}"
        )
        self._regime_label.setStyleSheet(
            f"color: {color}; font-size: 11px; font-family: '{FONT_MONO}'; "
            f"font-weight: bold; padding: 0 8px;"
        )

        # Transition alert — show temporarily in status label
        if regime.transition_alert:
            self._status_label.setText(regime.transition_alert)
            logger.info("Regime alert: %s", regime.transition_alert)

    # ──────────────────────────────────────────────────────────────────────────
    # PUBLIC API (for future phases)
    # ──────────────────────────────────────────────────────────────────────────

    def open_symbol_in_dashboard(self, symbol: str):
        """
        Called by scanner tab (Phase 5): switch to Dashboard + run pipeline.
        """
        logger.info("open_symbol_in_dashboard: %s", symbol)
        # Add to combo if not present (otherwise setCurrentText silently fails)
        idx = self.sidebar._symbol_combo.findText(symbol)
        if idx < 0:
            self.sidebar._symbol_combo.addItem(symbol)
        self.sidebar._symbol_combo.setCurrentText(symbol)
        self.tabs.setCurrentIndex(0)

    def _set_status(self, state: str, message: str):
        """Update status bar dot + label."""
        colors = {
            "LIVE": EM,
            "STALE": GOLD,
            "CACHED": BLUE,
            "ERROR": RED,
            "READY": MUTED,
        }
        color = colors.get(state, MUTED)
        self._status_dot.setStyleSheet(
            f"color: {color}; font-size: 10px; padding: 0 4px;"
        )
        self._status_label.setText(message)

    # ──────────────────────────────────────────────────────────────────────────
    # KEYBOARD SHORTCUTS (§6.2)
    # ──────────────────────────────────────────────────────────────────────────

    def _setup_shortcuts(self):
        """R = refresh, Cmd+1-5 = tab switch, Cmd+F = symbol search."""
        QShortcut(QKeySequence("R"), self).activated.connect(self._on_refresh)
        QShortcut(QKeySequence("Ctrl+1"), self).activated.connect(
            lambda: self.tabs.setCurrentIndex(0)
        )
        QShortcut(QKeySequence("Ctrl+2"), self).activated.connect(
            lambda: self.tabs.setCurrentIndex(1)
        )
        QShortcut(QKeySequence("Ctrl+3"), self).activated.connect(
            lambda: self.tabs.setCurrentIndex(2)
        )
        QShortcut(QKeySequence("Ctrl+4"), self).activated.connect(
            lambda: self.tabs.setCurrentIndex(3)
        )
        QShortcut(QKeySequence("Ctrl+5"), self).activated.connect(
            lambda: self.tabs.setCurrentIndex(4)
        )
        QShortcut(QKeySequence("Ctrl+F"), self).activated.connect(
            lambda: self.sidebar._symbol_input.setFocus()
        )

    # ──────────────────────────────────────────────────────────────────────────
    # WINDOW STATE PERSISTENCE (§6.2)
    # ──────────────────────────────────────────────────────────────────────────

    def _restore_state(self):
        """Restore window geometry and last symbol from QSettings."""
        settings = QSettings("NIMBUS", "EmeraldSlate")
        geo = settings.value("window/geometry")
        if geo:
            self.restoreGeometry(geo)
        last_sym = settings.value("window/last_symbol", "NIFTY")
        if last_sym:
            self.sidebar._symbol_combo.setCurrentText(last_sym)

    def _save_state(self):
        """Save window geometry and current symbol to QSettings."""
        settings = QSettings("NIMBUS", "EmeraldSlate")
        settings.setValue("window/geometry", self.saveGeometry())
        settings.setValue("window/last_symbol", self.sidebar.current_symbol())

    def _update_strategy_regime(self):
        """Recompute rolling strategy regime stats and update status bar."""
        try:
            from modules.strategy_regime import (
                compute_strategy_regimes, format_status_text, overall_dormant,
            )
            snapshot = compute_strategy_regimes(window_days=90)
            text = format_status_text(snapshot)
            self._strategy_regime_label.setText(text)
            # Color: red if any dormant, gold if all calibrating, muted otherwise
            if overall_dormant(snapshot):
                color = RED
            elif snapshot.regimes and all(
                r.state == "CALIBRATING" for r in snapshot.regimes.values()
            ):
                color = GOLD
            else:
                color = MUTED
            self._strategy_regime_label.setStyleSheet(
                f"color: {color}; font-size: 11px; font-family: '{FONT_MONO}'; padding: 0 8px;"
            )
        except Exception as exc:
            logger.warning("Strategy regime update failed: %s", exc)
            self._strategy_regime_label.setText("regime: error")

    def closeEvent(self, event):
        """Persist state and cleanly stop all worker threads."""
        self._save_state()

        # Stop scanner workers
        tab = self._scanner_tab
        for w in (getattr(tab, "_dual_worker", None),
                  getattr(tab, "_filings_worker", None)):
            if w and w.isRunning():
                if hasattr(w, "cancel"):
                    w.cancel()
                w.quit()
                w.wait(2000)

        # Stop ETF worker
        etf = self._etf_tab
        w = getattr(etf, "_worker", None)
        if w and w.isRunning():
            if hasattr(w, "cancel"):
                w.cancel()
            w.quit()
            w.wait(2000)

        # Stop DataManager workers
        dm = self.data_mgr
        for attr in ("_price_worker", "_options_worker", "_universe_worker"):
            w = getattr(dm, attr, None)
            if w and w.isRunning():
                w.quit()
                w.wait(2000)

        super().closeEvent(event)


