"""Shared pytest fixtures for nimbus_v3 tests.

Kept intentionally small: one synthetic OHLCV generator that produces a
deterministic DataFrame with known statistical properties. Tests that need
specific indicator values construct their own fixtures inline.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest


def _synthetic_ohlcv(n_bars: int, seed: int = 42, start_price: float = 100.0) -> pd.DataFrame:
    """Build a deterministic OHLCV DataFrame for tests.

    The series is a mild random walk with log-normal returns; volumes are
    positive integers. Index is business-day timestamps starting
    2020-01-01. NOT meant to be realistic — meant to be deterministic and
    large enough for 200-bar indicators.
    """
    rng = np.random.default_rng(seed)
    n = n_bars
    log_rets = rng.normal(loc=0.0005, scale=0.015, size=n)
    close = start_price * np.exp(np.cumsum(log_rets))
    # High/low straddle close by a small vol-proportional amount.
    intraday_range = np.abs(rng.normal(scale=0.01, size=n)) * close
    high = close + intraday_range * rng.uniform(0.3, 0.7, size=n)
    low = close - intraday_range * rng.uniform(0.3, 0.7, size=n)
    # Open ≈ previous close with a small gap.
    prev_close = np.concatenate([[start_price], close[:-1]])
    open_ = prev_close + rng.normal(scale=0.005, size=n) * prev_close
    # Ensure OHLC ordering is valid: high = max, low = min.
    high = np.maximum.reduce([high, open_, close])
    low = np.minimum.reduce([low, open_, close])
    volume = rng.integers(500_000, 5_000_000, size=n).astype(float)
    index = pd.bdate_range(start="2020-01-01", periods=n, freq="B")
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=index,
    )


@pytest.fixture
def ohlcv_300() -> pd.DataFrame:
    """A 300-bar synthetic OHLCV DataFrame. Enough for 200-bar indicators
    plus a 100-bar post-warmup window."""
    return _synthetic_ohlcv(n_bars=300)


@pytest.fixture
def ohlcv_100() -> pd.DataFrame:
    """A 100-bar synthetic OHLCV DataFrame. Too short for full enrichment —
    used to test the warmup error path."""
    return _synthetic_ohlcv(n_bars=100)


@pytest.fixture
def ohlcv_500() -> pd.DataFrame:
    """A 500-bar synthetic OHLCV DataFrame."""
    return _synthetic_ohlcv(n_bars=500)
