"""nimbus_v3.compute.seasonality — monthly seasonality from a price series.

Stateless. Given a daily Close series, computes calendar-month
seasonality: the average return for each month across all available
years, the hit rate (share of years that month closed positive), and
the average cumulative 12-month path (Jan→Dec) — the "if every year
were the average year" walk.

Symbol-agnostic: feed it an equity's Close for per-symbol seasonality,
or an index's Close (CNX500) for market seasonality. No UI, no IO.

Definitions:
  monthly return   = last-close-of-month / last-close-of-prior-month − 1
  avg_return[m]    = mean over years of that month's return
  hit_rate[m]      = % of years where that month's return > 0
  cumulative_path  = running sum of avg_return Jan..Dec, in percent
                     (additive average path, matching the reference
                     "average 12-month path" presentation)

The strongest/weakest month is by ``avg_return``; best/worst hit rate
by ``hit_rate``. All months are 1..12; a month with no observations
gets NaN avg/hit and is skipped in the extremes.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

_MONTH_ABBR = (
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
)

#: Minimum distinct years required before seasonality is meaningful.
MIN_YEARS: int = 3


@dataclass(frozen=True)
class MonthStat:
    """Per-month seasonality stats."""

    month: int                  # 1..12
    label: str                  # "Jan".."Dec"
    avg_return: float           # mean monthly return, percent (NaN if none)
    hit_rate: float             # % years positive, 0..100 (NaN if none)
    n_years: int                # observations contributing
    std_return: float = float("nan")    # std of monthly returns across years, %


@dataclass(frozen=True)
class SeasonalityResult:
    """Full seasonality summary for one price series."""

    months: tuple[MonthStat, ...]          # always 12, Jan..Dec
    cumulative_path: tuple[float, ...]     # 12 values, cumulative % Jan..Dec
    n_years: int                           # distinct calendar years seen
    strongest: MonthStat | None            # by avg_return
    weakest: MonthStat | None
    best_hit: MonthStat | None             # by hit_rate
    worst_hit: MonthStat | None

    @property
    def has_data(self) -> bool:
        return self.n_years >= MIN_YEARS


def _monthly_returns(close: pd.Series) -> pd.Series:
    """Month-end Close → month-over-month returns, indexed by period end."""
    close = close.dropna()
    if close.empty:
        return pd.Series(dtype=float)
    # Last close of each calendar month, then pct-change across months.
    monthly = close.resample("ME").last()
    return monthly.pct_change().dropna()


def compute_seasonality(close: pd.Series) -> SeasonalityResult:
    """Compute monthly seasonality from a daily Close series.

    Returns a :class:`SeasonalityResult`. When fewer than
    :data:`MIN_YEARS` years are available, ``has_data`` is False and the
    extremes are ``None`` (the caller shows an empty state) — but the
    per-month stats are still populated for whatever was observed.
    """
    rets = _monthly_returns(close)
    if rets.empty:
        empty = tuple(
            MonthStat(m + 1, _MONTH_ABBR[m], float("nan"), float("nan"), 0)
            for m in range(12)
        )
        return SeasonalityResult(
            months=empty, cumulative_path=(float("nan"),) * 12,
            n_years=0, strongest=None, weakest=None,
            best_hit=None, worst_hit=None,
        )

    idx = pd.DatetimeIndex(rets.index)
    months_of = idx.month
    n_years = int(pd.Index(idx.year).nunique())

    stats: list[MonthStat] = []
    for m in range(1, 13):
        sel = rets[months_of == m]
        if len(sel) == 0:
            stats.append(
                MonthStat(m, _MONTH_ABBR[m - 1], float("nan"), float("nan"), 0)
            )
            continue
        avg = float(sel.mean() * 100.0)
        hit = float((sel > 0).mean() * 100.0)
        # Dispersion across years — std of the monthly returns. With ≥2
        # observations this flags months whose mean is driven by one
        # outlier year (high std relative to |mean|). NaN for a single
        # observation (no spread defined).
        std = float(sel.std(ddof=0) * 100.0) if len(sel) >= 2 else float("nan")
        stats.append(
            MonthStat(m, _MONTH_ABBR[m - 1], avg, hit, len(sel), std))

    # Cumulative average path: running sum of avg_return Jan..Dec.
    # NaN months contribute 0 to the walk (flat) so the line stays
    # continuous even with a gap.
    cum: list[float] = []
    running = 0.0
    for s in stats:
        if s.avg_return == s.avg_return:    # not NaN
            running += s.avg_return
        cum.append(running)

    valid = [s for s in stats if s.avg_return == s.avg_return]
    hit_valid = [s for s in stats if s.hit_rate == s.hit_rate]
    strongest = max(valid, key=lambda s: s.avg_return) if valid else None
    weakest = min(valid, key=lambda s: s.avg_return) if valid else None
    best_hit = max(hit_valid, key=lambda s: s.hit_rate) if hit_valid else None
    worst_hit = min(hit_valid, key=lambda s: s.hit_rate) if hit_valid else None

    return SeasonalityResult(
        months=tuple(stats),
        cumulative_path=tuple(cum),
        n_years=n_years,
        strongest=strongest,
        weakest=weakest,
        best_hit=best_hit,
        worst_hit=worst_hit,
    )


def month_stat(result: SeasonalityResult, month: int) -> MonthStat | None:
    """Return the :class:`MonthStat` for ``month`` (1..12), or ``None``
    if out of range. Convenience accessor — ``result.months`` is always
    ordered Jan..Dec, so this is just a bounds-checked index. Kept out
    of :func:`compute_seasonality` so the compute stays time-agnostic;
    callers resolve "current month" at the presentation edge and look it
    up here."""
    if not (1 <= month <= 12):
        return None
    return result.months[month - 1]
