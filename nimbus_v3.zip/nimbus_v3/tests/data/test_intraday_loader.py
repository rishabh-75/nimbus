"""Tests for the secondary 4h loader: resample, tz handling, and the
forming-bar guard (the intraday analogue of the daily incomplete-session
drop)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

from nimbus_v3.data.intraday_loader import IntradayLoader

_IST = timezone(timedelta(hours=5, minutes=30))


def _hourly(start="2026-07-20 08:00", n=24):
    idx = pd.date_range(start, periods=n, freq="60min")
    c = np.linspace(100, 100 + n, n)
    return pd.DataFrame(
        {"Open": c, "High": c + 0.5, "Low": c - 0.5, "Close": c,
         "Volume": np.full(n, 1000.0)}, index=idx)


def test_resample_aggregates_ohlcv():
    df = _hourly(n=8)                      # two 4h buckets
    out = IntradayLoader.resample_to_4h(df)
    assert len(out) == 2
    first = out.iloc[0]
    # Open = first hour's open, High = max, Low = min, Close = last,
    # Volume = sum over the bucket.
    assert first["Open"] == df["Open"].iloc[0]
    assert first["High"] == df["High"].iloc[:4].max()
    assert first["Low"] == df["Low"].iloc[:4].min()
    assert first["Close"] == df["Close"].iloc[3]
    assert first["Volume"] == df["Volume"].iloc[:4].sum()


def test_resample_drops_empty_buckets():
    df = _hourly(n=4)
    # inject an overnight gap then a couple more bars
    later = _hourly(start="2026-07-21 09:00", n=4)
    out = IntradayLoader.resample_to_4h(pd.concat([df, later]))
    assert not out["Close"].isna().any()


def test_forming_bar_dropped_mid_bucket():
    """Last bar's bucket [12:00,16:00) is still forming at 14:00 → dropped."""
    idx = pd.to_datetime(["2026-07-20 08:00", "2026-07-20 12:00"])
    df = pd.DataFrame({"Open": [1, 2], "High": [1, 2], "Low": [1, 2],
                       "Close": [1, 2], "Volume": [1, 2]}, index=idx)
    now = datetime(2026, 7, 20, 14, 0, tzinfo=_IST)   # inside 12:00 bucket
    out = IntradayLoader._drop_forming_bar(df, now=now)
    assert len(out) == 1
    assert out.index[-1] == pd.Timestamp("2026-07-20 08:00")


def test_completed_bar_kept():
    """After the bucket closes (16:05), the 12:00 bar is final → kept."""
    idx = pd.to_datetime(["2026-07-20 08:00", "2026-07-20 12:00"])
    df = pd.DataFrame({"Open": [1, 2], "High": [1, 2], "Low": [1, 2],
                       "Close": [1, 2], "Volume": [1, 2]}, index=idx)
    now = datetime(2026, 7, 20, 16, 5, tzinfo=_IST)
    out = IntradayLoader._drop_forming_bar(df, now=now)
    assert len(out) == 2


def test_normalize_converts_utc_to_ist():
    """Intraday timestamps arrive tz-aware; buckets must align to IST."""
    idx = pd.date_range("2026-07-20 03:45", periods=4, freq="60min",
                        tz="UTC")           # 09:15 IST onward
    raw = pd.DataFrame(
        {"Open": 1.0, "High": 1.0, "Low": 1.0, "Close": 1.0, "Volume": 1.0},
        index=idx)
    out = IntradayLoader._normalize(raw)
    assert out.index.tz is None
    # 03:45 UTC + 5:30 = 09:15 IST
    assert out.index[0] == pd.Timestamp("2026-07-20 09:15")


def test_empty_inputs_are_safe():
    assert IntradayLoader.resample_to_4h(pd.DataFrame()).empty
    assert IntradayLoader._normalize(pd.DataFrame()).empty
    assert IntradayLoader._drop_forming_bar(pd.DataFrame()).empty


class _FakeCache:
    def __init__(self):
        self._d = {}
        self._age = {}

    def get(self, k):
        return self._d.get(k)

    def set(self, k, df):
        self._d[k] = df

    def age(self, k):
        return self._age.get(k)


def test_load_serves_cache_when_closed(monkeypatch):
    """Market closed + cached frame → returned without any fetch."""
    cache = _FakeCache()
    cache.set("TEST", _hourly(n=4))
    loader = IntradayLoader(cache)
    monkeypatch.setattr(
        "nimbus_v3.core.market_session.is_market_open", lambda: False)

    called = {"fetch": False}
    monkeypatch.setattr(loader, "_fetch",
                        lambda s: called.__setitem__("fetch", True) or
                        pd.DataFrame())
    out = loader.load("TEST")
    assert not out.empty
    assert called["fetch"] is False


def test_fetch_window_is_sufficient_but_not_excessive():
    """The 60m history window is DERIVED from the band period, not padded.

    It must be long enough that resampling yields >= BB period completed 4h
    bars (a NaN band fail-softs the flag to a false 'not above'), but no
    longer — every extra day is wasted 60m transfer across the universe.
    """
    from nimbus_v3.data.intraday_loader import (
        _BARS_PER_SESSION,
        _BB_PERIOD,
        _HISTORY_DAYS,
        _history_days_for,
    )
    # enough: trading days in the window * bars/session must clear the band.
    trading_days = _HISTORY_DAYS * 5 // 7
    assert trading_days * _BARS_PER_SESSION >= _BB_PERIOD, "under-fetch"
    # not excessive: no more than ~1.6x the bars the band needs.
    assert trading_days * _BARS_PER_SESSION <= _BB_PERIOD * 1.7, "over-fetch"
    # derivation tracks the period: a longer band widens the window.
    assert _history_days_for(40) > _history_days_for(20)


def test_fetch_requests_only_a_recent_rolling_window(monkeypatch):
    """The vendor request must be a recent window, never full history."""
    from datetime import date

    import nimbus_v3.data.intraday_loader as mod

    captured = {}

    class _FakeYF:
        @staticmethod
        def download(*, tickers, start, end, interval, **kw):
            captured.update(start=start, end=end, interval=interval)
            return pd.DataFrame()

    monkeypatch.setitem(__import__("sys").modules, "yfinance", _FakeYF)
    loader = IntradayLoader(_FakeCache())
    loader._fetch("TEST")

    start = date.fromisoformat(captured["start"])
    end = date.fromisoformat(captured["end"])
    span = (end - start).days
    assert captured["interval"] == "60m"
    assert span <= mod._HISTORY_DAYS + 2, (
        f"requested {span} days — wider than the derived window")
    assert span < 60, "this looks like a historic fetch, not a recent window"


def test_cache_only_never_fetches(monkeypatch):
    """The GUI-thread path must read cache and never hit the network."""
    cache = _FakeCache()
    cache.set("HIT", _hourly(n=4))
    loader = IntradayLoader(cache)
    called = {"fetch": False}
    monkeypatch.setattr(loader, "_fetch",
                        lambda s: called.__setitem__("fetch", True)
                        or pd.DataFrame())
    hit = loader.load("HIT", cache_only=True)
    miss = loader.load("MISS", cache_only=True)
    assert not hit.empty          # served from cache
    assert miss.empty             # miss -> empty, still no fetch
    assert called["fetch"] is False
