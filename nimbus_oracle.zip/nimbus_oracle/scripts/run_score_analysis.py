#!/usr/bin/env python3
"""
scripts/run_score_analysis.py — Can we simplify the score formula?

The current score (0-100) is a weighted composite of the same indicators
that already gate entry (WR, SMA, MFI, DD, streak, vol). The backtest
showed score is INVERTED as a predictor (r=-0.032). Grade handles conviction.

This script tests whether replacing the score with simple boolean entry
conditions changes the trade universe. If the same trades trigger either way,
the score formula is unnecessary complexity.

Tests:
  1. How many trades have score >= threshold but fail boolean entry?
  2. How many trades pass boolean entry but have score < threshold?
  3. What's the overlap between score-gated and boolean-gated entries?
  4. If we remove score entirely, what changes in the trade universe?

If overlap is >95%, score can be safely replaced with boolean conditions.
Then walkforward can be re-run with simplified entry logic.

Usage:
    python3 scripts/run_score_analysis.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("score_analysis")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="score_analysis_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    from modules.dual_mode import compute_dual_mode

    price_cache = {}
    for sym in trades_df["symbol"].unique():
        f = f"data/backtest_cache/{sym}_1d.parquet"
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except: pass

    # Reconstruct signals at entry
    rows = []
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        if sym not in price_cache: continue
        pdf = price_cache[sym]
        mask = pdf.index <= trade["entry_date"]
        if mask.sum() < 40: continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient: continue
            rows.append({
                "symbol": sym, "entry_date": trade["entry_date"],
                "pnl_pct": trade["pnl_pct"], "win": int(trade["pnl_pct"] > 0),
                "tier": sig.tier, "entry_triggered": sig.entry_triggered,
                "dual_score": sig.dual_score, "base_score": sig.base_score,
                "core_met": sig.core_met,
                "primary_met": sig.primary_met,
                "secondary_met": sig.secondary_met,
                "wr": sig.wr_30, "mfi": sig.mfi, "above_sma": sig.above_sma,
                "dd": sig.dd_from_high, "streak": sig.red_streak,
                "vol_ratio": sig.vol_ratio, "rsi": sig.rsi,
            })
        except: pass
        if len(rows) % 500 == 0:
            logger.info("  %d processed", len(rows))

    df = pd.DataFrame(rows)
    logger.info("Features: %d trades", len(df))

    report = []
    report.append("=" * 70)
    report.append("SCORE SIMPLIFICATION ANALYSIS")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)}")
    report.append("=" * 70)

    # ── TEST 1: Score distribution for entries vs non-entries ─────────
    report.append("\n" + "=" * 70)
    report.append("TEST 1: SCORE DISTRIBUTION")
    report.append("=" * 70)

    entries = df[df["entry_triggered"]]
    non_entries = df[~df["entry_triggered"]]
    report.append(f"  Entries: {len(entries)} (score mean={entries['dual_score'].mean():.1f}, min={entries['dual_score'].min()}, max={entries['dual_score'].max()})")
    report.append(f"  Non-entries: {len(non_entries)} (score mean={non_entries['dual_score'].mean():.1f})")

    # ── TEST 2: Boolean entry conditions ─────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 2: BOOLEAN vs SCORE ENTRY GATE")
    report.append("=" * 70)

    # Current entry: tier != NONE (which requires core_met at minimum)
    # Core: WR < -30, below SMA, MFI >= 30
    # Score threshold: varies, but typical is 45-60

    for thresh in [0, 30, 45, 50, 55, 60, 70]:
        # Boolean: just core_met (WR + SMA + MFI)
        bool_entry = df["core_met"]
        score_entry = df["dual_score"] >= thresh

        both = (bool_entry & score_entry).sum()
        bool_only = (bool_entry & ~score_entry).sum()
        score_only = (~bool_entry & score_entry).sum()
        neither = (~bool_entry & ~score_entry).sum()

        overlap = both / max(1, (both + bool_only + score_only)) * 100
        report.append(f"  Score >= {thresh:3d}: overlap={overlap:.1f}%  both={both}  bool_only={bool_only}  score_only={score_only}")

    # ── TEST 3: Do score-only entries (not core_met) even win? ───────
    report.append("\n" + "=" * 70)
    report.append("TEST 3: ENTRIES THAT PASS SCORE BUT FAIL BOOLEAN")
    report.append("=" * 70)

    for thresh in [45, 50, 55, 60]:
        score_not_bool = df[(df["dual_score"] >= thresh) & ~df["core_met"]]
        if len(score_not_bool) > 10:
            wr_val = score_not_bool["win"].mean() * 100
            avg_pnl = score_not_bool["pnl_pct"].mean()
            report.append(f"  Score >= {thresh} but !core_met: N={len(score_not_bool)}  Win={wr_val:.1f}%  Avg={avg_pnl:+.3f}%")
        else:
            report.append(f"  Score >= {thresh} but !core_met: N={len(score_not_bool)} (too few)")

    # ── TEST 4: Primary vs core-only comparison ──────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 4: PRIMARY FILTERS — DO THEY ADD VALUE?")
    report.append("=" * 70)
    report.append("  PRIMARY requires: core + DD<=moderate + streak>=2 + vol>=0.5")
    report.append("  Are these extra filters worth keeping?")

    pri = df[df["primary_met"]]
    sec = df[df["secondary_met"]]
    core_only = df[df["core_met"] & ~df["primary_met"]]

    if len(pri) >= 10 and len(core_only) >= 10:
        from scipy import stats
        t, p = stats.ttest_ind(pri["pnl_pct"], core_only["pnl_pct"], equal_var=False)
        report.append(f"\n  PRIMARY:    N={len(pri):4d}  Win={pri['win'].mean()*100:.1f}%  Avg={pri['pnl_pct'].mean():+.3f}%")
        report.append(f"  CORE only:  N={len(core_only):4d}  Win={core_only['win'].mean()*100:.1f}%  Avg={core_only['pnl_pct'].mean():+.3f}%")
        report.append(f"  t={t:.3f}  p={p:.4f}")
        if p < 0.05:
            report.append("  ✓ SIGNIFICANT — PRIMARY filters add value, KEEP them")
        else:
            report.append("  ○ NOT significant — PRIMARY filters don't add edge over core")

    # ── TEST 5: Minimal viable entry conditions ──────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 5: WHAT'S THE SIMPLEST ENTRY THAT WORKS?")
    report.append("=" * 70)

    conditions = [
        ("WR < -30 only", df["wr"] < -30),
        ("WR < -30 + below SMA", (df["wr"] < -30) & (~df["above_sma"])),
        ("WR < -30 + below SMA + MFI >= 30", df["core_met"]),
        ("Core + DD <= -5%", df["core_met"] & (df["dd"] <= -5)),
        ("Core + vol >= 0.5", df["core_met"] & (df["vol_ratio"] >= 0.5)),
        ("Core + DD + streak + vol (PRIMARY)", df["primary_met"]),
    ]

    report.append(f"\n  {'Condition':45s} {'N':>5s} {'Win%':>6s} {'Avg':>7s}")
    for name, mask in conditions:
        subset = df[mask]
        if len(subset) < 20: continue
        wr_val = subset["win"].mean() * 100
        avg = subset["pnl_pct"].mean()
        report.append(f"  {name:45s} {len(subset):5d} {wr_val:5.1f}% {avg:+6.3f}%")

    # ── RECOMMENDATION ───────────────────────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("RECOMMENDATION")
    report.append("=" * 70)
    report.append("""
  If boolean entry (core_met) captures 95%+ of all profitable entries,
  the score formula can be replaced with:
    entry_triggered = WR(30) < -30 AND below SMA(20) AND MFI >= 30

  This eliminates: weighted scoring, _label_and_sizing, base_score,
  and the confusing score number that predicts nothing (r=-0.032).

  Grade (from ConvictionEngine) handles all conviction ranking.
  Score is reduced to a boolean gate: you're in or you're out.
""")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
