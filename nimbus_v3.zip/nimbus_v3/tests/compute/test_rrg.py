"""Tests for nimbus_v3.compute.rrg."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.rrg import (
    DEFAULT_LOOKBACK,
    DEFAULT_TAIL,
    Quadrant,
    compute_rrg,
    _quadrant,
)


def _frame(drift: float, n: int = 80, vol: float = 1e5) -> pd.DataFrame:
    idx = pd.date_range("2025-01-01", periods=n, freq="D")
    close = 100 * (1 + drift) ** np.arange(n)
    atr = np.full(n, 2.0)
    return pd.DataFrame(
        {"Open": close, "High": close * 1.01, "Low": close * 0.99,
         "Close": close, "Volume": np.full(n, vol), "atr_14_pct": atr},
        index=idx)


def _ind(panel, prefix, drift, n=6):
    syms = []
    for i in range(n):
        s = f"{prefix}{i}"
        panel[s] = _frame(drift)
        syms.append(s)
    return syms


def test_quadrant_classification():
    assert _quadrant(105, 105) == Quadrant.LEADING
    assert _quadrant(105, 95) == Quadrant.WEAKENING
    assert _quadrant(95, 95) == Quadrant.LAGGING
    assert _quadrant(95, 105) == Quadrant.IMPROVING


def test_empty_without_members():
    res = compute_rrg({}, {}, None)
    assert not res.has_data


def test_min_members_enforced():
    panel = {}
    big = _ind(panel, "B", 0.01, n=6)
    small = _ind(panel, "S", 0.01, n=3)
    res = compute_rrg({"Big": big, "Small": small}, panel, None, lookback=60)
    inds = [p.industry for p in res.points]
    assert "Big" in inds
    assert "Small" not in inds


def test_all_and_unknown_skipped():
    panel = {}
    real = _ind(panel, "R", 0.01)
    res = compute_rrg(
        {"ALL": real, "Unknown": real, "Real": real}, panel, None, lookback=60)
    inds = [p.industry for p in res.points]
    assert inds == ["Real"]


def test_leader_has_higher_rs_than_laggard():
    panel = {}
    mbi = {"Strong": _ind(panel, "U", 0.02), "Weak": _ind(panel, "D", -0.01)}
    # benchmark = flat-ish mean → strong leads, weak lags
    res = compute_rrg(mbi, panel, None, lookback=60)
    by = {p.industry: p for p in res.points}
    assert by["Strong"].rs_ratio > by["Weak"].rs_ratio


def test_tail_length_capped():
    panel = {}
    mbi = {"X": _ind(panel, "X", 0.01)}
    res = compute_rrg(mbi, panel, None, lookback=60, tail_len=5)
    assert len(res.points[0].tail) <= 5


def test_volatility_from_atr():
    panel = {}
    mem = _ind(panel, "X", 0.01)
    # bump atr on members
    for s in mem:
        panel[s]["atr_14_pct"] = 3.5
    res = compute_rrg({"X": mem}, panel, None, lookback=60)
    assert res.points[0].volatility == pytest.approx(3.5, abs=0.01)


def test_explicit_benchmark_used():
    panel = {}
    mem = _ind(panel, "X", 0.01)
    bench = _frame(0.005)["Close"]    # benchmark rising slower
    res = compute_rrg({"X": mem}, panel, bench, lookback=60)
    assert res.has_data
    # industry rising faster than benchmark → RS should end >= 100-ish
    assert res.points[0].rs_ratio > 95


def test_defaults():
    assert DEFAULT_LOOKBACK == 60
    assert DEFAULT_TAIL == 8


def test_odds_ranking_improving_before_leading():
    """Improving (weak+gaining) must rank above Leading in the odds
    order — the early-entry reading."""
    from nimbus_v3.compute.rrg import RRGPoint, RRGResult, Quadrant
    pts = (
        RRGPoint("Lead", 110, 105, 2.0, Quadrant.LEADING, 5, ()),
        RRGPoint("Improve", 95, 106, 2.0, Quadrant.IMPROVING, 5, ()),
        RRGPoint("Weaken", 112, 96, 2.0, Quadrant.WEAKENING, 5, ()),
        RRGPoint("Lag", 90, 94, 2.0, Quadrant.LAGGING, 5, ()),
    )
    res = RRGResult(points=pts, lookback=60)
    order = [p.industry for p in res.odds_ranked()]
    assert order == ["Improve", "Lead", "Weaken", "Lag"]


def test_odds_ranking_high_rs_weakening_below_leading():
    """A high-RS fading leader (Weakening) ranks below a lower-RS healthy
    Leading name — the Telecom paradox fix."""
    from nimbus_v3.compute.rrg import RRGPoint, RRGResult, Quadrant
    pts = (
        RRGPoint("FadingLeader", 118, 97, 2.0, Quadrant.WEAKENING, 5, ()),
        RRGPoint("HealthyLeader", 103, 104, 2.0, Quadrant.LEADING, 5, ()),
    )
    res = RRGResult(points=pts, lookback=60)
    order = [p.industry for p in res.odds_ranked()]
    assert order[0] == "HealthyLeader"
    assert order[1] == "FadingLeader"


def test_maturity_classification():
    from nimbus_v3.compute.rrg import _maturity, Maturity, Quadrant
    # Strong side: decelerating = Maturing (pre-Weakening warning)
    assert _maturity(Quadrant.LEADING, -0.5) == Maturity.MATURING
    assert _maturity(Quadrant.LEADING, +0.5) == Maturity.FRESH
    assert _maturity(Quadrant.LEADING, 0.0) == Maturity.STABLE
    assert _maturity(Quadrant.WEAKENING, -0.5) == Maturity.MATURING
    # Weak side: accelerating = Turning (pre-Improving recovery)
    assert _maturity(Quadrant.LAGGING, +0.5) == Maturity.TURNING
    assert _maturity(Quadrant.IMPROVING, +0.5) == Maturity.TURNING
    assert _maturity(Quadrant.LAGGING, -0.5) == Maturity.MATURING
    assert _maturity(Quadrant.LAGGING, 0.0) == Maturity.STABLE


def test_mom_slope_computed_and_signed():
    import numpy as np, pandas as pd
    from nimbus_v3.compute.rrg import compute_rrg
    panel = {}
    idx = pd.date_range("2025-01-01", periods=90, freq="D")
    syms = []
    for i in range(6):
        drift = np.concatenate([
            np.full(60, 0.0),
            np.linspace(0.0, 0.010, 30),    # accelerating into the end
        ])
        close = 100 * np.cumprod(1 + drift)
        panel[f"A{i}"] = pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(90, 1e5), "atr_14_pct": np.full(90, 2.0)},
            index=idx)
        syms.append(f"A{i}")
    bench = pd.Series(np.full(90, 100.0), index=idx)
    res = compute_rrg({"Accel": syms}, panel, bench, lookback=60)
    assert res.has_data
    p = res.points[0]
    assert p.mom_slope > 0
    assert p.maturity.value in ("Fresh", "Turning")


def test_maturity_default_stable_for_short_tail():
    import numpy as np, pandas as pd
    from nimbus_v3.compute.rrg import compute_rrg
    panel = {}
    idx = pd.date_range("2025-01-01", periods=80, freq="D")
    syms = []
    for i in range(6):
        close = 100 * (1.001) ** np.arange(80)
        panel[f"X{i}"] = pd.DataFrame(
            {"Open": close, "High": close, "Low": close, "Close": close,
             "Volume": np.full(80, 1e5), "atr_14_pct": np.full(80, 2.0)},
            index=idx)
        syms.append(f"X{i}")
    res = compute_rrg({"X": syms}, panel, None, lookback=60, tail_len=2)
    assert res.has_data
    # tail_len 2 → slope defaults to 0 → Stable
    assert res.points[0].mom_slope == 0.0
