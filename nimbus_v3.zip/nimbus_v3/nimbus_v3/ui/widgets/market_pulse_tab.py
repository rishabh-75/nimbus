"""nimbus_v3.ui.widgets.market_pulse_tab — universe breadth charts.

A stacked, date-aligned multi-panel chart that plots market-breadth
series against the CNX500 (NIFTY 500) index, so the operator can read
the broad market's internal strength at a glance:

    ┌───────────────────────────────────────┐
    │ CNX500 close                          │
    ├───────────────────────────────────────┤
    │ % above SMA50  /  % above SMA200      │
    ├───────────────────────────────────────┤
    │ Advance / Decline line                │
    ├───────────────────────────────────────┤
    │ New highs − new lows                  │
    └───────────────────────────────────────┘

Pure view: it receives a breadth DataFrame (from
``compute.market_breadth.compute_breadth``) and an optional CNX500
Close series, and renders. No computation here.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pyqtgraph as pg
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QVBoxLayout, QWidget

from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, EM, FONT_MONO, GOLD, GREEN, MUTED, RED, VIOLET, WHITE,
)


class _DateAxisItem(pg.AxisItem):
    """Bottom axis that renders integer x positions as dates."""

    def __init__(self, timestamps=None, *a, **kw):    # noqa: ANN001
        super().__init__(*a, **kw)
        self._ts = timestamps
        self.setStyle(tickFont=QFont(FONT_MONO, 9))

    def set_timestamps(self, ts) -> None:    # noqa: ANN001
        self._ts = ts

    def tickStrings(self, values, scale, spacing):    # noqa: ANN001, N802
        if self._ts is None or len(self._ts) == 0:
            return [""] * len(values)
        out = []
        n = len(self._ts)
        for v in values:
            i = int(round(v))
            if 0 <= i < n:
                out.append(pd.Timestamp(self._ts[i]).strftime("%b '%y"))
            else:
                out.append("")
        return out


class MarketPulseTab(QWidget):
    """Stacked breadth panels vs CNX500. Call :meth:`set_data`."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        self._glw = pg.GraphicsLayoutWidget()
        self._glw.setBackground(BG)
        layout.addWidget(self._glw)

        self._date_axis = _DateAxisItem(orientation="bottom")

        # Four stacked plots sharing the x-axis.
        self._p_index = self._glw.addPlot(row=0, col=0)
        self._p_ma = self._glw.addPlot(row=1, col=0)
        self._p_ad = self._glw.addPlot(row=2, col=0)
        self._p_nhnl = self._glw.addPlot(
            row=3, col=0, axisItems={"bottom": self._date_axis},
        )
        self._plots = [self._p_index, self._p_ma, self._p_ad, self._p_nhnl]

        titles = ["CNX500", "% ABOVE SMA  (50 green · 200 violet)",
                  "ADVANCE / DECLINE LINE", "NEW HIGHS − NEW LOWS"]
        for plot, title in zip(self._plots, titles):
            plot.showGrid(x=True, y=True, alpha=0.08)
            plot.setMenuEnabled(False)
            plot.hideButtons()
            # Y-axis on the RIGHT: show the right axis with values, hide
            # the left so the scale sits beside the latest (right-most)
            # data rather than the far edge.
            plot.showAxis("right")
            plot.hideAxis("left")
            for side in ("left", "right", "top", "bottom"):
                ax = plot.getAxis(side)
                ax.setPen(pg.mkPen(BORDER, width=0.5))
                ax.setTextPen(pg.mkPen(MUTED))
                ax.setStyle(tickFont=QFont(FONT_MONO, 9))
            plot.setTitle(title, color=MUTED, size="9pt")
        # Stretch the index panel taller; link x across all panels.
        self._glw.ci.layout.setRowStretchFactor(0, 3)
        for plot in self._plots[1:]:
            plot.setXLink(self._p_index)
        # Hide x ticks on all but the bottom panel.
        for plot in self._plots[:-1]:
            plot.getAxis("bottom").setStyle(showValues=False)

        self._placeholder_shown = False
        self._show_placeholder()

    # ── public API ────────────────────────────────────────────────────────

    def set_data(
        self, breadth: pd.DataFrame, index_close: pd.Series | None = None,
    ) -> None:
        """Render the breadth frame (+ optional CNX500 Close series)."""
        for plot in self._plots:
            plot.clear()
        if breadth is None or breadth.empty:
            self._show_placeholder()
            return

        ts = list(breadth.index)
        self._date_axis.set_timestamps(ts)
        x = np.arange(len(breadth), dtype=float)

        # Panel 1 — CNX500 close, reindexed onto the breadth dates.
        if index_close is not None and not index_close.empty:
            idx = index_close.reindex(breadth.index).ffill()
            self._p_index.plot(x, idx.to_numpy(dtype=float),
                               pen=pg.mkPen(WHITE, width=1.2))
        else:
            txt = pg.TextItem("CNX500 unavailable", color=MUTED,
                              anchor=(0.5, 0.5))
            self._p_index.addItem(txt)
            txt.setPos(len(breadth) / 2, 0)

        # Panel 2 — % above SMA50 / SMA200, with the 50% reference line.
        self._p_ma.addItem(pg.InfiniteLine(
            pos=50, angle=0, pen=pg.mkPen(MUTED, width=0.5,
                                          style=pg.QtCore.Qt.PenStyle.DashLine)))
        self._p_ma.plot(x, breadth["pct_above_sma50"].to_numpy(dtype=float),
                        pen=pg.mkPen(GREEN, width=1.2))
        self._p_ma.plot(x, breadth["pct_above_sma200"].to_numpy(dtype=float),
                        pen=pg.mkPen(VIOLET, width=1.2))
        self._p_ma.setYRange(0, 100)

        # Panel 3 — A/D line.
        self._p_ad.plot(x, breadth["ad_line"].to_numpy(dtype=float),
                        pen=pg.mkPen(BLUE, width=1.2))
        self._p_ad.addItem(pg.InfiniteLine(
            pos=0, angle=0, pen=pg.mkPen(MUTED, width=0.5,
                                         style=pg.QtCore.Qt.PenStyle.DashLine)))

        # Panel 4 — new highs − new lows as a zero-centered bar/line.
        nhnl = breadth["nh_nl_diff"].to_numpy(dtype=float)
        self._p_nhnl.plot(x, nhnl, pen=pg.mkPen(GOLD, width=1.0),
                          fillLevel=0, brush=pg.mkBrush(245, 158, 11, 60))
        self._p_nhnl.addItem(pg.InfiniteLine(
            pos=0, angle=0, pen=pg.mkPen(MUTED, width=0.5)))

        self._placeholder_shown = False

    # ── internals ─────────────────────────────────────────────────────────

    def _show_placeholder(self) -> None:
        if self._placeholder_shown:
            return
        txt = pg.TextItem(
            "Market breadth loads with the universe panel.",
            color=MUTED, anchor=(0.5, 0.5),
        )
        self._p_index.addItem(txt)
        txt.setPos(0, 0)
        self._placeholder_shown = True
