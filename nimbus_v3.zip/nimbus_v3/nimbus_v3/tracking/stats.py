"""nimbus_v3.tracking.stats — rolling lift analyses over logged signals.

Two analyses, both answering the research question that's repeatedly
surfaced during validation: **is the forward-return edge stable in
live data?**

- :func:`rolling_lift_by_strategy` — one row per strategy, aggregated
  across a time window. The headline metric is `mean_fwd_ret_10d` and
  its comparison against a passed-in universe baseline.

- :func:`regime_conditioned_lift` — break out by a categorical field
  (grade, verdict, or setup_type) within a single strategy so we can
  see whether (for example) A-grade MR signals outperform B-grade.

Both return lightweight dataclasses, not pandas DataFrames, so callers
don't pull pandas into places that don't need it (Qt layer, JSON
exports, etc.). The tracker query returns are the heavy lifting; this
module just aggregates.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
import pandas as pd

from nimbus_v3.tracking.tracker import SignalTracker, TrackedSignal


# ══════════════════════════════════════════════════════════════════════════════
# Result shapes
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class StrategyLiftRow:
    """Aggregated stats for one strategy over a date window."""
    strategy_name: str
    n_total: int                 # rows matching the filter
    n_filled: int                # subset with realised forward returns
    mean_fwd_ret_10d: float      # NaN if n_filled == 0
    median_fwd_ret_10d: float
    win_rate_10d: float          # fraction with fwd_ret_10d > 0
    lift_vs_baseline_pp: float   # (mean_fwd_ret_10d − baseline) × 100
    t_stat_lift_10d: float       # NaN if insufficient n

    def as_row_dict(self) -> dict:
        return {
            "strategy": self.strategy_name,
            "n_total": self.n_total,
            "n_filled": self.n_filled,
            "mean_10d_pct": self.mean_fwd_ret_10d * 100.0,
            "win_rate_10d_pct": self.win_rate_10d * 100.0,
            "lift_pp": self.lift_vs_baseline_pp,
            "t_stat": self.t_stat_lift_10d,
        }


@dataclass(frozen=True)
class RegimeBreakdownRow:
    """One bucket in a regime-conditioned analysis."""
    bucket: str                  # e.g. "A" (grade) or "HIGH" (vix_regime)
    n_filled: int
    mean_fwd_ret_10d: float
    win_rate_10d: float
    lift_vs_baseline_pp: float


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _summarise(
    fwd_returns: list[float], baseline: float,
) -> tuple[float, float, float, float, float]:
    """Return (mean, median, win_rate, lift_pp, t_stat) from a list of
    10d forward returns (as log-returns)."""
    arr = np.array([r for r in fwd_returns if r is not None and not np.isnan(r)])
    if len(arr) == 0:
        return (float("nan"), float("nan"), float("nan"),
                float("nan"), float("nan"))
    mean = float(arr.mean())
    median = float(np.median(arr))
    win_rate = float((arr > 0).mean())
    lift_pp = (mean - baseline) * 100.0
    if len(arr) < 2:
        return mean, median, win_rate, lift_pp, float("nan")
    std = float(arr.std(ddof=1))
    if std <= 0:
        return mean, median, win_rate, lift_pp, float("nan")
    t_stat = (mean - baseline) / (std / np.sqrt(len(arr)))
    return mean, median, win_rate, lift_pp, float(t_stat)


# ══════════════════════════════════════════════════════════════════════════════
# Public analyses
# ══════════════════════════════════════════════════════════════════════════════

def rolling_lift_by_strategy(
    tracker: SignalTracker,
    *,
    asof_from: pd.Timestamp | None = None,
    asof_to: pd.Timestamp | None = None,
    baseline_mean_10d: float = 0.0,
    production_only: bool = False,
) -> list[StrategyLiftRow]:
    """Compute per-strategy lift over a date window.

    Args:
        tracker: The SignalTracker to read from.
        asof_from, asof_to: Optional date filters.
        baseline_mean_10d: Universe 10d log-return baseline to subtract
            from the strategy mean. Callers pass the universe mean
            computed from the same date window (see the validation
            harness for how). Defaults to 0 if unavailable.
        production_only: Restrict to strategies with production_weight > 0.

    Returns:
        One ``StrategyLiftRow`` per strategy that has at least one
        recorded signal in the window. Sorted by lift descending.
    """
    rows = tracker.query(
        asof_from=asof_from, asof_to=asof_to,
        production_only=production_only,
    )
    by_strategy: dict[str, list[TrackedSignal]] = {}
    for r in rows:
        by_strategy.setdefault(r.strategy_name, []).append(r)

    out: list[StrategyLiftRow] = []
    for name, sigs in by_strategy.items():
        filled = [s for s in sigs if s.fwd_ret_10d is not None]
        fwd_10 = [s.fwd_ret_10d for s in filled]
        mean, median, win_rate, lift_pp, t_stat = _summarise(
            fwd_10, baseline_mean_10d,
        )
        out.append(StrategyLiftRow(
            strategy_name=name,
            n_total=len(sigs),
            n_filled=len(filled),
            mean_fwd_ret_10d=mean,
            median_fwd_ret_10d=median,
            win_rate_10d=win_rate,
            lift_vs_baseline_pp=lift_pp,
            t_stat_lift_10d=t_stat,
        ))
    out.sort(
        key=lambda r: (
            r.lift_vs_baseline_pp
            if not np.isnan(r.lift_vs_baseline_pp) else -float("inf")
        ),
        reverse=True,
    )
    return out


def regime_conditioned_lift(
    tracker: SignalTracker,
    *,
    strategy_name: str,
    bucket_field: Literal["grade", "verdict", "setup_type"] = "grade",
    asof_from: pd.Timestamp | None = None,
    asof_to: pd.Timestamp | None = None,
    baseline_mean_10d: float = 0.0,
) -> list[RegimeBreakdownRow]:
    """Break out lift for a single strategy by a categorical bucket field.

    Answers questions like "does A-grade MR outperform B-grade MR?"
    or "do TAKE verdicts actually beat WATCH verdicts?".

    Args:
        tracker: The SignalTracker to read from.
        strategy_name: Which strategy to analyse.
        bucket_field: One of ``"grade"`` (A/B/C/D), ``"verdict"``
            (TAKE/WATCH/SKIP), or ``"setup_type"``.
        asof_from, asof_to: Optional date filters.
        baseline_mean_10d: Universe 10d mean (same semantics as
            ``rolling_lift_by_strategy``).

    Returns:
        One ``RegimeBreakdownRow`` per bucket with non-zero rows,
        sorted by bucket label ascending.
    """
    rows = tracker.query(
        strategy_name=strategy_name,
        asof_from=asof_from, asof_to=asof_to,
        filled_only=True,
    )
    buckets: dict[str, list[float]] = {}
    for r in rows:
        key = getattr(r, bucket_field)
        if r.fwd_ret_10d is not None:
            buckets.setdefault(str(key), []).append(r.fwd_ret_10d)

    out: list[RegimeBreakdownRow] = []
    for key, fwd in sorted(buckets.items()):
        mean, _median, win_rate, lift_pp, _t = _summarise(
            fwd, baseline_mean_10d,
        )
        out.append(RegimeBreakdownRow(
            bucket=key,
            n_filled=len(fwd),
            mean_fwd_ret_10d=mean,
            win_rate_10d=win_rate,
            lift_vs_baseline_pp=lift_pp,
        ))
    return out
