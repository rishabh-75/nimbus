"""Tests for scripts/run_vix_component_industry_validation.py primitives."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(_ROOT / "scripts"))

from run_vix_component_industry_validation import (                  # noqa: E402
    _MIN_INDUSTRY_MEMBERS,
    _MIN_SYMBOL_OBS,
    _STABILITY_THRESHOLD,
    _aggregate_to_industry,
    _compute_stability,
    _make_expanding_folds,
    _per_symbol_lift,
    _run_fold,
    _verdict_for_window,
)


# ══════════════════════════════════════════════════════════════════════
# _make_expanding_folds
# ══════════════════════════════════════════════════════════════════════

class TestMakeExpandingFolds:

    def test_four_folds_produced(self):
        dates = pd.bdate_range("2021-01-01", periods=1000)
        folds = _make_expanding_folds(dates, n_folds=4)
        assert len(folds) == 4

    def test_folds_are_expanding(self):
        """Each fold's train_end is later than the previous one's."""
        dates = pd.bdate_range("2021-01-01", periods=1000)
        folds = _make_expanding_folds(dates, n_folds=4)
        train_ends = [f[0] for f in folds]
        assert train_ends == sorted(train_ends)
        # Strictly increasing
        for i in range(1, len(train_ends)):
            assert train_ends[i] > train_ends[i - 1]

    def test_test_windows_are_sequential(self):
        """Fold N's test_end == Fold N+1's test_start (contiguous)."""
        dates = pd.bdate_range("2021-01-01", periods=1000)
        folds = _make_expanding_folds(dates, n_folds=4)
        for i in range(len(folds) - 1):
            _, _, test_end_i = folds[i]
            _, test_start_next, _ = folds[i + 1]
            assert test_start_next == test_end_i

    def test_test_start_equals_train_end(self):
        """Within a fold, test_start == train_end (purging is applied
        later, inside _run_fold, not by this function)."""
        dates = pd.bdate_range("2021-01-01", periods=1000)
        folds = _make_expanding_folds(dates, n_folds=4)
        for train_end, test_start, _ in folds:
            assert test_start == train_end


# ══════════════════════════════════════════════════════════════════════
# _per_symbol_lift
# ══════════════════════════════════════════════════════════════════════

class TestPerSymbolLift:

    def _synthetic_panel(self, n: int, seed: int = 0):
        """Build 10 symbols with controllable per-regime returns."""
        rng = np.random.default_rng(seed)
        idx = pd.bdate_range("2020-01-01", periods=n)
        regime = pd.Series(
            np.where(np.arange(n) % 30 < 10, "RISING",
                     np.where(np.arange(n) % 30 < 20, "STABLE", "FALLING")),
            index=idx,
        )
        panel = {}
        for i in range(10):
            sym = f"SYM{i}"
            # Each symbol has higher mean in STABLE, lower elsewhere
            fwd = np.where(regime.values == "STABLE",
                           rng.normal(0.02, 0.01, n),
                           rng.normal(0.00, 0.01, n))
            panel[sym] = pd.DataFrame({"fwd_ret_10d": fwd}, index=idx)
        return panel, regime

    def test_basic_lift_computed(self):
        """A symbol with higher STABLE returns should show positive
        STABLE lift and negative RISING/FALLING lift."""
        panel, regime = self._synthetic_panel(600, seed=1)
        out = _per_symbol_lift(
            panel, regime,
            date_start=regime.index.min(),
            date_end=regime.index.max(),
            min_obs=10,
        )
        stable = out[out["regime"] == "STABLE"]
        rising = out[out["regime"] == "RISING"]
        # Most STABLE lifts should be positive, most RISING negative
        assert (stable["lift_pp"] > 0).sum() >= 7
        assert (rising["lift_pp"] < 0).sum() >= 7

    def test_underpowered_cells_dropped(self):
        """Symbols with fewer than min_obs in-regime bars don't get
        a row for that cell."""
        panel, regime = self._synthetic_panel(100, seed=2)
        # 100 bars, ~33 per regime
        out = _per_symbol_lift(
            panel, regime,
            date_start=regime.index.min(),
            date_end=regime.index.max(),
            min_obs=50,   # require 50 per cell
        )
        # Expect zero rows since each cell has only ~33 obs
        assert len(out) == 0

    def test_date_range_filtering(self):
        """Bars outside [date_start, date_end] are excluded."""
        panel, regime = self._synthetic_panel(600, seed=3)
        # Use just the first 300 bars
        half_date = regime.index[300]
        out_full = _per_symbol_lift(
            panel, regime,
            date_start=regime.index.min(),
            date_end=regime.index.max(),
            min_obs=10,
        )
        out_half = _per_symbol_lift(
            panel, regime,
            date_start=regime.index.min(),
            date_end=half_date,
            min_obs=10,
        )
        # Full run has more observations per cell
        assert out_full["n_in_cell"].sum() > out_half["n_in_cell"].sum()


# ══════════════════════════════════════════════════════════════════════
# _aggregate_to_industry
# ══════════════════════════════════════════════════════════════════════

class TestAggregateToIndustry:

    def _symbol_lifts(self, data):
        return pd.DataFrame(data, columns=[
            "symbol", "regime", "n_in_cell", "in_cell_mean_pp",
            "unconditional_pp", "lift_pp",
        ])

    def test_median_aggregation(self):
        """Industry median is the median of its members' lifts."""
        lifts = self._symbol_lifts([
            # Industry A, STABLE: 3 members with lifts 0.1, 0.5, 0.9 → median 0.5
            ("SYM_A1", "STABLE", 100, 0.5, 0.4, 0.1),
            ("SYM_A2", "STABLE", 100, 0.5, 0.0, 0.5),
            ("SYM_A3", "STABLE", 100, 0.5, -0.4, 0.9),
            # Industry B, RISING: 2 members, below member gate
            ("SYM_B1", "RISING", 100, 0.5, 0.0, 0.3),
            ("SYM_B2", "RISING", 100, 0.5, 0.0, 0.5),
        ])
        industry_map = {
            "SYM_A1": "INDUSTRY_A", "SYM_A2": "INDUSTRY_A", "SYM_A3": "INDUSTRY_A",
            "SYM_A4": "INDUSTRY_A", "SYM_A5": "INDUSTRY_A",
            "SYM_B1": "INDUSTRY_B", "SYM_B2": "INDUSTRY_B",
        }
        # min_members=3 so INDUSTRY_A STABLE survives (3 members),
        # INDUSTRY_B RISING doesn't (2 members)
        out = _aggregate_to_industry(
            lifts, industry_map, min_members=3,
        )
        a_stable = out[(out["industry"] == "INDUSTRY_A") &
                       (out["regime"] == "STABLE")]
        assert len(a_stable) == 1
        assert a_stable.iloc[0]["median_lift_pp"] == 0.5
        # INDUSTRY_B RISING should be absent
        b_rising = out[(out["industry"] == "INDUSTRY_B") &
                       (out["regime"] == "RISING")]
        assert len(b_rising) == 0

    def test_empty_input_returns_empty(self):
        out = _aggregate_to_industry(
            pd.DataFrame(columns=["symbol", "regime", "lift_pp"]),
            {},
        )
        assert out.empty


# ══════════════════════════════════════════════════════════════════════
# _compute_stability
# ══════════════════════════════════════════════════════════════════════

class TestComputeStability:

    def test_full_agreement_stability_is_one(self):
        """4 folds all agreeing in sign → stability = 1.0."""
        rows = []
        for fold in range(1, 5):
            rows.append({
                "industry":               "A",
                "regime":                 "STABLE",
                "fold":                   fold,
                "sign_agree":             True,
                "median_lift_pp_train":   0.5,
                "median_lift_pp_test":    0.4,
                "n_members_train":        10,
                "n_members_test":         10,
            })
        df = pd.DataFrame(rows)
        out = _compute_stability(df)
        assert out.iloc[0]["stability_score"] == 1.0

    def test_mixed_agreement(self):
        """2 of 4 folds agree → stability = 0.5."""
        rows = []
        for fold in range(1, 5):
            rows.append({
                "industry":               "B",
                "regime":                 "RISING",
                "fold":                   fold,
                "sign_agree":             fold % 2 == 0,
                "median_lift_pp_train":   0.3,
                "median_lift_pp_test":    0.2,
                "n_members_train":        8,
                "n_members_test":         8,
            })
        df = pd.DataFrame(rows)
        out = _compute_stability(df)
        assert out.iloc[0]["stability_score"] == 0.5


# ══════════════════════════════════════════════════════════════════════
# _verdict_for_window
# ══════════════════════════════════════════════════════════════════════

class TestVerdictForWindow:

    def _stability_df(self, rows):
        return pd.DataFrame(rows, columns=[
            "industry", "regime", "n_folds", "n_agree",
            "mean_train", "mean_test", "min_n_members",
            "stability_score",
        ])

    def test_counts_stable_cells(self):
        df = self._stability_df([
            ("A", "RISING",  4, 4, 0.5, 0.4, 10, 1.0),
            ("A", "STABLE",  4, 3, 0.6, 0.5, 10, 0.75),
            ("A", "FALLING", 4, 2, 0.3, 0.3, 10, 0.5),   # not stable
            ("B", "STABLE",  4, 4, 0.4, 0.3, 8, 1.0),
        ])
        v = _verdict_for_window(df)
        assert v["n_stable_cells"] == 3
        # A has 2 stable regimes (RISING, STABLE) → counts as stable
        # B has only 1 stable regime → doesn't count
        assert v["n_stable_industries"] == 1
        assert v["stable_industries"] == ["A"]
        # Evidence score = 4 + 4 + 4 (the three stable cells)
        assert v["evidence_score"] == 12

    def test_empty_stability_df_zero_counts(self):
        v = _verdict_for_window(pd.DataFrame())
        assert v["n_stable_cells"] == 0
        assert v["n_stable_industries"] == 0
        assert v["stable_industries"] == []
        assert v["evidence_score"] == 0

    def test_evidence_score_rewards_deeper_folds(self):
        """Two scenarios with identical stable-cell counts but
        different fold depth per cell. The deeper one scores higher."""
        shallow_df = self._stability_df([
            ("A", "RISING",  2, 2, 0.5, 0.4, 10, 1.0),
            ("A", "STABLE",  2, 2, 0.6, 0.5, 10, 1.0),
            ("B", "RISING",  2, 2, 0.5, 0.4, 10, 1.0),
        ])
        deep_df = self._stability_df([
            ("A", "RISING",  4, 4, 0.5, 0.4, 10, 1.0),
            ("A", "STABLE",  4, 4, 0.6, 0.5, 10, 1.0),
            ("B", "RISING",  4, 4, 0.5, 0.4, 10, 1.0),
        ])
        shallow = _verdict_for_window(shallow_df)
        deep = _verdict_for_window(deep_df)
        # Same stable-cell and stable-industry counts
        assert shallow["n_stable_cells"] == deep["n_stable_cells"]
        # Deep evidence_score is strictly higher
        assert deep["evidence_score"] > shallow["evidence_score"]
        assert shallow["evidence_score"] == 6    # 3 cells × 2 folds
        assert deep["evidence_score"] == 12      # 3 cells × 4 folds
