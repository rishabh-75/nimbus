"""nimbus_v3.core.connectivity — fast internet-reachability probe.

A cheap, dependency-free check used to AVOID long network stalls when
offline. yfinance's underlying HTTP calls have no short connect timeout,
so a bulk refresh over hundreds of symbols with no connectivity would
hang for the OS-level TCP timeout (~30–120s) PER symbol. Probing once,
fast, lets the caller fall back to cache instead of freezing.

This is a reachability heuristic, not a guarantee — a True result means
"a TCP connection to a well-known host succeeded just now", which is a
strong signal the network is up. A False result means "don't bother
trying to fetch; serve cache."
"""
from __future__ import annotations

import logging
import socket

logger = logging.getLogger("nimbus.connectivity")

#: Hosts to probe (host, port). Yahoo first (the actual data source),
#: then public DNS resolvers as generic internet-reachability fallbacks.
_PROBE_TARGETS: tuple[tuple[str, int], ...] = (
    ("fc.yahoo.com", 443),
    ("query1.finance.yahoo.com", 443),
    ("8.8.8.8", 53),
    ("1.1.1.1", 53),
)

#: Per-probe connect timeout (seconds). Short by design — the whole
#: point is to fail fast when offline.
_PROBE_TIMEOUT: float = 2.0


def is_online(timeout: float = _PROBE_TIMEOUT) -> bool:
    """Return True if any probe target is reachable within ``timeout``.

    Tries each target in order, returning True on the first successful
    TCP connection. Returns False only if ALL targets fail — which is a
    strong signal there's no usable connectivity. Total worst-case cost
    is ``timeout × len(_PROBE_TARGETS)`` but in practice the first
    target usually answers (or fails) quickly.
    """
    for host, port in _PROBE_TARGETS:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            continue
    logger.info("connectivity: all probes failed — treating as offline")
    return False
