"""scripts/validate_grade_formula.py — golden-fixture regression test.

Loads ``nimbus_v3/conviction/fixtures/golden.json`` and asserts that
every fixture's (state_kwargs, bundle_kwargs, signal_kwargs,
strategy_kwargs) still produces its pinned expected output.

When a fixture fails, it's either:
  (a) A real regression — formula or engine changed accidentally. Fix the code.
  (b) An intentional formula change — re-run this script with
      ``--update`` to write the new values back to the JSON file.
      This is the "explicit review" step per ARCHITECTURE.md §18.4:
      the golden diff should be inspected in PR before merging.

Usage:
    python scripts/validate_grade_formula.py          # check mode
    python scripts/validate_grade_formula.py --update # regenerate expected values
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import pandas as pd

from nimbus_v3.conviction.grade_engine import Conviction, ConvictionEngine
from nimbus_v3.core.context import (
    ContextBundle, FilingContext, MarketContext, SectorContext,
)
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import (
    FilingImpact, RSRegime, SetupType, VIXRegime,
)
from nimbus_v3.strategies.base import StrategySignal


FIXTURES_PATH = Path(__file__).resolve().parent.parent / (
    "nimbus_v3/conviction/fixtures/golden.json"
)

_ASOF = pd.Timestamp("2024-05-15")


# ══════════════════════════════════════════════════════════════════════════════
# Fixture → concrete objects
# ══════════════════════════════════════════════════════════════════════════════

def _build_state(kwargs: dict) -> SignalState:
    defaults = dict(
        symbol="R", bar_date=_ASOF, bar_index=250,
        open=100.0, high=100.0, low=100.0, close=100.0, volume=1e6,
        sma_10=99.0, sma_20=98.0, sma_50=95.0, sma_200=90.0,
        wr_14=-50.0, wr_20=-50.0, wr_30=-50.0, wr_50=-50.0,
        rsi_14=50.0, mfi_14=50.0, mfi_slope_3=0.0,
        adx_14=25.0, atr_14=1.0, atr_14_pct=1.0,
        bb_20_1s_upper=101.0, bb_20_1s_mid=100.0,
        bb_20_1s_lower=99.0, bb_20_1s_pct=0.5,
        bb_20_2s_upper=103.0, bb_20_2s_lower=97.0,
        bbw_20_2s=6.0, bbw_20_2s_slope=0.0, bbw_20_2s_pctl=50.0,
        pct_from_sma_20=0.0, pct_from_sma_50=0.0, pct_from_sma_200=0.0,
        above_sma_20=True, above_sma_50=True, above_sma_200=True,
        dd_from_high_20=0.0, dd_from_high_50=0.0,
        red_streak=0, green_streak=0,
        vol_ratio_20=1.0, roc_5=0.0, roc_10=0.0, roc_20=0.0,
        data_sufficient=True,
    )
    defaults.update(kwargs)
    return SignalState(**defaults)


def _build_bundle(kwargs: dict) -> ContextBundle:
    vix_regime = VIXRegime(kwargs.get("vix_regime", "NORMAL"))
    vix_streak = int(kwargs.get("vix_streak", 0))
    rs_regime = RSRegime(kwargs.get("rs_regime", "NEUTRAL"))
    market = MarketContext(
        asof_date=_ASOF, vix_value=None,
        vix_regime=vix_regime, vix_high_streak=vix_streak,
    )
    sector = SectorContext(
        asof_date=_ASOF, symbol="R", sector_name="X", sector_type=None,
        rs_regime=rs_regime, rs_20d=float(kwargs.get("rs_20d", 0.0)),
        realized_vol_20d=15.0, vol_z_score=kwargs.get("vol_z", 0.0),
    )
    filing = None
    impact_str = kwargs.get("filing_impact")
    if impact_str is not None:
        impact = FilingImpact(impact_str)
        filing = FilingContext(
            asof_date=_ASOF, symbol="R",
            latest_impact=impact,
            is_trap=(impact == FilingImpact.TRAP),
            days_since_latest=int(kwargs.get("filing_days_since", 1)),
            latest_headline="fixture",
        )
    return ContextBundle(symbol="R", asof_date=_ASOF,
                          market=market, sector=sector, filing=filing)


def _build_signal(kwargs: dict) -> StrategySignal:
    return StrategySignal(
        strategy_name="Fixture", symbol="R",
        setup_type=SetupType(kwargs.get("setup_type", "MR")),
        asof_date=_ASOF, priority=int(kwargs.get("priority", 50)),
    )


@dataclass
class _FixtureStrategy:
    name: str = "Fixture"
    setup_type: SetupType = SetupType.MEAN_REVERSION
    priority: int = 50
    production_weight: float = 1.0

    def accepts(self, meta): return True                     # noqa: ARG002
    def evaluate(self, **kwargs): return None                # noqa: ARG002


def _build_strategy(kwargs: dict) -> _FixtureStrategy:
    return _FixtureStrategy(
        setup_type=SetupType(kwargs.get("setup_type", "MR")),
        priority=int(kwargs.get("priority", 50)),
        production_weight=float(kwargs.get("production_weight", 1.0)),
    )


# ══════════════════════════════════════════════════════════════════════════════
# Validator
# ══════════════════════════════════════════════════════════════════════════════

def _run_fixture(fx: dict) -> Conviction:
    state = _build_state(fx.get("state_kwargs", {}))
    bundle = _build_bundle(fx.get("bundle_kwargs", {}))
    signal = _build_signal(fx.get("signal_kwargs", {}))
    strategy = _build_strategy(fx.get("strategy_kwargs", {}))
    engine = ConvictionEngine()
    return engine.grade(
        state=state, contexts=bundle, signal=signal, strategy=strategy,
    )


def _check_fixture(fx: dict) -> list[str]:
    failures: list[str] = []
    try:
        c = _run_fixture(fx)
    except Exception as e:    # noqa: BLE001
        return [f"engine raised: {type(e).__name__}: {e}"]

    expected = fx["expected"]
    if abs(c.score - expected["score"]) > 1e-4:
        failures.append(f"score: expected {expected['score']}, got {c.score:.4f}")
    if c.grade.value != expected["grade"]:
        failures.append(f"grade: expected {expected['grade']}, got {c.grade.value}")
    if c.verdict.value != expected["verdict"]:
        failures.append(f"verdict: expected {expected['verdict']}, got {c.verdict.value}")
    if c.sizing.value != expected["sizing"]:
        failures.append(f"sizing: expected {expected['sizing']}, got {c.sizing.value}")
    if "override_reason" in expected:
        exp_reason = expected["override_reason"]
        if exp_reason is None and c.override_reason is not None:
            failures.append(f"override_reason: expected null, got {c.override_reason!r}")
        elif exp_reason is not None and c.override_reason != exp_reason:
            failures.append(
                f"override_reason: expected {exp_reason!r}, got {c.override_reason!r}"
            )
    if "override_reason_contains" in expected:
        needle = expected["override_reason_contains"]
        if c.override_reason is None or needle not in c.override_reason:
            failures.append(
                f"override_reason: expected to contain {needle!r}, got {c.override_reason!r}"
            )
    return failures


def _update_fixture_expectations(fx: dict) -> dict:
    c = _run_fixture(fx)
    expected: dict[str, Any] = {
        "score": round(c.score, 4),
        "grade": c.grade.value,
        "verdict": c.verdict.value,
        "sizing": c.sizing.value,
    }
    if "override_reason_contains" in fx.get("expected", {}):
        expected["override_reason_contains"] = fx["expected"]["override_reason_contains"]
    else:
        expected["override_reason"] = c.override_reason
    return expected


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--update", action="store_true",
        help="Rewrite the JSON fixture file with the engine's current outputs.",
    )
    args = parser.parse_args()

    with FIXTURES_PATH.open() as f:
        data = json.load(f)
    fixtures = data["fixtures"]

    if args.update:
        for fx in fixtures:
            fx["expected"] = _update_fixture_expectations(fx)
        with FIXTURES_PATH.open("w") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
        print(f"Updated {len(fixtures)} fixtures in {FIXTURES_PATH}")
        return 0

    failed = 0
    for fx in fixtures:
        failures = _check_fixture(fx)
        if failures:
            failed += 1
            print(f"\n✗ {fx['name']}")
            for msg in failures:
                print(f"    {msg}")
        else:
            print(f"✓ {fx['name']}")

    total = len(fixtures)
    print()
    if failed == 0:
        print(f"All {total} golden fixtures pass.")
        return 0
    print(f"{failed}/{total} golden fixtures FAILED.")
    print("If this reflects an intentional change, re-run with --update.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
