"""nimbus_v3.compute.rs_reversion — the RS-reversion display signal.

DISPLAY ONLY. This does NOT feed any score. It surfaces the one candidate
that survived the self-referential-valuation search and its out-of-sample
gate: ``price_over_rs`` — a name whose price is low versus its OWN trailing
relative-strength norm, which tends to catch back up.

Validation summary (see rs_reversion_validation_probe.py):
  • Out-of-sample TEST D1−D10 = +3.03%, t = +4.15 — held on held-out data.
  • Cost gate passed with wide margin.
  • Random-key control effectively dead (one seed grazed t=2.03).
  • BUT subperiod-unstable: negative in the earliest third of the 5y sample,
    strong in the mid/late thirds → regime-dependent, and the sample is too
    short to certify. Hence: a WATCH flag, not a scored factor.

The signal shown is the SAME quantity that validated: the per-date
cross-sectionally-demeaned own-history z-score of the price/RS ratio. The
demean is what removed the market-timing artifact ("everything is cheap at
once"); it is cheap to compute here because the whole panel is scored
together. (The probe additionally %B-orthogonalised; that is a fitted step
skipped for display — the demeaned z is the honest, self-contained form.)

Sign convention: NEGATIVE z = cheap-for-its-own-RS = reversion-long candidate.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

#: Trailing window (bars) for the RS norm — RS divided by its own mean here.
RS_WIN: int = 120
#: Own-history window (bars) for the z-score baseline (~2 trading years).
ZWIN: int = 504


def _rs_ratio(close: pd.Series, market: pd.Series) -> pd.Series:
    """price / (its own trailing RS norm) = RS / mean(RS over RS_WIN)."""
    m = market.reindex(close.index).ffill()
    rs = close / m.replace(0.0, np.nan)
    norm = rs.rolling(RS_WIN, min_periods=RS_WIN // 2).mean()
    return rs / norm


def _latest_own_z(ratio: pd.Series) -> float | None:
    """z-score of the ratio's LAST value against its own prior ZWIN history
    (strictly before the last bar — no lookahead). None if too short."""
    vals = ratio.to_numpy(dtype=float)
    n = len(vals)
    if n < ZWIN // 3 + 1:
        return None
    hist = vals[max(0, n - 1 - ZWIN):n - 1]      # strictly before last
    hist = hist[np.isfinite(hist)]
    if len(hist) < ZWIN // 3:
        return None
    mu, sd = hist.mean(), hist.std(ddof=1)
    last = vals[-1]
    if sd <= 0 or not np.isfinite(last):
        return None
    return float((last - mu) / sd)


def compute_rs_reversion_z(
    panel: dict[str, pd.DataFrame],
    benchmark_close: pd.Series | None,
) -> dict[str, float | None]:
    """Return ``{symbol: demeaned own-history z}`` for the RS-reversion flag.

    Per symbol: own-history z of price/RS-norm at the latest bar. Then the
    whole cross-section is DEMEANED (each z minus the panel mean z that
    build), which is what stripped the market-timing tide in validation.
    Symbols with insufficient history map to ``None`` and are excluded from
    the demean mean.

    Fail-soft: any error yields an all-None map rather than raising, so the
    display column degrades to blank rather than breaking the Edge build.
    """
    if benchmark_close is None or not panel:
        return {s: None for s in panel}
    try:
        raw: dict[str, float | None] = {}
        for sym, df in panel.items():
            if df is None or "Close" not in df.columns or len(df) < ZWIN // 2:
                raw[sym] = None
                continue
            ratio = _rs_ratio(df["Close"].astype(float), benchmark_close)
            raw[sym] = _latest_own_z(ratio)
        finite = [z for z in raw.values() if z is not None and np.isfinite(z)]
        if len(finite) < 5:
            return raw
        mu = float(np.mean(finite))
        return {s: (z - mu if z is not None and np.isfinite(z) else None)
                for s, z in raw.items()}
    except Exception:            # noqa: BLE001
        return {s: None for s in panel}
