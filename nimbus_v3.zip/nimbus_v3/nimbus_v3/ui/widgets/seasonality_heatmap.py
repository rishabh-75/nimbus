"""nimbus_v3.ui.widgets.seasonality_heatmap — month × industry heatmap.

Renders the :class:`SeasonalityGrid` as a coloured grid: one row per
industry, 12 month columns, cell colour = average monthly return
(diverging green↑ / red↓, intensity = magnitude). Cells with too few
years of history are greyed out — honest about the data-depth limit
rather than painting noise as signal. Hover shows avg return + hit rate.

Cell painting goes through a QStyledItemDelegate rather than
``item.setBackground``: a table-level stylesheet (which we use for the
header/font) overrides per-item backgrounds in Qt, so the delegate is
the reliable way to guarantee the colours actually render.

Pure renderer — computation lives in ``compute.industry_seasonality``.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QSplitter, QStyledItemDelegate, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from nimbus_v3.compute.industry_seasonality import (
    CellContribution,
    SeasonalityGrid,
    compute_cell_contributions,
    compute_industry_seasonality,
)
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, EM, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED, S2,
    WHITE,
)

_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

#: Average monthly return (%) that maps to the MAX (still muted) tint.
_FULL_SCALE: float = 9.0

#: Tighter full-scale for the Relative-to-market view — differentials
#: are smaller than raw returns once the market pattern is netted out,
#: so a ±5% spread should span the colour range, not ±9%.
_RELATIVE_SCALE: float = 5.0

#: Maximum blend toward the colour at _FULL_SCALE (0..1). Capped well
#: below 1 so even the strongest month is a muted tint.
_MAX_INTENSITY: float = 0.55

#: Signal-to-noise (|mean|/std) that maps to full reliability. ~2 means
#: the mean is twice its year-to-year spread — a clean, dependable read.
_SNR_FULL: float = 2.0

#: In the Magnitude view, the minimum fraction of a cell's colour kept
#: even at zero reliability, so the sign stays readable while outlier
#: cells visibly fade.
_DESAT_FLOOR: float = 0.25

#: Translucent white wash for the selected cell's row/column cross.
_CROSS_TINT = QColor(255, 255, 255, 28)

#: Item data role carrying the pre-computed cell background QColor.
_BG_ROLE = Qt.ItemDataRole.UserRole + 1


def _cell_color(avg: float) -> QColor:
    """Diverging colour for an average monthly return. Green for
    positive, red for negative, intensity ∝ |avg| up to _FULL_SCALE but
    capped at _MAX_INTENSITY so the grid stays muted, blended over the
    panel background."""
    if avg != avg:    # NaN
        return QColor(S2)
    frac = max(-1.0, min(1.0, avg / _FULL_SCALE))
    base = QColor(BG)
    target = QColor(GREEN if frac >= 0 else RED)
    t = abs(frac) * _MAX_INTENSITY
    r = int(base.red() + (target.red() - base.red()) * t)
    g = int(base.green() + (target.green() - base.green()) * t)
    b = int(base.blue() + (target.blue() - base.blue()) * t)
    return QColor(r, g, b)


def _relative_color(rel: float) -> QColor:
    """Diverging colour for a return-vs-market differential. Uses a
    tighter scale than magnitude (the market pattern is netted out, so
    differentials are smaller) — keeps the industry-specific edge
    visible instead of washing pale."""
    if rel != rel:
        return QColor(S2)
    frac = max(-1.0, min(1.0, rel / _RELATIVE_SCALE))
    base = QColor(BG)
    target = QColor(GREEN if frac >= 0 else RED)
    t = abs(frac) * _MAX_INTENSITY
    r = int(base.red() + (target.red() - base.red()) * t)
    g = int(base.green() + (target.green() - base.green()) * t)
    b = int(base.blue() + (target.blue() - base.blue()) * t)
    return QColor(r, g, b)


def _reliability(avg: float, std: float) -> float:
    """Signal-to-noise: |mean| / dispersion, mapped to 0..1.

    High when a month's average is large *relative to* its year-to-year
    spread (a consistent, dependable pattern). Low when the mean is small
    or driven by one outlier year (large spread). Returns NaN when std
    is undefined (single observation)."""
    if avg != avg or std != std:
        return float("nan")
    if std <= 1e-9:
        return 1.0    # zero spread → perfectly consistent
    snr = abs(avg) / std
    # snr ~1 means mean ≈ one std (noisy); ~2+ means a clean signal.
    return max(0.0, min(1.0, snr / _SNR_FULL))


def _desaturate(color: QColor, reliability: float) -> QColor:
    """Fade a magnitude colour toward the background as reliability
    drops, so outlier-driven cells visually recede. reliability NaN →
    treat as low (faded)."""
    if reliability != reliability:
        reliability = 0.0
    # Keep at least a floor of the colour so the sign is still readable.
    keep = _DESAT_FLOOR + (1.0 - _DESAT_FLOOR) * reliability
    base = QColor(BG)
    r = int(base.red() + (color.red() - base.red()) * keep)
    g = int(base.green() + (color.green() - base.green()) * keep)
    b = int(base.blue() + (color.blue() - base.blue()) * keep)
    return QColor(r, g, b)


def _reliability_color(reliability: float) -> QColor:
    """Colour for the Reliability view: grey (unreliable) → blue
    (dependable). Sign-agnostic — this view is about trust, not
    direction."""
    if reliability != reliability:
        return QColor(S2)
    base = QColor(BG)
    target = QColor(BLUE)
    t = reliability * _MAX_INTENSITY
    r = int(base.red() + (target.red() - base.red()) * t)
    g = int(base.green() + (target.green() - base.green()) * t)
    b = int(base.blue() + (target.blue() - base.blue()) * t)
    return QColor(r, g, b)


class _HeatmapDelegate(QStyledItemDelegate):
    """Paints each cell's background from the _BG_ROLE colour, then the
    centred text on top. Bypasses the stylesheet-override gotcha. Also
    draws a cross-highlight (the selected cell's row + column) so the
    focused industry × month is easy to trace."""

    def __init__(self, parent=None) -> None:    # noqa: ANN001
        super().__init__(parent)
        self.sel_row: int = -1
        self.sel_col: int = -1

    def paint(self, painter, option, index):    # noqa: ANN001, N802
        bg = index.data(_BG_ROLE)
        if isinstance(bg, QColor):
            painter.fillRect(option.rect, bg)

        # Cross-highlight: lighten cells sharing the selected row/column,
        # and outline the selected cell itself.
        r, c = index.row(), index.column()
        if self.sel_row >= 0 and (r == self.sel_row or c == self.sel_col):
            painter.save()
            painter.fillRect(option.rect, _CROSS_TINT)
            if r == self.sel_row and c == self.sel_col:
                pen = painter.pen()
                pen.setColor(QColor(WHITE))
                pen.setWidth(2)
                painter.setPen(pen)
                painter.drawRect(option.rect.adjusted(1, 1, -1, -1))
            painter.restore()

        text = index.data(Qt.ItemDataRole.DisplayRole)
        if text:
            painter.save()
            fg = index.data(Qt.ItemDataRole.ForegroundRole)
            painter.setPen(fg.color() if fg is not None else QColor(WHITE))
            painter.setFont(index.data(Qt.ItemDataRole.FontRole)
                            or QFont(FONT_MONO, 10))
            painter.drawText(option.rect, Qt.AlignmentFlag.AlignCenter, text)
            painter.restore()


class _ContributionTable(QWidget):
    """Constituent-contribution table for a selected (industry, month)
    cell. Shows each member's weight, own avg return for the month, its
    additive magnitude contribution, and a signed reliability impact
    (steadies vs destabilises). Sortable; defaults to magnitude share.

    Emits :attr:`symbol_activated(str)` when a row is double-clicked, so
    the host can open that constituent on the Dashboard."""

    symbol_activated = pyqtSignal(str)

    _COLS = ("Symbol", "Weight", "Avg%", "±Std", "σ/avg", "Hit%",
             "Mag.Contrib", "Rel.Impact", "Yrs", "Remark")

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 6, 2, 0)
        lay.setSpacing(5)
        self._title = QLabel("Select a cell to see constituent impact")
        self._title.setFont(QFont(FONT_UI, 10, QFont.Weight.Bold))
        self._title.setStyleSheet(f"color: {WHITE}; letter-spacing: 1px;")
        lay.addWidget(self._title)

        self._table = QTableWidget()
        self._table.setColumnCount(len(self._COLS))
        self._table.setHorizontalHeaderLabels(list(self._COLS))
        self._table.verticalHeader().setVisible(False)
        self._table.verticalHeader().setDefaultSectionSize(26)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setAlternatingRowColors(True)
        self._table.setShowGrid(False)
        self._table.setSortingEnabled(True)
        self._table.setStyleSheet(_CONTRIB_QSS)
        self._table.setCursor(Qt.CursorShape.PointingHandCursor)
        self._table.cellDoubleClicked.connect(self._on_row_activated)
        hdr = self._table.horizontalHeader()
        # Symbol + Remark are text columns (wider, interactive); the
        # numeric columns share the rest evenly.
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        for i in range(1, len(self._COLS) - 1):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(
            len(self._COLS) - 1, QHeaderView.ResizeMode.Interactive)
        self._table.setColumnWidth(0, 120)
        self._table.setColumnWidth(len(self._COLS) - 1, 230)
        hdr.setSectionsClickable(True)
        hdr.setHighlightSections(False)
        hdr.setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._table, stretch=1)

    def clear(self) -> None:
        self._table.setRowCount(0)
        self._title.setText("Select a cell to see constituent impact")

    def _on_row_activated(self, row: int, _col: int) -> None:
        """Double-click a constituent row → emit its symbol so the host
        can open it on the Dashboard."""
        item = self._table.item(row, 0)
        if item is not None:
            sym = item.text().strip()
            if sym:
                self.symbol_activated.emit(sym)

    def show_cell(self, cell: CellContribution, month_label: str,
                  cell_avg: float, cell_rel: float) -> None:
        if not cell.has_data:
            self.clear()
            return
        rel_txt = "—" if cell_rel != cell_rel else f"{cell_rel*100:.0f}/100"
        self._title.setText(
            f"{cell.industry}  ·  {month_label} — constituent impact      "
            f"cell avg {cell_avg:+.1f}%   ·   reliability {rel_txt}")

        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(cell.members))
        col = {name: i for i, name in enumerate(self._COLS)}
        mag_col = col["Mag.Contrib"]
        for r, m in enumerate(cell.members):
            ratio = (m.member_std / abs(m.member_avg)
                     if (m.member_std == m.member_std
                         and m.member_avg == m.member_avg
                         and abs(m.member_avg) > 1e-9)
                     else float("nan"))
            vals = [
                (m.symbol, m.symbol),
                (f"{m.weight*100:.1f}%", m.weight),
                (_fmt(m.member_avg, "+.1f"), m.member_avg),
                (_fmt(m.member_std, ".1f"), m.member_std),
                (_fmt(ratio, ".2f"), ratio),
                (_fmt(m.member_hit, ".0f"), m.member_hit),
                (_fmt(m.magnitude_contribution, "+.2f"),
                 m.magnitude_contribution),
                (_fmt(m.reliability_impact, "+.2f"), m.reliability_impact),
                (str(m.n_years), m.n_years),
                (m.remark, m.remark),
            ]
            remark_col = col["Remark"]
            for c, (text, sortval) in enumerate(vals):
                item = _NumItem()
                item.setData(Qt.ItemDataRole.DisplayRole, text)
                item.setData(Qt.ItemDataRole.UserRole, sortval)
                if c == remark_col:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignLeft
                                          | Qt.AlignmentFlag.AlignVCenter)
                else:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if c == 0:
                    item.setFont(QFont(FONT_MONO, 10, QFont.Weight.Bold))
                # Colour the contribution + key columns by meaning.
                if c == mag_col and m.magnitude_contribution == \
                        m.magnitude_contribution:
                    item.setForeground(QColor(
                        GREEN if m.magnitude_contribution >= 0 else RED))
                elif c == col["Rel.Impact"] and \
                        m.reliability_impact == m.reliability_impact:
                    item.setForeground(QColor(
                        BLUE if m.reliability_impact >= 0 else RED))
                elif c == col["Avg%"] and m.member_avg == m.member_avg:
                    item.setForeground(QColor(
                        GREEN if m.member_avg >= 0 else RED))
                elif c == col["σ/avg"] and ratio == ratio:
                    # Ratio tells the dispersion story: <0.4 tight (green),
                    # >1 lumpy (amber), middle neutral.
                    item.setForeground(QColor(
                        GREEN if ratio <= 0.4 else
                        GOLD if ratio >= 1.0 else MUTED))
                elif c == remark_col:
                    item.setForeground(QColor(_remark_color(m.remark)))
                    item.setFont(QFont(FONT_MONO, 9))
                else:
                    item.setForeground(QColor(WHITE))
                self._table.setItem(r, c, item)
        self._table.setSortingEnabled(True)
        self._table.sortItems(mag_col, Qt.SortOrder.DescendingOrder)


#: Words that mark a remark as cautionary (amber), reassuring (green),
#: or reliably-negative (red — a dependable loss is not a green light).
_REMARK_WARN = ("single year", "thin", "erratic", "lumpy", "destabilis",
                "drag", "watch")
_REMARK_GOOD = ("steady & dependable", "consistent gain", "anchor",
                "up every year", "solid")
_REMARK_BAD = ("reliably weak", "consistently negative")


def _remark_color(remark: str) -> str:
    r = remark.lower()
    if any(w in r for w in _REMARK_BAD):
        return RED
    if any(w in r for w in _REMARK_WARN):
        return GOLD
    if any(w in r for w in _REMARK_GOOD):
        return GREEN
    return MUTED


def _fmt(v: float, spec: str) -> str:
    return "—" if v != v else format(v, spec)


class _NumItem(QTableWidgetItem):
    """Table item that sorts by its numeric UserRole value (so "+10.0"
    sorts above "+2.0" instead of lexically). NaN/strings sink."""

    def __lt__(self, other: "QTableWidgetItem") -> bool:    # noqa: N802
        a = self.data(Qt.ItemDataRole.UserRole)
        b = other.data(Qt.ItemDataRole.UserRole)
        try:
            af = float(a)
            bf = float(b)
        except (TypeError, ValueError):
            return str(a) < str(b)
        if af != af:    # NaN sinks
            return False
        if bf != bf:
            return True
        return af < bf


class SeasonalityHeatmap(QWidget):
    """Month × industry average-return heatmap.

    Re-exposes :attr:`symbol_activated(str)` from the constituent table
    so a double-clicked constituent can be opened on the Dashboard."""

    symbol_activated = pyqtSignal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(4)

        title_row = QHBoxLayout()
        title = QLabel("SEASONALITY  ·  avg monthly return by industry")
        title.setFont(QFont(FONT_UI, 9, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
        title_row.addWidget(title)
        title_row.addStretch(1)
        # View toggle: Magnitude (mean, outliers desaturated) vs
        # Reliability (consistency — how trustworthy each month is).
        self._view = "magnitude"
        self._btn_mag = QPushButton("Magnitude")
        self._btn_rel = QPushButton("Reliability")
        self._btn_relm = QPushButton("vs Market")
        for b in (self._btn_mag, self._btn_rel, self._btn_relm):
            b.setFont(QFont(FONT_MONO, 9))
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(_TOGGLE_QSS)
            title_row.addWidget(b)
        self._btn_mag.setChecked(True)
        self._btn_mag.clicked.connect(lambda: self._set_view("magnitude"))
        self._btn_rel.clicked.connect(lambda: self._set_view("reliability"))
        self._btn_relm.clicked.connect(lambda: self._set_view("relative"))
        root.addLayout(title_row)
        self._subtitle = QLabel("")
        self._subtitle.setFont(QFont(FONT_MONO, 8))
        self._subtitle.setStyleSheet(f"color: {MUTED};")
        root.addWidget(self._subtitle)

        self._table = QTableWidget()
        self._table.setColumnCount(12)
        self._table.setHorizontalHeaderLabels(list(_MONTHS))
        self._table.verticalHeader().setVisible(True)
        self._table.verticalHeader().setDefaultSectionSize(24)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectItems)
        self._table.setShowGrid(False)
        self._delegate = _HeatmapDelegate(self._table)
        self._table.setItemDelegate(self._delegate)
        self._table.setStyleSheet(_HEATMAP_QSS)
        self._table.currentCellChanged.connect(self._on_cell_selected)
        self._table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch)
        self._table.horizontalHeader().setFixedHeight(28)
        # Click a month header to sort industries by that month's value
        # (toggles desc/asc). Click the same month again to flip order.
        self._table.horizontalHeader().setSectionsClickable(True)
        self._table.horizontalHeader().sectionClicked.connect(
            self._on_month_clicked)
        self._sort_month: int | None = None
        self._sort_desc: bool = True
        self._grid = None    # last SeasonalityGrid, for re-sorting
        # Industry-name (vertical header) column — wider + readable font.
        vh = self._table.verticalHeader()
        vh.setFont(QFont(FONT_MONO, 10))
        vh.setFixedWidth(200)
        vh.setDefaultAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        # Heatmap (top) + constituent-contribution table (bottom), in a
        # vertical splitter. The contribution table is populated when a
        # cell is selected — it decomposes that (industry, month) cell
        # into the member symbols that drove its magnitude & reliability.
        self._split = QSplitter(Qt.Orientation.Vertical)
        self._split.addWidget(self._table)
        self._contrib = _ContributionTable()
        self._contrib.symbol_activated.connect(self.symbol_activated)
        self._split.addWidget(self._contrib)
        self._split.setStretchFactor(0, 3)
        self._split.setStretchFactor(1, 2)
        self._split.setSizes([440, 260])
        root.addWidget(self._split, stretch=1)

        # Members + panel retained so a cell-click can decompose on demand.
        self._members_by_industry: dict = {}
        self._panel: dict = {}

        self._empty = QLabel(
            "Not enough history for seasonality yet — needs ≥3 years.\n"
            "The grid fills in as the price cache deepens.")
        self._empty.setFont(QFont(FONT_MONO, 9))
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty.setVisible(False)
        root.addWidget(self._empty)

    def set_data(self, members_by_industry: dict, panel: dict) -> None:
        self._members_by_industry = members_by_industry or {}
        self._panel = panel or {}
        grid = compute_industry_seasonality(members_by_industry, panel)
        self._grid = grid
        self._render(grid)
        self._contrib.clear()

    def _on_cell_selected(self, row: int, col: int, *_args) -> None:
        """Update the cross-highlight and decompose the selected cell
        into its constituent contributions."""
        self._delegate.sel_row = row
        self._delegate.sel_col = col
        self._table.viewport().update()
        if row < 0 or col < 0 or self._grid is None:
            return
        ordered = self._ordered_rows(self._grid)
        if row >= len(ordered):
            return
        ind_row = ordered[row]
        members = self._members_by_industry.get(ind_row.industry, [])
        if not members or not ind_row.has_data:
            self._contrib.clear()
            return
        cell = compute_cell_contributions(
            ind_row.industry, col + 1, members, self._panel)
        cell_rel = _reliability(ind_row.avg_returns[col],
                                ind_row.std_returns[col])
        self._contrib.show_cell(
            cell, _MONTHS[col], ind_row.avg_returns[col], cell_rel)

    def _set_view(self, view: str) -> None:
        """Switch between 'magnitude', 'reliability', 'relative' views."""
        self._view = view
        self._btn_mag.setChecked(view == "magnitude")
        self._btn_rel.setChecked(view == "reliability")
        self._btn_relm.setChecked(view == "relative")
        if self._grid is not None:
            self._render(self._grid)

    def _on_month_clicked(self, col: int) -> None:
        """Sort industries by the clicked month's avg return. Re-clicking
        the same month flips between descending and ascending."""
        if self._grid is None:
            return
        if self._sort_month == col:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_month = col
            self._sort_desc = True
        self._render(self._grid)

    def _ordered_rows(self, grid: SeasonalityGrid) -> list:
        """Rows in the active sort order. Default (no month selected) is
        the grid's own order (data-availability then name). When a month
        is selected, sort by the metric the ACTIVE VIEW shows for that
        month — avg return in Magnitude, reliability score in Reliability
        — so the ordering always matches the numbers on screen. No-data
        industries sink to the bottom regardless of direction."""
        rows = list(grid.rows)
        if self._sort_month is None:
            return rows
        m = self._sort_month

        def metric(r) -> float:
            if not r.has_data:
                return float("nan")
            if self._view == "reliability":
                return _reliability(r.avg_returns[m], r.std_returns[m])
            if self._view == "relative":
                base = grid.market_baseline[m]
                a = r.avg_returns[m]
                if a != a or base != base:
                    return float("nan")
                return a - base
            return r.avg_returns[m]

        def key(r):
            v = metric(r)
            if v != v:    # NaN sinks to the bottom in both directions
                return (1, 0.0)
            return (0, -v if self._sort_desc else v)

        return sorted(rows, key=key)

    def _render(self, grid: SeasonalityGrid) -> None:
        rows = self._ordered_rows(grid)
        # A re-render (sort/view change) invalidates the old selection
        # coordinates, so clear the cross-highlight to avoid a stale row.
        if getattr(self, "_delegate", None) is not None:
            self._delegate.sel_row = -1
            self._delegate.sel_col = -1
        if not rows:
            self._table.setVisible(False)
            self._empty.setVisible(True)
            self._subtitle.setText("")
            return
        self._table.setVisible(True)
        self._empty.setVisible(False)

        self._table.setRowCount(len(rows))
        self._table.setVerticalHeaderLabels([r.industry for r in rows])

        n_with_data = sum(1 for r in rows if r.has_data)
        sort_note = ""
        if self._sort_month is not None:
            arrow = "▼" if self._sort_desc else "▲"
            sort_note = f" · sorted by {_MONTHS[self._sort_month]} {arrow}"
        if self._view == "magnitude":
            view_note = "colour = magnitude, faded = outlier-driven"
        elif self._view == "reliability":
            view_note = "colour = reliability (blue = consistent)"
        else:
            view_note = "colour = return vs market (industry-specific edge)"
        self._subtitle.setText(
            f"{n_with_data}/{len(rows)} industries with ≥3y history · "
            f"{view_note} · click a month to sort{sort_note}"
        )

        cell_font = QFont(FONT_MONO, 10)
        for ri, row in enumerate(rows):
            for mi in range(12):
                avg = row.avg_returns[mi]
                hit = row.hit_rates[mi]
                std = row.std_returns[mi]
                rel = _reliability(avg, std)
                base = grid.market_baseline[mi]
                relm = (avg - base) if (avg == avg and base == base) \
                    else float("nan")
                item = QTableWidgetItem()
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                item.setFont(cell_font)
                if not row.has_data:
                    item.setData(_BG_ROLE, QColor(S2))
                    item.setForeground(QColor(MUTED))
                    item.setText("·")
                    item.setToolTip(
                        f"{row.industry} — only {row.n_years}y history "
                        f"(need 3). Not enough for seasonality.")
                elif avg == avg:
                    if self._view == "magnitude":
                        # Magnitude colour, faded toward background when
                        # the cell is outlier-driven (low reliability).
                        bg = _desaturate(_cell_color(avg), rel)
                        item.setText(f"{avg:+.1f}")
                    elif self._view == "reliability":
                        # Reliability view — colour by consistency, show
                        # the SNR-ish reliability as a 0..100 score.
                        bg = _reliability_color(rel)
                        item.setText("—" if rel != rel else f"{rel*100:.0f}")
                    else:
                        # Relative-to-market: industry return minus the
                        # cross-industry month baseline. Same diverging
                        # scale, centred at 0 — green = genuine
                        # industry-specific strength, not riding the
                        # market's month.
                        bg = (_relative_color(relm) if relm == relm
                              else QColor(S2))
                        item.setText("—" if relm != relm else f"{relm:+.1f}")
                    item.setData(_BG_ROLE, bg)
                    item.setForeground(QColor(WHITE))
                    hit_txt = (f"{hit:.0f}% of years positive"
                               if hit == hit else "—")
                    std_txt = (f"±{std:.1f}% year-to-year"
                               if std == std else "single year")
                    rel_txt = ("—" if rel != rel
                               else f"{rel*100:.0f}/100 consistency")
                    relm_txt = ("—" if relm != relm
                                else f"{relm:+.2f}% vs market")
                    item.setToolTip(
                        f"{row.industry} · {_MONTHS[mi]}\n"
                        f"avg return {avg:+.2f}%  ({std_txt})\n"
                        f"{relm_txt}\n{hit_txt}\nreliability {rel_txt}\n"
                        f"{row.n_years}y · {row.n_members} members")
                else:
                    item.setData(_BG_ROLE, QColor(S2))
                    item.setForeground(QColor(MUTED))
                    item.setText("")
                self._table.setItem(ri, mi, item)


_CONTRIB_QSS = f"""
QTableWidget {{
    background: transparent;
    color: {WHITE};
    border: 0;
    selection-background-color: {EM}33;
    selection-color: {WHITE};
    font-family: '{FONT_MONO}';
    font-size: 10pt;
    gridline-color: transparent;
    outline: 0;
}}
QHeaderView {{
    background: transparent;
    border: 0;
}}
QHeaderView::section {{
    background: transparent;
    color: {MUTED};
    border: 0;
    border-bottom: 1px solid {BORDER};
    border-right: 1px solid {BORDER}33;
    padding: 6px 8px;
    font-family: '{FONT_UI}';
    font-size: 9pt;
    font-weight: 600;
    letter-spacing: 1px;
}}
QHeaderView::section:last {{
    border-right: 0;
}}
QTableWidget::item {{
    padding: 5px 8px;
    border-bottom: 1px solid {BORDER}33;
    border-right: 1px solid {BORDER}22;
}}
QTableWidget::item:selected {{
    background: {EM}33;
    color: {WHITE};
}}
QTableWidget::item:alternate {{
    background: {BORDER}11;
}}
QTableCornerButton::section {{
    background: transparent;
    border: 0;
}}
"""


_TOGGLE_QSS = f"""
QPushButton {{
    background: {S2};
    border: 1px solid {BORDER};
    border-radius: 3px;
    padding: 2px 10px;
    color: {MUTED};
}}
QPushButton:checked {{
    border: 1px solid {EM};
    color: {WHITE};
}}
"""


_HEATMAP_QSS = f"""
QTableWidget {{
    background: {BG};
    border: 1px solid {BORDER};
    gridline-color: transparent;
    color: {WHITE};
}}
QHeaderView::section:horizontal {{
    background: {S2};
    color: {WHITE};
    border: none;
    padding: 4px 2px;
    font-family: '{FONT_MONO}';
    font-size: 9pt;
    font-weight: bold;
}}
QHeaderView::section:vertical {{
    background: {S2};
    color: {WHITE};
    border: none;
    padding: 2px 8px;
    font-family: '{FONT_MONO}';
    font-size: 9pt;
    text-align: left;
}}
"""
