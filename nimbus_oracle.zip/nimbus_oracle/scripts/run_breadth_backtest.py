#!/usr/bin/env python3
"""
scripts/run_breadth_backtest.py — Does market breadth predict mean reversion outcomes?

Hypothesis: When market breadth is healthy (>60% of NIFTY stocks above 20-SMA),
mean reversion works even during Normal VIX (13-18). When breadth is poor (<40%),
even Panic VIX entries may fail (broad-based selling, not a dip to buy).

Uses NIFTY 100 components to compute breadth. Tests:
  1. Breadth quintiles vs win rate
  2. Breadth × VIX regime interaction
  3. Breadth as a continuous predictor (correlation)
  4. Threshold sweep: what breadth level separates winners from losers?
  5. Breadth as a grade factor: impact on conviction engine

Data: Reconstructs daily breadth from cached price data.

Usage:
    python3 scripts/run_breadth_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd
from scipy import stats

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("breadth_bt")


def compute_breadth(price_cache: dict, date: pd.Timestamp, sma_period: int = 20) -> dict:
    """
    Compute market breadth: % of stocks above their SMA(20) on a given date.
    Uses all available cached symbols as the universe proxy.
    """
    above = 0
    total = 0
    for sym, df in price_cache.items():
        mask = df.index <= date
        sub = df.loc[mask]
        if len(sub) < sma_period + 5:
            continue
        sma = sub["Close"].rolling(sma_period).mean()
        if pd.isna(sma.iloc[-1]):
            continue
        total += 1
        if float(sub["Close"].iloc[-1]) > float(sma.iloc[-1]):
            above += 1

    pct = (above / total * 100) if total > 0 else 50.0
    return {
        "breadth_pct": round(pct, 1),
        "breadth_above": above,
        "breadth_total": total,
        "breadth_healthy": pct >= 60,
        "breadth_weak": pct < 40,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="breadth_backtest_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    # Load all price caches
    price_cache = {}
    cache_dir = "data/backtest_cache"
    if os.path.exists(cache_dir):
        for f in os.listdir(cache_dir):
            if f.endswith("_1d.parquet"):
                sym = f.replace("_1d.parquet", "")
                try:
                    df = pd.read_parquet(os.path.join(cache_dir, f))
                    df.index = pd.to_datetime(df.index)
                    if hasattr(df.index, "tz") and df.index.tz is not None:
                        df.index = df.index.tz_localize(None)
                    price_cache[sym] = df
                except: pass
    logger.info("Price cache: %d symbols", len(price_cache))

    # Load VIX
    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=60)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    # Pre-compute breadth for each unique entry date (much faster than per-trade)
    unique_dates = sorted(trades_df["entry_date"].unique())
    logger.info("Computing breadth for %d unique dates...", len(unique_dates))
    breadth_by_date = {}
    for i, dt in enumerate(unique_dates):
        breadth_by_date[dt] = compute_breadth(price_cache, dt)
        if (i + 1) % 50 == 0:
            logger.info("  %d/%d dates computed", i + 1, len(unique_dates))

    # Match breadth + VIX to each trade
    rows = []
    for _, trade in trades_df.iterrows():
        b = breadth_by_date.get(trade["entry_date"])
        if b is None or b["breadth_total"] < 30:
            continue

        vmask = vix_series.index <= trade["entry_date"]
        vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0
        vix_regime = "PANIC" if vix > 25 else ("ELEVATED" if vix >= 20 else ("NORMAL" if vix >= 13 else "LOW"))

        rows.append({
            "symbol": trade["symbol"],
            "entry_date": trade["entry_date"],
            "pnl_pct": trade["pnl_pct"],
            "win": int(trade["pnl_pct"] > 0),
            "vix": vix,
            "vix_regime": vix_regime,
            **b,
        })

    df = pd.DataFrame(rows)
    logger.info("Ready: %d trades with breadth data", len(df))

    report = []
    report.append("=" * 70)
    report.append("MARKET BREADTH BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)}")
    report.append(f"Breadth universe: {df['breadth_total'].median():.0f} symbols (median)")
    report.append("=" * 70)

    # ══════════════════════════════════════════════════════════════════
    # TEST 1: Breadth quintiles
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 1: BREADTH QUINTILES")
    report.append("=" * 70)

    df["breadth_q"] = pd.qcut(df["breadth_pct"], 5, labels=False, duplicates="drop")
    report.append(f"\n  {'Quintile':10s} {'Range':15s} {'N':>5s} {'Win%':>6s} {'Avg':>7s} {'Sh':>6s}")
    for q in sorted(df["breadth_q"].unique()):
        sub = df[df["breadth_q"] == q]
        rng = f"{sub['breadth_pct'].min():.0f}-{sub['breadth_pct'].max():.0f}%"
        wr = sub["win"].mean() * 100
        avg = sub["pnl_pct"].mean()
        std = sub["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        report.append(f"  Q{q+1:1d}        {rng:15s} {len(sub):5d} {wr:5.1f}% {avg:+6.3f}% {sh:5.2f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 2: Breadth × VIX regime
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 2: BREADTH × VIX REGIME")
    report.append("=" * 70)
    report.append(f"\n  {'VIX':12s} {'Breadth':15s} {'N':>5s} {'Win%':>6s} {'Avg':>7s} {'Sh':>6s}")

    for regime in ["PANIC", "ELEVATED", "NORMAL", "LOW"]:
        for blabel, bmask in [("Healthy (≥60%)", df["breadth_healthy"]),
                               ("Weak (<40%)", df["breadth_weak"]),
                               ("Middle", ~df["breadth_healthy"] & ~df["breadth_weak"])]:
            sub = df[(df["vix_regime"] == regime) & bmask]
            if len(sub) < 10: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            report.append(f"  {regime:12s} {blabel:15s} {len(sub):5d} {wr:5.1f}% {avg:+6.3f}% {sh:5.2f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 3: Correlation
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 3: BREADTH CORRELATION WITH OUTCOMES")
    report.append("=" * 70)

    r_pnl, p_pnl = stats.pearsonr(df["breadth_pct"], df["pnl_pct"])
    r_win, p_win = stats.pointbiserialr(df["win"], df["breadth_pct"])
    report.append(f"  Breadth vs PnL%:  r={r_pnl:+.4f}  p={p_pnl:.4f}")
    report.append(f"  Breadth vs Win:   r={r_win:+.4f}  p={p_win:.4f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 4: Threshold sweep
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 4: BREADTH THRESHOLD SWEEP")
    report.append("=" * 70)
    report.append(f"\n  {'Threshold':12s} {'Above N':>7s} {'Above Win':>9s} {'Below N':>7s} {'Below Win':>9s} {'Delta':>6s}")

    for thresh in [30, 40, 50, 55, 60, 65, 70, 75]:
        above = df[df["breadth_pct"] >= thresh]
        below = df[df["breadth_pct"] < thresh]
        if len(above) < 20 or len(below) < 20: continue
        a_wr = above["win"].mean() * 100
        b_wr = below["win"].mean() * 100
        delta = a_wr - b_wr
        report.append(f"  ≥{thresh}%        {len(above):7d} {a_wr:8.1f}% {len(below):7d} {b_wr:8.1f}% {delta:+5.1f}pp")

    # ══════════════════════════════════════════════════════════════════
    # TEST 5: Normal VIX + breadth — can we trade during normal VIX?
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 5: NORMAL VIX + BREADTH — CAN WE TRADE?")
    report.append("=" * 70)
    report.append("  (Normal VIX = 13-18, where the system currently sits idle)")

    normal = df[df["vix_regime"] == "NORMAL"]
    if len(normal) >= 30:
        report.append(f"\n  Normal VIX trades: {len(normal)}")
        for thresh in [50, 55, 60, 65, 70]:
            sub = normal[normal["breadth_pct"] >= thresh]
            if len(sub) < 10: continue
            wr = sub["win"].mean() * 100
            avg = sub["pnl_pct"].mean()
            std = sub["pnl_pct"].std()
            sh = avg / std * np.sqrt(252/10) if std > 0 else 0
            report.append(f"  Normal VIX + Breadth ≥{thresh}%:  N={len(sub):4d}  Win={wr:.1f}%  Avg={avg:+.3f}%  Sh={sh:.2f}")

    # ══════════════════════════════════════════════════════════════════
    # TEST 6: Breadth as grade factor (simulated)
    # ══════════════════════════════════════════════════════════════════
    report.append("\n" + "=" * 70)
    report.append("TEST 6: BREADTH AS GRADE FACTOR")
    report.append("=" * 70)
    report.append("  Simulated: if breadth ≥ 65% → +1 grade point, < 40% → -1 grade point")

    # Compute current grade from existing factors
    from modules.dual_mode import compute_dual_mode
    from modules.conviction import ConvictionEngine
    engine = ConvictionEngine()

    grade_rows = []
    for _, row in df.iterrows():
        sym = row["symbol"]
        if sym not in price_cache: continue
        pdf = price_cache[sym]
        mask = pdf.index <= row["entry_date"]
        if mask.sum() < 40: continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient: continue
            conv = engine.compute(sig, vix=row["vix"])
            grade_rows.append({
                "grade": conv.grade,
                "pnl_pct": row["pnl_pct"],
                "win": row["win"],
                "breadth_pct": row["breadth_pct"],
            })
        except: pass

    if grade_rows:
        gdf = pd.DataFrame(grade_rows)
        GRADE_ORD = {"A+": 8, "A": 7, "B+": 6, "B": 5, "C+": 4, "C": 3, "D": 2}
        gdf["grade_pts"] = gdf["grade"].map(GRADE_ORD).fillna(0)
        gdf["adj_pts"] = gdf["grade_pts"].copy()
        gdf.loc[gdf["breadth_pct"] >= 65, "adj_pts"] += 1
        gdf.loc[gdf["breadth_pct"] < 40, "adj_pts"] -= 1

        r_base, _ = stats.pearsonr(gdf["grade_pts"], gdf["pnl_pct"])
        r_adj, _ = stats.pearsonr(gdf["adj_pts"], gdf["pnl_pct"])
        report.append(f"\n  Base grade correlation:     r={r_base:+.4f}")
        report.append(f"  Breadth-adjusted grade:     r={r_adj:+.4f}")
        report.append(f"  Improvement:                {(r_adj - r_base):+.4f}")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
