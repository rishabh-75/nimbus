"""
modules/deal_levels.py — Institutional deal level analysis.

Fetches historical bulk, block, and short-selling deals from NSE.
Clusters deals into price levels, scores their significance,
and detects TRAP conditions (institutional shorting near entry).

Scoring weights are structural constants derived from NSE regulations:
  BLOCK > BULK > SHORT (by signal quality, not empirical optimization)
  See spec section "WHY WEIGHTS ARE NOT WALK-FORWARD PARAMETERS".

Usage:
    from modules.deal_levels import analyze_deal_levels
    result = analyze_deal_levels("IRFC", spot_price=94.7)
    print(result.score_delta)   # ±8 max
    print(result.has_trap)      # True if institutional short near spot
    print(result.summary_line)  # Human-readable summary
"""
import datetime
import logging
import math
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# ── Structural constants (not tunable — see spec) ─────────────────────────────

# Signal quality weights by deal type (NSE regulatory definitions)
DEAL_WEIGHTS = {
    "BLOCK": 1.5,   # Pre-negotiated institutional, highest quality
    "BULK": 1.0,    # Mixed participants (HNI + institutional)
    "SHORT": 1.2,   # Institutional bearish conviction
}

# Clustering: deals within this % band are grouped as one level
CLUSTER_BAND_PCT = 0.5

# Age decay: half-life in days (older deals carry less weight)
AGE_HALF_LIFE_DAYS = 180  # 6 months

# Proximity: level within this % of spot is "active"
PROXIMITY_PCT = 2.0

# TRAP thresholds
TRAP_PROXIMITY_PCT = 3.0   # SHORT must be within 3% of spot
TRAP_MAX_AGE_DAYS = 30     # SHORT must be recent (< 30 days)
TRAP_MIN_VALUE_CR = 25.0   # SHORT must be meaningful size

# Score contribution cap
MAX_SCORE_DELTA = 8


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class DealLevel:
    """A clustered price level where institutional deals occurred."""
    price: float              # Weighted average price of cluster
    value_cr: float           # Total deal value in ₹ Crores
    deal_type: str            # Dominant type: BLOCK / BULK / SHORT
    direction: str            # BUY / SELL / SHORT
    entity: str               # Primary entity name
    age_days: int             # Days since most recent deal in cluster
    deal_count: int           # Number of individual deals in cluster
    distance_pct: float = 0.0 # Distance from spot (set at analysis time)


@dataclass
class DealLevelResult:
    """Complete deal level analysis for a symbol."""
    symbol: str
    spot: float
    levels: list[DealLevel] = field(default_factory=list)  # Top-5 by value
    nearest_buy: Optional[DealLevel] = None   # Nearest buy-side below spot
    nearest_sell: Optional[DealLevel] = None   # Nearest sell/short above spot
    score_delta: int = 0                       # Score contribution (±8 max)
    has_trap: bool = False                     # Institutional short TRAP
    trap_detail: str = ""                      # Entity + details if TRAP
    summary_line: str = ""                     # Human-readable summary
    raw_deal_count: int = 0                    # Total deals found


# ── Core analysis ─────────────────────────────────────────────────────────────

def analyze_deal_levels(
    symbol: str,
    spot_price: float,
    client=None,
    lookback_days: int = 90,
) -> DealLevelResult:
    """
    Fetch and analyze institutional deal levels for a symbol.

    Args:
        symbol: NSE symbol (e.g., "IRFC", "GOLDBEES")
        spot_price: Current spot price for proximity calculations
        client: Optional NSEClient instance. Creates one if not provided.
        lookback_days: How far back to fetch deals (default 365 days)

    Returns:
        DealLevelResult with clustered levels, score, and TRAP status.
    """
    result = DealLevelResult(symbol=symbol, spot=spot_price)

    if spot_price <= 0:
        result.summary_line = "No spot price"
        return result

    # ── Fetch deals from NSE ──────────────────────────────────────────────
    today = datetime.date.today()
    from_date = (today - datetime.timedelta(days=lookback_days)).strftime("%d-%m-%Y")
    to_date = today.strftime("%d-%m-%Y")

    all_deals = _fetch_all_deals(symbol, from_date, to_date, client)
    result.raw_deal_count = len(all_deals)

    if not all_deals:
        result.summary_line = "No institutional deals found"
        return result

    # ── Cluster deals into price levels ───────────────────────────────────
    levels = _cluster_deals(all_deals, spot_price)
    if not levels:
        result.summary_line = "No significant deal levels"
        return result

    # ── Sort by value, keep top 5 ─────────────────────────────────────────
    levels.sort(key=lambda l: l.value_cr, reverse=True)
    result.levels = levels[:5]

    # ── Find nearest buy below and sell/short above ───────────────────────
    buy_levels = [l for l in levels if l.direction == "BUY" and l.price < spot_price]
    sell_levels = [l for l in levels if l.direction in ("SELL", "SHORT") and l.price > spot_price]

    if buy_levels:
        result.nearest_buy = min(buy_levels, key=lambda l: abs(l.distance_pct))
    if sell_levels:
        result.nearest_sell = min(sell_levels, key=lambda l: abs(l.distance_pct))

    # ── TRAP detection ────────────────────────────────────────────────────
    result.has_trap, result.trap_detail = _check_trap(levels, spot_price)

    # ── Score contribution ────────────────────────────────────────────────
    result.score_delta = _compute_score_delta(levels, spot_price, result.has_trap)

    # ── Summary line ──────────────────────────────────────────────────────
    result.summary_line = _build_summary(result)

    return result


# ── Deal fetching ─────────────────────────────────────────────────────────────

def _fetch_all_deals(
    symbol: str,
    from_date: str,
    to_date: str,
    client=None,
) -> list[dict]:
    """
    Fetch bulk + block + short deals for a symbol via CSV endpoint.

    Uses NSEClient.fetch_deals_csv() which adds csv=true — this returns
    ALL rows across the date range (the JSON API caps at ~70 display rows).
    3 calls total (bulk, block, short), filter by symbol locally.
    """
    if client is None:
        from modules.nse_client import get_shared_client
        client = get_shared_client()

    sym_upper = symbol.strip().upper()
    deals = []

    for deal_type in ("bulk_deals", "block_deals", "short_selling"):
        try:
            rows = client.fetch_deals_csv(deal_type, from_date, to_date)
            for row in rows:
                row_sym = str(row.get("Symbol", "")).strip().upper()
                if row_sym != sym_upper:
                    continue
                parsed = _parse_deal(row, deal_type)
                if parsed:
                    deals.append(parsed)
        except Exception as exc:
            logger.debug("fetch_deals_csv %s/%s failed: %s", symbol, deal_type, exc)

    return deals


def _parse_deal(row: dict, deal_type: str) -> Optional[dict]:
    """
    Parse a deal row into a normalized dict.

    Handles both CSV and JSON field names:
      CSV Bulk/Block: Date, Symbol, Client Name, Buy / Sell,
                      Quantity Traded, Trade Price / Wght. Avg. Price
      CSV Short:      Date, Symbol, Name, Quantity (no price, no buy/sell)
      JSON Bulk/Block: BD_DT_DATE, BD_SYMBOL, BD_CLIENT_NAME, BD_BUY_SELL,
                       BD_QTY_TRD, BD_TP_WATP
      JSON Short:      SS_DATE, SS_SYMBOL, SS_NAME, SS_QTY
    """
    try:
        is_short = "short" in deal_type

        # Price
        price = _safe_float(
            row.get("Trade Price / Wght. Avg. Price") or  # CSV
            row.get("BD_TP_WATP") or 0                    # JSON
        )
        if not is_short and (not price or price <= 0):
            return None

        # Quantity
        qty = _safe_float(
            row.get("Quantity Traded") or   # CSV bulk/block
            row.get("Quantity") or          # CSV short
            row.get("BD_QTY_TRD") or        # JSON bulk/block
            row.get("SS_QTY") or 0          # JSON short
        )

        # Value in Crores (short has no price → 0)
        value_cr = (price * qty / 1e7) if (price and qty) else 0.0

        # Direction
        if is_short:
            direction = "SHORT"
        else:
            action = str(
                row.get("Buy / Sell") or    # CSV
                row.get("BD_BUY_SELL") or   # JSON
                ""
            ).strip().upper()
            if action in ("BUY", "B"):
                direction = "BUY"
            elif action in ("SELL", "S"):
                direction = "SELL"
            else:
                direction = "BUY"

        # Type
        if "block" in deal_type:
            dtype = "BLOCK"
        elif is_short:
            dtype = "SHORT"
        else:
            dtype = "BULK"

        # Entity
        entity = str(
            row.get("Client Name") or       # CSV bulk/block
            row.get("Name") or              # CSV short
            row.get("BD_CLIENT_NAME") or    # JSON
            row.get("SS_NAME") or           # JSON
            "Unknown"
        ).strip()

        # Date
        date_str = str(
            row.get("Date") or              # CSV
            row.get("BD_DT_DATE") or        # JSON
            row.get("SS_DATE") or           # JSON
            ""
        ).strip()
        age_days = _parse_age(date_str)

        return {
            "price": price or 0.0,
            "value_cr": round(value_cr, 2),
            "deal_type": dtype,
            "direction": direction,
            "entity": entity,
            "age_days": age_days,
        }
    except Exception as exc:
        logger.debug("parse_deal failed: %s", exc)
        return None


def _parse_age(date_str: str) -> int:
    """Parse date string and return days ago. Returns 999 on failure."""
    today = datetime.date.today()
    for fmt in ("%d-%b-%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y", "%d-%B-%Y"):
        try:
            d = datetime.datetime.strptime(date_str.strip(), fmt).date()
            return (today - d).days
        except (ValueError, AttributeError):
            continue
    return 999


# ── Clustering ────────────────────────────────────────────────────────────────

def _cluster_deals(deals: list[dict], spot_price: float) -> list[DealLevel]:
    """
    Group deals within ±0.5% price bands.
    Returns DealLevel objects with aggregated stats.
    """
    if not deals:
        return []

    # Sort by price
    sorted_deals = sorted(deals, key=lambda d: d["price"])

    clusters = []
    current_cluster = [sorted_deals[0]]

    for deal in sorted_deals[1:]:
        center = current_cluster[0]["price"]
        if center > 0 and abs(deal["price"] - center) / center <= CLUSTER_BAND_PCT / 100:
            current_cluster.append(deal)
        else:
            clusters.append(current_cluster)
            current_cluster = [deal]
    clusters.append(current_cluster)

    # Convert clusters to DealLevel objects
    levels = []
    for cluster in clusters:
        total_value = sum(d["value_cr"] for d in cluster)
        if total_value < 1.0:  # Skip trivially small clusters (< ₹1 Cr)
            continue

        # Weighted average price
        if total_value > 0:
            w_price = sum(d["price"] * d["value_cr"] for d in cluster) / total_value
        else:
            w_price = cluster[0]["price"]

        # Dominant type by value
        type_values = {}
        for d in cluster:
            type_values[d["deal_type"]] = type_values.get(d["deal_type"], 0) + d["value_cr"]
        dom_type = max(type_values, key=type_values.get)

        # Dominant direction by value
        dir_values = {}
        for d in cluster:
            dir_values[d["direction"]] = dir_values.get(d["direction"], 0) + d["value_cr"]
        dom_dir = max(dir_values, key=dir_values.get)

        # Primary entity (largest deal)
        primary = max(cluster, key=lambda d: d["value_cr"])

        # Most recent age
        min_age = min(d["age_days"] for d in cluster)

        # Distance from spot
        dist_pct = ((w_price - spot_price) / spot_price * 100) if spot_price > 0 else 0

        levels.append(DealLevel(
            price=round(w_price, 2),
            value_cr=round(total_value, 1),
            deal_type=dom_type,
            direction=dom_dir,
            entity=primary["entity"],
            age_days=min_age,
            deal_count=len(cluster),
            distance_pct=round(dist_pct, 2),
        ))

    return levels


# ── TRAP detection ────────────────────────────────────────────────────────────

def _check_trap(levels: list[DealLevel], spot_price: float) -> tuple[bool, str]:
    """
    Detect institutional short TRAP condition.

    TRAP triggers when ALL of:
    - SHORT deal within TRAP_PROXIMITY_PCT (3%) of spot
    - Disclosed within TRAP_MAX_AGE_DAYS (30 days)
    - Value > TRAP_MIN_VALUE_CR (₹25 Cr)
    """
    for level in levels:
        if level.direction != "SHORT":
            continue
        if abs(level.distance_pct) > TRAP_PROXIMITY_PCT:
            continue
        if level.age_days > TRAP_MAX_AGE_DAYS:
            continue
        if level.value_cr < TRAP_MIN_VALUE_CR:
            continue

        detail = (
            f"SHORT ₹{level.value_cr:.0f}Cr by {level.entity} "
            f"at ₹{level.price:.1f} ({level.age_days}d ago, "
            f"{level.distance_pct:+.1f}% from spot)"
        )
        return True, detail

    return False, ""


# ── Score contribution ────────────────────────────────────────────────────────

def _compute_score_delta(
    levels: list[DealLevel],
    spot_price: float,
    has_trap: bool,
) -> int:
    """
    Compute deal-level score contribution (capped ±8).

    Positive: buy-side institutional levels below spot (support)
    Negative: sell/short levels above spot (resistance) or TRAP
    """
    if has_trap:
        return -MAX_SCORE_DELTA  # Maximum negative on TRAP

    delta = 0.0
    for level in levels:
        # Base weight by deal type
        weight = DEAL_WEIGHTS.get(level.deal_type, 1.0)

        # Age decay: exponential with 6-month half-life
        decay = math.pow(0.5, level.age_days / AGE_HALF_LIFE_DAYS)

        # Size factor: log scale, capped
        size_factor = min(2.0, math.log10(max(1, level.value_cr / 10)) + 0.5)

        # Proximity bonus: within 2% gets 1.5x, otherwise 1.0x
        prox_mult = 1.5 if abs(level.distance_pct) <= PROXIMITY_PCT else 1.0

        # Direction: buy below spot = positive, sell/short above = negative
        raw = weight * decay * size_factor * prox_mult

        if level.direction == "BUY" and level.price < spot_price:
            delta += raw   # Support below — positive
        elif level.direction in ("SELL", "SHORT") and level.price > spot_price:
            delta -= raw   # Resistance above — negative
        elif level.direction == "BUY" and level.price > spot_price:
            delta += raw * 0.3  # Buy above spot — mild positive (already passed)
        elif level.direction in ("SELL", "SHORT") and level.price < spot_price:
            delta -= raw * 0.3  # Sell below spot — mild negative (already passed)

    # Cap to ±MAX_SCORE_DELTA
    capped = max(-MAX_SCORE_DELTA, min(MAX_SCORE_DELTA, round(delta)))
    return int(capped)


# ── Summary ───────────────────────────────────────────────────────────────────

def _build_summary(result: DealLevelResult) -> str:
    """Build human-readable summary for workflow panel."""
    parts = []

    if result.has_trap:
        parts.append(f"⚠ TRAP: {result.trap_detail}")
        return " | ".join(parts)

    if result.nearest_buy:
        b = result.nearest_buy
        parts.append(
            f"BUY support ₹{b.price:.1f} ({b.distance_pct:+.1f}%) "
            f"₹{b.value_cr:.0f}Cr {b.deal_type} {b.age_days}d ago"
        )

    if result.nearest_sell:
        s = result.nearest_sell
        parts.append(
            f"SELL resistance ₹{s.price:.1f} ({s.distance_pct:+.1f}%) "
            f"₹{s.value_cr:.0f}Cr {s.deal_type} {s.age_days}d ago"
        )

    if not parts:
        parts.append(f"{result.raw_deal_count} deals, no levels near spot")

    if result.score_delta != 0:
        parts.append(f"Score {result.score_delta:+d}")

    return " | ".join(parts)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _safe_float(val) -> float:
    """Safely convert to float."""
    if val is None or val == "" or val == "-":
        return 0.0
    try:
        return float(str(val).replace(",", "").strip())
    except (ValueError, TypeError):
        return 0.0
