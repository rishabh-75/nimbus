"""Tests for nimbus_v3.data.nse_client.NSEClient.

Tests mock ``client._session.get`` — the Session's get method. The
Session provides TLS connection pooling that NSE's WAF requires; these
tests verify the cookie handshake, cooldown, and retry logic without
hitting the real NSE.
"""
from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest
import requests

from nimbus_v3.data.nse_client import NSEClient


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _resp(*, status=200, cookies=None, json=None, ct="application/json"):
    r = MagicMock()
    r.status_code = status
    r.cookies = cookies or {}
    r.headers = {"Content-Type": ct}
    r.json.return_value = json if json is not None else {}
    if status >= 400:
        r.raise_for_status.side_effect = Exception(f"HTTP {status}")
    else:
        r.raise_for_status.return_value = None
    return r


def _client(**kw) -> NSEClient:
    """Build a client with warm_on_init=False so we control the mock."""
    return NSEClient(warm_on_init=False, **kw)


def _mock_session(client, *responses):
    """Replace session.get with a sequence of canned responses."""
    it = iter(responses)
    def _get(*a, **k):
        try:
            return next(it)
        except StopIteration:
            raise AssertionError("unexpected extra session.get call")
    client._session.get = MagicMock(side_effect=_get)
    return client._session.get


# ══════════════════════════════════════════════════════════════════════════════
# Session usage
# ══════════════════════════════════════════════════════════════════════════════

def test_client_uses_requests_session() -> None:
    c = _client()
    assert isinstance(c._session, requests.Session)


def test_warm_on_init_calls_homepage() -> None:
    """When warm_on_init=True, constructor hits the homepage."""
    c = _client()
    mock = _mock_session(c,
        _resp(cookies={"nsit": "abc"}),    # warm
    )
    c._warm()
    assert mock.call_count == 1
    url = mock.call_args_list[0][0][0]
    assert "nseindia.com" in url


def test_warm_does_not_raise_on_failure() -> None:
    """_warm is fault-tolerant — logs but never raises."""
    c = _client()
    c._session.get = MagicMock(side_effect=Exception("network down"))
    c._warm()    # should NOT raise


# ══════════════════════════════════════════════════════════════════════════════
# Cookie handshake: warm → seed → fetch
# ══════════════════════════════════════════════════════════════════════════════

def test_warm_then_seed_then_fetch() -> None:
    c = _client()
    mock = _mock_session(c,
        _resp(cookies={"base": "B"}),           # warm
        _resp(cookies={"seed": "S"}),            # seed
        _resp(json={"ok": True}),                # fetch
    )
    c._warm()
    result = c.fetch(
        "https://www.nseindia.com/api/equity-stockIndices",
        referer="https://www.nseindia.com/market-data/live-equity-market",
    )
    assert result == {"ok": True}
    assert mock.call_count == 3

    # Fetch call should have explicit seed cookies.
    fetch_kwargs = mock.call_args_list[2][1]
    assert "seed" in (fetch_kwargs.get("cookies") or {})


def test_different_referers_get_different_seeds() -> None:
    c = _client()
    mock = _mock_session(c,
        _resp(cookies={"base": "B"}),        # warm
        _resp(cookies={"s_opt": "O"}),       # seed for options
        _resp(json={"ep": "options"}),       # fetch options
        _resp(cookies={"s_fil": "F"}),       # seed for filings
        _resp(json={"ep": "filings"}),       # fetch filings
    )
    c._warm()
    c.fetch("https://www.nseindia.com/api/option-chain",
            referer="https://www.nseindia.com/option-chain")
    c.fetch("https://www.nseindia.com/api/corporate-announcements",
            referer="https://www.nseindia.com/companies-listing")
    assert mock.call_count == 5


def test_seed_is_cached_within_ttl() -> None:
    """Second fetch to same referer reuses the cached seed cookies."""
    c = _client()
    mock = _mock_session(c,
        _resp(cookies={"base": "B"}),        # warm
        _resp(cookies={"seed": "S"}),        # seed (first)
        _resp(json={"n": 1}),                # fetch 1
        _resp(json={"n": 2}),                # fetch 2 (NO re-seed)
    )
    c._warm()
    c.fetch("https://x", referer="https://ref")
    c.fetch("https://x", referer="https://ref")
    # 4 calls: warm + seed + fetch1 + fetch2. NO second seed.
    assert mock.call_count == 4


# ══════════════════════════════════════════════════════════════════════════════
# Cooldown on failure
# ══════════════════════════════════════════════════════════════════════════════

def test_failure_triggers_cooldown() -> None:
    c = _client(max_retries=2)
    mock = _mock_session(c,
        _resp(cookies={"base": "B"}),    # warm
        _resp(cookies={"seed": "S"}),    # seed
        _resp(status=500),               # fetch attempt 1 (non-403 → no reset)
        _resp(status=500),               # fetch attempt 2 → cooldown
    )
    c._warm()
    result = c.fetch("https://x", referer="https://ref")
    assert result is None
    assert c.is_in_cooldown("https://ref") is True


def test_cooldown_short_circuits() -> None:
    c = _client(max_retries=2)
    mock = _mock_session(c,
        _resp(cookies={"base": "B"}),
        _resp(cookies={"seed": "S"}),
        _resp(status=500),
        _resp(status=500),
    )
    c._warm()
    c.fetch("https://x", referer="https://ref")
    calls_after = mock.call_count
    # Further calls short-circuit — no HTTP.
    assert c.fetch("https://x", referer="https://ref") is None
    assert mock.call_count == calls_after


def test_cooldown_is_per_referer() -> None:
    c = _client(max_retries=2)
    _mock_session(c,
        _resp(cookies={"base": "B"}),     # warm
        _resp(cookies={"seed_a": "A"}),   # seed ref-a
        _resp(status=500),                 # fail ref-a attempt 1
        _resp(status=500),                 # fail ref-a attempt 2 → cooldown
        _resp(cookies={"seed_b": "Bx"}),  # seed ref-b
        _resp(json={"ok": True}),          # fetch ref-b works
    )
    c._warm()
    assert c.fetch("https://x", referer="https://ref-a") is None
    assert c.is_in_cooldown("https://ref-a") is True
    assert c.is_in_cooldown("https://ref-b") is False
    assert c.fetch("https://y", referer="https://ref-b") == {"ok": True}


# ══════════════════════════════════════════════════════════════════════════════
# Reset
# ══════════════════════════════════════════════════════════════════════════════

def test_reset_creates_new_session() -> None:
    c = _client()
    old_session = c._session
    c.reset()
    assert c._session is not old_session
    assert isinstance(c._session, requests.Session)


# ══════════════════════════════════════════════════════════════════════════════
# Referer header
# ══════════════════════════════════════════════════════════════════════════════

def test_referer_header_on_fetch() -> None:
    c = _client()
    mock = _mock_session(c,
        _resp(cookies={"base": "B"}),
        _resp(cookies={"seed": "S"}),
        _resp(json={"ok": True}),
    )
    c._warm()
    ref = "https://www.nseindia.com/option-chain"
    c.fetch("https://www.nseindia.com/api/x", referer=ref)
    fetch_headers = mock.call_args_list[2][1]["headers"]
    assert fetch_headers["Referer"] == ref


# ══════════════════════════════════════════════════════════════════════════════
# Instance independence
# ══════════════════════════════════════════════════════════════════════════════

def test_two_clients_independent() -> None:
    a = _client(max_retries=2)
    b = _client()
    _mock_session(a,
        _resp(cookies={"base": "B"}),
        _resp(cookies={"seed": "S"}),
        _resp(status=500),
        _resp(status=500),
    )
    a._warm()
    a.fetch("https://x", referer="https://ref")
    assert a.is_in_cooldown("https://ref") is True
    assert b.is_in_cooldown("https://ref") is False
