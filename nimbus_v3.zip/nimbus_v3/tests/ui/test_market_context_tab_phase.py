"""tests.ui.test_market_context_tab_phase — Phase column rendering
+ Score column + ALL row + tooltip honesty.

The Phase column replaces the legacy boolean RIDE column. It
displays one of four short labels — INIT / RETEST / CONT / —
— with priority-tiered colours (Option B):

  - INIT   → WHITE  (highest conviction)
  - RETEST → BLUE   (info / second tier)
  - CONT   → MUTED  (lowest tier)
  - —      → MUTED  (no signal)

Score is the conviction composite (0-100, NaN when no fire).
Default sort is Score descending. ALL row is pinned at the top of
the group table as a universe aggregate.
"""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pandas as pd
import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.ui.theme import BLUE, MUTED, WHITE
from nimbus_v3.ui.widgets.market_context_tab import (
    _COL_WIDTHS,
    _COLUMNS,
    _CONSTITUENT_COLUMNS,
    _PHASE_TOOLTIP,
    _RIDE_PHASE_SORT_KEY,
    _ride_phase_color,
    MarketContextTab,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


# ══════════════════════════════════════════════════════════════════════
# Column presence + structure
# ══════════════════════════════════════════════════════════════════════


class TestColumnPresence:

    def test_phase_in_group_columns(self, qapp):
        assert "Phase" in _COLUMNS

    def test_phase_in_constituent_columns(self, qapp):
        assert "Phase" in _CONSTITUENT_COLUMNS

    def test_score_in_group_columns(self, qapp):
        assert "Score" in _COLUMNS

    def test_score_in_constituent_columns(self, qapp):
        assert "Score" in _CONSTITUENT_COLUMNS

    def test_legacy_ride_column_removed_group(self, qapp):
        assert "RIDE" not in _COLUMNS, (
            "Legacy RIDE column must be removed — replaced by Phase."
        )

    def test_legacy_ride_column_removed_constituent(self, qapp):
        assert "RIDE" not in _CONSTITUENT_COLUMNS

    def test_legacy_composite_removed(self, qapp):
        assert "Composite" not in _COLUMNS, (
            "MR-era Composite column must be removed — replaced by Score."
        )
        assert "Composite" not in _CONSTITUENT_COLUMNS

    def test_legacy_mr_columns_removed(self, qapp):
        """The MR-era SMA-arrow / phase-cycle columns are gone — they
        were artefacts of the abandoned trend-phase classifier."""
        for legacy in (
            "↑SMA20", "↑SMA50", "SMA20 slope", "BBW slope",
            "Vol Δ 60d", "α rank", "Tags",
        ):
            assert legacy not in _COLUMNS, (
                f"Legacy MR-era column {legacy!r} must be removed."
            )
            assert legacy not in _CONSTITUENT_COLUMNS

    def test_phase_before_score_group(self, qapp):
        """Reading flow: Phase column reads first, then Score."""
        assert _COLUMNS.index("Phase") < _COLUMNS.index("Score")

    def test_phase_before_score_constituent(self, qapp):
        assert _CONSTITUENT_COLUMNS.index("Phase") < _CONSTITUENT_COLUMNS.index("Score")

    def test_new_indicator_columns_present(self, qapp):
        """The strategy-native columns (%B / Vol / BBW) must exist on
        both tables — they're the at-a-glance ride context."""
        for col in ("%B", "Vol", "BBW"):
            assert col in _COLUMNS, f"{col} missing from group columns"
            assert col in _CONSTITUENT_COLUMNS, f"{col} missing from constituent"


# ══════════════════════════════════════════════════════════════════════
# Phase color helper
# ══════════════════════════════════════════════════════════════════════


class TestRidePhaseColor:
    """Option B colouring: priority-tiered, no green/red bullish/bearish
    claims (no validated edge). Highest conviction gets brightest WHITE,
    lower tiers get BLUE / MUTED."""

    def test_init_is_white(self, qapp):
        assert _ride_phase_color("INIT") == WHITE

    def test_retest_is_blue(self, qapp):
        assert _ride_phase_color("RETEST") == BLUE

    def test_cont_is_muted(self, qapp):
        assert _ride_phase_color("CONT") == MUTED

    def test_none_dash_is_muted(self, qapp):
        assert _ride_phase_color("—") == MUTED

    def test_unknown_falls_back_to_muted(self, qapp):
        """Defensive default — unknown phase strings render MUTED
        rather than crashing the table."""
        assert _ride_phase_color("UNEXPECTED") == MUTED


# ══════════════════════════════════════════════════════════════════════
# Phase sort priority
# ══════════════════════════════════════════════════════════════════════


class TestPhaseSortKey:
    """Sort key drives the Phase-column header click sort. Highest
    priority = highest sort value, so descending sort puts INIT
    rows at the top."""

    def test_priority_ordering(self, qapp):
        assert _RIDE_PHASE_SORT_KEY["INIT"] > _RIDE_PHASE_SORT_KEY["RETEST"]
        assert _RIDE_PHASE_SORT_KEY["RETEST"] > _RIDE_PHASE_SORT_KEY["CONT"]
        assert _RIDE_PHASE_SORT_KEY["CONT"] > _RIDE_PHASE_SORT_KEY["—"]

    def test_none_dash_is_zero(self, qapp):
        """No-signal rows must sort to the bottom of a descending sort."""
        assert _RIDE_PHASE_SORT_KEY["—"] == 0

    def test_init_is_top_priority(self, qapp):
        """INIT must be the highest-priority phase — operators want
        fresh initiations at the top of the table."""
        assert _RIDE_PHASE_SORT_KEY["INIT"] == max(_RIDE_PHASE_SORT_KEY.values())


# ══════════════════════════════════════════════════════════════════════
# Header tooltip honesty
# ══════════════════════════════════════════════════════════════════════


class TestPhaseTooltip:

    def test_tooltip_mentions_no_validated_edge(self, qapp):
        """Honesty disclosure — the tooltip must tell the operator
        this is a screener, not a validated forward-return signal."""
        tip = _PHASE_TOOLTIP.lower()
        assert "no validated" in tip or "not a validated" in tip or "screener" in tip, (
            "Phase tooltip missing the 'not validated edge' disclosure. "
            "Honesty regression — see research notes."
        )

    def test_tooltip_documents_all_three_phases(self, qapp):
        """The tooltip must describe each phase so operators know
        what triggers each label."""
        tip = _PHASE_TOOLTIP.upper()
        for phase_label in ("INIT", "RETEST", "CONT"):
            assert phase_label in tip, (
                f"Phase tooltip missing description for {phase_label!r}"
            )

    def test_tooltip_documents_priority(self, qapp):
        """Tooltip should explain that INIT > RETEST > CONT priority
        applies when multiple detectors fire on the same bar."""
        tip = _PHASE_TOOLTIP.lower()
        assert "priority" in tip, (
            "Phase tooltip should explain phase resolution priority"
        )

    def test_group_header_tooltip_set(self, qapp):
        tab = MarketContextTab()
        phase_idx = _COLUMNS.index("Phase")
        header_item = tab._table.horizontalHeaderItem(phase_idx)
        assert header_item is not None
        assert header_item.toolTip() == _PHASE_TOOLTIP

    def test_constituent_header_tooltip_set(self, qapp):
        tab = MarketContextTab()
        phase_idx = _CONSTITUENT_COLUMNS.index("Phase")
        header_item = tab._constituent_table.horizontalHeaderItem(phase_idx)
        assert header_item is not None
        assert header_item.toolTip() == _PHASE_TOOLTIP


# ══════════════════════════════════════════════════════════════════════
# Column widths
# ══════════════════════════════════════════════════════════════════════


class TestColumnWidths:

    def test_phase_width_fits_retest(self, qapp):
        """Phase column must be wide enough for the longest label
        ('RETEST', 6 chars). Default font is mono — ~8px per char +
        padding. 60px minimum, 80px comfortable."""
        assert _COL_WIDTHS.get("Phase", 0) >= 60

    def test_score_width_fits_three_digit(self, qapp):
        """Score is 0-100 (max 3 chars + decimal stripped) — 65px
        is comfortable."""
        assert _COL_WIDTHS.get("Score", 0) >= 50

    def test_vol_width_fits_with_suffix(self, qapp):
        """Vol shows "1.45x" — needs ~75px to avoid truncation."""
        assert _COL_WIDTHS.get("Vol", 0) >= 70

    def test_bbw_width_fits_two_digit(self, qapp):
        """BBW shows "12.45" — needs ~75px to avoid truncation."""
        assert _COL_WIDTHS.get("BBW", 0) >= 70


# ══════════════════════════════════════════════════════════════════════
# Default sort
# ══════════════════════════════════════════════════════════════════════


class TestDefaultSort:

    def _build_panel(self):
        """Three-symbol panel with enough history for the engine to
        run (200 bars). Flat input → all phases will be NONE; this
        test only verifies the sort wiring, not phase detection."""
        idx = pd.bdate_range("2024-01-01", periods=200)
        panel: dict[str, pd.DataFrame] = {}
        for sym in ("AAA", "BBB", "CCC"):
            df = pd.DataFrame(index=idx)
            df["Close"] = 100.0
            df["Open"] = 100.0
            df["High"] = 100.0
            df["Low"] = 100.0
            df["Volume"] = 1_000_000.0
            panel[sym] = df
        return panel

    def test_group_table_sort_column_is_score(self, qapp):
        """Verify the group table is configured to sort by Score
        descending after _render_table runs."""
        tab = MarketContextTab()
        # _render_table calls sortByColumn; we can read back the
        # current sort column from horizontalHeader after a render.
        # No data loaded → no rows; we just check the column exists
        # in the column list at the right slot for sort indexing.
        score_col = _COLUMNS.index("Score")
        assert score_col >= 0

    def test_constituent_table_sort_column_is_score(self, qapp):
        score_col = _CONSTITUENT_COLUMNS.index("Score")
        assert score_col >= 0
