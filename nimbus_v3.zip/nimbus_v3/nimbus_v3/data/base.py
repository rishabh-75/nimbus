"""nimbus_v3.data.base — shared protocols for the data layer.

Kept deliberately minimal. Two protocols:

- :class:`CacheStore` — key-to-DataFrame persistence with TTL-aware reads.
- :class:`Loader` — fetches data for a symbol (or market-wide entity); cache
  awareness is the loader's responsibility, not the caller's.

Concrete impls live alongside (``cache.py``, ``price_loader.py``, etc.) and
are injected into higher layers at application startup. No module-level
instances, no singletons — composition is the only integration pattern.
"""
from __future__ import annotations

from datetime import timedelta
from typing import Protocol

import pandas as pd


class CacheStore(Protocol):
    """Key-addressed persistent cache for DataFrames.

    Implementations decide where and how data lives on disk. Callers decide
    when data is stale — the cache surfaces age but never mutates on its
    own (no background eviction, no GC).

    All methods are thread-safe per key; concurrent writes to the same
    key are the caller's problem (wrapping in a lock is fine).
    """

    def get(self, key: str) -> pd.DataFrame | None:
        """Return the DataFrame for ``key``, or ``None`` if absent.

        Raises ``OSError`` only on underlying filesystem failures (disk full,
        permission denied). A missing key is a normal return value, not an
        exception.
        """
        ...

    def set(self, key: str, df: pd.DataFrame) -> None:
        """Persist ``df`` under ``key``. Overwrites any prior value.

        Implementations must write atomically — a partial write is worse
        than no write. Raises ``OSError`` on filesystem failure.
        """
        ...

    def exists(self, key: str) -> bool:
        """Return True if ``key`` has a value (regardless of age)."""
        ...

    def age(self, key: str) -> timedelta | None:
        """Return wall-clock age of the stored value, or ``None`` if absent.

        Callers use this with their own TTL policy to decide whether to
        refresh. The cache has no notion of "expired"; freshness is a
        per-caller decision.
        """
        ...

    def clear(self, prefix: str | None = None) -> int:
        """Remove every key starting with ``prefix`` (or all keys if
        ``prefix`` is ``None``). Return the number of keys removed.
        """
        ...


class Loader(Protocol):
    """A data loader for a single domain (price, options, filings, etc.).

    Loaders compose a ``CacheStore`` with a live fetcher. The default is to
    serve from cache when fresh and fetch-then-cache when stale. Callers
    can force a refresh via explicit parameters on concrete loader methods.

    This protocol is intentionally empty — each loader has domain-specific
    arguments that can't be generalized away. It exists as a type-level
    marker and a conceptual grouping.
    """


#: Canonical OHLCV field names, in the order the project stores them.
_OHLCV_FIELDS: tuple[str, ...] = ("Open", "High", "Low", "Close", "Volume")


def coerce_ohlcv_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Reduce any yfinance column layout to clean, unique OHLCV columns.

    yfinance is inconsistent across versions and between single- and
    multi-ticker requests. Two hazards this normalises, both observed in
    production:

    1. MultiIndex columns with the FIELD level in an unpredictable
       position — ``('Open','RELIANCE.NS')`` in some versions,
       ``('RELIANCE.NS','Open')`` in others. Blindly flattening to level 0
       can yield ticker strings instead of field names.
    2. DUPLICATE field columns on a flat index (a repeated level, or a
       vendor/concat artifact) — e.g. two ``Open`` columns. Selecting
       ``df['Open']`` then returns a 2-column frame, and the eventual
       ``to_parquet`` dies with "Duplicate column names found".

    The fix, shared by every loader so the two paths cannot drift:
    pick the MultiIndex level that actually carries OHLCV names, drop
    duplicate labels (keeping the first — they are identical data), then
    select the canonical fields in a stable order.

    Returns a column-normalised COPY; the index is left untouched (each
    loader owns its own tz / sort / dedupe policy).
    """
    if df is None or df.empty:
        return df
    out = df.copy()
    if isinstance(out.columns, pd.MultiIndex):
        fields = set(_OHLCV_FIELDS) | {"Adj Close"}
        level = 0
        for lvl in range(out.columns.nlevels):
            if set(out.columns.get_level_values(lvl)) & fields:
                level = lvl
                break
        out.columns = out.columns.get_level_values(level)
    if out.columns.duplicated().any():
        out = out.loc[:, ~out.columns.duplicated(keep="first")]
    wanted = [c for c in _OHLCV_FIELDS if c in out.columns]
    return out[wanted]
