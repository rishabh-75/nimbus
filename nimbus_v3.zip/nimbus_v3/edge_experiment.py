#!/usr/bin/env python3
"""edge_experiment.py — does making the edge STOCK-SPECIFIC actually help?

THE QUESTION
------------
The shipped expected-edge is:

    industry_edge = kappa * RS_excess * trust          <- same for ALL members
    member_shift  = kappa * tilt * member_excess * trust
    edge          = (industry_edge + member_shift) * liquidity_gate
    reward_risk   = edge / ATR%

``industry_edge`` is IDENTICAL for every member of an industry. Only
``member_shift`` differentiates them, and it is small: tilt=0.5, then
multiplied by kappa (0.30) and trust (~0.3-0.6), so the member term lands
at roughly 0.05-0.09x of the member's actual excess. The consequence is
that within an industry the ranking is essentially ``1 / ATR%`` — it
favours the QUIETEST name in a hot sector.

Two candidate fixes:

  A) STRUCTURAL — raise ``tilt`` so a stock's own strength genuinely moves
     its edge. This is the honest fix: it makes the model rank stocks, not
     just industries.

  B) PATCH — a "confirmation" gate that discounts members showing no
     participation (no band-ride streak, no volume, no thrust).

They may overlap (both reward the mover) or complement (tilt uses trailing
relative return; confirmation uses volume/streak/thrust, which are
different information). This script tests A, B, and A+B against REAL
forward returns across MULTIPLE as-of dates.

WHAT IS MEASURED
----------------
For each as-of date, build the board using only data up to that date, then
score against what actually happened over the next H bars.

Scored against forward EXCESS return (stock return minus the benchmark's
return over the same window) — because that is what the model claims to
predict. An earlier version scored against ABSOLUTE return, which is a
category error: in a window where the whole market rallies, absolute
returns are dominated by beta and drown the cross-sectional signal.

CONTROLS. The model is an elaborate combination of signals. Before asking
whether that combination is well-tuned, ask whether ANY raw ingredient
predicts forward excess return at all — hence ctl:streak, ctl:vol_ratio,
ctl:chg_5d/10d, ctl:rs_excess, ctl:1/ATR, and ctl:random (a sanity floor
that must score ~0). Two outcomes are especially informative:

  * If NOTHING beats ctl:random, the problem is not the formula — it is
    the premise. There may be no exploitable cross-sectional momentum in
    this universe/period.
  * If ctl:1/ATR or ctl:rs_excess MATCHES the full model, the model's
    machinery is adding nothing over a single raw column.

Metrics:

  * ``rho``    — Spearman rank-corr of the ranking vs forward move/ATR.
                 Does the ordering track what delivered?
  * ``top-k``  — mean forward return of the k highest-ranked names.
                 Would you have made money taking the top of the board?
  * ``spread`` — mean forward return of top-k MINUS bottom-k. Does the
                 ranking separate winners from losers at all?

Averaged over dates, with the per-date spread shown so you can see whether
a result is consistent or one lucky date carrying it.

USAGE
-----
    python edge_experiment.py                    # default sweep
    python edge_experiment.py --horizon 20 --dates 12 --step 10
    python edge_experiment.py --csv results.csv
"""
from __future__ import annotations

import argparse
import logging
import statistics
import sys


def spearman(a, b):
    def ranks(xs):
        order = sorted(range(len(xs)), key=lambda i: xs[i], reverse=True)
        r = [0] * len(xs)
        for pos, i in enumerate(order):
            r[i] = pos
        return r
    n = len(a)
    if n < 3:
        return float("nan")
    ra, rb = ranks(a), ranks(b)
    d2 = sum((ra[i] - rb[i]) ** 2 for i in range(n))
    return 1.0 - 6.0 * d2 / (n * (n * n - 1))


def confirmation(streak, vol_ratio, chg_5d, atr_pct,
                 floor=0.40, streak_full=10.0,
                 vol_base=0.70, vol_span=1.50, thrust_full=4.0):
    """Participation haircut. max() because a name qualifies by being
    EITHER a sustained rider OR a fresh explosive move."""
    s = min(1.0, max(0.0, streak / streak_full)) if streak else 0.0
    v = (min(1.0, max(0.0, (vol_ratio - vol_base) / vol_span))
         if vol_ratio == vol_ratio else 0.0)
    t = (min(1.0, max(0.0, (chg_5d / atr_pct) / thrust_full))
         if (chg_5d == chg_5d and atr_pct and atr_pct > 0) else 0.0)
    return floor + (1.0 - floor) * max(s, v, t)


def load_panel(engine, ind_db):
    from nimbus_v3.data.cache import ParquetCache
    from nimbus_v3.data.enriched_cache import EnrichedPanelCache
    from nimbus_v3.data.paths import cache_dir

    raw_cache = ParquetCache(base_dir=cache_dir("equity_price"))
    ecache = EnrichedPanelCache(
        raw_cache=raw_cache, schema_hash=engine.enrichment_schema_hash())
    panel = {}
    for sym in sorted(ind_db):
        # NB: explicit `is None` checks — `a or b` raises on DataFrames
        # ("truth value is ambiguous"), it does not fall through.
        df = ecache.get_if_fresh(sym)
        if df is None:
            df = ecache.get_stale(sym)
        if df is None:
            try:
                raw = raw_cache.get(sym)
            except Exception:      # noqa: BLE001
                raw = None
            if raw is not None and not raw.empty:
                try:
                    df = engine.enrich(raw, sym)
                except Exception:  # noqa: BLE001
                    df = None
        if df is not None and not df.empty:
            panel[sym] = df
    return panel


def load_benchmark():
    from nimbus_v3.data.cache import ParquetCache
    from nimbus_v3.data.paths import cache_dir
    c = ParquetCache(base_dir=cache_dir("index_price"))
    for sym in ("^CRSLDX", "^NSEI"):
        try:
            df = c.get(sym)
        except Exception:          # noqa: BLE001
            df = None
        if df is not None and not df.empty and "Close" in df:
            return df["Close"]
    return None


def board_at(panel, ind_db, bench, month, asof, tilt):
    """Build the edge board using ONLY data at or before the DATE ``asof``.

    Calls the REAL shipped engine — the only thing varied is ``tilt``, an
    existing engine parameter. No engine code is modified.
    """
    from nimbus_v3.compute.breadth_regime import classify_regime
    from nimbus_v3.compute.confluence import compute_confluence
    from nimbus_v3.compute.equity_edge import compute_equity_edge
    from nimbus_v3.compute.industry_rotation import compute_industry_rotation
    from nimbus_v3.compute.industry_seasonality import (
        compute_industry_seasonality,
    )
    from nimbus_v3.compute.market_breadth import (
        compute_breadth, pct_members_above_sma50,
    )
    from nimbus_v3.compute.market_pulse_common import window_return_pct
    from nimbus_v3.compute.market_pulse_config import (
        RRG_LOOKBACK, STRENGTH_LOOKBACK,
    )
    from nimbus_v3.compute.rrg import compute_rrg
    from nimbus_v3.compute.seasonality import MIN_YEARS

    mbi = {}
    for sym in panel:
        rec = ind_db.get(sym)
        if rec is not None and rec.industry:
            mbi.setdefault(rec.industry, []).append(sym)

    b = bench
    if b is not None and asof is not None:
        b = b.loc[:asof]

    rot = compute_industry_rotation(mbi, panel, lookback=STRENGTH_LOOKBACK)
    rrg = compute_rrg(mbi, panel, b, lookback=RRG_LOOKBACK)
    seas = compute_industry_seasonality(mbi, panel,
                                        min_member_years=MIN_YEARS)
    breadth = {i: pct_members_above_sma50(m, panel) for i, m in mbi.items()}

    regime = None
    mkt_b = None
    try:
        bdf = compute_breadth(panel)
        regime = classify_regime(bdf, b)
        col = bdf["pct_above_sma50"].dropna()
        if len(col):
            mkt_b = float(col.iloc[-1])
            if mkt_b > 1.0:
                mkt_b /= 100.0
    except Exception:              # noqa: BLE001
        pass
    if mkt_b is None:
        mkt_b = pct_members_above_sma50(list(panel), panel)

    bret = (window_return_pct(b, STRENGTH_LOOKBACK)
            if b is not None else 0.0)
    conf = compute_confluence(
        rot, rrg, seas, regime, month,
        breadth_by_industry=breadth, market_breadth=mkt_b,
        benchmark_return=bret)
    return compute_equity_edge(
        conf, rot, mbi, panel, b,
        lookback=STRENGTH_LOOKBACK, member_tilt=tilt)


def run_date(full_panel, ind_db, bench, month, asof, horizon, tilts):
    """One as-of DATE. Returns {variant: [(rank_key, fwd_ret, fwd_rr)]}.

    CRITICAL: the model predicts EXCESS return over the benchmark
    (``mu_hat`` is explicitly "expected return in excess of the
    benchmark"). Scoring it against ABSOLUTE forward return measures
    something it never claimed to predict — in a window where the whole
    market rallies, absolute returns are dominated by beta, which drowns
    the (small) cross-sectional signal. So we subtract the benchmark's
    move over the SAME forward window and score against excess.
    """
    # Benchmark's forward move over the SAME window, in %.
    #
    # Everything below slices by DATE, not by position. `cut = len(df) -
    # offset` slices each symbol at a DIFFERENT CALENDAR DATE whenever the
    # panel's symbols do not all end on the same day — which yours do not
    # (two distinct end-dates). That silently compares a peer group across
    # mismatched days, and it is why a RANDOM control was scoring +1.8%
    # excess in earlier runs: an impossible result in a correctly specified
    # excess-return study, and the tell that the harness was broken.
    bench_fwd = 0.0
    if bench is not None:
        bi = bench.index.searchsorted(asof, side="right") - 1
        if 0 <= bi and bi + horizon < len(bench):
            b0 = float(bench.iloc[bi])
            b1 = float(bench.iloc[bi + horizon])
            if b0 > 0:
                bench_fwd = (b1 / b0 - 1.0) * 100.0

    hist = {}
    fwd = {}
    for sym, df in full_panel.items():
        idx = df.index
        pos = idx.searchsorted(asof, side="right") - 1
        if pos < 60 or pos + horizon >= len(idx):
            continue
        h = df.iloc[:pos + 1]
        c0 = float(df["Close"].iloc[pos])
        c1 = float(df["Close"].iloc[pos + horizon])
        if c0 <= 0:
            continue
        hist[sym] = h
        # EXCESS forward return — the quantity the model actually predicts.
        fwd[sym] = (c1 / c0 - 1.0) * 100.0 - bench_fwd
    if len(hist) < 30:
        return None

    out = {}
    for tilt in tilts:
        edge = board_at(hist, ind_db, bench, month, asof, tilt)
        if not edge.has_data:
            continue

        # RANKING-KEY SWEEP. The shipped key is edge/ATR%. That denominator
        # systematically favours LOW-VOLATILITY names — which for a
        # rotation tool is backwards: the movers are volatile *because*
        # they are moving. So we test the same edge under four keys:
        #
        #   /ATR      : shipped (Sharpe-like)
        #   raw       : expected_edge, no risk denominator at all
        #   /sqrtATR  : half-strength denominator (compromise)
        #   xATR      : edge * ATR — actively PREFERS volatile names
        #
        # Each with and without the confirmation gate. If `raw` beats
        # `/ATR`, the denominator is destroying signal and should go.
        keys = {}
        for gated in (False, True):
            suffix = "+conf" if gated else ""
            keys[f"t{tilt}{suffix} /ATR"] = []
            keys[f"t{tilt}{suffix} raw"] = []
            keys[f"t{tilt}{suffix} /sqrtATR"] = []
            keys[f"t{tilt}{suffix} xATR"] = []

        for r in edge.rows:
            fr = fwd.get(r.symbol)
            if fr is None or r.atr_pct <= 0:
                continue
            frr = fr / r.atr_pct
            cg = confirmation(r.streak, r.vol_ratio, r.chg_5d, r.atr_pct)
            for gated in (False, True):
                suffix = "+conf" if gated else ""
                e = r.expected_edge * (cg if gated else 1.0)
                a = r.atr_pct
                keys[f"t{tilt}{suffix} /ATR"].append((e / a, fr, frr))
                keys[f"t{tilt}{suffix} raw"].append((e, fr, frr))
                keys[f"t{tilt}{suffix} /sqrtATR"].append(
                    (e / (a ** 0.5), fr, frr))
                keys[f"t{tilt}{suffix} xATR"].append((e * a, fr, frr))

        for k, rows in keys.items():
            if rows:
                out[k] = rows

    # ---- CONTROLS -----------------------------------------------------
    # The model is an elaborate combination of signals. Before asking
    # whether the combination is well-tuned, ask whether ANY of its raw
    # ingredients predicts forward excess return at all. If none of these
    # controls works either, the problem is not the formula — it is the
    # premise (there may simply be no exploitable cross-sectional momentum
    # signal in this universe/period).
    #
    # A control that BEATS the model is also informative: it means the
    # model's machinery is destroying signal that a raw column already has.
    ref = board_at(hist, ind_db, bench, month, asof, 0.5)
    if ref.has_data:
        ctl = {
            "ctl:streak": [],       # pure band-ride persistence
            "ctl:vol_ratio": [],    # pure volume surge
            "ctl:chg_5d": [],       # pure short-term momentum
            "ctl:chg_10d": [],      # pure medium-term momentum
            "ctl:rs_excess": [],    # pure INDUSTRY strength (no member info)
            "ctl:1/ATR": [],        # pure low-volatility (what the shipped
                                    # ranking degenerates to within-industry)
            "ctl:random": [],       # sanity floor — should score ~0
        }
        import random as _rnd
        _r = _rnd.Random(12345 + hash(asof) % 10000)
        for r in ref.rows:
            fr = fwd.get(r.symbol)
            if fr is None or r.atr_pct <= 0:
                continue
            frr = fr / r.atr_pct
            v = r.vol_ratio if r.vol_ratio == r.vol_ratio else 0.0
            c5 = r.chg_5d if r.chg_5d == r.chg_5d else 0.0
            c10 = r.chg_10d if r.chg_10d == r.chg_10d else 0.0
            ctl["ctl:streak"].append((float(r.streak), fr, frr))
            ctl["ctl:vol_ratio"].append((v, fr, frr))
            ctl["ctl:chg_5d"].append((c5, fr, frr))
            ctl["ctl:chg_10d"].append((c10, fr, frr))
            ctl["ctl:rs_excess"].append((r.industry_rs_excess, fr, frr))
            ctl["ctl:1/ATR"].append((1.0 / r.atr_pct, fr, frr))
            ctl["ctl:random"].append((_r.random(), fr, frr))
        for k, rows in ctl.items():
            if rows:
                out[k] = rows
    return out


def score(rows, topk):
    """rho vs forward EXCESS return, mean top-k excess, top-minus-bottom.

    NOTE the rho target is PLAIN forward excess return, deliberately NOT
    excess/ATR. Scoring against excess/ATR would put ATR in the denominator
    of the *target* as well as the ranking key, which structurally flatters
    ATR-denominated rankings — it would rig the very comparison we are
    running. What we care about is: does the ranking pick names that go up
    more than the market? That is plain excess return.
    """
    rows = sorted(rows, key=lambda t: -t[0])
    n = len(rows)
    if n < topk * 2:
        return None
    rho = spearman([t[0] for t in rows], [t[1] for t in rows])
    top = statistics.mean(t[1] for t in rows[:topk])
    bot = statistics.mean(t[1] for t in rows[-topk:])
    return rho, top, top - bot


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--horizon", type=int, default=10,
                    help="forward horizon in bars (default 10). Was 20 — too "
                         "long: the edge model's signals (streak, thrust, "
                         "volume) are short-lived, and a month-long window "
                         "lets them decay into noise before we measure.")
    ap.add_argument("--dates", type=int, default=10,
                    help="how many as-of dates to test (default 10)")
    ap.add_argument("--step", type=int, default=10,
                    help="bars between as-of dates (default 10)")
    ap.add_argument("--topk", type=int, default=10,
                    help="basket size for the top-k return (default 10)")
    ap.add_argument("--tilts", type=str, default="0.5",
                    help="member tilts to sweep (0.5 = shipped). Default is "
                         "just the shipped tilt, so the RANKING-KEY question "
                         "is legible; pass more to sweep tilt as well.")
    ap.add_argument("--month", type=int, default=None)
    ap.add_argument("--csv", type=str, default=None)
    args = ap.parse_args()

    logging.basicConfig(level=logging.ERROR)

    import datetime as dt
    import pandas as pd
    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db

    engine = StrategyComputeEngine()
    ind_db = load_industry_db()
    if not ind_db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    print("loading panel...", file=sys.stderr)
    panel = load_panel(engine, ind_db)

    # ALWAYS print the panel's real shape. A sibling script (volume_probe)
    # silently truncated its whole study to the SHORTEST symbol's history —
    # 204 bars out of 1242 — and reported confident nulls computed on a
    # fifth of the data. The only reason it was caught is that the number
    # looked wrong on screen. Print the inputs; do not make the reader
    # trust that the harness got them right.
    lens = sorted(len(df) for df in panel.values())
    if lens:
        ends = {df.index[-1] for df in panel.values()}
        print(f"  bars per symbol: min={lens[0]}  "
              f"median={lens[len(lens) // 2]}  max={lens[-1]}",
              file=sys.stderr)
        print(f"  distinct end-dates: {len(ends)}"
              f"{'  (all aligned)' if len(ends) == 1 else '  <-- WARNING'}",
              file=sys.stderr)
        if len(ends) > 1:
            print("  *** Symbols end on DIFFERENT dates. `cut = len(df) - "
                  "offset` would then slice each symbol at a different "
                  "CALENDAR DATE, comparing a peer group across mismatched "
                  "days. Results would be meaningless. ***",
                  file=sys.stderr)

    bench = load_benchmark()
    if bench is None:
        print("^CRSLDX not cached — run the app once first.",
              file=sys.stderr)
        return 1
    print(f"panel: {len(panel)} symbols; benchmark: {len(bench)} bars",
          file=sys.stderr)

    month = args.month or dt.date.today().month
    tilts = [float(x) for x in args.tilts.split(",")]

    # A DATE grid, walking back from the most recent testable day.
    #
    # NOT positional offsets. `len(df) - offset` means a different CALENDAR
    # DATE for every symbol once the panel's symbols end on different days,
    # which silently compares the cross-section across mismatched dates.
    all_dates = sorted({d for df in panel.values() for d in df.index})
    asofs = []
    for i in range(args.dates):
        di = len(all_dates) - args.horizon - 1 - i * args.step
        if di < 80:
            break
        asofs.append(all_dates[di])

    per_variant = {}
    n_ok = 0
    for k, asof in enumerate(asofs, 1):
        print(f"  date {k}/{len(asofs)} ({asof.date()})...",
              file=sys.stderr)
        res = run_date(panel, ind_db, bench, month, asof, args.horizon,
                       tilts)
        if not res:
            continue
        n_ok += 1
        for variant, rows in res.items():
            s = score(rows, args.topk)
            if s is None:
                continue
            per_variant.setdefault(variant, []).append(s)

    if not per_variant:
        print("no usable dates — not enough history.", file=sys.stderr)
        return 1

    print()
    print("=" * 94)
    print(f"  EDGE EXPERIMENT — {n_ok} as-of dates, {args.horizon}-bar "
          f"horizon, top-{args.topk} basket")
    print("  Scored against forward EXCESS return (vs benchmark) — the "
          "quantity the model predicts.")
    print("=" * 94)
    print(f"  {'variant':<22}{'rho':>16}{'top-k excess':>16}"
          f"{'top-bot spread':>18}{'sig?':>8}")
    print(f"  {'':<22}{'mean (sd)':>16}{'mean (sd)':>16}{'mean (sd)':>18}")
    print("-" * 94)

    shipped_key = "t0.5 /ATR"

    _KEY_ORDER = {"/ATR": 0, "/sqrtATR": 1, "raw": 2, "xATR": 3}

    def sort_key(v):
        if v.startswith("ctl:"):
            return (2, 0, 0, v)
        # e.g. "t0.5+conf /ATR"
        head, _, kname = v.rpartition(" ")
        gated = 1 if "+conf" in head else 0
        try:
            tilt = float(head.replace("t", "").replace("+conf", ""))
        except ValueError:
            tilt = 0.0
        return (0, gated, _KEY_ORDER.get(kname, 9), tilt)

    rows_out = []
    printed_ctl_header = False
    for variant in sorted(per_variant, key=sort_key):
        if variant.startswith("ctl:") and not printed_ctl_header:
            print("-" * 94)
            print("  CONTROLS — raw single signals. Does ANYTHING predict?")
            printed_ctl_header = True
        vals = per_variant[variant]
        rhos = [v[0] for v in vals if v[0] == v[0]]
        tops = [v[1] for v in vals]
        sprs = [v[2] for v in vals]

        def ms(xs, pct=False):
            if not xs:
                return "—"
            m = statistics.mean(xs)
            s = statistics.stdev(xs) if len(xs) > 1 else 0.0
            return (f"{m:+.2f}% ({s:.1f})" if pct
                    else f"{m:+.3f} ({s:.2f})")

        # Crude significance: is |mean| > 2 standard ERRORS from zero?
        # (se = sd / sqrt(n)). Anything not flagged is indistinguishable
        # from noise and must NOT be acted on.
        sig = ""
        if len(tops) > 1:
            se = statistics.stdev(tops) / (len(tops) ** 0.5)
            if se > 0 and abs(statistics.mean(tops)) > 2 * se:
                sig = "  *"
        mark = "  <- shipped" if variant == shipped_key else ""
        print(f"  {variant:<22}{ms(rhos):>16}{ms(tops, True):>16}"
              f"{ms(sprs, True):>18}{sig:>8}{mark}")
        rows_out.append({
            "variant": variant,
            "rho_mean": statistics.mean(rhos) if rhos else float("nan"),
            "rho_sd": statistics.stdev(rhos) if len(rhos) > 1 else 0.0,
            "topk_excess_mean": statistics.mean(tops),
            "topk_excess_sd": (statistics.stdev(tops) if len(tops) > 1
                               else 0.0),
            "spread_mean": statistics.mean(sprs),
            "spread_sd": statistics.stdev(sprs) if len(sprs) > 1 else 0.0,
            "significant": bool(sig.strip()),
            "n_dates": len(vals),
        })

    print("-" * 94)
    print("  HOW TO READ THIS")
    print("  rho    : rank-corr of the ranking vs forward EXCESS move/ATR.")
    print("  top-k  : mean forward EXCESS return of the k top-ranked names.")
    print("  spread : top-k minus bottom-k. ~0 means the ranking is not")
    print("           separating winners from losers at all.")
    print("  sig?   : '*' = |mean| exceeds 2 standard errors from zero.")
    print("           NO STAR = indistinguishable from noise. Do not act")
    print("           on an unstarred result, however good the mean looks.")
    print()
    print("  ctl:random is the sanity floor — it MUST score ~0. If a real")
    print("  signal cannot beat it, that signal is not predictive here.")
    print()
    print("  ctl:1/ATR matters: within an industry the shipped ranking")
    print("  degenerates to exactly this. If 1/ATR scores as well as the")
    print("  full model, the model's machinery is adding nothing.")
    print()
    print("  RANKING KEYS — same edge, different denominator:")
    print("    /ATR     = shipped (Sharpe-like). Favours LOW-vol names.")
    print("    raw      = expected_edge alone, no risk denominator.")
    print("    /sqrtATR = half-strength denominator.")
    print("    xATR     = actively prefers volatile names.")
    print("  If `raw` beats `/ATR`, the denominator is destroying signal:")
    print("  for a rotation tool the movers are volatile BECAUSE they move,")
    print("  so dividing by vol systematically demotes exactly the names")
    print("  you are trying to find.")
    print()
    print("  ctl:rs_excess is the pure INDUSTRY signal with no member info.")
    print("  If it matches the full model, the model is ranking industries,")
    print("  not stocks.")
    print()

    if args.csv:
        pd.DataFrame(rows_out).to_csv(args.csv, index=False)
        print(f"wrote {args.csv}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
