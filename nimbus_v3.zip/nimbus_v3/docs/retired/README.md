# Retired Code Log

When a subsystem is removed for being orphaned or superseded, its design
and salvageable core logic are documented here **before** deletion — so
the code can be reconstructed if it's ever wanted again. This is what
makes it safe to let redundant code go: the executable is gone, the
knowledge isn't.

This mirrors the research log (`docs/research/`): the codebase carries
what's live; this log carries what was removed and why.

## Conventions

- One file per retirement: `docs/retired/NNN-slug.md`, zero-padded.
- Record: what it was, exact modules/tests removed, preserved core
  logic as code snippets, and restoration notes.
- Full source always remains in zip/version history; the snippets here
  are the *reusable cores* so reconstruction doesn't require archaeology.

## Index

| ID | Title | Retired | Reason |
|----|-------|---------|--------|
| 001 | Industry relative-strength analytics | 2026-06-18 | Orphaned by ride-only refactor (audit Issue 1) |
