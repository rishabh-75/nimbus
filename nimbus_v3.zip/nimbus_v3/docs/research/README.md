# Research Log

Findings and methodology for every research/validation effort, kept as
durable markdown instead of one-off scripts.

## Why this exists

Research scripts are write-once, run-a-few-times, then rot — they import
modules that get refactored away and break, and they bury the actual
*finding* under argparse/IO/logging scaffolding. The knowledge is worth
keeping; the executable rarely is.

**The practice:** when a research question is answered, write it up here
(copy `_TEMPLATE.md` → `NNN-slug.md`), preserve the reusable core logic
as a code snippet, record the numbers including null results, then delete
the script. The strategy code carries the *result* (a tuned constant, a
gate); this log carries the *justification* (why that value, what else
was tried).

## Conventions

- One file per study: `docs/research/NNN-slug.md`, zero-padded sequential.
- Every file starts with the metadata table from the template.
- `Status` is one of: `exploratory`, `validated`, `rejected`, `superseded`.
- When a later study supersedes an earlier one, set the old one's status
  to `superseded` and link forward.
- Record null/negative results — they stop the same dead-end being
  re-explored.

## Index

| ID  | Title | Status | Outcome |
|-----|-------|--------|---------|
| RT-001 | Ride continuation/retest tuning | validated | Locked CONT/RETEST lookbacks + body/detach thresholds |
| RT-002 | Phase P(win) study | exploratory | Phase classification stays technical; capital-cycle deferred |
| RT-003 | Industry score recalibration | validated | Breadth-scaled ADTV-weighted member score + Riding count |
| RT-004 | Market-breadth regime | validated | Confirming tape predicts ride sustain; added as display-only sidebar state |

_(Add a row per study. Keep newest at the bottom.)_

## Note on pre-log studies

Studies run before this log existed (the April–May 2026 validation
scripts: gate ablation, walk-forward, alpha/beta/volume feature research,
VIX/correlation regime work, etc.) were deleted once their conclusions
were baked into the ride engine. Their *results* survive as the tuned
constants in `compute/ride_initiation/constants.py` and the strategy
logic; their detailed methodology was not back-filled into this log.
RT-001 and RT-002 capture the two whose findings are still load-bearing
and reconstructable with confidence.
