"""Tests for nimbus_v3.ui.widgets.components — Dashboard primitives."""
from __future__ import annotations

from PyQt6.QtWidgets import QLabel

from nimbus_v3.ui.theme import (
    BORDER, EM, GOLD, GRADE_STYLES, GREEN, MUTED, RED, SIZING_STYLES,
    STAGE_STYLES, VERDICT_STYLES, WHITE,
)
from nimbus_v3.ui.widgets.components import (
    Badge, ChecklistRow, KPITile, LevelRow, PanelFrame, RiskNote,
)


# ══════════════════════════════════════════════════════════════════════════════
# KPITile
# ══════════════════════════════════════════════════════════════════════════════

def test_kpi_tile_constructs(qapp) -> None:    # noqa: ARG001
    t = KPITile("SPOT")
    # Label rendered uppercase.
    assert t._name.text() == "SPOT"
    # Initial placeholder.
    assert t._value.text() == "--"
    # Delta hidden until set.
    assert not t._delta.isVisible() or t._delta.text() == ""


def test_kpi_tile_uppercases_label(qapp) -> None:    # noqa: ARG001
    t = KPITile("pcr oi")
    assert t._name.text() == "PCR OI"


def test_kpi_tile_set_value_updates_text(qapp) -> None:    # noqa: ARG001
    t = KPITile("SPOT")
    t.set_value("25,800.50", color=GREEN, delta="+0.42%")
    assert t._value.text() == "25,800.50"
    assert "color: #22C55E" in t._value.styleSheet()    # GREEN
    assert t._delta.text() == "+0.42%"


def test_kpi_tile_set_value_no_delta_hides_delta(qapp) -> None:    # noqa: ARG001
    t = KPITile("X")
    t.set_value("100", delta="should-show")
    assert t._delta.text() == "should-show"
    t.set_value("200")    # no delta arg
    # Delta should be hidden when called without one.
    assert t._delta.isHidden() or t._delta.text() == "should-show"


def test_kpi_tile_set_title_renames(qapp) -> None:    # noqa: ARG001
    t = KPITile("PCR OI")
    t.set_title("vsr")
    assert t._name.text() == "VSR"


def test_kpi_tile_set_stale_changes_border_color(qapp) -> None:    # noqa: ARG001
    t = KPITile("SPOT")
    initial_qss = t.styleSheet()
    t.set_stale(True)
    stale_qss = t.styleSheet()
    assert "#F59E0B" in stale_qss     # GOLD
    assert stale_qss != initial_qss


# ══════════════════════════════════════════════════════════════════════════════
# Badge — multi-dict lookup
# ══════════════════════════════════════════════════════════════════════════════

def test_badge_constructs_neutral(qapp) -> None:    # noqa: ARG001
    b = Badge()
    # Constructed via apply_style("NEUTRAL") which falls back to _NEUTRAL_BADGE.
    qss = b.styleSheet()
    assert "border" in qss


def test_badge_grade_styles_resolve(qapp) -> None:    # noqa: ARG001
    """A grade letter resolves via GRADE_STYLES."""
    b = Badge()
    b.set_badge("A")
    expected = GRADE_STYLES["A"]
    qss = b.styleSheet()
    assert expected["text"] in qss


def test_badge_sizing_styles_resolve(qapp) -> None:    # noqa: ARG001
    """A sizing keyword resolves via SIZING_STYLES."""
    b = Badge()
    b.set_badge("FULL")
    expected = SIZING_STYLES["FULL"]
    assert expected["text"] in b.styleSheet()


def test_badge_verdict_styles_resolve(qapp) -> None:    # noqa: ARG001
    b = Badge()
    b.set_badge("TAKE")
    assert VERDICT_STYLES["TAKE"]["text"] in b.styleSheet()


def test_badge_stage_styles_resolve(qapp) -> None:    # noqa: ARG001
    b = Badge()
    b.set_badge("EXTENDED")
    assert STAGE_STYLES["EXTENDED"]["text"] in b.styleSheet()


def test_badge_unknown_text_falls_back_to_neutral(qapp) -> None:    # noqa: ARG001
    b = Badge()
    b.set_badge("Some custom unrecognised label")
    # Neutral text colour.
    assert MUTED in b.styleSheet()


def test_badge_explicit_style_key_overrides_text(qapp) -> None:    # noqa: ARG001
    """Passing an explicit style_key overrides the text-driven lookup."""
    b = Badge()
    b.set_badge("Bullish breakout setup", style_key="A")
    assert b.text() == "Bullish breakout setup"
    assert GRADE_STYLES["A"]["text"] in b.styleSheet()


def test_badge_long_text_elided(qapp) -> None:    # noqa: ARG001
    """Text over 28 chars is elided, full text in tooltip."""
    long_text = "x" * 40
    b = Badge()
    b.set_badge(long_text)
    assert b.text().endswith("…")
    assert len(b.text()) <= 28
    assert b.toolTip() == long_text


def test_badge_short_text_not_elided(qapp) -> None:    # noqa: ARG001
    b = Badge()
    b.set_badge("FULL")
    assert b.text() == "FULL"
    assert "…" not in b.text()


# ══════════════════════════════════════════════════════════════════════════════
# PanelFrame
# ══════════════════════════════════════════════════════════════════════════════

def test_panel_frame_constructs_with_title(qapp) -> None:    # noqa: ARG001
    pf = PanelFrame("Conviction")
    # First widget in the layout should be the title label.
    first = pf.content_layout().itemAt(0).widget()
    assert isinstance(first, QLabel)
    assert first.text() == "CONVICTION"


def test_panel_frame_constructs_without_title(qapp) -> None:    # noqa: ARG001
    pf = PanelFrame()
    # No title widget added.
    assert pf.content_layout().count() == 0


def test_panel_frame_set_accent_changes_top_border(qapp) -> None:    # noqa: ARG001
    pf = PanelFrame("X", accent=BORDER)
    initial = pf.styleSheet()
    pf.set_accent(EM)
    assert EM in pf.styleSheet()
    assert pf.styleSheet() != initial


def test_panel_frame_content_layout_accepts_children(qapp) -> None:    # noqa: ARG001
    pf = PanelFrame("X")
    label = QLabel("child")
    pf.content_layout().addWidget(label)
    # Title (1) + child (1) = 2 items.
    assert pf.content_layout().count() == 2


# ══════════════════════════════════════════════════════════════════════════════
# LevelRow
# ══════════════════════════════════════════════════════════════════════════════

def test_level_row_constructs(qapp) -> None:    # noqa: ARG001
    lr = LevelRow()
    assert lr._name.text() == ""
    assert lr._val.text() == ""
    assert lr._pct.text() == ""


def test_level_row_set_data_renders_with_thousands_sep(qapp) -> None:    # noqa: ARG001
    lr = LevelRow()
    lr.set_data("Resistance", 25000.0, color=GREEN, pct="+5.3%")
    assert lr._name.text() == "RESISTANCE"
    assert lr._val.text() == "25,000"
    assert lr._pct.text() == "+5.3%"
    assert GREEN in lr._val.styleSheet()
    assert GREEN in lr._pct.styleSheet()


def test_level_row_color_propagates_to_value_and_pct(qapp) -> None:    # noqa: ARG001
    lr = LevelRow()
    lr.set_data("Support", 24000.0, color=RED, pct="-3.1%")
    assert RED in lr._val.styleSheet()
    assert RED in lr._pct.styleSheet()


# ══════════════════════════════════════════════════════════════════════════════
# ChecklistRow
# ══════════════════════════════════════════════════════════════════════════════

def test_checklist_row_pass_status(qapp) -> None:    # noqa: ARG001
    cr = ChecklistRow()
    cr.set_data("pass", "item-key", "BB %B above 0.95", "Strong upside")
    assert cr._icon.text() == "✓"
    assert GREEN in cr._icon.styleSheet()
    assert cr._detail.text() == "BB %B above 0.95"
    assert cr._impl.text() == "Strong upside"


def test_checklist_row_warn_status(qapp) -> None:    # noqa: ARG001
    cr = ChecklistRow()
    cr.set_data("warn", "key", "Volume thin", "Low conviction")
    assert cr._icon.text() == "!"
    assert GOLD in cr._icon.styleSheet()


def test_checklist_row_fail_status(qapp) -> None:    # noqa: ARG001
    cr = ChecklistRow()
    cr.set_data("fail", "key", "Hard gate fired", "Skip")
    assert cr._icon.text() == "✗"
    assert RED in cr._icon.styleSheet()


def test_checklist_row_empty_implication_hides_implication_label(
    qapp,    # noqa: ARG001
) -> None:
    cr = ChecklistRow()
    cr.set_data("pass", "key", "All good", "")
    assert cr._impl.isHidden() or cr._impl.text() == ""


def test_checklist_row_unknown_status_falls_back_to_neutral(
    qapp,    # noqa: ARG001
) -> None:
    cr = ChecklistRow()
    cr.set_data("nonsense", "key", "detail", "implication")
    assert cr._icon.text() == "-"
    assert MUTED in cr._icon.styleSheet()


# ══════════════════════════════════════════════════════════════════════════════
# RiskNote
# ══════════════════════════════════════════════════════════════════════════════

def test_risk_note_constructs(qapp) -> None:    # noqa: ARG001
    rn = RiskNote("SEBI show-cause within 5 days")
    qss = rn.styleSheet()
    # Red accent border encoded as the literal RED hex.
    assert RED in qss
    # The "!" prefix is added in the inner label.
    label = rn.findChild(QLabel)
    assert label is not None
    assert label.text().startswith("!")
    assert "SEBI show-cause within 5 days" in label.text()


# ══════════════════════════════════════════════════════════════════════════════
# RESEARCH badge style (Phase 11 Turn B addition)
# ══════════════════════════════════════════════════════════════════════════════

def test_badge_research_style_resolves_to_violet(qapp) -> None:    # noqa: ARG001
    """RESEARCH badge renders with VIOLET — visually distinct from
    WATCH (blue, "close but not sufficient") and HALF (gold solid,
    "sized down"). Encodes 'emitted for tracking, not for action'."""
    from nimbus_v3.ui.theme import RESEARCH_STYLES, VIOLET
    b = Badge()
    b.set_badge("RESEARCH")
    qss = b.styleSheet()
    assert VIOLET in qss
    assert RESEARCH_STYLES["RESEARCH"]["bg"] in qss


def test_badge_research_alias_keys_all_resolve(qapp) -> None:    # noqa: ARG001
    """Aliases OOS and TRACK point to the same violet triple —
    accommodate operator vocabulary drift."""
    from nimbus_v3.ui.theme import VIOLET
    for key in ("RESEARCH", "OOS", "TRACK"):
        b = Badge()
        b.set_badge(key)
        assert VIOLET in b.styleSheet(), f"{key} should resolve to VIOLET"
