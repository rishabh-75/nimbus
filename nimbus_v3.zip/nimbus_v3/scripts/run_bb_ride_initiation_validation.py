"""Research: does Bollinger Band "ride initiation" predict forward returns?

Hypothesis: when a symbol transitions from a consolidation/squeeze
state into a sustained ride above the upper BB, this transition is
operationally distinguishable from "already riding" or "snapshot-
positioned-above-band" states, and the transition itself carries
forward-return signal at multiple horizons.

Pattern from operator screenshots (MOSCHIP, DATAPATTNS, TATACONSUM,
BEML — late March / April 2026):
  1. Pre-transition: price near or below SMA20, %B oscillating
     mid-band, BBW flat or contracting.
  2. Transition: first close above upper BB in 20 bars, held for
     2+ consecutive bars.
  3. Post-transition: SMA20 slope accelerates upward, BBW expands,
     "ride" is established.

We test three nested definitions:
  A — cross + hold:        loosest. Just the BB cross + 2-bar hold.
  B — A + slope accel:     adds: SMA20 slope now > slope 10 bars ago by ≥ 0.3
  C — B + BBW expansion:   adds: BBW now > BBW 10 bars ago

C is the strictest and matches all four screenshots most closely.
A and B are tested as ablations to see whether the extra criteria
add edge or just narrow samples.

Methodology:
  1. For each symbol bar, compute fired_A/B/C boolean at that bar.
  2. For each fired_X, look back 5 bars: did fired_X fire in the
     last 5 bars including this one? That's the "active signal"
     window — what an operator would see "X just initiated a ride."
  3. For each (definition, fwd_horizon, fold): pool fwd returns
     across (symbol, bar) pairs where active signal is True;
     measure lift vs universe baseline (all bars, fired or not,
     with a non-NaN fwd return).
  4. Walk-forward 4 expanding folds, 10-bar purge.

Ship rules (locked BEFORE seeing data, laddered by horizon):
  fwd_5d:   ≥ 0.5pp lift,  ≥ 75% sign agreement
  fwd_10d:  ≥ 1.0pp lift,  ≥ 75% sign agreement
  fwd_20d:  ≥ 1.5pp lift,  ≥ 75% sign agreement

If the primary (universe-baseline) test passes for any
(definition, horizon), a secondary "hot-stock baseline" is also
reported for that cell — i.e. lift vs. only the bars where some
"in-trend" condition is already met. Tells us if the signal
carries edge ON TOP OF being in a strong setup.

Output: scripts/output/bb_ride_initiation_validation.txt
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

# Make project root importable
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("bb_ride_initiation")


_EQ_CACHE_DIR: Path = _ROOT / "data" / "cache" / "enriched"
_OUT_PATH: Path = _ROOT / "scripts" / "output" / "bb_ride_initiation_validation.txt"


# ══════════════════════════════════════════════════════════════════════
# Constants — all locked before data inspection
# ══════════════════════════════════════════════════════════════════════

#: Look-back for "first cross above upper BB". A symbol must NOT have
#: closed above its upper BB in the prior CROSS_LOOKBACK bars for
#: the current cross to count as a fresh initiation.
CROSS_LOOKBACK: int = 20

#: How many consecutive bars price must stay above the upper BB to
#: count the cross as "held" (filters single-bar pokes that get
#: rejected).
HOLD_BARS: int = 2

#: SMA20 slope acceleration threshold for definitions B and C:
#: current 5-bar SMA20 slope must exceed slope from 10 bars ago by
#: at least this amount (in raw price units per bar). Tuned to the
#: scale of typical NSE midcap moves in the screenshots; equivalent
#: to ~30bp/day acceleration.
SLOPE_ACCEL_LOOKBACK: int = 10
SLOPE_ACCEL_THRESHOLD: float = 0.3

#: BBW expansion lookback for definition C: BBW now must exceed
#: BBW from this many bars ago.
BBW_EXPANSION_LOOKBACK: int = 10

#: Active-signal window. After ride-init fires at bar T, the operator
#: sees the signal as "active" for bars T..T+ACTIVE_WINDOW-1. We
#: measure forward returns from any of those active bars.
#: 5 bars ≈ 1 trading week.
ACTIVE_WINDOW: int = 5

#: Confirmation window for definitions B and C: A must have fired
#: within the last CONFIRM_WINDOW bars (including the current bar)
#: for B/C to fire. Captures the operator's "lagged confirmation"
#: view — they look at the chart now, see a recent cross+hold, and
#: check whether slope/BBW conditions confirm. Same length as
#: ACTIVE_WINDOW; intuitively the operator's "recent" window.
CONFIRM_WINDOW: int = 5

#: Walk-forward folds + purge, matching VIX/CORR research pattern.
N_FOLDS: int = 4
PURGE_BARS: int = 10

#: Ship thresholds laddered by horizon.
SHIP_LIFT_PP: dict[int, float] = {
    5:  0.5,
    10: 1.0,
    20: 1.5,
}

#: Sign agreement bar — uniform across horizons.
SHIP_FOLD_AGREEMENT: float = 0.75

#: Cosmetic.
DIV_WIDE: str = "═" * 78
DIV_THIN: str = "─" * 78


# ══════════════════════════════════════════════════════════════════════
# Data prep — equity-only, cached enrichment
# ══════════════════════════════════════════════════════════════════════

def _prepare_data() -> dict:
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    if not raw_panel:
        raise RuntimeError("Equity panel empty — no cached data available")
    log.info("Equity panel: %d symbols", len(raw_panel))

    log.info("Enriching (cache-first)...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    hits = misses = 0
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
            hits += 1
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
                misses += 1
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched: %d symbols (%d cache hits, %d misses)",
             len(enriched_panel), hits, misses)

    log.info("Attaching forward returns...")
    panel_w_fwd: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        panel_w_fwd[sym] = add_forward_returns(df)

    return {"panel_w_fwd": panel_w_fwd}


# ══════════════════════════════════════════════════════════════════════
# Compute the three ride-init definitions per symbol
# ══════════════════════════════════════════════════════════════════════

#: Required columns for ride-init computation. Listed up front so
#: per-symbol failure can be detected and logged cleanly.
_REQUIRED_COLS: tuple[str, ...] = (
    "Close", "sma_20",
    "bb_20_1s_upper", "bb_20_1s_lower", "bb_20_1s_mid",
    "bbw_20_1s",
)


def _compute_ride_init_signals(df: pd.DataFrame) -> pd.DataFrame:
    """Append `ride_init_a`, `ride_init_b`, `ride_init_c` boolean
    columns to ``df``. Each is True at bar T if the corresponding
    definition fires AT bar T (not in a window).

    The semantics are *operator-perspective*:

      A fires the bar a cross+hold event happens.
      B fires on any bar where (a) A fired in the last 5 bars AND
        (b) the slope acceleration is currently strong.
      C fires on any bar where B fires AND BBW is expanding.

    This means B/C are "lagged confirmations" — they fire some bars
    AFTER A as the trend builds. Matches the operator's view of a
    chart: "this had a fresh cross recently AND the slope/BBW now
    confirm it."
    """
    out = df.copy()
    if not all(c in out.columns for c in _REQUIRED_COLS):
        # Insufficient data — set all signals False
        for col in ("ride_init_a", "ride_init_b", "ride_init_c"):
            out[col] = False
        return out

    close = out["Close"]
    upper = out["bb_20_1s_upper"]
    sma = out["sma_20"]
    bbw = out["bbw_20_1s"]

    # ── Definition A: cross + hold (fires on the cross-confirm day) ──
    above = close > upper
    prior_above_count = (
        above.shift(1)
        .rolling(CROSS_LOOKBACK, min_periods=1)
        .sum()
    )
    fresh_cross = above & (prior_above_count == 0)
    hold_ok = above & above.shift(1)
    # A fires when: today is held AND a fresh cross was yesterday
    cross_recent = fresh_cross.shift(1).fillna(False).astype(bool)
    a_fired = (cross_recent & hold_ok).fillna(False).astype(bool)
    out["ride_init_a"] = a_fired

    # ── Definition B: A fired recently AND slope accel now ──────────
    # "A fired in last CONFIRM_WINDOW bars" — uses _expand_active_window
    # logic inline (rolling sum) since we want this here without
    # a circular import
    a_recent = (
        a_fired.astype(int)
        .rolling(CONFIRM_WINDOW, min_periods=1)
        .sum() > 0
    )
    # 5-bar slope of SMA20 at bar T
    slope_now = (sma - sma.shift(5)) / 5
    # 5-bar slope at bar T - SLOPE_ACCEL_LOOKBACK
    slope_then = slope_now.shift(SLOPE_ACCEL_LOOKBACK)
    slope_accel = slope_now - slope_then
    out["ride_init_b"] = (
        a_recent & (slope_accel >= SLOPE_ACCEL_THRESHOLD)
    ).fillna(False).astype(bool)

    # ── Definition C: B AND BBW expanding now ───────────────────────
    bbw_then = bbw.shift(BBW_EXPANSION_LOOKBACK)
    bbw_expanding = bbw > bbw_then
    out["ride_init_c"] = (out["ride_init_b"] & bbw_expanding).fillna(False).astype(bool)

    return out


def _expand_active_window(signal: pd.Series, window: int) -> pd.Series:
    """A bar is "active" if the ride-init signal fired at that bar
    OR within the prior (window-1) bars. Captures the operator's
    perspective: "I see the ride init flag set, would I act now?"
    """
    rolling_any = (
        signal.astype(int)
        .rolling(window, min_periods=1)
        .sum()
        > 0
    )
    return rolling_any.fillna(False)


# ══════════════════════════════════════════════════════════════════════
# Aggregate forward returns per (definition, horizon, fold)
# ══════════════════════════════════════════════════════════════════════

def _aggregate_lift(
    panel: dict[str, pd.DataFrame],
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
    definition: str,
    horizon: int,
) -> dict:
    """Return aggregate stats for a (definition, horizon) pair within
    the date range. Includes:

      n_active           — bar-symbols where active signal True
      n_baseline         — bar-symbols with valid fwd return (any state)
      mean_active_pp     — mean fwd return on active bars (in pp)
      mean_baseline_pp   — mean fwd return on all bars
      lift_pp            — mean_active − mean_baseline
    """
    fwd_col = f"fwd_ret_{horizon}d"
    sig_col = f"ride_init_{definition.lower()}"
    active_col = f"_active_{definition.lower()}"

    active_returns: list[float] = []
    baseline_returns: list[float] = []

    for sym, df in panel.items():
        if fwd_col not in df.columns or sig_col not in df.columns:
            continue
        # Date-bound the dataframe
        in_range = (df.index >= date_start) & (df.index <= date_end)
        sub = df.loc[in_range]
        if sub.empty:
            continue
        # Compute active mask in this date window (recompute rather
        # than rely on cached, since active depends on lookback into
        # bars potentially before date_start — but using sub's local
        # rolling is fine because we only care about firing within
        # the date range, and the inner active_window is just 5 bars)
        active_mask = _expand_active_window(sub[sig_col], ACTIVE_WINDOW)

        fwd = sub[fwd_col]
        valid = fwd.notna()
        # Active returns: bars where active=True and fwd is valid
        active_vals = fwd[active_mask & valid].values
        active_returns.extend(active_vals.tolist())
        # Baseline: all valid bars in date range, regardless of
        # active state
        baseline_vals = fwd[valid].values
        baseline_returns.extend(baseline_vals.tolist())

    if not active_returns or not baseline_returns:
        return {
            "n_active":         len(active_returns),
            "n_baseline":       len(baseline_returns),
            "mean_active_pp":   0.0,
            "mean_baseline_pp": 0.0,
            "lift_pp":          0.0,
        }

    mean_active = float(np.mean(active_returns)) * 100
    mean_baseline = float(np.mean(baseline_returns)) * 100
    return {
        "n_active":         len(active_returns),
        "n_baseline":       len(baseline_returns),
        "mean_active_pp":   mean_active,
        "mean_baseline_pp": mean_baseline,
        "lift_pp":          mean_active - mean_baseline,
    }


# ══════════════════════════════════════════════════════════════════════
# Walk-forward folds — same construction as VIX / CORR research
# ══════════════════════════════════════════════════════════════════════

def _make_folds(
    dates: pd.DatetimeIndex, n_folds: int,
) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    start = dates.min()
    end = dates.max()
    total = end - start
    chunk = total / (n_folds + 1)
    folds = []
    for i in range(n_folds):
        train_end = start + chunk * (i + 1)
        test_start = train_end + pd.Timedelta(days=PURGE_BARS)
        test_end = start + chunk * (i + 2)
        folds.append((train_end, test_start, test_end))
    return folds


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data...")
    try:
        prepared = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return
    panel_w_fwd = prepared["panel_w_fwd"]

    log.info("Computing ride-init signals per symbol...")
    panel_signaled: dict[str, pd.DataFrame] = {}
    fire_counts = {"a": 0, "b": 0, "c": 0}
    for sym, df in panel_w_fwd.items():
        sig_df = _compute_ride_init_signals(df)
        panel_signaled[sym] = sig_df
        for d in ("a", "b", "c"):
            col = f"ride_init_{d}"
            if col in sig_df.columns:
                fire_counts[d] += int(sig_df[col].sum())

    log.info("Total fires across panel: A=%d, B=%d, C=%d",
             fire_counts["a"], fire_counts["b"], fire_counts["c"])

    # Find the union of valid date ranges
    all_dates = pd.DatetimeIndex([])
    for df in panel_signaled.values():
        all_dates = all_dates.union(df.index)
    valid_dates = all_dates.sort_values()
    folds = _make_folds(valid_dates, N_FOLDS)

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("BB RIDE INITIATION — WALK-FORWARD VALIDATION")
        emit(DIV_WIDE)
        emit("Hypothesis: BB ride initiation is a multi-bar")
        emit("transition pattern (squeeze → cross → hold → slope")
        emit("acceleration → bandwidth expansion) that carries fwd-")
        emit("return signal beyond what a snapshot of 'price above")
        emit("upper BB' captures.")
        emit("")
        emit("Definitions tested:")
        emit("  A — cross + hold (loosest)")
        emit(f"      first close > upper BB in {CROSS_LOOKBACK} bars,")
        emit(f"      held for {HOLD_BARS} consecutive bars")
        emit("  B — A + slope acceleration")
        emit(f"      SMA20 slope now > slope {SLOPE_ACCEL_LOOKBACK} bars")
        emit(f"      ago by ≥ {SLOPE_ACCEL_THRESHOLD}")
        emit("  C — B + BBW expansion")
        emit(f"      BBW now > BBW {BBW_EXPANSION_LOOKBACK} bars ago")
        emit("")
        emit(f"Active-signal window: {ACTIVE_WINDOW} bars after fire")
        emit(f"Walk-forward: expanding-window, {N_FOLDS} folds, "
             f"purged ±{PURGE_BARS} bars")
        emit("")
        emit("Ship rules (laddered by horizon):")
        for h, lift in SHIP_LIFT_PP.items():
            emit(f"  fwd_{h}d: |lift| ≥ {lift}pp AND "
                 f"sign agreement ≥ {SHIP_FOLD_AGREEMENT:.0%}")
        emit("")
        emit(f"Total fires across panel:")
        for d in ("a", "b", "c"):
            emit(f"  Definition {d.upper()}: {fire_counts[d]:,} bar-symbols fired")
        emit("")
        emit("Fold boundaries:")
        for i, (te, ts_s, ts_e) in enumerate(folds):
            emit(f"  Fold {i + 1}: train → {te.date()}, "
                 f"test {ts_s.date()} → {ts_e.date()}")
        emit("")

        # ── Run all definitions × horizons × folds ─────────────
        all_results: dict = {}
        for definition in ("A", "B", "C"):
            for horizon in (5, 10, 20):
                fold_lifts = []
                fold_n_active = []
                for fi, (train_end, test_start, test_end) in enumerate(folds):
                    train_start = valid_dates.min()
                    train_stats = _aggregate_lift(
                        panel_signaled, train_start, train_end,
                        definition, horizon,
                    )
                    test_stats = _aggregate_lift(
                        panel_signaled, test_start, test_end,
                        definition, horizon,
                    )
                    fold_lifts.append({
                        "train": train_stats,
                        "test":  test_stats,
                    })
                    fold_n_active.append(test_stats["n_active"])
                all_results[(definition, horizon)] = fold_lifts

                # Per-(definition, horizon) detail block
                emit(DIV_WIDE)
                emit(f"DEFINITION {definition} × fwd_{horizon}d")
                emit(DIV_WIDE)
                emit(f"  {'FOLD':<5} {'TRAIN_LIFT':>12} {'TRAIN_N':>10} "
                     f"{'TEST_LIFT':>12} {'TEST_N':>10}  SIGN")
                for fi, fl in enumerate(fold_lifts):
                    tr = fl["train"]
                    te = fl["test"]
                    sign = "—"
                    if tr["n_active"] >= 50 and te["n_active"] >= 50:
                        sign = "✓" if (tr["lift_pp"] >= 0) == (te["lift_pp"] >= 0) else "✗"
                    emit(f"  {fi + 1:<5} "
                         f"{tr['lift_pp']:>+11.2f}pp {tr['n_active']:>10d} "
                         f"{te['lift_pp']:>+11.2f}pp {te['n_active']:>10d}  {sign}")

                # Aggregate verdict
                valid_test = [
                    fl["test"] for fl in fold_lifts if fl["test"]["n_active"] >= 50
                ]
                if not valid_test:
                    emit(f"  → No folds with n_active ≥ 50, can't ship")
                    emit("")
                    continue
                lifts = [t["lift_pp"] for t in valid_test]
                mean_lift = float(np.mean(lifts))
                same_sign = sum(
                    1 for li in lifts if (li >= 0) == (mean_lift >= 0)
                )
                agreement = same_sign / len(lifts)
                lift_threshold = SHIP_LIFT_PP[horizon]
                lift_ok = abs(mean_lift) >= lift_threshold
                sign_ok = agreement >= SHIP_FOLD_AGREEMENT
                ship = lift_ok and sign_ok
                emit(f"  Mean test lift: {mean_lift:+.2f}pp  |  "
                     f"Sign agreement: {agreement:.0%}  |  "
                     f"Threshold: ≥{lift_threshold}pp")
                emit(f"  → {'SHIP' if ship else 'NO SHIP'}")
                emit("")

        # ── Final summary ──────────────────────────────────────
        emit(DIV_WIDE)
        emit("FINAL SUMMARY — SHIP/NO-SHIP MATRIX")
        emit(DIV_WIDE)
        emit(f"  {'DEF':<5} | {'HORIZON':<8} | "
             f"{'AGREE':>6} | {'LIFT':>9} | {'THRESH':>7} | SHIP")
        emit(DIV_THIN)
        any_ship = False
        ship_cells = []
        for definition in ("A", "B", "C"):
            for horizon in (5, 10, 20):
                fold_lifts = all_results[(definition, horizon)]
                valid_test = [
                    fl["test"] for fl in fold_lifts
                    if fl["test"]["n_active"] >= 50
                ]
                if not valid_test:
                    emit(f"  {definition:<5} | fwd_{horizon}d   | "
                         f"{'—':>6} | {'—':>9} | "
                         f"{SHIP_LIFT_PP[horizon]:>5.1f}pp | "
                         f"—  (insufficient n)")
                    continue
                lifts = [t["lift_pp"] for t in valid_test]
                mean_lift = float(np.mean(lifts))
                same_sign = sum(
                    1 for li in lifts if (li >= 0) == (mean_lift >= 0)
                )
                agreement = same_sign / len(lifts)
                lift_threshold = SHIP_LIFT_PP[horizon]
                ship = (
                    abs(mean_lift) >= lift_threshold
                    and agreement >= SHIP_FOLD_AGREEMENT
                )
                if ship:
                    any_ship = True
                    ship_cells.append((definition, horizon, mean_lift))
                emit(f"  {definition:<5} | fwd_{horizon}d   | "
                     f"{agreement * 100:>5.0f}% | "
                     f"{mean_lift:>+8.2f}pp | "
                     f"{lift_threshold:>5.1f}pp | "
                     f"{'YES' if ship else '—'}")
        emit("")

        emit(DIV_WIDE)
        if any_ship:
            emit("VERDICT: SHIP candidates exist")
            emit("")
            emit("Validated cells:")
            for d, h, lift in ship_cells:
                emit(f"  - Definition {d} × fwd_{h}d: {lift:+.2f}pp")
            emit("")
            emit("Recommendation: surface as a 'RIDE INIT' tag in")
            emit("Market Pulse constituent table. Tag fires when")
            emit("the validated definition's signal fires within")
            emit(f"the last {ACTIVE_WINDOW} bars.")
            emit("")
            emit("Choice of definition: prefer the strictest")
            emit("definition that ships (C > B > A) — narrowest")
            emit("noise floor, fewest false positives.")
        else:
            emit("VERDICT: DO NOT SHIP")
            emit("")
            emit("No (definition, horizon) cell cleared the laddered")
            emit("ship rule. The BB ride initiation pattern is")
            emit("visually compelling on hand-picked charts but")
            emit("doesn't survive walk-forward validation across")
            emit("the universe.")
            emit("")
            emit("Possible explanations (all probably partly true):")
            emit("  - Survivor bias in screenshot examples")
            emit("  - Pattern's edge is captured by existing")
            emit("    %B / SMA20 slope columns (subsumed)")
            emit("  - 'Active window' approach loses signal vs.")
            emit("    measuring at exact-bar fire")
            emit("  - The directional move resolves before fwd_5d")
            emit("    finishes (operator catches too late)")
            emit("")
            emit("Archive as negative result. Don't add UI element.")
        emit(DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
