"""nimbus_v3.core.context — typed context dataclasses consumed by the
conviction formula and downstream layers.

Every context provider (``context/market_context.py``, ``sector_context.py``,
``options_context.py``, ``filing_context.py``) returns one of these
dataclasses. The scan engine composes them into a ``ContextBundle``
and hands it to strategies and the conviction engine.

All dataclasses are frozen (immutable after construction), which makes
them safe to pass across threads and store in sets. All numeric fields
are native Python floats (not numpy scalars) to avoid subtle dtype bugs
when these values are serialised into golden fixtures.

The fields listed here are the minimum set consumed by the grade-formula
contributions specified in ``docs/GRADE_FORMULA.md``. Extensions land as
the formula grows, backed by research-note justification.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.types import (
    ExpiryRisk,
    FilingImpact,
    GEXRegime,
    RSRegime,
    SectorType,
)


# ══════════════════════════════════════════════════════════════════════════════
# Sector context
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class SectorContext:
    """Per-symbol sector context at an ``asof_date``.

    Carries NSE's four-level industry classification plus relative
    strength and volatility metrics computed at the ``industry`` level
    (industryInfo in NSE's terminology, ~40 groups).

    Classification hierarchy (from ``data/nifty500_industry_db.json``):
        macro_sector   → "Commodities"          (coarsest, ~12)
        sector_name    → "Metals & Mining"       (~20)
        industry       → "Non - Ferrous Metals"  (~40, RS computed here)
        basic_industry → "Zinc"                  (finest, ~120)

    Produced by ``context/sector_context.py::SectorContextProvider``.
    Consumed by ``sector_rs_contribution`` and ``sector_vol_contribution``.
    """
    asof_date: pd.Timestamp
    symbol: str
    sector_name: str
    sector_type: SectorType | None
    rs_regime: RSRegime
    #: Sector index 20-day return minus NIFTY 500 20-day return, in percent.
    rs_20d: float
    #: Sector index annualised realised volatility over the last 20 bars, percent.
    realized_vol_20d: float
    #: Z-score of ``realized_vol_20d`` versus its own 1-year rolling history.
    #: None when insufficient sector history to compute.
    vol_z_score: float | None = None
    #: Four-level NSE classification (populated from industry DB when available).
    macro_sector: str = "Unknown"
    industry: str = "Unknown"
    basic_industry: str = "Unknown"

    def __post_init__(self) -> None:
        if not isinstance(self.asof_date, pd.Timestamp):
            object.__setattr__(self, "asof_date", pd.Timestamp(self.asof_date))


# ══════════════════════════════════════════════════════════════════════════════
# Options context
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class OptionsContext:
    """Option-chain-derived context. Present only for F&O-listed symbols.

    Produced by ``context/options_context.py::OptionsContextProvider``.
    This dataclass is the exposed contract for that provider — its
    implementation lands in a later Phase 2 turn.
    """
    asof_date: pd.Timestamp
    symbol: str
    spot: float
    dte: int
    max_pain: float | None
    support_wall: float | None
    resistance_wall: float | None
    pct_to_support: float | None
    pct_to_resistance: float | None
    net_gex: float | None
    hvl: float | None
    gex_regime: GEXRegime | None
    pcr_oi: float | None
    iv_atm: float | None
    ivr: float | None
    expiry_risk: ExpiryRisk

    def __post_init__(self) -> None:
        if not isinstance(self.asof_date, pd.Timestamp):
            object.__setattr__(self, "asof_date", pd.Timestamp(self.asof_date))


# ══════════════════════════════════════════════════════════════════════════════
# Filing context
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class FilingContext:
    """Corporate-filing-derived context for a symbol at ``asof_date``.

    Produced by ``context/filing_context.py::FilingContextProvider``.
    """
    asof_date: pd.Timestamp
    symbol: str
    latest_impact: FilingImpact
    is_trap: bool
    days_since_latest: int | None
    latest_headline: str | None

    def __post_init__(self) -> None:
        if not isinstance(self.asof_date, pd.Timestamp):
            object.__setattr__(self, "asof_date", pd.Timestamp(self.asof_date))


# ══════════════════════════════════════════════════════════════════════════════
# Bundle
# ══════════════════════════════════════════════════════════════════════════════
# (ContextBundle removed — it aggregated MarketContext + the per-symbol
# contexts for the old strategy/conviction pipeline, which no longer
# exists. The cockpit consumes OptionsContext / SectorContext /
# FilingContext directly.)
