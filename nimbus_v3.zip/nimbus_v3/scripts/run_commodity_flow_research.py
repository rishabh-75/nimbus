"""scripts/run_commodity_flow_research.py — validates commodity flow signals.

The Commodity tab's ``FlowAnalyticsEngine`` computes three-window
z-scores (10/30/60d) and derives stage labels (early / mid / mature /
extended) from them. These were originally introduced with intuitive
thresholds but never validated against forward returns.

This script asks: do the signals actually predict commodity forward
returns, or are they cosmetic? Four ablation passes:

1. **Decile reports** — per-window z-score vs forward return. A
   feature with edge shows monotonic progression from bottom-decile
   fwd return to top-decile fwd return.

2. **Signature ablation** — test specific patterns:
   * ``z10 > +2``    : fresh bullish impulse (early-stage hot)
   * ``z60 > +2``    : mature bullish trend
   * ``extended``    : all three windows hot (stage label)
   * ``z10 < -2``    : fresh bearish impulse

3. **Stage ablation** — for each stage label, report mean forward
   return. Does 'early' predict better forward returns than 'mature'
   or '—'?

4. **Category aggregate → member prediction** — when a category's
   mean z is hot, do individual members still have edge? Or is the
   aggregate signal already priced in at the member level?

Horizons tested: fwd_5d, fwd_20d. Commodities trend on different
timescales than equities so we test short (5d) and medium (20d).

Decision criteria (stricter than equity research — commodity panel
is smaller, ~23 instruments × years, so we need larger effect sizes
to be confident):

  - n_fired   >= 200
  - |Δ pp|    >= 1.0  (commodities are more volatile than equities;
                       the noise floor is higher)
  - |t_stat|  >= 2.5

Run::

    python scripts/run_commodity_flow_research.py

Writes:
  - data/commodity_flow_research.csv
  - stdout report
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Use the same panel loader the UI uses — keeps this script's data
# path identical to what the live app sees.
from scripts._composition import build_macro_panel_loader       # noqa: E402

from nimbus_v3.macro.flow_detector import (                     # noqa: E402
    PRICE_Z_WINDOWS, MacroFlowResult, _window_z,
)
from nimbus_v3.macro.universe import (                          # noqa: E402
    COMMODITY_UNIVERSE, CommodityCategory,
)
from nimbus_v3.compute.flow_analytics import FlowAnalyticsEngine    # noqa: E402

logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("commodity_flow_research")


# ══════════════════════════════════════════════════════════════════════
# Configuration
# ══════════════════════════════════════════════════════════════════════

#: Horizons (trading days) for forward returns. 5d + 20d keeps the
#: test small and reflects the two holding windows an operator using
#: the commodity tab would actually consider.
HORIZONS = (5, 20)

#: Minimum bars required per instrument. Needs 60 for longest z-score
#: window + 252 for the z-score's history reference + 20 for fwd_20d.
MIN_BARS_PER_INSTRUMENT = 60 + 252 + 20


# ══════════════════════════════════════════════════════════════════════
# Stats helpers (same style as run_volume_feature_research.py)
# ══════════════════════════════════════════════════════════════════════

def welch_t(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(va / na + vb / nb)
    if denom == 0 or not np.isfinite(denom):
        return float("nan")
    return float((a.mean() - b.mean()) / denom)


def ablate_signature(
    feats: pd.DataFrame, mask: np.ndarray,
    fwd_col: str, name: str,
) -> dict:
    fwd = feats[fwd_col].to_numpy()
    valid = np.isfinite(fwd)
    fired = valid & mask
    unfired = valid & ~mask
    f_ret = fwd[fired]
    u_ret = fwd[unfired]
    return {
        "signature": name,
        "horizon": fwd_col,
        "n_fired": int(fired.sum()),
        "n_unfired": int(unfired.sum()),
        "fired_pct": float(f_ret.mean() * 100) if len(f_ret) else float("nan"),
        "unfired_pct": float(u_ret.mean() * 100) if len(u_ret) else float("nan"),
        "delta_pp": (
            float((f_ret.mean() - u_ret.mean()) * 100)
            if len(f_ret) and len(u_ret) else float("nan")
        ),
        "t_stat": welch_t(f_ret, u_ret),
    }


def decile_report(
    feats: pd.DataFrame, feature: str, horizon: str,
) -> pd.DataFrame:
    valid = feats[
        np.isfinite(feats[feature]) & np.isfinite(feats[horizon])
    ]
    if len(valid) < 500:
        return pd.DataFrame()
    deciles = pd.qcut(valid[feature], 10, labels=False, duplicates="drop")
    grouped = (
        valid.assign(decile=deciles)
             .groupby("decile", observed=True)
             .agg(n=(horizon, "size"),
                  mean_fwd=(horizon, "mean"),
                  feature_min=(feature, "min"),
                  feature_max=(feature, "max"))
    )
    grouped["mean_fwd_pct"] = grouped["mean_fwd"] * 100
    return grouped


# ══════════════════════════════════════════════════════════════════════
# Feature table build — mirrors compute_features / compute_beta_features
# but for commodities. Builds per-(ticker, bar) rows with z-scores +
# forward returns.
# ══════════════════════════════════════════════════════════════════════

def build_commodity_feature_table(
    panel: dict[str, pd.DataFrame],
) -> pd.DataFrame:
    """For each (ticker, bar), compute the three-window z-scores plus
    forward returns. Output shape is one row per (ticker, bar-date),
    ready for panel-wide ablation.

    We compute z-scores INLINE here rather than calling the live
    ``FlowAnalyticsEngine`` because the engine returns a single
    "latest bar" snapshot per ticker, whereas this research needs
    historical z-scores at every bar for proper forward-return
    measurement (no look-ahead bias).
    """
    rows: list[pd.DataFrame] = []
    universe_by_ticker = {
        instr.ticker: instr for instr in COMMODITY_UNIVERSE
    }
    for ticker, df in panel.items():
        instr = universe_by_ticker.get(ticker)
        if instr is None:
            # Ticker not in the canonical universe — skip. This
            # happens if the panel has extra symbols from manual
            # testing; we only research what's in the shipped universe.
            continue
        if len(df) < MIN_BARS_PER_INSTRUMENT:
            continue
        if "Close" not in df.columns:
            continue

        work = df.copy()
        if work.index.tz is not None:
            work.index = work.index.tz_localize(None)
        work = work.sort_index()
        closes = work["Close"].astype(float)

        with np.errstate(invalid="ignore", divide="ignore"):
            rets = np.log(closes / closes.shift(1))

        # z-scores at every bar. Use a rolling window over history.
        # We can't just call _window_z once — we need it at every bar.
        # Vectorize: for each window, compute rolling cumulative log
        # return, then rolling mean / std of those cumulative values
        # over the trailing 252-bar history.
        ticker_feats = pd.DataFrame(index=closes.index)
        ticker_feats["ticker"] = ticker
        ticker_feats["category"] = instr.category.value
        ticker_feats["close"] = closes

        for window in PRICE_Z_WINDOWS:
            # Cumulative log return over the window
            cum_w = rets.rolling(window).sum()
            # Mean + std of cum_w over the trailing 252 bars (shifted
            # by 1 to exclude the current point from its own baseline)
            hist_mean = cum_w.shift(1).rolling(252, min_periods=30).mean()
            hist_std = cum_w.shift(1).rolling(252, min_periods=30).std(ddof=1)
            z = (cum_w - hist_mean) / hist_std
            ticker_feats[f"z_{window}d"] = z

        # Forward returns
        for h in HORIZONS:
            ticker_feats[f"fwd_{h}d"] = closes.shift(-h) / closes - 1

        # Stage label at each bar — derived from the three z-scores.
        # Use the same rules as MacroFlowResult.stage_label.
        z10 = ticker_feats["z_10d"]
        z30 = ticker_feats["z_30d"]
        z60 = ticker_feats["z_60d"]
        a10, a30, a60 = z10.abs(), z30.abs(), z60.abs()
        stage = pd.Series("—", index=ticker_feats.index, dtype=object)
        stage[(a10 >= 1.5) & (a30 >= 1.5) & (a60 >= 1.5)] = "extended"
        stage[(a60 >= 1.5) & (a10 < 1.0) & (stage == "—")] = "mature"
        stage[(a10 >= 1.0) & (a30 < 1.0) & (a60 < 0.8) & (stage == "—")] = "early"
        stage[(a30 >= 1.0) & (a10 < 1.0) & (a60 < 1.3) & (stage == "—")] = "mid"
        ticker_feats["stage"] = stage

        rows.append(ticker_feats)

    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=False)


# ══════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════

def verdict(row: dict) -> str:
    n = row["n_fired"]
    d = row["delta_pp"]
    t = row["t_stat"]
    if n < 200:
        return "too few fires"
    if np.isnan(d) or np.isnan(t):
        return "n/a"
    # Positive-direction signals (z>+2, 'extended' when bullish, etc):
    # "working" means delta_pp >= +1.0 AND t >= +2.5
    # Negative-direction signals (z<-2): "working" means delta_pp <= -1.0
    # AND t <= -2.5
    # We infer direction from the signature name: signatures with '<'
    # or 'bear' treat negative deltas as working.
    sig_name = row["signature"]
    is_bearish = "<" in sig_name or "bear" in sig_name.lower()
    if is_bearish:
        if d <= -1.0 and t <= -2.5:
            return "STRONG working"
        if d <= -0.5 and t <= -2.0:
            return "weak working"
        if d >= +1.0 and t >= +2.5:
            return "STRONG HARMFUL (fired cohort outperforms)"
    else:
        if d >= +1.0 and t >= +2.5:
            return "STRONG working"
        if d >= +0.5 and t >= +2.0:
            return "weak working"
        if d <= -1.0 and t <= -2.5:
            return "STRONG HARMFUL (fired cohort underperforms)"
    if abs(d) < 0.5 or abs(t) < 1.5:
        return "noise"
    return "inconclusive"


def print_signature_table(rows: list[dict]) -> None:
    hdr = (
        f"  {'signature':24s}  {'horizon':8s}  {'n_fire':>7s}  "
        f"{'n_keep':>7s}  {'fired%':>8s}  {'kept%':>8s}  "
        f"{'Δ pp':>8s}  {'t':>7s}  verdict"
    )
    sep = "─" * len(hdr)
    print(sep)
    print(hdr)
    print(sep)
    for r in rows:
        v = verdict(r)
        print(
            f"  {r['signature']:24s}  {r['horizon']:8s}  "
            f"{r['n_fired']:>7,d}  {r['n_unfired']:>7,d}  "
            f"{r['fired_pct']:>+7.3f}  {r['unfired_pct']:>+7.3f}  "
            f"{r['delta_pp']:>+7.3f}  {r['t_stat']:>+6.2f}  {v}"
        )
    print(sep)


def print_decile_table(
    grouped: pd.DataFrame, feature: str, horizon: str,
) -> None:
    print(f"\nDecile report: {feature} vs {horizon}")
    print("─" * 62)
    print(f"  {'decile':>6s}  {'n':>6s}  {'feature range':>22s}  {'fwd%':>8s}")
    for decile, row in grouped.iterrows():
        rng = f"{row['feature_min']:+7.2f} to {row['feature_max']:+7.2f}"
        print(
            f"  {decile:>6}  {int(row['n']):>6,d}  {rng:>22s}  "
            f"{row['mean_fwd_pct']:>+7.3f}"
        )
    spread = grouped.iloc[-1]["mean_fwd_pct"] - grouped.iloc[0]["mean_fwd_pct"]
    print(f"  Spread (top decile − bottom decile): {spread:+.3f}pp")
    print("─" * 62)


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Building commodity panel loader …")
    loader = build_macro_panel_loader()
    if loader is None:
        log.error("Loader build failed — can't proceed")
        sys.exit(1)

    log.info("Loading commodity panel …")
    panel = loader()
    log.info("Panel: %d tickers", len(panel))

    if not panel:
        log.error("Empty panel — can't proceed. Check data/cache/commodity_price/")
        sys.exit(1)

    log.info("Building feature table …")
    feats = build_commodity_feature_table(panel)
    if feats.empty:
        log.error(
            "Empty feature table. Every ticker had < %d bars of "
            "history. Commodity cache may be thin.",
            MIN_BARS_PER_INSTRUMENT,
        )
        sys.exit(1)
    log.info(
        "Feature table: %d rows × %d cols, %d tickers",
        len(feats), len(feats.columns), feats["ticker"].nunique(),
    )

    # ────────────────────────────────────────────────────────────────
    # 1. Decile reports — do z-scores separate forward returns?
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("DECILE REPORTS — do z-scores separate forward returns?")
    print("═" * 72)
    print("A feature with real information shows a monotonic progression")
    print("from bottom-decile fwd return to top-decile fwd return.")
    for feature in ("z_10d", "z_30d", "z_60d"):
        for horizon in (f"fwd_{h}d" for h in HORIZONS):
            grouped = decile_report(feats, feature, horizon)
            if len(grouped):
                print_decile_table(grouped, feature, horizon)

    # ────────────────────────────────────────────────────────────────
    # 2. Signature ablation — specific patterns
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("SIGNATURE ABLATION — specific patterns")
    print("═" * 72)

    z10 = feats["z_10d"].to_numpy()
    z30 = feats["z_30d"].to_numpy()
    z60 = feats["z_60d"].to_numpy()
    stages = feats["stage"].to_numpy()

    signature_tests = [
        ("z10 > +2",        (z10 > 2.0)),
        ("z30 > +2",        (z30 > 2.0)),
        ("z60 > +2",        (z60 > 2.0)),
        ("z10 < -2",        (z10 < -2.0)),
        ("z60 < -2",        (z60 < -2.0)),
        ("extended (stage)", (stages == "extended")),
        ("mature (stage)",   (stages == "mature")),
        ("early (stage)",    (stages == "early")),
        ("mid (stage)",      (stages == "mid")),
    ]
    sig_rows: list[dict] = []
    for name, mask in signature_tests:
        mask = np.asarray(mask, dtype=bool)
        for horizon in (f"fwd_{h}d" for h in HORIZONS):
            sig_rows.append(ablate_signature(feats, mask, horizon, name))
    print_signature_table(sig_rows)

    # ────────────────────────────────────────────────────────────────
    # 3. Stage ablation — mean forward return by stage label
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("STAGE MEAN RETURNS — does the label segment forward returns?")
    print("═" * 72)
    print("If early/mid/mature/extended labels genuinely carry edge, the")
    print("mean forward returns across stages should differ materially.")
    print()
    for horizon in (f"fwd_{h}d" for h in HORIZONS):
        print(f"Horizon: {horizon}")
        print("─" * 52)
        print(f"  {'stage':>10s}  {'n':>8s}  {'mean_fwd%':>10s}  {'std%':>8s}")
        for stage in ("early", "mid", "mature", "extended", "—"):
            sub = feats[feats["stage"] == stage]
            fwd = sub[horizon].dropna()
            if len(fwd):
                print(
                    f"  {stage:>10s}  {len(fwd):>8,d}  "
                    f"{fwd.mean()*100:>+9.3f}  {fwd.std()*100:>+7.3f}"
                )
        print()

    # ────────────────────────────────────────────────────────────────
    # 4. Category aggregate → member prediction
    # ────────────────────────────────────────────────────────────────
    print("\n" + "═" * 72)
    print("CATEGORY AGGREGATE — does category hotness predict members?")
    print("═" * 72)
    print("At each bar, compute the category's mean z across its members.")
    print("Then for each instrument in the category, ablate by whether")
    print("its category aggregate was hot (>+0.5) or cold (<-0.5).")
    print()

    # Build per-bar category aggregates
    feats = feats.copy()
    feats["_avg_z"] = (
        feats[["z_10d", "z_30d", "z_60d"]].mean(axis=1, skipna=True)
    )
    # Group by date + category to get the category aggregate
    cat_agg = (
        feats.groupby([feats.index, "category"])["_avg_z"]
             .mean()
             .reset_index()
             .rename(columns={"_avg_z": "cat_agg_z"})
    )
    # Merge back onto feats
    cat_agg.columns = ["bar_date_idx", "category", "cat_agg_z"]
    feats["_bar_date_idx"] = feats.index
    feats = feats.merge(
        cat_agg, left_on=["_bar_date_idx", "category"],
        right_on=["bar_date_idx", "category"], how="left",
    )
    feats = feats.drop(columns=["bar_date_idx"])

    cat_agg_tests = [
        ("cat_agg > +0.5 (hot)",  feats["cat_agg_z"].to_numpy() > 0.5),
        ("cat_agg < -0.5 (cold)", feats["cat_agg_z"].to_numpy() < -0.5),
    ]
    cat_rows: list[dict] = []
    for name, mask in cat_agg_tests:
        mask = np.asarray(mask, dtype=bool)
        for horizon in (f"fwd_{h}d" for h in HORIZONS):
            cat_rows.append(ablate_signature(feats, mask, horizon, name))
    print_signature_table(cat_rows)

    # ────────────────────────────────────────────────────────────────
    # Persist + summary
    # ────────────────────────────────────────────────────────────────
    all_rows = sig_rows + cat_rows
    out_path = Path("data/commodity_flow_research.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(all_rows).to_csv(out_path, index=False)
    log.info("\nFull results written to %s", out_path)

    print("\n" + "═" * 72)
    print("SUMMARY")
    print("═" * 72)
    working = [r for r in all_rows if verdict(r).endswith("working")]
    if not working:
        print("No signature earned production-quality edge on the commodity")
        print("panel. Interpretation: the existing z-score / stage labels")
        print("are descriptive (they tell you WHERE a commodity is in its")
        print("move) but may not predict forward returns at the thresholds")
        print("tested. This doesn't mean the tab is useless — it means the")
        print("current signals are context indicators, not trading triggers.")
        print()
        print("Next-step candidates if we want predictive commodity signals:")
        print("  - Different thresholds (z>1, z>1.5 instead of z>2)")
        print("  - Cross-window patterns (z10 cooling + z30 hot, etc.)")
        print("  - Term-structure carry (requires front vs deferred prices)")
    else:
        print(f"{len(working)} signature × horizon pair(s) earned edge:")
        for r in working:
            print(f"  • {r['signature']} @ {r['horizon']}: "
                  f"Δ {r['delta_pp']:+.2f}pp  t={r['t_stat']:+.2f}  ({verdict(r)})")


if __name__ == "__main__":
    main()
