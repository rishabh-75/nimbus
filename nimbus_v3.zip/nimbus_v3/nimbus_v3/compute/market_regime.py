"""nimbus_v3.compute.market_regime — broad-market regime detection.

Derived summary statistics over a population of
``IndustryRelativeState``. Used as a defensive guard around the
alpha / beta tag system: in regimes where a supermajority of
industries are in DECLINE, the alpha signal empirically loses its
forward-return edge and tags should render with reduced visual
confidence.

Source of the guard: the walk-forward validation
(``scripts/run_alpha_walk_forward.py``) showed 2025-H1 at -2.77pp
forward-20d delta with t=-7.66 — a genuine signal failure during
broad NSE correction. A guard triggered off DECLINE-phase breadth
is the cheapest defensive intervention for that regime.

Design principles mirror ``IndustryState`` / ``IndustryRelativeState``:
frozen dataclass, no behaviour, pure functions operate on them.

Thresholds
──────────
:data:`BROAD_DECLINE_THRESHOLD` is a heuristic. In the 2025-H1
walk-forward failure, eyeballing the NSE sector roll — a
supermajority of industries were in DECLINE. 0.60 catches that
regime without being so permissive it triggers on routine
sector rotation.

The threshold is tunable but not critical to tune. The value of
this guard is its presence (a defensive UX cue), not the precision
of its cutoff. Any value in the 0.50-0.70 range catches the same
regime episodes in-sample.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

from nimbus_v3.core.industry_relative_state import IndustryRelativeState


#: Fraction of industries in DECLINE above which the broad-decline
#: guard fires. Heuristic — see module docstring.
BROAD_DECLINE_THRESHOLD: Final[float] = 0.60


@dataclass(frozen=True)
class MarketRegime:
    """Summary of broad-market state at a single evaluation.

    Derived from a population of ``IndustryRelativeState``. Not
    per-symbol and not per-industry — this is a market-wide summary
    consumed by UI code to apply defensive rendering.
    """

    #: ``True`` when ``pct_declining >= BROAD_DECLINE_THRESHOLD`` AND
    #: we have enough industries for the reading to be meaningful.
    #: Used by UI code as the single flag: mute tags / show banner.
    is_broad_decline: bool

    #: Fraction (0.0-1.0) of industries in DECLINE phase at this
    #: evaluation. Displayed so operators can see *how* broad the
    #: decline is, not just that one exists.
    pct_declining: float

    #: Count of industries considered — sanity / statistical honesty
    #: field. When small (e.g. only 3 industries cached) the regime
    #: read is weak and ``is_broad_decline`` is suppressed regardless
    #: of percentage.
    n_industries: int


#: Minimum industry count before ``is_broad_decline`` can fire.
#: Below this, the sample is too small for broad-market inference
#: even if technically 100% of measured industries are in DECLINE.
_MIN_INDUSTRIES_FOR_REGIME: Final[int] = 10


def evaluate_market_regime(
    states: dict[str, IndustryRelativeState],
) -> MarketRegime:
    """Summarise broad-market state from a batched analytics pass.

    Args:
        states: output of ``IndustryAnalyticsEngine.batch_analyze`` —
            ``{symbol: IndustryRelativeState}``. Deduplicates industries
            internally (one stock's ``industry_phase`` equals every
            other stock-in-industry's, so a set of unique
            ``(industry, phase)`` pairs is what's counted).

    Returns:
        ``MarketRegime`` with the decline-breadth summary. Safe to
        call on empty or small-sample inputs — returns a MarketRegime
        with ``is_broad_decline=False`` and the measured counts.
    """
    if not states:
        return MarketRegime(
            is_broad_decline=False,
            pct_declining=0.0,
            n_industries=0,
        )

    # Dedupe to unique industries. Every member of an industry
    # carries the same industry_phase, so just take the set.
    industry_phase: dict[str, str] = {}
    for state in states.values():
        industry_phase[state.industry] = state.industry_phase

    n = len(industry_phase)
    if n == 0:
        return MarketRegime(
            is_broad_decline=False, pct_declining=0.0, n_industries=0,
        )

    n_decline = sum(1 for phase in industry_phase.values() if phase == "DECLINE")
    pct = n_decline / n

    # Suppress the flag when the sample is tiny — a broad-market
    # claim on 3 industries isn't a broad-market claim.
    triggered = (
        pct >= BROAD_DECLINE_THRESHOLD
        and n >= _MIN_INDUSTRIES_FOR_REGIME
    )
    return MarketRegime(
        is_broad_decline=triggered,
        pct_declining=pct,
        n_industries=n,
    )
