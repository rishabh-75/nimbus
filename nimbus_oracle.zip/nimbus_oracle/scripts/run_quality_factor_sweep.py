#!/usr/bin/env python3
"""
scripts/run_quality_factor_sweep.py — Investigate D-grade inversion.

D-grade trades (lowest quality) outperform B/C+ grades by 8pp.
This script finds which quality factors are predictive vs noise.

Tests:
  1. Each factor independently: does higher WR depth → higher win rate?
  2. Factor combinations: which pairs compound, which cancel?
  3. Factor contribution: remove one factor at a time, measure correlation change
  4. Inversion analysis: what do D-grade winners look like?

Usage:
    python3 scripts/run_quality_factor_sweep.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("factor_sweep")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="quality_factor_report.txt")
    args = parser.parse_args()

    if not os.path.exists(args.trades):
        for alt in ["/mnt/user-data/uploads/wf_oos_trades.csv"]:
            if os.path.exists(alt): args.trades = alt; break

    trades_df = pd.read_csv(args.trades)
    trades_df["entry_date"] = pd.to_datetime(trades_df["entry_date"])
    trades_df["win"] = trades_df["pnl_pct"] > 0
    logger.info("Loaded %d OOS trades", len(trades_df))

    # ── Reconstruct features ────────────────────────────────────────────
    logger.info("Reconstructing entry features...")
    from modules.dual_mode import compute_dual_mode

    price_cache = {}
    cache_dir = "data/backtest_cache"
    for sym in trades_df["symbol"].unique():
        f = os.path.join(cache_dir, f"{sym}_1d.parquet")
        if os.path.exists(f):
            try:
                df = pd.read_parquet(f)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_cache[sym] = df
            except Exception:
                pass

    # Fetch VIX
    import yfinance as yf
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    vix_df = yf.download("^INDIAVIX", start=start.strftime("%Y-%m-%d"),
                         end=end.strftime("%Y-%m-%d"), progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    rows = []
    skipped = 0
    for _, trade in trades_df.iterrows():
        sym = trade["symbol"]
        entry_date = trade["entry_date"]
        if sym not in price_cache:
            skipped += 1; continue
        pdf = price_cache[sym]
        mask = pdf.index <= entry_date
        if mask.sum() < 40:
            skipped += 1; continue
        try:
            sig = compute_dual_mode(pdf.loc[mask], symbol=sym)
            if not sig.data_sufficient:
                skipped += 1; continue
            vmask = vix_series.index <= entry_date
            vix = float(vix_series[vmask].iloc[-1]) if vmask.any() else 15.0
            if vix > 22: vr = "PANIC"
            elif vix >= 18: vr = "ELEVATED"
            elif vix >= 13: vr = "NORMAL"
            else: vr = "LOW"

            rows.append({
                "pnl_pct": trade["pnl_pct"],
                "win": 1 if trade["pnl_pct"] > 0 else 0,
                "tier": trade["tier"],
                "vix": vix, "vix_regime": vr,
                "score": sig.dual_score,
                "wr": sig.wr_30,
                "mfi": sig.mfi, "mfi_slope": sig.mfi_slope,
                "dd": sig.dd_from_high,
                "streak": sig.red_streak,
                "vol_ratio": sig.vol_ratio,
                "bbw_pctl": sig.bbw_pctl,
                "bbw_slope": sig.bbw_slope,
                "pct_sma": sig.pct_from_sma,
                "rsi": sig.rsi,
            })
        except Exception:
            skipped += 1
        if (len(rows) + skipped) % 500 == 0:
            logger.info("  %d/%d", len(rows), len(trades_df))

    df = pd.DataFrame(rows)
    logger.info("Features: %d trades (%d skipped)", len(df), skipped)

    report = []
    report.append("=" * 70)
    report.append("QUALITY FACTOR INVESTIGATION — D-GRADE INVERSION")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(df)}")
    report.append("=" * 70)

    # ── TEST 1: Each factor's correlation with PnL ──────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 1: INDIVIDUAL FACTOR → PnL CORRELATION")
    report.append("=" * 70)
    report.append("  Positive = factor predicts higher returns")
    report.append("  Negative = factor INVERTS (higher value → worse returns)")
    report.append("")

    factors = [
        ("score", "Score (0-100)"),
        ("wr", "WR(30) — more negative = more oversold"),
        ("mfi", "MFI — money flow strength"),
        ("mfi_slope", "MFI slope — flow direction"),
        ("dd", "DD% — drawdown (more negative = deeper)"),
        ("streak", "Red streak — consecutive down days"),
        ("vol_ratio", "Volume ratio — vs 20d average"),
        ("bbw_pctl", "BBW percentile — band width"),
        ("pct_sma", "% from SMA — pullback depth"),
        ("vix", "India VIX"),
        ("rsi", "RSI(14)"),
    ]

    for col, desc in factors:
        if col not in df.columns:
            continue
        vals = df[col].dropna()
        if len(vals) < 100:
            continue
        corr = np.corrcoef(vals, df.loc[vals.index, "pnl_pct"])[0, 1]
        # Also point-biserial with win/loss
        corr_win = np.corrcoef(vals, df.loc[vals.index, "win"])[0, 1]
        marker = "✓" if abs(corr) > 0.03 else "○"
        direction = "↑ GOOD" if corr > 0.03 else ("↓ INVERTS" if corr < -0.03 else "~ FLAT")
        report.append(f"  {marker} {col:12s}  r={corr:+.4f}  r(win)={corr_win:+.4f}  {direction}  {desc}")

    # ── TEST 2: Factor bins → win rate ──────────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 2: FACTOR BINS → WIN RATE")
    report.append("=" * 70)

    bin_tests = [
        ("score", [(0, 50, "<50"), (50, 60, "50-60"), (60, 70, "60-70"), (70, 80, "70-80"), (80, 101, "80+")]),
        ("wr", [(-100, -70, "<-70"), (-70, -50, "-70:-50"), (-50, -30, "-50:-30"), (-30, 0, ">-30")]),
        ("mfi", [(0, 30, "<30"), (30, 40, "30-40"), (40, 50, "40-50"), (50, 60, "50-60"), (60, 100, "60+")]),
        ("dd", [(-100, -15, "<-15%"), (-15, -10, "-15:-10"), (-10, -5, "-10:-5"), (-5, 0, ">-5%")]),
        ("streak", [(0, 1, "0d"), (1, 2, "1d"), (2, 3, "2d"), (3, 4, "3d"), (4, 99, "4d+")]),
        ("vol_ratio", [(0, 0.5, "<0.5"), (0.5, 1.0, "0.5-1"), (1.0, 1.5, "1-1.5"), (1.5, 99, "1.5+")]),
        ("bbw_pctl", [(0, 25, "<25"), (25, 50, "25-50"), (50, 75, "50-75"), (75, 101, "75+")]),
    ]

    for col, bins in bin_tests:
        report.append(f"\n  {col}:")
        for lo, hi, label in bins:
            mask = (df[col] >= lo) & (df[col] < hi)
            n = mask.sum()
            if n < 20:
                continue
            wr = df.loc[mask, "win"].mean() * 100
            avg = df.loc[mask, "pnl_pct"].mean()
            report.append(f"    {label:10s}: N={n:4d}  win={wr:.1f}%  avg={avg:+.3f}%")

    # ── TEST 3: Leave-one-out factor contribution ───────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 3: LEAVE-ONE-OUT — removing each factor from grade")
    report.append("=" * 70)
    report.append("  If removing a factor IMPROVES correlation → that factor is noise")
    report.append("")

    def compute_pts(row, skip_factor=None):
        pts = 0
        if skip_factor != "score":
            sc = row["score"]
            if sc >= 80: pts += 4
            elif sc >= 70: pts += 3
            elif sc >= 60: pts += 2
            elif sc >= 50: pts += 1
        if skip_factor != "wr":
            w = row["wr"]
            if w < -70: pts += 3
            elif w < -50: pts += 2
            elif w < -30: pts += 1
        if skip_factor != "mfi":
            m = row["mfi"]
            ms = row.get("mfi_slope", 0)
            if m >= 55 and ms > 3: pts += 2
            elif m >= 45: pts += 1
        if skip_factor != "cap":
            d = row["dd"]
            s = row["streak"]
            if d < -10 and s >= 3: pts += 2
            elif d < -5 or s >= 3: pts += 1
        if skip_factor != "bbw":
            if row["bbw_pctl"] < 25: pts += 1
        if skip_factor != "vol":
            if row["vol_ratio"] >= 1.5: pts += 1
        if skip_factor != "tier":
            if row["tier"] == "PRIMARY": pts += 1
        # Always add VIX (flat)
        vr = row["vix_regime"]
        if vr == "PANIC": pts += 4
        elif vr == "ELEVATED": pts += 3
        elif vr == "LOW": pts += 2
        return pts

    # Baseline with all factors
    df["pts_all"] = df.apply(lambda r: compute_pts(r), axis=1)
    base_corr = np.corrcoef(df["pts_all"], df["pnl_pct"])[0, 1]
    report.append(f"  Baseline (all factors): r={base_corr:+.4f}")
    report.append("")

    for factor in ["score", "wr", "mfi", "cap", "bbw", "vol", "tier"]:
        col_name = f"pts_no_{factor}"
        df[col_name] = df.apply(lambda r, f=factor: compute_pts(r, skip_factor=f), axis=1)
        corr = np.corrcoef(df[col_name], df["pnl_pct"])[0, 1]
        delta = corr - base_corr
        marker = "✗ NOISE" if delta > 0.002 else ("✓ HELPS" if delta < -0.002 else "~ FLAT")
        report.append(f"  Without {factor:5s}: r={corr:+.4f}  Δ={delta:+.4f}  {marker}")

    # ── TEST 4: What do D-grade winners look like? ──────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 4: D-GRADE ANATOMY — what makes them win?")
    report.append("=" * 70)

    # Compute grades
    def to_grade(pts):
        if pts >= 14: return "A+"
        if pts >= 12: return "A"
        if pts >= 10: return "B+"
        if pts >= 8: return "B"
        if pts >= 6: return "C+"
        if pts >= 4: return "C"
        return "D"

    df["grade"] = df["pts_all"].apply(to_grade)

    d_trades = df[df["grade"] == "D"]
    b_trades = df[df["grade"] == "B"]

    report.append(f"\n  D-grade: N={len(d_trades)}, win={d_trades['win'].mean()*100:.1f}%")
    report.append(f"  B-grade: N={len(b_trades)}, win={b_trades['win'].mean()*100:.1f}%")
    report.append("")

    # Profile comparison
    for col, label in [("score", "Score"), ("wr", "WR"), ("mfi", "MFI"), ("dd", "DD%"),
                        ("streak", "Streak"), ("vol_ratio", "Vol"), ("bbw_pctl", "BBW pctl"),
                        ("vix", "VIX"), ("pct_sma", "% SMA")]:
        d_avg = d_trades[col].mean()
        b_avg = b_trades[col].mean()
        report.append(f"  {label:10s}: D avg={d_avg:+7.1f}  B avg={b_avg:+7.1f}  diff={d_avg-b_avg:+7.1f}")

    # VIX regime distribution within D vs B
    report.append(f"\n  VIX regime distribution:")
    for vr in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
        d_pct = (d_trades["vix_regime"] == vr).mean() * 100
        b_pct = (b_trades["vix_regime"] == vr).mean() * 100
        report.append(f"    {vr:10s}: D={d_pct:.0f}%  B={b_pct:.0f}%")

    # ── TEST 5: Non-linear score effect ────────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 5: SCORE BAND → PnL (is the score formula itself inverted?)")
    report.append("=" * 70)

    for lo, hi, label in [(0, 40, "0-40"), (40, 50, "40-50"), (50, 60, "50-60"),
                           (60, 70, "60-70"), (70, 80, "70-80"), (80, 101, "80+")]:
        mask = (df["score"] >= lo) & (df["score"] < hi)
        n = mask.sum()
        if n < 20: continue
        wr = df.loc[mask, "win"].mean() * 100
        avg = df.loc[mask, "pnl_pct"].mean()
        report.append(f"  Score {label:5s}: N={n:4d}  win={wr:.1f}%  avg={avg:+.3f}%")

    # ── TEST 6: WR depth × MFI interaction ─────────────────────────────
    report.append("\n" + "=" * 70)
    report.append("TEST 6: WR × MFI INTERACTION (2D grid)")
    report.append("=" * 70)

    wr_bins = [(-100, -70, "WR<-70"), (-70, -50, "WR -70:-50"), (-50, -30, "WR -50:-30")]
    mfi_bins = [(0, 30, "MFI<30"), (30, 45, "MFI 30-45"), (45, 100, "MFI 45+")]

    header = f"\n  {'':15s}"
    for _, _, ml in mfi_bins:
        header += f"  {ml:12s}"
    report.append(header)

    for wlo, whi, wl in wr_bins:
        row_str = f"  {wl:15s}"
        for mlo, mhi, ml in mfi_bins:
            mask = (df["wr"] >= wlo) & (df["wr"] < whi) & (df["mfi"] >= mlo) & (df["mfi"] < mhi)
            n = mask.sum()
            if n < 15:
                row_str += f"  {'N<15':12s}"
            else:
                wr_pct = df.loc[mask, "win"].mean() * 100
                row_str += f"  {wr_pct:.0f}% N={n:4d}   "
        report.append(row_str)

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
