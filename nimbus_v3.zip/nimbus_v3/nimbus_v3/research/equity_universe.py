"""nimbus_v3.research.equity_universe — equity panel auto-fetcher.

Single entry point: ``load_equity_panel()``. On first call, it downloads
the configured symbol list via ``PriceLoader`` (yfinance) and writes
parquet files under ``data/cache/equity_price/``. On subsequent calls,
it reads from the cache. Stale-cache fallback applies when yfinance
fails (the existing ``PriceLoader`` policy).

To extend or change the universe, edit ``DEFAULT_SYMBOLS`` below.
There is no other configuration — the cache directory and yfinance
suffix are intentionally hardcoded so that ``python scripts/run_X.py``
is the only command an operator ever needs to run.
"""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Final

import pandas as pd

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.price_loader import PriceLoader


logger = logging.getLogger(__name__)


def _default_cache_dir() -> Path:
    """Lazily-resolved equity-price cache root.

    Routes through :func:`nimbus_v3.data.paths.cache_dir` so the
    location tracks the ``NIMBUS_DATA_DIR`` env override. Resolved
    at call time, not import time.
    """
    from nimbus_v3.data.paths import cache_dir as _cache_dir
    return _cache_dir("equity_price")

#: Minimum bars a symbol must have to be included in the panel.
MIN_BARS: Final[int] = 250

#: Default fetch depth.
DEFAULT_YEARS: Final[int] = 6


#: Fallback NIFTY 200 universe — mid-2024 snapshot. Used when the
#: industry DB hasn't been built yet (first-run before
#: ``scripts/build_industry_db.py`` has generated
#: ``data/nifty500_industry_db.json``). Keeping the hardcoded tuple
#: ensures tests + fresh installs don't crash before the DB exists.
_FALLBACK_SYMBOLS: Final[tuple[str, ...]] = (
    "360ONE", "ABB", "ABCAPITAL", "ADANIENSOL", "ADANIENT", "ADANIGREEN",
    "ADANIPORTS", "ADANIPOWER", "ALKEM", "AMBUJACEM", "APLAPOLLO",
    "APOLLOHOSP", "ASHOKLEY", "ASIANPAINT", "ASTRAL", "ATGL", "AUBANK",
    "AUROPHARMA", "AXISBANK", "BAJAJ-AUTO", "BAJAJFINSV", "BAJAJHLDNG",
    "BAJFINANCE", "BANKBARODA", "BANKINDIA", "BEL", "BHARATFORG",
    "BHARTIARTL", "BHEL", "BIOCON", "BOSCHLTD", "BPCL", "BRITANNIA",
    "BSE", "CANBK", "CGPOWER", "CHOLAFIN", "CIPLA", "COALINDIA",
    "COFORGE", "COLPAL", "CONCOR", "COROMANDEL", "CUMMINSIND", "DABUR",
    "DIVISLAB", "DIXON", "DLF", "DMART", "DRREDDY", "EICHERMOT",
    "ETERNAL", "EXIDEIND", "FEDERALBNK", "FORTIS", "GAIL", "GLENMARK",
    "GMRAIRPORT", "GODREJCP", "GODREJPROP", "GRASIM", "HAL", "HAVELLS",
    "HCLTECH", "HDFCAMC", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO",
    "HINDALCO", "HINDPETRO", "HINDUNILVR", "HINDZINC", "HUDCO",
    "ICICIBANK", "ICICIGI", "IDEA", "IDFCFIRSTB", "INDHOTEL", "INDIANB",
    "INDIGO", "INDUSINDBK", "INDUSTOWER", "INFY", "IOC", "IRCTC",
    "IREDA", "IRFC", "ITC", "JINDALSTEL", "JIOFIN", "JSWENERGY",
    "JSWSTEEL", "JUBLFOOD", "KALYANKJIL", "KEI", "KOTAKBANK", "KPITTECH",
    "LAURUSLABS", "LICHSGFIN", "LODHA", "LT", "LTF", "LTM", "LUPIN",
    "M&M", "M&MFIN", "MANKIND", "MARICO", "MARUTI", "MAXHEALTH",
    "MAZDOCK", "MCX", "MFSL", "MOTHERSON", "MPHASIS", "MRF", "MUTHOOTFIN",
    "NATIONALUM", "NAUKRI", "NESTLEIND", "NHPC", "NMDC", "NTPC", "NYKAA",
    "OBEROIRLTY", "OFSS", "OIL", "ONGC", "PAGEIND", "PATANJALI", "PAYTM",
    "PERSISTENT", "PFC", "PIDILITIND", "PIIND", "PNB", "POLICYBZR",
    "POLYCAB", "POWERGRID", "PRESTIGE", "RECLTD", "RELIANCE", "RVNL",
    "SAIL", "SBICARD", "SBILIFE", "SBIN", "SHREECEM", "SHRIRAMFIN",
    "SIEMENS", "SOLARINDS", "SRF", "SUNPHARMA", "SUPREMEIND", "SUZLON",
    "TATACOMM", "TATACONSUM", "TATAELXSI", "TATAINVEST", "TATAPOWER",
    "TATASTEEL", "TCS", "TECHM", "TIINDIA", "TITAN", "TORNTPHARM",
    "TRENT", "TVSMOTOR", "ULTRACEMCO", "UNIONBANK", "UNITDSPR", "UPL",
    "VBL", "VEDL", "VOLTAS", "WIPRO", "YESBANK", "ZYDUSLIFE",
)


def _resolve_default_symbols() -> tuple[str, ...]:
    """Load the full symbol list from the industry DB when available.

    The DB at ``data/nifty500_industry_db.json`` is built by
    ``scripts/build_industry_db.py`` and covers the full NIFTY 500
    universe. When present it supersedes the hardcoded fallback so
    every symbol tracked by the system participates in the equity
    panel — Market Context, Scanner, and Dashboard all see the same
    universe without manual list maintenance.

    Any error (DB missing, unreadable, empty) falls back to
    :data:`_FALLBACK_SYMBOLS` so first-run and test environments
    keep working before the DB has been built.
    """
    try:
        from nimbus_v3.data.industry_db import load_industry_db
        db = load_industry_db()
        if db:
            syms = tuple(sorted(db.keys()))
            logger.info(
                "equity_universe: loaded %d symbols from industry DB",
                len(syms),
            )
            return syms
    except Exception:   # noqa: BLE001
        logger.exception(
            "equity_universe: failed to resolve symbols from industry DB "
            "— using hardcoded fallback",
        )
    logger.info(
        "equity_universe: using hardcoded fallback (%d symbols) — "
        "build the DB via scripts/build_industry_db.py to expand",
        len(_FALLBACK_SYMBOLS),
    )
    return _FALLBACK_SYMBOLS


#: Active default symbol list — NIFTY 500 from the industry DB when
#: present, else the NIFTY 200 hardcoded fallback. Resolved once at
#: import time so repeat reads are O(1).
DEFAULT_SYMBOLS: Final[tuple[str, ...]] = _resolve_default_symbols()


def load_equity_panel(
    *,
    symbols: tuple[str, ...] = DEFAULT_SYMBOLS,
    cache_dir: Path | None = None,
    years: int = DEFAULT_YEARS,
    min_bars: int = MIN_BARS,
    verbose: bool = True,
) -> dict[str, pd.DataFrame]:
    """Load the equity panel, fetching from yfinance on cache miss.

    Returns a dict {symbol → DataFrame(Open/High/Low/Close/Volume)}.
    The cache is shared across all validation scripts so the first
    script invocation pays the fetch cost; subsequent runs are instant.

    Args:
        symbols: Iterable of NSE symbols (no ``.NS`` suffix).
        cache_dir: Where parquet files live. ``None`` → resolves via
            :func:`nimbus_v3.data.paths.cache_dir` so the location
            tracks the ``NIMBUS_DATA_DIR`` env override. Created if
            missing.
        years: History depth requested from yfinance on first fetch.
        min_bars: Drop symbols whose returned series is shorter than this.
        verbose: Print per-symbol progress.

    Returns:
        Dict of symbol → tz-naive ascending OHLCV DataFrame.
    """
    if cache_dir is None:
        cache_dir = _default_cache_dir()
    cache = ParquetCache(base_dir=cache_dir)
    loader = PriceLoader(cache, default_years=years, yfinance_suffix=".NS")

    panel: dict[str, pd.DataFrame] = {}
    failed: list[str] = []
    n = len(symbols)
    needs_fetch = sum(1 for s in symbols if not cache.exists(s))
    if needs_fetch and verbose:
        print(
            f"Equity panel: {needs_fetch}/{n} symbols not yet cached — "
            f"fetching now (one-time, ~{needs_fetch * 2}s)"
        )

    t0 = time.perf_counter()
    for i, sym in enumerate(symbols, 1):
        df = loader.load(sym)
        if df.empty or len(df) < min_bars:
            failed.append(sym)
            if verbose and not cache.exists(sym):
                print(f"  [{i:3d}/{n}] {sym:12s}  insufficient data, skipped")
            continue
        panel[sym] = df

    elapsed = time.perf_counter() - t0
    if verbose:
        print(
            f"Equity panel: {len(panel)} symbols ready ({elapsed:.1f}s); "
            f"{len(failed)} skipped"
        )
    return panel
