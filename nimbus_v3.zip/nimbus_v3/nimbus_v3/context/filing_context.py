"""nimbus_v3.context.filing_context — filing impact classification and provider.

Two responsibilities, kept in separate classes (single-responsibility):

- :class:`FilingImpactClassifier` — maps a ``Filing`` to a
  ``FilingImpact`` enum using a ruleset of keyword patterns. Pure,
  stateless, easily overridable for research.
- :class:`FilingContextProvider` — composes the loader and the
  classifier, applies them to the most recent filing within a lookback
  window, and emits a ``FilingContext``.

Classification rules (preserved from oracle, refinable in Phase 7)
──────────────────────────────────────────────────────────────────

**TRAP** — adverse news the market is likely to re-price over days, not
minutes. Highest priority; triggers the TRAP strategy's override.
Patterns: SEBI notices / orders, investigations, fraud allegations,
auditor resignations, CFO resignations, "qualified opinion" / "going
concern" audit red flags, debt defaults, material misstatements /
restatements.

**MATERIAL** — price-moving but not automatically adverse. Patterns:
M&A activity, quarterly / annual results, earnings guidance, major
capex, management changes at CEO/MD level, stock splits, bonuses,
dividends above a threshold, QIP / preferential allotment.

**MINOR** — routine compliance disclosures. Patterns: trading window
closure notices, generic regulatory intimations, board meeting notices,
record-date notices.

**NONE** — nothing matched.

Priority: TRAP > MATERIAL > MINOR > NONE. The first match wins.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Final

import pandas as pd

from nimbus_v3.core.context import FilingContext
from nimbus_v3.core.types import FilingImpact
from nimbus_v3.data.filings_loader import Filing, FilingsLoader


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Pattern rulesets
# ══════════════════════════════════════════════════════════════════════════════

#: Each entry is a compiled case-insensitive regex matched against the
#: concatenated headline + category + details string.
_TRAP_PATTERNS: Final[tuple[re.Pattern, ...]] = tuple(re.compile(p, re.IGNORECASE) for p in (
    r"\bsebi\b.*\b(notice|order|investigation|penalty|direction)\b",
    r"\b(investigation|enforcement action)\b.*\bsebi\b",
    r"\bfraud\b",
    r"\bauditor\b.*\b(resign|disqualif)",
    r"\bresignation of auditor",
    r"\b(cfo|chief financial officer)\b.*\bresign",
    r"\bresign\w*.*\b(cfo|chief financial officer)\b",
    r"\bqualified opinion\b",
    r"\bgoing concern\b",
    r"\bdefault\b.*\b(payment|interest|principal|debt|loan)\b",
    r"\brestatement of (financial|accounts|statements)",
    r"\bmaterial misstatement\b",
    r"\binsolvency\b",
    r"\bnclt\b.*\b(petition|admission|order)\b",
    r"\bforensic audit\b",
))

_MATERIAL_PATTERNS: Final[tuple[re.Pattern, ...]] = tuple(re.compile(p, re.IGNORECASE) for p in (
    r"\bacquisition\b",
    r"\bmerger\b",
    r"\bdemerger\b",
    r"\bdivestiture\b",
    r"\bscheme of arrangement\b",
    r"\bquarterly results\b",
    r"\bannual results\b",
    r"\bfinancial results\b",
    r"\bearnings guidance\b",
    r"\bcapex\b",
    r"\bcapital expenditure\b",
    r"\b(ceo|managing director|md)\b.*\b(appointment|resign|change|cessation)\b",
    r"\b(appointment|resign\w*|change|cessation)\b.*\b(ceo|managing director|md)\b",
    r"\b(stock split|sub-division|bonus issue|rights issue)\b",
    r"\bpreferential\s+(allotment|issue)\b",
    r"\bqip\b",
    r"\bbuyback\b",
    r"\binterim dividend\b",
    r"\bfinal dividend\b",
))

_MINOR_PATTERNS: Final[tuple[re.Pattern, ...]] = tuple(re.compile(p, re.IGNORECASE) for p in (
    r"\btrading window\b",
    r"\bdisclosure under regulation\b",
    r"\bboard meeting\b",
    r"\bintimation\b",
    r"\brecord date\b",
    r"\bcompliance certificate\b",
    r"\bsecretarial audit\b",
    r"\bpostal ballot\b",
    r"\bannual general meeting\b",
    r"\bcorporate governance\b",
))


# ══════════════════════════════════════════════════════════════════════════════
# Classifier
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class FilingClassifierConfig:
    """Tunable pattern sets for the classifier. Tests and Phase 7
    research override these without monkey-patching."""
    trap_patterns: tuple[re.Pattern, ...] = field(default=_TRAP_PATTERNS)
    material_patterns: tuple[re.Pattern, ...] = field(default=_MATERIAL_PATTERNS)
    minor_patterns: tuple[re.Pattern, ...] = field(default=_MINOR_PATTERNS)


class FilingImpactClassifier:
    """Maps a ``Filing`` to a ``FilingImpact`` via regex pattern matching.

    Stateless, thread-safe. Priority order is TRAP > MATERIAL > MINOR
    > NONE: the first bucket to match wins.
    """

    def __init__(self, config: FilingClassifierConfig | None = None) -> None:
        self._config = config if config is not None else FilingClassifierConfig()

    def classify(self, filing: Filing) -> FilingImpact:
        """Classify a single filing."""
        return self._classify_text(self._filing_text(filing))

    def _classify_text(self, text: str) -> FilingImpact:
        if not text:
            return FilingImpact.NONE
        for p in self._config.trap_patterns:
            if p.search(text):
                return FilingImpact.TRAP
        for p in self._config.material_patterns:
            if p.search(text):
                return FilingImpact.MATERIAL
        for p in self._config.minor_patterns:
            if p.search(text):
                return FilingImpact.MINOR
        return FilingImpact.NONE

    @staticmethod
    def _filing_text(filing: Filing) -> str:
        """Concatenate the searchable surfaces of a filing.

        Order prioritises headline first so its patterns dominate when
        the same keyword might appear incidentally in a long details
        body.
        """
        return " | ".join(
            s for s in (filing.headline, filing.category, filing.details)
            if s
        )


# ══════════════════════════════════════════════════════════════════════════════
# Provider
# ══════════════════════════════════════════════════════════════════════════════

class FilingContextProvider:
    """``ContextProvider[FilingContext]`` over the filings loader.

    Emits a context referencing the **most impactful filing** within a
    ``lookback_days`` window ending at ``asof_date``. "Most impactful"
    means highest-priority classification (TRAP beats MATERIAL beats
    MINOR); if multiple share the top bucket, the most recent wins.
    """

    def __init__(
        self,
        filings_loader: FilingsLoader,
        classifier: FilingImpactClassifier | None = None,
        *,
        lookback_days: int = 7,
    ) -> None:
        self._loader = filings_loader
        self._classifier = classifier if classifier is not None else FilingImpactClassifier()
        self._lookback = lookback_days

    def build(
        self,
        *,
        symbol: str | None,
        asof_date: pd.Timestamp,
    ) -> FilingContext | None:
        if not symbol:
            return None
        asof = _normalise(asof_date)
        filings = self._loader.load_since(
            symbol, asof_date=asof, lookback_days=self._lookback,
        )

        if not filings:
            return FilingContext(
                asof_date=asof,
                symbol=symbol.upper(),
                latest_impact=FilingImpact.NONE,
                is_trap=False,
                days_since_latest=None,
                latest_headline=None,
            )

        classified = [(f, self._classifier.classify(f)) for f in filings]
        top = _pick_highest_priority(classified)
        top_filing, top_impact = top
        days_since = int((asof - top_filing.filing_date).days)

        return FilingContext(
            asof_date=asof,
            symbol=symbol.upper(),
            latest_impact=top_impact,
            is_trap=(top_impact is FilingImpact.TRAP),
            days_since_latest=days_since,
            latest_headline=top_filing.headline or None,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

_PRIORITY: Final[dict[FilingImpact, int]] = {
    FilingImpact.TRAP: 3,
    FilingImpact.MATERIAL: 2,
    FilingImpact.MINOR: 1,
    FilingImpact.NONE: 0,
}


def _pick_highest_priority(
    classified: list[tuple[Filing, FilingImpact]],
) -> tuple[Filing, FilingImpact]:
    """Return the (filing, impact) with the highest priority. Ties
    broken by most recent ``filing_date``. Assumes non-empty input."""
    return max(
        classified,
        key=lambda pair: (_PRIORITY[pair[1]], pair[0].filing_date),
    )


def _normalise(ts: pd.Timestamp) -> pd.Timestamp:
    t = pd.Timestamp(ts)
    if t.tz is not None:
        t = t.tz_localize(None)
    return t.normalize()
