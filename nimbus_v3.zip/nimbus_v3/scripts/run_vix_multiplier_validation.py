"""scripts/run_vix_multiplier_validation.py — walk-forward validation
of VIX regime multipliers.

The VIX pace research (``run_vix_pace_research.py``) computed tag ×
regime lifts from the full 5-year panel. To use those as conviction
multipliers in production, we need to know they generalize — that
lifts derived from 2021-2023 still predict fwd returns in
2024-2026. This script runs that test.

Design:
  1. Fixed-date midpoint split of the VIX + panel history.
  2. On train half: compute the lift of each tag in each VIX regime,
     converted to a multiplier m_T(R) = 1 + k·lift_TR, clamped.
  3. On test half: measure (a) whether the same tag×regime lifts
     replicate, (b) whether applying train-derived multipliers to
     test-period bars produces better correlation with actual
     fwd_ret_10d than using no multipliers (multiplier = 1.0).
  4. Across a grid of (slope_window, k, clamp) combinations, identify
     the parameter tuple with the best out-of-sample performance.

Key design decisions (chose defaults per the conversation):
  - Train/test split: fixed date at ``(start + end) / 2``. Unbalanced
    cells across halves are acceptable — that asymmetry is part of the
    validity check. A perfectly balanced split would mask regime-
    period effects.
  - Minimum cell N: if the TRAIN cell has fewer than 200 observations,
    multiplier is forced to 1.0 for that (tag, regime). Avoids
    shipping multipliers derived from 30-50 observations that will
    never replicate.
  - Sign flips: the script REPORTS flips (train lift +0.28pp,
    test lift -0.15pp) but does not auto-neutralize them. Operator
    judgment is better than an automatic rule here; the warnings
    surface them in the verdict output.

Output: a single text file at
``scripts/output/vix_multiplier_validation.txt`` with:
  - Lift preservation tables per (window, tag, regime)
  - Correlation grid across (window, k, clamp)
  - Verdict naming the best parameter tuple, or a negative verdict
    if no combination survives the walk-forward.
"""
from __future__ import annotations

import logging
import sys
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))
if str(_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(_ROOT / "scripts"))

# Reuse the heavyweight data prep from the main research script.
from run_vix_pace_research import (                                  # noqa: E402
    _Z_WIN, _Z_CUT, _prepare_data, _print_table, _TAG_COLS,
    classify_vix_pace,
)

logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("vix_mult_valid")
log.setLevel(logging.INFO)


_OUT_PATH = Path("scripts/output/vix_multiplier_validation.txt")

#: Slope windows to test.
_WINDOWS: tuple[int, ...] = (5, 10, 20, 60)

#: Damping factors to sweep. k controls how aggressively a per-cell
#: lift becomes a multiplier: m = 1 + k·lift_pp. Smaller k = more
#: conservative, less regime sensitivity.
_K_GRID: tuple[float, ...] = (0.25, 0.5, 1.0)

#: Clamp ranges to sweep. Multipliers below/above these bounds get
#: clipped. Tighter bounds = less signal extraction but less tail risk
#: from underpowered cells.
_CLAMP_GRID: tuple[tuple[float, float], ...] = (
    (0.7, 1.3),
    (0.5, 1.5),
    (0.3, 1.7),
)

#: Minimum observations required in a train cell before we trust
#: the derived multiplier. Below this, multiplier is forced to 1.0.
_MIN_CELL_N: int = 200

#: Magnitude threshold below which sign flips are treated as noise
#: (both train and test lift < 0.3pp apart). Above this, they're
#: flagged as overfitting warnings.
_FLIP_NOISE_THRESHOLD_PP: float = 0.3


# ══════════════════════════════════════════════════════════════════════
# Metric primitives
# ══════════════════════════════════════════════════════════════════════

def _mean_tstat(x: pd.Series) -> tuple[float, int, float]:
    """Mean, N, t-stat vs H0: mean=0. Returns (nan, 0, nan) for empty."""
    x = x.dropna()
    n = len(x)
    if n < 2:
        return (float("nan"), n, float("nan"))
    mean = float(x.mean())
    sd = float(x.std(ddof=1))
    if sd == 0:
        return (mean, n, float("nan"))
    t = mean / (sd / np.sqrt(n))
    return (mean, n, t)


# ══════════════════════════════════════════════════════════════════════
# Tag lift measurement on a date-bounded slice
# ══════════════════════════════════════════════════════════════════════

def _measure_tag_lifts(
    tagged_panel: dict[str, pd.DataFrame],
    regime_series: pd.Series,
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
) -> pd.DataFrame:
    """For each (tag, regime) on bars in [date_start, date_end]:
    mean fwd_ret_10d, N, baseline mean (no tag filter, same regime),
    lift = tag_mean - baseline_mean.
    Returns a long DataFrame.
    """
    regime_aligned = regime_series.rename("regime")

    stacked_parts = []
    for sym, df in tagged_panel.items():
        if "fwd_ret_10d" not in df.columns:
            continue
        cols_kept = [c for c in df.columns if c.startswith("is_") or c == "fwd_ret_10d"]
        if "fwd_ret_10d" not in cols_kept:
            continue
        sub = df[cols_kept]
        sub = sub.join(regime_aligned, how="inner")
        # Date-bound slice
        mask = (sub.index >= date_start) & (sub.index <= date_end)
        sub = sub.loc[mask]
        if len(sub) > 0:
            stacked_parts.append(sub)
    if not stacked_parts:
        return pd.DataFrame()
    stacked = pd.concat(stacked_parts)
    stacked = stacked.dropna(subset=["fwd_ret_10d"])

    rows: list[dict] = []
    for regime in ("RISING", "STABLE", "FALLING"):
        baseline = stacked.loc[stacked["regime"] == regime, "fwd_ret_10d"]
        base_mean, base_n, _ = _mean_tstat(baseline)
        for tag_col, tag_display in _TAG_COLS:
            if tag_col not in stacked.columns:
                continue
            regime_mask = stacked["regime"] == regime
            tag_mask = stacked[tag_col].fillna(False).astype(bool)
            in_cell = stacked.loc[regime_mask & tag_mask, "fwd_ret_10d"]
            mean, n, _ = _mean_tstat(in_cell)
            # Paired t-stat for the lift (in_cell minus baseline mean)
            lift_series = in_cell.dropna() - (base_mean if not np.isnan(base_mean) else 0)
            _, _, lift_t = _mean_tstat(lift_series)
            rows.append({
                "tag":          tag_display,
                "regime":       regime,
                "n_cell":       n,
                "n_baseline":   base_n,
                "mean_pp":      mean * 100 if not np.isnan(mean) else float("nan"),
                "baseline_pp":  base_mean * 100 if not np.isnan(base_mean) else float("nan"),
                "lift_pp":      (mean - base_mean) * 100 if not np.isnan(mean) and not np.isnan(base_mean) else float("nan"),
                "t_lift":       lift_t,
            })
    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════
# Multiplier derivation
# ══════════════════════════════════════════════════════════════════════

def _derive_multipliers(
    train_lifts: pd.DataFrame,
    k: float,
    clamp_lo: float,
    clamp_hi: float,
) -> pd.DataFrame:
    """Build the multiplier table from train-half lifts.

    Applies:
      - n_cell >= _MIN_CELL_N gate → multiplier = 1.0 otherwise
      - m = clip(1 + k * lift_pp, clamp_lo, clamp_hi)
    """
    out = train_lifts.copy()
    raw = 1.0 + k * out["lift_pp"].fillna(0.0)
    clipped = raw.clip(lower=clamp_lo, upper=clamp_hi)
    underpowered = out["n_cell"] < _MIN_CELL_N
    out["multiplier"] = clipped.where(~underpowered, 1.0)
    out["k"] = k
    out["clamp_lo"] = clamp_lo
    out["clamp_hi"] = clamp_hi
    return out[["tag", "regime", "n_cell", "lift_pp",
                "k", "clamp_lo", "clamp_hi", "multiplier"]]


# ══════════════════════════════════════════════════════════════════════
# Test-half correlation metric
# ══════════════════════════════════════════════════════════════════════

def _test_correlation(
    tagged_panel: dict[str, pd.DataFrame],
    regime_series: pd.Series,
    multipliers: pd.DataFrame,
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
) -> tuple[float, int]:
    """Compute the correlation between a multiplier-adjusted "expected
    lift" and the actual fwd_ret_10d on the test half.

    For each (symbol, bar) in [date_start, date_end]:
      expected_lift(sym, bar) = sum_{T active on this bar} lift_T(regime)
                                where lift_T(regime) = (m_T(regime) - 1)
                                                         (for ranking only;
                                                          sign and relative
                                                          magnitude matter,
                                                          absolute value does
                                                          not)
      actual = fwd_ret_10d(sym, bar)

    Correlation across the full test-half panel. Higher = multipliers
    carry predictive signal out-of-sample.

    Returns (pearson_r, n_pairs).
    """
    # Build a fast lookup: multipliers[tag][regime] -> scalar m
    mult_lookup: dict[tuple[str, str], float] = {
        (row["tag"], row["regime"]): row["multiplier"]
        for _, row in multipliers.iterrows()
    }

    regime_aligned = regime_series.rename("regime")

    expected_parts: list[pd.Series] = []
    actual_parts: list[pd.Series] = []

    for sym, df in tagged_panel.items():
        if "fwd_ret_10d" not in df.columns:
            continue
        sub = df[[c for c in df.columns
                  if c.startswith("is_") or c == "fwd_ret_10d"]]
        sub = sub.join(regime_aligned, how="inner")
        # Date-bound
        mask = (sub.index >= date_start) & (sub.index <= date_end)
        sub = sub.loc[mask]
        sub = sub.dropna(subset=["fwd_ret_10d"])
        if len(sub) == 0:
            continue

        # Build the "expected lift" column per bar
        exp_lift = pd.Series(0.0, index=sub.index)
        for tag_col, tag_display in _TAG_COLS:
            if tag_col not in sub.columns:
                continue
            flag = sub[tag_col].fillna(False).astype(bool)
            if not flag.any():
                continue
            # For rows where the tag fires, add (m - 1) per regime
            regime_col = sub["regime"]
            for regime_val in ("RISING", "STABLE", "FALLING"):
                m = mult_lookup.get((tag_display, regime_val), 1.0)
                contribution = (m - 1.0)
                if contribution == 0.0:
                    continue
                regime_mask = (regime_col == regime_val) & flag
                exp_lift.loc[regime_mask] = exp_lift.loc[regime_mask] + contribution

        expected_parts.append(exp_lift)
        actual_parts.append(sub["fwd_ret_10d"])

    if not expected_parts:
        return (float("nan"), 0)

    expected = pd.concat(expected_parts)
    actual = pd.concat(actual_parts)
    # Align and drop any remaining NaNs
    df = pd.DataFrame({"exp": expected, "act": actual}).dropna()
    if len(df) < 10:
        return (float("nan"), len(df))
    r = float(df["exp"].corr(df["act"]))
    return (r, len(df))


# ══════════════════════════════════════════════════════════════════════
# Sign flip detection
# ══════════════════════════════════════════════════════════════════════

def _find_sign_flips(
    train: pd.DataFrame, test: pd.DataFrame,
) -> list[dict]:
    """Return a list of (tag, regime) rows where the lift changed sign
    between train and test AND at least one magnitude exceeds the noise
    threshold. Small-magnitude flips both sides of zero are noise and
    not worth flagging.
    """
    merged = train.merge(
        test, on=["tag", "regime"], suffixes=("_train", "_test"),
    )
    flips: list[dict] = []
    for _, row in merged.iterrows():
        lt = row["lift_pp_train"]
        lv = row["lift_pp_test"]
        if np.isnan(lt) or np.isnan(lv):
            continue
        signs_differ = (lt > 0) != (lv > 0)
        big_enough = (abs(lt) >= _FLIP_NOISE_THRESHOLD_PP or
                      abs(lv) >= _FLIP_NOISE_THRESHOLD_PP)
        if signs_differ and big_enough:
            flips.append({
                "tag":             row["tag"],
                "regime":          row["regime"],
                "lift_train_pp":   lt,
                "lift_test_pp":    lv,
                "n_train_cell":    row["n_cell_train"],
                "n_test_cell":     row["n_cell_test"],
            })
    return flips


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data (VIX + enriched panel + industry tags)...")
    try:
        prepared = _prepare_data()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    vix_close = prepared["vix_close"]
    tagged_panel = prepared["tagged_panel"]

    # ── Determine the train/test split date ───────────────────────────
    date_start = vix_close.index.min()
    date_end = vix_close.index.max()
    split_date = date_start + (date_end - date_start) / 2
    log.info("Split: train=[%s, %s), test=[%s, %s]",
             date_start.date(), split_date.date(),
             split_date.date(), date_end.date())

    # Run the whole analysis writing to the output file
    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("VIX MULTIPLIER WALK-FORWARD VALIDATION")
        emit("=" * 78)
        emit(f"VIX history: {len(vix_close)} bars "
             f"({date_start.date()} → {date_end.date()})")
        emit(f"Split date (midpoint):    {split_date.date()}")
        emit(f"Train period:             {date_start.date()} → "
             f"{(split_date - pd.Timedelta(days=1)).date()}")
        emit(f"Test period:              {split_date.date()} → "
             f"{date_end.date()}")
        emit(f"Tagged panel symbols:     {len(tagged_panel)}")
        emit(f"Minimum cell N in train:  {_MIN_CELL_N}")
        emit(f"Sign-flip noise cutoff:   ±{_FLIP_NOISE_THRESHOLD_PP:.1f}pp")
        emit(f"k values tested:          {_K_GRID}")
        emit(f"Clamp ranges tested:      {_CLAMP_GRID}")
        emit("")

        # Collect all verdict scores for the final summary
        verdict_rows: list[dict] = []
        # Track flips per window for the summary
        flips_per_window: dict[int, list[dict]] = {}

        for win in _WINDOWS:
            emit("━" * 78)
            emit(f"SLOPE WINDOW = {win}d")
            emit("━" * 78)

            regime_df = classify_vix_pace(vix_close, slope_win=win)
            regime_series = regime_df["regime"]

            # Train vs test lift measurement
            train_lifts = _measure_tag_lifts(
                tagged_panel, regime_series,
                date_start, split_date - pd.Timedelta(days=1),
            )
            test_lifts = _measure_tag_lifts(
                tagged_panel, regime_series,
                split_date, date_end,
            )

            if train_lifts.empty or test_lifts.empty:
                emit(f"\n[skipped — insufficient data on {win}d]\n")
                continue

            # Side-by-side lift preservation
            merged = train_lifts.merge(
                test_lifts, on=["tag", "regime"], suffixes=("_train", "_test"),
            )
            side_by_side = merged[[
                "tag", "regime",
                "n_cell_train", "lift_pp_train", "t_lift_train",
                "n_cell_test",  "lift_pp_test",  "t_lift_test",
            ]].copy()
            side_by_side.columns = [
                "tag", "regime",
                "n_train", "train_lift_pp", "train_t",
                "n_test",  "test_lift_pp",  "test_t",
            ]

            emit("")
            emit("LIFT PRESERVATION: train-half vs test-half")
            emit("-" * 78)
            with pd.option_context("display.max_rows", None,
                                    "display.max_columns", None,
                                    "display.width", 180,
                                    "display.float_format", lambda x: f"{x:.3f}"):
                emit(side_by_side.to_string(index=False))
            emit("")

            # Sign flips
            flips = _find_sign_flips(train_lifts, test_lifts)
            flips_per_window[win] = flips
            if flips:
                emit(f"⚠ SIGN FLIPS (train lift and test lift differ in sign, "
                     f"at least one ≥ ±{_FLIP_NOISE_THRESHOLD_PP:.1f}pp):")
                emit("-" * 78)
                flip_df = pd.DataFrame(flips)
                with pd.option_context("display.max_rows", None,
                                        "display.max_columns", None,
                                        "display.width", 180,
                                        "display.float_format", lambda x: f"{x:.3f}"):
                    emit(flip_df.to_string(index=False))
                emit("")
                emit("(Sign flips are NOT auto-neutralized. They indicate the "
                     "train lift\ndid not replicate out-of-sample. The research "
                     "finding for that\n(tag, regime) cell may be overfit.)")
                emit("")
            else:
                emit("No sign flips above the noise threshold.\n")

            # Parameter sensitivity — correlation grid
            emit("TEST-HALF CORRELATION: (multiplier-adjusted expected lift) "
                 "vs actual fwd_ret_10d")
            emit("-" * 78)
            emit("(higher = multiplier carries out-of-sample predictive signal)")
            emit("")

            corr_rows: list[dict] = []
            for k, (clo, chi) in product(_K_GRID, _CLAMP_GRID):
                mults = _derive_multipliers(train_lifts, k, clo, chi)
                r, n = _test_correlation(
                    tagged_panel, regime_series, mults,
                    split_date, date_end,
                )
                corr_rows.append({
                    "window":   win,
                    "k":        k,
                    "clamp_lo": clo,
                    "clamp_hi": chi,
                    "corr":     r,
                    "n_pairs":  n,
                })
                verdict_rows.append({
                    **corr_rows[-1],
                    "n_sign_flips": len(flips),
                })
            corr_df = pd.DataFrame(corr_rows)
            corr_pivot = corr_df.pivot_table(
                index="k", columns=["clamp_lo", "clamp_hi"],
                values="corr",
            )
            with pd.option_context("display.float_format", lambda x: f"{x:+.5f}"):
                emit(corr_pivot.to_string())
            emit("")

            # Baseline: no multiplier (m=1.0 everywhere). Zero-variance
            # expected_lift makes numpy's divide-by-zero raise a
            # RuntimeWarning; that's expected here so we silence it at
            # this one site (not globally) to keep real numerical
            # issues visible elsewhere.
            import warnings
            baseline_mults = train_lifts.copy()
            baseline_mults["multiplier"] = 1.0
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                r_base, n_base = _test_correlation(
                    tagged_panel, regime_series, baseline_mults,
                    split_date, date_end,
                )
            emit(f"Baseline (no multiplier, m=1.0 everywhere): "
                 f"corr = {r_base}, n = {n_base}")
            emit("(Expected to be NaN: with m=1 everywhere the "
                 "'expected lift'\nis constant zero → correlation "
                 "undefined. This is the reference\npoint; any positive "
                 "corr in the grid above is signal from the\nmultipliers.)")
            emit("")

        # ── Final verdict ──────────────────────────────────────────────
        emit("━" * 78)
        emit("VERDICT")
        emit("━" * 78)
        emit("")
        if not verdict_rows:
            emit("No parameter combinations ran — insufficient data.")
            return

        verdict_df = pd.DataFrame(verdict_rows)
        # Filter out rows from windows with >3 sign flips (too overfit)
        verdict_df["overfit_flag"] = verdict_df["n_sign_flips"] > 3
        clean = verdict_df[~verdict_df["overfit_flag"]]

        emit("Ranking by test-half correlation (windows with >3 sign flips "
             "excluded):")
        emit("")
        if clean.empty:
            emit("ALL windows had >3 sign flips. Multipliers do NOT replicate "
                 "out-of-sample.")
            emit("Recommendation: DO NOT SHIP multipliers. Revert to either "
                 "gated or unconditional tag semantics.")
            return

        top = clean.sort_values("corr", ascending=False).head(5)
        with pd.option_context("display.float_format", lambda x: f"{x:+.5f}"):
            emit(top.to_string(index=False))
        emit("")

        best = top.iloc[0]
        emit(f"Best parameter tuple:")
        emit(f"  slope window:   {int(best['window'])}d")
        emit(f"  k damping:      {best['k']}")
        emit(f"  clamp range:    [{best['clamp_lo']}, {best['clamp_hi']}]")
        emit(f"  test corr:      {best['corr']:+.5f}")
        emit(f"  n sign flips:   {int(best['n_sign_flips'])}")
        emit("")

        if best["corr"] < 0.005:
            emit("⚠ Best test correlation is < 0.005 — multipliers carry "
                 "negligible\nout-of-sample signal even at the best tuning. "
                 "DO NOT SHIP multipliers.")
        elif best["corr"] < 0.02:
            emit("⚠ Best test correlation is modest (< 0.02). Multipliers may "
                 "add small\nincremental signal but at high configuration "
                 "complexity cost. Consider\nshipping only if the UI benefit "
                 "of regime-awareness itself is significant.")
        else:
            emit(f"✓ Best test correlation ≥ 0.02. Multipliers generalize "
                 f"meaningfully.\nRecommend shipping with these parameters.")

        emit("")
        emit(f"Full sign-flip census (all windows):")
        for win in _WINDOWS:
            flips = flips_per_window.get(win, [])
            if flips:
                emit(f"  {win:3d}d: {len(flips)} flip(s)")
                for fl in flips:
                    emit(f"         {fl['tag']:8s} {fl['regime']:8s}"
                         f" train={fl['lift_train_pp']:+.2f}pp"
                         f" test={fl['lift_test_pp']:+.2f}pp"
                         f" (n_train={fl['n_train_cell']},"
                         f" n_test={fl['n_test_cell']})")
            else:
                emit(f"  {win:3d}d: none")

    # Also echo the verdict to stdout
    log.info("Wrote %s", _OUT_PATH)
    with _OUT_PATH.open("r") as f:
        content = f.read()
    # Print everything from VERDICT onward
    if "VERDICT" in content:
        print(content[content.index("━" * 78 + "\nVERDICT"):])


if __name__ == "__main__":
    main()
