"""Smoke test for run_ride_screener_inspection.py.

Verifies imports work and module-level constants reference current
names (not stale ones from past iterations). Doesn't run main()
since that needs cached equity data.

LIMITATION: NameErrors inside main() function bodies (e.g.
referencing a deleted constant in an emit call) won't be caught
here — Python only resolves those at call time. To catch those,
we'd need either to run main (needs data) or do AST analysis of
function bodies. The current defense is to keep the constant set
small and to do a module-level smoke check after every change.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


def test_script_imports_cleanly():
    from scripts import run_ride_screener_inspection
    assert hasattr(run_ride_screener_inspection, "main")
    assert hasattr(run_ride_screener_inspection, "_inspect_symbol")
    assert hasattr(run_ride_screener_inspection, "_POSITIVE_EXAMPLES")
    assert len(run_ride_screener_inspection._POSITIVE_EXAMPLES) == 4


def test_no_undefined_uppercase_names():
    """AST-based scan: every UPPERCASE identifier loaded in the
    script must be imported, defined locally, or be a builtin.

    This catches the class of bug where a constant gets renamed
    (e.g. DETACHED_PCT → DETACHED_PCTB_MAX), the import is updated
    correctly at the top of the module, but a use deep in main()
    or a helper function still references the old name. Pure
    import smoke tests miss this because Python only resolves
    function-body names at call time, not import time.

    Limitation: only catches UPPERCASE identifiers. Lowercase
    typos in function bodies still need running the script to
    catch.
    """
    import ast

    script_path = _ROOT / "scripts" / "run_ride_screener_inspection.py"
    with open(script_path) as f:
        tree = ast.parse(f.read())

    # Module-level names: imports + top-level defs/assigns
    module_names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                module_names.add(alias.asname or alias.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                module_names.add(alias.asname or alias.name.split(".")[0])

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            module_names.add(node.name)
        elif isinstance(node, ast.ClassDef):
            module_names.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    module_names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(
            node.target, ast.Name,
        ):
            module_names.add(node.target.id)

    # Every UPPERCASE Load reference
    referenced: set[str] = set()
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Load)
            and node.id.isupper()
            and not node.id.startswith("_")
        ):
            referenced.add(node.id)

    builtins = {"True", "False", "None"}
    unresolved = referenced - module_names - builtins
    assert not unresolved, (
        f"Inspection script references UPPERCASE names that aren't "
        f"imported or defined locally: {sorted(unresolved)}. This "
        f"would cause a NameError at runtime. Likely a stale "
        f"reference from a renamed constant."
    )
