"""scripts/run_etf_validation.py — ETF Momentum validation.

Designed to be run on a machine with live yfinance access. Fetches
~20 liquid Indian ETFs via the v3 ``PriceLoader``, builds the same
panel/forward-return/VIX-streak structure as the equity validation,
then tests:

A) The current ``ETFMomentumStrategy`` gates (roc_20 > 3, close > sma_50,
   wr_20 > -50) on train and test.
B) Two alternative gate sets the equity validation suggested might
   work in normal regimes (PULLBACK_IN_UPTREND, BB_LOWER_BOUNCE).
C) MR's gates applied to ETFs (just to confirm they make no sense
   for ETFs — or perhaps surprise us).

Usage on your machine:

    cd nimbus_v3/
    python scripts/run_etf_validation.py

Requires network access to yfinance. The first run takes ~30 seconds
to fetch all ETF histories; subsequent runs use the parquet cache and
finish in 2-3 seconds. To force-refresh, delete
``data/cache/etf_price/`` between runs.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.price_loader import PriceLoader
from nimbus_v3.research.etf_universe import all_etfs
from nimbus_v3.research.harness import (
    add_forward_returns,
    build_vix_proxy,
    compute_vix_streaks,
    evaluate_vector_predicate_panel,
    split_panel_by_date,
    split_streak_by_date,
    summarise,
)


CACHE_DIR = Path("./data/cache/etf_price")
OOS_CUTOFF = pd.Timestamp("2025-01-01")


# ══════════════════════════════════════════════════════════════════════════════
# Candidate strategies (vectorised gates)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Candidate:
    name: str
    premise: str
    gates: Callable[[pd.DataFrame, pd.Series], pd.Series]


def _and(*conds):
    def fn(df, st):
        result = None
        for c in conds:
            mask = c(df, st)
            result = mask if result is None else (result & mask)
        return result
    return fn


CANDIDATES: list[Candidate] = [
    Candidate(
        "ETF_MOMENTUM_CURRENT",
        "Current production: roc_20 > 3, Close > sma_50, wr_20 > -50.",
        _and(
            lambda df, _: df["roc_20"] > 3.0,
            lambda df, _: df["Close"] > df["sma_50"],
            lambda df, _: df["wr_20"] > -50.0,
        ),
    ),
    Candidate(
        "ETF_PULLBACK_IN_UPTREND",
        "Equity-validated normal-regime setup: above SMA50/200 + "
        "ADX>20 + small pullback to SMA20.",
        _and(
            lambda df, _: df["above_sma_50"].astype(bool),
            lambda df, _: df["above_sma_200"].astype(bool),
            lambda df, _: df["adx_14"] > 20,
            lambda df, _: (df["pct_from_sma_20"] > -3.0)
                          & (df["pct_from_sma_20"] < 0),
        ),
    ),
    Candidate(
        "ETF_STRONG_TREND_PULLBACK",
        "Stricter version: ADX>30 + price between SMA20 and SMA50.",
        _and(
            lambda df, _: df["adx_14"] > 30,
            lambda df, _: df["above_sma_50"].astype(bool),
            lambda df, _: df["pct_from_sma_20"] < 0,
            lambda df, _: df["pct_from_sma_50"] > 0,
        ),
    ),
    Candidate(
        "ETF_MR",
        "Equity MR ported to ETFs (sanity check — ETFs rarely move "
        "this fast, expect very few signals).",
        _and(
            lambda df, _: df["roc_5"] < -3.0,
            lambda df, _: df["bbw_20_2s_pctl"] < 40.0,
            lambda _, st: st >= 6,
        ),
    ),
    Candidate(
        "ETF_ROC_60",
        "Long-horizon momentum: rolling 60-bar return > 5%, "
        "above SMA200. Diversified positive trend.",
        _and(
            lambda df, _: df["above_sma_200"].astype(bool),
            lambda df, _: df["roc_20"] > 5,
            lambda df, _: df["adx_14"] > 25,
        ),
    ),
]


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    print("Fetching ETF price data via PriceLoader …")
    cache = ParquetCache(base_dir=CACHE_DIR)
    loader = PriceLoader(cache, default_years=6, yfinance_suffix=".NS")
    panel: dict[str, pd.DataFrame] = {}
    for sym in all_etfs():
        df = loader.load(sym)
        if not df.empty and len(df) >= 250:
            panel[sym] = df
            print(f"  {sym:15s}  {len(df):4d} bars  "
                  f"{df.index.min().date()} → {df.index.max().date()}")
        else:
            print(f"  {sym:15s}  ⚠ insufficient data, skipping")
    if not panel:
        print("\nNo ETF data fetched. Check yfinance connectivity and ticker list.")
        return
    print(f"  loaded {len(panel)} ETFs")

    print("\nBuilding VIX proxy + streak series from the ETF panel …")
    vix_df = build_vix_proxy(panel, smoothing=5)
    high_threshold = float(vix_df["Close"].quantile(0.65))
    streak = compute_vix_streaks(vix_df, high_threshold=high_threshold)
    print(f"  HIGH threshold = {high_threshold:.2f}, max streak = {int(streak.max())}")

    print("\nEnriching with indicators + forward returns …")
    engine = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            e = engine.enrich(df, sym)
            e = add_forward_returns(e, horizons=(5, 10, 20))
            enriched[sym] = e
        except Exception as exc:    # noqa: BLE001
            print(f"  {sym:15s}  ⚠ enrich failed: {exc}")
            continue
    print(f"  enriched {len(enriched)} ETFs")

    if len(enriched) < 5:
        print("\nFewer than 5 ETFs enriched — stats will be unreliable. Stopping.")
        return

    print(f"\nSplitting at OOS cutoff {OOS_CUTOFF.date()} …")
    train_panel, test_panel = split_panel_by_date(enriched, cutoff=OOS_CUTOFF)
    train_streak, test_streak = split_streak_by_date(streak, cutoff=OOS_CUTOFF)
    print(f"  train: {len(train_panel)} ETFs, test: {len(test_panel)} ETFs")

    train_uni = summarise(evaluate_vector_predicate_panel(
        strategy_name="u", enriched_panel=train_panel,
        vix_streak=train_streak, predicate=lambda d, s: True,
    )).mean_10d
    test_uni = summarise(evaluate_vector_predicate_panel(
        strategy_name="u", enriched_panel=test_panel,
        vix_streak=test_streak, predicate=lambda d, s: True,
    )).mean_10d
    print(f"  ETF universe mean 10d — train: {train_uni*100:+.2f}%   "
          f"test: {test_uni*100:+.2f}%")

    # ── Run every candidate ──────────────────────────────────────────────────
    print()
    print("=" * 130)
    print(f"  {'STRATEGY':30s}  {'tr n':>5s}  {'tr lift':>8s}  {'tr t':>5s}  "
          f"{'te n':>5s}  {'te lift':>8s}  {'te t':>5s}  {'decay':>6s}  ACCEPT?")
    print("=" * 130)

    accepted: list[str] = []
    for c in CANDIDATES:
        train_stats = summarise(evaluate_vector_predicate_panel(
            strategy_name=c.name, enriched_panel=train_panel,
            vix_streak=train_streak, predicate=c.gates,
        ), baseline_mean_10d=train_uni)
        test_stats = summarise(evaluate_vector_predicate_panel(
            strategy_name=c.name, enriched_panel=test_panel,
            vix_streak=test_streak, predicate=c.gates,
        ), baseline_mean_10d=test_uni)
        train_lift = (train_stats.mean_10d - train_uni) * 100
        test_lift = (
            (test_stats.mean_10d - test_uni) * 100
            if test_stats.n > 0 else float("nan")
        )
        decay = test_lift - train_lift if test_stats.n > 0 else float("nan")

        # Lower n thresholds for ETFs — universe is much smaller (~20 names).
        # Asymmetric decay: only punish negative decay (overfit).
        accept = (
            test_stats.n >= 50
            and not pd.isna(test_lift) and test_lift >= 0.3
            and not pd.isna(decay) and decay >= -0.5
            and not pd.isna(test_stats.t_stat_lift_10d)
            and test_stats.t_stat_lift_10d >= 2.0
        )
        flag = "✅ YES" if accept else ""
        if accept:
            accepted.append(c.name)
        print(
            f"  {c.name:30s}  {train_stats.n:>5d}  "
            f"{train_lift:>+7.2f}pp  {train_stats.t_stat_lift_10d:>+5.2f}  "
            f"{test_stats.n:>5d}  {test_lift:>+7.2f}pp  "
            f"{test_stats.t_stat_lift_10d:>+5.2f}  "
            f"{decay:>+5.2f}pp  {flag}"
        )

    print("=" * 130)
    if accepted:
        print(f"\nAccepted ({len(accepted)}):")
        for c in CANDIDATES:
            if c.name in accepted:
                print(f"  {c.name}")
                print(f"    Premise: {c.premise}")
    else:
        print("\nNo candidate met all four acceptance criteria.")


if __name__ == "__main__":
    main()
