"""Tests for MarketContextProvider + VIXRegimeThresholds + helpers."""
from __future__ import annotations

from unittest.mock import MagicMock

import pandas as pd
import pytest

from nimbus_v3.context.market_context import (
    MarketContextProvider,
    VIXRegimeThresholds,
    _compute_high_streak,
    _compute_vix_zscore,
)
from nimbus_v3.core.types import VIXRegime


# ══════════════════════════════════════════════════════════════════════════════
# Regime classification
# ══════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize(("value", "expected"), [
    (10.0, VIXRegime.LOW),
    (11.99, VIXRegime.LOW),
    (12.0, VIXRegime.NORMAL),
    (15.9, VIXRegime.NORMAL),
    (16.0, VIXRegime.ELEVATED),
    (21.99, VIXRegime.ELEVATED),
    (22.0, VIXRegime.HIGH),
    (29.99, VIXRegime.HIGH),
    (30.0, VIXRegime.PANIC),
    (45.0, VIXRegime.PANIC),
])
def test_regime_thresholds_classify_boundaries(value: float, expected: VIXRegime) -> None:
    assert VIXRegimeThresholds().classify(value) == expected


# ══════════════════════════════════════════════════════════════════════════════
# High-streak
# ══════════════════════════════════════════════════════════════════════════════

def _vix_history(values: list[float]) -> pd.DataFrame:
    idx = pd.bdate_range(start="2024-01-01", periods=len(values))
    return pd.DataFrame({"Close": values}, index=idx)


def test_streak_counts_high_and_panic_at_end() -> None:
    # 12, 18, 18, 25, 25, 25 — last three are HIGH.
    history = _vix_history([12.0, 18.0, 18.0, 25.0, 25.0, 25.0])
    asof = history.index[-1]
    assert _compute_high_streak(history, asof, VIXRegimeThresholds()) == 3


def test_streak_treats_panic_as_high() -> None:
    history = _vix_history([25.0, 25.0, 35.0])
    asof = history.index[-1]
    assert _compute_high_streak(history, asof, VIXRegimeThresholds()) == 3


def test_streak_zero_when_last_bar_below_high() -> None:
    history = _vix_history([25.0, 25.0, 18.0])
    asof = history.index[-1]
    assert _compute_high_streak(history, asof, VIXRegimeThresholds()) == 0


def test_streak_zero_on_empty_history() -> None:
    assert _compute_high_streak(pd.DataFrame(), pd.Timestamp("2024-05-01"),
                                  VIXRegimeThresholds()) == 0


def test_streak_respects_asof_slicing() -> None:
    # Full: HIGH (25) at indices 3,4,5. asof=2024-01-03 → no HIGH seen yet.
    history = _vix_history([12.0, 25.0, 12.0, 25.0, 25.0, 25.0])
    asof = history.index[2]   # 12 — not high
    assert _compute_high_streak(history, asof, VIXRegimeThresholds()) == 0
    asof = history.index[1]   # 25 — single high day
    assert _compute_high_streak(history, asof, VIXRegimeThresholds()) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Z-score
# ══════════════════════════════════════════════════════════════════════════════

def test_zscore_none_when_insufficient_history() -> None:
    history = _vix_history([15.0] * 10)
    assert _compute_vix_zscore(history, history.index[-1], window=20) is None


def test_zscore_basic_calculation() -> None:
    """A positive excursion at the end of a non-flat baseline produces a
    positive z-score. A flat baseline has σ=0 and correctly returns None."""
    # σ=0 baseline → None.
    flat = _vix_history([15.0] * 20 + [20.0])
    assert _compute_vix_zscore(flat, flat.index[-1], window=20) is None

    # Noisy baseline with a big upward excursion at the end → positive z.
    import random
    random.seed(0)
    noisy = _vix_history(
        [15.0 + random.uniform(-2, 2) for _ in range(20)] + [25.0]
    )
    z = _compute_vix_zscore(noisy, noisy.index[-1], window=20)
    assert z is not None and z > 0


# ══════════════════════════════════════════════════════════════════════════════
# Provider end-to-end with a stubbed VIX loader
# ══════════════════════════════════════════════════════════════════════════════

def test_provider_builds_market_context() -> None:
    vix_loader = MagicMock()
    vix_history = _vix_history([22.0, 24.0, 25.0])
    vix_loader.load_value_on.return_value = 25.0
    vix_loader.load_history.return_value = vix_history

    provider = MarketContextProvider(vix_loader)
    ctx = provider.build(symbol=None, asof_date=pd.Timestamp("2024-01-03"))
    assert ctx.vix_value == pytest.approx(25.0)
    assert ctx.vix_regime == VIXRegime.HIGH
    assert ctx.vix_high_streak == 3
    # No NIFTY history injected → trend fields are None.
    assert ctx.index_above_sma_200 is None
    assert ctx.index_roc_20d is None


def test_provider_when_vix_unavailable() -> None:
    vix_loader = MagicMock()
    vix_loader.load_value_on.return_value = None
    vix_loader.load_history.return_value = pd.DataFrame()

    provider = MarketContextProvider(vix_loader)
    ctx = provider.build(symbol=None, asof_date=pd.Timestamp("2024-05-01"))
    assert ctx.vix_value is None
    assert ctx.vix_regime is None
    assert ctx.vix_high_streak == 0


def test_provider_uses_injected_index_history_for_trend() -> None:
    vix_loader = MagicMock()
    vix_loader.load_value_on.return_value = 15.0
    vix_loader.load_history.return_value = _vix_history([15.0] * 50)

    # 250-bar NIFTY history with a clean uptrend.
    idx = pd.bdate_range(start="2023-01-01", periods=250)
    index_df = pd.DataFrame(
        {"Close": [100.0 + i * 0.5 for i in range(250)]}, index=idx,
    )

    provider = MarketContextProvider(vix_loader, index_history=index_df)
    ctx = provider.build(symbol=None, asof_date=idx[-1])
    assert ctx.index_above_sma_200 is True
    assert ctx.index_roc_20d is not None and ctx.index_roc_20d > 0
