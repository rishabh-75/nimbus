"""Unit tests for every concrete strategy in strategies/.

Uses small helper functions to build valid ``SignalState`` and
``ContextBundle`` fixtures, then tweaks specific fields to assert each
strategy's entry gates hold independently.
"""
from __future__ import annotations

import dataclasses

import pandas as pd
import pytest

from nimbus_v3.core.context import (
    ContextBundle, FilingContext, MarketContext, SectorContext,
)
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import (
    FilingImpact, RSRegime, SetupType, VIXRegime,
)
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.breakout import BreakoutStrategy
from nimbus_v3.strategies.drawdown_reversal import DrawdownReversalStrategy
from nimbus_v3.strategies.etf_momentum import ETFMomentumStrategy
from nimbus_v3.strategies.mean_reversion import MeanReversionStrategy
from nimbus_v3.strategies.pullback_uptrend import PullbackUptrendStrategy
from nimbus_v3.strategies.ride import RideStrategy
from nimbus_v3.strategies.trap import TrapStrategy


# ══════════════════════════════════════════════════════════════════════════════
# Fixture builders
# ══════════════════════════════════════════════════════════════════════════════

_ASOF = pd.Timestamp("2024-05-15")


def _state(**overrides) -> SignalState:
    """Build a permissive SignalState; override specific fields via kwargs."""
    defaults = dict(
        symbol="RELIANCE", bar_date=_ASOF, bar_index=250,
        open=100.0, high=100.0, low=100.0, close=100.0, volume=1e6,
        sma_10=99.0, sma_20=98.0, sma_50=95.0, sma_200=90.0,
        wr_14=-50.0, wr_20=-50.0, wr_30=-50.0, wr_50=-50.0,
        rsi_14=50.0, mfi_14=50.0, mfi_slope_3=0.0,
        adx_14=25.0, atr_14=1.0, atr_14_pct=1.0,
        bb_20_1s_upper=101.0, bb_20_1s_mid=100.0,
        bb_20_1s_lower=99.0, bb_20_1s_pct=0.5,
        bb_20_2s_upper=103.0, bb_20_2s_lower=97.0,
        bbw_20_2s=6.0, bbw_20_2s_slope=0.0, bbw_20_2s_pctl=50.0,
        pct_from_sma_20=0.0, pct_from_sma_50=0.0, pct_from_sma_200=0.0,
        above_sma_20=True, above_sma_50=True, above_sma_200=True,
        dd_from_high_20=0.0, dd_from_high_50=0.0,
        red_streak=0, green_streak=0,
        vol_ratio_20=1.0, roc_5=0.0, roc_10=0.0, roc_20=0.0,
        data_sufficient=True,
    )
    defaults.update(overrides)
    return SignalState(**defaults)


def _bundle(
    *,
    vix_streak: int = 0,
    filing_is_trap: bool = False,
) -> ContextBundle:
    market = MarketContext(
        asof_date=_ASOF, vix_value=18.0,
        vix_regime=VIXRegime.ELEVATED, vix_high_streak=vix_streak,
    )
    sector = SectorContext(
        asof_date=_ASOF, symbol="RELIANCE", sector_name="Energy",
        sector_type=None, rs_regime=RSRegime.NEUTRAL,
        rs_20d=0.0, realized_vol_20d=15.0,
    )
    filing = None
    if filing_is_trap:
        filing = FilingContext(
            asof_date=_ASOF, symbol="RELIANCE",
            latest_impact=FilingImpact.TRAP, is_trap=True,
            days_since_latest=2, latest_headline="SEBI investigation",
        )
    return ContextBundle(
        symbol="RELIANCE", asof_date=_ASOF,
        market=market, sector=sector, filing=filing,
    )


_EQUITY_META = SymbolMeta(symbol="RELIANCE", sector="Energy")
_ETF_META = SymbolMeta(symbol="NIFTYBEES", is_etf=True)


# ══════════════════════════════════════════════════════════════════════════════
# Mean Reversion
# ══════════════════════════════════════════════════════════════════════════════

def test_mr_fires_when_all_gates_met() -> None:
    strat = MeanReversionStrategy()
    state = _state(roc_5=-4.0, bbw_20_2s_pctl=20.0)
    ctx = _bundle(vix_streak=6)
    sig = strat.evaluate(symbol="RELIANCE", state=state, contexts=ctx)
    assert sig is not None
    assert sig.setup_type == SetupType.MEAN_REVERSION


@pytest.mark.parametrize("patch", [
    dict(roc_5=-2.0),                          # not enough selloff
    dict(bbw_20_2s_pctl=60.0),                 # exceeds new default of 40
])
def test_mr_fails_when_any_gate_broken(patch: dict) -> None:
    strat = MeanReversionStrategy()
    base = dict(roc_5=-4.0, bbw_20_2s_pctl=20.0)
    base.update(patch)
    state = _state(**base)
    ctx = _bundle(vix_streak=6)
    assert strat.evaluate(symbol="R", state=state, contexts=ctx) is None


def test_mr_fails_when_vix_streak_low() -> None:
    strat = MeanReversionStrategy()
    state = _state(roc_5=-4.0, bbw_20_2s_pctl=20.0)
    ctx = _bundle(vix_streak=3)
    assert strat.evaluate(symbol="R", state=state, contexts=ctx) is None


def test_mr_rejects_etfs() -> None:
    strat = MeanReversionStrategy()
    assert strat.accepts(_ETF_META) is False
    assert strat.accepts(_EQUITY_META) is True


# ══════════════════════════════════════════════════════════════════════════════
# Breakout
# ══════════════════════════════════════════════════════════════════════════════

def test_breakout_fires() -> None:
    """Post-validation Breakout has only one gate: roc_20 > 7."""
    strat = BreakoutStrategy()
    state = _state(roc_20=8.0)
    sig = strat.evaluate(symbol="R", state=state, contexts=_bundle())
    assert sig is not None
    assert sig.setup_type == SetupType.BREAKOUT


def test_breakout_fails_when_roc_20_too_low() -> None:
    strat = BreakoutStrategy()
    # Default threshold is 7.0 (tightened from 5.0).
    state = _state(roc_20=6.0)
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_breakout_no_longer_uses_vol_ratio_or_vix_gates() -> None:
    """The validation study showed these gates destroyed alpha. Confirm
    that Breakout fires regardless of vol_ratio and vix_streak now."""
    strat = BreakoutStrategy()
    # Low vol_ratio AND zero vix streak — old gates would have rejected this.
    state = _state(roc_20=8.0, vol_ratio_20=0.5)
    sig = strat.evaluate(symbol="R", state=state, contexts=_bundle(vix_streak=0))
    assert sig is not None


def test_breakout_rejects_etfs() -> None:
    assert BreakoutStrategy().accepts(_ETF_META) is False


# ══════════════════════════════════════════════════════════════════════════════
# Ride
# ══════════════════════════════════════════════════════════════════════════════

def test_ride_fires_when_all_new_gates_met() -> None:
    """Post-redesign: BB band + green_streak ≥ 3 + adx_14 > 25."""
    strat = RideStrategy()
    state = _state(
        close=102.0, bb_20_1s_upper=101.0, bb_20_2s_upper=103.0,
        green_streak=4, adx_14=30.0,
    )
    sig = strat.evaluate(symbol="R", state=state, contexts=_bundle())
    assert sig is not None
    assert sig.setup_type == SetupType.RIDE


def test_ride_fails_when_close_below_1s_upper() -> None:
    strat = RideStrategy()
    state = _state(
        close=100.5, bb_20_1s_upper=101.0, bb_20_2s_upper=103.0,
        green_streak=4, adx_14=30.0,
    )
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_ride_fails_when_close_above_2s_upper() -> None:
    strat = RideStrategy()
    state = _state(
        close=104.0, bb_20_1s_upper=101.0, bb_20_2s_upper=103.0,
        green_streak=4, adx_14=30.0,
    )
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_ride_fails_when_green_streak_too_short() -> None:
    strat = RideStrategy()
    state = _state(
        close=102.0, bb_20_1s_upper=101.0, bb_20_2s_upper=103.0,
        green_streak=2, adx_14=30.0,
    )
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_ride_fails_when_adx_too_low() -> None:
    strat = RideStrategy()
    state = _state(
        close=102.0, bb_20_1s_upper=101.0, bb_20_2s_upper=103.0,
        green_streak=4, adx_14=20.0,
    )
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_ride_rejects_etfs() -> None:
    assert RideStrategy().accepts(_ETF_META) is False


# ══════════════════════════════════════════════════════════════════════════════
# ETF Momentum
# ══════════════════════════════════════════════════════════════════════════════

def test_etf_fires_for_etf_only() -> None:
    strat = ETFMomentumStrategy()
    assert strat.accepts(_ETF_META) is True
    assert strat.accepts(_EQUITY_META) is False


def test_etf_fires_when_all_gates_met() -> None:
    strat = ETFMomentumStrategy()
    state = _state(symbol="NIFTYBEES", roc_20=5.0, close=110.0, sma_50=100.0, wr_20=-30.0)
    sig = strat.evaluate(symbol="NIFTYBEES", state=state, contexts=_bundle())
    assert sig is not None


@pytest.mark.parametrize("patch", [
    dict(roc_20=1.0),        # not enough momentum
    dict(close=90.0),        # below sma_50
    dict(wr_20=-70.0),       # too oversold
])
def test_etf_fails(patch: dict) -> None:
    strat = ETFMomentumStrategy()
    base = dict(
        symbol="NIFTYBEES", roc_20=5.0, close=110.0, sma_50=100.0, wr_20=-30.0,
    )
    base.update(patch)
    state = _state(**base)
    assert strat.evaluate(symbol="NIFTYBEES", state=state, contexts=_bundle()) is None


# ══════════════════════════════════════════════════════════════════════════════
# TRAP
# ══════════════════════════════════════════════════════════════════════════════

def test_trap_fires_when_filing_is_trap() -> None:
    strat = TrapStrategy()
    sig = strat.evaluate(
        symbol="RELIANCE", state=_state(),
        contexts=_bundle(filing_is_trap=True),
    )
    assert sig is not None
    assert sig.setup_type == SetupType.TRAP
    assert sig.priority == 100   # highest


def test_trap_does_not_fire_when_no_filing() -> None:
    strat = TrapStrategy()
    sig = strat.evaluate(
        symbol="RELIANCE", state=_state(),
        contexts=_bundle(filing_is_trap=False),
    )
    assert sig is None


def test_trap_does_not_fire_when_filing_not_trap() -> None:
    strat = TrapStrategy()
    ctx = dataclasses.replace(
        _bundle(),
        filing=FilingContext(
            asof_date=_ASOF, symbol="RELIANCE",
            latest_impact=FilingImpact.MATERIAL, is_trap=False,
            days_since_latest=2, latest_headline="Results",
        ),
    )
    assert strat.evaluate(symbol="RELIANCE", state=_state(), contexts=ctx) is None


def test_trap_accepts_everything() -> None:
    strat = TrapStrategy()
    assert strat.accepts(_EQUITY_META) is True
    assert strat.accepts(_ETF_META) is True


# ══════════════════════════════════════════════════════════════════════════════
# PullbackUptrend (research-tier)
# ══════════════════════════════════════════════════════════════════════════════

def test_pullback_uptrend_fires_when_all_gates_met() -> None:
    strat = PullbackUptrendStrategy()
    state = _state(
        above_sma_50=True, above_sma_200=True,
        adx_14=25.0, pct_from_sma_20=-1.5,
    )
    sig = strat.evaluate(symbol="R", state=state, contexts=_bundle())
    assert sig is not None
    assert sig.setup_type == SetupType.PULLBACK_IN_UPTREND


def test_pullback_uptrend_requires_above_both_smas() -> None:
    strat = PullbackUptrendStrategy()
    state = _state(above_sma_50=True, above_sma_200=False,
                     adx_14=25.0, pct_from_sma_20=-1.5)
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_pullback_uptrend_requires_adx_above_threshold() -> None:
    strat = PullbackUptrendStrategy()
    state = _state(above_sma_50=True, above_sma_200=True,
                     adx_14=18.0, pct_from_sma_20=-1.5)
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_pullback_uptrend_requires_pullback_band() -> None:
    strat = PullbackUptrendStrategy()
    # Too deep (below -3%)
    assert strat.evaluate(symbol="R",
        state=_state(above_sma_50=True, above_sma_200=True,
                     adx_14=25.0, pct_from_sma_20=-5.0),
        contexts=_bundle()) is None
    # Already above SMA (positive pct_from_sma_20)
    assert strat.evaluate(symbol="R",
        state=_state(above_sma_50=True, above_sma_200=True,
                     adx_14=25.0, pct_from_sma_20=2.0),
        contexts=_bundle()) is None


def test_pullback_uptrend_rejects_etfs() -> None:
    assert PullbackUptrendStrategy().accepts(_ETF_META) is False


# ══════════════════════════════════════════════════════════════════════════════
# DrawdownReversal (research-tier, counter-cyclical)
# ══════════════════════════════════════════════════════════════════════════════

def test_drawdown_reversal_fires_when_all_gates_met() -> None:
    strat = DrawdownReversalStrategy()
    state = _state(dd_from_high_50=-12.0, green_streak=3, mfi_14=55.0)
    sig = strat.evaluate(symbol="R", state=state, contexts=_bundle())
    assert sig is not None
    assert sig.setup_type == SetupType.DRAWDOWN_REVERSAL


def test_drawdown_reversal_requires_drawdown() -> None:
    strat = DrawdownReversalStrategy()
    # Not enough drawdown
    state = _state(dd_from_high_50=-5.0, green_streak=3, mfi_14=55.0)
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_drawdown_reversal_requires_green_streak() -> None:
    strat = DrawdownReversalStrategy()
    state = _state(dd_from_high_50=-12.0, green_streak=1, mfi_14=55.0)
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_drawdown_reversal_requires_mfi_above_40() -> None:
    strat = DrawdownReversalStrategy()
    state = _state(dd_from_high_50=-12.0, green_streak=3, mfi_14=30.0)
    assert strat.evaluate(symbol="R", state=state, contexts=_bundle()) is None


def test_drawdown_reversal_rejects_etfs() -> None:
    assert DrawdownReversalStrategy().accepts(_ETF_META) is False
