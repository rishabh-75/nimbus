"""nimbus_v3.ui.widgets.components — Dashboard cockpit primitives.

Ported from ``nimbus_oracle/ui/components.py`` and re-keyed against the
v3 theme. Six reusable widgets used by the Dashboard tab (Phase 11):

- ``KPITile``       — labelled metric tile with value + delta subtitle
- ``Badge``         — coloured state pill (grade / sizing / verdict / stage / generic)
- ``PanelFrame``    — card container with optional accent top border
- ``LevelRow``      — single row in a key-levels grid (name | value | pct)
- ``ChecklistRow``  — viability checklist row with status icon + detail + implication
- ``RiskNote``      — bordered red warning bar

Design principles inherited from oracle (lifted verbatim from its
docstring because they're correct):
  - Information density: every pixel carries signal
  - Typography hierarchy: monospace numbers, sans-serif labels
  - Colour encodes state: green=go, red=stop, gold=caution

Differences from oracle's components.py
───────────────────────────────────────
1. ``Badge.apply_style`` looks up across all four v3 style dicts
   (GRADE_STYLES, SIZING_STYLES, VERDICT_STYLES, STAGE_STYLES) plus a
   built-in NEUTRAL fallback. Oracle had two flat dicts merged.
2. v3's theme has no ``BADGE_STYLES``-as-NEUTRAL entry; we inline the
   neutral triple here so ``Badge`` works with no style key at all.
3. JetBrains Mono is the only font family across the board (oracle
   used FONT_UI / FONT_MONO interchangeably; both resolve to JetBrains
   Mono in v3 anyway).
"""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget,
)

from nimbus_v3.ui.theme import (
    BORDER, FONT_MONO, FONT_UI, GOLD, GRADE_STYLES, GREEN, MUTED, RED,
    RESEARCH_STYLES, S2, SIZING_STYLES, STAGE_STYLES, SURFACE,
    VERDICT_STYLES, WHITE,
)


# Neutral fallback for badges with no recognised style key.
_NEUTRAL_BADGE = {"bg": S2, "text": MUTED, "border": BORDER}


# ══════════════════════════════════════════════════════════════════════════════
# KPI TILE — value + delta subtitle
# ══════════════════════════════════════════════════════════════════════════════

class KPITile(QFrame):
    """Compact metric tile: small UPPERCASE label + large monospace
    value + optional small coloured delta subtitle.

    Used in the Dashboard tab's KPI row (SPOT, WR, MFI, vs SMA, BB %B,
    PCR OI, NET GEX, TO EXPIRY, VOL STATE).

    The border colour is BORDER by default; ``set_stale(True)`` flips
    it to GOLD to flag that the underlying data hasn't refreshed.
    """

    def __init__(self, label: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        # Per-instance object name so the QSS border style applies only
        # to THIS frame and not every QFrame in the dashboard.
        self._oid = f"kpi-{id(self)}"
        self.setObjectName(self._oid)
        self._set_border(BORDER)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 4, 6, 4)
        lay.setSpacing(1)

        # Label (small, muted, uppercase, letter-spaced).
        self._name = QLabel(label.upper())
        self._name.setFont(QFont(FONT_UI, 6))
        self._name.setStyleSheet(f"color: {MUTED}; letter-spacing: 0.8px;")
        lay.addWidget(self._name)

        # Value (large, monospace, bold).
        self._value = QLabel("--")
        self._value.setFont(QFont(FONT_MONO, 10))
        self._value.setStyleSheet(f"color: {WHITE}; font-weight: bold;")
        lay.addWidget(self._value)

        # Delta / subtitle (small, coloured).
        self._delta = QLabel("")
        self._delta.setFont(QFont(FONT_MONO, 7))
        self._delta.setStyleSheet(f"color: {MUTED};")
        self._delta.setVisible(False)
        lay.addWidget(self._delta)

    def set_value(
        self,
        text: str,
        color: str = WHITE,
        delta: str = "",
    ) -> None:
        """Update the main value + optional delta string in one call."""
        self._value.setText(text)
        self._value.setStyleSheet(f"color: {color}; font-weight: bold;")
        if delta:
            self._delta.setText(delta)
            self._delta.setVisible(True)
        else:
            self._delta.setVisible(False)

    def set_title(self, text: str) -> None:
        """Rename the tile label at runtime (e.g. PCR OI → VSR for ETFs)."""
        self._name.setText(text.upper())

    def set_delta(self, text: str, color: str = MUTED) -> None:
        """Set just the delta line independently of the main value."""
        self._delta.setText(text)
        self._delta.setStyleSheet(f"color: {color};")
        self._delta.setVisible(bool(text))

    def set_stale(self, stale: bool) -> None:
        """Flip the border to GOLD to indicate stale data."""
        self._set_border(GOLD if stale else BORDER)

    def _set_border(self, color: str) -> None:
        self.setStyleSheet(
            f"QFrame#{self._oid} {{ background: {S2}; "
            f"border: 1px solid {color}; border-radius: 6px; }}"
        )


# ══════════════════════════════════════════════════════════════════════════════
# BADGE — coloured state pill
# ══════════════════════════════════════════════════════════════════════════════

class Badge(QLabel):
    """Coloured state pill that resolves its colour triple by looking
    up the text in v3's style dictionaries.

    Lookup order: GRADE_STYLES → SIZING_STYLES → VERDICT_STYLES →
    STAGE_STYLES → NEUTRAL fallback. The first matching style wins.

    Usage:
        b = Badge()
        b.set_badge("A")          # uses GRADE_STYLES["A"] (green-on-dark)
        b.set_badge("WATCH")      # uses SIZING_STYLES["WATCH"] (blue-on-dark)
        b.set_badge("EXTENDED")   # uses STAGE_STYLES["EXTENDED"] (red-on-dark)
        b.set_badge("Custom",     # explicit key — overrides text-driven lookup
                    style_key="A")
    """

    _LOOKUP = (
        GRADE_STYLES, SIZING_STYLES, VERDICT_STYLES,
        STAGE_STYLES, RESEARCH_STYLES,
    )

    def __init__(self, text: str = "", parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.setFont(QFont(FONT_UI, 7))
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(18)
        self.setMaximumWidth(220)
        self.setTextFormat(Qt.TextFormat.PlainText)
        self.apply_style("NEUTRAL")

    def apply_style(self, key: str) -> None:
        """Look the key up across all style dicts; fall back to neutral."""
        style = _NEUTRAL_BADGE
        for lookup in self._LOOKUP:
            if key in lookup:
                style = lookup[key]
                break
        bg = style.get("bg", _NEUTRAL_BADGE["bg"])
        tc = style.get("text", _NEUTRAL_BADGE["text"])
        bc = style.get("border", _NEUTRAL_BADGE["border"])
        self.setStyleSheet(
            f"background: {bg}; color: {tc}; border: 1px solid {bc}; "
            f"border-radius: 3px; padding: 1px 6px; font-weight: 600;"
        )

    def set_badge(self, text: str, style_key: str = "") -> None:
        """Set badge text and optionally an explicit style key.

        If ``style_key`` is empty, the text itself is used as the key
        (so ``set_badge("A")`` looks up GRADE_STYLES["A"]).

        Long text is elided with an ellipsis at 28 chars; full text
        survives in the tooltip.
        """
        display = text if len(text) <= 28 else text[:26] + "…"
        self.setText(display)
        self.setToolTip(text)
        self.apply_style(style_key or text)


# ══════════════════════════════════════════════════════════════════════════════
# PANEL FRAME — card with optional accent top border
# ══════════════════════════════════════════════════════════════════════════════

class PanelFrame(QFrame):
    """Card container with an optional title header and an optional
    coloured top border (the "accent").

    The accent is the visual cue for the panel's current state — e.g.
    a viability panel can flip its accent to GREEN/GOLD/RED based on
    the current verdict, and the operator's eye picks it up
    immediately without reading the panel's contents.

    Use ``content_layout()`` to add child widgets below the optional
    title header.
    """

    def __init__(
        self,
        title: str = "",
        accent: str = BORDER,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._accent = accent
        self._oid = f"pf-{id(self)}"
        self.setObjectName(self._oid)
        self._apply_style()

        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(12, 10, 12, 10)
        self._layout.setSpacing(5)

        if title:
            hdr = QLabel(title.upper())
            hdr.setFont(QFont(FONT_UI, 7))
            hdr.setStyleSheet(f"color: {MUTED}; letter-spacing: 1px;")
            self._layout.addWidget(hdr)

    def _apply_style(self) -> None:
        self.setStyleSheet(
            f"QFrame#{self._oid} {{ background: {SURFACE}; "
            f"border: 1px solid {BORDER}; border-radius: 6px; "
            f"border-top: 2px solid {self._accent}; }}"
        )

    def set_accent(self, color: str) -> None:
        """Change the accent (top-border) colour at runtime."""
        self._accent = color
        self._apply_style()

    def content_layout(self) -> QVBoxLayout:
        """The vertical layout below the title header. Add children here."""
        return self._layout


# ══════════════════════════════════════════════════════════════════════════════
# LEVEL ROW — single row in a key-levels grid (name | value | pct)
# ══════════════════════════════════════════════════════════════════════════════

class LevelRow(QWidget):
    """One row in the Dashboard's Key Levels grid.

    Format:    RESISTANCE   25,000   +5.3%
               (label)      (value)  (pct distance from spot)

    The colour applies to both the value and the pct columns, so a
    single glance tells you whether the level is above (green/gold) or
    below (red) the current spot, and how far.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        lay = QHBoxLayout(self)
        # Zero margins + fixed 20px height for a dense grid. The
        # previous (0, 2, 0, 2) margins combined with label line-height
        # gave ~26px per row; 4 rows looked airy and 9 rows would have
        # needed a scroll. 20px is tight but readable with the
        # configured 9pt mono values.
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        self.setFixedHeight(20)

        self._name = QLabel("")
        self._name.setFont(QFont(FONT_UI, 7))
        self._name.setStyleSheet(f"color: {MUTED}; letter-spacing: 0.5px;")
        self._name.setFixedWidth(90)
        lay.addWidget(self._name)

        self._val = QLabel("")
        self._val.setFont(QFont(FONT_MONO, 9))
        self._val.setStyleSheet(f"color: {WHITE}; font-weight: 600;")
        self._val.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
        )
        lay.addWidget(self._val, stretch=1)

        self._pct = QLabel("")
        self._pct.setFont(QFont(FONT_MONO, 7))
        self._pct.setMinimumWidth(60)
        self._pct.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
        )
        lay.addWidget(self._pct)

        self.setStyleSheet(f"border-bottom: 1px solid {BORDER};")

    def set_data(
        self,
        name: str,
        value: float | None,
        color: str = WHITE,
        pct: str = "",
    ) -> None:
        """Update all three columns.

        ``value`` is formatted with thousands separators when numeric;
        passing ``None`` renders an em-dash for the value column
        (dashboard empty-state path). ``pct`` is passed through verbatim
        (caller decides format).
        """
        self._name.setText(name.upper())
        if value is None:
            self._val.setText("—")
        else:
            self._val.setText(f"{value:,.0f}")
        self._val.setStyleSheet(f"color: {color}; font-weight: 600;")
        self._pct.setText(pct)
        self._pct.setStyleSheet(f"color: {color};")


# ══════════════════════════════════════════════════════════════════════════════
# CHECKLIST ROW — status icon + detail + implication
# ══════════════════════════════════════════════════════════════════════════════

class ChecklistRow(QWidget):
    """One row in the Dashboard's Viability Checklist.

    Format:    ✓   <detail>
                   <implication>     (smaller, muted)

    Status icon and colour:
        pass     ✓   green
        warn     !   gold
        fail     ✗   red
        neutral  -   muted
    """

    _ICONS = {
        "pass":    ("✓", GREEN),
        "warn":    ("!", GOLD),
        "fail":    ("✗", RED),
        "neutral": ("-", MUTED),
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 3, 0, 3)
        outer.setSpacing(8)

        self._icon = QLabel("-")
        self._icon.setFixedWidth(14)
        self._icon.setFont(QFont(FONT_MONO, 9))
        self._icon.setAlignment(
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
        )
        outer.addWidget(self._icon)

        col = QVBoxLayout()
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)

        self._detail = QLabel("")
        self._detail.setFont(QFont(FONT_UI, 8))
        self._detail.setStyleSheet(f"color: {WHITE};")
        self._detail.setWordWrap(True)
        col.addWidget(self._detail)

        self._impl = QLabel("")
        self._impl.setFont(QFont(FONT_UI, 7))
        self._impl.setStyleSheet(f"color: {MUTED};")
        self._impl.setWordWrap(True)
        col.addWidget(self._impl)

        outer.addLayout(col, stretch=1)
        self.setStyleSheet(f"border-bottom: 1px solid {BORDER};")

    def set_data(
        self,
        status: str,
        item: str,                 # noqa: ARG002 — accepted for API parity, unused in display
        detail: str,
        implication: str = "",
    ) -> None:
        """Render the row. ``item`` is accepted for API parity with
        oracle's ``CheckItem`` shape but currently unused in display
        — the detail line is what the operator reads.
        """
        icon, color = self._ICONS.get(status, ("-", MUTED))
        self._icon.setText(icon)
        self._icon.setStyleSheet(f"color: {color};")
        self._detail.setText(detail)
        self._impl.setText(implication)
        self._impl.setVisible(bool(implication))


# ══════════════════════════════════════════════════════════════════════════════
# RISK NOTE — bordered red warning bar
# ══════════════════════════════════════════════════════════════════════════════

class RiskNote(QFrame):
    """Bordered red warning bar with leading "!" — used in the Dashboard
    cockpit for hard-blocking risks (e.g. F&O ban list, illiquid expiry,
    SEBI show-cause).

    Visually: subtle red background tint, red left accent border,
    salmon text. Designed to draw the eye without screaming.
    """

    def __init__(self, text: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setStyleSheet(
            f"background: rgba(239,68,68,0.07); "
            f"border: 1px solid rgba(239,68,68,0.2); "
            f"border-left: 2px solid {RED}; "
            f"border-radius: 3px; padding: 3px 8px;"
        )
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum,
        )
        self.setMinimumWidth(0)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 1, 2, 1)
        lbl = QLabel(f"! {text}")
        lbl.setFont(QFont(FONT_UI, 8))
        lbl.setStyleSheet("color: #fca5a5;")     # lighter salmon for legibility
        lbl.setWordWrap(True)
        lbl.setMinimumWidth(0)
        lbl.setSizePolicy(
            QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum,
        )
        lay.addWidget(lbl, stretch=1)
