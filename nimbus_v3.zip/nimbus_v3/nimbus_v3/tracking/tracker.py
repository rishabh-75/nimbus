"""nimbus_v3.tracking.tracker — signal log reader/writer.

Three operations, all designed to be idempotent and robust:

- :meth:`SignalTracker.record` / :meth:`record_many` — persist scan
  results to the log. Duplicate records (same symbol × asof_date ×
  strategy_name) are skipped, not overwritten: the first record wins,
  preserving the historical record of what the engine believed at
  scan time.

- :meth:`SignalTracker.backfill_returns` — walk unfilled rows, compute
  realised forward returns at 1/5/10/20-day horizons using a supplied
  price panel, write them back. Safe to call repeatedly; already-
  filled rows are ignored.

- :meth:`SignalTracker.query` — read rows by strategy / date range /
  production flag / filled flag. Returns dicts, not raw Rows, so
  callers don't have to import sqlite3.

The tracker holds a SQLite connection for its lifetime. Construct one
per process; it's not thread-safe for concurrent writers (SQLite
permits multiple readers but only one writer at a time).
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.tracking.schema import connect


logger = logging.getLogger(__name__)


#: Horizons (in calendar-day index positions) the backfill computes.
BACKFILL_HORIZONS: tuple[int, ...] = (1, 5, 10, 20)


# ══════════════════════════════════════════════════════════════════════════════
# Result record (query output shape)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class TrackedSignal:
    """One row read from the signal log.

    Lightweight dataclass to keep callers agnostic of sqlite3. All
    floats are Python floats (not numpy scalars) to avoid subtle
    serialisation bugs.
    """
    id: int
    symbol: str
    asof_date: pd.Timestamp
    strategy_name: str
    setup_type: str
    priority: int
    score: float
    raw_score: float
    grade: str
    verdict: str
    sizing: str
    production_weight: float
    override_reason: str | None
    close_price: float
    fwd_ret_1d: float | None
    fwd_ret_5d: float | None
    fwd_ret_10d: float | None
    fwd_ret_20d: float | None
    recorded_at: float
    returns_filled_at: float | None


# ══════════════════════════════════════════════════════════════════════════════
# Tracker
# ══════════════════════════════════════════════════════════════════════════════

class SignalTracker:
    """Signal log reader/writer backed by SQLite.

    Construct once per process; reuse the instance for every scan.
    Close with :meth:`close` or via the context-manager protocol.
    """

    def __init__(self, db_path: Path) -> None:
        self._db_path = Path(db_path)
        self._conn: sqlite3.Connection = connect(self._db_path)

    # ── context manager lifecycle ─────────────────────────────────────────────
    def __enter__(self) -> "SignalTracker":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying connection. Safe to call multiple times."""
        if self._conn is not None:
            try:
                self._conn.close()
            finally:
                self._conn = None   # type: ignore[assignment]

    # ══════════════════════════════════════════════════════════════════════
    # Write path
    # ══════════════════════════════════════════════════════════════════════

    def record(self, result: ScanResult) -> bool:
        """Persist one ``ScanResult``. Returns True if inserted, False if
        the (symbol, asof_date, strategy_name) tuple already exists."""
        return self._insert_one(result)

    def record_many(self, results: Iterable[ScanResult]) -> int:
        """Persist many ``ScanResult``s atomically. Returns number inserted."""
        count = 0
        for r in results:
            if self._insert_one(r, commit=False):
                count += 1
        self._conn.commit()
        return count

    def _insert_one(
        self, result: ScanResult, *, commit: bool = True,
    ) -> bool:
        """Return True on insert, False on duplicate.

        Close price is pulled from the signal's metadata when present
        (strategy signal carries it) or from state via the conviction
        record's contributions where ``close`` is referenced. If
        neither is available we fall back to ``float('nan')`` — the
        backfill logic then skips forward-return computation for that
        row.
        """
        c = result.conviction
        close_price = _extract_close_price(result)
        # Coerce NaN to SQL NULL — both mean "price not available".
        close_param = None if np.isnan(close_price) else close_price
        contributions_json = json.dumps([
            {"name": co.name, "value": co.value, "reason": co.reason}
            for co in c.contributions
        ])
        try:
            self._conn.execute(
                """
                INSERT INTO signals (
                    symbol, asof_date, strategy_name, setup_type, priority,
                    score, raw_score, grade, verdict, sizing,
                    production_weight, override_reason,
                    contributions_json, close_price,
                    recorded_at
                ) VALUES (?, ?, ?, ?, ?,
                          ?, ?, ?, ?, ?,
                          ?, ?,
                          ?, ?,
                          ?)
                """,
                (
                    result.symbol,
                    result.asof_date.strftime("%Y-%m-%d"),
                    c.strategy_name, c.setup_type.value,
                    int(result.strategy.priority),
                    float(c.score), float(c.raw_score),
                    c.grade.value, c.verdict.value, c.sizing.value,
                    float(c.production_weight), c.override_reason,
                    contributions_json, close_param,
                    time.time(),
                ),
            )
            if commit:
                self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            # Duplicate (UNIQUE constraint on symbol+asof_date+strategy_name).
            return False

    # ══════════════════════════════════════════════════════════════════════
    # Backfill path
    # ══════════════════════════════════════════════════════════════════════

    def backfill_returns(
        self,
        *,
        price_panel: dict[str, pd.DataFrame],
        horizons: tuple[int, ...] = BACKFILL_HORIZONS,
    ) -> int:
        """Compute realised forward returns for every unfilled row that has
        sufficient forward history.

        Args:
            price_panel: Dict of symbol → OHLCV DataFrame (uppercase
                "Close" column). Typically the same panel the scanner
                consumes.
            horizons: Bar offsets to fill. Default (1, 5, 10, 20).

        Returns:
            Number of rows updated.
        """
        unfilled_rows = self._conn.execute(
            """
            SELECT id, symbol, asof_date, close_price
            FROM signals
            WHERE returns_filled_at IS NULL
            ORDER BY asof_date ASC
            """
        ).fetchall()

        if not unfilled_rows:
            return 0

        updated = 0
        for row in unfilled_rows:
            raw_close = row["close_price"]
            if raw_close is None:
                continue    # no price captured at signal time — can't compute
            returns = _compute_forward_returns(
                symbol=row["symbol"],
                asof_date=pd.Timestamp(row["asof_date"]),
                close_at_signal=float(raw_close),
                price_panel=price_panel,
                horizons=horizons,
            )
            if returns is None:
                continue   # not enough forward bars yet
            self._conn.execute(
                """
                UPDATE signals
                   SET fwd_ret_1d = ?, fwd_ret_5d = ?,
                       fwd_ret_10d = ?, fwd_ret_20d = ?,
                       returns_filled_at = ?
                 WHERE id = ?
                """,
                (
                    returns.get(1), returns.get(5),
                    returns.get(10), returns.get(20),
                    time.time(), row["id"],
                ),
            )
            updated += 1
        self._conn.commit()
        return updated

    # ══════════════════════════════════════════════════════════════════════
    # Read path
    # ══════════════════════════════════════════════════════════════════════

    def query(
        self,
        *,
        strategy_name: str | None = None,
        asof_from: pd.Timestamp | None = None,
        asof_to: pd.Timestamp | None = None,
        production_only: bool = False,
        filled_only: bool = False,
        limit: int | None = None,
    ) -> list[TrackedSignal]:
        """Return log rows matching the given filters."""
        clauses: list[str] = []
        params: list = []
        if strategy_name is not None:
            clauses.append("strategy_name = ?")
            params.append(strategy_name)
        if asof_from is not None:
            clauses.append("asof_date >= ?")
            params.append(pd.Timestamp(asof_from).strftime("%Y-%m-%d"))
        if asof_to is not None:
            clauses.append("asof_date <= ?")
            params.append(pd.Timestamp(asof_to).strftime("%Y-%m-%d"))
        if production_only:
            clauses.append("production_weight > 0")
        if filled_only:
            clauses.append("returns_filled_at IS NOT NULL")

        sql = "SELECT * FROM signals"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY asof_date DESC, id DESC"
        if limit is not None:
            sql += f" LIMIT {int(limit)}"

        rows = self._conn.execute(sql, params).fetchall()
        return [_row_to_tracked(r) for r in rows]

    def count(self) -> int:
        """Total number of signals in the log."""
        row = self._conn.execute("SELECT COUNT(*) AS n FROM signals").fetchone()
        return int(row["n"])

    def count_unfilled(self) -> int:
        """Number of signals awaiting forward-return backfill."""
        row = self._conn.execute(
            "SELECT COUNT(*) AS n FROM signals WHERE returns_filled_at IS NULL"
        ).fetchone()
        return int(row["n"])


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _extract_close_price(result: ScanResult) -> float:
    """Pull the signal-time close from the ScanResult. Returns NaN if
    the scanner didn't populate it (legacy path) — backfill will then
    skip the row, but the record still persists for audit."""
    return float(getattr(result, "close_price", float("nan")))


def _compute_forward_returns(
    *,
    symbol: str,
    asof_date: pd.Timestamp,
    close_at_signal: float,
    price_panel: dict[str, pd.DataFrame],
    horizons: tuple[int, ...],
) -> dict[int, float] | None:
    """Compute (log) forward returns for a given asof_date.

    Returns ``None`` if the panel lacks data for this symbol or if
    there isn't enough forward history to cover the LARGEST horizon.
    """
    if np.isnan(close_at_signal) or close_at_signal <= 0:
        return None
    df = price_panel.get(symbol)
    if df is None or df.empty or "Close" not in df.columns:
        return None

    idx = df.index
    if idx.tz is not None:
        idx = idx.tz_localize(None)
    mask = idx <= asof_date
    if not mask.any():
        return None
    signal_pos = int(mask.sum()) - 1
    bars_remaining = len(df) - 1 - signal_pos
    if bars_remaining < max(horizons):
        return None   # wait for more forward bars

    closes = df["Close"].to_numpy(dtype=float)
    returns: dict[int, float] = {}
    for h in horizons:
        future_close = closes[signal_pos + h]
        if future_close <= 0:
            continue
        returns[h] = float(np.log(future_close / close_at_signal))
    return returns or None


def _row_to_tracked(row: sqlite3.Row) -> TrackedSignal:
    return TrackedSignal(
        id=int(row["id"]),
        symbol=str(row["symbol"]),
        asof_date=pd.Timestamp(row["asof_date"]),
        strategy_name=str(row["strategy_name"]),
        setup_type=str(row["setup_type"]),
        priority=int(row["priority"]),
        score=float(row["score"]),
        raw_score=float(row["raw_score"]),
        grade=str(row["grade"]),
        verdict=str(row["verdict"]),
        sizing=str(row["sizing"]),
        production_weight=float(row["production_weight"]),
        override_reason=(
            str(row["override_reason"]) if row["override_reason"] is not None
            else None
        ),
        close_price=(
            float(row["close_price"]) if row["close_price"] is not None
            else float("nan")
        ),
        fwd_ret_1d=_opt_float(row["fwd_ret_1d"]),
        fwd_ret_5d=_opt_float(row["fwd_ret_5d"]),
        fwd_ret_10d=_opt_float(row["fwd_ret_10d"]),
        fwd_ret_20d=_opt_float(row["fwd_ret_20d"]),
        recorded_at=float(row["recorded_at"]),
        returns_filled_at=_opt_float(row["returns_filled_at"]),
    )


def _opt_float(value) -> float | None:    # noqa: ANN001
    return float(value) if value is not None else None
