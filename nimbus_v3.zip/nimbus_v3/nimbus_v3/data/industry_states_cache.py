"""nimbus_v3.data.industry_states_cache — pickle cache for
``IndustryAnalyticsEngine.batch_analyze`` output.

``batch_analyze`` takes ~5 seconds on a 463-symbol × 34-industry
panel (measured). Its output is a ``dict[str, IndustryRelativeState]``
that's a pure function of the enriched panel plus the engine's
tunable constants. Today this compute happens on every launch because
the output isn't persisted.

This module caches that dict to a single pickle file. The cache is
invalidated by two signals:

1. **Schema drift**. The file path includes a composite schema hash
   combining ``StrategyComputeEngine.enrichment_schema_hash()`` +
   ``IndustryAnalyticsEngine.analytics_schema_hash()``. Any constant
   change or dataclass-field change in either engine produces a
   different hash → fresh file path → old cache becomes unreachable
   (but harmless on disk).

2. **Freshness**. The cache file's mtime is compared against the
   latest mtime inside the enriched cache directory. If any enriched
   parquet has been written since the cache was last saved, the
   states cache is stale and must be recomputed.

Why pickle and not JSON: the cached value is a dict keyed by string
symbols with ``IndustryRelativeState`` (frozen dataclass) values
containing NaN-bearing floats, tuples, and booleans. Pickle
roundtrips all of this natively at ~10× the speed of JSON for this
payload. Schema-hash gating means we never read an old pickle with
a changed dataclass definition — the hash changes when the fields
change, making the old file unreachable by path.
"""
from __future__ import annotations

import logging
import os
import pickle
import tempfile
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


#: Fixed filename inside the per-schema subdirectory. Single file —
#: the batch output is atomic, not per-symbol.
_CACHE_FILENAME = "batch.pickle"


class IndustryStatesCache:
    """Persistent cache of ``batch_analyze`` output.

    Usage::

        cache = IndustryStatesCache(
            enriched_root=Path("data/cache/equity_enriched/{hash}"),
            schema_hash=f"{enrichment_hash}-{analytics_hash}",
        )
        hit = cache.get_if_fresh()
        if hit is None:
            states = engine.batch_analyze(panel, industry_map)
            cache.set(states)

    The cache is single-keyed (one value per schema namespace), so
    there's no ``key`` parameter on ``get``/``set``. Thread-safe for
    reads; concurrent writes are last-writer-wins via atomic rename.
    """

    def __init__(
        self,
        *,
        enriched_root: Path,
        schema_hash: str,
        root: Path | None = None,
    ) -> None:
        """Args:
            enriched_root: Path to the enriched-cache subdirectory whose
                mtime tracks when any enriched file was last written.
                Typically ``data/cache/equity_enriched/{hash}``.
                Freshness is determined by comparing this directory's
                newest-file mtime against the cache file's mtime.
            schema_hash: Composite hash combining the enrichment recipe
                and analytics engine versions. Namespaces the cache
                file so schema drift is transparently handled.
            root: Base directory. ``None`` (default) → resolves via
                :func:`nimbus_v3.data.paths.cache_dir` so the
                directory tracks the ``NIMBUS_DATA_DIR`` env override.
                Per-hash subdir created below.
        """
        self._enriched_root = Path(enriched_root)
        self._schema_hash = schema_hash
        if root is None:
            from nimbus_v3.data.paths import cache_dir
            root = cache_dir("industry_states")
        self._root = Path(root)
        self._ns_dir = self._root / schema_hash
        self._ns_dir.mkdir(parents=True, exist_ok=True)
        self._file_path = self._ns_dir / _CACHE_FILENAME

    # ══════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════

    def get_if_fresh(self) -> Any | None:
        """Return the cached batch output iff fresh. ``None`` when
        missing, stale, or unreadable.

        Staleness rule: if the newest file inside the enriched-cache
        directory has an mtime strictly after this cache file's mtime,
        the cache is stale. Equal mtimes count as fresh (covers the
        "identical clock tick" case on fast filesystems).
        """
        if not self._file_path.is_file():
            return None

        cache_mtime = self._file_path.stat().st_mtime
        enriched_mtime = self._newest_enriched_mtime()
        if enriched_mtime is not None and enriched_mtime > cache_mtime:
            return None    # stale

        try:
            with self._file_path.open("rb") as f:
                return pickle.load(f)
        except Exception:    # noqa: BLE001
            # Corrupt or version-incompatible pickle. Remove it so the
            # next call returns None deterministically.
            logger.warning(
                "industry_states_cache: corrupt pickle; removing",
            )
            try:
                self._file_path.unlink()
            except OSError:
                pass
            return None

    def set(self, states: Any) -> None:
        """Persist the batch output atomically. Overwrites any
        existing cache file via tmp+rename."""
        with tempfile.NamedTemporaryFile(
            mode="wb",
            suffix=".tmp",
            dir=self._ns_dir,
            delete=False,
        ) as tmp:
            tmp_path = Path(tmp.name)
            pickle.dump(states, tmp, protocol=pickle.HIGHEST_PROTOCOL)
        try:
            os.replace(tmp_path, self._file_path)
        except Exception:
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass
            raise

    def exists(self) -> bool:
        """True if there's a cache file, regardless of freshness."""
        return self._file_path.is_file()

    # ══════════════════════════════════════════════════════════════════
    # Internals
    # ══════════════════════════════════════════════════════════════════

    def _newest_enriched_mtime(self) -> float | None:
        """Return the max mtime across all files in the enriched-cache
        directory, or ``None`` if the directory is empty or missing.

        Scans all entries; for a 463-symbol directory this is ~0.5ms
        total (stat is cheap). No caching — each call re-walks so a
        concurrent enrichment write is correctly detected.
        """
        if not self._enriched_root.is_dir():
            return None
        newest: float | None = None
        for entry in self._enriched_root.iterdir():
            try:
                mtime = entry.stat().st_mtime
            except OSError:
                continue
            if newest is None or mtime > newest:
                newest = mtime
        return newest

    @property
    def schema_hash(self) -> str:
        """The schema hash this cache is keyed to. Exposed for
        diagnostic logging."""
        return self._schema_hash

    @property
    def file_path(self) -> Path:
        """Location of the pickle file. Exposed for diagnostic
        logging and manual inspection."""
        return self._file_path
