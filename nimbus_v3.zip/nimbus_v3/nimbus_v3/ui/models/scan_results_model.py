"""nimbus_v3.ui.models.scan_results_model — Qt table model for scan results.

Separates data (``list[ScanResult]``) from presentation (the view).
Qt's model/view pattern means the view never knows about ``ScanResult``
directly — it asks the model for cell values and display hints.

The model is **read-only from the view's perspective.** Updating the
data goes through :meth:`set_results`, which emits the appropriate
``beginResetModel`` / ``endResetModel`` signals.

Columns (in display order)
──────────────────────────

0. Symbol
1. Strategy
2. Grade (color-coded)
3. Verdict
4. Sizing
5. Score (right-aligned, 2dp)
6. Reason (top-3 weighted contributions, or override reason)

The model keeps ``ScanResult`` references so selection handlers can
pull the full object back out via :meth:`result_at`.
"""
from __future__ import annotations

from typing import Final

from PyQt6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PyQt6.QtGui import QBrush, QColor

from nimbus_v3.scanner.engine import ScanResult


# Column indices as module constants for testing / indexing safety.
COL_SYMBOL: Final[int] = 0
COL_STRATEGY: Final[int] = 1
COL_GRADE: Final[int] = 2
COL_VERDICT: Final[int] = 3
COL_SIZING: Final[int] = 4
COL_SCORE: Final[int] = 5
COL_REASON: Final[int] = 6
N_COLS: Final[int] = 7

_HEADERS: Final[tuple[str, ...]] = (
    "Symbol", "Strategy", "Grade", "Verdict", "Sizing", "Score", "Reason",
)


# ── Color palette ─────────────────────────────────────────────────────────────
# Single source of truth lives in nimbus_v3.ui.theme — these wrappers map
# the canonical colour helpers from there into the Qt model layer.

from nimbus_v3.ui.theme import (
    GREEN, MUTED, RED,
    grade_fg, sizing_fg, verdict_fg,
)


def _top_reason(result: ScanResult) -> str:
    """Synthesise a short reason string from the top 3 weighted contributions.

    Mirrors the output format used in ``scripts/scan.py::_format_reason``
    so the UI and CLI show consistent reason strings.
    """
    conviction = result.conviction
    if conviction.override_reason:
        return conviction.override_reason
    contribs = sorted(
        conviction.contributions,
        key=lambda c: abs(c.weighted),
        reverse=True,
    )[:3]
    parts = [
        f"{c.name}={c.weighted:+.1f}"
        for c in contribs if abs(c.weighted) > 0.05
    ]
    return "; ".join(parts) if parts else "no dominant factor"


class ScanResultsModel(QAbstractTableModel):
    """Qt table model backed by a list of ``ScanResult``s."""

    def __init__(self, results: list[ScanResult] | None = None, parent=None) -> None:
        super().__init__(parent)
        self._results: list[ScanResult] = list(results or [])

    # ══════════════════════════════════════════════════════════════════════
    # Data mutation
    # ══════════════════════════════════════════════════════════════════════

    def set_results(self, results: list[ScanResult]) -> None:
        """Replace the backing list. Emits model-reset signals."""
        self.beginResetModel()
        self._results = list(results)
        self.endResetModel()

    def result_at(self, row: int) -> ScanResult | None:
        """Return the raw ``ScanResult`` for display row ``row``, or None."""
        if 0 <= row < len(self._results):
            return self._results[row]
        return None

    # ══════════════════════════════════════════════════════════════════════
    # Qt model interface
    # ══════════════════════════════════════════════════════════════════════

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:   # noqa: B008
        return 0 if parent.isValid() else len(self._results)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:   # noqa: B008
        return 0 if parent.isValid() else N_COLS

    def headerData(
        self, section: int,
        orientation: Qt.Orientation,
        role: int = Qt.ItemDataRole.DisplayRole,
    ):
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal and 0 <= section < N_COLS:
            return _HEADERS[section]
        if orientation == Qt.Orientation.Vertical:
            return str(section + 1)
        return None

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row, col = index.row(), index.column()
        if not (0 <= row < len(self._results)):
            return None
        result = self._results[row]
        conv = result.conviction

        if role == Qt.ItemDataRole.DisplayRole:
            if col == COL_SYMBOL:
                return result.symbol
            if col == COL_STRATEGY:
                return result.strategy.name
            if col == COL_GRADE:
                return conv.grade.value
            if col == COL_VERDICT:
                return conv.verdict.value
            if col == COL_SIZING:
                return conv.sizing.value
            if col == COL_SCORE:
                return f"{conv.score:+.2f}"
            if col == COL_REASON:
                return _top_reason(result)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if col == COL_SCORE:
                return int(
                    Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
                )
            if col in (COL_GRADE, COL_VERDICT, COL_SIZING):
                return int(
                    Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter
                )
            return int(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
            )

        if role == Qt.ItemDataRole.ForegroundRole:
            if col == COL_GRADE:
                return QBrush(QColor(grade_fg(conv.grade.value)))
            if col == COL_VERDICT:
                return QBrush(QColor(verdict_fg(conv.verdict.value)))
            if col == COL_SIZING:
                return QBrush(QColor(sizing_fg(conv.sizing.value)))
            if col == COL_SCORE:
                if conv.score > 0.05:
                    return QBrush(QColor(GREEN))
                if conv.score < -0.05:
                    return QBrush(QColor(RED))
                return QBrush(QColor(MUTED))

        return None

    # ══════════════════════════════════════════════════════════════════════
    # Sort support — delegated by QSortFilterProxyModel.
    # ══════════════════════════════════════════════════════════════════════

    def sort_key(self, row: int, col: int):
        """Return a sort key for the given (row, column) cell.

        Numeric columns (Score) sort numerically; enum columns
        (Grade/Verdict/Sizing) sort by their canonical order.
        """
        if not (0 <= row < len(self._results)):
            return ""
        conv = self._results[row].conviction
        if col == COL_SCORE:
            return conv.score
        if col == COL_GRADE:
            return _GRADE_ORDER.get(conv.grade.value, 99)
        if col == COL_VERDICT:
            return _VERDICT_ORDER.get(conv.verdict.value, 99)
        if col == COL_SIZING:
            return _SIZING_ORDER.get(conv.sizing.value, 99)
        if col == COL_SYMBOL:
            return self._results[row].symbol
        if col == COL_STRATEGY:
            return self._results[row].strategy.name
        if col == COL_REASON:
            return _top_reason(self._results[row])
        return ""


# Canonical sort orders for enum-valued columns.
_GRADE_ORDER: Final[dict[str, int]] = {"A": 0, "B": 1, "C": 2, "D": 3}
_VERDICT_ORDER: Final[dict[str, int]] = {"TAKE": 0, "WATCH": 1, "SKIP": 2}
_SIZING_ORDER: Final[dict[str, int]] = {"FULL": 0, "HALF": 1, "SKIP": 2}
