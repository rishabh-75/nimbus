"""nimbus_v3.strategies.aggressive_mean_reversion_tracking — tracking-tier MR.

Companion to :class:`AggressiveMeanReversionStrategy`. The production
strategy applies oracle's full primary-tier MR gates (WR<-30, MFI>=30,
DD<=-8%, red_streak>=4, vol_ratio>=1.5). This tracking strategy
captures the broader "developing oversold" population — symbols that
are oversold on one or two dimensions but don't yet meet the full
primary-tier criteria.

Matches the same design as :mod:`.aggressive_ride_tracking`: two
strategies that share the MR bucket via ``setup_type`` but split
responsibility by ``production_weight``. Fresh primary-tier entries
get real grades; developing-oversold tracking entries get the
research-override (grade=D, verdict=WATCH, sizing=SKIP).

Intent
──────

The operator scanning the MR panel in aggressive mode expects to
see every oversold candidate worth watching, not only the ones
that passed all five strict gates simultaneously. A stock 10% off
its 50-day high with WR=-35 but vol_ratio=0.9 is a legitimate MR
watchlist entry; the production strategy rejects it for the volume
miss. Tracking catches it.

De-duplication
──────────────

When the production gates would fire for a bar, this tracking
strategy returns None. Prevents double-emission in the MR bucket.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.core.context import ContextBundle
from nimbus_v3.core.signal_state import SignalState
from nimbus_v3.core.types import SetupType
from nimbus_v3.core.universe import SymbolMeta
from nimbus_v3.strategies.base import StrategySignal


# ══════════════════════════════════════════════════════════════════════════════
# Gate parameters — only the core oversold gate is required here.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class AggressiveMeanReversionTrackingParams:
    #: The only hard gate — WR<-30 is the MR regime marker per oracle.
    #: Everything else (MFI / DD / streak / volume) is on the
    #: production-tier sibling; this tracking tier emits as long as
    #: the symbol is genuinely oversold.
    wr_30_max: float = -30.0


#: Primary-tier gates from AggressiveMeanReversion for de-dupe. If
#: ALL five of these pass, production fires; this tracking strategy
#: returns None so the symbol doesn't double-appear in the MR panel.
_PRIMARY_MFI_MIN: float = 30.0
_PRIMARY_DD_MAX: float = -8.0           # signed: ≤ -8 means ≥8% off high
_PRIMARY_RED_STREAK_MIN: int = 4
_PRIMARY_VOL_RATIO_MIN: float = 1.5


class AggressiveMeanReversionTrackingStrategy:
    """Developing-oversold MR tracking. Rejects ETFs.

    Routes to the same MR bucket as
    :class:`AggressiveMeanReversionStrategy` via shared setup_type,
    but the weight=0 production-weight triggers the conviction
    research-override so these show as grade=D / verdict=WATCH /
    sizing=SKIP rows in the Scanner MR table — ungraded tracking
    alongside the real graded entries.
    """

    name: str = "AggressiveMeanReversionTracking"
    setup_type: SetupType = SetupType.MEAN_REVERSION
    priority: int = 45          # below AggressiveMR's 50 — tracking sorts after entries
    production_weight: float = 0.0

    def __init__(
        self,
        params: AggressiveMeanReversionTrackingParams
        = AggressiveMeanReversionTrackingParams(),
    ) -> None:
        self._p = params

    def accepts(self, symbol_meta: SymbolMeta) -> bool:
        return not symbol_meta.is_etf

    def evaluate(
        self,
        *,
        symbol: str,
        state: SignalState,
        contexts: ContextBundle,    # noqa: ARG002 — purely state-driven
    ) -> StrategySignal | None:
        # Core: WR oversold. This is the MR regime marker.
        if state.wr_30 >= self._p.wr_30_max:
            return None
        # Trend gate from production (keeps semantic "below trend"
        # consistent with AggressiveMR — an oversold stock above
        # its SMA_20 is uptrend pullback, not reversion).
        if state.above_sma_20:
            return None
        if state.sma_20 <= 0:
            return None

        # De-dupe: if ALL primary-tier gates would fire, let the
        # production AggressiveMeanReversion emit instead.
        primary_fires = (
            state.mfi_14 >= _PRIMARY_MFI_MIN
            and state.dd_from_high_50 <= _PRIMARY_DD_MAX
            and state.red_streak >= _PRIMARY_RED_STREAK_MIN
            and state.vol_ratio_20 >= _PRIMARY_VOL_RATIO_MIN
        )
        if primary_fires:
            return None

        return StrategySignal(
            strategy_name=self.name,
            symbol=symbol,
            setup_type=self.setup_type,
            asof_date=pd.Timestamp(state.bar_date),
            priority=self.priority,
            metadata={
                "wr_30": state.wr_30,
                "mfi_14": state.mfi_14,
                "dd_from_high_50": state.dd_from_high_50,
                "red_streak": state.red_streak,
                "vol_ratio_20": state.vol_ratio_20,
                "pct_from_sma_20": state.pct_from_sma_20,
                "kind": "tracking",
            },
        )
