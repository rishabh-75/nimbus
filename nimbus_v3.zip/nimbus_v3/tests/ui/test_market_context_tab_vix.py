"""tests.ui.test_market_context_tab_vix — VIX pace badge + per-industry
directional arrows on Market Pulse tab.

Tests the set_vix_state() → badge/label update path and the
_vix_arrow_for_group helper that decides when to render ↑/↓
arrows next to industry names.
"""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.compute.vix_pace import (
    REGIME_FALLING, REGIME_RISING, REGIME_STABLE, REGIME_UNKNOWN,
    VIXPaceState,
)
from nimbus_v3.ui.theme import GREEN, MUTED, RED, WHITE
from nimbus_v3.ui.widgets.market_context_tab import MarketContextTab


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _state(regime: str, z: float = 1.2, run: int = 5, vix: float = 16.5):
    return VIXPaceState(
        regime=regime, slope_z=z, run_length=run, vix_close=vix,
    )


# ══════════════════════════════════════════════════════════════════════
# Initial state — placeholder before set_vix_state is called
# ══════════════════════════════════════════════════════════════════════

class TestInitialBadgeState:

    def test_placeholder_before_set_vix_state(self, qapp):
        """Before MainWindow pushes a VIX state, the badge shows the
        em-dash placeholder in MUTED color."""
        tab = MarketContextTab()
        assert tab._vix_regime_label.text() == "VIX: —"
        assert MUTED in tab._vix_regime_label.styleSheet()
        # State cache starts empty
        assert tab._vix_state is None


# ══════════════════════════════════════════════════════════════════════
# Badge updates via set_vix_state
# ══════════════════════════════════════════════════════════════════════

class TestSetVixState:

    def test_rising_regime_badge(self, qapp):
        tab = MarketContextTab()
        tab.set_vix_state(_state(REGIME_RISING))
        assert tab._vix_regime_label.text() == "VIX: RISING"
        assert RED in tab._vix_regime_label.styleSheet()

    def test_stable_regime_badge(self, qapp):
        tab = MarketContextTab()
        tab.set_vix_state(_state(REGIME_STABLE))
        assert tab._vix_regime_label.text() == "VIX: STABLE"
        assert WHITE in tab._vix_regime_label.styleSheet()

    def test_falling_regime_badge(self, qapp):
        tab = MarketContextTab()
        tab.set_vix_state(_state(REGIME_FALLING))
        assert tab._vix_regime_label.text() == "VIX: FALLING"
        assert GREEN in tab._vix_regime_label.styleSheet()

    def test_unknown_regime_badge(self, qapp):
        """UNKNOWN during baseline warmup → placeholder. Badge should
        not render 'VIX: UNKNOWN' text — same treatment as None."""
        tab = MarketContextTab()
        tab.set_vix_state(_state(REGIME_UNKNOWN))
        assert tab._vix_regime_label.text() == "VIX: —"
        assert MUTED in tab._vix_regime_label.styleSheet()

    def test_none_resets_badge(self, qapp):
        """If VIX load fails after a previous successful state,
        passing None resets the badge cleanly."""
        tab = MarketContextTab()
        tab.set_vix_state(_state(REGIME_RISING))
        assert tab._vix_regime_label.text() == "VIX: RISING"
        tab.set_vix_state(None)
        assert tab._vix_regime_label.text() == "VIX: —"
        assert MUTED in tab._vix_regime_label.styleSheet()

    def test_repeated_calls_safe(self, qapp):
        """Setter can be invoked multiple times without errors."""
        tab = MarketContextTab()
        for regime in (REGIME_RISING, REGIME_STABLE, REGIME_FALLING,
                       REGIME_RISING, REGIME_UNKNOWN):
            tab.set_vix_state(_state(regime))


# ══════════════════════════════════════════════════════════════════════
# _vix_arrow_for_group — decides when to render ↑/↓
# ══════════════════════════════════════════════════════════════════════

class TestVixArrowForGroup:

    def test_stable_industry_rising_regime_returns_up_green(self, qapp):
        """Realty is in the stable-11 list with UP direction in
        RISING regime."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_RISING))
        arrow, color = tab._vix_arrow_for_group("Realty")
        assert arrow == "↑"
        assert color == GREEN

    def test_stable_industry_stable_regime_returns_down_red(self, qapp):
        """Realty DOWN in STABLE regime."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_STABLE))
        arrow, color = tab._vix_arrow_for_group("Realty")
        assert arrow == "↓"
        assert color == RED

    def test_stable_industry_falling_regime_returns_neutral(self, qapp):
        """FALLING-regime cells didn't pass stability — all stable
        industries return no arrow in FALLING."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_FALLING))
        arrow, color = tab._vix_arrow_for_group("Realty")
        assert arrow == ""
        assert color == ""

    def test_non_stable_industry_returns_neutral(self, qapp):
        """Banks is NOT in the stable-11 — no arrow regardless of
        regime."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        for regime in (REGIME_RISING, REGIME_STABLE, REGIME_FALLING):
            tab.set_vix_state(_state(regime))
            arrow, _ = tab._vix_arrow_for_group("Banks")
            assert arrow == ""

    def test_non_industry_level_returns_neutral(self, qapp):
        """Research was validated at Industry granularity only. No
        arrow when the level selector is on Sector or Macro."""
        tab = MarketContextTab()
        tab.set_vix_state(_state(REGIME_RISING))
        for level in ("sector", "macro-economic sector", "basic industry"):
            tab._current_level = level
            arrow, _ = tab._vix_arrow_for_group("Realty")
            assert arrow == ""

    def test_no_vix_state_returns_neutral(self, qapp):
        """Before set_vix_state is called, no arrows render."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        arrow, _ = tab._vix_arrow_for_group("Realty")
        assert arrow == ""

    def test_unknown_regime_returns_neutral(self, qapp):
        """UNKNOWN during warmup → no arrows."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_UNKNOWN))
        arrow, _ = tab._vix_arrow_for_group("Realty")
        assert arrow == ""

    def test_all_eleven_stable_industries_arrow_in_rising(self, qapp):
        """Spot-check that every industry in the stable-11 list
        produces an UP arrow in RISING regime. Coherent check that
        the data layer wiring is consistent."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_RISING))
        expected_up = (
            "Aerospace & Defense",
            "Auto Components",
            "Chemicals & Petrochemicals",
            "Electrical Equipment",
            "Fertilizers & Agrochemicals",
            "IT - Services",
            "Leisure Services",
            "Power",
            "Realty",
            "Telecom - Services",
            "Transport Services",
        )
        for industry in expected_up:
            arrow, color = tab._vix_arrow_for_group(industry)
            assert arrow == "↑", f"{industry} should have UP arrow in RISING"
            assert color == GREEN, f"{industry} color should be GREEN in RISING"


# ══════════════════════════════════════════════════════════════════════
# Arrow prefix must NOT pollute constituent-lookup path
# ══════════════════════════════════════════════════════════════════════

class TestArrowPrefixDoesNotBreakConstituentLookup:
    """Regression tests for the bug where the ↑/↓ display prefix
    leaked into the industry-name lookup key. Group cells now store
    the raw industry name on UserRole and display text may carry the
    arrow prefix, but the lookup key is always clean."""

    def _populate_group_table(self, tab, industry_names):
        """Simulate what _render_table does for the Group column —
        create cells with display text AND UserRole raw name."""
        from PyQt6.QtCore import Qt
        from PyQt6.QtWidgets import QTableWidgetItem

        tab._table.setRowCount(len(industry_names))
        for row_idx, name in enumerate(industry_names):
            arrow, _ = tab._vix_arrow_for_group(name)
            item = QTableWidgetItem()
            item.setData(Qt.ItemDataRole.UserRole, name)
            if arrow:
                item.setText(f"{arrow} {name}")
            else:
                item.setText(name)
            tab._table.setItem(row_idx, 0, item)

    def test_display_text_has_arrow_but_userrole_is_raw(self, qapp):
        """Bug reproducer: in RISING regime, Aerospace & Defense
        cell displays '↑ Aerospace & Defense' but UserRole carries
        'Aerospace & Defense' cleanly."""
        from PyQt6.QtCore import Qt

        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_RISING))
        self._populate_group_table(tab, ["Aerospace & Defense", "Banks"])

        # Row 0: stable industry — display has arrow, UserRole raw
        cell_0 = tab._table.item(0, 0)
        assert cell_0.text() == "↑ Aerospace & Defense"
        assert cell_0.data(Qt.ItemDataRole.UserRole) == "Aerospace & Defense"

        # Row 1: non-stable — display and UserRole both raw
        cell_1 = tab._table.item(1, 0)
        assert cell_1.text() == "Banks"
        assert cell_1.data(Qt.ItemDataRole.UserRole) == "Banks"

    def test_selection_reads_userrole_not_text(self, qapp):
        """After selecting a stable-industry row, _on_group_selection_changed
        must look up members by raw name — not the '↓ Name' display
        text that would miss in _group_members."""
        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_STABLE))
        self._populate_group_table(tab, ["Realty", "Banks"])

        # Prime _group_members keyed by raw name (same as production)
        tab._group_members = {
            "Realty":    ["DLFLTD", "GODREJPROP", "OBEROIRLTY"],
            "Banks":     ["HDFCBANK", "ICICIBANK"],
        }

        # Select row 0 (Realty, which in STABLE displays as "↓ Realty")
        tab._table.selectRow(0)
        # _on_group_selection_changed fires synchronously off
        # selectRow via the signal connection in _build_ui. If the
        # bug were present, the header would read "↓ Realty (0 symbols)".
        # With the fix, it reads "Realty (3 symbols)".
        header_text = tab._constituent_header.text()
        assert "Realty" in header_text
        assert "↓" not in header_text
        assert "(3 symbols)" in header_text

    def test_fallback_when_userrole_not_set(self, qapp):
        """Defensive fallback: if a cell is populated without
        UserRole (legacy code path), the handler strips a leading
        arrow prefix from the display text."""
        from PyQt6.QtCore import Qt
        from PyQt6.QtWidgets import QTableWidgetItem

        tab = MarketContextTab()
        tab._current_level = "industry"
        tab.set_vix_state(_state(REGIME_RISING))

        # Populate a cell deliberately without UserRole
        tab._table.setRowCount(1)
        item = QTableWidgetItem()
        item.setText("↑ Power")
        # Intentionally NOT calling setData(UserRole, ...)
        tab._table.setItem(0, 0, item)

        tab._group_members = {"Power": ["NTPC", "POWERGRID"]}
        tab._table.selectRow(0)

        # Fallback should strip the arrow and find Power
        header_text = tab._constituent_header.text()
        assert "Power" in header_text
        assert "↑" not in header_text
        assert "(2 symbols)" in header_text
