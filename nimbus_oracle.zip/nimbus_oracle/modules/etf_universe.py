"""
modules/etf_universe.py — Single source of truth for NSE ETF data.

Fetches the full ETF list from NSE /api/etf once at startup.
Provides NAV lookup, premium/discount, category classification, AUM, and symbol lists.
Read-only after __init__ — safe for worker threads to read without locks.

Cache TTL: 24 hours. ETF list does not change intraday.
NAV precision: end-of-day snapshot from NSE.
  Premium = (Spot - NAV) / NAV — a quality signal for sector rotation scoring,
  not a trading trigger — daily precision is sufficient.

Usage:
    universe = ETFUniverse()         # fetches once from NSE
    nav = universe.get_nav("GOLDBEES")
    premium = universe.get_premium_pct("GOLDBEES", spot=119.92)
    symbols = universe.get_all_symbols()
    is_etf = universe.is_etf("GOLDBEES")
"""
import logging
import time
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# ── Category classification by keyword matching on scheme name / underlying ──
_CATEGORY_RULES = [
    # (keywords_in_name, category)
    (["gold"], "gold"),
    (["silver"], "silver"),
    (["liquid", "overnight", "money market"], "debt"),
    (["gilt", "bond", "g-sec", "sdl", "10 year", "5 year"], "debt"),
    (["nifty 50", "sensex", "bse 100", "nifty 100"], "equity_index"),
    (["nifty next 50", "nifty midcap", "midcap 150", "smallcap"], "equity_broad"),
    (["bank", "financial", "fin service"], "banking"),
    (["it", "technology", "digital"], "technology"),
    (["pharma", "health", "healthcare"], "healthcare"),
    (["infra", "infrastructure", "cpse", "psu"], "psu_infra"),
    (["auto", "automobile"], "auto"),
    (["fmcg", "consumption", "consumer"], "consumer"),
    (["metal", "commodit"], "commodity"),
    (["energy", "oil", "gas"], "energy"),
    (["real", "realty"], "realty"),
    (["momentum", "alpha", "low vol", "value", "quality", "equal"], "factor"),
    (["nasdaq", "s&p 500", "hang seng", "world", "international", "us"], "international"),
    (["media"], "media"),
    (["defence", "defense"], "defence"),
]


@dataclass
class ETFRecord:
    """Single ETF record from NSE /api/etf response."""
    symbol: str
    name: str           # scheme name
    category: str       # classified from name/underlying
    underlying: str     # tracked index name
    nav: Optional[float] = None
    aum_cr: float = 0.0
    ter: float = 0.0    # total expense ratio
    last_price: float = 0.0


def _classify_category(name: str, underlying: str) -> str:
    """Classify ETF into a category based on name and underlying index."""
    combined = f"{name} {underlying}".lower()
    for keywords, category in _CATEGORY_RULES:
        if any(kw in combined for kw in keywords):
            return category
    return "other"


def _parse_float(val) -> Optional[float]:
    """Safely parse a float from NSE's sometimes messy data."""
    if val is None or val == "" or val == "-" or val == "NA":
        return None
    try:
        return float(str(val).replace(",", "").strip())
    except (ValueError, TypeError):
        return None


class ETFUniverse:
    """
    Immutable ETF universe fetched from NSE at construction time.

    Thread safety: read-only after __init__. Workers may call any
    getter without locks. Never mutate _records or _by_symbol.
    """

    def __init__(self, client=None):
        """
        Fetch ETF list from NSE. Falls back to empty if NSE is unreachable.

        Args:
            client: Optional NSEClient instance. Uses shared singleton if not provided.
        """
        self._records: list[ETFRecord] = []
        self._by_symbol: dict[str, ETFRecord] = {}
        self._fetch_ts: float = 0.0
        self._load(client)

    def _load(self, client=None):
        """Fetch and parse ETF data from NSE."""
        try:
            if client is None:
                from modules.nse_client import get_shared_client
                client = get_shared_client()

            raw = client.fetch_etf()
            rows = raw if isinstance(raw, list) else raw.get("data", [])

            records = []
            for row in rows:
                sym = str(row.get("symbol", "")).strip().upper()
                if not sym:
                    continue

                name = str(row.get("etfScheme", row.get("companyName", "")))
                underlying = str(row.get("underlyingIndex", row.get("underlying", "")))

                rec = ETFRecord(
                    symbol=sym,
                    name=name,
                    category=_classify_category(name, underlying),
                    underlying=underlying,
                    nav=_parse_float(row.get("nav")),
                    aum_cr=_parse_float(row.get("aum")) or 0.0,
                    ter=_parse_float(row.get("ter") or row.get("expenseRatio")) or 0.0,
                    last_price=_parse_float(
                        row.get("ltP") or row.get("lastPrice") or row.get("close")
                    ) or 0.0,
                )
                records.append(rec)

            self._records = records
            self._by_symbol = {r.symbol: r for r in records}
            self._fetch_ts = time.time()
            logger.info("ETFUniverse: loaded %d ETFs from NSE", len(records))

        except Exception as exc:
            logger.warning("ETFUniverse: NSE fetch failed (%s) — empty universe", exc)
            self._records = []
            self._by_symbol = {}
            # Set timestamp with short cooldown (5 min) to prevent retry storm.
            # Without this, is_stale returns True forever → infinite retry loop.
            self._fetch_ts = time.time() - 86400 + 300  # stale in 5 min, not immediately

    # ── Lookups ───────────────────────────────────────────────────────────

    def is_etf(self, symbol: str) -> bool:
        """Check if a symbol is in the NSE ETF universe."""
        return symbol.strip().upper() in self._by_symbol

    def get(self, symbol: str) -> Optional[ETFRecord]:
        """Get full ETF record, or None."""
        return self._by_symbol.get(symbol.strip().upper())

    def get_nav(self, symbol: str) -> Optional[float]:
        """Get NAV for an ETF symbol. None if not found or unavailable."""
        rec = self.get(symbol)
        return rec.nav if rec else None

    def get_premium_pct(self, symbol: str, spot: float = None) -> Optional[float]:
        """
        Compute ETF premium/discount vs NAV as percentage.

        Premium = (Spot - NAV) / NAV × 100
          +ve = premium (overpaying vs underlying)
          -ve = discount (buying below underlying value)

        Args:
            symbol: ETF symbol
            spot: market price. Uses NSE last_price if not provided.
        """
        rec = self.get(symbol)
        if not rec or not rec.nav or rec.nav <= 0:
            return None
        price = spot if spot is not None else rec.last_price
        if not price or price <= 0:
            return None
        return round((price - rec.nav) / rec.nav * 100, 3)

    def get_category(self, symbol: str) -> str:
        """Get category classification. Returns 'other' if not found."""
        rec = self.get(symbol)
        return rec.category if rec else "other"

    def get_aum(self, symbol: str) -> float:
        """Get AUM in Crores. Returns 0 if not found."""
        rec = self.get(symbol)
        return rec.aum_cr if rec else 0.0

    # ── Lists ─────────────────────────────────────────────────────────────

    def get_all_symbols(self) -> list[str]:
        """All ETF symbols from NSE, sorted."""
        return sorted(self._by_symbol.keys())

    def get_symbols_by_category(self, category: str) -> list[str]:
        """ETF symbols filtered by category."""
        return sorted(r.symbol for r in self._records if r.category == category)

    def get_momentum_universe(self) -> list[str]:
        """
        ETF symbols suitable for the momentum scanner.
        Excludes debt/liquid ETFs (no trending behavior).
        """
        exclude = {"debt"}
        return sorted(
            r.symbol for r in self._records
            if r.category not in exclude and "LIQ" not in r.symbol.upper()
        )

    @property
    def size(self) -> int:
        return len(self._records)

    @property
    def fetch_ts(self) -> float:
        return self._fetch_ts

    @property
    def is_stale(self) -> bool:
        """True if data is older than 24 hours."""
        return time.time() - self._fetch_ts > 86400

    # ── Backward compat ───────────────────────────────────────────────────

    def as_symbol_set(self) -> set[str]:
        """For code that checks `symbol in NSE_ETF_SYMBOLS`."""
        return set(self._by_symbol.keys())


# ── Module-level singleton (24h cache) ────────────────────────────────────────
# All NAV lookups route through get_universe() which returns the cached instance.
# New fetch only happens if cache is stale (>24h) or not yet initialized.

_INSTANCE: Optional[ETFUniverse] = None


def get_universe(client=None) -> ETFUniverse:
    """
    Get the cached ETFUniverse singleton. Creates on first call.
    Thread-safe for reads — ETFUniverse is immutable after __init__.
    """
    global _INSTANCE
    if _INSTANCE is None or _INSTANCE.is_stale:
        _INSTANCE = ETFUniverse(client=client)
    return _INSTANCE
