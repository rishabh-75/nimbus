"""Tests for the momentum-implied equity edge engine."""
import numpy as np
import pandas as pd

from nimbus_v3.compute.confluence import (
    ConfluenceResult,
    ConfluenceRow,
    FactorRead,
)
from nimbus_v3.compute.industry_rotation import (
    IndustryRotation,
    RotationResult,
)
from nimbus_v3.compute.equity_edge import compute_equity_edge


def _fr(v=0.0, p=50.0, c=1.0):
    return FactorRead(value=v, percentile=p, confidence=c, detail="")


def _conf(rows):
    """rows: list of (industry, trust)."""
    crows = tuple(
        ConfluenceRow(
            industry=ind, score=50.0, confidence=trust,
            strength=_fr(), direction=_fr(), seasonal=_fr(),
            n_members=6)
        for ind, trust in rows)
    return ConfluenceResult(
        rows=crows, month=7, regime_label="—",
        regime_signals_on=0, regime_n_signals=0)


def _rot(rows):
    """rows: list of (industry, roc)."""
    inds = tuple(
        IndustryRotation(industry=ind, dates=(), cum_return=(),
                         roc=roc, n_members=6)
        for ind, roc in rows)
    return RotationResult(industries=inds, lookback=20)


def _series(total_ret_pct, n=30, lookback=20, adtv=5e10):
    """A close series whose return over the trailing ``lookback`` bars is
    exactly ``total_ret_pct``. Flat before the window so the engine's
    trailing-window read matches the stated number. ``adtv`` sets the
    average daily traded value (default ₹5,000cr — well above the liquidity
    ceiling, so the liquidity gate is 1.0 and doesn't perturb edge-math
    tests unless a test deliberately lowers it)."""
    pre = n - lookback
    end = 100.0 * (1 + total_ret_pct / 100.0)
    ramp = np.linspace(100.0, end, lookback)
    c = np.concatenate([np.full(pre, 100.0), ramp])
    idx = pd.date_range("2025-01-01", periods=n, freq="B")
    # Volume chosen so Close×Volume ≈ adtv (Close ~100 in the flat region).
    vol = np.full(n, adtv / 100.0)
    return pd.DataFrame({
        "Close": c,
        "Volume": vol,
        "atr_14_pct": np.full(n, 2.0),
    }, index=idx)


def test_edge_shrunk_by_kappa_and_trust():
    """The industry edge = κ · RS_excess · trust. A high-trust strong
    industry produces a positive edge well below its raw RS (shrunk)."""
    conf = _conf([("Hot", 0.8)])
    rot = _rot([("Hot", 10.0)])          # +10% over window
    mbi = {"Hot": ["A"]}
    panel = {"A": _series(10.0)}
    bench = _series(2.0)["Close"]         # benchmark +2%
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, kappa=0.30, member_tilt=0.0)
    r = res.rows[0]
    # RS_excess = 10 - 2 = 8; edge = 0.30 * 8 * 0.8 = 1.92
    assert abs(r.industry_rs_excess - 8.0) < 1e-6
    assert abs(r.expected_edge - 0.30 * 8.0 * 0.8) < 1e-6
    # Shrunk well below the raw 8% excess.
    assert r.expected_edge < r.industry_rs_excess


def test_low_trust_shrinks_edge_toward_zero():
    """Same raw RS but low trust (narrow/fading confluence) → much
    smaller edge. Trust is the shrinkage that says 'we don't expect this
    to persist'."""
    rot = _rot([("X", 10.0)])
    mbi = {"X": ["A"]}
    panel = {"A": _series(10.0)}
    bench = _series(0.0)["Close"]
    hi = compute_equity_edge(_conf([("X", 0.9)]), rot, mbi, panel, bench,
                             lookback=20, member_tilt=0.0).rows[0]
    lo = compute_equity_edge(_conf([("X", 0.2)]), rot, mbi, panel, bench,
                             lookback=20, member_tilt=0.0).rows[0]
    assert hi.expected_edge > lo.expected_edge
    assert lo.expected_edge < 0.5 * hi.expected_edge


def test_member_shift_is_sign_correct_in_weak_industry():
    """A strong member in a WEAK (negative-edge) industry must be made
    LESS bad, not amplified downward — the additive member shift lifts it
    above a weak member of the same industry."""
    conf = _conf([("Weak", 0.4)])
    rot = _rot([("Weak", -6.0)])          # industry down 6%
    mbi = {"Weak": ["Leader", "Laggard"]}
    panel = {
        "Leader": _series(2.0),           # outperforms its -6% group
        "Laggard": _series(-12.0),        # underperforms
    }
    bench = _series(0.0)["Close"]
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, member_tilt=0.5)
    by = {r.symbol: r for r in res.rows}
    # Leader's within-group shift is positive, laggard's negative.
    assert by["Leader"].member_shift > 0
    assert by["Laggard"].member_shift < 0
    # And the leader ends up strictly better than the laggard.
    assert by["Leader"].expected_edge > by["Laggard"].expected_edge


def test_reward_to_risk_divides_by_atr():
    """Reward-to-risk = edge / ATR%. Two identical-edge symbols with
    different vol rank by the lower-vol one first."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["LowVol", "HighVol"]}
    lo = _series(10.0); lo["atr_14_pct"] = 1.0
    hi = _series(10.0); hi["atr_14_pct"] = 4.0
    panel = {"LowVol": lo, "HighVol": hi}
    bench = _series(0.0)["Close"]
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, member_tilt=0.0)
    by = {r.symbol: r for r in res.rows}
    # Same edge, but low-vol has higher reward-to-risk.
    assert abs(by["LowVol"].expected_edge
               - by["HighVol"].expected_edge) < 1e-9
    assert by["LowVol"].reward_to_risk > by["HighVol"].reward_to_risk
    # And it ranks first.
    assert res.rows[0].symbol == "LowVol"


def test_atr_floor_prevents_blowup():
    """A near-zero-vol symbol is floored so reward-to-risk can't explode."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["A"]}
    df = _series(10.0); df["atr_14_pct"] = 0.01   # absurdly low
    res = compute_equity_edge(conf, rot, mbi, {"A": df},
                              _series(0.0)["Close"], lookback=20,
                              member_tilt=0.0, min_atr_pct=0.5)
    assert res.rows[0].atr_pct == 0.5     # floored


def test_industry_without_trust_excluded():
    """An industry with no confluence trust (not a ranked candidate) is
    excluded — its members carry no edge."""
    conf = _conf([("Ranked", 0.7)])       # only Ranked has trust
    rot = _rot([("Ranked", 8.0), ("Orphan", 5.0)])
    mbi = {"Ranked": ["A"], "Orphan": ["B"]}
    panel = {"A": _series(8.0), "B": _series(5.0)}
    res = compute_equity_edge(conf, rot, mbi, panel,
                              _series(0.0)["Close"], lookback=20)
    syms = {r.symbol for r in res.rows}
    assert "A" in syms
    assert "B" not in syms


def test_liquidity_gate_crushes_thin_names():
    """A thin name (low ADTV) has its edge shrunk toward the liquidity
    floor, while a liquid name of identical momentum is untouched — the
    executability haircut, separate from ATR%."""
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    mbi = {"I": ["Liquid", "Thin"]}
    panel = {
        "Liquid": _series(10.0, adtv=5e10),   # ₹5,000cr — above ceiling
        "Thin": _series(10.0, adtv=2e8),      # ₹20cr — below floor
    }
    bench = _series(0.0)["Close"]
    res = compute_equity_edge(conf, rot, mbi, panel, bench,
                              lookback=20, member_tilt=0.0)
    by = {r.symbol: r for r in res.rows}
    assert by["Liquid"].liquidity_gate == 1.0
    assert by["Thin"].liquidity_gate < 0.5
    assert by["Thin"].expected_edge < by["Liquid"].expected_edge
    # member_tilt=0 so the only difference is the gate.
    assert abs(by["Thin"].expected_edge
               - by["Liquid"].expected_edge * by["Thin"].liquidity_gate) < 1e-9
    assert res.rows[0].symbol == "Liquid"


def test_nan_adtv_treated_as_thin():
    """A symbol with no volume data can't be confirmed tradeable, so it is
    treated as fully thin (gated to the floor), not given the benefit of
    the doubt."""
    from nimbus_v3.compute.market_pulse_config import EDGE_LIQUIDITY_FLOOR
    conf = _conf([("I", 0.8)])
    rot = _rot([("I", 10.0)])
    df = _series(10.0).drop(columns=["Volume"])   # no volume → NaN ADTV
    res = compute_equity_edge(conf, rot, {"I": ["A"]}, {"A": df},
                              _series(0.0)["Close"], lookback=20,
                              member_tilt=0.0)
    r = res.rows[0]
    assert r.adtv != r.adtv                        # NaN
    assert abs(r.liquidity_gate - EDGE_LIQUIDITY_FLOOR) < 1e-9


def test_deterministic_across_seeds():
    """Ranking is deterministic (sorted with a symbol tiebreak)."""
    conf = _conf([("I", 0.6)])
    rot = _rot([("I", 7.0)])
    mbi = {"I": [f"S{i}" for i in range(8)]}
    panel = {f"S{i}": _series(7.0 + i * 0.1) for i in range(8)}
    bench = _series(1.0)["Close"]
    order1 = [r.symbol for r in compute_equity_edge(
        conf, rot, mbi, panel, bench, lookback=20).rows]
    order2 = [r.symbol for r in compute_equity_edge(
        conf, rot, mbi, panel, bench, lookback=20).rows]
    assert order1 == order2
