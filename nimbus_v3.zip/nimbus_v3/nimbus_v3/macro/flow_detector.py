"""nimbus_v3.macro.flow_detector — multi-window price z-score detector.

Computes the foundational signals for the Macro Flow Panel:
- Price z-score over 10/30/60 day windows
- Most-recent close + N-day percent change for display

Future turns will extend ``MacroFlowResult`` with realised-vol z (9b),
carry slope z (9c), ratio context (9d), and leader z-score (9e). The
dataclass is built with optional fields so each turn can land
independently without breaking the schema.

Why three windows
─────────────────
A 60-day z-score crosses 2σ only after a sustained move; by then the
event is mature and the entry is poor. A 10-day z-score crosses 2σ
earlier in the trajectory because recent history hasn't yet absorbed
the new regime — but it's noisier (single outlier days fire it).

The pattern across the three windows tells you where in the move you
are:

- 10d hot, 30d warm, 60d cool   → early-stage event
- 10d cool, 30d hot, 60d warm   → mid-stage
- 10d cool, 30d warm, 60d hot   → mature trend

Single-window readings are not actionable on their own; the cross-
window pattern is.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd

from nimbus_v3.macro.universe import (
    COMMODITY_UNIVERSE, CommodityCategory, CommodityInstrument,
)


logger = logging.getLogger(__name__)


#: Z-score window lengths (in trading days).
PRICE_Z_WINDOWS: Final[tuple[int, ...]] = (10, 30, 60)

#: Minimum bars required to compute the longest window's z-score.
MIN_BARS_REQUIRED: Final[int] = max(PRICE_Z_WINDOWS) + 1


# ══════════════════════════════════════════════════════════════════════════════
# Result shape
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class MacroFlowResult:
    """One commodity's flow signals at an asof date.

    Optional fields default to ``None`` so future turns can extend the
    panel without breaking older detector outputs.
    """
    instrument: CommodityInstrument
    asof_date: pd.Timestamp
    close_price: float
    pct_change_1d: float
    pct_change_5d: float

    # Multi-window price z-scores. NaN when insufficient history.
    price_z_10d: float
    price_z_30d: float
    price_z_60d: float

    # Reserved for future turns:
    vol_z_20d: float | None = None      # Phase 9b
    carry_slope_z: float | None = None  # Phase 9c
    leader_z_10d: float | None = None   # Phase 9e

    #: ``True`` when this commodity shows a mean-reversion rebound
    #: signal: ``z_60d < -2`` AND the panel-wide vol regime is calm
    #: or normal (not volatile). Research from
    #: ``scripts/run_commodity_flow_research_v2.py`` validated this
    #: across 4 subsets on the 23-instrument × 6-year panel:
    #:   - cat=Agricultural:  Δ +1.75pp fwd-20d, t=+4.42, n=581
    #:   - regime=calm:       Δ +1.98pp fwd-20d, t=+3.79, n=277
    #:   - regime=normal:     Δ +1.35pp fwd-5d,  t=+5.32, n=339
    #:   - regime=normal:     Δ +3.55pp fwd-20d, t=+8.59, n=339
    #: Intentionally gated OUT of volatile regimes where the same
    #: z_60d<-2 signal shows Δ -0.80pp fwd-20d, t=-2.18 (opposite
    #: sign — commodities that dump in a volatile regime keep
    #: dumping). Default ``False`` when unset so older callers
    #: producing ``MacroFlowResult`` directly (e.g. via
    #: ``detect_flows`` before the engine layer adds tags) keep
    #: working. ``FlowAnalyticsEngine.analyze`` attaches the real
    #: value after computing the regime.
    is_rebound: bool = False

    @property
    def category(self) -> CommodityCategory:
        return self.instrument.category

    @property
    def max_abs_z(self) -> float:
        """The strongest absolute z-score across the three windows.

        Used as the default sort key in the UI — most-stretched
        instruments float to the top of the table.

        Returns NaN when every window is NaN (insufficient history),
        without raising NumPy's ``All-NaN axis`` warning.
        """
        zs = (self.price_z_10d, self.price_z_30d, self.price_z_60d)
        finite = [abs(z) for z in zs if z == z]    # NaN-aware filter
        if not finite:
            return float("nan")
        return max(finite)

    @property
    def stage_label(self) -> str:
        """Human-readable stage based on cross-window z-score pattern.

        Stages (using *signed* z — direction matters for 'hot'):
            early    — 10d hot, 30d tepid, 60d cool   (fresh impulse)
            mid      — 10d tepid, 30d hot, 60d still warm
            mature   — 60d sustained hot, 10d cooling
            extended — every window persistently hot (over-stretched)
            —        — no clear pattern

        Thresholds tuned Apr 2026 — the v1 gates (|z|≥2 everywhere)
        were so strict that typical observed moves like Copper
        (z10=+1.25, z30=+0.4, z60=+0.12) classified as "—" even when
        the category aggregate flagged the whole group as hot.
        Gates now use absolute z for the qualification windows (hot
        vs cool) but require *direction* on the leading window so a
        crashing instrument doesn't read 'early' on its bounce.
        """
        z10, z30, z60 = self.price_z_10d, self.price_z_30d, self.price_z_60d
        a10, a30, a60 = abs(z10), abs(z30), abs(z60)

        # extended — all three windows holding a strong move.
        if a10 >= 1.5 and a30 >= 1.5 and a60 >= 1.5:
            return "extended"
        # mature — 60d stretched and still warm, leading window cooling.
        if a60 >= 1.5 and a10 < 1.0:
            return "mature"
        # early — 10d pushing, 30d/60d not yet confirming.
        if a10 >= 1.0 and a30 < 1.0 and a60 < 0.8:
            return "early"
        # mid — 30d carrying the move, 10d has cooled off the peak.
        if a30 >= 1.0 and a10 < 1.0 and a60 < 1.3:
            return "mid"
        return "—"


# ══════════════════════════════════════════════════════════════════════════════
# Detector
# ══════════════════════════════════════════════════════════════════════════════

def detect_flows(
    panel: dict[str, pd.DataFrame],
    *,
    asof_date: pd.Timestamp | None = None,
    universe: tuple[CommodityInstrument, ...] = COMMODITY_UNIVERSE,
) -> list[MacroFlowResult]:
    """Compute flow signals for every instrument in ``universe``.

    Args:
        panel: Dict of ticker → OHLCV DataFrame. Tickers missing from
            the panel are skipped silently. Symbols with insufficient
            history return NaN z-scores rather than being omitted —
            the panel surfaces them with em-dashes so the operator
            knows the instrument is being tracked but currently has
            no data.
        asof_date: Compute as of this bar. ``None`` means most-recent
            available bar per instrument.
        universe: Override the default universe (testing).

    Returns:
        List of ``MacroFlowResult``, one per instrument in the universe
        that has at least one bar in the panel. Sorted by
        ``max_abs_z`` descending (strongest moves first).
    """
    results: list[MacroFlowResult] = []
    for instr in universe:
        df = panel.get(instr.ticker)
        if df is None or df.empty:
            logger.debug("flow_detector: no data for %s; skipping", instr.ticker)
            continue
        try:
            result = _compute_one(instr, df, asof_date=asof_date)
        except Exception:    # noqa: BLE001
            logger.exception(
                "flow_detector: failed on %s; skipping", instr.ticker,
            )
            continue
        if result is not None:
            results.append(result)

    # Sort by absolute z-score across windows, NaNs to the bottom.
    results.sort(
        key=lambda r: (
            r.max_abs_z if not np.isnan(r.max_abs_z) else -1.0
        ),
        reverse=True,
    )
    return results


# ══════════════════════════════════════════════════════════════════════════════
# Internals
# ══════════════════════════════════════════════════════════════════════════════

def _compute_one(
    instr: CommodityInstrument,
    df: pd.DataFrame,
    *,
    asof_date: pd.Timestamp | None,
) -> MacroFlowResult | None:
    """Compute one ``MacroFlowResult`` from a single OHLCV frame."""
    if "Close" not in df.columns:
        return None

    work = df.copy()
    if work.index.tz is not None:
        work.index = work.index.tz_localize(None)
    work = work.sort_index()

    if asof_date is not None:
        asof = pd.Timestamp(asof_date).normalize()
        work = work[work.index <= asof]

    if work.empty:
        return None

    closes = work["Close"].astype(float)
    asof_actual = pd.Timestamp(closes.index[-1])
    last_close = float(closes.iloc[-1])

    # Daily log returns are the basis for both z-scores and pct-change.
    # log(0)/log(-x) on bad rows produce -inf/nan which dropna() strips;
    # silencing the numpy RuntimeWarning that leaks to the terminal.
    with np.errstate(invalid="ignore", divide="ignore"):
        rets = np.log(closes / closes.shift(1)).dropna()

    if len(rets) < 1:
        return MacroFlowResult(
            instrument=instr,
            asof_date=asof_actual,
            close_price=last_close,
            pct_change_1d=float("nan"),
            pct_change_5d=float("nan"),
            price_z_10d=float("nan"),
            price_z_30d=float("nan"),
            price_z_60d=float("nan"),
        )

    pct_1d = (np.exp(float(rets.iloc[-1])) - 1.0) * 100.0
    pct_5d = (
        (np.exp(float(rets.iloc[-5:].sum())) - 1.0) * 100.0
        if len(rets) >= 5 else float("nan")
    )

    z_values = [_window_z(rets, w) for w in PRICE_Z_WINDOWS]

    return MacroFlowResult(
        instrument=instr,
        asof_date=asof_actual,
        close_price=last_close,
        pct_change_1d=pct_1d,
        pct_change_5d=pct_5d,
        price_z_10d=z_values[0],
        price_z_30d=z_values[1],
        price_z_60d=z_values[2],
    )


def _window_z(returns: pd.Series, window: int) -> float:
    """Z-score the *cumulative* log return over the last ``window`` bars
    against the historical distribution of cumulative ``window``-bar
    log returns over the previous year (~252 bars).

    This compares "is the last N days unusual" against "what's a typical
    N-day move" — the right framing for spike detection. Single-day
    returns z-scored against single-day-return history would tell you
    something different (recent volatility) and isn't what we want for
    the price-z-score column.
    """
    needed = window + 252
    if len(returns) < window + 30:
        # Not enough history to z-score even loosely.
        return float("nan")

    # Cumulative N-day returns at every point in history.
    rolling_sum = returns.rolling(window).sum()
    rolling_sum = rolling_sum.dropna()

    if len(rolling_sum) < 30:
        return float("nan")

    current = float(rolling_sum.iloc[-1])
    # Use up to last 252 historical samples (excluding current point).
    history = rolling_sum.iloc[-(min(252, len(rolling_sum) - 1) + 1):-1]
    if len(history) < 30:
        return float("nan")

    mean = float(history.mean())
    std = float(history.std(ddof=1))
    if std <= 0 or not np.isfinite(std):
        return float("nan")
    return (current - mean) / std
