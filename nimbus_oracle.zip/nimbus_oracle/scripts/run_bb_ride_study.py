#!/usr/bin/env python3
"""
scripts/run_bb_ride_study.py — BB Upper Band Momentum Continuation Study

  ┌──────────────────────────────────────────────────────────────────────────┐
  │ RELATED INVESTIGATION: RIDE DECAY — CLOSED                               │
  │                                                                          │
  │ Earlier in the project we flagged a "BB Ride decay" issue — the         │
  │ strategy's Sharpe dropping from 1.24 (pre-2024) to 0.15 (2024+).        │
  │ That investigation is now CLOSED with the following framing:             │
  │                                                                          │
  │ The decay was not Ride-specific. The correlation study                  │
  │ (scripts/run_strategy_correlation_study.py) found MR and Ride are       │
  │ highly correlated (Pearson +0.64, 81% sign agreement in weekly PnL).    │
  │ Both strategies depend on the same underlying alpha: directional        │
  │ market moves paying off. When that alpha disappeared in late 2024,     │
  │ BOTH strategies degraded together. Ride's decay is the same regime     │
  │ change that hit MR in fold 5 (2024-10 through 2025-03).                │
  │                                                                          │
  │ The original Ride decay Sharpe collapse (1.24 → 0.15) has no           │
  │ Ride-specific cause. The strategy code is fine; the market regime      │
  │ doesn't reward it right now.                                            │
  │                                                                          │
  │ Implication: don't look for a fix to BB Ride. There's nothing broken.  │
  │ Instead, use the strategy regime detector in modules/strategy_regime.py │
  │ to know when the underlying alpha is paying out, and trade accordingly.│
  │                                                                          │
  │ Remaining Ride questions (for future research, not urgent):             │
  │   - Does Ride add coverage MR doesn't already catch at the              │
  │     trade-day level? (+0.40 same-day correlation suggests partial      │
  │     independence)                                                       │
  │   - Is Ride's "+4pp better than MR on bad weeks in fold 5" finding     │
  │     statistically robust or fold-5-specific noise? (needs more         │
  │     stressed-regime data to confirm)                                    │
  └──────────────────────────────────────────────────────────────────────────┘

ORIGINAL QUESTION: When price first touches/crosses the BB upper band (1σ),
what is the likelihood it keeps riding? How far can it go?

Entry signal: Close >= BB_Upper(20, 1σ) for the FIRST time after being below
Exit conditions studied:
  - Drops below BB_Upper (1σ) → ride over
  - Drops below BB_Mid (SMA20) → trend broken
  - Fixed holding periods (5d, 10d, 21d)

Measures:
  - Ride duration (bars above upper band)
  - Max gain during ride
  - Max drawdown from entry
  - Win rate at various horizons
  - Persistence by sector, VIX, volume, ADX

Usage:
    python3 scripts/run_bb_ride_study.py --years 5 --stocks 50
    python3 scripts/run_bb_ride_study.py --years 7 --stocks 80 --export
"""
import argparse, logging, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()
import numpy as np, pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("bb_ride")


def get_stock_list(n=50):
    """Get top N F&O stocks."""
    try:
        from modules.index_constituents import get_nifty100
        stocks = get_nifty100()
        if stocks and len(stocks) >= 20:
            return stocks[:n]
    except Exception:
        pass
    # Fallback
    return [
        "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK", "BHARTIARTL",
        "SBIN", "ITC", "HINDUNILVR", "LT", "KOTAKBANK", "HCLTECH",
        "AXISBANK", "ASIANPAINT", "MARUTI", "BAJFINANCE", "TATAMOTORS",
        "SUNPHARMA", "TITAN", "ULTRACEMCO", "WIPRO", "NESTLEIND",
        "POWERGRID", "NTPC", "M&M", "TATASTEEL", "JSWSTEEL", "ADANIPORTS",
        "BAJAJFINSV", "TECHM", "INDUSINDBK", "DIVISLAB", "DRREDDY",
        "ONGC", "COALINDIA", "GRASIM", "CIPLA", "APOLLOHOSP",
        "EICHERMOT", "HINDALCO", "BPCL", "TATACONSUM", "HEROMOTOCO",
        "PIDILITIND", "BRITANNIA", "GODREJCP", "DABUR", "BERGEPAINT",
        "ABB", "BOSCHLTD",
    ][:n]


def fetch_daily(symbol, years=5):
    """Fetch daily OHLCV from yfinance."""
    import yfinance as yf
    try:
        ticker = symbol if symbol.startswith("^") else f"{symbol}.NS"
        df = yf.download(ticker, period=f"{years}y", interval="1d",
                         auto_adjust=True, progress=False)
        if df is not None and not df.empty:
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            if hasattr(df.index, "tz") and df.index.tz is not None:
                df.index = df.index.tz_localize(None)
        return df if df is not None else pd.DataFrame()
    except Exception as exc:
        logger.warning("  %s failed: %s", symbol, exc)
        return pd.DataFrame()


def compute_bb_touches(df, symbol, bb_period=20, bb_std=1.0):
    """
    Detect first touches of BB upper band and measure ride characteristics.
    
    A 'touch' is when Close >= BB_Upper for the first time after being below.
    We then track:
      - How many bars it stays at or above BB_Upper (ride duration)
      - Max gain from entry while riding
      - When it drops below BB_Upper (ride end)
      - When/if it drops below BB_Mid (trend break)
      - Forward returns at 5d, 10d, 21d from touch
    """
    if df is None or len(df) < bb_period + 30:
        return []
    
    c = df["Close"].values.astype(float)
    h = df["High"].values.astype(float)
    l = df["Low"].values.astype(float)
    v = df["Volume"].values.astype(float) if "Volume" in df.columns else np.zeros(len(df))
    dates = df.index
    
    # Compute BB (1σ)
    mid = pd.Series(c).rolling(bb_period).mean().values
    std = pd.Series(c).rolling(bb_period).std().values
    upper = mid + bb_std * std
    lower = mid - bb_std * std
    
    # Also compute 2σ for comparison
    upper_2 = mid + 2.0 * std
    
    # BB %B
    band = upper - lower
    band[band == 0] = np.nan
    pct_b = (c - lower) / band
    
    # BBW
    bbw = band / np.where(mid > 0, mid, np.nan) * 100
    bbw_slope = np.full_like(bbw, np.nan)
    bbw_slope[5:] = bbw[5:] - bbw[:-5]
    
    # ADX(14)
    tr = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    atr = pd.Series(np.concatenate([[np.nan], tr])).rolling(14).mean().values
    
    # Volume ratio
    vol_avg = pd.Series(v).rolling(20).mean().values
    vol_ratio = np.where(vol_avg > 0, v / vol_avg, 0)
    
    # RSI(14)
    delta = np.diff(c, prepend=c[0])
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    avg_gain = pd.Series(gain).rolling(14).mean().values
    avg_loss = pd.Series(loss).rolling(14).mean().values
    with np.errstate(divide='ignore', invalid='ignore'):
        rs = np.where(avg_loss > 0, avg_gain / avg_loss, 0)
        rsi = 100 - (100 / (1 + rs))
    
    # MFI(14)
    tp = (h + l + c) / 3
    mf = tp * v
    pmf = np.where(tp > np.roll(tp, 1), mf, 0)
    nmf = np.where(tp < np.roll(tp, 1), mf, 0)
    pmf_sum = pd.Series(pmf).rolling(14).sum().values
    nmf_sum = pd.Series(nmf).rolling(14).sum().values
    with np.errstate(divide='ignore', invalid='ignore'):
        mfr = np.where(nmf_sum > 0, pmf_sum / nmf_sum, 0)
        mfi = 100 - (100 / (1 + mfr))
    
    # Detect first touches: Close crosses above BB_Upper
    touches = []
    was_below = True  # start assuming below
    
    for i in range(bb_period + 5, len(c) - 21):  # need 21d forward
        if np.isnan(upper[i]) or np.isnan(mid[i]):
            continue
        
        at_or_above = c[i] >= upper[i]
        
        if was_below and at_or_above:
            # FIRST TOUCH — entry signal
            entry_price = c[i]
            entry_date = dates[i]
            
            # Measure ride: how many bars does it stay >= upper?
            ride_bars = 0
            max_gain = 0.0
            max_dd = 0.0
            max_pct_b = pct_b[i] if not np.isnan(pct_b[i]) else 1.0  # peak deviation
            max_dist_from_upper = 0.0  # % distance above upper band
            pct_b_at_peak = pct_b[i] if not np.isnan(pct_b[i]) else 1.0
            
            # Track the peak and where the pullback starts
            peak_bar = 0
            pullback_started = False
            pullback_bar = None
            
            for j in range(i + 1, min(i + 60, len(c))):  # max 60 bar lookforward
                gain_pct = (c[j] / entry_price - 1) * 100
                max_gain = max(max_gain, gain_pct)
                max_dd = min(max_dd, gain_pct)
                
                # Track max %B deviation
                if not np.isnan(pct_b[j]) and pct_b[j] > max_pct_b:
                    max_pct_b = pct_b[j]
                    peak_bar = j - i
                    pct_b_at_peak = pct_b[j]
                
                # Track max % distance above upper band
                if not np.isnan(upper[j]) and upper[j] > 0:
                    dist = (c[j] - upper[j]) / upper[j] * 100
                    if dist > max_dist_from_upper:
                        max_dist_from_upper = dist
                
                # Detect pullback start: first bar %B drops after peak
                if not pullback_started and not np.isnan(pct_b[j]):
                    if pct_b[j] < max_pct_b - 0.15:  # meaningful drop
                        pullback_started = True
                        pullback_bar = j - i
                
                if c[j] >= upper[j] and not np.isnan(upper[j]):
                    ride_bars += 1
                else:
                    break  # ride over
            
            # Is this a "second touch" after a prior ride? Track touch number
            # (already handled by was_below reset — each touch is first after being below)
            
            # When does it break below mid?
            mid_break_bar = None
            for j in range(i + 1, min(i + 60, len(c))):
                if c[j] < mid[j] and not np.isnan(mid[j]):
                    mid_break_bar = j - i
                    break
            
            # Forward returns
            fwd_5d = (c[i+5] / entry_price - 1) * 100 if i+5 < len(c) else np.nan
            fwd_10d = (c[i+10] / entry_price - 1) * 100 if i+10 < len(c) else np.nan
            fwd_21d = (c[i+21] / entry_price - 1) * 100 if i+21 < len(c) else np.nan
            
            # Was it also above 2σ? (overextended)
            above_2sigma = c[i] >= upper_2[i] if not np.isnan(upper_2[i]) else False
            
            # Pullback after peak: what's the drawdown from peak gain?
            peak_price = entry_price * (1 + max_gain / 100)
            dd_from_peak = 0.0
            for j in range(i + peak_bar + 1, min(i + 60, len(c))):
                dd = (c[j] / peak_price - 1) * 100
                dd_from_peak = min(dd_from_peak, dd)
            
            touches.append({
                "symbol": symbol,
                "date": entry_date,
                "entry_price": entry_price,
                "bb_pct": pct_b[i] if not np.isnan(pct_b[i]) else 0.5,
                "above_2sigma": above_2sigma,
                "ride_bars": ride_bars,
                "max_gain": round(max_gain, 2),
                "max_dd": round(max_dd, 2),
                "mid_break_bar": mid_break_bar,
                "max_pct_b": round(max_pct_b, 3),       # peak %B during ride
                "max_dist_upper": round(max_dist_from_upper, 2),  # max % above upper band
                "pct_b_at_peak": round(pct_b_at_peak, 3),
                "peak_bar": peak_bar,                    # bars to peak
                "pullback_bar": pullback_bar,            # bars to first pullback
                "dd_from_peak": round(dd_from_peak, 2),  # DD from peak price
                "fwd_5d": round(fwd_5d, 3) if not np.isnan(fwd_5d) else np.nan,
                "fwd_10d": round(fwd_10d, 3) if not np.isnan(fwd_10d) else np.nan,
                "fwd_21d": round(fwd_21d, 3) if not np.isnan(fwd_21d) else np.nan,
                "rsi": round(rsi[i], 1),
                "mfi": round(mfi[i], 1),
                "adx": round(float(atr[i] / c[i] * 100), 2) if atr[i] and c[i] else 0,
                "vol_ratio": round(vol_ratio[i], 2),
                "bbw": round(bbw[i], 2) if not np.isnan(bbw[i]) else 0,
                "bbw_slope": round(bbw_slope[i], 2) if not np.isnan(bbw_slope[i]) else 0,
            })
            
            was_below = False  # now riding
        
        elif not at_or_above:
            was_below = True  # reset — ready for next touch
    
    return touches


def analyze(touches_df):
    """Full analysis of BB touch events."""
    df = touches_df
    N = len(df)
    
    print(f"\nTotal BB upper band touches: {N}")
    print(f"Unique stocks: {df['symbol'].nunique()}")
    
    # ══════════════════════════════════════════════════════════════════════
    # 1. BASIC STATS — What happens after a touch?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("1. WHAT HAPPENS AFTER TOUCHING BB UPPER (1σ)?")
    print("="*70)
    
    for h, label in [("fwd_5d", "5d"), ("fwd_10d", "10d"), ("fwd_21d", "21d")]:
        valid = df[h].dropna()
        win = (valid > 0).mean() * 100
        avg = valid.mean()
        med = valid.median()
        print(f"  {label}: Win={win:.1f}%  Avg={avg:+.2f}%  Med={med:+.2f}%  (N={len(valid)})")
    
    # ══════════════════════════════════════════════════════════════════════
    # 2. RIDE DURATION — How long does it stay?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("2. RIDE DURATION (bars staying >= BB upper after touch)")
    print("="*70)
    
    print(f"\n  Distribution: min={df['ride_bars'].min()}  p25={df['ride_bars'].quantile(0.25):.0f}  "
          f"med={df['ride_bars'].median():.0f}  p75={df['ride_bars'].quantile(0.75):.0f}  "
          f"max={df['ride_bars'].max()}")
    
    print(f"\n  {'Ride duration':>15s} {'N':>6s} {'%':>5s} {'MaxGain':>8s} {'MaxDD':>7s} {'10d Avg':>8s}")
    for label, lo, hi in [
        ("0 bars (fail)", 0, 0),
        ("1-2 bars", 1, 2),
        ("3-5 bars", 3, 5),
        ("6-10 bars", 6, 10),
        ("11-20 bars", 11, 20),
        ("20+ bars", 20, 999),
    ]:
        sub = df[(df["ride_bars"] >= lo) & (df["ride_bars"] <= hi)]
        if len(sub) < 5: continue
        pct = len(sub) / N * 100
        mg = sub["max_gain"].mean()
        md = sub["max_dd"].mean()
        f10 = sub["fwd_10d"].mean()
        print(f"  {label:>15s} {len(sub):6d} {pct:4.1f}% {mg:+7.2f}% {md:+6.2f}% {f10:+7.2f}%")
    
    # ══════════════════════════════════════════════════════════════════════
    # 3. MAX GAIN DURING RIDE — How far can it go?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("3. MAX GAIN FROM ENTRY WHILE RIDING")
    print("="*70)
    
    print(f"\n  Distribution: min={df['max_gain'].min():.1f}%  p25={df['max_gain'].quantile(0.25):.1f}%  "
          f"med={df['max_gain'].median():.1f}%  p75={df['max_gain'].quantile(0.75):.1f}%  "
          f"max={df['max_gain'].max():.1f}%  mean={df['max_gain'].mean():.1f}%")
    
    # ══════════════════════════════════════════════════════════════════════
    # 4. MID-BAND BREAK — When does the trend actually break?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("4. TIME TO MID-BAND BREAK (SMA20)")
    print("="*70)
    
    has_break = df[df["mid_break_bar"].notna()]
    no_break = df[df["mid_break_bar"].isna()]
    print(f"\n  Breaks mid within 60 bars: {len(has_break)} ({len(has_break)/N*100:.1f}%)")
    print(f"  Never breaks mid (60 bars): {len(no_break)} ({len(no_break)/N*100:.1f}%)")
    
    if len(has_break) > 10:
        mb = has_break["mid_break_bar"]
        print(f"\n  Time to mid-band break: min={mb.min():.0f}  p25={mb.quantile(0.25):.0f}  "
              f"med={mb.median():.0f}  p75={mb.quantile(0.75):.0f}  max={mb.max():.0f}")
    
    # ══════════════════════════════════════════════════════════════════════
    # 5. FACTORS — What predicts a longer ride?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("5. WHAT PREDICTS A LONGER RIDE?")
    print("="*70)
    
    factors = ["rsi", "mfi", "vol_ratio", "bbw", "bbw_slope", "bb_pct"]
    
    print(f"\n  {'Factor':>12s} {'r(ride)':>8s} {'r(maxG)':>8s} {'r(10d)':>8s}")
    for f in factors:
        valid = df[[f, "ride_bars", "max_gain", "fwd_10d"]].dropna()
        if len(valid) < 30: continue
        r_ride = valid[f].corr(valid["ride_bars"])
        r_gain = valid[f].corr(valid["max_gain"])
        r_fwd = valid[f].corr(valid["fwd_10d"])
        print(f"  {f:>12s} {r_ride:+.4f} {r_gain:+.4f} {r_fwd:+.4f}")
    
    # ══════════════════════════════════════════════════════════════════════
    # 6. VOLUME AT TOUCH — Does volume predict persistence?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("6. VOLUME AT TOUCH — Does it predict ride quality?")
    print("="*70)
    
    print(f"\n  {'Vol bucket':>12s} {'N':>6s} {'Ride med':>9s} {'MaxGain':>8s} {'10d Avg':>8s} {'Win10d':>7s}")
    for label, lo, hi in [("<0.5x", 0, 0.5), ("0.5-1x", 0.5, 1.0), ("1-1.5x", 1.0, 1.5),
                           ("1.5-2x", 1.5, 2.0), (">2x", 2.0, 99)]:
        sub = df[(df["vol_ratio"] >= lo) & (df["vol_ratio"] < hi)]
        if len(sub) < 10: continue
        print(f"  {label:>12s} {len(sub):6d} {sub['ride_bars'].median():8.0f}  {sub['max_gain'].mean():+7.2f}% "
              f"{sub['fwd_10d'].mean():+7.2f}% {sub['fwd_10d'].gt(0).mean()*100:6.1f}%")
    
    # ══════════════════════════════════════════════════════════════════════
    # 7. 1σ vs 2σ TOUCH — Overextension
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("7. TOUCH AT 1σ vs ABOVE 2σ — Does overextension help or hurt?")
    print("="*70)
    
    at_1 = df[~df["above_2sigma"]]
    at_2 = df[df["above_2sigma"]]
    print(f"\n  Touch at 1σ (not 2σ):  N={len(at_1):5d}  Ride med={at_1['ride_bars'].median():.0f}  "
          f"MaxGain={at_1['max_gain'].mean():+.2f}%  10d={at_1['fwd_10d'].mean():+.2f}%  Win={at_1['fwd_10d'].gt(0).mean()*100:.1f}%")
    print(f"  Touch above 2σ:       N={len(at_2):5d}  Ride med={at_2['ride_bars'].median():.0f}  "
          f"MaxGain={at_2['max_gain'].mean():+.2f}%  10d={at_2['fwd_10d'].mean():+.2f}%  Win={at_2['fwd_10d'].gt(0).mean()*100:.1f}%")
    
    # ══════════════════════════════════════════════════════════════════════
    # 8. BBW STATE — Squeeze breakout vs trending
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("8. BB WIDTH AT TOUCH — Squeeze breakout vs wide-band trending")
    print("="*70)
    
    print(f"\n  {'BBW bucket':>15s} {'N':>6s} {'Ride med':>9s} {'MaxGain':>8s} {'10d':>8s} {'Win10d':>7s}")
    for label, lo, hi in [("Tight <3%", 0, 3), ("Normal 3-6%", 3, 6), ("Wide 6-10%", 6, 10), ("Very wide >10%", 10, 99)]:
        sub = df[(df["bbw"] >= lo) & (df["bbw"] < hi)]
        if len(sub) < 10: continue
        print(f"  {label:>15s} {len(sub):6d} {sub['ride_bars'].median():8.0f}  {sub['max_gain'].mean():+7.2f}% "
              f"{sub['fwd_10d'].mean():+7.2f}% {sub['fwd_10d'].gt(0).mean()*100:6.1f}%")

    # ══════════════════════════════════════════════════════════════════════
    # 9. DEVIATION THRESHOLD — How far above upper band before pullback?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("9. DEVIATION FROM UPPER BAND — At what %B does pullback become inevitable?")
    print("="*70)
    print(f"  %B = 1.0 → at upper band(1σ), 1.5 → halfway to 2σ, 2.0 → at 2σ")

    print(f"\n  Peak %B distribution: min={df['max_pct_b'].min():.2f}  p25={df['max_pct_b'].quantile(0.25):.2f}  "
          f"med={df['max_pct_b'].median():.2f}  p75={df['max_pct_b'].quantile(0.75):.2f}  "
          f"max={df['max_pct_b'].max():.2f}")

    print(f"\n  {'Peak %B':>15s} {'N':>6s} {'Ride':>5s} {'MaxG':>7s} {'DD peak':>8s} {'PB bar':>7s} {'10d':>7s}")
    print(f"  {'-'*15} {'-'*6} {'-'*5} {'-'*7} {'-'*8} {'-'*7} {'-'*7}")

    for label, lo, hi in [
        ("1.0-1.2 (near)", 1.0, 1.2),
        ("1.2-1.5 (ext)", 1.2, 1.5),
        ("1.5-2.0 (far)", 1.5, 2.0),
        (">2.0 (extreme)", 2.0, 99),
    ]:
        sub = df[(df["max_pct_b"] >= lo) & (df["max_pct_b"] < hi)]
        if len(sub) < 10: continue
        ride = sub["ride_bars"].median()
        mg = sub["max_gain"].mean()
        dd_pk = sub["dd_from_peak"].mean()
        pb = sub["pullback_bar"].dropna()
        pb_med = pb.median() if len(pb) > 0 else 0
        f10 = sub["fwd_10d"].mean()
        print(f"  {label:>15s} {len(sub):6d} {ride:4.0f}d {mg:+6.2f}% {dd_pk:+7.2f}% {pb_med:6.0f}d {f10:+6.2f}%")

    print(f"\n  Key question: at what peak %B does 10d return go negative?")
    for thresh in [1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.5]:
        sub = df[df["max_pct_b"] >= thresh]
        if len(sub) < 10: continue
        avg = sub["fwd_10d"].mean()
        win = sub["fwd_10d"].gt(0).mean() * 100
        print(f"    Peak %B ≥ {thresh:.1f}: N={len(sub):5d}  10d={avg:+.2f}%  Win={win:.1f}%")

    # ══════════════════════════════════════════════════════════════════════
    # 10. PEAK-TO-PULLBACK — How fast does reversion happen?
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("10. PEAK-TO-PULLBACK — How quickly does reversion kick in?")
    print("="*70)

    has_pb = df[df["pullback_bar"].notna()]
    no_pb = df[df["pullback_bar"].isna()]
    print(f"\n  Pullback detected (within 60 bars): {len(has_pb)} ({len(has_pb)/N*100:.0f}%)")
    print(f"  No pullback: {len(no_pb)} ({len(no_pb)/N*100:.0f}%)")

    if len(has_pb) > 20:
        print(f"\n  Bars to pullback: min={has_pb['pullback_bar'].min():.0f}  "
              f"p25={has_pb['pullback_bar'].quantile(0.25):.0f}  "
              f"med={has_pb['pullback_bar'].median():.0f}  "
              f"p75={has_pb['pullback_bar'].quantile(0.75):.0f}  "
              f"max={has_pb['pullback_bar'].max():.0f}")

    print(f"\n  DD from peak price after pullback starts:")
    print(f"  {'DD from peak':>15s} {'N':>6s} {'%':>5s}")
    for label, lo, hi in [("< -1%", -99, -1), ("-1 to -3%", -3, -1),
                          ("-3 to -5%", -5, -3), ("-5 to -10%", -10, -5), ("> -10%", -99, -10)]:
        sub = df[(df["dd_from_peak"] >= lo) & (df["dd_from_peak"] < hi)]
        if len(sub) < 5: continue
        print(f"  {label:>15s} {len(sub):6d} {len(sub)/N*100:4.1f}%")

    # ══════════════════════════════════════════════════════════════════════
    # 11. MAX % ABOVE UPPER BAND — The Canara Bank pattern
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("11. MAX % ABOVE UPPER BAND — Distance-based exit signal")
    print("="*70)
    print(f"  Your thesis: when price deviates too far above BB upper,")
    print(f"  pullback is inevitable. What's the threshold?")

    print(f"\n  Max dist above UB: min={df['max_dist_upper'].min():.1f}%  "
          f"p25={df['max_dist_upper'].quantile(0.25):.1f}%  "
          f"med={df['max_dist_upper'].median():.1f}%  "
          f"p75={df['max_dist_upper'].quantile(0.75):.1f}%  "
          f"max={df['max_dist_upper'].max():.1f}%")

    print(f"\n  {'Dist above UB':>15s} {'N':>6s} {'Ride':>5s} {'MaxGain':>8s} {'DD peak':>8s} {'10d':>7s} {'Win10':>6s}")
    for label, lo, hi in [
        ("0-1%", 0, 1), ("1-2%", 1, 2), ("2-4%", 2, 4),
        ("4-6%", 4, 6), ("6-10%", 6, 10), (">10%", 10, 99),
    ]:
        sub = df[(df["max_dist_upper"] >= lo) & (df["max_dist_upper"] < hi)]
        if len(sub) < 10: continue
        print(f"  {label:>15s} {len(sub):6d} {sub['ride_bars'].median():4.0f}d {sub['max_gain'].mean():+7.2f}% "
              f"{sub['dd_from_peak'].mean():+7.2f}% {sub['fwd_10d'].mean():+6.2f}% "
              f"{sub['fwd_10d'].gt(0).mean()*100:5.1f}%")

    # Correlation: distance above upper → subsequent pullback size
    valid = df[["max_dist_upper", "dd_from_peak", "fwd_10d"]].dropna()
    if len(valid) > 30:
        r_dd = valid["max_dist_upper"].corr(valid["dd_from_peak"])
        r_fwd = valid["max_dist_upper"].corr(valid["fwd_10d"])
        print(f"\n  max_dist_upper ↔ dd_from_peak: r = {r_dd:+.4f}  (more extension → bigger pullback?)")
        print(f"  max_dist_upper ↔ fwd_10d:      r = {r_fwd:+.4f}  (more extension → worse 10d return?)")

    # ══════════════════════════════════════════════════════════════════════
    # 12. OPTIMAL EXIT — When to get off the ride
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "="*70)
    print("12. OPTIMAL EXIT — Entry at touch, exit at various signals")
    print("="*70)

    # Simulate: entry at touch, exit when %B drops back below 1.0
    # vs exit when price drops below mid
    # vs fixed 5d/10d hold
    print(f"\n  Strategy comparison (entry = BB upper touch):")
    print(f"  {'Exit rule':>25s} {'Avg PnL':>8s} {'Win%':>6s} {'Med hold':>9s}")

    # Exit: fixed holds
    for h_days, col in [(5, "fwd_5d"), (10, "fwd_10d"), (21, "fwd_21d")]:
        valid = df[col].dropna()
        print(f"  {'Hold '+str(h_days)+'d':>25s} {valid.mean():+7.2f}% {(valid>0).mean()*100:5.1f}% {h_days:8d}d")

    # Exit: ride end (drops below upper band)
    print(f"  {'Ride end (below UB)':>25s} {df['max_gain'].mean():+7.2f}% {'':>6s} {df['ride_bars'].median():8.0f}d  (max gain during ride)")

    # Exit: mid-band break
    has_mb = df[df["mid_break_bar"].notna()]
    if len(has_mb) > 20:
        # PnL at mid-band break ≈ fwd at mid_break_bar (approximate)
        print(f"  {'Mid-band break':>25s} {'varies':>8s} {'':>6s} {has_mb['mid_break_bar'].median():8.0f}d  (wait for SMA20 break)")


def main():
    parser = argparse.ArgumentParser(description="BB Upper Band Ride Study")
    parser.add_argument("--years", type=int, default=5, help="Years of data")
    parser.add_argument("--stocks", type=int, default=50, help="Number of stocks")
    parser.add_argument("--export", action="store_true", help="Export CSV")
    args = parser.parse_args()
    
    stocks = get_stock_list(args.stocks)
    logger.info("BB Ride Study: %d stocks, %d years", len(stocks), args.years)
    
    all_touches = []
    failed = 0
    for i, sym in enumerate(stocks):
        logger.info("  [%d/%d] %s", i+1, len(stocks), sym)
        df = fetch_daily(sym, args.years)
        if df is None or len(df) < 80:
            failed += 1
            continue
        touches = compute_bb_touches(df, sym)
        all_touches.extend(touches)
        time.sleep(0.3)
    
    if not all_touches:
        logger.error("No touches found")
        return
    
    touches_df = pd.DataFrame(all_touches)
    logger.info("\nTotal touches: %d from %d stocks (%d failed)",
                len(touches_df), len(stocks) - failed, failed)
    
    analyze(touches_df)
    
    if args.export:
        out = os.path.join("data", "backtest_results")
        os.makedirs(out, exist_ok=True)
        path = os.path.join(out, "bb_ride_touches.csv")
        touches_df.to_csv(path, index=False)
        logger.info("\nExported %d touches to %s", len(touches_df), path)


if __name__ == "__main__":
    main()
