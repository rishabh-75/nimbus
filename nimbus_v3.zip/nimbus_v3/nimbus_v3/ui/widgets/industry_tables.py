"""nimbus_v3.ui.widgets.industry_tables — slim Industries +
Constituents tables for the unified Dashboard.

Two minimal tables embedded in the Dashboard's bottom strip:

  - :class:`IndustriesTable` — fixed at the NSE "industry"
    classification level (third level), columns
    ``Group | ADTV | Riding | Phase | Score``. ALL row pinned at the top.
  - :class:`ConstituentsTable` — symbols within the currently
    selected industry, columns
    ``Symbol | ADTV | Phase | Score``.

Everything that was in the old ``MarketContextTab`` — level
selector dropdown, regime label, phase distribution widget,
ROC/%B/Vol/BBW columns, Basic Industry column, summary line —
has been deliberately stripped. The Dashboard's bottom strip is
not a screener; it is contextual readout for the symbol on the
chart above it.

Selection model (interpreted by MainWindow, not these widgets)
──────────────────────────────────────────────────────────────
  - Click on an Industries row → MainWindow re-populates
    Constituents with that industry's members. Chart stays.
  - Double-click on a Constituents row → MainWindow loads that
    symbol on the chart. Tables stay put — they react only to
    explicit clicks, not to sidebar-driven symbol changes.
  - The chart and the tables therefore exist on slightly
    different selection rails. Operators choose what to look at
    on the chart, then explore industry context independently.
"""
from __future__ import annotations

import logging
from typing import Final

import pandas as pd
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.constituent_features import extract_constituent_features
from nimbus_v3.compute.early_entry import extract_features, score_cohort
from nimbus_v3.compute.industry_rollup import aggregate_industry
from nimbus_v3.core.universe import Universe
from nimbus_v3.ui.widgets.formatters import format_adtv_m
from nimbus_v3.ui.theme import (
    BLUE, BORDER, EM, FONT_MONO, FONT_UI, GOLD, GREEN, MUTED, RED,
    S2, SURFACE, WHITE,
)
from nimbus_v3.ui.widgets.components import PanelFrame


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════════════


INDUSTRY_COLUMNS: Final[tuple[str, ...]] = (
    "Group", "ADTV", "Riding",
)

#: Constituents columns — full per-symbol context. ``Industry`` is
#: the NSE 4th-level classification. Three change-percent columns
#: (1-bar, 5-bar, 10-bar) give a nested freshness read. ``Score`` is
#: the cohort-relative Early-Entry score (see compute/early_entry):
#: higher = earlier in a fresh, liquid, un-extended band-ride.
CONSTITUENT_COLUMNS: Final[tuple[str, ...]] = (
    "Symbol", "Industry", "ADTV",
    "Chg", "Chg 5d%", "Chg 10d%", "%B", "Vol", "BBW",
    "Above", "Streak", "Score",
)

#: Default pixel widths (Interactive resize mode lets the operator
#: drag dividers; the Constituents Symbol column gets 100px while
#: Basic Industry stretches to absorb slack — Industries' Group
#: column also stretches).
_COL_WIDTHS: Final[dict[str, int]] = {
    "ADTV":     115,
    "Riding":    70,    # fits "12 / 15"
    "Above":     60,    # ▲ / —
    "Streak":    65,    # consecutive body-above bars
    "Chg":       80,    # fits "+12.34" — 1-bar pct change
    "Chg 5d%":   90,    # fits "-12.34"
    "Chg 10d%":  90,
    "%B":        78,    # fits "-0.23" / "1.45"
    "Vol":       85,    # fits "1.45x"
    "BBW":       85,    # fits "12.45"
    "Score":     80,
}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════


#: Styling for the per-table search box.
_SEARCH_QSS: Final[str] = f"""
QLineEdit {{
    background: {S2};
    border: 1px solid {BORDER};
    border-radius: 3px;
    padding: 2px 6px;
    color: {WHITE};
}}
QLineEdit:focus {{ border: 1px solid {EM}; }}
"""


def _filter_table_rows(table: QTableWidget, query: str) -> int:
    """Hide rows in ``table`` whose text cells don't contain ``query``
    (case-insensitive substring across all columns). Empty query shows
    all rows. Returns the number of visible rows."""
    q = query.strip().lower()
    visible = 0
    for r in range(table.rowCount()):
        if not q:
            table.setRowHidden(r, False)
            visible += 1
            continue
        match = False
        for c in range(table.columnCount()):
            item = table.item(r, c)
            if item is not None and q in item.text().lower():
                match = True
                break
        table.setRowHidden(r, not match)
        visible += int(match)
    return visible


class _NumericItem(QTableWidgetItem):
    """QTableWidgetItem that sorts by a numeric UserRole value while
    displaying free-form text. Avoids lexicographic sort artifacts
    on formatted cells (``"1,000 M"`` < ``"2 M"`` < ``"946 M"`` etc).

    Missing values (None / NaN) sink to the bottom in both ascending
    and descending order — operators never want em-dash rows
    interleaved with real values regardless of sort direction.
    """

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, QTableWidgetItem):
            return NotImplemented
        a = self.data(Qt.ItemDataRole.UserRole)
        b = other.data(Qt.ItemDataRole.UserRole)
        a_missing = a is None or (isinstance(a, float) and a != a)
        b_missing = b is None or (isinstance(b, float) and b != b)

        if a_missing and b_missing:
            return False
        if a_missing or b_missing:
            descending = False
            tw = self.tableWidget()
            if tw is not None:
                hdr = tw.horizontalHeader()
                if hdr is not None:
                    descending = (
                        hdr.sortIndicatorOrder()
                        == Qt.SortOrder.DescendingOrder
                    )
            if descending:
                return a_missing and not b_missing
            return b_missing and not a_missing

        try:
            return float(a) < float(b)
        except (TypeError, ValueError):
            return super().__lt__(other)


# ══════════════════════════════════════════════════════════════════════════════
# IndustriesTable
# ══════════════════════════════════════════════════════════════════════════════


class IndustriesTable(QWidget):
    """Compact table of NSE industries with Phase + Score from the
    roll-up classifier.

    Public API
    ──────────
        :meth:`refresh(panel, universe)` — recompute every visible
            industry's Phase + Score.
        :meth:`clear()` — empty placeholder state.

    Signals
    ───────
        :attr:`industry_selected(str)` — single-click on a row.
            Emits the raw industry name (or ``"ALL"`` for the
            pinned aggregate row). MainWindow connects this to
            re-populate :class:`ConstituentsTable`.
    """

    industry_selected = pyqtSignal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._panel: dict[str, pd.DataFrame] = {}
        self._universe: Universe | None = None
        # ``industry_name → [member_symbols]``. Used by MainWindow
        # to drive the constituents table without re-classifying.
        self._members_by_industry: dict[str, list[str]] = {}
        # Whether the latest selection came from a programmatic
        # default (set_panel auto-select) vs a real user click.
        # Lets the Dashboard's set_symbol() pivot the tables when
        # the operator hasn't actively chosen an industry yet, but
        # respect their pick once they have.
        self._user_selected: bool = False
        self._build_ui()

    # ── public ────────────────────────────────────────────────────────────

    def refresh(
        self,
        panel: dict[str, pd.DataFrame],
        universe: Universe | None,
    ) -> None:
        """Rebuild the table from a fresh enriched panel + universe.

        Args:
            panel: ``{symbol: enriched_df}`` keyed on NSE ticker.
            universe: ``Universe`` object — drives the industry
                grouping and the per-symbol metadata used by
                ``ConstituentsTable``.
        """
        self._panel = panel or {}
        self._universe = universe
        # A fresh panel rebuild discards the previous user pick —
        # the operator can re-click whatever they want once the new
        # rows are in.
        self._user_selected = False
        if universe is None or not panel:
            self._members_by_industry = {}
            self._render([])
            return

        # Group symbols by NSE "industry" (third classification
        # level). We stay fixed at this level — no dropdown — per
        # design.
        groups: dict[str, list[str]] = {}
        for sym, meta in universe.symbols.items():
            if sym not in panel:
                continue
            ind = (getattr(meta, "industry", None) or "Unknown").strip()
            if not ind:
                ind = "Unknown"
            groups.setdefault(ind, []).append(sym)
        self._members_by_industry = groups

        rows: list[dict] = []
        for industry, members in groups.items():
            row = self._analyze_group(industry, members)
            if row is not None:
                rows.append(row)

        # Sort regular industries by riding strength descending — the
        # summed ADTV of members whose last bar is body-above (NaN, i.e.
        # nothing riding, sinks to the bottom). Industries with the most
        # and most-liquid riders rank first.
        df = pd.DataFrame(rows)
        if not df.empty:
            df = df.sort_values(
                "_riding_strength", ascending=False, na_position="last",
            ).reset_index(drop=True)

        # ALL row — every panel symbol the universe contains.
        all_members = [s for s in panel.keys() if s in universe.symbols]
        all_row = (
            self._analyze_group("ALL", all_members)
            if all_members else None
        )

        ordered: list[dict] = []
        if all_row is not None:
            ordered.append(all_row)
        if not df.empty:
            ordered.extend(df.to_dict("records"))
        self._render(ordered)

    def clear(self) -> None:
        self._panel = {}
        self._universe = None
        self._members_by_industry = {}
        self._user_selected = False
        self._render([])

    def members_for(self, industry: str) -> list[str]:
        """Return the member symbols for ``industry``. Returns the
        full panel for the special ``"ALL"`` row, [] for unknown
        industries.
        """
        if industry == "ALL":
            if self._universe is None:
                return []
            return [s for s in self._panel.keys() if s in self._universe.symbols]
        return list(self._members_by_industry.get(industry, []))

    def riding_map(self) -> dict[str, tuple[int, int]]:
        """Return ``{industry: (riders, members)}`` across all grouped
        industries — feeds the Early-Entry participation axis for the
        ALL cohort. Computed from the same stateless rollup the table
        rows use, so the participation fractions match the Riding
        column exactly."""
        out: dict[str, tuple[int, int]] = {}
        for name, members in self._members_by_industry.items():
            rollup = aggregate_industry(members, self._panel)
            if rollup is not None:
                out[name] = (rollup.riding, rollup.members)
        return out

    def is_known_industry(self, industry: str) -> bool:
        """Return True if ``industry`` matches one of the rows
        currently rendered (or the special ``"ALL"`` aggregate)."""
        if industry == "ALL":
            return self.has_all_row()
        return industry in self._members_by_industry

    def has_all_row(self) -> bool:
        """Return True if the pinned ALL aggregate row is currently
        rendered. False on an empty / unloaded table."""
        if self._table.rowCount() == 0:
            return False
        first = self._table.item(0, 0)
        return first is not None and first.text() == "ALL"

    def select_industry(
        self, industry: str, *, user_initiated: bool = False,
    ) -> bool:
        """Programmatically select the row matching ``industry``.

        Used by the Dashboard on initial panel push to default the
        Constituents table to a sensible industry (typically the
        chart symbol's industry, with ALL as fallback). Emits the
        same ``industry_selected`` signal a real click would, so
        downstream consumers don't have to special-case
        programmatic selection.

        Args:
            industry: industry name to select.
            user_initiated: True only when the caller is replaying a
                user click (rare). Programmatic defaults from
                ``set_panel`` should leave this False so subsequent
                ``set_symbol`` calls can still pivot the tables.

        Returns True iff a matching row was found and selected.
        """
        for r in range(self._table.rowCount()):
            cell = self._table.item(r, 0)
            if cell is None:
                continue
            stored = cell.data(Qt.ItemDataRole.UserRole) or cell.text()
            if str(stored) == industry:
                # Block the selection-changed signal during the
                # programmatic mutation; we'll set the flag and
                # re-emit explicitly so consumers still get the
                # callback but ``_user_selected`` stays accurate.
                self._table.blockSignals(True)
                try:
                    self._table.selectRow(r)
                finally:
                    self._table.blockSignals(False)
                self._user_selected = bool(user_initiated)
                self.industry_selected.emit(industry)
                return True
        return False

    def selected_industry(self) -> str | None:
        """Return the currently-selected industry name (or
        ``"ALL"``), or ``None`` when nothing is selected."""
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return None
        cell = self._table.item(rows[0].row(), 0)
        if cell is None:
            return None
        stored = cell.data(Qt.ItemDataRole.UserRole) or cell.text()
        return str(stored) if stored else None

    def is_user_pinned(self) -> bool:
        """Return True if the current selection came from a real
        user click (not a programmatic default). The Dashboard
        consults this when set_symbol decides whether to pivot the
        tables under a fresh chart symbol."""
        return self._user_selected

    # ── build ─────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        # Wrap the table in a PanelFrame so the bottom strip's two
        # cards visually echo the OPTIONS OVERLAY / INDUSTRY CONTEXT
        # cards on the right rail — same rounded corners, same
        # 1px subtle border, same coloured-accent top edge. We don't
        # pass a title to PanelFrame because we want the title and
        # count on a single row (matches the Constituents pattern):
        # ``INDUSTRIES · 51 industries · 473 symbols``. The
        # PanelFrame's stock title slot would render the title on
        # its own row above the body.
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self._frame = PanelFrame(accent=EM)
        outer.addWidget(self._frame)

        body = self._frame.content_layout()
        body.setSpacing(4)

        head = QHBoxLayout()
        head.setSpacing(8)
        title = QLabel("INDUSTRIES")
        title.setFont(QFont(FONT_UI, 7))
        title.setStyleSheet(
            f"color: {MUTED}; letter-spacing: 1px;"
        )
        head.addWidget(title)
        # Count: " · N industries · M symbols". Sits next to the
        # title on the same row.
        self._header_count = QLabel("")
        self._header_count.setFont(QFont(FONT_UI, 8))
        self._header_count.setStyleSheet(f"color: {MUTED};")
        head.addWidget(self._header_count)
        head.addStretch(1)
        # Compact search box — filters visible rows by substring match
        # across Group (and any text cell). Sits on the title row so it
        # adds no vertical height.
        self._search = QLineEdit()
        self._search.setPlaceholderText("filter…")
        self._search.setClearButtonEnabled(True)
        self._search.setFixedWidth(140)
        self._search.setFont(QFont(FONT_MONO, 8))
        self._search.setStyleSheet(_SEARCH_QSS)
        self._search.textChanged.connect(self._apply_filter)
        head.addWidget(self._search)
        body.addLayout(head)

        # Table.
        self._table = QTableWidget()
        self._table.setColumnCount(len(INDUSTRY_COLUMNS))
        self._table.setHorizontalHeaderLabels(INDUSTRY_COLUMNS)
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows,
        )
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection,
        )
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers,
        )
        # Alternating-row tint — pairs with the QSS rule that gives
        # every other row a faint BORDER tint, so dense lists are
        # easier to read across.
        self._table.setAlternatingRowColors(True)
        self._table.setShowGrid(False)
        self._table.setStyleSheet(_TABLE_QSS)
        # Sorting stays OFF: row order (ALL pinned first, then industries
        # by riding strength) is owned by refresh(). Enabling Qt sort
        # would unpin the ALL aggregate.
        self._table.setSortingEnabled(False)
        # Default row height — gives each cell more breathing room
        # than Qt's tight default. Bumped from implicit ~18px to 26.
        self._table.verticalHeader().setDefaultSectionSize(26)

        hdr = self._table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        # Group column stretches to absorb width.
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for i in range(1, len(INDUSTRY_COLUMNS)):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            self._table.setColumnWidth(
                i, _COL_WIDTHS.get(INDUSTRY_COLUMNS[i], 80),
            )

        self._table.itemSelectionChanged.connect(self._on_selection_changed)
        body.addWidget(self._table, stretch=1)

    def _apply_filter(self, text: str) -> None:
        """Hide rows that don't match the search box (substring, any
        column). The ALL row is always kept visible so the operator can
        still jump back to the full universe."""
        _filter_table_rows(self._table, text)
        # Keep the ALL row visible regardless of filter.
        for r in range(self._table.rowCount()):
            item = self._table.item(r, 0)
            if item is not None and item.text().strip().upper() == "ALL":
                self._table.setRowHidden(r, False)

    # ── analysis ──────────────────────────────────────────────────────────

    def _analyze_group(
        self, name: str, members: list[str],
    ) -> dict | None:
        """Build the ADTV + Riding row for one industry.

        Riding is now phase-independent: the count of members whose
        LAST bar's candle body is above the upper BB (the strategy's
        canonical ``body_above_band`` definition). The row carries a
        hidden ``_riding_strength`` (summed ADTV of those riders) used
        to sort the table — most/most-liquid riders first. All of it
        comes from the stateless
        :func:`compute.industry_rollup.aggregate_industry`; the widget
        renders, never computes.
        """
        rollup = aggregate_industry(members, self._panel)
        if rollup is None:
            return None

        return {
            "Group":  name,
            "ADTV":   rollup.adtv_total,
            "Riding": rollup.riding,
            "_members": rollup.members,
            "_riding_strength": rollup.riding_strength,
        }

    # ── render ────────────────────────────────────────────────────────────

    def _render(self, rows: list[dict]) -> None:
        # Sort handling: turn off while we mutate, restore after.
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(rows))

        n_industries = sum(1 for r in rows if r.get("Group") != "ALL")
        n_symbols = sum(
            len(self._members_by_industry.get(r.get("Group", ""), []))
            for r in rows if r.get("Group") != "ALL"
        )
        self._header_count.setText(
            f"· {n_industries} industries · {n_symbols} symbols"
            if n_industries else ""
        )

        for row_idx, row in enumerate(rows):
            for col_idx, col_name in enumerate(INDUSTRY_COLUMNS):
                val = row.get(col_name)
                if col_name == "Group":
                    item = QTableWidgetItem(str(val))
                    item.setData(Qt.ItemDataRole.UserRole, str(val))
                    if val == "ALL":
                        f = QFont(FONT_MONO, 9, QFont.Weight.Bold)
                        item.setFont(f)
                        item.setForeground(QColor(EM))
                    else:
                        item.setForeground(QColor(WHITE))
                elif col_name == "ADTV":
                    item = _NumericItem()
                    item.setText(format_adtv_m(val) if val is not None else "—")
                    if val is not None and val == val:
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                    item.setForeground(QColor(WHITE))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "Riding":
                    item = _NumericItem()
                    riders = int(val) if (val is not None and val == val) else 0
                    total = int(row.get("_members") or 0)
                    item.setText(f"{riders} / {total}" if total > 0 else "—")
                    item.setData(Qt.ItemDataRole.UserRole, float(riders))
                    item.setForeground(
                        QColor(WHITE if riders > 0 else MUTED),
                    )
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "Score":
                    item = _NumericItem()
                    if val is not None and val == val:
                        item.setText(f"{float(val):.0f}")
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                        item.setForeground(QColor(WHITE))
                    else:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                else:
                    item = QTableWidgetItem("")
                self._table.setItem(row_idx, col_idx, item)

        # Rows arrive already ordered by refresh(): ALL pinned first,
        # then industries by riding strength (ADTV-weighted body-above
        # count) descending. We deliberately DO NOT enable Qt's
        # column-click sorting here — it would re-order the rows by raw
        # cell value and unpin the ALL aggregate from the top, which is
        # exactly the bug where selecting a symbol / clicking a header
        # scrambled the ALL row. The order is owned by refresh().
        self._table.setSortingEnabled(False)

        # Re-apply any active search filter to the freshly built rows.
        if getattr(self, "_search", None) is not None and self._search.text():
            self._apply_filter(self._search.text())

    # ── selection ─────────────────────────────────────────────────────────

    def _on_selection_changed(self) -> None:
        # The selection-changed signal is blocked during programmatic
        # ``select_industry()`` calls, so this slot only runs for
        # real user clicks. Mark the selection as user-initiated so
        # the Dashboard knows not to overwrite it on the next
        # ``set_symbol`` call.
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return
        cell = self._table.item(rows[0].row(), 0)
        if cell is None:
            return
        industry = cell.data(Qt.ItemDataRole.UserRole) or cell.text()
        if industry:
            self._user_selected = True
            self.industry_selected.emit(str(industry))


# ══════════════════════════════════════════════════════════════════════════════
# ConstituentsTable
# ══════════════════════════════════════════════════════════════════════════════


class ConstituentsTable(QWidget):
    """Per-symbol table for one industry.

    Public API
    ──────────
        :meth:`set_industry(industry, members, panel)` — populate
            the table with one row per symbol in ``members``,
            classified individually.
        :meth:`clear()` — empty placeholder state.

    Signals
    ───────
        :attr:`symbol_activated(str)` — double-click on a row.
            MainWindow connects this to load the symbol on the
            chart.
    """

    symbol_activated = pyqtSignal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._build_ui()

    # ── public ────────────────────────────────────────────────────────────

    def set_industry(
        self,
        industry: str,
        members: list[str],
        panel: dict[str, pd.DataFrame],
        universe: Universe | None = None,
        industry_riding: dict[str, tuple[int, int]] | None = None,
    ) -> None:
        """Render rows for every member of ``industry`` present in
        ``panel``.

        Args:
            industry: human-readable industry name shown in the header.
            members: ordered list of member symbols to render.
            panel: shared enriched panel; missing members are skipped.
            universe: source for the ``Industry`` column.
            industry_riding: ``{industry: (riders, members)}`` for the
                Early-Entry participation axis. Supply ONLY for the ALL
                cohort; omit for a single-industry view (participation
                is constant there and stays dormant).
        """
        self._title.setText(
            f"CONSTITUENTS — {industry}"
            if industry else "CONSTITUENTS"
        )
        rows: list[dict] = []
        for sym in members:
            row = self._analyze_symbol(sym, panel.get(sym), universe)
            if row is not None:
                rows.append(row)
        self._inject_scores(rows, panel, universe, industry_riding)
        self._count.setText(
            f"· {len(rows)} symbols" if rows else ""
        )
        self._render(rows)

    def _inject_scores(
        self,
        rows: list[dict],
        panel: dict[str, pd.DataFrame],
        universe: Universe | None,
        industry_riding: dict[str, tuple[int, int]] | None,
    ) -> None:
        """Compute the cohort-relative Early-Entry score across the
        rendered rows and write it onto each row's ``Score``."""
        if not rows:
            return
        feats = []
        for r in rows:
            sym = r["Symbol"]
            ind = None
            if universe is not None:
                meta = universe.symbols.get(sym)
                if meta is not None:
                    ind = getattr(meta, "industry", None)
            feats.append(extract_features(sym, panel.get(sym), industry=ind))
        scores = score_cohort(feats, industry_riding=industry_riding)
        for r in rows:
            r["Score"] = scores.get(r["Symbol"], float("nan"))

    def set_title(self, text: str) -> None:
        """Override the panel title (used when the table is embedded in
        a non-constituents context, e.g. the Watchlist tab)."""
        self._title.setText(text)

    def clear(self) -> None:
        self._title.setText("CONSTITUENTS")
        self._count.setText("")
        self._render([])

    # ── build ─────────────────────────────────────────────────────────────

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Wrap in a PanelFrame for visual parity with OPTIONS OVERLAY
        # / INDUSTRY CONTEXT / INDUSTRIES. We don't pass a title to
        # PanelFrame because the title needs to update at runtime
        # ("CONSTITUENTS — Banks") — we render our own header row
        # inside the body instead.
        self._frame = PanelFrame(accent=BLUE)
        outer.addWidget(self._frame)

        body = self._frame.content_layout()
        body.setSpacing(4)

        head = QHBoxLayout()
        head.setSpacing(8)
        self._title = QLabel("CONSTITUENTS")
        # Match PanelFrame's stock title styling (FONT_UI 7pt, MUTED,
        # 1px letter-spacing) so the two cards look like siblings.
        # Using the same font / colour / spacing as the implicit
        # title PanelFrame would render means visual symmetry across
        # all four cards in the Workflow Analysis stack + bottom strip.
        self._title.setFont(QFont(FONT_UI, 7))
        self._title.setStyleSheet(
            f"color: {MUTED}; letter-spacing: 1px;"
        )
        head.addWidget(self._title)
        self._count = QLabel("")
        self._count.setFont(QFont(FONT_UI, 8))
        self._count.setStyleSheet(f"color: {MUTED};")
        head.addWidget(self._count)
        head.addStretch(1)
        # Per-table search — filters by symbol or industry substring.
        self._search = QLineEdit()
        self._search.setPlaceholderText("filter…")
        self._search.setClearButtonEnabled(True)
        self._search.setFixedWidth(160)
        self._search.setFont(QFont(FONT_MONO, 8))
        self._search.setStyleSheet(_SEARCH_QSS)
        self._search.textChanged.connect(self._apply_filter)
        head.addWidget(self._search)
        body.addLayout(head)

        self._table = QTableWidget()
        self._table.setColumnCount(len(CONSTITUENT_COLUMNS))
        self._table.setHorizontalHeaderLabels(CONSTITUENT_COLUMNS)
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows,
        )
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection,
        )
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers,
        )
        self._table.setAlternatingRowColors(True)
        self._table.setShowGrid(False)
        self._table.setStyleSheet(_TABLE_QSS)
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setDefaultSectionSize(26)

        hdr = self._table.horizontalHeader()
        # All columns Interactive — the operator can drag any
        # boundary to resize. Stretch mode would have prevented
        # dragging the column it was applied to. Setting the last
        # section non-stretch means the rightmost column doesn't
        # get force-extended; if the total column width exceeds the
        # viewport, the table grows a horizontal scrollbar (rare in
        # practice with 11 columns at ~85px each + a fixed sidebar).
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(False)
        # Set explicit starting widths. Symbol (col 0): 100px so
        # 9-character NSE tickers like ``BANDHANBNK`` fit. Industry
        # (col 1): 180px — wide enough for "Refineries & Marketing"
        # without truncation, and now user-resizable.
        self._table.setColumnWidth(0, 100)
        self._table.setColumnWidth(1, 180)
        for i in range(2, len(CONSTITUENT_COLUMNS)):
            self._table.setColumnWidth(
                i, _COL_WIDTHS.get(CONSTITUENT_COLUMNS[i], 80),
            )

        self._table.cellDoubleClicked.connect(self._on_activated)
        body.addWidget(self._table, stretch=1)

    def _apply_filter(self, text: str) -> None:
        """Hide rows that don't match the search box (substring across
        any column — symbol, industry, etc.)."""
        _filter_table_rows(self._table, text)

    # ── analysis ──────────────────────────────────────────────────────────

    @staticmethod
    def _analyze_symbol(
        sym: str,
        df: pd.DataFrame | None,
        universe: Universe | None = None,
    ) -> dict | None:
        # Per-symbol feature computation lives in the engine; the table
        # only assembles the row (engine features + industry label +
        # cohort Score injected later).
        feats = extract_constituent_features(sym, df)
        if feats is None:
            return None

        # Industry (fourth-level NSE classification) — sourced from
        # the Universe metadata. None / unset → em-dash.
        basic_industry = ""
        if universe is not None:
            meta = universe.symbols.get(sym)
            if meta is not None:
                basic_industry = (
                    getattr(meta, "basic_industry", "") or ""
                ).strip()

        return {
            "Symbol":   sym,
            "Industry": basic_industry,
            "ADTV":     feats.adtv,
            "Chg":      feats.chg_1d,
            "Chg 5d%":  feats.chg_5d,
            "Chg 10d%": feats.chg_10d,
            "%B":       feats.pct_b,
            "Vol":      feats.vol_ratio,
            "BBW":      feats.bbw,
            "Above":    feats.above,
            "Streak":   feats.streak,
            # Score is injected at the cohort level (see _inject_scores);
            # it's relative to the displayed set and can't be computed
            # per-row in isolation.
            "Score":    float("nan"),
        }

    # ── render ────────────────────────────────────────────────────────────

    def _render(self, rows: list[dict]) -> None:
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(rows))

        # Score-descending default order.
        rows = sorted(
            rows,
            key=lambda r: (
                # Sort key flips NaN to last regardless of direction
                # — same intent as _NumericItem's missing-value sink,
                # applied here at fill time so the initial render is
                # already in operator-friendly order.
                -1.0 if (r.get("Score") != r.get("Score")
                         or r.get("Score") is None)
                else float(r["Score"])
            ),
            reverse=True,
        )

        for row_idx, row in enumerate(rows):
            for col_idx, col_name in enumerate(CONSTITUENT_COLUMNS):
                val = row.get(col_name)
                if col_name == "Symbol":
                    item = QTableWidgetItem(str(val))
                    item.setForeground(QColor(WHITE))
                elif col_name == "Industry":
                    item = QTableWidgetItem(str(val) if val else "—")
                    item.setForeground(QColor(MUTED))
                elif col_name == "ADTV":
                    item = _NumericItem()
                    item.setText(
                        format_adtv_m(val) if val is not None else "—"
                    )
                    if val is not None and val == val:
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                    item.setForeground(QColor(WHITE))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name in ("Chg", "Chg 5d%", "Chg 10d%"):
                    item = _NumericItem()
                    if val is not None and val == val:
                        item.setText(f"{float(val):+.2f}")
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                        # Bullish / bearish colouring — positive green,
                        # negative red, near-zero white. Threshold is
                        # 0.0 (no dead-zone) since ROC is a clean
                        # percent and any sign carries information.
                        if float(val) > 0:
                            item.setForeground(QColor(GREEN))
                        elif float(val) < 0:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                    else:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "%B":
                    # %B as a Bollinger position: ≥1 = above upper band
                    # (riding), ≤0 = below lower band (capitulation),
                    # 0..1 = inside band (neutral). We highlight the
                    # extremes so the operator can scan a column of
                    # neutrals quickly.
                    item = _NumericItem()
                    if val is not None and val == val:
                        item.setText(f"{float(val):.2f}")
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                        if float(val) >= 1.0:
                            item.setForeground(QColor(GREEN))
                        elif float(val) <= 0.0:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                    else:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "Vol":
                    item = _NumericItem()
                    if val is not None and val == val:
                        item.setText(f"{float(val):.2f}x")
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                        # ≥1.5× mean = unusual participation; flag gold.
                        # ≤0.5× = volume drought, flag muted-red.
                        if float(val) >= 1.5:
                            item.setForeground(QColor(GOLD))
                        elif float(val) <= 0.5:
                            item.setForeground(QColor(RED))
                        else:
                            item.setForeground(QColor(WHITE))
                    else:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "BBW":
                    item = _NumericItem()
                    if val is not None and val == val:
                        item.setText(f"{float(val):.2f}")
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                        item.setForeground(QColor(WHITE))
                    else:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "Above":
                    item = _NumericItem()
                    is_above = bool(val)
                    item.setText("▲" if is_above else "—")
                    item.setData(Qt.ItemDataRole.UserRole,
                                 1.0 if is_above else 0.0)
                    item.setForeground(QColor(GREEN if is_above else MUTED))
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                elif col_name == "Streak":
                    item = _NumericItem()
                    n = int(val) if (val is not None and val == val) else 0
                    item.setText(str(n) if n > 0 else "—")
                    item.setData(Qt.ItemDataRole.UserRole, float(n))
                    item.setForeground(QColor(GREEN if n > 0 else MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                elif col_name == "Score":
                    item = _NumericItem()
                    if val is not None and val == val:
                        item.setText(f"{float(val):.0f}")
                        item.setData(Qt.ItemDataRole.UserRole, float(val))
                        item.setForeground(QColor(WHITE))
                    else:
                        item.setText("—")
                        item.setForeground(QColor(MUTED))
                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter,
                    )
                else:
                    item = QTableWidgetItem("")
                self._table.setItem(row_idx, col_idx, item)

        self._table.setSortingEnabled(True)
        self._table.sortByColumn(
            CONSTITUENT_COLUMNS.index("Score"),
            Qt.SortOrder.DescendingOrder,
        )

        # Re-apply any active search filter to the freshly built rows.
        if getattr(self, "_search", None) is not None and self._search.text():
            self._apply_filter(self._search.text())

    # ── activation ────────────────────────────────────────────────────────

    def _on_activated(self, row: int, _col: int) -> None:
        if row < 0:
            return
        cell = self._table.item(row, 0)
        if cell is None:
            return
        sym = cell.text().strip()
        if sym:
            self.symbol_activated.emit(sym)


# ══════════════════════════════════════════════════════════════════════════════
# Shared QSS
# ══════════════════════════════════════════════════════════════════════════════


_TABLE_QSS: Final[str] = f"""
QTableWidget {{
    background: transparent;
    color: {WHITE};
    border: 0;
    selection-background-color: {EM}33;
    selection-color: {WHITE};
    font-family: '{FONT_MONO}';
    font-size: 10pt;
    gridline-color: transparent;
    outline: 0;
}}
QHeaderView {{
    background: transparent;
    border: 0;
}}
QHeaderView::section {{
    background: transparent;
    color: {MUTED};
    border: 0;
    border-bottom: 1px solid {BORDER};
    padding: 6px 8px;
    font-family: '{FONT_UI}';
    font-size: 9pt;
    font-weight: 600;
    letter-spacing: 1px;
}}
QTableWidget::item {{
    padding: 6px 8px;
    border-bottom: 1px solid {BORDER}33;
}}
QTableWidget::item:selected {{
    background: {EM}33;
    color: {WHITE};
}}
QTableWidget::item:alternate {{
    background: {BORDER}11;
}}
QTableCornerButton::section {{
    background: transparent;
    border: 0;
}}
"""
