"""Tests for ScanResultsView and ConvictionPanel widgets."""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
import pytest

from nimbus_v3.conviction.formula import Contribution
from nimbus_v3.conviction.grade_engine import Conviction
from nimbus_v3.core.types import GradeLetter, SetupType, Sizing, Verdict
from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.ui.widgets.conviction_panel import ConvictionPanel
from nimbus_v3.ui.widgets.scan_results_view import ScanResultsView


_ASOF = pd.Timestamp("2024-05-15")


@dataclass
class _FakeStrategy:
    name: str = "MeanReversion"
    priority: int = 50
    production_weight: float = 1.0


def _mk_result(symbol="R", score=3.5, grade=GradeLetter.A, override=None):
    return ScanResult(
        symbol=symbol, asof_date=_ASOF, strategy=_FakeStrategy(),
        conviction=Conviction(
            symbol=symbol, asof_date=_ASOF, strategy_name="MeanReversion",
            setup_type=SetupType.MEAN_REVERSION,
            raw_score=score, score=score,
            grade=grade, verdict=Verdict.TAKE, sizing=Sizing.FULL,
            contributions=(
                Contribution("mfi", 0.7, "oversold"),
                Contribution("vix", 1.5, "HIGH regime"),
                Contribution("volume", 0.3, "ok"),
            ),
            production_weight=1.0, override_reason=override,
        ),
        close_price=100.0,
    )


# ══════════════════════════════════════════════════════════════════════════════
# ScanResultsView
# ══════════════════════════════════════════════════════════════════════════════

def test_view_initial_state_is_empty(qapp) -> None:   # noqa: ARG001
    view = ScanResultsView()
    # Empty-state widget is shown initially.
    assert view._stack.currentWidget() is view._empty_label


def test_view_shows_table_when_results_set(qapp) -> None:    # noqa: ARG001
    view = ScanResultsView()
    view.set_results([_mk_result("A"), _mk_result("B")])
    assert view._stack.currentWidget() is view._table


def test_view_reverts_to_empty_on_zero_results(qapp) -> None:    # noqa: ARG001
    view = ScanResultsView()
    view.set_results([_mk_result("A")])
    view.set_results([])
    assert view._stack.currentWidget() is view._empty_label


def test_view_emits_result_selected_signal(qapp) -> None:     # noqa: ARG001
    view = ScanResultsView()
    view.set_results([_mk_result("A"), _mk_result("B")])

    captured: list = []
    view.result_selected.connect(captured.append)

    # Programmatic selection of row 0.
    table = view._table
    index = view._proxy.index(0, 0)
    table.selectionModel().select(
        index,
        table.selectionModel().SelectionFlag.Select
        | table.selectionModel().SelectionFlag.Rows,
    )
    # Qt event loop processes selection synchronously in tests.
    qapp.processEvents()
    assert len(captured) == 1
    assert isinstance(captured[0], ScanResult)


# ══════════════════════════════════════════════════════════════════════════════
# ConvictionPanel
# ══════════════════════════════════════════════════════════════════════════════

def test_panel_initial_state_empty(qapp) -> None:     # noqa: ARG001
    panel = ConvictionPanel()
    assert panel._header_label.text().startswith("Select a signal")
    assert panel._override_label.isVisibleTo(panel) is False


def test_panel_set_result_populates(qapp) -> None:     # noqa: ARG001
    panel = ConvictionPanel()
    panel.show()          # realize for visibility queries
    r = _mk_result("RELIANCE")
    panel.set_result(r)
    assert "RELIANCE" in panel._header_label.text()
    assert "MeanReversion" in panel._header_label.text()


def test_panel_renders_contribution_rows(qapp) -> None:   # noqa: ARG001
    panel = ConvictionPanel()
    r = _mk_result("R")
    panel.set_result(r)
    # One widget per contribution, plus the trailing stretch item.
    # Layout count = 3 contributions + 1 stretch = 4.
    assert panel._contributions_layout.count() == 4


def test_panel_shows_override_when_present(qapp) -> None:    # noqa: ARG001
    panel = ConvictionPanel()
    panel.show()
    r = _mk_result("R", override="research-only strategy (production_weight=0)")
    panel.set_result(r)
    assert panel._override_label.isVisibleTo(panel) is True
    assert "research-only" in panel._override_label.text()


def test_panel_hides_override_when_absent(qapp) -> None:    # noqa: ARG001
    panel = ConvictionPanel()
    panel.show()
    # First set one with override, then one without — ensure override hides.
    panel.set_result(_mk_result("R", override="TRAP"))
    panel.set_result(_mk_result("S"))
    assert panel._override_label.isVisibleTo(panel) is False


def test_panel_set_result_none_clears(qapp) -> None:    # noqa: ARG001
    panel = ConvictionPanel()
    panel.set_result(_mk_result("R"))
    panel.set_result(None)
    assert panel._header_label.text().startswith("Select a signal")


def test_panel_replace_result_clears_previous_contributions(qapp) -> None:  # noqa: ARG001
    panel = ConvictionPanel()
    r1 = _mk_result("R1")
    r2 = _mk_result("R2")
    panel.set_result(r1)
    panel.set_result(r2)
    # Still 3 contributions + stretch = 4 total, not 6+1.
    assert panel._contributions_layout.count() == 4
