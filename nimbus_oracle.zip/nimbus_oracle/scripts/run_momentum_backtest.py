#!/usr/bin/env python3
"""
scripts/run_momentum_backtest.py — Momentum breakout strategy for low-VIX periods.

Problem: Mean reversion only fires during pullbacks. During sustained uptrends
(VIX 13-18, steady grind), there are no oversold stocks to buy. The system
sits idle for weeks/months.

Strategy: Buy breakouts above N-day high with volume confirmation.
  Entry: Close > max(Close, N days) AND Volume > 1.5× avg(20)
         AND weekly SMA rising AND price > weekly SMA
  Exit:  Close < SMA(20) OR trailing stop (2× ATR from peak) OR 30d max

This is a COMPLEMENTARY strategy — runs ONLY when VIX < 18 (Normal/Low).
Mean reversion handles Elevated/Panic VIX.

Tests multiple breakout lookback periods (10, 15, 20, 30 days).

Usage:
    python3 scripts/run_momentum_backtest.py
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("momentum_bt")


def scan_breakouts(price_df, lookback=20, vol_mult=1.5, min_bars=100):
    """
    Scan for breakout entries in a single stock's price history.
    Returns list of (entry_date, entry_price) tuples.
    """
    if price_df is None or len(price_df) < min_bars:
        return []

    df = price_df.copy()
    df["high_N"] = df["Close"].shift(1).rolling(lookback).max()
    df["vol_avg"] = df["Volume"].rolling(20).mean()
    df["sma_20"] = df["Close"].rolling(20).mean()

    # Weekly SMA for trend
    weekly = df["Close"].resample("W").last().dropna()
    weekly_sma = weekly.rolling(50).mean()
    # Map back to daily
    df["weekly_sma"] = weekly_sma.reindex(df.index, method="ffill")

    # ATR for trailing stop
    tr = pd.concat([
        df["High"] - df["Low"],
        (df["High"] - df["Close"].shift(1)).abs(),
        (df["Low"] - df["Close"].shift(1)).abs(),
    ], axis=1).max(axis=1)
    df["atr_14"] = tr.rolling(14).mean()

    entries = []
    df = df.dropna(subset=["high_N", "vol_avg", "weekly_sma", "atr_14"])

    for i in range(len(df)):
        row = df.iloc[i]
        # Entry conditions
        if (row["Close"] > row["high_N"]                    # breakout above N-day high
            and row["Volume"] > vol_mult * row["vol_avg"]    # volume confirmation
            and row["Close"] > row["weekly_sma"]              # above weekly SMA
            and row["sma_20"] > df["sma_20"].iloc[max(0,i-5)] * 0.998  # SMA not falling
           ):
            entries.append((df.index[i], float(row["Close"]), float(row["atr_14"])))

    return entries


def simulate_momentum_exit(entry_date, entry_price, entry_atr, price_df, max_days=30):
    """
    Simulate momentum exit:
      - Close < SMA(20) → exit (trend broken)
      - Trailing stop: 2× ATR from peak
      - Max 30 days
    """
    future = price_df[price_df.index > entry_date].head(max_days)
    if future.empty:
        return entry_date, entry_price, "NO_DATA", 0, 0

    sma_20 = price_df["Close"].rolling(20).mean()
    peak = entry_price
    trail_mult = 2.0

    for dt, row in future.iterrows():
        close = float(row["Close"])
        high = float(row.get("High", close))
        low = float(row.get("Low", close))
        days = (dt - entry_date).days

        peak = max(peak, high)
        trail_stop = peak - trail_mult * entry_atr

        # Trailing stop hit
        if low <= trail_stop:
            pnl = (trail_stop - entry_price) / entry_price * 100
            return dt, trail_stop, "TRAIL", pnl, days

        # SMA break (trend broken)
        if dt in sma_20.index and not pd.isna(sma_20[dt]):
            if close < sma_20[dt]:
                pnl = (close - entry_price) / entry_price * 100
                return dt, close, "SMA_BREAK", pnl, days

    # Max days
    last = future.iloc[-1]
    close = float(last["Close"])
    pnl = (close - entry_price) / entry_price * 100
    return future.index[-1], close, "MAX", pnl, (future.index[-1] - entry_date).days


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="momentum_backtest_report.txt")
    args = parser.parse_args()

    # Load all price caches
    price_cache = {}
    cache_dir = "data/backtest_cache"
    if os.path.exists(cache_dir):
        for f in os.listdir(cache_dir):
            if f.endswith("_1d.parquet"):
                sym = f.replace("_1d.parquet", "")
                try:
                    df = pd.read_parquet(os.path.join(cache_dir, f))
                    df.index = pd.to_datetime(df.index)
                    if hasattr(df.index, "tz") and df.index.tz is not None:
                        df.index = df.index.tz_localize(None)
                    price_cache[sym] = df
                except: pass
    logger.info("Price cache: %d symbols", len(price_cache))

    # Load VIX
    import yfinance as yf
    vix_df = yf.download("^INDIAVIX", start="2022-01-01", end="2025-12-31", progress=False)
    if isinstance(vix_df.columns, pd.MultiIndex):
        vix_df.columns = vix_df.columns.get_level_values(0)
    vix_df.index = pd.to_datetime(vix_df.index)
    if hasattr(vix_df.index, "tz") and vix_df.index.tz is not None:
        vix_df.index = vix_df.index.tz_localize(None)
    vix_series = vix_df["Close"]

    report = []
    report.append("=" * 70)
    report.append("MOMENTUM BREAKOUT STRATEGY BACKTEST")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Universe: {len(price_cache)} symbols")
    report.append("=" * 70)

    # Test multiple lookback periods
    for lookback in [10, 15, 20, 30]:
        report.append(f"\n{'=' * 70}")
        report.append(f"LOOKBACK: {lookback}-DAY HIGH BREAKOUT")
        report.append(f"{'=' * 70}")

        # Scan all symbols for breakouts
        all_trades = []
        for sym, pdf in price_cache.items():
            entries = scan_breakouts(pdf, lookback=lookback)
            for entry_date, entry_price, entry_atr in entries:
                # Get VIX at entry
                vmask = vix_series.index <= entry_date
                if not vmask.any(): continue
                vix = float(vix_series[vmask].iloc[-1])

                # Filter: OOS period only (2022-10 to 2025-10)
                if entry_date < pd.Timestamp("2022-10-01") or entry_date > pd.Timestamp("2025-10-31"):
                    continue

                # Simulate exit
                dt, px, reason, pnl, hold = simulate_momentum_exit(
                    entry_date, entry_price, entry_atr, pdf
                )

                vix_regime = "PANIC" if vix > 25 else ("ELEVATED" if vix >= 20 else ("NORMAL" if vix >= 13 else "LOW"))
                all_trades.append({
                    "symbol": sym, "entry_date": entry_date,
                    "pnl_pct": pnl, "exit_reason": reason, "hold_days": hold,
                    "vix": vix, "vix_regime": vix_regime,
                })

        tdf = pd.DataFrame(all_trades)
        if len(tdf) < 30:
            report.append(f"  Too few trades: {len(tdf)}")
            continue

        tdf["win"] = tdf["pnl_pct"] > 0

        # Remove duplicate entries (same symbol within 5 days)
        tdf = tdf.sort_values(["symbol", "entry_date"])
        keep = []
        for sym in tdf["symbol"].unique():
            sym_trades = tdf[tdf["symbol"] == sym].sort_values("entry_date")
            last_entry = pd.Timestamp("2000-01-01")
            for _, t in sym_trades.iterrows():
                if (t["entry_date"] - last_entry).days >= 5:
                    keep.append(t)
                    last_entry = t["entry_date"]
        tdf = pd.DataFrame(keep)
        tdf["win"] = tdf["pnl_pct"] > 0

        logger.info("  Lookback=%d: %d trades", lookback, len(tdf))

        # Overall stats
        wr = tdf["win"].mean() * 100
        avg = tdf["pnl_pct"].mean()
        std = tdf["pnl_pct"].std()
        sh = avg / std * np.sqrt(252/10) if std > 0 else 0
        wins = tdf[tdf["pnl_pct"] > 0]["pnl_pct"].sum()
        losses = abs(tdf[tdf["pnl_pct"] < 0]["pnl_pct"].sum())
        pf = wins / losses if losses > 0 else 999
        avg_hold = tdf["hold_days"].mean()

        report.append(f"\n  OVERALL:  N={len(tdf):5d}  Win={wr:.1f}%  Avg={avg:+.3f}%  Sh={sh:.2f}  PF={pf:.2f}  Hold={avg_hold:.0f}d")

        # Exit reasons
        for reason in ["TRAIL", "SMA_BREAK", "MAX"]:
            sub = tdf[tdf["exit_reason"] == reason]
            if len(sub) > 0:
                pct = len(sub) / len(tdf) * 100
                sub_avg = sub["pnl_pct"].mean()
                report.append(f"  Exit {reason:10s}: {pct:4.0f}%  Avg={sub_avg:+.3f}%")

        # By VIX regime
        report.append(f"\n  {'VIX Regime':12s} {'N':>5s} {'Win%':>6s} {'Avg':>7s} {'Sh':>6s}")
        for regime in ["LOW", "NORMAL", "ELEVATED", "PANIC"]:
            sub = tdf[tdf["vix_regime"] == regime]
            if len(sub) < 10: continue
            r_wr = sub["win"].mean() * 100
            r_avg = sub["pnl_pct"].mean()
            r_std = sub["pnl_pct"].std()
            r_sh = r_avg / r_std * np.sqrt(252/10) if r_std > 0 else 0
            report.append(f"  {regime:12s} {len(sub):5d} {r_wr:5.1f}% {r_avg:+6.3f}% {r_sh:5.2f}")

        # LOW + NORMAL only (the target market)
        calm = tdf[tdf["vix_regime"].isin(["LOW", "NORMAL"])]
        if len(calm) >= 20:
            c_wr = calm["win"].mean() * 100
            c_avg = calm["pnl_pct"].mean()
            c_std = calm["pnl_pct"].std()
            c_sh = c_avg / c_std * np.sqrt(252/10) if c_std > 0 else 0
            report.append(f"\n  LOW+NORMAL ONLY: N={len(calm):5d}  Win={c_wr:.1f}%  Avg={c_avg:+.3f}%  Sh={c_sh:.2f}")

    # ══════════════════════════════════════════════════════════════════
    # COMPARISON: Mean Reversion vs Momentum by VIX regime
    # ══════════════════════════════════════════════════════════════════
    report.append(f"\n{'=' * 70}")
    report.append("REGIME ALLOCATION: WHEN TO USE WHICH STRATEGY")
    report.append(f"{'=' * 70}")
    report.append("""
  The goal: use MOMENTUM during LOW/NORMAL VIX, MEAN REVERSION during
  ELEVATED/PANIC VIX. Compare with the backtest results above.

  If momentum Sharpe > 0.5 during LOW+NORMAL VIX, it's worth adding.
  The system switches strategies based on VIX regime — not a prediction,
  just reading the current environment.

  ELEVATED/PANIC → Mean reversion (pullback buying) [current system]
  LOW/NORMAL     → Momentum breakout (trend following) [new strategy]
""")

    report_text = "\n".join(report)
    print(report_text)
    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nSaved: %s", args.output)


if __name__ == "__main__":
    main()
