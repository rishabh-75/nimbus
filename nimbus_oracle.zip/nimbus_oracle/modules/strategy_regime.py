"""
modules/strategy_regime.py — Rolling per-strategy regime detector.

Computes 90-day rolling Sharpe ratio per strategy mode from the signal tracker
DB. Surfaces a DORMANT flag when Sharpe falls below 0 over the rolling window.

The 2024+ era analysis showed:
  - BB Ride: Sharpe 1.24 → 0.15 (broken — regime collapse)
  - MR overall: Sharpe 1.32 → 1.03 (mild degradation)
  - MR LEADING: Sharpe held up (1.91 → 2.65 actually improved)
  - MR PANIC/ELEVATED: improved significantly in 2024+

Strategies behave differently across regimes. The detector lets the user
SEE which strategy is currently working without having to recompute.

Used by main_window status bar to display:
  MR Sh+0.45 · Ride Sh-0.40 [DORMANT]
"""

from __future__ import annotations

import datetime
import logging
import os
import sqlite3
import time
from dataclasses import dataclass, field

import numpy as np

logger = logging.getLogger(__name__)

_DB_PATH = None  # resolved lazily on first use


def _get_db_path() -> str:
    """Defer DB path resolution to signal_tracker so both stay in sync."""
    global _DB_PATH
    if _DB_PATH is None:
        try:
            from modules.signal_tracker import _DB_PATH as TRACKER_DB
            _DB_PATH = TRACKER_DB
        except Exception:
            # Fallback if signal_tracker import fails
            _DB_PATH = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "data", "signal_tracker.db",
            )
    return _DB_PATH

# Indian risk-free rate proxy: 10Y G-Sec yield ~7%
# Used to compute excess return per trade. Trades that just earn risk-free
# add nothing — Q score should reflect alpha over the safe alternative.
_RFR_ANNUAL = 0.07
_AVG_HOLD_DAYS = 10  # MR ~10 bars, Ride ~9 bars — close enough for both
_TRADE_RFR_PCT = (_RFR_ANNUAL / 252) * _AVG_HOLD_DAYS * 100  # ~0.278% per trade

# Annualization: trading days / avg holding period
_ANNUALIZATION_FACTOR = np.sqrt(252 / _AVG_HOLD_DAYS)

# Dormancy threshold: rolling Q-score below this → strategy dormant
_DORMANT_THRESHOLD = 0.0

# Minimum N for meaningful Q-score — fewer than this is "calibrating"
_MIN_TRADES_FOR_REGIME = 15

# Hybrid mode threshold: if open positions are more than this fraction of
# the total sample, the Q score is "hybrid-heavy" and gets a * suffix.
_HYBRID_HEAVY_THRESHOLD = 0.30

# Mode grouping — collapses raw DB `mode` values into canonical strategy
# buckets for the regime detector. Both PRIMARY and SECONDARY tiers come from
# the SAME mean-reversion strategy (dual_mode.py); SECONDARY is just the
# looser entry tier. They should be tracked together as one strategy ("MR").
# RIDE is a genuinely separate strategy (BB Ride momentum).
#
# As of 2026-04-08: SECONDARY tier is disabled in production
# (ENABLE_SECONDARY_TIER=False in dual_mode.py). The map still includes
# SECONDARY because historical signals in the DB use that mode value, and
# the resolver still processes them. New signals will only have mode=PRIMARY.
_MODE_GROUP_MAP = {
    "PRIMARY":   "MR",
    "SECONDARY": "MR",   # SECONDARY is MR's looser entry tier, NOT Ride
    "RIDE":      "RIDE",
}

# Price cache for mark-to-market — keyed by symbol, refreshed every 5 minutes.
# Avoids hammering yfinance on every regime refresh.
_PRICE_CACHE: dict[str, tuple[float, float]] = {}  # symbol -> (price, timestamp)
_PRICE_CACHE_TTL = 300  # 5 minutes


@dataclass
class StrategyRegime:
    """Per-strategy regime stats.

    quality_score: trade-level Sharpe-like metric using 7% risk-free baseline.
                   Q = (mean(pnl) - trade_rfr) / std(pnl) * sqrt(252/hold_days)
                   Measures excess return per unit of trade volatility.
                   NOT a benchmark-relative metric (no NIFTY comparison) —
                   that's planned as a separate IR metric in future iteration.

    Hybrid mode (resolved + open):
      n_resolved: realized trades from signal_tracker DB
      n_open: open positions valued at current price (mark-to-market)
      is_hybrid_heavy: True if open trades are >30% of sample (indicates
                      Q value should be read with extra caution)
    """
    mode: str = ""
    n_trades: int = 0
    n_resolved: int = 0
    n_open: int = 0
    win_rate: float = 0.0
    avg_pnl: float = 0.0
    quality_score: float = 0.0
    state: str = "UNKNOWN"  # ACTIVE, DORMANT, CALIBRATING, PENDING, NO_DATA
    window_days: int = 90
    is_hybrid_heavy: bool = False


@dataclass
class RegimeSnapshot:
    """All strategy regimes at a point in time."""
    regimes: dict[str, StrategyRegime] = field(default_factory=dict)
    timestamp: datetime.datetime = field(default_factory=datetime.datetime.now)

    def get(self, mode: str) -> StrategyRegime:
        return self.regimes.get(mode, StrategyRegime(mode=mode, state="NO_DATA"))


def _get_current_price(symbol: str) -> float | None:
    """
    Fetch current price for a symbol with 5-minute caching.
    Returns None on failure (caller should skip the trade).
    Uses modules.data.get_price_daily which is already battle-tested.
    """
    now = time.time()
    cached = _PRICE_CACHE.get(symbol)
    if cached and (now - cached[1]) < _PRICE_CACHE_TTL:
        return cached[0]

    try:
        from modules.data import get_price_daily
        df, _ = get_price_daily(symbol, days=10)
        if df is None or df.empty:
            return None
        price = float(df["Close"].iloc[-1])
        _PRICE_CACHE[symbol] = (price, now)
        return price
    except Exception as exc:
        logger.debug("Mark-to-market price fetch failed for %s: %s", symbol, exc)
        return None


def compute_strategy_regimes(window_days: int = 90) -> RegimeSnapshot:
    """
    Compute rolling regime stats per strategy mode using HYBRID computation:
      - Resolved trades contribute realized PnL (from signal_tracker DB)
      - Open positions contribute mark-to-market PnL (current price vs entry)

    The hybrid approach gives a current view of regime instead of lagging
    by the hold period (~10 days). Open positions are valued at the latest
    cached/fetched price; failures are skipped silently.

    Returns RegimeSnapshot with state per mode:
      ACTIVE       — Q > 0, n_total >= MIN_TRADES
      DORMANT      — Q < 0, n_total >= MIN_TRADES (strategy not working)
      CALIBRATING  — n_total < MIN_TRADES (not enough data yet)
      PENDING      — signals logged but mark-to-market also failed
      NO_DATA      — no signals at all

    is_hybrid_heavy is True when open positions are >30% of the sample —
    a hint that the Q value is more provisional than realized.
    """
    snapshot = RegimeSnapshot()
    db_path = _get_db_path()

    if not os.path.exists(db_path):
        logger.debug("Signal tracker DB not found, returning empty regime snapshot")
        return snapshot

    cutoff = (datetime.date.today() - datetime.timedelta(days=window_days)).isoformat()

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row

        # Resolved trades within window — realized PnL
        resolved_rows = conn.execute(
            """SELECT mode, pnl_pct
               FROM signals
               WHERE resolved = 1
                 AND signal_date >= ?
                 AND pnl_pct IS NOT NULL""",
            (cutoff,),
        ).fetchall()

        # Unresolved (open) trades — need mark-to-market valuation
        open_rows = conn.execute(
            """SELECT mode, symbol, entry_price
               FROM signals
               WHERE resolved = 0
                 AND signal_date >= ?
                 AND entry_price IS NOT NULL
                 AND entry_price > 0""",
            (cutoff,),
        ).fetchall()

        conn.close()
    except Exception as exc:
        logger.warning("Strategy regime query failed: %s", exc)
        return snapshot

    # Build resolved-pnl lookup, grouping modes into canonical strategy buckets
    resolved_by_mode: dict[str, list[float]] = {}
    for r in resolved_rows:
        raw_mode = r["mode"] or "UNKNOWN"
        mode = _MODE_GROUP_MAP.get(raw_mode, raw_mode)
        resolved_by_mode.setdefault(mode, []).append(float(r["pnl_pct"]))

    # Mark-to-market open positions
    open_by_mode: dict[str, list[float]] = {}
    open_logged_by_mode: dict[str, int] = {}  # all open signals (including failed M2M)
    for r in open_rows:
        raw_mode = r["mode"] or "UNKNOWN"
        mode = _MODE_GROUP_MAP.get(raw_mode, raw_mode)
        open_logged_by_mode[mode] = open_logged_by_mode.get(mode, 0) + 1

        symbol = r["symbol"]
        entry_price = float(r["entry_price"])
        current_price = _get_current_price(symbol)
        if current_price is None or entry_price <= 0:
            continue
        m2m_pnl = (current_price / entry_price - 1) * 100
        open_by_mode.setdefault(mode, []).append(m2m_pnl)

    # Iterate union of all modes seen
    all_modes = set(resolved_by_mode.keys()) | set(open_logged_by_mode.keys())

    for mode in all_modes:
        resolved_pnls = resolved_by_mode.get(mode, [])
        open_pnls = open_by_mode.get(mode, [])
        n_resolved = len(resolved_pnls)
        n_open_valued = len(open_pnls)
        n_open_logged = open_logged_by_mode.get(mode, 0)
        combined = resolved_pnls + open_pnls
        n_total = len(combined)

        regime = StrategyRegime(
            mode=mode,
            n_trades=n_total,
            n_resolved=n_resolved,
            n_open=n_open_valued,
            window_days=window_days,
        )

        if n_resolved == 0 and n_open_logged == 0:
            regime.state = "NO_DATA"
        elif n_total == 0:
            # Signals logged but every mark-to-market failed (no live prices)
            regime.state = "PENDING"
            regime.n_trades = n_open_logged
        elif n_total < _MIN_TRADES_FOR_REGIME:
            regime.state = "CALIBRATING"
            arr = np.array(combined)
            regime.win_rate = float((arr > 0).mean() * 100)
            regime.avg_pnl = float(arr.mean())
        else:
            arr = np.array(combined)
            regime.win_rate = float((arr > 0).mean() * 100)
            regime.avg_pnl = float(arr.mean())
            std = float(arr.std())
            if std > 0:
                # Excess return over per-trade risk-free rate, annualized
                excess = arr - _TRADE_RFR_PCT
                regime.quality_score = float(excess.mean() / std * _ANNUALIZATION_FACTOR)
            regime.state = "DORMANT" if regime.quality_score < _DORMANT_THRESHOLD else "ACTIVE"
            # Flag as hybrid-heavy if open positions dominate the sample
            if n_total > 0 and (n_open_valued / n_total) > _HYBRID_HEAVY_THRESHOLD:
                regime.is_hybrid_heavy = True

        snapshot.regimes[mode] = regime

    return snapshot


def format_status_text(snapshot: RegimeSnapshot) -> str:
    """
    Format regime snapshot for status bar display.

    Leads with a COMBINED MARKET VERDICT reflecting the correlation finding
    (Pearson +0.64, sign agreement 80.6%): MR and Ride are essentially
    measuring the same underlying alpha. When one works, the other usually
    works. When one breaks, the other usually breaks. So the top-line message
    should be about the market state, not a per-strategy focus recommendation.

    Per-strategy Q scores are still shown (for diagnostic purposes) but the
    lead message is the verdict.

    Market verdict states:
      "alpha paying out"      — both strategies working (both Q ≥ 0)
      "alpha not paying out"  — both strategies dormant (both Q < 0) + sit-out
      "mixed signals"         — one working, one dormant (caution)
      "warming up"            — at least one still calibrating
      "no data yet"           — empty snapshot

    Example outputs:
      "alpha paying out · MR Q+1.05 · Ride Q+0.85"
      "alpha not paying out · MR Q-0.40 · Ride Q-0.20 — sit out"
      "mixed signals · MR Q+0.60 · Ride Q-0.20 — caution"
      "warming up · MR Q+1.05 (18 trades) · Ride warming up (8 trades)"
      "MR no data yet (5 logged) · Ride no data yet (12 logged)"
      "no data yet"

    The "*" suffix on Q indicates hybrid-heavy (>30% mark-to-market).

    Q score: per-trade Sharpe-like metric using 7% RFR baseline.
    Q ≥ 0 means "earning excess return over risk-free", Q < 0 means dormant.
    """
    if not snapshot.regimes:
        return "no data yet"

    # After mode grouping, regimes are keyed by canonical buckets ("MR", "RIDE")
    # not raw DB modes ("PRIMARY", "SECONDARY", "RIDE"). See _MODE_GROUP_MAP.
    display_order = ["MR", "RIDE"]
    label_map = {"MR": "MR", "RIDE": "Ride"}

    def _format_one(r: StrategyRegime, label: str) -> tuple[str | None, str]:
        """
        Returns (display_text, state_tag).
        state_tag is one of: 'working', 'dormant', 'warming', 'pending', ''
        display_text is the per-strategy chunk to show after the verdict.
        """
        if r.state == "NO_DATA":
            return (None, "")

        if r.state == "PENDING":
            return (f"{label} no data yet ({r.n_trades} logged)", "pending")

        if r.state == "CALIBRATING":
            n_total = r.n_resolved + r.n_open
            n_str = f"{n_total} trades" if n_total != 1 else "1 trade"
            return (f"{label} warming up ({n_str})", "warming")

        # ACTIVE or DORMANT — has enough data to score
        sign = "+" if r.quality_score >= 0 else ""
        marker = "*" if r.is_hybrid_heavy else ""
        q_str = f"Q{sign}{r.quality_score:.2f}{marker}"
        state_tag = "dormant" if r.state == "DORMANT" else "working"
        return (f"{label} {q_str}", state_tag)

    # Collect all per-strategy chunks in display order
    parts = []
    states_by_label: dict[str, str] = {}

    for mode in display_order:
        if mode not in snapshot.regimes:
            continue
        r = snapshot.regimes[mode]
        label = label_map.get(mode, mode)
        text, state_tag = _format_one(r, label)
        if text is None:
            continue
        parts.append(text)
        states_by_label[label] = state_tag

    # Catch any unusual modes not in display_order
    for mode, r in snapshot.regimes.items():
        if mode in display_order:
            continue
        text, state_tag = _format_one(r, mode)
        if text is None:
            continue
        parts.append(text)
        states_by_label[mode] = state_tag

    if not parts:
        return "no data yet"

    # Determine combined market verdict
    state_values = list(states_by_label.values())
    n_working = state_values.count("working")
    n_dormant = state_values.count("dormant")
    n_uncertain = sum(1 for v in state_values if v in ("warming", "pending"))

    per_strategy = " · ".join(parts)

    # Case 1: everything scored, all working → "alpha paying out"
    if n_working > 0 and n_dormant == 0 and n_uncertain == 0:
        return f"alpha paying out · {per_strategy}"

    # Case 2: everything scored, all dormant → "alpha not paying out"
    if n_dormant > 0 and n_working == 0 and n_uncertain == 0:
        return f"alpha not paying out · {per_strategy} — sit out"

    # Case 3: mixed (some working, some dormant) → "mixed signals"
    if n_working > 0 and n_dormant > 0:
        return f"mixed signals · {per_strategy} — caution"

    # Case 4: some working, some still calibrating → show "warming up" prefix
    # Partial info — don't pretend to know the full verdict yet
    if n_working > 0 and n_uncertain > 0 and n_dormant == 0:
        return f"warming up · {per_strategy}"

    # Case 5: some dormant, some still calibrating → caution prefix
    if n_dormant > 0 and n_uncertain > 0:
        return f"warming up · {per_strategy} — caution"

    # Case 6: all uncertain (all warming/pending) → just show the parts
    return per_strategy


def overall_dormant(snapshot: RegimeSnapshot) -> bool:
    """True if ANY strategy is currently dormant."""
    return any(r.state == "DORMANT" for r in snapshot.regimes.values())
