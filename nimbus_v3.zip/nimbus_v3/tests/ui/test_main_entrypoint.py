"""Tests for the project-root main.py entrypoint.

Coverage:
- Argument parser shape (default values + every flag).
- Font loading helper (graceful when assets missing or present).
- Splash construction (smoke — produces a QSplashScreen with the
  expected dark-slate pixmap).
- Splash message helper (calls through to splash.showMessage).

We do NOT smoke-test ``main()`` end-to-end because it loads the full
equity panel, builds NSE clients, and opens a GUI — those paths are
covered by their own modules' tests. The contract here is just that
the entrypoint scaffolding is correct.
"""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest


_PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_PROJECT_ROOT))


@pytest.fixture(scope="module")
def main_module():
    """Import main fresh so the module-level logging doesn't interfere
    with other tests' caplog assertions."""
    if "main" in sys.modules:
        importlib.reload(sys.modules["main"])
    return importlib.import_module("main")


# ══════════════════════════════════════════════════════════════════════════════
# Argument parser
# ══════════════════════════════════════════════════════════════════════════════

def test_parse_args_defaults(main_module, monkeypatch) -> None:
    monkeypatch.setattr(sys, "argv", ["main.py"])
    args = main_module._parse_args()
    assert args.date is None
    assert args.track is None
    assert args.no_live_vix is False
    assert args.no_live_sector is False
    assert args.no_live_filing is False
    assert args.no_live_options is True
    assert args.no_macro is False


def test_parse_args_offline_mode(main_module, monkeypatch) -> None:
    monkeypatch.setattr(sys, "argv", [
        "main.py", "--no-live-vix", "--no-live-sector",
        "--no-live-filing", "--no-live-options",
    ])
    args = main_module._parse_args()
    assert args.no_live_vix is True
    assert args.no_live_sector is True
    assert args.no_live_filing is True
    assert args.no_live_options is True
    # --no-macro not passed → False
    assert args.no_macro is False


def test_parse_args_no_live_options_alone(main_module, monkeypatch) -> None:
    """--no-live-options can be passed independently of other live flags."""
    monkeypatch.setattr(sys, "argv", ["main.py", "--no-live-options"])
    args = main_module._parse_args()
    assert args.no_live_options is True
    assert args.no_live_vix is False
    assert args.no_live_sector is False
    assert args.no_live_filing is False


def test_parse_args_with_date(main_module, monkeypatch) -> None:
    monkeypatch.setattr(sys, "argv", ["main.py", "--date", "2025-06-01"])
    args = main_module._parse_args()
    assert args.date == "2025-06-01"


def test_parse_args_with_track(main_module, monkeypatch, tmp_path) -> None:
    db = tmp_path / "signals.db"
    monkeypatch.setattr(sys, "argv", ["main.py", "--track", str(db)])
    args = main_module._parse_args()
    assert args.track == str(db)


def test_parse_args_no_macro(main_module, monkeypatch) -> None:
    monkeypatch.setattr(sys, "argv", ["main.py", "--no-macro"])
    args = main_module._parse_args()
    assert args.no_macro is True


# ══════════════════════════════════════════════════════════════════════════════
# Font loading
# ══════════════════════════════════════════════════════════════════════════════

def test_load_fonts_returns_count(main_module, qapp) -> None:    # noqa: ARG001
    """In environments that have the bundled fonts, _load_fonts loads them.
    In environments that don't, it returns 0 without raising."""
    n = main_module._load_fonts()
    assert isinstance(n, int)
    assert n >= 0


def test_load_fonts_handles_missing_assets_dir(
    main_module, qapp, monkeypatch, tmp_path,    # noqa: ARG001
) -> None:
    """Pointing _PROJECT_ROOT at an empty dir → 0 fonts loaded, no crash."""
    monkeypatch.setattr(main_module, "_PROJECT_ROOT", tmp_path)
    n = main_module._load_fonts()
    assert n == 0


# ══════════════════════════════════════════════════════════════════════════════
# Splash screen
# ══════════════════════════════════════════════════════════════════════════════

def test_show_splash_constructs_widget(main_module, qapp) -> None:
    """_show_splash returns a QSplashScreen with a 420x140 pixmap."""
    from PyQt6.QtWidgets import QSplashScreen
    splash = main_module._show_splash(qapp, "Courier")
    assert isinstance(splash, QSplashScreen)
    pixmap = splash.pixmap()
    assert pixmap.width() == 420
    assert pixmap.height() == 140
    splash.close()


def test_splash_msg_updates_status(main_module, qapp) -> None:
    """_splash_msg should call through to splash.showMessage without raising."""
    splash = main_module._show_splash(qapp, "Courier")
    try:
        # Smoke — the call should not raise.
        main_module._splash_msg(splash, qapp, "Loading test...")
        # Also verify the message text shows up.
        assert "Loading test..." in splash.message()
    finally:
        splash.close()


# ══════════════════════════════════════════════════════════════════════════════
# main module shape
# ══════════════════════════════════════════════════════════════════════════════

def test_main_module_exposes_main(main_module) -> None:
    assert hasattr(main_module, "main")
    assert callable(main_module.main)


def test_logging_handler_writes_to_data_dir(main_module) -> None:
    """The configured log path lives under data/ at the project root."""
    log_path = main_module._log_path
    assert log_path.parent.name == "data"
    assert log_path.name == "nimbus.log"
