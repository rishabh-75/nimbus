"""Tests for ScanResultsModel — the Qt table model backing the scan view."""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
import pytest
from PyQt6.QtCore import QModelIndex, Qt

from nimbus_v3.conviction.formula import Contribution
from nimbus_v3.conviction.grade_engine import Conviction
from nimbus_v3.core.types import GradeLetter, SetupType, Sizing, Verdict
from nimbus_v3.scanner.engine import ScanResult
from nimbus_v3.ui.models.scan_results_model import (
    COL_GRADE, COL_REASON, COL_SCORE, COL_STRATEGY, COL_SYMBOL,
    COL_VERDICT, N_COLS, ScanResultsModel, _top_reason,
)


_ASOF = pd.Timestamp("2024-05-15")


@dataclass
class _FakeStrategy:
    name: str = "MeanReversion"
    priority: int = 50
    production_weight: float = 1.0


def _mk_conviction(
    *, score=3.5, grade=GradeLetter.A, verdict=Verdict.TAKE,
    sizing=Sizing.FULL, override_reason=None,
    contributions=None,
) -> Conviction:
    contribs = contributions or (
        Contribution("mfi", 0.5, "neutral"),
        Contribution("volume", 0.3, "ok"),
        Contribution("vix", 1.5, "HIGH regime"),
    )
    return Conviction(
        symbol="X", asof_date=_ASOF, strategy_name="MeanReversion",
        setup_type=SetupType.MEAN_REVERSION,
        raw_score=score, score=score,
        grade=grade, verdict=verdict, sizing=sizing,
        contributions=contribs, production_weight=1.0,
        override_reason=override_reason,
    )


def _mk_result(symbol="R", score=3.5, grade=GradeLetter.A, **kw) -> ScanResult:
    return ScanResult(
        symbol=symbol, asof_date=_ASOF, strategy=_FakeStrategy(),
        conviction=_mk_conviction(score=score, grade=grade, **kw),
        close_price=100.0,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Basic model shape
# ══════════════════════════════════════════════════════════════════════════════

def test_empty_model_has_zero_rows(qapp) -> None:       # noqa: ARG001
    model = ScanResultsModel()
    assert model.rowCount() == 0
    assert model.columnCount() == N_COLS


def test_set_results_updates_row_count(qapp) -> None:   # noqa: ARG001
    model = ScanResultsModel()
    model.set_results([_mk_result("A"), _mk_result("B"), _mk_result("C")])
    assert model.rowCount() == 3


def test_headers_match_column_indices(qapp) -> None:     # noqa: ARG001
    model = ScanResultsModel()
    header = model.headerData(
        COL_SYMBOL, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole,
    )
    assert header == "Symbol"
    score_header = model.headerData(
        COL_SCORE, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole,
    )
    assert score_header == "Score"


# ══════════════════════════════════════════════════════════════════════════════
# Display role content
# ══════════════════════════════════════════════════════════════════════════════

def test_display_role_symbol(qapp) -> None:          # noqa: ARG001
    model = ScanResultsModel([_mk_result("RELIANCE")])
    cell = model.data(
        model.index(0, COL_SYMBOL), Qt.ItemDataRole.DisplayRole,
    )
    assert cell == "RELIANCE"


def test_display_role_score_formatted(qapp) -> None:    # noqa: ARG001
    model = ScanResultsModel([_mk_result(score=3.5)])
    cell = model.data(
        model.index(0, COL_SCORE), Qt.ItemDataRole.DisplayRole,
    )
    assert cell == "+3.50"


def test_display_role_grade(qapp) -> None:            # noqa: ARG001
    model = ScanResultsModel([_mk_result(grade=GradeLetter.B)])
    cell = model.data(
        model.index(0, COL_GRADE), Qt.ItemDataRole.DisplayRole,
    )
    assert cell == "B"


def test_display_role_verdict(qapp) -> None:           # noqa: ARG001
    model = ScanResultsModel([_mk_result(verdict=Verdict.WATCH)])
    cell = model.data(
        model.index(0, COL_VERDICT), Qt.ItemDataRole.DisplayRole,
    )
    assert cell == "WATCH"


# ══════════════════════════════════════════════════════════════════════════════
# Reason synthesis
# ══════════════════════════════════════════════════════════════════════════════

def test_reason_uses_override_when_present(qapp) -> None:    # noqa: ARG001
    result = _mk_result(override_reason="TRAP filing — hard SKIP")
    reason = _top_reason(result)
    assert reason == "TRAP filing — hard SKIP"


def test_reason_uses_top_contributions_otherwise(qapp) -> None:    # noqa: ARG001
    contribs = (
        Contribution("mfi", 0.3, "neutral"),
        Contribution("vix", 1.5, "HIGH regime"),
        Contribution("rsi", -0.2, "neutral"),
    )
    result = _mk_result(contributions=contribs)
    reason = _top_reason(result)
    # vix has largest absolute weighted value — must appear first.
    assert reason.startswith("vix=")


def test_reason_handles_all_noise_contributions(qapp) -> None:     # noqa: ARG001
    contribs = (
        Contribution("mfi", 0.01, "neutral"),
        Contribution("rsi", -0.02, "neutral"),
    )
    result = _mk_result(contributions=contribs)
    reason = _top_reason(result)
    assert reason == "no dominant factor"


# ══════════════════════════════════════════════════════════════════════════════
# Selection helper
# ══════════════════════════════════════════════════════════════════════════════

def test_result_at_returns_original_scan_result(qapp) -> None:    # noqa: ARG001
    r1 = _mk_result("A")
    r2 = _mk_result("B")
    model = ScanResultsModel([r1, r2])
    assert model.result_at(0) is r1
    assert model.result_at(1) is r2
    assert model.result_at(99) is None


# ══════════════════════════════════════════════════════════════════════════════
# set_results emits reset
# ══════════════════════════════════════════════════════════════════════════════

def test_set_results_replaces_contents(qapp) -> None:     # noqa: ARG001
    model = ScanResultsModel([_mk_result("A"), _mk_result("B")])
    model.set_results([_mk_result("C")])
    assert model.rowCount() == 1
    assert model.data(
        model.index(0, COL_SYMBOL), Qt.ItemDataRole.DisplayRole,
    ) == "C"


def test_set_results_empty_clears_contents(qapp) -> None:    # noqa: ARG001
    model = ScanResultsModel([_mk_result("A")])
    model.set_results([])
    assert model.rowCount() == 0
