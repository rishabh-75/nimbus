"""nimbus_v3.compute.industry_rotation — composite industry ROC series.

Stateless. Builds, per industry, an ADTV-weighted composite cumulative
return series over a lookback window, so the Rotation view can show which
industries are leading and lagging (the multi-line "rebased to zero"
rotation chart).

Method, per industry:
  1. For each member with usable data, take its daily Close over the
     window and convert to a cumulative-return series rebased to 0% at
     the window start: ``close / close[0] - 1``.
  2. Weight members by their latest ADTV (liquidity), normalised so the
     weights sum to 1 within the industry. Liquid names dominate the
     composite; a tiny illiquid member can't swing the whole industry.
  3. The industry's composite series is the ADTV-weighted mean of member
     rebased-return series, in percent.

The latest value of each composite series is the industry's window ROC,
used to rank leaders/laggards. Symbol-agnostic and pure — no UI, no IO.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.compute.industry_composite import build_industry_composite

#: Default lookback (trading days). ~3 months — long enough that daily
#: bars show real rotation, short enough to be "current" leadership.
DEFAULT_LOOKBACK: int = 60

#: Minimum members with usable data before an industry is composited.
#: Small buckets (and the "Unknown" catch-all) are excluded — a 2-symbol
#: "industry" isn't a meaningful rotation signal and tends to be noisy.
MIN_MEMBERS: int = 5

#: Minimum bars a member needs within the window to contribute.
_MIN_BARS: int = 5

#: Centered rolling-mean window (bars) applied to each composite series
#: to tame daily jitter. 3 = light smoothing; raise for smoother lines.
SMOOTH_WINDOW: int = 3


@dataclass(frozen=True)
class IndustryRotation:
    """One industry's composite rotation series."""

    industry: str
    #: Trading-day timestamps (index of the composite series).
    dates: tuple[pd.Timestamp, ...]
    #: Cumulative return in percent, rebased to 0 at window start.
    cum_return: tuple[float, ...]
    #: Latest cumulative return (the headline ROC for ranking).
    roc: float
    #: Members that contributed to the composite.
    n_members: int


@dataclass(frozen=True)
class RotationResult:
    """All industries' rotation series + leader/laggard split."""

    industries: tuple[IndustryRotation, ...]    # all, sorted by roc desc
    lookback: int

    @property
    def has_data(self) -> bool:
        return len(self.industries) > 0

    def top(self, n: int) -> tuple[IndustryRotation, ...]:
        """The ``n`` leading industries (highest ROC)."""
        return self.industries[:n]

    def bottom(self, n: int) -> tuple[IndustryRotation, ...]:
        """The ``n`` lagging industries (lowest ROC), worst first."""
        return tuple(reversed(self.industries[-n:])) if n else ()



def compute_industry_rotation(
    members_by_industry: dict[str, list[str]],
    panel: dict[str, pd.DataFrame],
    *,
    lookback: int = DEFAULT_LOOKBACK,
) -> RotationResult:
    """Build ADTV-weighted composite ROC series for every industry.

    Args:
        members_by_industry: ``{industry: [symbols]}`` — same grouping
            the Industries table uses.
        panel: ``{symbol: enriched_df}``.
        lookback: trading-day window for the cumulative return.

    Returns:
        A :class:`RotationResult` with every industry's series, sorted by
        current ROC descending (leaders first).
    """
    rotations: list[IndustryRotation] = []

    for industry, members in members_by_industry.items():
        if industry in ("ALL", "Unknown", ""):
            continue    # ALL is a table aggregate; Unknown is the
            #             no-classification catch-all — neither is a
            #             real rotation line.

        # ADTV-weighted composite index (100-based) via the shared
        # builder, which handles the common-grid alignment + anchor
        # rebasing that prevents the vertical-cliff artifact from members
        # with differing history lengths.
        comp_index, member_weights = build_industry_composite(
            members, panel, min_members=MIN_MEMBERS, min_bars=_MIN_BARS,
            lookback=lookback)
        if comp_index is None:
            continue

        # Express as percent-from-zero (the rotation view's convention).
        composite = (comp_index.to_numpy() / 100.0 - 1.0) * 100.0
        n_used = len(member_weights)

        # Light smoothing — a short centered rolling mean tames daily
        # jitter so the rotation lines read as trends, not noise. ROC
        # (the ranking value) is taken from the SMOOTHED tail so the
        # leaderboard matches the line ends.
        comp_s = pd.Series(composite)
        if SMOOTH_WINDOW > 1:
            comp_s = comp_s.rolling(
                SMOOTH_WINDOW, min_periods=1, center=True,
            ).mean()
        composite = comp_s.to_numpy()

        dates = tuple(pd.DatetimeIndex(comp_index.index))
        cum = tuple(float(x) for x in composite)
        roc = float(composite[-1]) if len(composite) and \
            composite[-1] == composite[-1] else float("nan")
        if roc != roc:
            continue

        rotations.append(IndustryRotation(
            industry=industry,
            dates=dates,
            cum_return=cum,
            roc=roc,
            n_members=n_used,
        ))

    rotations.sort(key=lambda r: r.roc, reverse=True)
    return RotationResult(industries=tuple(rotations), lookback=lookback)
