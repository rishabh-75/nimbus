#!/usr/bin/env python3
"""
scripts/run_hybrid_exit_sim.py — Test the hybrid exit rules.

DECIDED RULES (not tunable, baked into the principle):
  1. HARD FLOOR: max single-trade loss capped at -5%.
     If close ≤ entry × 0.95, exit immediately.
     Fires regardless of any other condition.

  2. BAR RATCHET: cut early if not working.
     If at bar N the trade is still underwater (close < entry), exit.
     N is the only tunable parameter — test 6, 8, 10.

  3. WINNER RUNNER: don't cap winners.
     When original PT (+5%) would have hit, instead switch to trailing
     stop at 1.5×ATR_at_entry from peak. Bounded by original exit_date.

PRIORITY ORDER (highest first — first match wins):
  1. Hard floor (-5%)              ← always fires if hit
  2. Bar ratchet (bar N underwater) ← only at the checkpoint bar
  3. PT (+5%) → switch to trailing  ← winner runner replaces PT exit
  4. Trailing stop (post-PT only)
  5. Original BBW / MAX_HOLD exit   ← fallback

GOAL:
  Pick the bar-ratchet value (6, 8, or 10) that:
    - Best improves fold 5 PnL
    - Doesn't cost more than ~0.3% in good folds (2/3/4) avg PnL
  All variants share the hard floor and winner runner.

NOT TUNABLE:
  - The -5% floor (decided)
  - The 1.5×ATR trailing on winners (decided)
  - The application to MR (PRIMARY) trades only (Ride has its own logic)

USAGE:
  python3 scripts/run_hybrid_exit_sim.py
  python3 scripts/run_hybrid_exit_sim.py --bars 6 8 10
"""
import argparse
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("hybrid_exit_sim")


CSV_PATH = "data/backtest_results/wf_oos_trades.csv"
CACHE_DIR = "data/bbw_pctl_cache"

# Decided constants — non-tunable
HARD_FLOOR_PCT = -5.0      # cap single-trade loss at -5%
TRAIL_ATR_MULT = 1.5       # winner runner trail
MAX_TRAIL_PCT = 4.0        # trail width capped at 4% of entry (high-vol stocks)
ATR_PERIOD = 14
ORIG_PT_PCT = 5.0          # the level that activates the winner-runner switch

DEFAULT_BAR_RATCHETS = [6, 8, 10]


# ══════════════════════════════════════════════════════════════════════════════
# DATA FETCHING
# ══════════════════════════════════════════════════════════════════════════════

def fetch_symbol_history(symbol: str, start: pd.Timestamp,
                         end: pd.Timestamp) -> pd.DataFrame:
    """Get OHLC for a symbol covering [start, end]. Reuses bbw_pctl_cache."""
    os.makedirs(CACHE_DIR, exist_ok=True)
    cache_path = os.path.join(CACHE_DIR, f"{symbol}.parquet")

    df = pd.DataFrame()
    if os.path.exists(cache_path):
        try:
            df = pd.read_parquet(cache_path)
            if df.empty or df.index.min() > start or df.index.max() < end:
                df = pd.DataFrame()
        except Exception:
            df = pd.DataFrame()

    if df.empty:
        from scripts.run_bbw_pctl_study import fetch_price_history_range
        df = fetch_price_history_range(
            symbol,
            start - pd.Timedelta(days=60),
            end + pd.Timedelta(days=20),  # extra forward window for winner runner
        )
        if not df.empty:
            try:
                df.to_parquet(cache_path)
            except Exception:
                pass
    return df


def compute_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    if df.empty or len(df) < period + 1:
        return pd.Series(dtype=float)
    high = df["High"]
    low = df["Low"]
    close = df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()


# ══════════════════════════════════════════════════════════════════════════════
# SIMULATION
# ══════════════════════════════════════════════════════════════════════════════

def _check_data_gaps(price_df: pd.DataFrame, entry_idx: int, exit_idx: int,
                     max_gap_days: int = 5) -> bool:
    """
    Returns True if there are no problematic gaps in the price series between
    entry and exit. A gap > max_gap_days suggests missing data and we shouldn't
    trust the bar-walk simulation on this trade.
    """
    if exit_idx <= entry_idx + 1:
        return True
    dates = price_df.index[entry_idx:exit_idx + 1]
    if len(dates) < 2:
        return True
    diffs = pd.Series(dates).diff().dt.days.dropna()
    return diffs.max() <= max_gap_days


def simulate_trade(trade: dict, price_df: pd.DataFrame, bar_ratchet: int) -> dict:
    """
    Apply hybrid exit rules to a single trade.

    Rule priority on EVERY bar:
      1. HARD FLOOR (-5%)  — non-negotiable, checked first regardless of mode
      2. BAR RATCHET       — only at the checkpoint bar, only if not yet in trail
      3. WINNER RUNNER PT  — switch to trail mode when PT hits
      4. TRAIL CHECK       — if in trail mode, check current trail stop

    Returns updated outcome with sim_pnl_pct, sim_exit_reason, etc.
    """
    symbol = trade["symbol"]
    entry_date = trade["entry_date"]
    exit_date = trade["exit_date"]
    entry_price = trade["entry_price"]
    orig_pnl = trade["pnl_pct"]
    orig_exit = trade["exit_reason"]

    base_result = {
        "sim_pnl_pct": orig_pnl,
        "sim_exit_reason": orig_exit,
        "sim_exit_bar": int(trade["bars_held"]),
        "fired_floor": False,
        "fired_ratchet": False,
        "fired_runner": False,
        "skipped_data_gap": False,
    }

    if price_df.empty:
        return base_result

    atr_series = compute_atr(price_df)
    if atr_series.empty:
        return base_result

    try:
        entry_idx_atr = atr_series.index.get_indexer([entry_date], method="ffill")[0]
        if entry_idx_atr < 0:
            return base_result
        atr_at_entry = float(atr_series.iloc[entry_idx_atr])
    except Exception:
        return base_result

    if np.isnan(atr_at_entry) or atr_at_entry <= 0:
        return base_result

    closes = price_df["Close"]
    try:
        entry_idx = closes.index.get_indexer([entry_date], method="ffill")[0]
        exit_idx = closes.index.get_indexer([exit_date], method="ffill")[0]
    except Exception:
        return base_result

    if entry_idx < 0 or exit_idx < entry_idx:
        return base_result

    # Skip trades with data gaps in the price series
    if not _check_data_gaps(price_df, entry_idx, exit_idx):
        result = base_result.copy()
        result["skipped_data_gap"] = True
        return result

    floor_price = entry_price * (1 + HARD_FLOOR_PCT / 100)
    pt_price = entry_price * (1 + ORIG_PT_PCT / 100)

    # Trail width: cap at 4% of entry to prevent runaway on high-vol stocks
    raw_trail = TRAIL_ATR_MULT * atr_at_entry
    max_trail = entry_price * MAX_TRAIL_PCT / 100
    trail_width = min(raw_trail, max_trail)

    in_trail_mode = False
    peak_price = entry_price
    trail_stop = 0.0

    def _walk_bar(bar_offset: int, i: int) -> dict | None:
        """
        Walk a single bar and check all rules in priority order.
        Returns an exit result dict, or None if the trade continues.
        Mutates closure variables in_trail_mode, peak_price, trail_stop.
        """
        nonlocal in_trail_mode, peak_price, trail_stop
        if i >= len(closes):
            return None
        bar_close = float(closes.iloc[i])

        # Rule 1: HARD FLOOR — checked on EVERY bar, regardless of trail mode
        if bar_close <= floor_price:
            return {
                "sim_pnl_pct": (bar_close / entry_price - 1) * 100,
                "sim_exit_reason": "FLOOR",
                "sim_exit_bar": bar_offset,
                "fired_floor": True,
                "fired_ratchet": False,
                "fired_runner": False,
                "skipped_data_gap": False,
            }

        # Rule 2: BAR RATCHET — only at the checkpoint, only if not in trail
        if not in_trail_mode and bar_offset == bar_ratchet and bar_close < entry_price:
            return {
                "sim_pnl_pct": (bar_close / entry_price - 1) * 100,
                "sim_exit_reason": "RATCHET",
                "sim_exit_bar": bar_offset,
                "fired_floor": False,
                "fired_ratchet": True,
                "fired_runner": False,
                "skipped_data_gap": False,
            }

        # Rule 3: WINNER RUNNER activation
        if not in_trail_mode and bar_close >= pt_price:
            in_trail_mode = True
            peak_price = bar_close
            trail_stop = peak_price - trail_width
            return None  # don't exit yet, start trailing

        # Rule 4: trailing stop check (only when in trail mode)
        if in_trail_mode:
            if bar_close > peak_price:
                peak_price = bar_close
                trail_stop = peak_price - trail_width
            if bar_close <= trail_stop:
                return {
                    "sim_pnl_pct": (bar_close / entry_price - 1) * 100,
                    "sim_exit_reason": "TRAIL",
                    "sim_exit_bar": bar_offset,
                    "fired_floor": False,
                    "fired_ratchet": False,
                    "fired_runner": True,
                    "skipped_data_gap": False,
                }

        return None

    # First pass: walk from entry+1 to exit_idx (inclusive)
    for bar_offset in range(1, exit_idx - entry_idx + 1):
        i = entry_idx + bar_offset
        result = _walk_bar(bar_offset, i)
        if result is not None:
            return result

    # Second pass (only if in trail mode): walk past exit_date until trail hits
    if not in_trail_mode:
        return base_result

    max_forward = min(len(closes), exit_idx + 21)
    for i in range(exit_idx + 1, max_forward):
        bar_offset = i - entry_idx
        result = _walk_bar(bar_offset, i)
        if result is not None:
            return result

    # Trail never hit — exit at last available bar
    last_close = float(closes.iloc[max_forward - 1])
    return {
        "sim_pnl_pct": (last_close / entry_price - 1) * 100,
        "sim_exit_reason": "TRAIL_END",
        "sim_exit_bar": max_forward - 1 - entry_idx,
        "fired_floor": False,
        "fired_ratchet": False,
        "fired_runner": True,
        "skipped_data_gap": False,
    }


# ══════════════════════════════════════════════════════════════════════════════
# RUN OVER ALL TRADES
# ══════════════════════════════════════════════════════════════════════════════

def run_simulation(trades: pd.DataFrame, bar_ratchet: int) -> pd.DataFrame:
    logger.info(f"  Running with bar_ratchet={bar_ratchet}")
    rows = []
    symbol_cache: dict[str, pd.DataFrame] = {}

    t0 = time.time()
    for i, (_, trade) in enumerate(trades.iterrows()):
        if i % 500 == 0 and i > 0:
            elapsed = time.time() - t0
            rate = i / elapsed
            eta = (len(trades) - i) / rate
            logger.info(f"    [{i}/{len(trades)}] eta {eta:.0f}s")

        symbol = trade["symbol"]
        if symbol not in symbol_cache:
            sym_trades = trades[trades["symbol"] == symbol]
            symbol_cache[symbol] = fetch_symbol_history(
                symbol,
                start=sym_trades["entry_date"].min() - pd.Timedelta(days=60),
                end=sym_trades["exit_date"].max() + pd.Timedelta(days=30),
            )

        result = simulate_trade(trade.to_dict(), symbol_cache[symbol], bar_ratchet)
        row = trade.to_dict()
        row.update(result)
        rows.append(row)

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# REPORTING
# ══════════════════════════════════════════════════════════════════════════════

def header(text: str, char: str = "="):
    print("\n" + char * 78)
    print(f"  {text}")
    print(char * 78)


def per_fold_report(sim_df: pd.DataFrame, bar_ratchet: int):
    print(f"\n  Bar ratchet: {bar_ratchet}    "
          f"Hard floor: {HARD_FLOOR_PCT}%    "
          f"Trail: {TRAIL_ATR_MULT}×ATR")

    print(f"\n  {'Fold':<6s}  {'N':>5s}  "
          f"{'orig win%':>10s}  {'sim win%':>10s}  "
          f"{'orig avg':>10s}  {'sim avg':>10s}  "
          f"{'max loss':>10s}  {'Δ avg':>9s}")
    print(f"  {'-'*6}  {'-'*5}  {'-'*10}  {'-'*10}  "
          f"{'-'*10}  {'-'*10}  {'-'*10}  {'-'*9}")

    summaries = []
    for fold in sorted(sim_df["fold"].unique()):
        f = sim_df[sim_df["fold"] == fold]
        n = len(f)
        orig_win = (f["pnl_pct"] > 0).mean() * 100
        sim_win = (f["sim_pnl_pct"] > 0).mean() * 100
        orig_avg = f["pnl_pct"].mean()
        sim_avg = f["sim_pnl_pct"].mean()
        sim_max_loss = f["sim_pnl_pct"].min()
        delta = sim_avg - orig_avg
        summaries.append({
            "fold": fold, "n": n,
            "orig_win": orig_win, "sim_win": sim_win,
            "orig_avg": orig_avg, "sim_avg": sim_avg,
            "delta": delta, "win_delta": sim_win - orig_win,
            "sim_max_loss": sim_max_loss,
        })
        print(f"  fold={fold}  {n:>5d}  "
              f"{orig_win:>9.1f}%  {sim_win:>9.1f}%  "
              f"{orig_avg:>+9.2f}%  {sim_avg:>+9.2f}%  "
              f"{sim_max_loss:>+9.2f}%  {delta:>+8.2f}%")
    return summaries


def rule_firing_breakdown(sim_df: pd.DataFrame):
    print(f"\n  Rule firing — how often does each rule trigger?")
    n = len(sim_df)
    n_floor = int(sim_df["fired_floor"].sum())
    n_ratchet = int(sim_df["fired_ratchet"].sum())
    n_runner = int(sim_df["fired_runner"].sum())
    n_gap = int(sim_df["skipped_data_gap"].sum()) if "skipped_data_gap" in sim_df.columns else 0
    n_orig = n - n_floor - n_ratchet - n_runner

    print(f"    HARD FLOOR (-5%):     {n_floor:5d} / {n} ({n_floor/n*100:.1f}%)")
    print(f"    BAR RATCHET:          {n_ratchet:5d} / {n} ({n_ratchet/n*100:.1f}%)")
    print(f"    WINNER RUNNER:        {n_runner:5d} / {n} ({n_runner/n*100:.1f}%)")
    print(f"    Original exit kept:   {n_orig:5d} / {n} ({n_orig/n*100:.1f}%)")
    if n_gap > 0:
        print(f"    Skipped (data gap):   {n_gap:5d} / {n} ({n_gap/n*100:.1f}%)")

    print(f"\n  Rule firing by fold:")
    print(f"  {'Fold':<6s}  {'Floor':>6s}  {'Ratchet':>8s}  {'Runner':>7s}")
    for fold in sorted(sim_df["fold"].unique()):
        f = sim_df[sim_df["fold"] == fold]
        nf = int(f["fired_floor"].sum())
        nr = int(f["fired_ratchet"].sum())
        nw = int(f["fired_runner"].sum())
        print(f"  fold={fold}  {nf:>6d}  {nr:>8d}  {nw:>7d}")


def loss_tail_check(sim_df: pd.DataFrame):
    """
    Check that the floor is enforcing properly. Excludes data-gap-skipped
    trades since those keep their original outcome by design.
    """
    n_gap = int(sim_df["skipped_data_gap"].sum()) if "skipped_data_gap" in sim_df.columns else 0
    rule_active = sim_df[~sim_df["skipped_data_gap"]] if n_gap else sim_df

    print(f"\n  Loss tail enforcement — biggest single losses:")
    print(f"    Worst original loss (any trade):       {sim_df['pnl_pct'].min():+.2f}%")
    print(f"    Worst sim loss (rule-active trades):   {rule_active['sim_pnl_pct'].min():+.2f}%")
    print(f"    Floor target:                          {HARD_FLOOR_PCT:.1f}%")
    if n_gap > 0:
        print(f"    Trades skipped (data gap, kept original): {n_gap}")
        print(f"    Worst sim loss in gap-skipped trades: "
              f"{sim_df[sim_df['skipped_data_gap']]['sim_pnl_pct'].min():+.2f}%")

    worst_active = rule_active["sim_pnl_pct"].min()
    if worst_active < HARD_FLOOR_PCT - 1.0:
        print(f"    ⚠ WARNING: rule-active worst loss exceeded floor by >1pp")
        print(f"      (gap-down through floor on a single daily close)")
    else:
        print(f"    ✓ Hard floor holding for rule-active trades")


def winner_upside(sim_df: pd.DataFrame):
    """Did the winner runner actually capture upside?"""
    runners = sim_df[sim_df["fired_runner"]]
    if len(runners) == 0:
        print(f"\n  No winner-runner trades fired.")
        return
    print(f"\n  Winner runner upside (trades that hit PT and then trailed):")
    print(f"    N = {len(runners)}")
    print(f"    Original PnL avg (would have closed at PT): {runners['pnl_pct'].mean():+.2f}%")
    print(f"    Simulated PnL avg (with trail):              {runners['sim_pnl_pct'].mean():+.2f}%")
    print(f"    Upside captured: {(runners['sim_pnl_pct'] - runners['pnl_pct']).mean():+.2f}% per runner")
    print(f"    Best case: {(runners['sim_pnl_pct'] - runners['pnl_pct']).max():+.2f}%")
    print(f"    Worst case: {(runners['sim_pnl_pct'] - runners['pnl_pct']).min():+.2f}%")


def cross_variant_summary(all_results: dict):
    header("CROSS-VARIANT SUMMARY")

    print(f"\n  Per-fold avg PnL DELTA from baseline (positive = improvement):")
    print(f"  {'Fold':<6s}  ", end="")
    bars_list = sorted(all_results.keys())
    for b in bars_list:
        print(f"{f'bar {b}':>10s}  ", end="")
    print()
    print(f"  {'-'*6}  " + "  ".join("-" * 10 for _ in bars_list))

    folds = sorted({s["fold"] for s in all_results[bars_list[0]]["per_fold"]})
    for fold in folds:
        print(f"  fold={fold}  ", end="")
        for b in bars_list:
            fd = next(s for s in all_results[b]["per_fold"] if s["fold"] == fold)
            print(f"{fd['delta']:>+9.2f}%   ", end="")
        print()

    print(f"\n  Headline metrics by variant:")
    print(f"  {'Bar':<5s}  {'Fold5 Δavg':>12s}  {'Fold4 Δavg':>12s}  "
          f"{'Good folds avg Δ':>17s}  {'Worst loss':>12s}")
    for b in bars_list:
        per = all_results[b]["per_fold"]
        f5 = next(s for s in per if s["fold"] == 5)
        f4 = next(s for s in per if s["fold"] == 4)
        good = [s for s in per if s["fold"] in (2, 3, 4)]
        good_avg_delta = np.mean([s["delta"] for s in good])
        worst = all_results[b]["df"]["sim_pnl_pct"].min()
        print(f"  {b:<5d}  {f5['delta']:>+11.2f}%  {f4['delta']:>+11.2f}%  "
              f"{good_avg_delta:>+16.2f}%  {worst:>+11.2f}%")


def recommendation(all_results: dict):
    header("RECOMMENDATION")

    bars_list = sorted(all_results.keys())
    print()
    candidates = []
    for b in bars_list:
        per = all_results[b]["per_fold"]
        f5 = next(s for s in per if s["fold"] == 5)
        good = [s for s in per if s["fold"] in (2, 3, 4)]
        good_avg_delta = np.mean([s["delta"] for s in good])

        passes = good_avg_delta >= -0.30
        score = f5["delta"] - max(0, -good_avg_delta - 0.10) * 2  # penalize if cost is high

        flag = "✓ valid" if passes else "✗ violates good-fold floor (-0.30%)"
        print(f"  bar {b}: fold5 Δavg={f5['delta']:+.2f}%   "
              f"good-folds avg Δ={good_avg_delta:+.2f}%   {flag}")

        if passes:
            candidates.append((score, b, f5, good_avg_delta))

    print()
    if not candidates:
        print("  NO BAR RATCHET PASSES THE GOOD-FOLD FLOOR.")
        print("  But the hard floor and winner runner are independent of bar choice.")
        print("  Consider shipping just floor + runner without the ratchet.")
        return

    candidates.sort(reverse=True)
    score, best_bar, f5, good_delta = candidates[0]
    print(f"  WINNER: bar {best_bar} ratchet")
    print(f"    Fold 5 avg PnL change:   {f5['delta']:+.2f}%")
    print(f"    Good folds avg cost:     {good_delta:+.2f}%")
    print(f"    Worst sim loss:          {all_results[best_bar]['df']['sim_pnl_pct'].min():+.2f}%")
    print()
    print(f"  Configuration to ship:")
    print(f"    Hard floor:    -5% (close-based)")
    print(f"    Bar ratchet:   bar {best_bar} (cut if underwater)")
    print(f"    Winner runner: 1.5×ATR trail past +5% PT")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bars", type=int, nargs="+", default=DEFAULT_BAR_RATCHETS,
                    help=f"Bar ratchet values to test (default: {DEFAULT_BAR_RATCHETS})")
    args = ap.parse_args()

    if not os.path.exists(CSV_PATH):
        logger.error(f"{CSV_PATH} not found")
        sys.exit(1)

    trades = pd.read_csv(CSV_PATH)
    trades["entry_date"] = pd.to_datetime(trades["entry_date"])
    trades["exit_date"] = pd.to_datetime(trades["exit_date"])
    logger.info(f"Loaded {len(trades):,} trades")

    mr_trades = trades[trades["tier"] == "PRIMARY"].copy()
    logger.info(f"Filtering to PRIMARY (MR): {len(mr_trades):,} trades")
    logger.info(f"Hard floor: {HARD_FLOOR_PCT}%   Trail: {TRAIL_ATR_MULT}×ATR")

    all_results = {}
    for bar_ratchet in args.bars:
        header(f"SIMULATION — bar ratchet = {bar_ratchet}")
        sim_df = run_simulation(mr_trades, bar_ratchet)
        per_fold = per_fold_report(sim_df, bar_ratchet)
        rule_firing_breakdown(sim_df)
        loss_tail_check(sim_df)
        winner_upside(sim_df)
        all_results[bar_ratchet] = {
            "per_fold": per_fold,
            "df": sim_df,
        }

    cross_variant_summary(all_results)
    recommendation(all_results)


if __name__ == "__main__":
    main()
