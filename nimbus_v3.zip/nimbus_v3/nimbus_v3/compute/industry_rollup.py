"""nimbus_v3.compute.industry_rollup — member-aggregate industry metrics.

Stateless functions that roll a set of per-symbol ride results up to
an industry-level summary: how many members are riding, and a single
recalibrated industry score that blends *breadth* (how many ride),
*liquidity* (ADTV weighting) and *conviction* (each rider's own ride
score).

This is deliberately separate from ``RideEngine.classify_industry``,
which builds a synthetic peer index and scores *that*. The synthetic
index still drives the industry **Phase**; this module drives the
recalibrated industry **Score** and the **Riding** count. Keeping the
arithmetic here (not in the table widget) preserves the rule that the
UI renders, never computes.

Score formula (operator-chosen "option 2" — breadth-scaled
ADTV-weighted mean of riders' scores):

    riders          = members whose latest phase != NONE
    weighted_mean   = Σ(score_i · adtv_i) / Σ(adtv_i)      over riders
    breadth         = len(riders) / len(members_with_data)
    industry_score  = breadth · weighted_mean

So an industry ranks high only when a large *fraction* of its members
ride (breadth), those riders carry real ₹-liquidity (ADTV weight), and
they score well individually (score_i). A lone liquid rider in an
otherwise-quiet industry is discounted by the breadth term; a swarm of
tiny illiquid riders is discounted by the ADTV weighting.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.compute.indicators import adtv_latest
from nimbus_v3.compute.ride_initiation import RideResult
from nimbus_v3.compute.ride_initiation.criteria import body_above_band

#: Minimum bars of Close×Volume needed to trust a member's ADTV.
_ADTV_MIN_BARS: int = 5
#: ADTV lookback (bars) — matches the engine/score definition.
_ADTV_WINDOW: int = 20


def last_body_above(df: pd.DataFrame) -> bool:
    """True if the LAST bar's candle body is above the upper BB.

    Uses the strategy's canonical definition (``body_above_band``:
    BOTH Open and Close exceed the upper band), so the table flag and
    the ride engine never disagree on what "above the band" means.
    Phase-independent — this is purely the last bar's geometry.
    """
    if df is None or df.empty or "bb_20_1s_upper" not in df.columns:
        return False
    try:
        return bool(body_above_band(df).iloc[-1])
    except Exception:    # noqa: BLE001
        return False


def body_above_streak(df: pd.DataFrame) -> int:
    """Count of consecutive most-recent bars with the body above the
    upper BB, ending at the last bar.

    Returns 0 when the last bar is not body-above. Counts the trailing
    run only (e.g. if the flags are ...T,F,T,T,T the streak is 3).
    """
    if df is None or df.empty or "bb_20_1s_upper" not in df.columns:
        return 0
    try:
        flags = body_above_band(df).to_numpy(dtype=bool)
    except Exception:    # noqa: BLE001
        return 0
    streak = 0
    for v in reversed(flags):
        if v:
            streak += 1
        else:
            break
    return streak


@dataclass(frozen=True)
class IndustryRollup:
    """Member-aggregate summary for one industry.

    Attributes:
        riding: count of members whose LAST bar's candle body is above
            the upper BB (phase-independent — see ``last_body_above``).
        members: count of members that had usable data in the panel.
        adtv_total: summed 20-bar mean Close×Volume across members (₹).
        riding_strength: ADTV-weighted riding metric used to sort the
            table — the summed ADTV of the body-above members
            (so industries with many *and* liquid riders rank top).
            NaN when nothing rides.
    """

    riding: int
    members: int
    adtv_total: float
    riding_strength: float


def _member_adtv(df: pd.DataFrame) -> float:
    """20-bar mean Close×Volume for one member, or NaN if unusable.

    Thin wrapper over the canonical :func:`indicators.adtv_latest` so
    the roll-up shares one ADTV definition with the ride engine.
    """
    return adtv_latest(df, window=_ADTV_WINDOW, min_bars=_ADTV_MIN_BARS)


def aggregate_industry(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    symbol_results: dict[str, RideResult],
) -> IndustryRollup | None:
    """Roll up one industry's members into an :class:`IndustryRollup`.

    Args:
        members: symbols belonging to the industry.
        panel: ``{symbol: enriched_df}`` (for ADTV).
        symbol_results: ``{symbol: RideResult}`` — the per-symbol ride
            cache (single source of truth for phase + score).

    Returns:
        An :class:`IndustryRollup`, or ``None`` if no member had usable
        panel data (so the caller can skip the row entirely).
    """
    present = [s for s in members if s in panel and panel[s] is not None
               and not panel[s].empty]
    if not present:
        return None

    adtv_total = 0.0
    riders = 0
    riding_adtv_sum = 0.0

    for sym in present:
        df = panel[sym]
        adtv = _member_adtv(df)
        if adtv == adtv:    # not NaN
            adtv_total += adtv

        # "Riding" is now phase-independent: the member's LAST bar has
        # its candle body above the upper BB. (symbol_results is kept
        # in the signature for compatibility but no longer gates the
        # riding count.)
        if last_body_above(df):
            riders += 1
            if adtv == adtv:
                riding_adtv_sum += adtv

    members_n = len(present)
    # Sort key: summed ADTV of the riding members. Industries with many
    # *and* liquid body-above members rank highest. NaN when none ride
    # so they sink in a descending sort.
    riding_strength = riding_adtv_sum if riders > 0 else float("nan")

    return IndustryRollup(
        riding=riders,
        members=members_n,
        adtv_total=adtv_total if adtv_total > 0 else float("nan"),
        riding_strength=riding_strength,
    )
