"""scripts/run_normal_regime_search.py — search for normal-regime strategies.

Problem
───────
Mean Reversion's edge is real (+1.9pp OOS) but its ``vix_streak >= 6``
gate fires rarely outside genuine vol spikes — only 51 trades in 16
OOS months. Breakout failed OOS. Ride is marginal (+0.2pp). In a
typical calm regime the v3 grading engine would have very little to
grade.

This script searches for strategies that earn production weight
**without depending on elevated VIX**. Each candidate is a small,
named gate set with a stated premise. Every candidate is evaluated on
both the train (2020-2024) and the OOS test (2025-2026) periods.

Acceptance criteria for a candidate to be considered for production:
  1. ``test_n >= 200``           — fires often enough to matter
  2. ``test_lift >= +0.3pp``     — clearly above noise in the test period
  3. ``|test_lift − train_lift| <= 0.5pp``  — OOS lift replicates
  4. ``test_t_stat >= 2.0``      — non-trivial significance in the OOS sample

These are stricter than the in-sample-only thresholds we'd use for
exploratory work, on purpose: with ~12 candidates tested, we expect
~1-2 false positives at the standard t≥2 threshold by chance alone.
The OOS-replication requirement substantially reduces the false-
positive rate.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import (
    add_forward_returns,
    build_vix_proxy,
    compute_vix_streaks,
    evaluate_vector_predicate_panel,
    split_panel_by_date,
    split_streak_by_date,
    summarise,
)


OOS_CUTOFF = pd.Timestamp("2025-01-01")


# ══════════════════════════════════════════════════════════════════════════════
# Candidate strategies — each is (name, premise, gates)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Candidate:
    name: str
    premise: str
    gates: Callable[[pd.DataFrame, pd.Series], pd.Series]


def _and(*conds):
    def fn(df, st):
        result = None
        for c in conds:
            mask = c(df, st)
            result = mask if result is None else (result & mask)
        return result
    return fn


CANDIDATES: list[Candidate] = [
    # ── Trend-pullback family ─────────────────────────────────────────────────
    Candidate(
        "PULLBACK_IN_UPTREND",
        "Stock in confirmed uptrend (above SMA50/200, ADX>20) pulling back "
        "to SMA20 (-3% to 0% from it). Buy the dip in trend.",
        _and(
            lambda df, _: df["above_sma_50"].astype(bool),
            lambda df, _: df["above_sma_200"].astype(bool),
            lambda df, _: df["adx_14"] > 20,
            lambda df, _: (df["pct_from_sma_20"] > -3.0)
                          & (df["pct_from_sma_20"] < 0),
        ),
    ),
    Candidate(
        "DEEP_PULLBACK_IN_UPTREND",
        "Same as above but a deeper pullback: -5% to -2% from SMA20.",
        _and(
            lambda df, _: df["above_sma_50"].astype(bool),
            lambda df, _: df["above_sma_200"].astype(bool),
            lambda df, _: df["adx_14"] > 20,
            lambda df, _: (df["pct_from_sma_20"] > -5.0)
                          & (df["pct_from_sma_20"] < -2.0),
        ),
    ),

    # ── Squeeze breakout family ───────────────────────────────────────────────
    Candidate(
        "SQUEEZE_BREAKOUT",
        "BB width in bottom 20% (squeezed) followed by a green expansion. "
        "Bands often release with directional bias.",
        _and(
            lambda df, _: df["bbw_20_2s_pctl"] < 20,
            lambda df, _: df["green_streak"] >= 2,
            lambda df, _: df["Close"] > df["sma_20"],
        ),
    ),
    Candidate(
        "SQUEEZE_RELEASE_STRONG",
        "Squeezed BBs releasing, and BB width starting to widen "
        "(positive bbw slope). The early phase of a band expansion.",
        _and(
            lambda df, _: df["bbw_20_2s_pctl"] < 25,
            lambda df, _: df["bbw_20_2s_slope"] > 0,
            lambda df, _: df["Close"] > df["sma_20"],
        ),
    ),

    # ── Momentum continuation family ──────────────────────────────────────────
    Candidate(
        "STRONG_MOMENTUM_TREND",
        "ADX > 30 (very strong trend) + perfect MA alignment + roc_20 > 5. "
        "Pure momentum continuation with quality filters.",
        _and(
            lambda df, _: df["adx_14"] > 30,
            lambda df, _: df["Close"] > df["sma_20"],
            lambda df, _: df["sma_20"] > df["sma_50"],
            lambda df, _: df["sma_50"] > df["sma_200"],
            lambda df, _: df["roc_20"] > 5,
        ),
    ),
    Candidate(
        "MOMENTUM_PULLBACK_RESET",
        "Strong recent move (roc_20 > 5) with brief 5-bar pause "
        "(roc_5 in [-3, 0]). Continuation after rest.",
        _and(
            lambda df, _: df["roc_20"] > 5,
            lambda df, _: (df["roc_5"] > -3) & (df["roc_5"] < 0),
            lambda df, _: df["above_sma_50"].astype(bool),
        ),
    ),

    # ── Oversold bounce family ────────────────────────────────────────────────
    Candidate(
        "QUALITY_OVERSOLD_BOUNCE",
        "Above SMA200 (bigger uptrend intact) but RSI < 35 + MFI turning up. "
        "Oversold within an uptrend.",
        _and(
            lambda df, _: df["above_sma_200"].astype(bool),
            lambda df, _: df["rsi_14"] < 35,
            lambda df, _: df["mfi_slope_3"] > 0,
        ),
    ),
    Candidate(
        "DRAWDOWN_REVERSAL",
        "Stock has drawn down ≥8% from 50-bar high but green_streak ≥ 2 + "
        "MFI > 40. Capitulation reversal.",
        _and(
            lambda df, _: df["dd_from_high_50"] < -8,
            lambda df, _: df["green_streak"] >= 2,
            lambda df, _: df["mfi_14"] > 40,
        ),
    ),

    # ── BB-bounce family ──────────────────────────────────────────────────────
    Candidate(
        "BB_LOWER_BOUNCE_IN_UPTREND",
        "Close below lower 2σ BB (mean-reversion candidate) but stock is "
        "above SMA200 + MFI slope turning. Quality oversold MR.",
        _and(
            lambda df, _: df["Close"] < df["bb_20_2s_lower"],
            lambda df, _: df["above_sma_200"].astype(bool),
            lambda df, _: df["mfi_slope_3"] > 0,
        ),
    ),

    # ── Sustained-accumulation family ─────────────────────────────────────────
    Candidate(
        "SUSTAINED_ACCUMULATION",
        "MFI > 60 (strong inflow) + 4+ green days + above SMA50. Money "
        "is flowing in over sustained period.",
        _and(
            lambda df, _: df["mfi_14"] > 60,
            lambda df, _: df["green_streak"] >= 4,
            lambda df, _: df["pct_from_sma_50"] > 0,
        ),
    ),

    # ── 200-SMA-cross family ──────────────────────────────────────────────────
    Candidate(
        "FRESH_TREND_INITIATION",
        "Just crossed above SMA200 (pct in [0, 2]%) + above SMA50 + ADX > 20. "
        "Catching the start of a new uptrend.",
        _and(
            lambda df, _: (df["pct_from_sma_200"] > 0)
                          & (df["pct_from_sma_200"] < 2.0),
            lambda df, _: df["above_sma_50"].astype(bool),
            lambda df, _: df["adx_14"] > 20,
        ),
    ),

    # ── Volume-confirmed move ─────────────────────────────────────────────────
    Candidate(
        "VOLUME_BREAKOUT_QUALITY",
        "Vol ratio > 2 (clear demand) + green_streak ≥ 1 + above SMA50. "
        "Different from old Breakout — uses volume + simple trend filter, "
        "no roc_20 minimum, no VIX dependence.",
        _and(
            lambda df, _: df["vol_ratio_20"] > 2.0,
            lambda df, _: df["green_streak"] >= 1,
            lambda df, _: df["above_sma_50"].astype(bool),
        ),
    ),
]


# ══════════════════════════════════════════════════════════════════════════════
# Market-regime-conditioned candidates
# ══════════════════════════════════════════════════════════════════════════════
# Premise: the un-conditioned candidates above failed OOS partly because
# they're pro-cyclical and the test period included a correction. Here we
# test whether requiring "market is in uptrend" — measured by an
# equal-weighted index built from the panel itself being above its
# 200-day SMA — saves any of them.

def _market_index(panel: dict[str, pd.DataFrame]) -> pd.Series:
    """Equal-weighted close-price index from the panel (geometric)."""
    log_returns = []
    for sym, df in panel.items():
        lr = (df["Close"] / df["Close"].shift(1)).apply(lambda x: pd.NA if pd.isna(x) else x).dropna()
        import numpy as np
        lr = np.log(df["Close"] / df["Close"].shift(1)).dropna()
        log_returns.append(lr.rename(sym))
    cross = pd.concat(log_returns, axis=1)
    eq_weighted_lr = cross.mean(axis=1).fillna(0)
    cumulative = eq_weighted_lr.cumsum()
    return cumulative.apply(lambda x: pd.NA if pd.isna(x) else x).dropna()


def _market_regime_series(panel: dict[str, pd.DataFrame]) -> pd.Series:
    """Boolean Series: True when equal-weighted market index > its 200-bar SMA."""
    idx = _market_index(panel)
    sma200 = idx.rolling(window=200, min_periods=200).mean()
    return (idx > sma200).reindex(idx.index).fillna(False)


def _conditioned(base_gates: Callable, regime: pd.Series) -> Callable:
    """Apply ``base_gates`` AND ``regime[bar_date] == True``."""
    # Pre-coerce the regime series once to avoid pandas' FutureWarning
    # about object-dtype fillna. The regime is already bool-valued.
    regime_bool = regime.astype(bool)
    def fn(df, st):
        base_mask = base_gates(df, st)
        regime_mask = regime_bool.reindex(df.index, fill_value=False)
        return base_mask & regime_mask
    return fn


# ══════════════════════════════════════════════════════════════════════════════
# Evaluation + reporting
# ══════════════════════════════════════════════════════════════════════════════

def _eval(strategy_name, panel, streak, predicate, *, baseline_mean=None):
    return summarise(evaluate_vector_predicate_panel(
        strategy_name=strategy_name, enriched_panel=panel,
        vix_streak=streak, predicate=predicate,
    ), baseline_mean_10d=baseline_mean)


def _universe_mean(panel, streak):
    return summarise(evaluate_vector_predicate_panel(
        strategy_name="universe", enriched_panel=panel,
        vix_streak=streak, predicate=lambda df, st: True,
    )).mean_10d


def main() -> None:
    panel = load_equity_panel()
    if not panel:
        print("No equity panel loaded — yfinance unreachable? Stopping.")
        return

    print("Building VIX proxy + enriching …")
    vix_df = build_vix_proxy(panel, smoothing=5)
    high_threshold = float(vix_df["Close"].quantile(0.65))
    streak = compute_vix_streaks(vix_df, high_threshold=high_threshold)
    engine = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            e = engine.enrich(df, sym)
            e = add_forward_returns(e, horizons=(5, 10, 20))
            enriched[sym] = e
        except Exception:    # noqa: BLE001
            continue
    print(f"  {len(enriched)} symbols enriched")

    train_panel, test_panel = split_panel_by_date(enriched, cutoff=OOS_CUTOFF)
    train_streak, test_streak = split_streak_by_date(streak, cutoff=OOS_CUTOFF)
    train_uni = _universe_mean(train_panel, train_streak)
    test_uni = _universe_mean(test_panel, test_streak)
    print(f"  train universe mean 10d = {train_uni*100:+.2f}%, "
          f"test universe mean 10d = {test_uni*100:+.2f}%")

    # ── Run every candidate and collect rows ─────────────────────────────────
    print()
    print("=" * 130)
    print(f"  {'STRATEGY':35s}  {'train n':>7s}  {'tr lift':>8s}  {'tr t':>5s}  "
          f"{'test n':>6s}  {'te lift':>8s}  {'te t':>5s}  {'decay':>6s}  ACCEPT?")
    print("=" * 130)

    all_rows: list[dict] = []
    accepted: list[str] = []
    for c in CANDIDATES:
        train_stats = _eval(c.name, train_panel, train_streak, c.gates,
                              baseline_mean=train_uni)
        test_stats = _eval(c.name, test_panel, test_streak, c.gates,
                             baseline_mean=test_uni)
        train_lift = (train_stats.mean_10d - train_uni) * 100
        test_lift = (
            (test_stats.mean_10d - test_uni) * 100
            if test_stats.n > 0 else float("nan")
        )
        decay = test_lift - train_lift if test_stats.n > 0 else float("nan")

        accept = (
            test_stats.n >= 200
            and not pd.isna(test_lift) and test_lift >= 0.3
            and not pd.isna(decay) and decay >= -0.5
            and not pd.isna(test_stats.t_stat_lift_10d)
            and test_stats.t_stat_lift_10d >= 2.0
        )
        flag = "✅ YES" if accept else ""
        if accept:
            accepted.append(c.name)
        print(
            f"  {c.name:35s}  {train_stats.n:>7d}  "
            f"{train_lift:>+7.2f}pp  {train_stats.t_stat_lift_10d:>+5.2f}  "
            f"{test_stats.n:>6d}  {test_lift:>+7.2f}pp  "
            f"{test_stats.t_stat_lift_10d:>+5.2f}  "
            f"{decay:>+5.2f}pp  {flag}"
        )
        all_rows.append({
            "round": 1, "strategy": c.name, "premise": c.premise,
            "train_n": train_stats.n, "train_lift_pp": round(train_lift, 3),
            "train_t": round(train_stats.t_stat_lift_10d, 2),
            "test_n": test_stats.n,
            "test_lift_pp": round(test_lift, 3) if not pd.isna(test_lift) else None,
            "test_t": round(test_stats.t_stat_lift_10d, 2) if not pd.isna(test_stats.t_stat_lift_10d) else None,
            "decay_pp": round(decay, 3) if not pd.isna(decay) else None,
            "accepted": accept,
        })

    print("=" * 130)

    # ── Print premises for accepted candidates ───────────────────────────────
    if accepted:
        print()
        print(f"Accepted candidates ({len(accepted)}):")
        for c in CANDIDATES:
            if c.name in accepted:
                print(f"  {c.name}")
                print(f"    Premise: {c.premise}")
    else:
        print()
        print("No candidate met all four acceptance criteria.")

    # ── For comparison, run MR on the same split ─────────────────────────────
    print()
    print("Reference: MR (post-tuning) on the same split")
    mr_gates = _and(
        lambda df, _: df["roc_5"] < -3.0,
        lambda df, _: df["bbw_20_2s_pctl"] < 40.0,
        lambda _, st: st >= 6,
    )
    mr_train = _eval("MR", train_panel, train_streak, mr_gates)
    mr_test = _eval("MR", test_panel, test_streak, mr_gates)
    mr_train_lift = (mr_train.mean_10d - train_uni) * 100
    mr_test_lift = (
        (mr_test.mean_10d - test_uni) * 100 if mr_test.n > 0 else float("nan")
    )
    print(f"  MR train: n={mr_train.n}, lift={mr_train_lift:+.2f}pp, "
          f"t={mr_train.t_stat_10d:+.2f}")
    print(f"  MR test:  n={mr_test.n}, lift={mr_test_lift:+.2f}pp, "
          f"t={mr_test.t_stat_10d:+.2f}")

    # ════════════════════════════════════════════════════════════════════════════
    # Round 2: same candidates conditioned on "market index > 200-SMA"
    # ════════════════════════════════════════════════════════════════════════════
    print()
    print("Building equal-weighted market index + regime series …")
    full_regime = _market_regime_series(enriched)
    train_regime = full_regime[full_regime.index < OOS_CUTOFF]
    test_regime = full_regime[full_regime.index >= OOS_CUTOFF]
    pct_up_train = float(train_regime.mean()) * 100
    pct_up_test = float(test_regime.mean()) * 100
    print(f"  market regime: train {pct_up_train:.0f}% of bars uptrending, "
          f"test {pct_up_test:.0f}% of bars uptrending")

    print()
    print("=" * 130)
    print(f"  ROUND 2 — same gates AND market regime up (index > 200-SMA)")
    print("=" * 130)
    print(f"  {'STRATEGY':35s}  {'train n':>7s}  {'tr lift':>8s}  {'tr t':>5s}  "
          f"{'test n':>6s}  {'te lift':>8s}  {'te t':>5s}  {'decay':>6s}  ACCEPT?")
    print("=" * 130)

    accepted_r2: list[str] = []
    for c in CANDIDATES:
        cond_gates_train = _conditioned(c.gates, train_regime)
        cond_gates_test = _conditioned(c.gates, test_regime)
        train_stats = _eval(c.name, train_panel, train_streak, cond_gates_train,
                              baseline_mean=train_uni)
        test_stats = _eval(c.name, test_panel, test_streak, cond_gates_test,
                             baseline_mean=test_uni)
        train_lift = (train_stats.mean_10d - train_uni) * 100
        test_lift = (
            (test_stats.mean_10d - test_uni) * 100
            if test_stats.n > 0 else float("nan")
        )
        decay = test_lift - train_lift if test_stats.n > 0 else float("nan")
        accept = (
            test_stats.n >= 200
            and not pd.isna(test_lift) and test_lift >= 0.3
            and not pd.isna(decay) and decay >= -0.5
            and not pd.isna(test_stats.t_stat_lift_10d)
            and test_stats.t_stat_lift_10d >= 2.0
        )
        flag = "✅ YES" if accept else ""
        if accept:
            accepted_r2.append(c.name)
        print(
            f"  {c.name:35s}  {train_stats.n:>7d}  "
            f"{train_lift:>+7.2f}pp  {train_stats.t_stat_lift_10d:>+5.2f}  "
            f"{test_stats.n:>6d}  {test_lift:>+7.2f}pp  "
            f"{test_stats.t_stat_lift_10d:>+5.2f}  "
            f"{decay:>+5.2f}pp  {flag}"
        )
        all_rows.append({
            "round": 2, "strategy": c.name, "premise": c.premise,
            "train_n": train_stats.n, "train_lift_pp": round(train_lift, 3),
            "train_t": round(train_stats.t_stat_lift_10d, 2),
            "test_n": test_stats.n,
            "test_lift_pp": round(test_lift, 3) if not pd.isna(test_lift) else None,
            "test_t": round(test_stats.t_stat_lift_10d, 2) if not pd.isna(test_stats.t_stat_lift_10d) else None,
            "decay_pp": round(decay, 3) if not pd.isna(decay) else None,
            "accepted": accept,
        })

    print("=" * 130)
    if accepted_r2:
        print(f"\nRound 2 accepted candidates ({len(accepted_r2)}):")
        for c in CANDIDATES:
            if c.name in accepted_r2:
                print(f"  {c.name}")
                print(f"    Premise: {c.premise}")
    else:
        print("\nRound 2: no candidate met all four acceptance criteria.")

    # ── Export ────────────────────────────────────────────────────────────────
    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("data/research")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"normal_regime_search_{ts}.csv"
    pd.DataFrame(all_rows).to_csv(out_path, index=False)
    print(f"\n  Exported → {out_path}")


if __name__ == "__main__":
    main()
