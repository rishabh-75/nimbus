"""Smoke tests for run_correlation_regime_diagnostics.py.

The diagnostic script reuses the validated helpers from
run_correlation_regime_validation.py — those don't need re-testing.
The new logic worth testing is:

  - Cluster-detection in _calendar_diagnostic: contiguous runs of
    a regime, ≥ MIN_CLUSTER_DAYS long.
  - Per-fold magnitude analysis correctness.

Both tested on synthetic data we control.
"""
from __future__ import annotations

import io
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from scripts.run_correlation_regime_diagnostics import (    # noqa: E402
    _calendar_diagnostic,
    _fold_magnitude_diagnostic,
)


# ══════════════════════════════════════════════════════════════════════
# Cluster detection
# ══════════════════════════════════════════════════════════════════════

class TestCalendarDiagnostic:

    def _capture(self, regime_series):
        """Run the diagnostic and return the emitted text as a string."""
        buf = io.StringIO()
        _calendar_diagnostic(regime_series, lambda s="": buf.write(s + "\n"))
        return buf.getvalue()

    def test_long_high_corr_cluster_is_listed(self):
        """A run of 10 consecutive HIGH_CORR days should appear."""
        idx = pd.bdate_range("2024-01-01", periods=30)
        labels = ["NORMAL"] * 10 + ["HIGH_CORR"] * 10 + ["NORMAL"] * 10
        rs = pd.Series(labels, index=idx)
        out = self._capture(rs)
        # The emitted text should contain the cluster's dates and length
        assert "10d" in out, f"expected length 10 in output, got:\n{out}"

    def test_short_cluster_not_listed(self):
        """A 3-day run is below the 5-day minimum and shouldn't be
        listed as a cluster."""
        idx = pd.bdate_range("2024-01-01", periods=30)
        labels = ["NORMAL"] * 10 + ["HIGH_CORR"] * 3 + ["NORMAL"] * 17
        rs = pd.Series(labels, index=idx)
        out = self._capture(rs)
        assert "No clusters" in out

    def test_cluster_extending_to_end_of_series_detected(self):
        """A cluster that runs to the last bar — make sure the
        end-of-series boundary is handled."""
        idx = pd.bdate_range("2024-01-01", periods=20)
        labels = ["NORMAL"] * 10 + ["HIGH_CORR"] * 10
        rs = pd.Series(labels, index=idx)
        out = self._capture(rs)
        assert "10d" in out

    def test_low_corr_section_listed_independently(self):
        """HIGH_CORR and LOW_CORR are reported in separate sections."""
        idx = pd.bdate_range("2024-01-01", periods=30)
        labels = (
            ["HIGH_CORR"] * 7 + ["NORMAL"] * 5 + ["LOW_CORR"] * 8 + ["NORMAL"] * 10
        )
        rs = pd.Series(labels, index=idx)
        out = self._capture(rs)
        assert "REGIME: HIGH_CORR" in out
        assert "REGIME: LOW_CORR" in out
        # Both clusters should be listed
        assert "7d" in out
        assert "8d" in out


# ══════════════════════════════════════════════════════════════════════
# Per-fold magnitude diagnostic
# ══════════════════════════════════════════════════════════════════════

class TestFoldMagnitudeDiagnostic:

    def _capture(self, fold_results):
        buf = io.StringIO()
        results = _fold_magnitude_diagnostic(
            fold_results, lambda s="": buf.write(s + "\n"),
        )
        return buf.getvalue(), results

    def test_outlier_flag_fires_on_2x_spike(self):
        """Three folds at +1pp and one fold at +9pp should flag
        as an outlier (max/mean = ~2.5×)."""
        fold_results = [
            {"test_stats": {
                "HIGH_CORR": {"lift_pp": 1.0, "n_obs": 10000, "mean_pp": 0.0},
                "NORMAL":    {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
                "LOW_CORR":  {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
            }} for _ in range(3)
        ] + [
            {"test_stats": {
                "HIGH_CORR": {"lift_pp": 9.0, "n_obs": 1000, "mean_pp": 0.0},
                "NORMAL":    {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
                "LOW_CORR":  {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
            }}
        ]
        out, results = self._capture(fold_results)
        assert results["HIGH_CORR"]["outlier_flag"] is True
        assert "OUTLIER FLAG" in out

    def test_robust_mean_collapses_when_outlier_dropped(self):
        """If three folds are at +1 and one fold (smallest N) is at
        +9, robust mean (excl. smallest) should be ~+1, much less
        than all-fold mean of ~+3."""
        fold_results = [
            {"test_stats": {
                "HIGH_CORR": {"lift_pp": 1.0, "n_obs": 10000, "mean_pp": 0.0},
                "NORMAL":    {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
                "LOW_CORR":  {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
            }} for _ in range(3)
        ] + [
            {"test_stats": {
                "HIGH_CORR": {"lift_pp": 9.0, "n_obs": 1000, "mean_pp": 0.0},
                "NORMAL":    {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
                "LOW_CORR":  {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
            }}
        ]
        _, results = self._capture(fold_results)
        # All-fold mean: (1+1+1+9)/4 = 3.0
        assert abs(results["HIGH_CORR"]["mean_lift"] - 3.0) < 0.01
        # Robust mean: (1+1+1)/3 = 1.0
        assert abs(results["HIGH_CORR"]["robust_mean"] - 1.0) < 0.01

    def test_no_outlier_when_lifts_are_consistent(self):
        """All four folds at ~+1pp → no outlier flag."""
        fold_results = [
            {"test_stats": {
                "HIGH_CORR": {"lift_pp": 1.0 + i * 0.1, "n_obs": 10000, "mean_pp": 0.0},
                "NORMAL":    {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
                "LOW_CORR":  {"lift_pp": 0.0, "n_obs": 10000, "mean_pp": 0.0},
            }} for i in range(4)
        ]
        _, results = self._capture(fold_results)
        assert results["HIGH_CORR"]["outlier_flag"] is False
