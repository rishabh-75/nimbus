"""Tests for nimbus_v3.data.filings_loader.FilingsLoader."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd
import pytest

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.filings_loader import (
    Filing,
    FilingsLoader,
    parse_filings_payload,
)


@dataclass
class _MockNSE:
    responses: dict[str, object] = field(default_factory=dict)
    calls: list = field(default_factory=list)

    def fetch(self, url, *, referer, params=None, extra_headers=None):  # noqa: ANN001, ARG002
        self.calls.append({"url": url, "params": params})
        symbol = (params or {}).get("symbol", "")
        return self.responses.get(symbol)


@pytest.fixture
def loader(tmp_path: Path) -> tuple[FilingsLoader, _MockNSE]:
    nse = _MockNSE()
    cache = ParquetCache(tmp_path / "filings")
    fl = FilingsLoader(nse_client=nse, cache=cache)  # type: ignore[arg-type]
    return fl, nse


# ══════════════════════════════════════════════════════════════════════════════
# Parser
# ══════════════════════════════════════════════════════════════════════════════

def test_parse_flat_list_shape() -> None:
    payload = [
        {"an_dt": "15-May-2024 16:30", "subject": "Quarterly Results",
         "desc": "Announcement"},
    ]
    filings = parse_filings_payload(payload, "RELIANCE")
    assert len(filings) == 1
    assert filings[0].symbol == "RELIANCE"
    assert filings[0].headline == "Quarterly Results"


def test_parse_rows_dict_shape() -> None:
    payload = {"rows": [
        {"broadcastDate": "15-May-2024", "subject": "Dividend"},
    ]}
    filings = parse_filings_payload(payload, "TCS")
    assert len(filings) == 1


def test_parse_data_dict_shape() -> None:
    payload = {"data": [
        {"date": "15-May-2024", "subject": "Results"},
    ]}
    filings = parse_filings_payload(payload, "HDFC")
    assert len(filings) == 1


def test_parse_skips_rows_without_date() -> None:
    filings = parse_filings_payload([
        {"subject": "No date here"},
        {"an_dt": "15-May-2024", "subject": "Has date"},
    ], "X")
    assert len(filings) == 1


def test_parse_sorts_newest_first() -> None:
    filings = parse_filings_payload([
        {"an_dt": "01-May-2024", "subject": "Older"},
        {"an_dt": "15-May-2024", "subject": "Newer"},
        {"an_dt": "10-May-2024", "subject": "Middle"},
    ], "X")
    assert [f.headline for f in filings] == ["Newer", "Middle", "Older"]


def test_parse_tolerates_garbage() -> None:
    assert parse_filings_payload("garbage", "X") == []
    assert parse_filings_payload(42, "X") == []
    assert parse_filings_payload({"unexpected": "shape"}, "X") == []


def test_parse_captures_attachment_url() -> None:
    filings = parse_filings_payload([
        {"an_dt": "15-May-2024", "subject": "Q4",
         "attchmntFile": "https://archives.nseindia.com/corporate/file.pdf"},
    ], "X")
    assert filings[0].attachment_url == "https://archives.nseindia.com/corporate/file.pdf"


# ══════════════════════════════════════════════════════════════════════════════
# Filing dataclass
# ══════════════════════════════════════════════════════════════════════════════

def test_filing_is_frozen_and_tz_normalised() -> None:
    f = Filing(
        symbol="X",
        filing_date=pd.Timestamp("2024-05-15 10:00", tz="UTC"),
        category="c", headline="h", details="d", attachment_url=None,
    )
    import dataclasses
    with pytest.raises(dataclasses.FrozenInstanceError):
        f.symbol = "Y"  # type: ignore[misc]
    assert f.filing_date.tz is None


# ══════════════════════════════════════════════════════════════════════════════
# Loader behaviour
# ══════════════════════════════════════════════════════════════════════════════

def test_load_hits_nse_and_caches(loader: tuple[FilingsLoader, _MockNSE]) -> None:
    fl, nse = loader
    nse.responses["R"] = [{"an_dt": "15-May-2024", "subject": "Results"}]
    out1 = fl.load("R")
    assert len(out1) == 1
    # Second call: cache hit. Change NSE response and confirm cache wins.
    nse.responses["R"] = [
        {"an_dt": "15-May-2024", "subject": "Results"},
        {"an_dt": "16-May-2024", "subject": "New One"},
    ]
    out2 = fl.load("R")
    assert len(out2) == 1


def test_load_force_refresh(loader: tuple[FilingsLoader, _MockNSE]) -> None:
    fl, nse = loader
    nse.responses["R"] = [{"an_dt": "15-May-2024", "subject": "A"}]
    fl.load("R")
    nse.responses["R"] = [
        {"an_dt": "15-May-2024", "subject": "A"},
        {"an_dt": "16-May-2024", "subject": "B"},
    ]
    out = fl.load("R", force_refresh=True)
    assert len(out) == 2


def test_load_since_window(loader: tuple[FilingsLoader, _MockNSE]) -> None:
    fl, nse = loader
    nse.responses["R"] = [
        {"an_dt": "01-May-2024", "subject": "Old"},
        {"an_dt": "10-May-2024", "subject": "Mid"},
        {"an_dt": "15-May-2024", "subject": "Recent"},
    ]
    recent = fl.load_since("R", asof_date=pd.Timestamp("2024-05-15"),
                              lookback_days=7)
    # 7-day window: 10-May and 15-May only.
    assert [f.headline for f in recent] == ["Recent", "Mid"]


def test_empty_symbol_rejected(loader: tuple[FilingsLoader, _MockNSE]) -> None:
    fl, _ = loader
    with pytest.raises(ValueError):
        fl.load("")


def test_load_returns_empty_on_nse_failure(loader: tuple[FilingsLoader, _MockNSE]) -> None:
    fl, _ = loader
    assert fl.load("UNKNOWN") == []
