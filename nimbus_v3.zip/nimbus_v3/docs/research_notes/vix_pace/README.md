# VIX Pace Research Archive

Iteration-by-iteration research on whether India VIX's *pace* (rate of
change) carries actionable signal for the NIMBUS v3 conviction
system. This directory is the authoritative record of what was
tested, what replicated out-of-sample, and what got shipped.

## TL;DR

**Shipped**: panel-wide `VIX: RISING/STABLE/FALLING` badge in Market
Pulse header, plus per-industry ↑/↓ arrows for 11 industries whose
directional response to VIX regime replicated across 3+ walk-forward
folds at the 20-day VIX slope window.

**Did not ship**: per-tag × regime numerical multipliers for the
conviction formula. Walk-forward showed tag × regime lifts do not
replicate out-of-sample.

---

## Timeline

### Iteration 1 — single-window research (20d)

**Script**: `scripts/run_vix_pace_research.py` (single-window mode)
**Output**: `vix_pace_research_20d.txt`

Initial exploration. Four reports: regime distribution, industry ×
regime, tag × regime, phase × regime. Key findings:

- **Baseline is regime-dependent.** Universe fwd_10d is +2.48% in
  RISING, +0.35% in STABLE, +1.68% in FALLING. Stocks go UP more
  when VIX is rising — that's the "inflection off a low base"
  pattern.
- **ACCUM's edge is STABLE-only.** Lift +0.28pp (t=+5.5) in STABLE,
  negative or insignificant everywhere else.
- **LOWβ is regime-robust.** Positive lift in all three regimes
  (+0.26 / +0.57 / +0.24 pp, all t>3).
- **ALPHA's headline +2pp lift is mostly baseline.** True
  marginal edge is ~+0.1pp in STABLE.

### Iteration 2 — multi-window bake-off (5/10/20/60)

**Script**: `scripts/run_vix_pace_research.py` (multi-window mode)
**Outputs**: `vix_pace_research_{5,10,20,60}d.txt` +
`vix_pace_research_summary.txt`

Tested each slope window to compare regime distributions and
signal strength. Findings:

- ACCUM-STABLE-only pattern replicated across every window.
- LOWβ regime-robustness held at 5-20d, flipped negative in RISING
  at 60d (secular fear-rise trends don't favour quality names).
- 60d produced biggest industry spreads but noisiest baseline
  z-score (only ~4 independent 60d slope observations per 252d
  baseline).

### Iteration 3 — per-tag multiplier walk-forward (NEGATIVE RESULT)

**Script**: `scripts/run_vix_multiplier_validation.py`
**Output**: `vix_multiplier_validation.txt`

Tested whether tag × regime lifts generalize across a temporal
split. Fixed-date midpoint split (2021-04→2023-10 train, 2023-10
→2026-04 test). Sweep of 9 (k, clamp) parameter combinations per
window.

**Verdict: DO NOT SHIP multipliers.** All 4 windows had >3 sign
flips. Training lifts and test lifts disagreed on direction for
cells that were supposed to be robust. ACCUM's train-half +0.37pp
STABLE flipped to -0.02pp on test. ALPHA's train-half +1.29pp
RISING flipped to -0.33pp.

Out-of-sample correlations were positive (+0.02 to +0.03) but
mostly from the regime baseline shift, not from the tag × regime
interactions we were trying to calibrate.

### Iteration 4 — per-symbol → per-industry direction (POSITIVE RESULT)

**Script**: `scripts/run_vix_component_industry_validation.py`
**Output**: `vix_component_industry_validation.txt`

Different approach. Instead of pooling at the industry level and
computing one lift per cell, stratify per-symbol first (each
stock has ~1200 bars of regime-labelled history), then median-
aggregate to per-industry direction.

Validation: expanding-window walk-forward, 4 folds, 10-bar purging
at train/test boundaries to block fwd_10d leakage. Stability
score per (industry, regime) = fraction of folds where train
direction and test direction agreed in sign.

**Verdict at 20d: SHIP.** 31 (industry, regime) cells at 100%
stability across 3 folds. 11 industries have ≥ 2 stable regimes.
All 11 show the same directional pattern: **UP in RISING, DOWN in
STABLE**. Coherent economic narrative (cyclicals/rate-sensitives
catch rotation bids when fear inflects up, lag when markets are
quiet).

The 11 stable industries:

    Aerospace & Defense, Auto Components, Chemicals & Petrochemicals,
    Electrical Equipment, Fertilizers & Agrochemicals, IT - Services,
    Leisure Services, Power, Realty, Telecom - Services,
    Transport Services

---

## Why 20d (and not 5d, which the script's verdict line flagged first)

The initial version of the verdict picker used
`max(n_stable_industries)` as the tie-breaker, which picked 5d.
But reading the underlying stability tables honestly:

- 5d had most of its stable cells coming from 2-fold 100%
  pairwise agreements. Under the null, 2-fold pairwise agreement
  has a 25% coincidence rate. Across 52 industries × 3 regimes,
  expected coincidence = ~10 cells.
- 20d had 31 cells at stability=1.0 across 3 folds. Coincidence
  rate under null = ~12.5%. Strong evidence.

The verdict picker was updated in the same commit that shipped
the production code (see `scripts/run_vix_component_industry_validation.py::_verdict_for_window`)
to use an `evidence_score = Σ n_folds across stable cells`,
rewarding deep replication over shallow pairwise agreement.
Future re-runs will correctly pick 20d.

---

## Production code

Research outputs consumed by:

- `nimbus_v3/compute/vix_pace.py` — `VIXPaceClassifier`
  (regime classifier) + `VIXPaceState` dataclass. Constants:
  SLOPE_WINDOW=20, Z_BASELINE_WINDOW=252, Z_CUTOFF=1.0. All three
  tunable constants contribute to `schema_hash()` so parameter
  changes invalidate downstream caches.

- `nimbus_v3/compute/vix_regime_industry_directions.py` — static
  config encoding the 11-industry × regime directional table.
  Public API: `direction_for(industry, regime)` returns UP /
  DOWN / NEUTRAL.

- `nimbus_v3/ui/widgets/market_context_tab.py` — `set_vix_state`
  method accepts a `VIXPaceState` and updates (a) the header
  badge "VIX: RISING/STABLE/FALLING", (b) per-industry ↑/↓
  arrows in the group table.

- `nimbus_v3/ui/main_window.py::_push_vix_state_to_market_context` —
  loads VIX history, classifies current state, pushes to the
  tab. Called during `install_scan_dependencies` (startup +
  post-scan). Best-effort: failures route to `set_vix_state(None)`
  and log.

---

## When to re-run the validation

Every 6 months OR after any major market-regime shift. Run:

    python scripts/run_vix_component_industry_validation.py

Result lands at `scripts/output/vix_component_industry_validation.txt`.
If the stable-11 list changes by more than 2-3 industries,
update `nimbus_v3/compute/vix_regime_industry_directions.py`
accordingly (the `_STABLE_DIRECTIONS` dict + the
`STABLE_INDUSTRIES` tuple). The corresponding test file
`tests/compute/test_vix_regime_industry_directions.py` pins the
list with `_EXPECTED_STABLE_INDUSTRIES` — update it in the same
commit.

---

## What future iterations could try

Not shipping these, but documenting for posterity so the next
researcher doesn't re-tread:

- **Per-symbol multipliers** (not per-industry aggregation).
  Each stock gets its own regime-response profile. Problem: each
  symbol has only ~1200 bars split across 3 regimes = ~100-140
  observations per symbol-regime cell. Thinner than the industry
  cells and more prone to overfitting. Would need ≥ 2 more years
  of data or a shrinkage prior toward the industry aggregate.

- **Shrinkage toward unconditional tag effect**, weighted by cell N
  (Bayesian-flavoured). Small-N cells pull strongly toward the prior;
  large-N cells retain their conditional estimate. The right
  methodology when you have sparse cells, but material
  implementation effort and no certainty it would flip the negative
  multiplier-validation result.

- **Per-industry multipliers** (not just directions). The research
  measures lift magnitudes; the production code only uses signs.
  Shipping magnitudes would require a second walk-forward showing
  magnitude-preservation out-of-sample, which iteration 3 already
  showed does not hold at the tag level. Probably wouldn't hold at
  the industry level either but hasn't been formally tested.

- **VIX level × VIX pace interactions**. Current classifier is
  pace-only (a slope z-score). Level (absolute VIX value) might
  carry independent signal. Would require re-designing the
  classifier to emit a 2D regime label, and the research/validation
  work doubles.
