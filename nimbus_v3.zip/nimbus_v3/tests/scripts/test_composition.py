"""Tests for scripts._composition — ChainedMarketProvider fallback semantics
and ProxyMarketProvider correctness."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.core.context import MarketContext
from nimbus_v3.core.types import VIXRegime
from scripts._composition import (
    ChainedMarketProvider,
    ProxyMarketProvider,
    build_context_providers,
    build_market_provider,
    universe_from_panel,
)


_ASOF = pd.Timestamp("2024-05-15")


# ══════════════════════════════════════════════════════════════════════════════
# Fakes — mimic the ContextProvider protocol with controllable behaviour
# ══════════════════════════════════════════════════════════════════════════════

class _GoodPrimary:
    """Always returns a usable MarketContext."""
    def __init__(self):
        self.calls = 0
    def build(self, *, symbol, asof_date):
        self.calls += 1
        return MarketContext(
            asof_date=asof_date, vix_value=20.0,
            vix_regime=VIXRegime.HIGH, vix_high_streak=7,
        )


class _RaisingPrimary:
    def __init__(self, exc=RuntimeError("nse down")):
        self.exc = exc
        self.calls = 0
    def build(self, *, symbol, asof_date):
        self.calls += 1
        raise self.exc


class _RegimeNonePrimary:
    """Simulates VIX fetch failure cascading into a None regime."""
    def __init__(self):
        self.calls = 0
    def build(self, *, symbol, asof_date):
        self.calls += 1
        return MarketContext(
            asof_date=asof_date, vix_value=None,
            vix_regime=None, vix_high_streak=0,
        )


class _CountingFallback:
    def __init__(self, regime=VIXRegime.NORMAL):
        self.regime = regime
        self.calls = 0
    def build(self, *, symbol, asof_date):
        self.calls += 1
        return MarketContext(
            asof_date=asof_date, vix_value=15.0,
            vix_regime=self.regime, vix_high_streak=0,
        )


# ══════════════════════════════════════════════════════════════════════════════
# ChainedMarketProvider
# ══════════════════════════════════════════════════════════════════════════════

def test_chained_uses_primary_when_healthy() -> None:
    primary = _GoodPrimary()
    fallback = _CountingFallback()
    chain = ChainedMarketProvider(primary, fallback)
    ctx = chain.build(symbol="X", asof_date=_ASOF)
    assert ctx.vix_value == 20.0
    assert ctx.vix_regime == VIXRegime.HIGH
    assert primary.calls == 1
    assert fallback.calls == 0
    assert chain.primary_hits == 1
    assert chain.fallback_hits == 0


def test_chained_falls_back_when_primary_raises(caplog) -> None:
    primary = _RaisingPrimary()
    fallback = _CountingFallback(regime=VIXRegime.ELEVATED)
    chain = ChainedMarketProvider(primary, fallback)
    with caplog.at_level(logging.ERROR):
        ctx = chain.build(symbol="X", asof_date=_ASOF)
    assert primary.calls == 1
    assert fallback.calls == 1
    assert ctx.vix_regime == VIXRegime.ELEVATED
    assert chain.primary_hits == 0
    assert chain.fallback_hits == 1
    # The exception is logged.
    assert any("primary raised" in rec.message for rec in caplog.records)


def test_chained_falls_back_when_primary_returns_none_regime(caplog) -> None:
    primary = _RegimeNonePrimary()
    fallback = _CountingFallback(regime=VIXRegime.NORMAL)
    chain = ChainedMarketProvider(primary, fallback)
    with caplog.at_level(logging.INFO):
        ctx = chain.build(symbol="X", asof_date=_ASOF)
    assert primary.calls == 1
    assert fallback.calls == 1
    assert ctx.vix_regime == VIXRegime.NORMAL
    assert chain.fallback_hits == 1


def test_chained_hit_counters_accumulate_across_calls() -> None:
    primary = _GoodPrimary()
    fallback = _CountingFallback()
    chain = ChainedMarketProvider(primary, fallback)
    for _ in range(5):
        chain.build(symbol="X", asof_date=_ASOF)
    assert chain.primary_hits == 5
    assert chain.fallback_hits == 0


# ══════════════════════════════════════════════════════════════════════════════
# ProxyMarketProvider
# ══════════════════════════════════════════════════════════════════════════════

def _vix_proxy_df() -> tuple[pd.DataFrame, pd.Series]:
    idx = pd.bdate_range("2024-04-01", periods=40)
    closes = np.linspace(15.0, 22.0, len(idx))
    df = pd.DataFrame({"Close": closes}, index=idx)
    streak = pd.Series(np.arange(len(idx), dtype=int), index=idx)
    return df, streak


def test_proxy_provider_returns_context_at_asof() -> None:
    df, streak = _vix_proxy_df()
    p = ProxyMarketProvider(df, streak)
    asof = df.index[-1]
    ctx = p.build(symbol="X", asof_date=asof)
    assert ctx.vix_value == pytest.approx(22.0)
    # 22 ≥ 19.39 → HIGH per the proxy thresholds.
    assert ctx.vix_regime == VIXRegime.HIGH
    assert ctx.vix_high_streak == streak.iloc[-1]


def test_proxy_provider_handles_asof_before_panel() -> None:
    df, streak = _vix_proxy_df()
    p = ProxyMarketProvider(df, streak)
    too_early = pd.Timestamp("2020-01-01")
    ctx = p.build(symbol="X", asof_date=too_early)
    assert ctx.vix_regime == VIXRegime.NORMAL
    assert ctx.vix_high_streak == 0
    assert ctx.vix_value is None


def test_proxy_provider_classifies_normal_range() -> None:
    idx = pd.bdate_range("2024-05-01", periods=5)
    df = pd.DataFrame({"Close": [13.0, 14.0, 14.5, 13.0, 12.5]}, index=idx)
    streak = pd.Series([0]*5, index=idx)
    p = ProxyMarketProvider(df, streak)
    ctx = p.build(symbol="X", asof_date=idx[-1])
    assert ctx.vix_regime == VIXRegime.NORMAL


# ══════════════════════════════════════════════════════════════════════════════
# build_market_provider
# ══════════════════════════════════════════════════════════════════════════════

def _enriched_panel(symbols=("A", "B", "C")) -> dict:
    """Tiny enriched-style panel sufficient for build_vix_proxy."""
    rng = np.random.default_rng(0)
    idx = pd.bdate_range("2024-01-01", periods=200)
    panel = {}
    for s in symbols:
        closes = 100.0 + rng.normal(0, 1.5, len(idx)).cumsum()
        panel[s] = pd.DataFrame({
            "Open": closes, "High": closes + 1, "Low": closes - 1,
            "Close": closes, "Volume": 1e6,
        }, index=idx)
    return panel


def test_build_market_provider_no_live_returns_proxy() -> None:
    panel = _enriched_panel()
    p = build_market_provider(panel, use_live_vix=False)
    assert isinstance(p, ProxyMarketProvider)


def test_build_market_provider_live_returns_chained() -> None:
    panel = _enriched_panel()
    # Live mode tries to construct VIXLoader. In environments without
    # network, that may fall back to proxy; either result is acceptable.
    p = build_market_provider(panel, use_live_vix=True)
    assert isinstance(p, (ChainedMarketProvider, ProxyMarketProvider))


def test_build_context_providers_returns_bundle_with_market() -> None:
    panel = _enriched_panel()
    bundle = build_context_providers(
        panel,
        use_live_vix=False, use_live_filing=False, use_live_options=False,
    )
    assert bundle.market is not None
    # Sector requires a Universe; filing + options explicitly disabled
    # here to keep this test deterministic and offline.
    assert bundle.sector is None
    assert bundle.options is None
    assert bundle.filing is None
    assert bundle.flow is None


# ══════════════════════════════════════════════════════════════════════════════
# universe_from_panel
# ══════════════════════════════════════════════════════════════════════════════

def test_universe_from_panel_includes_every_symbol() -> None:
    panel = _enriched_panel(("A", "B", "C", "D"))
    u = universe_from_panel(panel)
    assert set(u.symbols.keys()) == {"A", "B", "C", "D"}
    for sym, meta in u.symbols.items():
        assert meta.symbol == sym
        assert meta.sector == "Unknown"


# ══════════════════════════════════════════════════════════════════════════════
# Cached sectors (universe cache on disk)
# ══════════════════════════════════════════════════════════════════════════════

from pathlib import Path
import json
import os
import time

from scripts._composition import (
    _load_cached_sectors, _save_sectors_cache, _sectors_from_universe,
    build_sector_provider, build_universe_with_sectors,
)
from nimbus_v3.core.universe import SymbolMeta, Universe


def test_sectors_cache_miss_returns_none(tmp_path: Path) -> None:
    assert _load_cached_sectors(tmp_path / "missing.json") is None


def test_sectors_cache_round_trip(tmp_path: Path) -> None:
    cache = tmp_path / "sectors.json"
    sectors = {
        "RELIANCE": {"sector": "Oil & Gas", "industry": "Petroleum"},
        "HDFCBANK": {"sector": "Private Banking", "industry": "Banking"},
    }
    _save_sectors_cache(cache, sectors)
    loaded = _load_cached_sectors(cache)
    assert loaded == sectors


def test_sectors_cache_stale_returns_none(tmp_path: Path) -> None:
    """A file older than the TTL is treated as a miss."""
    cache = tmp_path / "stale.json"
    _save_sectors_cache(cache, {"X": {"sector": "Banking", "industry": "Banking"}})
    # Stamp the file 30 hours in the past (TTL is 24h).
    old = time.time() - 30 * 3600
    os.utime(cache, (old, old))
    assert _load_cached_sectors(cache) is None


def test_sectors_cache_corrupt_json_returns_none(tmp_path: Path) -> None:
    """Corrupted cache files are treated as misses rather than raising."""
    cache = tmp_path / "corrupt.json"
    cache.write_text("this is not json {{{")
    assert _load_cached_sectors(cache) is None


def test_sectors_from_universe_extracts_map() -> None:
    uni = Universe(
        symbols={
            "RELIANCE": SymbolMeta(
                symbol="RELIANCE", sector="Oil & Gas", industry="Petroleum",
            ),
            "HDFCBANK": SymbolMeta(
                symbol="HDFCBANK", sector="Private Banking", industry="Banking",
            ),
        },
        built_at=pd.Timestamp("2024-01-01"),
    )
    mapping = _sectors_from_universe(uni)
    assert mapping["RELIANCE"]["sector"] == "Oil & Gas"
    assert mapping["HDFCBANK"]["industry"] == "Banking"


# ══════════════════════════════════════════════════════════════════════════════
# build_universe_with_sectors
# ══════════════════════════════════════════════════════════════════════════════

def test_build_universe_uses_cache_when_fresh(tmp_path: Path) -> None:
    """A fresh cache avoids the NSE fetch entirely."""
    cache = tmp_path / "universe.json"
    _save_sectors_cache(cache, {
        "A": {"sector": "Banking", "industry": "Banking"},
        "B": {"sector": "FMCG", "industry": "Consumer Staples"},
    })
    panel = _enriched_panel(("A", "B"))
    # use_live_nse=True but cache hit wins.
    uni = build_universe_with_sectors(
        panel, use_live_nse=True, cache_path=cache,
    )
    assert uni.symbols["A"].sector == "Banking"
    assert uni.symbols["B"].sector == "FMCG"


def test_build_universe_only_includes_panel_symbols(tmp_path: Path) -> None:
    """Cache may cover 500 symbols but universe contains only those in the panel."""
    cache = tmp_path / "universe.json"
    _save_sectors_cache(cache, {
        "A": {"sector": "Banking", "industry": "Banking"},
        "B": {"sector": "FMCG", "industry": "Consumer"},
        "C": {"sector": "IT", "industry": "Software"},
        "D": {"sector": "Auto", "industry": "Vehicles"},
    })
    panel = _enriched_panel(("A", "B"))
    uni = build_universe_with_sectors(
        panel, use_live_nse=False, cache_path=cache,
    )
    assert set(uni.symbols.keys()) == {"A", "B"}


def test_build_universe_fallback_unknown_sectors_when_no_cache_no_live(
    tmp_path: Path,
) -> None:
    """No cache AND use_live_nse=False → every symbol tagged Unknown."""
    cache = tmp_path / "never_created.json"
    panel = _enriched_panel(("A", "B", "C"))
    uni = build_universe_with_sectors(
        panel, use_live_nse=False, cache_path=cache,
    )
    assert all(
        m.sector == "Unknown" for m in uni.symbols.values()
    )
    assert set(uni.symbols) == {"A", "B", "C"}


def test_build_universe_handles_panel_symbol_missing_from_cache(
    tmp_path: Path,
) -> None:
    """Symbols in the panel but not in the cache default to Unknown."""
    cache = tmp_path / "partial.json"
    _save_sectors_cache(cache, {
        "A": {"sector": "Banking", "industry": "Banking"},
    })
    panel = _enriched_panel(("A", "NEW_SYMBOL"))
    uni = build_universe_with_sectors(
        panel, use_live_nse=False, cache_path=cache,
    )
    assert uni.symbols["A"].sector == "Banking"
    assert uni.symbols["NEW_SYMBOL"].sector == "Unknown"


# ══════════════════════════════════════════════════════════════════════════════
# build_sector_provider
# ══════════════════════════════════════════════════════════════════════════════

def test_build_sector_provider_returns_none_when_no_known_sectors() -> None:
    """If every universe symbol is 'Unknown', the factory skips."""
    uni = Universe(
        symbols={
            "A": SymbolMeta(symbol="A", sector="Unknown"),
            "B": SymbolMeta(symbol="B", sector="Unknown"),
        },
        built_at=pd.Timestamp("2024-01-01"),
    )
    provider = build_sector_provider(uni)
    assert provider is None


def test_build_sector_provider_constructs_when_sectors_known(tmp_path: Path) -> None:
    """At least one known sector → provider gets built."""
    uni = Universe(
        symbols={
            "A": SymbolMeta(symbol="A", sector="Banking"),
            "B": SymbolMeta(symbol="B", sector="Unknown"),
        },
        built_at=pd.Timestamp("2024-01-01"),
    )
    provider = build_sector_provider(uni, cache_dir=tmp_path / "index_cache")
    assert provider is not None


# ══════════════════════════════════════════════════════════════════════════════
# Extended build_context_providers
# ══════════════════════════════════════════════════════════════════════════════

def test_build_context_providers_wires_sector_when_universe_supplied(
    tmp_path: Path,
) -> None:
    panel = _enriched_panel(("A", "B"))
    uni = Universe(
        symbols={
            "A": SymbolMeta(symbol="A", sector="Banking"),
            "B": SymbolMeta(symbol="B", sector="FMCG"),
        },
        built_at=pd.Timestamp("2024-01-01"),
    )
    bundle = build_context_providers(
        panel, universe=uni, use_live_vix=False, use_live_sector=True,
    )
    assert bundle.market is not None
    assert bundle.sector is not None


def test_build_context_providers_sector_disabled_by_flag() -> None:
    panel = _enriched_panel(("A",))
    uni = Universe(
        symbols={"A": SymbolMeta(symbol="A", sector="Banking")},
        built_at=pd.Timestamp("2024-01-01"),
    )
    bundle = build_context_providers(
        panel, universe=uni, use_live_vix=False, use_live_sector=False,
    )
    assert bundle.sector is None


def test_build_context_providers_sector_none_when_universe_absent() -> None:
    """Legacy call pattern (no universe arg) → sector slot stays None.
    Filing explicitly disabled for determinism."""
    panel = _enriched_panel(("A",))
    bundle = build_context_providers(
        panel, use_live_vix=False, use_live_filing=False,
    )
    assert bundle.sector is None
    assert bundle.filing is None


# ══════════════════════════════════════════════════════════════════════════════
# build_filing_provider + filing wiring
# ══════════════════════════════════════════════════════════════════════════════

from scripts._composition import build_filing_provider
from nimbus_v3.context.filing_context import FilingContextProvider


def test_build_filing_provider_constructs_when_nse_available() -> None:
    """In a normal environment, the filing provider gets built."""
    provider = build_filing_provider()
    # Either we got a real provider, or NSE construction failed gracefully.
    assert provider is None or isinstance(provider, FilingContextProvider)


def test_build_filing_provider_returns_none_when_construction_fails(
    monkeypatch,
) -> None:
    """If NSEClient construction raises, the factory returns None."""
    import scripts._composition as comp

    def raising_nse():
        raise RuntimeError("network unreachable")

    monkeypatch.setattr(comp, "get_shared_client", raising_nse)
    provider = build_filing_provider()
    assert provider is None


def test_build_context_providers_wires_filing_when_enabled() -> None:
    """Default config: use_live_filing=True → filing slot populated
    when NSEClient is constructible."""
    panel = _enriched_panel(("A",))
    bundle = build_context_providers(
        panel, use_live_vix=False, use_live_sector=False, use_live_filing=True,
    )
    # Filing provider built, OR construction failed gracefully — both valid.
    assert bundle.filing is None or isinstance(
        bundle.filing, FilingContextProvider
    )


def test_build_context_providers_filing_disabled_by_flag() -> None:
    panel = _enriched_panel(("A",))
    bundle = build_context_providers(
        panel, use_live_vix=False, use_live_sector=False, use_live_filing=False,
    )
    assert bundle.filing is None


def test_build_context_providers_filing_independent_of_sector() -> None:
    """sector and filing toggles don't interfere with each other."""
    panel = _enriched_panel(("A",))
    uni = Universe(
        symbols={"A": SymbolMeta(symbol="A", sector="Banking")},
        built_at=pd.Timestamp("2024-01-01"),
    )
    bundle = build_context_providers(
        panel, universe=uni,
        use_live_vix=False, use_live_sector=True, use_live_filing=False,
    )
    assert bundle.sector is not None
    assert bundle.filing is None


# ══════════════════════════════════════════════════════════════════════════════
# Phase 8d-i: options provider wiring
# ══════════════════════════════════════════════════════════════════════════════

from scripts._composition import build_options_provider
from nimbus_v3.context.options_context import OptionsContextProvider


def test_build_options_provider_constructs_when_nse_available() -> None:
    """In a normal environment, the options provider gets built."""
    provider = build_options_provider()
    # Either we got a real provider, or NSE construction failed gracefully.
    assert provider is None or isinstance(provider, OptionsContextProvider)


def test_build_options_provider_returns_none_when_construction_fails(
    monkeypatch,
) -> None:
    """If NSEClient construction raises, the factory returns None
    rather than propagating the exception out to the caller."""
    import scripts._composition as comp

    def raising_nse():
        raise RuntimeError("network unreachable")

    monkeypatch.setattr(comp, "get_shared_client", raising_nse)
    provider = build_options_provider()
    assert provider is None


def test_build_context_providers_wires_options_when_enabled() -> None:
    """Default config: use_live_options=True → options slot populated
    when NSEClient is constructible."""
    panel = _enriched_panel(("A",))
    bundle = build_context_providers(
        panel,
        use_live_vix=False, use_live_sector=False,
        use_live_filing=False, use_live_options=True,
    )
    # Options provider built, OR construction failed gracefully — both valid.
    assert bundle.options is None or isinstance(
        bundle.options, OptionsContextProvider
    )


def test_build_context_providers_options_disabled_by_flag() -> None:
    """When use_live_options=False the options slot stays None even if
    NSEClient would have constructed cleanly."""
    panel = _enriched_panel(("A",))
    bundle = build_context_providers(
        panel,
        use_live_vix=False, use_live_sector=False,
        use_live_filing=False, use_live_options=False,
    )
    assert bundle.options is None


def test_build_context_providers_options_independent_of_other_toggles() -> None:
    """Sector + filing + options toggles don't interfere with each other.
    Enabling sector doesn't force-enable options, disabling options
    doesn't disable filing, and so on."""
    panel = _enriched_panel(("A",))
    uni = Universe(
        symbols={"A": SymbolMeta(symbol="A", sector="Banking")},
        built_at=pd.Timestamp("2024-01-01"),
    )
    bundle = build_context_providers(
        panel, universe=uni,
        use_live_vix=False, use_live_sector=True,
        use_live_filing=False, use_live_options=False,
    )
    assert bundle.sector is not None
    assert bundle.filing is None
    assert bundle.options is None
