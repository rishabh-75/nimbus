"""nimbus_v3.compute.industry_seasonality — month × industry grid.

Stateless. For each industry, builds an ADTV-weighted composite price
series over FULL available history (not the rotation 60-day window —
seasonality needs years), then runs the per-symbol seasonality compute
on that composite. The result is a grid the heatmap renders: one row per
industry, 12 month columns, cell = average monthly return.

Composite-first (matching the rotation engine's philosophy): the
industry is treated as one ADTV-weighted entity, so a small illiquid
member can't distort the industry's seasonal read.

Honesty about history depth: seasonality needs multiple years to mean
anything (``seasonality.MIN_YEARS``). Industries whose composite has
fewer years are returned with ``has_data=False`` and their cells should
be greyed out by the renderer rather than painted as confident signal.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from nimbus_v3.compute.indicators import adtv_latest
from nimbus_v3.compute.industry_composite import build_industry_composite
from nimbus_v3.compute.industry_rotation import MIN_MEMBERS
from nimbus_v3.compute.seasonality import (
    MIN_YEARS,
    compute_seasonality,
)


@dataclass(frozen=True)
class IndustrySeasonality:
    """One industry's monthly seasonality row."""

    industry: str
    #: 12 average monthly returns (%, Jan..Dec); NaN where no data.
    avg_returns: tuple[float, ...]
    #: 12 hit rates (% years positive, Jan..Dec); NaN where no data.
    hit_rates: tuple[float, ...]
    #: 12 dispersions (std of monthly returns across years, %); NaN where
    #: fewer than 2 observations.
    std_returns: tuple[float, ...]
    n_years: int
    n_members: int
    has_data: bool


@dataclass(frozen=True)
class SeasonalityGrid:
    """All industries' monthly seasonality, ready for a heatmap."""

    rows: tuple[IndustrySeasonality, ...]
    #: Per-month cross-industry average return (%, Jan..Dec) over the
    #: industries that have data — the "market-wide" seasonal baseline.
    #: The Relative-to-market view subtracts this from each cell so the
    #: uniform market pattern cancels and only industry-specific
    #: seasonality remains. NaN for a month no industry has data for.
    market_baseline: tuple[float, ...] = (float("nan"),) * 12

    @property
    def has_data(self) -> bool:
        return any(r.has_data for r in self.rows)


@dataclass(frozen=True)
class MemberContribution:
    """One member's contribution to a single (industry, month) cell."""

    symbol: str
    weight: float              # ADTV weight within the industry (0..1)
    member_avg: float          # member's own avg return for that month, %
    member_std: float          # member's own dispersion that month, %
    member_hit: float          # member's own hit rate that month, %
    #: weight × member_avg — the member's additive share of the industry's
    #: composite avg return for the month (sums ≈ the cell magnitude).
    magnitude_contribution: float
    #: Signed reliability impact: positive = this member STEADIES the cell
    #: (consistent, low own-dispersion), negative = this member is an
    #: outlier source DRAGGING reliability down (erratic that month).
    reliability_impact: float
    n_years: int
    #: Compact human-readable caveat for this member's stats — the
    #: subtlety the raw numbers don't make obvious (thin sample, erratic,
    #: steady, outlier-driven, etc.). Computed in the engine so the UI
    #: just renders it.
    remark: str = ""


@dataclass(frozen=True)
class CellContribution:
    """Decomposition of one (industry, month) cell into member impacts."""

    industry: str
    month: int                 # 1..12
    cell_avg: float            # the industry cell's avg return (%)
    cell_reliability: float    # the cell's reliability score (0..1)
    members: tuple[MemberContribution, ...]

    @property
    def has_data(self) -> bool:
        return len(self.members) > 0


def compute_cell_contributions(
    industry: str,
    month: int,
    members: list[str],
    panel: dict[str, pd.DataFrame],
) -> CellContribution:
    """Decompose an (industry, month) seasonality cell into the member
    symbols that drive its magnitude and reliability.

    Magnitude is additive: each member contributes ``weight × its own
    average return for that month``, and these sum to (approximately) the
    industry composite's average for the month. Reliability impact is a
    signed read of whether a member steadies the cell (consistent in that
    month) or is the outlier source inflating one year — a member can be
    the top magnitude contributor while being the worst for reliability.

    Args:
        industry: industry name (for labelling).
        month: calendar month, 1..12.
        members: member symbols.
        panel: ``{symbol: enriched_df}``.
    """
    raw: list[tuple[str, float, pd.Series]] = []
    for sym in members:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        s = df["Close"].dropna()
        if len(s) < 2:
            continue
        adtv = adtv_latest(df)
        w = adtv if (adtv == adtv and adtv > 0) else 0.0
        raw.append((sym, w, s))

    if not raw:
        return CellContribution(industry, month, float("nan"),
                                float("nan"), ())

    wsum = sum(w for _, w, _ in raw)
    if wsum <= 0:
        eq = 1.0 / len(raw)
        weights = {sym: eq for sym, _, _ in raw}
    else:
        weights = {sym: w / wsum for sym, w, _ in raw}

    mi = month - 1
    contribs: list[MemberContribution] = []
    cell_avg_acc = 0.0
    for sym, _, close in raw:
        res = compute_seasonality(close)
        stat = res.months[mi]
        avg = stat.avg_return
        std = stat.std_return
        hit = stat.hit_rate
        w = weights[sym]
        mag_contrib = (w * avg) if avg == avg else float("nan")
        if mag_contrib == mag_contrib:
            cell_avg_acc += mag_contrib

        own_rel = _member_reliability(avg, std)
        # Centre at 0.5: above → steadying, below → destabilising; scale
        # by weight so trivial members don't dominate the read.
        reliability_impact = w * (own_rel - 0.5) * 2.0 \
            if own_rel == own_rel else float("nan")

        contribs.append(MemberContribution(
            symbol=sym,
            weight=w,
            member_avg=avg,
            member_std=std,
            member_hit=hit,
            magnitude_contribution=mag_contrib,
            reliability_impact=reliability_impact,
            n_years=stat.n_years,
            remark=_member_remark(avg, std, hit, w, mag_contrib,
                                  reliability_impact, stat.n_years),
        ))

    # Default sort: biggest movers first, by absolute magnitude share.
    contribs.sort(
        key=lambda c: (abs(c.magnitude_contribution)
                       if c.magnitude_contribution == c.magnitude_contribution
                       else -1.0),
        reverse=True)

    return CellContribution(
        industry=industry, month=month,
        cell_avg=cell_avg_acc if contribs else float("nan"),
        cell_reliability=float("nan"),
        members=tuple(contribs))


def _member_remark(avg: float, std: float, hit: float, weight: float,
                   mag: float, rel_impact: float, n_years: int) -> str:
    """A compact caveat string for a member's seasonal stats — the
    subtlety the raw numbers don't make obvious. Priority: sample size
    first (it invalidates everything else), then the magnitude/dispersion
    character. Returns '' when nothing notable stands out."""
    if avg != avg:
        return "no data this month"
    # Sample size dominates — a great-looking stat off 1-2 years is noise.
    if n_years <= 1:
        return "single year — not a pattern"
    if n_years == 2:
        return "only 2 yrs — thin sample"

    big_weight = weight >= 0.15
    dominant = weight >= 0.35
    strong_mag = abs(mag) >= 1.0
    # Dispersion relative to the move: >1 means the year-to-year swing is
    # bigger than the average itself (lumpy); <0.4 means tight/consistent.
    noisy = (std == std and abs(avg) > 1e-9 and std / abs(avg) >= 1.0)
    tight = (std == std and abs(avg) > 1e-9 and std / abs(avg) <= 0.4)
    moderate_disp = (std == std and abs(avg) > 1e-9
                     and 0.4 < std / abs(avg) < 1.0)
    steady_hit = hit == hit and hit >= 80
    perfect_hit = hit == hit and hit >= 100
    steadies = rel_impact == rel_impact and rel_impact > 0.02

    # The most useful flags, in order of what an operator cares about.
    if strong_mag and rel_impact == rel_impact and rel_impact < 0:
        return "drives the number but destabilises it"
    if big_weight and noisy:
        return "heavyweight but erratic — watch"
    if noisy:
        return "lumpy — high yr-to-yr swing"
    # The cell's ANCHOR: a dominant-weight member that also steadies the
    # cell (positive reliability impact) and isn't a loss. This is the
    # most important row — recognise it explicitly rather than leaving it
    # blank just because its dispersion sits in the middle band.
    if dominant and avg >= 0 and steadies:
        return "anchor — drives & steadies"
    # Tight dispersion = a dependable PATTERN — but the sign decides
    # whether that pattern is a tailwind (good) or a headwind (a reliable
    # drag you'd want to avoid that month). "Consistent" must never read
    # as reassuring when the consistent thing is a loss.
    if tight and avg >= 0:
        return "steady & dependable" if steady_hit else "consistent gain"
    if tight and avg < 0:
        return ("reliably weak — steady drag" if (hit == hit and hit <= 20)
                else "consistently negative")
    # Up EVERY year (perfect hit) with positive return — dependable even
    # if the magnitude is modest and the dispersion only moderate.
    if perfect_hit and avg > 0:
        return "up every year — dependable"
    if avg < 0:
        return "seasonal drag"
    if 0 < abs(mag) < 0.2:
        return "minor contributor"
    # In-between: positive, moderate everything, nothing extreme. Name it
    # so a BLANK remark only ever means genuinely unremarkable.
    if avg > 0 and moderate_disp:
        return "solid — moderate swing" if steadies else "moderate, mixed"
    return ""


def _member_reliability(avg: float, std: float) -> float:
    """|mean|/std mapped 0..1 (same SNR idea the heatmap uses), for a
    single member's month. NaN when std is undefined."""
    if avg != avg or std != std:
        return float("nan")
    if std <= 1e-9:
        return 1.0
    return max(0.0, min(1.0, (abs(avg) / std) / 2.0))


def _composite_close(
    members: list[str],
    panel: dict[str, pd.DataFrame],
) -> tuple[pd.Series | None, int]:
    """ADTV-weighted composite close over FULL history. Returns
    (series, n_members_used). None when too few usable members.

    Thin wrapper over the shared ``build_industry_composite`` (full
    history, MIN_YEARS-agnostic; seasonality needs every year available).
    """
    composite, member_weights = build_industry_composite(
        members, panel, min_members=MIN_MEMBERS, min_bars=2, lookback=None)
    if composite is None:
        return None, 0
    return composite, len(member_weights)


def compute_industry_seasonality(
    members_by_industry: dict[str, list[str]],
    panel: dict[str, pd.DataFrame],
) -> SeasonalityGrid:
    """Build the month × industry seasonality grid.

    Args:
        members_by_industry: ``{industry: [symbols]}`` — same grouping
            the Industries table and rotation engine use.
        panel: ``{symbol: enriched_df}``.

    Returns:
        A :class:`SeasonalityGrid`; rows sorted by data-availability then
        name so populated industries surface first.
    """
    rows: list[IndustrySeasonality] = []

    for industry, members in members_by_industry.items():
        if industry in ("ALL", "Unknown", ""):
            continue
        comp, n_members = _composite_close(members, panel)
        if comp is None:
            continue
        result = compute_seasonality(comp)
        avg = tuple(m.avg_return for m in result.months)
        hit = tuple(m.hit_rate for m in result.months)
        std = tuple(m.std_return for m in result.months)
        rows.append(IndustrySeasonality(
            industry=industry,
            avg_returns=avg,
            hit_rates=hit,
            std_returns=std,
            n_years=result.n_years,
            n_members=n_members,
            has_data=result.has_data,
        ))

    # Populated industries first, then alphabetical.
    rows.sort(key=lambda r: (not r.has_data, r.industry))

    # Per-month market baseline = mean of each month's avg return across
    # the industries that HAVE data. The Relative-to-market view nets
    # this out so only industry-specific seasonality remains.
    baseline: list[float] = []
    data_rows = [r for r in rows if r.has_data]
    for m in range(12):
        vals = [r.avg_returns[m] for r in data_rows
                if r.avg_returns[m] == r.avg_returns[m]]
        baseline.append(float(np.mean(vals)) if vals else float("nan"))

    return SeasonalityGrid(
        rows=tuple(rows), market_baseline=tuple(baseline))
