# BB Ride Initiation Research

Research thread: does the **Bollinger Band ride initiation pattern**
predict above-baseline forward returns at fwd_5d / fwd_10d /
fwd_20d horizons?

## Status: Research negative; shipped as a SCREENER (not validated alpha)

### What the walk-forward research showed

Run on 2026-04-27 across the full NIFTY 500 panel (2021-2026), 4
walk-forward folds with 10-bar purge, three nested definitions
(A/B/C), three forward horizons (5d/10d/20d).

**Verdict: NO SHIP.** No (definition, horizon) cell cleared the
laddered ship rule. Every single one of 9 cells produced
*slightly negative* mean test lift across folds.

| Cell | Mean test lift | Sign agreement |
|---|---|---|
| A × 5d | -0.20pp | 50% |
| A × 10d | -0.49pp | 75% |
| A × 20d | -0.40pp | 50% |
| B × 5d | -0.27pp | 75% |
| B × 10d | -0.30pp | 75% |
| B × 20d | -0.53pp | 50% |
| C × 5d | -0.29pp | 75% |
| C × 10d | -0.25pp | 75% |
| C × 20d | -0.48pp | 75% |

A clean negative result. Verdict file: `run_2026_04_27_walk_forward_verdict.txt`

### Key observation: signal decay

Both train and test lifts deteriorate monotonically across folds:
- Fold 1 (2018-2021 train): mostly positive, including +1.69 to +2.28pp on Definition A train sets
- Fold 4 (through 2025-2026): mostly negative, with worst test lifts approaching -1pp

Interpretation: the pattern likely had real edge in early-2020s
post-COVID NSE rallies, then inverted as the regime shifted
(2024 election volatility, 2025 Trump tariff corrections).
Pattern-recognition signals are notoriously regime-dependent;
this is consistent with that pattern.

### Honest disposition: shipped as a SCREENER, not a tag

After the negative walk-forward, the operator pivoted from
"validated alpha tag" to "screener for manual review." The
explicit framing: surface symbols where the visual pattern is
firing right now, so the operator can pull up charts and decide
manually. No predictive edge claim.

The shipped product:
- New **RIDE** column on Market Pulse constituent and group tables
- Active marker (✓) when the screener fires; em-dash otherwise
- **Neutral coloring** (white ✓ / muted em-dash) — no green/red
  that would imply bullishness
- **Header tooltip explicitly discloses** that this is a screener,
  not a validated forward-return signal
- **Not integrated** into composite or conviction scoring

### Operator-defined criteria (post-research, calibrated to charts)

Operator reviewed 4 positive examples (MOSCHIP, DATAPATTNS,
TATACONSUM, BEML) and 4 problem examples (KIRLOSENG, TITAN, ONGC,
HINDALCO) and identified three failure modes that needed mechanical
filters:

1. **Detached breakout** (KIRLOSENG/TITAN): cross bar closes far
   above upper BB, not riding. Filter: bound close's %B and
   open's %B (see "Detached check evolution" below).
2. **Single-bar gap-through** (ONGC): cross bar opens below SMA20
   and closes above upper. Filter: suppress if open at cross bar
   was below SMA20.
3. **Ride didn't materialize** (HINDALCO): fire but next bars
   drop back below SMA20. Filter: kill switch — turn off active
   flag if close drops below SMA20 within active window.

### Detached check evolution (transparent post-hoc tuning)

The detached check went through three iterations across calibration
runs. Each iteration documents what changed and the methodological
status of that change:

**v1 — Absolute % above upper (DETACHED_PCT = 2%)**
- Set initially based on operator inspection of failure-mode charts.
- Calibration check: 0/4 positive examples fired.
- Diagnosis: 2% threshold rejected legitimate vigorous breakouts
  (DATAPATTNS bar 04-16 closed 4.06% above upper).

**v2 — %B-based ceiling (DETACHED_PCTB_MAX = 1.5)**
- STRUCTURAL change: replaced absolute % with %B for volatility
  adaptivity. Methodologically defensible — different abstraction,
  not threshold tuning.
- Plus structural change to fresh-cross criterion: switched from
  "close above upper" to "body above" (Open > upper AND Close >
  upper). Filters momentum bars that close above but open below.
- Calibration check: still 0/4 positive examples fired.
- Diagnosis: legitimate ride bars sit at %B 1.5-1.7, just above
  the 1.5 ceiling.

**v3 — Dual-bound %B (DETACHED_PCTB_MAX = 1.7, OPEN ∈ [1.0, 1.5])**
- HONEST DISCLOSURE: the 1.7 close ceiling is post-hoc parameter
  tuning. Operator inspected per-bar values on legitimate ride-
  init bars, observed close %B clusters in 1.5-1.7 during BBW-
  expanding breakouts, set ceiling at 1.7 to capture them. This
  is methodologically equivalent to overfitting.
- The OPEN ∈ [1.0, 1.5] check is STRUCTURAL: discriminates
  open-in-zone from gap-up open. Two different patterns (vigorous
  push from band start vs gap detached at open). The numeric
  bounds are defensible because they encode the categorical
  distinction.
- The screener's classification (screener for manual review, NOT
  validated alpha) reflects this — these are calibration-tuned
  parameters, not validated thresholds.

Plus operator feedback on parameter tuning (relative to the
20-bar lookbacks in original research): "lookback windows are too
high, slope changes sharply" → reduced to 10-bar cross lookback,
5-bar slope/BBW lookbacks. Then "10 still too high" → reduced
further to CROSS_LOOKBACK = 5.

These calibrations are NOT walk-forward validated. They tune the
screener to match the operator's visual pattern recognition. The
deliverable is a UI tool, not an edge claim. **A subsequent
walk-forward run on these calibrated parameters would be a
methodological loop — calibration data was used to set the
parameters, so re-validating on the same data is circular.**

### Implementation

- `nimbus_v3/compute/ride_initiation.py` — pure compute module.
  `compute_ride_init_active(df)` → bool Series.
  `compute_ride_init_active_industry(members_panel)` → industry-level.
- `tests/compute/test_ride_initiation.py` — 20 tests covering all
  3 failure modes, body-above semantics, %B-based detached check,
  edge cases, schema hash.
- `tests/ui/test_market_context_tab_ride.py` — 9 tests covering
  column presence, position, header tooltip honesty.
- Tooltip text in `nimbus_v3/ui/widgets/market_context_tab.py`
  as `_RIDE_TOOLTIP` constant.

### How to revisit

If this thread is reopened in the future:

1. **Rerun walk-forward with the operator-calibrated parameters**
   (the lookbacks were shortened during screener calibration). It's
   POSSIBLE the shorter parameters surface signal that the longer
   ones smoothed away. Low prior, but not implausible.
2. **Test conditional edge**: maybe the pattern works when
   conditioned on regime — e.g., RIDE active during VIX:STABLE
   AND CORR:LOW (orderly rally) might survive walk-forward where
   the unconditional version doesn't.

But the screener stands on its own without further research —
operator finds it useful for visual chart selection, and that's
the legitimate use case.

## Methodology of the original research (for reference)

1. Compute three nested signal definitions per (symbol, bar):
   - A: cross + hold (loosest)
   - B: A fired in last 5 bars AND slope acceleration now
   - C: B fires AND BBW expanding now
2. Active-signal window: signal "operationally visible" for 5
   bars after firing
3. For each (definition, horizon, fold): pool fwd returns from
   active bars; measure lift vs universe baseline
4. Walk-forward 4 expanding folds with 10-bar purge

## Ship rules (locked before run, all failed)

| Horizon | Lift threshold | Sign agreement |
|---|---|---|
| fwd_5d | ≥ 0.5pp | ≥ 75% folds |
| fwd_10d | ≥ 1.0pp | ≥ 75% folds |
| fwd_20d | ≥ 1.5pp | ≥ 75% folds |

Stricter than VIX/CORR (0.5pp uniform) because ride-init claims a
directional pattern, not a regime.
