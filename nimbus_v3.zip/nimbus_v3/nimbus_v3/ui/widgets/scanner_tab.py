"""nimbus_v3.ui.widgets.scanner_tab — self-contained scan terminal.

Architecture (SOLID):
  S — ScannerTab owns UI; DualScanWorker owns computation.
  O — Column definitions are data-driven tuples, easy to extend.
  L — Worker follows QThread contract (run/cancel).
  I — Two narrow signals: symbol_selected(str), row_double_clicked(str).
  D — Depends on Scanner abstraction + ScanInputFn, not concrete loaders.

Layout:
  ┌─────────────────────────────────────────────────┐
  │ ▶ SCAN │ UNIVERSE ▼ │           │ TOP [10] │ EXP│  ← control bar
  ├─────────────────────────────────────────────────┤
  │ ▌MEAN REVERSION              3 entries / 170   │  ← MR header
  │ Symbol │ Price │ Chg% │ WR │ MFI │ Grade │ ... │  ← MR table
  ├─────────────────────────────────────────────────┤
  │ ▌BB RIDE MOMENTUM            1 entry / 170     │  ← Ride header
  │ Symbol │ Price │ Chg% │ %B │ ADX │ Grade │ ... │  ← Ride table
  └─────────────────────────────────────────────────┘
"""
from __future__ import annotations

import logging
import time
from enum import Enum
from typing import Callable, Final

import pandas as pd
from PyQt6.QtCore import QThread, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QComboBox, QFileDialog, QFrame, QHBoxLayout,
    QHeaderView, QLabel, QProgressBar, QPushButton, QSpinBox,
    QSplitter, QTableView, QVBoxLayout, QWidget,
)

from nimbus_v3.core.types import SetupType
from nimbus_v3.scanner.engine import ScanResult, ScanSnapshot, Scanner
from nimbus_v3.ui.theme import (
    BG, BLUE, BORDER, EM, FONT_MONO, GOLD, GREEN,
    MUTED, RED, SURFACE, VIOLET, WHITE,
    grade_fg, sizing_fg, verdict_fg,
)

logger = logging.getLogger(__name__)

# Type alias: returns (enriched_panel, asof_date, scanner).
ScanInputFn = Callable[[], tuple[dict[str, pd.DataFrame], pd.Timestamp, "Scanner"]]


# ══════════════════════════════════════════════════════════════════════════════
# Column definitions — data-driven, easy to extend
# ══════════════════════════════════════════════════════════════════════════════

_ColDef = tuple[str, str, int]   # (header, key, width)

# ──────────────────────────────────────────────────────────────────────────
# Column layouts — width sizing discipline:
#   * # (rank)   35px — just enough for 3-digit rank
#   * Verdict    60px — longest token is "AVOID" at 5 chars
#   * Grade      45px — "A+"/"B-"/"D" all fit with padding
#   * Sizing     55px — "FULL"/"HALF"/"SKIP"
#   * Score/num  45-65px — 2-3 sig figs in mono
# Total ~640px for MR, ~665px for Ride. Header stretch is disabled so
# the tables scroll horizontally instead of distorting a column.
# ──────────────────────────────────────────────────────────────────────────

_MR_COLUMNS: Final[tuple[_ColDef, ...]] = (
    ("#",       "rank",         40),
    ("Symbol",  "symbol",      105),
    ("Price",   "close_price",  85),
    ("Grade",   "grade",        55),
    ("Verdict", "verdict",      72),
    ("Sizing",  "sizing",       64),
    ("Score",   "score",        60),
    ("WR",      "wr_30",        54),
    ("MFI",     "mfi_14",       54),
    ("vs SMA",  "pct_sma",      74),
    ("ADX",     "adx_14",       54),
    ("Vol",     "vol_ratio",    54),
)

_RIDE_COLUMNS: Final[tuple[_ColDef, ...]] = (
    ("#",       "rank",         40),
    ("Symbol",  "symbol",      105),
    ("Price",   "close_price",  85),
    ("Grade",   "grade",        55),
    ("Verdict", "verdict",      72),
    ("Sizing",  "sizing",       64),
    ("%B",      "bb_pct",       60),
    ("ADX",     "adx_14",       54),
    ("Vol",     "vol_ratio",    54),
    ("Streak",  "green_streak", 64),
)


# ══════════════════════════════════════════════════════════════════════════════
# Research-tier columns — strategies with production_weight=0 fire into a
# separate collapsible table so they don't pollute the production MR/Ride
# tables with synthetic D/WATCH/SKIP rows. No Grade/Verdict/Sizing columns
# because those are forced constants by the research-only override path
# (grade=D, verdict=WATCH, sizing=SKIP for every row) — showing them would
# be noise. The Strategy column identifies which research strategy fired.
# ──────────────────────────────────────────────────────────────────────────

_RESEARCH_COLUMNS: Final[tuple[_ColDef, ...]] = (
    ("#",        "rank",          40),
    ("Symbol",   "symbol",       105),
    ("Price",    "close_price",   85),
    ("Strategy", "strategy_name",150),
    ("WR",       "wr_30",         54),
    ("MFI",      "mfi_14",        54),
    ("vs SMA",   "pct_sma",       74),
    ("ADX",      "adx_14",        54),
    ("Vol",      "vol_ratio",     54),
    ("Streak",   "red_streak",    64),
)


# ══════════════════════════════════════════════════════════════════════════════
# Row-bucket classification — single source of truth for which table a
# ScanResult lands in. Keys on ``SetupType`` (the semantic setup category
# carried on every signal) rather than ``strategy_name`` strings, which
# means both conservative and aggressive strategy families route the
# same way:
#
#   MeanReversion            ─┐
#   AggressiveMeanReversion  ─┴─→ SetupType.MEAN_REVERSION → _RowBucket.MR
#
#   Ride                     ─┐
#   AggressiveRide           ─┴─→ SetupType.RIDE           → _RowBucket.RIDE
#
#   Breakout / PullbackUptrend / DrawdownReversal / ETFMomentum
#                              → various                   → _RowBucket.RESEARCH
#
#   Trap                       → SetupType.TRAP            → _RowBucket.TRAP
#
# Any future mode (or custom strategy) that emits a signal with one of
# these SetupType values will route correctly without changing this
# module. Use this classifier from every routing site; never duplicate
# the if/elif chain.
# ──────────────────────────────────────────────────────────────────────────

class _RowBucket(Enum):
    """Target table for a given ScanResult."""
    MR = "mr"           # Mean-reversion table
    RIDE = "ride"       # BB Ride table
    TRAP = "trap"       # TRAP override — counted in footer only
    RESEARCH = "research"   # Research Monitor collapsible section


def _classify_result(r: ScanResult) -> _RowBucket:
    """Route a ScanResult to its display bucket.

    Classification is by ``SetupType`` (not by strategy name) so
    the routing is mode-agnostic. See the _RowBucket module-level
    comment for the full mapping.
    """
    setup = r.conviction.setup_type
    if setup == SetupType.MEAN_REVERSION:
        return _RowBucket.MR
    if setup == SetupType.RIDE:
        return _RowBucket.RIDE
    if setup == SetupType.TRAP:
        return _RowBucket.TRAP
    return _RowBucket.RESEARCH


# ══════════════════════════════════════════════════════════════════════════════
# Worker — runs scan in background thread
# ══════════════════════════════════════════════════════════════════════════════

class _ScanWorker(QThread):
    """Runs the full scan pipeline off the main thread.

    ``scan_input_fn`` returns ``(enriched_panel, asof, scanner)``
    — the scanner may be freshly created on first call (lazy init).
    ``universe_name`` optionally scopes the scan to one NIFTY index
    (e.g. ``"NIFTY 50"``, ``"NIFTY BANK"``); ``None`` or an unknown
    name runs the full universe. Resolution happens on this thread
    so the UI doesn't block while we slice.
    """
    progress = pyqtSignal(int, int, str)       # done, total, symbol
    finished = pyqtSignal(object)              # ScanSnapshot
    error = pyqtSignal(str)
    #: Emitted per firing symbol during the scan. Payload is a 2-tuple
    #: of (list[ScanResult], SignalState | None). UI routes these to
    #: the appropriate table model so rows appear live instead of all
    #: dumping at finish.
    result_ready = pyqtSignal(object)

    def __init__(
        self,
        scan_input_fn: ScanInputFn,
        universe_name: str | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self._scan_input_fn = scan_input_fn
        self._universe_name = universe_name
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        logger.info("ScanWorker: starting scan_input_fn...")
        try:
            enriched_panel, asof_date, scanner = self._scan_input_fn()
            logger.info("ScanWorker: scan_input_fn OK — %d symbols, asof=%s",
                        len(enriched_panel), asof_date)
        except Exception as exc:
            logger.exception("ScanWorker: scan_input_fn FAILED")
            self.error.emit(f"Scan input failed: {exc}")
            return

        # Progress callback marshals engine-thread updates onto the
        # worker's Qt signal, which is then delivered to the UI thread.
        # Guarded against cancellation so a stopped scan stops reporting.
        def _on_progress(done: int, total: int, symbol: str) -> None:
            if self._cancelled:
                return
            self.progress.emit(done, total, symbol)

        # Per-symbol result callback — fires live as each symbol
        # produces signals. Same cancellation guard. Emits a 2-tuple
        # because pyqtSignal(object) delivers a single payload; the
        # UI handler unpacks.
        def _on_result(symbol_results, state) -> None:
            if self._cancelled:
                return
            self.result_ready.emit((symbol_results, state))

        # Resolve the universe slice — only if the caller named one and
        # the scanner exposes a universe to slice against. If the slice
        # returns empty *and* the caller asked for NIFTY 50, fall back
        # to the hardcoded constituent list rather than silently
        # scanning the full panel. Intersection with the enriched_panel
        # happens inside scan_with_snapshot via _resolve_symbols, so
        # non-tradable fallback symbols get dropped gracefully.
        symbols: list[str] | None = None
        fallback_used = False
        if self._universe_name:
            try:
                universe = getattr(scanner, "universe", None)
                if universe is not None:
                    subset = universe.slice(self._universe_name)
                    if subset:
                        symbols = subset
                        logger.info("ScanWorker: universe %r → %d symbols",
                                    self._universe_name, len(subset))
                    elif self._universe_name == "NIFTY 50":
                        symbols = sorted(_NIFTY_50_FALLBACK)
                        fallback_used = True
                        logger.info(
                            "ScanWorker: universe.slice('NIFTY 50') empty — "
                            "using hardcoded constituent fallback (%d symbols)",
                            len(symbols),
                        )
                    else:
                        logger.info(
                            "ScanWorker: universe %r empty, no fallback — "
                            "scanning full panel", self._universe_name,
                        )
            except Exception:
                logger.exception("ScanWorker: universe slice failed — "
                                 "scanning full panel")

        # Stash the fallback flag on the worker so _on_scan_done can
        # annotate the footer — a scan run with the hardcoded NIFTY 50
        # list is worth flagging so the operator knows the universe
        # DB is missing metadata and some tickers may not trade yet.
        self._fallback_used = fallback_used

        try:
            logger.info("ScanWorker: starting scan_with_snapshot...")
            snapshot = scanner.scan_with_snapshot(
                enriched_panel=enriched_panel,
                asof_date=asof_date,
                symbols=symbols,
                progress_callback=_on_progress,
                result_callback=_on_result,
            )
            logger.info("ScanWorker: scan done — %d results", len(snapshot.results))
            if not self._cancelled:
                self.finished.emit(snapshot)
        except Exception as exc:
            logger.exception("ScanWorker: scan FAILED")
            self.error.emit(f"Scan failed: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
# Row extraction — convert ScanResult + SignalState to flat dict for tables
# ══════════════════════════════════════════════════════════════════════════════

def _mr_row(r: ScanResult, state) -> dict:
    """Flatten a MR ScanResult into a display dict."""
    c = r.conviction
    pct_sma = (
        (state.close / state.sma_20 - 1) * 100
        if state and state.sma_20 > 0 else 0.0
    )
    # vol_ratio_20 is today's volume / 20-day average, pre-computed
    # in compute.engine.enrich and carried through SignalState. The
    # previous impl dereferenced a non-existent avg_volume_20 attr
    # and silently fell through to 0.0 for every row.
    vol_ratio = float(getattr(state, "vol_ratio_20", 0.0) or 0.0) if state else 0.0
    return {
        "symbol": r.symbol,
        "close_price": r.close_price,
        "grade": c.grade.value,
        "verdict": c.verdict.value,
        "sizing": c.sizing.value,
        "score": round(c.score, 2),
        "wr_30": round(state.wr_30, 0) if state else 0,
        "mfi_14": round(state.mfi_14, 0) if state else 0,
        "pct_sma": round(pct_sma, 1),
        "adx_14": round(state.adx_14, 0) if state else 0,
        "vol_ratio": round(vol_ratio, 1),
        "_result": r,
    }


def _ride_row(r: ScanResult, state) -> dict:
    """Flatten a Ride ScanResult into a display dict."""
    c = r.conviction
    bb_pct = 0.0
    if state and state.bb_20_1s_upper != state.bb_20_1s_lower:
        bb_pct = (state.close - state.bb_20_1s_lower) / (
            state.bb_20_1s_upper - state.bb_20_1s_lower
        )
    return {
        "symbol": r.symbol,
        "close_price": r.close_price,
        "grade": c.grade.value,
        "verdict": c.verdict.value,
        "sizing": c.sizing.value,
        "bb_pct": round(bb_pct, 2),
        "adx_14": round(state.adx_14, 0) if state else 0,
        "vol_ratio": round(
            float(getattr(state, "vol_ratio_20", 0.0) or 0.0), 1
        ) if state else 0.0,
        "green_streak": state.green_streak if state else 0,
        "_result": r,
    }


def _research_row(r: ScanResult, state) -> dict:
    """Flatten a research-tier ScanResult into a display dict.

    Research tier = ``production_weight == 0`` strategies (Pullback,
    Drawdown, Breakout, ETFMomentum). The conviction engine forces
    these through the research-only override path, so grade / verdict
    / sizing are always D/WATCH/SKIP and carry no information — they
    are intentionally omitted from the row dict to keep the display
    honest.
    """
    pct_sma = (
        (state.close / state.sma_20 - 1) * 100
        if state and state.sma_20 > 0 else 0.0
    )
    vol_ratio = float(getattr(state, "vol_ratio_20", 0.0) or 0.0) if state else 0.0
    return {
        "symbol": r.symbol,
        "close_price": r.close_price,
        "strategy_name": r.conviction.strategy_name,
        "wr_30": round(state.wr_30, 0) if state else 0,
        "mfi_14": round(state.mfi_14, 0) if state else 0,
        "pct_sma": round(pct_sma, 1),
        "adx_14": round(state.adx_14, 0) if state else 0,
        "vol_ratio": round(vol_ratio, 1),
        "red_streak": state.red_streak if state else 0,
        "_result": r,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Generic table model — parameterised by column definitions
# ══════════════════════════════════════════════════════════════════════════════

from PyQt6.QtCore import QAbstractTableModel, QModelIndex


class _ScanTableModel(QAbstractTableModel):
    """Generic table model driven by column definitions."""

    def __init__(self, columns: tuple[_ColDef, ...], parent=None):
        super().__init__(parent)
        self._cols = columns
        self._data: list[dict] = []

    def set_data(self, rows: list[dict]):
        self.beginResetModel()
        self._data = list(rows)
        self.endResetModel()

    def clear(self):
        self.beginResetModel()
        self._data = []
        self.endResetModel()

    def row_data(self, idx: int) -> dict | None:
        return self._data[idx] if 0 <= idx < len(self._data) else None

    def rowCount(self, parent=QModelIndex()):
        return len(self._data)

    def columnCount(self, parent=QModelIndex()):
        return len(self._cols)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self._cols[section][0]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row = self._data[index.row()]
        _, key, _ = self._cols[index.column()]
        val = row.get(key)

        if role == Qt.ItemDataRole.DisplayRole:
            if val is None:
                return "—"
            if key == "rank" and isinstance(val, (int, float)):
                return f"{int(val)}"
            if key == "close_price":
                return f"{val:,.2f}"
            if key in ("wr_30", "mfi_14", "adx_14") and isinstance(val, (int, float)):
                return f"{val:.0f}"
            if key == "pct_sma" and isinstance(val, (int, float)):
                return f"{val:+.1f}%"
            if key == "vol_ratio" and isinstance(val, (int, float)):
                return f"{val:.1f}x"
            if key == "bb_pct" and isinstance(val, (int, float)):
                return f"{val:.2f}"
            if key == "score" and isinstance(val, (int, float)):
                return f"{val:.1f}"
            if key == "green_streak" and isinstance(val, (int, float)):
                return f"{int(val)}d"
            return str(val)

        if role == Qt.ItemDataRole.ForegroundRole:
            if key == "rank":
                return QBrush(QColor(MUTED))
            if key == "grade":
                return QBrush(QColor(grade_fg(val)))
            if key == "verdict":
                return QBrush(QColor(verdict_fg(val)))
            if key == "sizing":
                return QBrush(QColor(sizing_fg(val)))
            if key == "wr_30" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val < -50 else (GREEN if val < -30 else MUTED)))
            if key == "mfi_14" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 50 else (GREEN if val >= 30 else RED)))
            if key == "pct_sma" and isinstance(val, (int, float)):
                return QBrush(QColor(RED if val < -5 else (GOLD if val < -2 else MUTED)))
            if key == "vol_ratio" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 1.5 else (GREEN if val >= 1.0 else MUTED)))
            if key == "bb_pct" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val >= 1.0 else (GOLD if val >= 0.75 else MUTED)))

        if role == Qt.ItemDataRole.FontRole:
            if key in ("symbol", "grade", "sizing"):
                f = QFont(FONT_MONO, 10)
                f.setBold(True)
                return f
            if key in ("close_price", "wr_30", "mfi_14", "adx_14",
                       "pct_sma", "vol_ratio", "bb_pct", "score"):
                return QFont(FONT_MONO, 10)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if key not in ("symbol", "verdict", "industry"):
                return Qt.AlignmentFlag.AlignCenter

        if role == Qt.ItemDataRole.UserRole:
            # For sorting.
            if val is None:
                return -9999
            if isinstance(val, (int, float)):
                return float(val)
            return str(val)

        return None


# ══════════════════════════════════════════════════════════════════════════════
# Scanner Tab widget
# ══════════════════════════════════════════════════════════════════════════════

_TABLE_STYLE = (
    f"QTableView {{"
    f"  background: {BG}; alternate-background-color: #0A0E14;"
    f"  gridline-color: transparent; border: none;"
    f"  selection-background-color: rgba(16,185,129,0.08);"
    f"  selection-color: {WHITE};"
    f"}}"
    f"QTableView::item {{ padding: 0px 5px; border-bottom: 1px solid #0C1018; }}"
    f"QTableView::item:selected {{ background: rgba(16,185,129,0.08); }}"
    f"QHeaderView::section {{"
    f"  background: {SURFACE}; color: {MUTED};"
    f"  border: none; border-bottom: 1px solid {BORDER};"
    f"  font-weight: 600; padding: 3px 5px;"
    f"}}"
    f"QScrollBar:vertical {{ background: transparent; width: 5px; }}"
    f"QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 2px; }}"
)
# Fonts are applied imperatively via setFont() in _build_table_section
# so they use pt-based sizing (QFont honours point size + DPI scale)
# rather than CSS px — which stays fixed regardless of display density
# and was the cause of scanner text reading smaller than the macro
# flow tables on retina displays.

_UNIVERSES: Final[tuple[str, ...]] = (
    "NIFTY 50", "NIFTY 100", "NIFTY 200", "NIFTY 500",
    "NIFTY AUTO", "NIFTY BANK", "NIFTY COMMODITIES",
    "NIFTY ENERGY", "NIFTY FIN SERVICE", "NIFTY FMCG",
    "NIFTY HEALTHCARE", "NIFTY INDIA DEFENCE", "NIFTY INFRA",
    "NIFTY IT", "NIFTY METAL", "NIFTY PHARMA",
    "NIFTY PSU BANK", "NIFTY PVT BANK", "NIFTY REALTY",
)


# Hardcoded NIFTY 50 constituent list — used as a fallback when the
# loaded :class:`Universe` doesn't carry index-membership metadata
# (which happens when ``build_universe_with_sectors`` runs without
# a live NSE connection and the industry DB lacks ``indices`` sets
# per symbol). These 50 blue chips form the operator's triage core
# and the list is stable enough that shipping it inline is
# preferable to silently scanning the full panel.
_NIFTY_50_FALLBACK: Final[frozenset[str]] = frozenset({
    "ADANIENT", "ADANIPORTS", "APOLLOHOSP", "ASIANPAINT", "AXISBANK",
    "BAJAJ-AUTO", "BAJAJFINSV", "BAJFINANCE", "BEL", "BHARTIARTL",
    "CIPLA", "COALINDIA", "DRREDDY", "EICHERMOT", "ETERNAL",
    "GRASIM", "HCLTECH", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO",
    "HINDALCO", "HINDUNILVR", "ICICIBANK", "INDUSINDBK", "INFY",
    "ITC", "JIOFIN", "JSWSTEEL", "KOTAKBANK", "LT",
    "LTIM", "M&M", "MARUTI", "NESTLEIND", "NTPC",
    "ONGC", "POWERGRID", "RELIANCE", "SBILIFE", "SBIN",
    "SHRIRAMFIN", "SUNPHARMA", "TATACONSUM", "TATAMOTORS",
    "TATASTEEL", "TCS", "TECHM", "TITAN", "TRENT",
    "ULTRACEMCO", "WIPRO",
})


class ScannerTab(QWidget):
    """Self-contained scanner terminal.

    Public signals:
        symbol_selected(str): single-click row → update sidebar
        row_double_clicked(str): double-click → open in Dashboard
    """

    symbol_selected = pyqtSignal(str)
    row_double_clicked = pyqtSignal(str)
    scan_completed = pyqtSignal(object)   # ScanSnapshot

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._scanner: Scanner | None = None
        self._scan_input_fn: ScanInputFn | None = None
        self._worker: _ScanWorker | None = None
        self._snapshot: ScanSnapshot | None = None
        # Caches so the TOP N filter is reactive — swapping the spinner
        # re-slices these without re-running the scan.
        self._all_mr_rows: list[dict] | None = None
        self._all_ride_rows: list[dict] | None = None
        self._all_research_rows: list[dict] | None = None
        self._last_scan_ts: float | None = None
        # Strategy mode label — shown in the footer so screenshots /
        # exports are self-documenting about which strategy set was
        # active when the scan ran. Set by MainWindow; empty string
        # means "don't annotate" (safe fallback).
        self._strategy_mode_label: str = ""

        # Models.
        self._mr_model = _ScanTableModel(_MR_COLUMNS)
        self._ride_model = _ScanTableModel(_RIDE_COLUMNS)
        self._research_model = _ScanTableModel(_RESEARCH_COLUMNS)

        self._build_ui()

    # ── Dependency injection (called by MainWindow) ───────────────────

    def set_scanner(self, scanner: Scanner, scan_input_fn: ScanInputFn):
        """Wire the scanner + data loader after construction."""
        self._scanner = scanner
        self._scan_input_fn = scan_input_fn

    def set_strategy_mode_label(self, label: str) -> None:
        """Set the strategy-mode annotation shown in the scanner footer.

        Called by ``MainWindow.set_strategy_mode`` whenever the mode
        changes so screenshots / exports of scanner output carry the
        active mode as context. Empty string disables the annotation.
        """
        self._strategy_mode_label = label or ""

    def reset_for_mode_change(self, mode_label: str) -> None:
        """Clear all scan state and prompt the operator to rescan.

        Called from :meth:`MainWindow.set_strategy_mode` after a mode
        swap. The tab owns its own widgets + models, so it should
        also own the logic for clearing them — the previous approach
        (MainWindow reaching into ``_mr_model`` / ``_ride_model`` /
        ``_footer_lbl`` via ``# noqa: SLF001`` pragmas) was an
        encapsulation leak.

        Clears:
          - MR, Ride, and Research table models
          - Cached live-stream row buffers (so a stale partial scan
            doesn't leak through if the operator flips modes mid-scan)
          - Research-count label reverts to muted "no signals"
          - Footer advises "Rescan required" with the new mode label

        Snapshot ownership lives on MainWindow — this method deals
        only with tab-scoped state.
        """
        try:
            self._mr_model.clear()
            self._ride_model.clear()
            self._research_model.clear()
            self._all_mr_rows = None
            self._all_ride_rows = None
            self._all_research_rows = None
            # If a scan is currently streaming rows, the buffers it's
            # appending to would now be stale vs the new mode. Drop
            # them so the next _on_scan_result starts fresh — the
            # worker will still complete its in-flight scan but its
            # rows will be discarded on arrival when _on_run next
            # resets the buffers (or the streaming handler appends
            # harmlessly to a new buffer cleared by the next scan).
            if hasattr(self, "_live_mr_rows"):
                self._live_mr_rows = []
                self._live_ride_rows = []
                self._live_research_rows = []
                self._live_trap_count = 0
            self._research_count_lbl.setText("no signals")
            self._research_count_lbl.setStyleSheet(f"color: {MUTED};")
            self._footer_lbl.setText(
                f"Strategy mode: {mode_label} · "
                f"Rescan required — click SCAN to populate."
            )
        except Exception:    # noqa: BLE001
            logger.exception(
                "ScannerTab.reset_for_mode_change: partial failure — "
                "some tab state may remain stale until next scan"
            )

    @property
    def snapshot(self) -> ScanSnapshot | None:
        return self._snapshot

    # ── UI construction ───────────────────────────────────────────────

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Control bar ───────────────────────────────────────────
        ctrl = QFrame()
        ctrl.setFixedHeight(34)
        ctrl.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-bottom: 1px solid {BORDER}; }}"
            f"QPushButton {{ background: {EM}; color: {BG}; font-weight: bold;"
            f"  border: none; border-radius: 2px; padding: 4px 14px;"
            f"  font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QPushButton:hover {{ background: #34D399; }}"
            f"QPushButton#export {{ background: transparent; color: {MUTED};"
            f"  border: 1px solid {BORDER}; }}"
            f"QComboBox {{ background: {BG}; color: {WHITE}; border: 1px solid {BORDER};"
            f"  border-radius: 2px; padding: 2px 6px; font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QSpinBox {{ background: {BG}; color: {WHITE}; border: 1px solid {BORDER};"
            f"  border-radius: 2px; padding: 2px 4px; font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 9px;"
            f"  background: transparent; border: none; }}"
        )
        cl = QHBoxLayout(ctrl)
        cl.setContentsMargins(8, 0, 8, 0)
        cl.setSpacing(8)

        self._run_btn = QPushButton("▶ SCAN")
        self._run_btn.setFixedSize(80, 24)
        self._run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._run_btn.clicked.connect(self._on_run)
        cl.addWidget(self._run_btn)

        cl.addWidget(QLabel("UNIVERSE"))
        self._universe_combo = QComboBox()
        self._universe_combo.addItems(_UNIVERSES)
        # NIFTY 50 is the default — small enough to triage quickly, big
        # enough to surface the day's setups.  Users still have 200 /
        # 500 / sectoral in the dropdown for broader sweeps.
        self._universe_combo.setCurrentText("NIFTY 50")
        self._universe_combo.setFixedSize(190, 24)
        cl.addWidget(self._universe_combo)

        cl.addStretch(1)

        cl.addWidget(QLabel("TOP"))
        self._topn = QSpinBox()
        self._topn.setRange(0, 100)
        # Default 10 — matches the operator's typical triage window.
        # 0 is the "ALL" special value (spinner shows the literal text).
        self._topn.setValue(10)
        self._topn.setSpecialValueText("ALL")
        self._topn.setFixedSize(50, 24)
        self._topn.setToolTip("Show top N by score (0 = ALL)")
        # Reactive filter — re-apply on every change without requiring
        # a re-scan. The last-completed snapshot is cached on the tab
        # so the filter is just a re-populate of the two table models.
        self._topn.valueChanged.connect(self._on_topn_changed)
        cl.addWidget(self._topn)

        self._export_btn = QPushButton("EXPORT")
        self._export_btn.setObjectName("export")
        self._export_btn.setFixedSize(70, 24)
        self._export_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._export_btn.clicked.connect(self._on_export)
        cl.addWidget(self._export_btn)
        layout.addWidget(ctrl)

        # ── Progress bar ──────────────────────────────────────────
        self._progress_frame = QFrame()
        self._progress_frame.setFixedHeight(18)
        self._progress_frame.setStyleSheet(
            f"QFrame {{ background: {BG}; border-bottom: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 8px;"
            f"  background: transparent; border: none; }}"
            f"QProgressBar {{ background: {BG}; border: none; border-radius: 2px; max-height: 4px; }}"
            f"QProgressBar::chunk {{ background: {EM}; border-radius: 2px; }}"
        )
        pl = QHBoxLayout(self._progress_frame)
        pl.setContentsMargins(8, 0, 8, 0)
        pl.setSpacing(8)
        self._progress = QProgressBar()
        self._progress.setFixedHeight(4)
        self._progress.setTextVisible(False)
        pl.addWidget(self._progress, stretch=1)
        self._progress_lbl = QLabel("")
        pl.addWidget(self._progress_lbl)
        self._progress_frame.setVisible(False)
        layout.addWidget(self._progress_frame)

        # ── Tables in horizontal splitter ─────────────────────────
        # Side-by-side MR + Ride — the prior vertical stack wasted
        # most of the right half of the window on wide displays,
        # especially when Ride was empty. Splitting horizontally
        # puts both datasets in view simultaneously.
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(3)
        splitter.setStyleSheet(
            f"QSplitter::handle {{ background: {SURFACE}; width: 1px; }}"
        )

        # MR table.
        mr_container = self._build_table_section(
            "MEAN REVERSION", GREEN, self._mr_model, _MR_COLUMNS,
        )
        self._mr_table = mr_container.findChild(QTableView)
        splitter.addWidget(mr_container)

        # Ride table.
        ride_container = self._build_table_section(
            "BB RIDE MOMENTUM", BLUE, self._ride_model, _RIDE_COLUMNS,
        )
        self._ride_table = ride_container.findChild(QTableView)
        splitter.addWidget(ride_container)

        splitter.setSizes([520, 520])
        layout.addWidget(splitter, stretch=1)

        # ── Research Monitor section (collapsible, hidden body) ────
        # Fires from weight=0 strategies (Pullback, Drawdown, Breakout,
        # ETFMomentum). Header is always visible with signal count; click
        # toggles body visibility. Lives between the main MR|Ride splitter
        # and the footer so it doesn't steal real estate when collapsed.
        self._research_section = self._build_research_section()
        layout.addWidget(self._research_section)

        # ── Footer ───────────────────────────────────────────────
        footer = QFrame()
        footer.setFixedHeight(20)
        footer.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-top: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 8px;"
            f"  background: transparent; border: none; }}"
        )
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(10, 0, 10, 0)
        fl.addStretch(1)
        self._footer_lbl = QLabel("Ready")
        fl.addWidget(self._footer_lbl)
        layout.addWidget(footer)

    def _build_table_section(
        self, title: str, color: str,
        model: _ScanTableModel, cols: tuple[_ColDef, ...],
    ) -> QWidget:
        """Build a header + table container."""
        container = QWidget()
        container.setStyleSheet(f"background: {BG};")
        vl = QVBoxLayout(container)
        vl.setContentsMargins(0, 0, 0, 0)
        vl.setSpacing(0)

        # Section header.
        hdr = QFrame()
        hdr.setFixedHeight(22)
        hdr.setStyleSheet(
            f"background: {SURFACE}; border-left: 3px solid {color};"
        )
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(10, 0, 10, 0)
        lbl = QLabel(title)
        lbl.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        lbl.setStyleSheet(f"color: {color}; background: transparent; border: none;")
        hl.addWidget(lbl)
        hl.addStretch(1)
        count_lbl = QLabel("")
        count_lbl.setFont(QFont(FONT_MONO, 7))
        count_lbl.setStyleSheet(f"color: {MUTED}; background: transparent; border: none;")
        count_lbl.setObjectName("count")
        hl.addWidget(count_lbl)
        vl.addWidget(hdr)

        # Table.
        table = QTableView()
        table.setModel(model)
        table.setSortingEnabled(True)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False)
        table.verticalHeader().setDefaultSectionSize(24)
        table.setShowGrid(False)
        table.setStyleSheet(_TABLE_STYLE)
        # Fonts applied imperatively in pt (not px) so they match the
        # Commodity and Market Pulse tables at matching point sizes.
        # 10pt body / 9pt header — same as MacroFlowPanel._build_table.
        table.setFont(QFont(FONT_MONO, 10))
        h = table.horizontalHeader()
        h.setFont(QFont(FONT_MONO, 9, QFont.Weight.DemiBold))
        h.setMinimumSectionSize(30)
        h.setStretchLastSection(False)
        h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        h.setFixedHeight(26)
        # Column sizing: numeric / narrow columns stay Interactive with
        # their calibrated widths, while the Symbol column (index 1)
        # stretches to absorb any extra table width. Prevents the large
        # blank gap on the right that appeared when the viewport was
        # wider than the sum of fixed column widths. Symbol is the
        # natural stretch candidate — text content varies and the
        # numeric columns are already right-sized for their value
        # ranges.
        for i, (header_name, _, w) in enumerate(cols):
            if header_name == "Symbol":
                h.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)
            else:
                h.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
                h.resizeSection(i, w)
        table.clicked.connect(lambda idx, m=model: self._on_row_click(m, idx))
        table.doubleClicked.connect(lambda idx, m=model: self._on_row_dbl(m, idx))
        vl.addWidget(table, stretch=1)

        return container

    def _build_research_section(self) -> QWidget:
        """Build the collapsible RESEARCH MONITOR container.

        Structure:
          [◂ header — always visible, click toggles body ]
          [   body: QTableView of _research_model       ]   ← hidden by default

        The header shows a violet caret + title + count label.
        The body caps at a fixed height so it doesn't steal all
        screen real estate when expanded; users can scroll inside
        the table to see more rows.
        """
        container = QWidget()
        container.setStyleSheet(f"background: {BG};")
        vl = QVBoxLayout(container)
        vl.setContentsMargins(0, 0, 0, 0)
        vl.setSpacing(0)

        # ── Clickable header ────────────────────────────────────
        hdr = QFrame()
        hdr.setFixedHeight(22)
        hdr.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-left: 3px solid {VIOLET};"
            f"  border-top: 1px solid {BORDER}; }}"
            f"QLabel {{ background: transparent; border: none; }}"
        )
        hdr.setCursor(Qt.CursorShape.PointingHandCursor)
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(10, 0, 10, 0)
        hl.setSpacing(6)

        self._research_caret = QLabel("▸")
        self._research_caret.setFont(QFont(FONT_MONO, 10))
        self._research_caret.setStyleSheet(f"color: {VIOLET};")
        hl.addWidget(self._research_caret)

        title_lbl = QLabel("RESEARCH MONITOR")
        title_lbl.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        title_lbl.setStyleSheet(f"color: {VIOLET};")
        hl.addWidget(title_lbl)

        note_lbl = QLabel("· OOS unconfirmed — track only, do not trade")
        note_lbl.setFont(QFont(FONT_MONO, 8))
        note_lbl.setStyleSheet(f"color: {MUTED};")
        hl.addWidget(note_lbl)

        hl.addStretch(1)

        self._research_count_lbl = QLabel("0 signals")
        self._research_count_lbl.setFont(QFont(FONT_MONO, 7))
        self._research_count_lbl.setStyleSheet(f"color: {MUTED};")
        hl.addWidget(self._research_count_lbl)

        # Bind click to toggle — using a lambda keeps it defensive
        # against the body being reassigned later.
        hdr.mousePressEvent = lambda _ev: self._toggle_research_body()
        vl.addWidget(hdr)

        # ── Body: table wrapped in a container so we can toggle it ─
        self._research_body = QWidget()
        bl = QVBoxLayout(self._research_body)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(0)

        table = QTableView()
        table.setModel(self._research_model)
        table.setSortingEnabled(True)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False)
        table.verticalHeader().setDefaultSectionSize(24)
        table.setShowGrid(False)
        table.setStyleSheet(_TABLE_STYLE)
        # Same pt sizing as MR/Ride for cross-table visual consistency.
        table.setFont(QFont(FONT_MONO, 10))
        h = table.horizontalHeader()
        h.setFont(QFont(FONT_MONO, 9, QFont.Weight.DemiBold))
        h.setMinimumSectionSize(30)
        h.setStretchLastSection(False)
        h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        h.setFixedHeight(26)
        # Symbol column stretches to absorb slack — same pattern as
        # MR/Ride for visual consistency across all three tables.
        for i, (header_name, _, w) in enumerate(_RESEARCH_COLUMNS):
            if header_name == "Symbol":
                h.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)
            else:
                h.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
                h.resizeSection(i, w)
        table.clicked.connect(
            lambda idx: self._on_row_click(self._research_model, idx)
        )
        table.doubleClicked.connect(
            lambda idx: self._on_row_dbl(self._research_model, idx)
        )
        self._research_table = table
        bl.addWidget(table)

        # Cap height so expansion doesn't steal the whole window.
        # Operators can scroll inside the table for longer lists.
        self._research_body.setMaximumHeight(220)
        self._research_body.setVisible(False)
        vl.addWidget(self._research_body)

        return container

    def _toggle_research_body(self) -> None:
        """Flip research table visibility and update the caret.

        Uses explicit state (``_research_expanded``) rather than
        ``isVisible()`` because Qt returns ``False`` for any widget
        whose top-level parent isn't mapped yet — this would make
        the toggle unreliable before the tab is first shown.
        """
        self._research_expanded = not getattr(self, "_research_expanded", False)
        self._research_body.setVisible(self._research_expanded)
        self._research_caret.setText("▾" if self._research_expanded else "▸")

    # ── Scan flow ─────────────────────────────────────────────────

    def _on_run(self):
        logger.info("ScannerTab._on_run called")
        if self._worker and self._worker.isRunning():
            logger.info("  cancelling running worker")
            self._worker.cancel()
            self._run_btn.setText("▶ SCAN")
            self._progress_frame.setVisible(False)
            return

        if self._scan_input_fn is None:
            logger.warning("  scan_input_fn is None — not wired")
            self._footer_lbl.setText("Scanner not initialised — click REFRESH in sidebar first.")
            return

        logger.info("  starting worker thread")
        self._mr_model.clear()
        self._ride_model.clear()
        self._research_model.clear()
        # Live-row buffers — accumulate rows as they stream from the
        # worker. _on_scan_done replaces model data with the final
        # sorted snapshot version so the display matches the canonical
        # sort order.
        self._live_mr_rows: list[dict] = []
        self._live_ride_rows: list[dict] = []
        self._live_research_rows: list[dict] = []
        self._live_trap_count = 0
        self._research_count_lbl.setText("scanning…")
        self._research_count_lbl.setStyleSheet(f"color: {MUTED};")
        self._run_btn.setText("■ STOP")
        self._progress_frame.setVisible(True)
        # Determinate mode: range 0..100, updated as symbols complete.
        # (Was previously stuck at 0 because no progress signal was wired.)
        self._progress.setRange(0, 100)
        self._progress.setValue(0)
        self._progress_lbl.setText("Starting…")

        self._worker = _ScanWorker(
            self._scan_input_fn,
            universe_name=self._universe_combo.currentText(),
        )
        self._worker.progress.connect(self._on_scan_progress)
        self._worker.result_ready.connect(self._on_scan_result)
        self._worker.finished.connect(self._on_scan_done)
        self._worker.error.connect(self._on_scan_error)
        self._worker.start()

        self._footer_lbl.setText(
            f"Scanning {self._universe_combo.currentText()}…"
        )

    def _on_scan_progress(self, done: int, total: int, symbol: str) -> None:
        """Update progress bar + label as the scanner completes symbols."""
        if total <= 0:
            return
        pct = int(round(100 * done / total))
        self._progress.setValue(max(0, min(100, pct)))
        self._progress_lbl.setText(f"{done}/{total}  ·  {symbol}")

    def _on_scan_result(self, payload) -> None:
        """Route per-symbol streaming results to the right table model.

        Fires once per firing symbol during the scan. Classification
        is by :func:`_classify_result` — shared with the batch
        post-scan path in :meth:`_on_scan_done` so streaming and final
        views agree. Mode-agnostic: aggressive and conservative
        strategies share this routing via their common SetupType.
        """
        symbol_results, state = payload
        for r in symbol_results:
            bucket = _classify_result(r)
            if bucket is _RowBucket.MR:
                self._live_mr_rows.append(_mr_row(r, state))
                self._mr_model.set_data(self._live_mr_rows)
            elif bucket is _RowBucket.RIDE:
                self._live_ride_rows.append(_ride_row(r, state))
                self._ride_model.set_data(self._live_ride_rows)
            elif bucket is _RowBucket.TRAP:
                self._live_trap_count += 1
            else:  # _RowBucket.RESEARCH
                self._live_research_rows.append(_research_row(r, state))
                self._research_model.set_data(self._live_research_rows)
                # Live-update the violet count label so the operator
                # can see research fires accumulating even with the
                # body collapsed.
                n = len(self._live_research_rows)
                self._research_count_lbl.setText(
                    f"{n} signal{'s' if n != 1 else ''}"
                )
                self._research_count_lbl.setStyleSheet(f"color: {VIOLET};")

    def _on_scan_done(self, snapshot: ScanSnapshot):
        logger.info("ScannerTab._on_scan_done: %d results", len(snapshot.results))
        self._snapshot = snapshot
        self._run_btn.setText("▶ SCAN")
        self._progress_frame.setVisible(False)
        self._last_scan_ts = time.time()

        # Re-classify the SORTED snapshot results. Rows already streamed
        # live via ``_on_scan_result`` in scan order (symbol-alphabetical);
        # the snapshot's ``results`` list is sorted canonically by
        # ``(-score, -priority, name)`` in scan_with_snapshot. Replacing
        # the live buffers with this sorted view gives the operator a
        # stable final ordering without needing to re-sort in the model.
        # Classification delegates to :func:`_classify_result` so this
        # path and the streaming path in _on_scan_result stay in lockstep.
        mr_rows: list[dict] = []
        ride_rows: list[dict] = []
        research_rows: list[dict] = []
        trap_count = 0
        for r in snapshot.results:
            state = snapshot.state_by_symbol.get(r.symbol)
            bucket = _classify_result(r)
            if bucket is _RowBucket.MR:
                mr_rows.append(_mr_row(r, state))
            elif bucket is _RowBucket.RIDE:
                ride_rows.append(_ride_row(r, state))
            elif bucket is _RowBucket.TRAP:
                trap_count += 1
            else:   # _RowBucket.RESEARCH
                research_rows.append(_research_row(r, state))

        # Already roughly sorted by score from the snapshot, but MR/Ride
        # sort keys above use ``score`` explicitly for determinism. The
        # snapshot sort is on Conviction.score; the row dicts mirror it.
        mr_rows.sort(key=lambda d: d.get("score", 0), reverse=True)
        ride_rows.sort(
            key=lambda d: d.get("score", 0) if "score" in d else 0,
            reverse=True,
        )
        # Research tier has no score column (override forces all to 0);
        # sort by symbol so the ordering is stable.
        research_rows.sort(key=lambda d: d.get("symbol", ""))
        self._all_mr_rows = mr_rows
        self._all_ride_rows = ride_rows
        self._all_research_rows = research_rows
        self._research_count = len(research_rows)
        self._trap_count = trap_count

        self._apply_view()

        # Populate research model with the canonical sorted view and
        # update its count label.
        self._research_model.set_data(research_rows)
        if len(research_rows) > 0:
            self._research_count_lbl.setText(
                f"{len(research_rows)} signal{'s' if len(research_rows) != 1 else ''}"
            )
            self._research_count_lbl.setStyleSheet(f"color: {VIOLET};")
        else:
            self._research_count_lbl.setText("no signals")
            self._research_count_lbl.setStyleSheet(f"color: {MUTED};")

        suffix = ""
        if self._worker is not None and getattr(self._worker, "_fallback_used", False):
            suffix = "  · NIFTY 50 fallback (universe metadata missing)"
        # Surface non-production signal counts — research-tier and TRAP
        # fires don't go into the MR/Ride tables but the operator should
        # know the scan found them. Research rows ARE displayed in the
        # collapsible RESEARCH MONITOR section; TRAP fires are hidden
        # entirely (hard-skip overrides, no tradable information).
        hidden_parts: list[str] = []
        if len(research_rows) > 0:
            hidden_parts.append(f"{len(research_rows)} research")
        if trap_count > 0:
            hidden_parts.append(f"{trap_count} TRAP")
        hidden_suffix = f"  ·  also: {', '.join(hidden_parts)}" if hidden_parts else ""
        # Footer reads the VISIBLE slice counts from the models (after
        # TOP-N filtering) and reports totals separately — previously
        # the footer showed the raw scan counts even after filtering,
        # which didn't match the visible row counts on the tables.
        visible_mr = self._mr_model.rowCount()
        visible_ride = self._ride_model.rowCount()
        count_txt = (
            f"MR: {visible_mr} of {len(mr_rows)} · "
            f"Ride: {visible_ride} of {len(ride_rows)}"
        ) if (visible_mr < len(mr_rows) or visible_ride < len(ride_rows)) else (
            f"MR: {len(mr_rows)} · Ride: {len(ride_rows)}"
        )
        # Strategy-mode prefix — makes screenshots self-documenting
        # about which strategy set produced these results. Silent when
        # unset so tests / unparented usage don't get noise.
        mode_prefix = (
            f"[{self._strategy_mode_label}]  "
            if self._strategy_mode_label else ""
        )
        self._footer_lbl.setText(
            f"{mode_prefix}{count_txt} · Total scanned: {len(snapshot.enriched_panel)} "
            f"symbols  (asof {snapshot.asof_date.date()}){hidden_suffix}{suffix}"
        )
        self.scan_completed.emit(snapshot)

    def _on_topn_changed(self, _value: int) -> None:
        """TOP spinner changed — re-slice the cached results without
        re-scanning. No-op before the first scan completes."""
        if getattr(self, "_all_mr_rows", None) is None:
            return
        self._apply_view()

    def _apply_view(self) -> None:
        """Slice the cached all-results lists by the current TOP N and
        populate both table models. Rank is recomputed over the sliced
        view so the ``#`` column always reads 1, 2, 3 … from the top
        of the visible set."""
        mr_rows = list(self._all_mr_rows or [])
        ride_rows = list(self._all_ride_rows or [])

        top_n = self._topn.value()     # 0 == "ALL" (special value text)
        if top_n > 0:
            mr_rows = mr_rows[:top_n]
            ride_rows = ride_rows[:top_n]

        # Rank assignment is idempotent — mutate a copy of each dict
        # so repeated filter changes don't stack stale ranks.
        mr_rows = [{**r, "rank": i} for i, r in enumerate(mr_rows, start=1)]
        ride_rows = [{**r, "rank": i} for i, r in enumerate(ride_rows, start=1)]

        self._mr_model.set_data(mr_rows)
        self._ride_model.set_data(ride_rows)

        for container, model in (
            (self._mr_table.parent(), self._mr_model),
            (self._ride_table.parent(), self._ride_model),
        ):
            count_lbl = container.findChild(QLabel, "count")
            if not count_lbl:
                continue
            total = len(self._all_mr_rows) if model is self._mr_model else len(self._all_ride_rows)
            visible = model.rowCount()
            if total == 0:
                count_lbl.setText("no signals")
            elif visible < total:
                count_lbl.setText(f"{visible} of {total} signals")
            else:
                count_lbl.setText(f"{visible} signals")

    def _on_scan_error(self, msg: str):
        logger.error("ScannerTab._on_scan_error: %s", msg)
        self._run_btn.setText("▶ SCAN")
        self._progress_frame.setVisible(False)
        self._footer_lbl.setText(f"Error: {msg}")

    # ── Table interaction ─────────────────────────────────────────

    def _on_row_click(self, model: _ScanTableModel, index):
        row = model.row_data(index.row())
        if row:
            self.symbol_selected.emit(row["symbol"])

    def _on_row_dbl(self, model: _ScanTableModel, index):
        row = model.row_data(index.row())
        if row:
            self.symbol_selected.emit(row["symbol"])
            self.row_double_clicked.emit(row["symbol"])

    # ── Export ────────────────────────────────────────────────────

    def _on_export(self):
        if self._mr_model.rowCount() == 0 and self._ride_model.rowCount() == 0:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Scan", "nimbus_scan.csv", "CSV (*.csv)",
        )
        if not path:
            return
        rows = []
        for model in (self._mr_model, self._ride_model):
            for i in range(model.rowCount()):
                d = model.row_data(i)
                if d:
                    rows.append({k: v for k, v in d.items() if not k.startswith("_")})
        pd.DataFrame(rows).to_csv(path, index=False)
