#!/usr/bin/env python3
"""seasonal_breakout_probe.py — does "fresh breakout INTO a seasonally
strong next month" actually predict forward return, or does it just
describe COCHINSHIP after the fact?

THE THESIS UNDER TEST
─────────────────────
The operator's intuition: a name that has JUST broken out (body above the
upper band, streak <= 2) in an industry whose NEXT calendar month has high
seasonal reliability is an EARLY entry into a seasonal move — in before the
rally rather than chasing it. If real, fresh breakouts sitting in front of a
strong seasonal month should out-earn fresh breakouts in front of a weak one.

WHY THIS NEEDS A PROBE, NOT A BUILD
───────────────────────────────────
Two priors say be skeptical:
  1. Freshness alone has tested NULL repeatedly (entry_probe: forward excess
     is flat-to-rising with streak, not decaying). So "fresh" is an entry
     PREFERENCE, not a predictive edge.
  2. Seasonal "reliability" is consistency of a monthly sign over ~3-5 years
     — a rank of 100 can rest on 4 observations. Suggestive, not a forecast.

So the ONLY thing that justifies turning this into a scored factor is if the
CONJUNCTION predicts out of sample, against controls. That is what this
measures.

PRE-REGISTERED HYPOTHESIS (fixed before looking at any number)
──────────────────────────────────────────────────────────────
H1: Among fresh breakouts (above==True AND streak<=STREAK_MAX at the entry
    bar), forward FWD-day excess return over the equal-weight market is
    HIGHER for names whose industry's NEXT calendar month is in the top
    seasonal-reliability quartile than for the bottom quartile.

    Direction: top > bottom. Monotonic across the four quartiles.

PASS BAR (all three, or it does not become a factor):
  • date-clustered t(top-minus-bottom) > 2  (NOT per-trade t — crosses
    cluster; per-trade t is printed only to show the inflation).
  • monotonic mean excess across Q1<Q2<Q3<Q4 (allowing one inversion).
  • survives the random control below.

CONTROLS
  ctl:random-seasonal   Each industry's next-month reliability is REPLACED by
                        a random draw (seeded), rebuilt into quartiles. The
                        real split must beat this. If a random seasonal label
                        sorts forward returns just as well, the seasonal
                        signal is noise. ~0 expected.
  ctl:fresh-only-noseason  Fresh breakouts with NO seasonal split — the base
                        forward excess of a fresh breakout. Tells us whether
                        any top-quartile effect is the SEASON or just the
                        BREAKOUT. (If fresh-only already equals Q4, seasonality
                        adds nothing.)
  ctl:season-only-nofresh  ALL names (not just fresh) in top vs bottom
                        seasonal quartile. Isolates whether the effect needs
                        the breakout at all, or is just the seasonality factor
                        wearing a breakout costume.

STATISTICS
Breakouts cluster in time (a strong tape breaks hundreds of names at once,
and they co-move). Independent-looking per-trade t-stats over tens of
thousands of correlated events are the classic self-deception. Inference is
therefore on DATE-CLUSTERED means: average excess across all entries sharing
an entry date, t-test across DATES. Per-trade counts shown for context only.

SLICING
Date-grid slicing only (never positional): forward return is measured from
the entry date's position in THAT symbol's index, and "next month
seasonality" is computed from data STRICTLY BEFORE the entry date — no bar at
or after entry may inform the seasonal label (that would be lookahead). A
ctl:shuffle-dates canary must score ~0.

Run on your machine (needs the cached panel):
    python seasonal_breakout_probe.py
    python seasonal_breakout_probe.py --selftest   # mechanics only, no cache
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict

STREAK_MAX = 2          # "fresh": trailing body-above run <= this
FWD = 20                # forward horizon (trading days) for the outcome
MIN_ENTRIES_PER_DATE = 1
MIN_SEASON_YEARS = 3    # ≥3y history to trust a monthly reliability cell
UPPER = "bb_20_1s_upper"


# ── seasonal reliability of an industry's NEXT month, as-of a date ──────────
def next_month_reliability(industry_close, asof, *, min_years=MIN_SEASON_YEARS):
    """Reliability of the industry composite's NEXT calendar month, using
    ONLY data strictly before ``asof``.

    Returns (reliability_0_1, n_years) or (nan, 0). Reliability is the same
    |mean|/std SNR the app uses (seasonal_reliability), computed over the
    per-year returns of the target month.
    """
    import numpy as np
    import pandas as pd

    from nimbus_v3.compute.seasonality import (
        _monthly_returns,
        seasonal_reliability,
    )

    # STRICTLY before asof — no lookahead.
    hist = industry_close.loc[industry_close.index < asof]
    if hist.empty:
        return float("nan"), 0
    monthly = _monthly_returns(hist)          # month-over-month, indexed ME
    if monthly.empty:
        return float("nan"), 0
    target_month = (pd.Timestamp(asof).month % 12) + 1     # NEXT month
    vals = monthly[monthly.index.month == target_month].to_numpy(dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < min_years:
        return float("nan"), len(vals)
    avg = float(np.mean(vals))
    std = float(np.std(vals, ddof=1)) if len(vals) > 1 else float("nan")
    return seasonal_reliability(avg, std), len(vals)


# ── fresh-breakout entries across the panel ─────────────────────────────────
def find_fresh_entries(panel, sym_to_industry):
    """Yield (date, symbol, industry) for every bar where a name is FRESH:
    body above the upper band with a trailing streak <= STREAK_MAX.

    Uses the same body-above rule as the app (min(Open,Close) > upper).
    """
    import numpy as np

    entries = []
    for sym, df in panel.items():
        ind = sym_to_industry.get(sym)
        if ind is None or UPPER not in df.columns:
            continue
        o = df["Open"].to_numpy(dtype=float)
        c = df["Close"].to_numpy(dtype=float)
        up = df[UPPER].to_numpy(dtype=float)
        body = np.minimum(o, c)
        above = body > up
        # trailing streak at each bar
        streak = 0
        for i in range(len(above)):
            streak = streak + 1 if above[i] else 0
            if above[i] and streak <= STREAK_MAX:
                entries.append((df.index[i], sym, ind, i))
    return entries


def forward_excess(df, i, market_cum, *, fwd=FWD):
    """FWD-day forward return of the symbol from bar i MINUS the market's
    return over the identical dates. Date-grid based: uses bar i and bar
    i+fwd in THIS symbol's own index; returns nan if it runs off the end.
    """
    import numpy as np

    if i + fwd >= len(df):
        return float("nan"), None
    c = df["Close"].to_numpy(dtype=float)
    r_sym = c[i + fwd] / c[i] - 1.0
    d0, d1 = df.index[i], df.index[i + fwd]
    m0 = market_cum.get(d0)
    m1 = market_cum.get(d1)
    if m0 is None or m1 is None or m0 <= 0:
        return float("nan"), None
    r_mkt = m1 / m0 - 1.0
    if not (np.isfinite(r_sym) and np.isfinite(r_mkt)):
        return float("nan"), None
    return r_sym - r_mkt, d0


# ── date-clustered inference ────────────────────────────────────────────────
def clustered_t(pairs):
    """pairs: list of (entry_date, excess). Returns (mean, t, n_dates,
    n_trades) with the t-stat computed across DATE means, not trades."""
    import numpy as np

    by_date = defaultdict(list)
    for d, x in pairs:
        if x == x:
            by_date[d].append(x)
    date_means = [float(np.mean(v)) for v in by_date.values()
                  if len(v) >= MIN_ENTRIES_PER_DATE]
    n_trades = sum(len(v) for v in by_date.values())
    if len(date_means) < 3:
        return float("nan"), float("nan"), len(date_means), n_trades
    arr = np.array(date_means)
    mean = float(arr.mean())
    se = float(arr.std(ddof=1) / np.sqrt(len(arr)))
    t = mean / se if se > 0 else float("nan")
    return mean, t, len(arr), n_trades


def quartile_split(values):
    """Return quartile edges [q25,q50,q75] over finite values."""
    import numpy as np

    v = np.array([x for x in values if x == x])
    if len(v) < 4:
        return None
    return [float(np.quantile(v, q)) for q in (0.25, 0.5, 0.75)]


def assign_quartile(x, edges):
    if x != x or edges is None:
        return None
    if x <= edges[0]:
        return 0
    if x <= edges[1]:
        return 1
    if x <= edges[2]:
        return 2
    return 3


# ── main study ──────────────────────────────────────────────────────────────
def run_study(panel, sym_to_industry, industry_composites, market_cum,
              *, rng, label="real", shuffle_seasonal=False,
              shuffle_dates=False):
    """Build (entry -> forward excess, next-month reliability quartile) and
    report by quartile, plus the top-minus-bottom clustered t.
    """
    import numpy as np

    entries = find_fresh_entries(panel, sym_to_industry)

    # Reliability per (industry, entry-month) — cache by (industry, year,
    # month) since it only changes as history grows; keyed to asof date.
    rel_cache = {}
    records = []          # (date, excess, reliability)
    for (date, sym, ind, i) in entries:
        df = panel[sym]
        excess, d0 = forward_excess(df, i, market_cum)
        if excess != excess:
            continue
        comp = industry_composites.get(ind)
        if comp is None:
            continue
        key = (ind, date.year, date.month)
        if key not in rel_cache:
            rel_cache[key] = next_month_reliability(comp, date)[0]
        rel = rel_cache[key]
        if rel != rel:
            continue
        records.append([date, excess, rel])

    if shuffle_dates:
        # canary: destroy the date<->excess link. Must score ~0.
        ds = [r[0] for r in records]
        rng.shuffle(ds)
        for r, d in zip(records, ds):
            r[0] = d

    rels = [r[2] for r in records]
    if shuffle_seasonal:
        # ctl:random-seasonal — replace each record's reliability with a
        # random draw from the SAME distribution, then re-quartile.
        shuffled = list(rels)
        rng.shuffle(shuffled)
        for r, s in zip(records, shuffled):
            r[2] = s
        rels = [r[2] for r in records]

    edges = quartile_split(rels)
    buckets = defaultdict(list)     # quartile -> [(date, excess)]
    for date, excess, rel in records:
        q = assign_quartile(rel, edges)
        if q is not None:
            buckets[q].append((date, excess))

    print(f"\n─── {label} " + "─" * (60 - len(label)))
    print(f"  fresh entries with usable fwd return + seasonality: "
          f"{len(records)}")
    qstats = {}
    for q in range(4):
        mean, t, nd, ntr = clustered_t(buckets.get(q, []))
        qstats[q] = (mean, t, nd, ntr)
        bar = "" if mean != mean else f"{mean*100:+6.2f}%"
        print(f"  Q{q+1} (reliability {'low' if q==0 else 'high' if q==3 else 'mid'}):"
              f" mean {bar}  clustered-t {t:+5.2f}  "
              f"dates {nd:4d}  trades {ntr:5d}")

    # top-minus-bottom, clustered across dates on the DIFFERENCE is not
    # well-defined (different dates), so report both means + a pooled
    # difference t via the two independent date-mean samples.
    top = buckets.get(3, [])
    bot = buckets.get(0, [])
    tm, tt, tnd, _ = clustered_t(top)
    bm, bt, bnd, _ = clustered_t(bot)
    diff = (tm - bm) if (tm == tm and bm == bm) else float("nan")

    # Welch t on the two date-mean samples (independent dates).
    import numpy as np

    def date_means(pairs):
        d = defaultdict(list)
        for dt, x in pairs:
            if x == x:
                d[dt].append(x)
        return np.array([np.mean(v) for v in d.values()])
    a, b = date_means(top), date_means(bot)
    if len(a) >= 3 and len(b) >= 3:
        va, vb = a.var(ddof=1), b.var(ddof=1)
        se = np.sqrt(va/len(a) + vb/len(b))
        welch_t = (a.mean() - b.mean()) / se if se > 0 else float("nan")
    else:
        welch_t = float("nan")

    print(f"  ── Q4 − Q1 = {diff*100:+.2f}%   Welch-t(across dates) "
          f"= {welch_t:+.2f}")
    monotonic = all(
        qstats[q][0] <= qstats[q+1][0] + 1e-9
        for q in range(3)
        if qstats[q][0] == qstats[q][0] and qstats[q+1][0] == qstats[q+1][0])
    print(f"  monotonic Q1≤Q2≤Q3≤Q4: {monotonic}")
    return {"diff": diff, "welch_t": welch_t, "monotonic": monotonic,
            "qstats": qstats}


def build_market_cum(panel, *, min_count=20):
    import numpy as np

    sums, counts = defaultdict(float), defaultdict(int)
    for df in panel.values():
        c = df["Close"].to_numpy(dtype=float)
        idx = df.index
        for i in range(1, len(c)):
            if c[i-1] > 0 and np.isfinite(c[i]) and np.isfinite(c[i-1]):
                r = c[i]/c[i-1] - 1.0
                sums[idx[i]] += r
                counts[idx[i]] += 1
    daily = {d: sums[d]/counts[d] for d in sums if counts[d] >= min_count}
    dates = sorted(daily)
    cum, acc = {}, 1.0
    for d in dates:
        acc *= (1.0 + daily[d])
        cum[d] = acc
    return cum


def build_industry_composites(panel, sym_to_industry):
    from nimbus_v3.compute.industry_composite import build_industry_composite

    members = defaultdict(list)
    for sym, ind in sym_to_industry.items():
        if sym in panel:
            members[ind].append(sym)
    out = {}
    for ind, syms in members.items():
        comp, _ = build_industry_composite(
            syms, panel, min_members=3, min_bars=250, lookback=None)
        if comp is not None:
            out[ind] = comp
    return out


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=17)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return _selftest(args)

    import numpy as np

    from nimbus_v3.compute.engine import StrategyComputeEngine
    from nimbus_v3.data.industry_db import load_industry_db

    rng = np.random.default_rng(args.seed)
    eng = StrategyComputeEngine()
    db = load_industry_db()
    if not db:
        print("industry DB empty.", file=sys.stderr)
        return 1
    sym_to_industry = {s: c.industry for s, c in db.items()}

    # reuse strategy_probe's panel loader (same cache, same freshness rules)
    from strategy_probe import load_panel
    print("loading panel...", file=sys.stderr)
    panel = load_panel(eng, db)
    print(f"panel: {len(panel)} symbols", file=sys.stderr)
    if len(panel) < 50:
        print("panel too small — is the cache present?", file=sys.stderr)
        return 1

    print("building industry composites + market...", file=sys.stderr)
    comps = build_industry_composites(panel, sym_to_industry)
    market = build_market_cum(panel)

    real = run_study(panel, sym_to_industry, comps, market,
                     rng=rng, label="REAL: fresh × next-month seasonality")
    run_study(panel, sym_to_industry, comps, market, rng=rng,
              label="ctl:random-seasonal", shuffle_seasonal=True)
    run_study(panel, sym_to_industry, comps, market, rng=rng,
              label="ctl:shuffle-dates (canary, expect ~0)",
              shuffle_dates=True)

    print("\n" + "=" * 68)
    print("VERDICT")
    ok = (real["welch_t"] > 2 and real["monotonic"] and real["diff"] > 0)
    if ok:
        print("  Q4−Q1 positive, monotonic, Welch-t > 2 across dates.")
        print("  → The conjunction has a signal worth building as a FACTOR.")
        print("    Next: confirm it survives random-seasonal (should be ~0)")
        print("    and that Q4 beats ctl:fresh-only (season adds over break).")
    else:
        print("  Does NOT clear the bar (need Q4>Q1, monotonic, Welch-t>2).")
        print("  → Do NOT score it. Build the 'Seasonal Setup' VIEW FILTER")
        print("    instead: fresh + high next-month reliability + high trust,")
        print("    displayed and sortable, as a scanning aid — honest about")
        print("    being a lens, not a predictor.")
    return 0


# ── self-test: mechanics only, synthetic data, no cache needed ──────────────
def _selftest(args):
    """Validate the machinery without the real panel.

    Design: many industries, each with a CONTINUOUS reliability r in (0,1),
    and a planted forward bump PROPORTIONAL to r — high-reliability
    industries get a real seasonal payoff after a breakout, low ones get
    none. A correct probe must then show monotonically rising excess across
    quartiles with Q4 > Q1 and Welch-t > 2. The shuffle-dates canary on the
    same data must collapse that.
    """
    import numpy as np
    import pandas as pd

    rng = np.random.default_rng(args.seed)
    dates = pd.bdate_range("2015-01-01", periods=1500)
    panel, sym_to_industry = {}, {}
    rel_by_ind = {}
    N_IND = 24

    for k in range(N_IND):
        r = (k + 0.5) / N_IND               # continuous reliability
        ind = f"Ind{k:02d}"
        rel_by_ind[ind] = r
        for j in range(3):
            sym = f"S{k:02d}_{j}"
            rets = rng.normal(0.0002, 0.012, len(dates))
            # First pass: locate breakouts on the UNBUMPED path.
            c0 = 100 * np.exp(np.cumsum(rets))
            s0 = pd.Series(c0, index=dates)
            up0 = (s0.rolling(20).mean() + s0.rolling(20).std()).to_numpy()
            body0 = c0                      # Open==Close here, so body==Close
            # Plant forward drift ∝ reliability in RETURNS space, so a later
            # entry's forward ratio reflects only its own window's bump
            # (earlier bumps sit before the window and cancel in the ratio).
            per_bar = (0.05 * r) / FWD
            for i in range(25, len(c0) - FWD - 1):
                if body0[i] > up0[i] and body0[i-1] <= up0[i-1]:
                    rets[i+1:i+1+FWD] += per_bar
            c = 100 * np.exp(np.cumsum(rets))
            df = pd.DataFrame({"Open": c, "High": c*1.01, "Low": c*0.99,
                               "Close": c, "Volume": 1e6}, index=dates)
            mid = df["Close"].rolling(20).mean()
            sd = df["Close"].rolling(20).std()
            df[UPPER] = mid + sd
            panel[sym] = df
            sym_to_industry[sym] = ind

    # Flat filler names to anchor the equal-weight market near zero drift,
    # so the planted per-quartile excess is measurable rather than absorbed
    # into a market that is itself made of the bumped names.
    filler = {}
    for k in range(120):
        ret = rng.normal(0.0002, 0.012, len(dates))
        c = 100 * np.exp(np.cumsum(ret))
        filler[f"MKT{k:03d}"] = pd.DataFrame(
            {"Open": c, "High": c*1.01, "Low": c*0.99, "Close": c,
             "Volume": 1e6}, index=dates)
    market = build_market_cum({**panel, **filler}, min_count=10)
    comps = build_industry_composites(panel, sym_to_industry)

    import seasonal_breakout_probe as mod
    real_next = mod.next_month_reliability
    ind_of_comp = {id(comp): ind for ind, comp in comps.items()}

    def fake_rel(industry_close, asof, **kw):
        ind = ind_of_comp.get(id(industry_close))
        return (rel_by_ind.get(ind, float("nan")), 5)
    mod.next_month_reliability = fake_rel
    try:
        planted = run_study(panel, sym_to_industry, comps, market, rng=rng,
                            label="selftest: PLANTED monotone signal")
        # Decisive canary for a SEASONAL signal: randomise the reliability
        # labels. If the gradient survives that, the split is noise. (Note
        # shuffle-DATES is not the right canary here — it keeps each record's
        # excess+reliability pair, so it only probes clustering inference,
        # not the seasonal link.)
        canary = run_study(panel, sym_to_industry, comps, market, rng=rng,
                           label="selftest: ctl:random-seasonal (expect ~0)",
                           shuffle_seasonal=True)
    finally:
        mod.next_month_reliability = real_next

    # Monotone up to one inversion (as pre-registered).
    qm = [planted["qstats"][q][0] for q in range(4)]
    inversions = sum(1 for q in range(3) if qm[q] > qm[q+1] + 1e-9)
    ok = planted["diff"] > 0 and planted["welch_t"] > 2 and inversions <= 1
    canary_ok = not (canary["welch_t"] > 2)      # gradient must vanish
    print("\n" + "=" * 68)
    print(f"SELFTEST planted detected (Q4>Q1, ≤1 inversion, t>2): {ok}")
    print(f"SELFTEST random-seasonal collapses (t not > 2):       {canary_ok}")
    print("PASS" if (ok and canary_ok) else "FAIL")
    return 0 if (ok and canary_ok) else 1


if __name__ == "__main__":
    raise SystemExit(main())
