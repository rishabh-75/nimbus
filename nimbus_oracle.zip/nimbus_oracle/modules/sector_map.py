"""
modules/sector_map.py
─────────────────────
Sector ticker registry for NIMBUS Market Context tab.

Tickers:
  ^CNX* / ^NSE*  — NSE index tickers (yfinance confirmed)
  *.NS           — NSE ETF tickers (yfinance confirmed)

Nifty 500 benchmark: MONIFTY500.NS (MO ETF) → fallback ^NSEI
"""

from __future__ import annotations

# ── Market benchmark ──────────────────────────────────────────────────────────
MARKET_TICKER = "MONIFTY500.NS"  # Motilal Oswal Nifty 500 ETF
MARKET_FALLBACK = "^NSEI"  # Nifty 50 fallback

# ── Sector map: yfinance_ticker → (Display Name, category) ───────────────────
# Category is used for future grouping/colour overrides.
# Ordered by logical grouping — sorted by RS at runtime.
SECTOR_MAP: dict[str, tuple[str, str]] = {
    # Financials (3 tiers: broad bank, PSU bank, private bank + NBFC/insurance)
    "^NSEBANK": ("Nifty Bank", "financials"),
    "^CNXPSUBANK": ("PSU Bank", "financials"),
    "PVTBANIETF.NS": ("Private Bank", "financials"),
    "FINIETF.NS": ("Fin Service", "financials"),    # Nippon Fin Service ETF (if 404: remove, falls back to Bank)
    # Technology
    "^CNXIT": ("IT", "technology"),
    # Healthcare (pharma + hospitals split)
    "^CNXPHARMA": ("Pharma", "healthcare"),
    "HEALTHIETF.NS": ("Healthcare", "healthcare"),   # Nippon Healthcare ETF (if 404: remove, falls back to Pharma)
    # Materials
    "^CNXMETAL": ("Metal", "materials"),
    # Consumer
    "^CNXFMCG": ("FMCG", "consumer"),
    "CONSUMBEES.NS": ("Consumption", "consumer"),
    # Auto
    "^CNXAUTO": ("Auto", "auto"),
    # Energy / Oil / PSU
    "^CNXENERGY": ("Energy", "energy"),              # power: NTPC, POWERGRID, TATAPOWER
    "CPSEETF.NS": ("CPSE", "psu"),                   # PSU basket: ONGC, NTPC, SBI, etc.
    "OILIETF.NS": ("Oil & Gas", "energy"),           # upstream + marketing: ONGC, IOC, BPCL
    "^CNXPSE": ("PSE", "psu"),                       # all public sector enterprises
    # Infrastructure
    "^CNXINFRA": ("Infra", "infra"),
    "^CNXREALTY": ("Realty", "realty"),
    # Media
    "^CNXMEDIA": ("Media", "media"),
    # Thematic
    "MODEFENCE.NS": ("MODEFENCE", "defence"),
    "METALIETF.NS": ("METALIETF", "materials"),
    # Commodity
    "GOLDBEES.NS": ("Gold", "COMMODITY"),
    "SILVERBEES.NS": ("Silver", "COMMODITY"),
    # INTERNATIONAL
    "MON100.NS": ("MON100", "International"),
    "MAFANG.NS": ("MAFANG", "International"),
    "HNGSNGBEES.NS": ("HNGSNGBEES", "International"),
    "MAHKTECH.NS": ("MAHKTECH", "International"),
}

# Convenience exports (legacy — kept for signal_engine.py compatibility)
SECTOR_TICKERS = list(SECTOR_MAP.keys())
SECTOR_NAMES = {t: v[0] for t, v in SECTOR_MAP.items()}

# ══════════════════════════════════════════════════════════════════════════════
# STOCK → SECTOR DISPLAY NAME (for sector RS conviction factor)
#
# Maps stocks to the MOST SPECIFIC rotation index available.
# Values must match SECTOR_MAP[ticker][0] exactly.
# get_sector_context() step 2 uses this; step 3 (dynamic) covers the rest.
#
# Principle: use the sector that best predicts the stock's rotation behavior.
# SBIN rotates with PSU Bank, not with HDFCBANK. ONGC rotates with Oil & Gas,
# not with NTPC. Use the primary business sector, not ownership type.
# ══════════════════════════════════════════════════════════════════════════════

STOCK_SECTOR_MAP: dict[str, str] = {
    # ── Private Banks → Private Bank ──────────────────────────────────────
    "HDFCBANK": "Private Bank", "ICICIBANK": "Private Bank",
    "AXISBANK": "Private Bank", "KOTAKBANK": "Private Bank",
    "INDUSINDBK": "Private Bank", "FEDERALBNK": "Private Bank",
    "IDFCFIRSTB": "Private Bank", "AUBANK": "Private Bank",
    "BANDHANBNK": "Private Bank", "RBLBANK": "Private Bank",
    # ── PSU Banks → PSU Bank ──────────────────────────────────────────────
    "SBIN": "PSU Bank", "BANKBARODA": "PSU Bank", "PNB": "PSU Bank",
    "CANBK": "PSU Bank", "UNIONBANK": "PSU Bank", "INDIANB": "PSU Bank",
    "BANKINDIA": "PSU Bank", "IOB": "PSU Bank", "CENTRALBK": "PSU Bank",
    "MAHABANK": "PSU Bank",
    # ── NBFCs / Insurance / AMCs → Fin Service ────────────────────────────
    "BAJFINANCE": "Fin Service", "BAJAJFINSV": "Fin Service",
    "HDFCLIFE": "Fin Service", "SBILIFE": "Fin Service",
    "ICICIPRULI": "Fin Service", "CHOLAFIN": "Fin Service",
    "MUTHOOTFIN": "Fin Service", "SHRIRAMFIN": "Fin Service",
    "HDFCAMC": "Fin Service", "LICHSGFIN": "Fin Service",
    "MANAPPURAM": "Fin Service", "SBICARD": "Fin Service",
    "ICICIGI": "Fin Service", "NIACL": "Fin Service",
    # ── PSU Finance → PSU Bank (closer proxy than Fin Service) ────────────
    "PFC": "PSU Bank", "RECLTD": "PSU Bank", "IRFC": "PSU Bank",
    # ── IT ─────────────────────────────────────────────────────────────────
    "TCS": "IT", "INFY": "IT", "WIPRO": "IT", "HCLTECH": "IT",
    "TECHM": "IT", "LTIM": "IT", "PERSISTENT": "IT", "COFORGE": "IT",
    "MPHASIS": "IT", "NAUKRI": "IT",
    # ── Telecom → IT (closest proxy) ──────────────────────────────────────
    "BHARTIARTL": "IT", "IDEA": "IT",
    # ── Pharma (drug companies) ───────────────────────────────────────────
    "SUNPHARMA": "Pharma", "CIPLA": "Pharma", "DRREDDY": "Pharma",
    "DIVISLAB": "Pharma", "BIOCON": "Pharma", "TORNTPHARM": "Pharma",
    "AUROPHARMA": "Pharma", "LUPIN": "Pharma", "ALKEM": "Pharma",
    "IPCALAB": "Pharma", "GLENMARK": "Pharma", "ZYDUSLIFE": "Pharma",
    "LAURUSLABS": "Pharma", "GRANULES": "Pharma",
    # ── Healthcare (hospitals, diagnostics) → Healthcare ──────────────────
    "APOLLOHOSP": "Healthcare", "MAXHEALTH": "Healthcare",
    "FORTIS": "Healthcare", "METROPOLIS": "Healthcare",
    "LALPATHLAB": "Healthcare",
    # ── Auto ───────────────────────────────────────────────────────────────
    "MARUTI": "Auto", "TATAMOTORS": "Auto", "BAJAJ-AUTO": "Auto",
    "HEROMOTOCO": "Auto", "EICHERMOT": "Auto", "M&M": "Auto",
    "ASHOKLEY": "Auto", "TVSMOTOR": "Auto", "BOSCHLTD": "Auto",
    "MOTHERSON": "Auto", "BALKRISIND": "Auto", "BHARATFORG": "Auto",
    # ── Metals ─────────────────────────────────────────────────────────────
    "TATASTEEL": "Metal", "JSWSTEEL": "Metal", "HINDALCO": "Metal",
    "VEDL": "Metal", "NMDC": "Metal", "SAIL": "Metal",
    "NATIONALUM": "Metal", "HINDCOPPER": "Metal", "JINDALSTEL": "Metal",
    # ── Oil & Gas (upstream + marketing + gas) → Oil & Gas ────────────────
    "ONGC": "Oil & Gas", "BPCL": "Oil & Gas", "IOC": "Oil & Gas",
    "GAIL": "Oil & Gas", "HINDPETRO": "Oil & Gas", "OIL": "Oil & Gas",
    "PETRONET": "Oil & Gas", "MGL": "Oil & Gas", "IGL": "Oil & Gas",
    "RELIANCE": "Oil & Gas",  # primarily refining + petchem revenue
    # ── Energy (power generation, transmission) → Energy ──────────────────
    "NTPC": "Energy", "POWERGRID": "Energy", "TATAPOWER": "Energy",
    "ADANIGREEN": "Energy", "NHPC": "Energy", "SJVN": "Energy",
    "TORNTPOWER": "Energy", "JSWENERGY": "Energy",
    # ── PSE / CPSE (non-specific PSU conglomerates) → PSE ─────────────────
    "COALINDIA": "PSE", "IRCTC": "PSE", "CONCOR": "PSE",
    # ── Adani group → primary business ────────────────────────────────────
    "ADANIENT": "Infra", "ADANIPORTS": "Infra",
    # ── FMCG (packaged goods, staples) → FMCG ────────────────────────────
    "ITC": "FMCG", "HINDUNILVR": "FMCG", "NESTLEIND": "FMCG",
    "BRITANNIA": "FMCG", "TATACONSUM": "FMCG", "DABUR": "FMCG",
    "GODREJCP": "FMCG", "MARICO": "FMCG", "COLPAL": "FMCG",
    "EMAMILTD": "FMCG", "VBL": "FMCG", "UBL": "FMCG",
    # ── Consumer discretionary → Consumption ──────────────────────────────
    "TITAN": "Consumption", "ASIANPAINT": "Consumption",
    "PIDILITIND": "Consumption", "TRENT": "Consumption",
    "PAGEIND": "Consumption", "JUBLFOOD": "Consumption",
    "DMART": "Consumption", "NYKAA": "Consumption",
    "ETERNAL": "Consumption",
    # ── Infra / Cement / Engineering ──────────────────────────────────────
    "LT": "Infra", "ULTRACEMCO": "Infra", "GRASIM": "Infra",
    "AMBUJACEM": "Infra", "SHREECEM": "Infra", "ACC": "Infra",
    "SIEMENS": "Infra", "ABB": "Infra", "HAVELLS": "Infra",
    "CUMMINSIND": "Infra",
    # ── Realty ─────────────────────────────────────────────────────────────
    "DLF": "Realty", "GODREJPROP": "Realty", "OBEROIRLTY": "Realty",
    "PRESTIGE": "Realty", "LODHA": "Realty", "BRIGADE": "Realty",
    # ── Defence → MODEFENCE ───────────────────────────────────────────────
    "BEL": "MODEFENCE", "HAL": "MODEFENCE",
}


# ══════════════════════════════════════════════════════════════════════════════
# STOCK SEGMENT CLASSIFICATION (data-driven from param sweep)
#
# Two behavioral populations on NSE:
#   INSTITUTIONAL: institutional-flow-driven, trend-persistent
#     → Mode A: Early Momentum (WR(20), -50, ADX)
#   CYCLICAL: commodity/cycle-driven, mean-reverting
#     → Mode B: Mean Reversion (WR(30), -30, below SMA)
#
# Classification based on:
#   - Sector characteristics (banking, IT = institutional; metals, pharma = cyclical)
#   - Market cap (mega-cap tends institutional)
#   - Sweep results showing distinct optimal parameters per group
# ══════════════════════════════════════════════════════════════════════════════

SEGMENT_INSTITUTIONAL = {
    # Banking & Finance
    "HDFCBANK", "ICICIBANK", "SBIN", "AXISBANK", "KOTAKBANK",
    "BAJFINANCE", "BAJAJFINSV", "INDUSINDBK", "HDFCLIFE", "SBILIFE",
    # IT (institutional flow heavy)
    "TCS", "INFY",
    # Mega-cap conglomerates
    "RELIANCE", "BHARTIARTL", "ADANIENT", "ADANIPORTS",
    # Indices
    "NIFTY", "BANKNIFTY", "FINNIFTY",
}

SEGMENT_CYCLICAL = {
    # Metals
    "TATASTEEL", "JSWSTEEL", "HINDALCO",
    # IT (mid-tier, more cyclical)
    "WIPRO", "TECHM", "HCLTECH",
    # Pharma
    "SUNPHARMA", "CIPLA", "DRREDDY", "DIVISLAB", "APOLLOHOSP",
    # Auto
    "MARUTI", "TATAMOTORS", "BAJAJ-AUTO", "HEROMOTOCO", "EICHERMOT", "M&M",
    # PSU / Infra
    "LT", "NTPC", "POWERGRID", "COALINDIA", "ONGC", "BPCL",
    # Consumer
    "ITC", "HINDUNILVR", "NESTLEIND", "BRITANNIA", "TATACONSUM",
    "TITAN", "ASIANPAINT",
    # Cement
    "ULTRACEMCO", "GRASIM",
    # Chemicals / New Age
    "UPL", "ETERNAL",
}


def get_segment(symbol: str) -> str:
    """
    Return 'INSTITUTIONAL' or 'CYCLICAL' for a given symbol.
    Default: CYCLICAL (mean reversion is the safer assumption).
    """
    sym = symbol.strip().upper().replace(".NS", "")
    if sym in SEGMENT_INSTITUTIONAL:
        return "INSTITUTIONAL"
    if sym in SEGMENT_CYCLICAL:
        return "CYCLICAL"
    # Default to cyclical — mean reversion has more robust sample sizes
    return "CYCLICAL"


# Legacy export for signal_engine.py
SECTOR_INDEX = {"DEFAULT": MARKET_TICKER}
