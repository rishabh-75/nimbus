"""Tests for nimbus_v3.data.price_loader.PriceLoader.

``yfinance`` is patched out; the tests exercise cache behaviour, the TTL
policy, and the yfinance-response normaliser on representative payloads.
"""
from __future__ import annotations

from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

import pandas as pd
import pytest

from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.price_loader import PriceLoader


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _yf_frame(n: int = 10, *, start: str = "2024-01-01") -> pd.DataFrame:
    idx = pd.bdate_range(start=start, periods=n)
    return pd.DataFrame(
        {
            "Open":   [100.0 + i for i in range(n)],
            "High":   [101.0 + i for i in range(n)],
            "Low":    [ 99.0 + i for i in range(n)],
            "Close":  [100.5 + i for i in range(n)],
            "Volume": [1_000_000 for _ in range(n)],
        },
        index=idx,
    )


def _multi_index_yf_frame(n: int = 10) -> pd.DataFrame:
    """yfinance returns a MultiIndex when given a list, even of one."""
    base = _yf_frame(n)
    base.columns = pd.MultiIndex.from_product([base.columns, ["RELIANCE.NS"]])
    return base


@pytest.fixture
def cache(tmp_path: Path) -> ParquetCache:
    return ParquetCache(base_dir=tmp_path / "price")


@pytest.fixture
def loader(cache: ParquetCache) -> PriceLoader:
    return PriceLoader(cache, default_years=2, default_cache_ttl=timedelta(hours=20))


# ══════════════════════════════════════════════════════════════════════════════
# Load: cache miss → fetch → cache hit
# ══════════════════════════════════════════════════════════════════════════════

def test_cache_miss_triggers_fetch_and_caches(loader: PriceLoader) -> None:
    with patch("nimbus_v3.data.price_loader.yf.download", return_value=_yf_frame(10)) as mock_dl:
        df = loader.load("RELIANCE")
        assert mock_dl.call_count == 1
        assert not df.empty
        assert list(df.columns) == ["Open", "High", "Low", "Close", "Volume"]
    # Second call — cache hit, no new download.
    with patch("nimbus_v3.data.price_loader.yf.download") as mock_dl:
        df2 = loader.load("RELIANCE")
        mock_dl.assert_not_called()
        pd.testing.assert_frame_equal(df2, df, check_freq=False)


def test_force_refresh_bypasses_cache(loader: PriceLoader) -> None:
    first = _yf_frame(5)
    second = _yf_frame(8, start="2024-02-01")
    with patch("nimbus_v3.data.price_loader.yf.download", side_effect=[first, second]) as mock_dl:
        loader.load("TCS")
        df2 = loader.load("TCS", force_refresh=True)
        assert mock_dl.call_count == 2
        assert len(df2) == 8


def test_stale_cache_is_refreshed(loader: PriceLoader) -> None:
    """With a very short open-market TTL, the second call should hit
    yfinance again. Market is patched open so the age-based refetch
    path is exercised (closed hours serve from cache regardless of
    age — that's covered by test_closed_hours_serves_cache)."""
    short = PriceLoader(
        loader._cache,
        default_years=2,
        default_cache_ttl=timedelta(milliseconds=1),
    )
    with patch("nimbus_v3.data.price_loader.is_market_open", return_value=True), \
         patch("nimbus_v3.data.price_loader.yf.download",
               return_value=_yf_frame(5)) as mock_dl:
        short.load("INFY")
        import time
        time.sleep(0.01)
        short.load("INFY")
        assert mock_dl.call_count == 2


def test_closed_hours_serves_cache_regardless_of_age(loader: PriceLoader) -> None:
    """During closed hours a cached symbol is served as-is — no age
    check, no refetch — even with a 1ms open-market TTL. Closed-hours
    freshness is owned by the startup bulk refresh, not per-symbol."""
    short = PriceLoader(
        loader._cache,
        default_years=2,
        default_cache_ttl=timedelta(milliseconds=1),
    )
    with patch("nimbus_v3.data.price_loader.is_market_open", return_value=False), \
         patch("nimbus_v3.data.price_loader.yf.download",
               return_value=_yf_frame(5)) as mock_dl:
        short.load("INFY")            # primes cache (1 fetch)
        import time
        time.sleep(0.01)
        short.load("INFY")            # served from cache, no 2nd fetch
        assert mock_dl.call_count == 1


def test_closed_hours_fetches_uncached_symbol(loader: PriceLoader) -> None:
    """The one closed-hours fetch path: a symbol with no cache at all
    is fetched once so it's viewable."""
    fresh = PriceLoader(loader._cache, default_years=2)
    with patch("nimbus_v3.data.price_loader.is_market_open", return_value=False), \
         patch("nimbus_v3.data.price_loader.yf.download",
               return_value=_yf_frame(5)) as mock_dl:
        df = fresh.load("NEWSYM")
        assert not df.empty
        assert mock_dl.call_count == 1


def test_empty_fetch_falls_back_to_stale_cache(loader: PriceLoader) -> None:
    """If yfinance returns empty and we have any cache, return the cache —
    stale beats nothing."""
    with patch("nimbus_v3.data.price_loader.yf.download", return_value=_yf_frame(5)):
        loader.load("RELIANCE")  # prime the cache
    # Force a fresh fetch that comes back empty.
    with patch("nimbus_v3.data.price_loader.yf.download", return_value=pd.DataFrame()):
        df = loader.load("RELIANCE", force_refresh=True)
    assert not df.empty
    assert len(df) == 5


def test_empty_fetch_with_no_cache_returns_empty(loader: PriceLoader) -> None:
    with patch("nimbus_v3.data.price_loader.yf.download", return_value=pd.DataFrame()):
        df = loader.load("NOPE")
    assert df.empty


def test_yfinance_exception_returns_empty(loader: PriceLoader) -> None:
    with patch("nimbus_v3.data.price_loader.yf.download",
                 side_effect=RuntimeError("network on fire")):
        df = loader.load("RELIANCE")
    assert df.empty


# ══════════════════════════════════════════════════════════════════════════════
# Normalisation
# ══════════════════════════════════════════════════════════════════════════════

def test_normalize_flattens_multi_index_columns(loader: PriceLoader) -> None:
    with patch("nimbus_v3.data.price_loader.yf.download",
                 return_value=_multi_index_yf_frame(10)):
        df = loader.load("RELIANCE")
    assert list(df.columns) == ["Open", "High", "Low", "Close", "Volume"]


def test_normalize_drops_adj_close() -> None:
    raw = _yf_frame(5)
    raw["Adj Close"] = raw["Close"]
    normalised = PriceLoader._normalize(raw)
    assert "Adj Close" not in normalised.columns


def test_normalize_tz_naive_and_sorted() -> None:
    raw = _yf_frame(5)
    raw.index = raw.index.tz_localize("UTC")
    # Shuffle.
    raw = raw.sample(frac=1.0, random_state=0)
    out = PriceLoader._normalize(raw)
    assert out.index.tz is None
    assert out.index.is_monotonic_increasing


def test_normalize_drops_all_nan_rows() -> None:
    raw = _yf_frame(5)
    raw.iloc[2] = float("nan")  # inject an all-NaN row
    out = PriceLoader._normalize(raw)
    assert len(out) == 4


# ══════════════════════════════════════════════════════════════════════════════
# Batch + introspection
# ══════════════════════════════════════════════════════════════════════════════

def test_load_batch(loader: PriceLoader) -> None:
    with patch("nimbus_v3.data.price_loader.yf.download",
                 side_effect=[_yf_frame(5), _yf_frame(7), pd.DataFrame()]):
        out = loader.load_batch(["A", "B", "C"])
    assert set(out.keys()) == {"A", "B", "C"}
    assert not out["A"].empty and not out["B"].empty
    assert out["C"].empty


def test_is_cached_and_cache_age(loader: PriceLoader) -> None:
    assert loader.is_cached("Z") is False
    assert loader.cache_age("Z") is None
    with patch("nimbus_v3.data.price_loader.yf.download", return_value=_yf_frame(3)):
        loader.load("Z")
    assert loader.is_cached("Z") is True
    age = loader.cache_age("Z")
    assert age is not None and age >= timedelta()


def test_empty_symbol_rejected(loader: PriceLoader) -> None:
    with pytest.raises(ValueError):
        loader.load("")


# ══════════════════════════════════════════════════════════════════════════════
# Regression: end parameter is IST-today + 1 day (not UTC-today)
#
# yfinance's ``end`` is exclusive. Passing ``today`` gave us bars up
# to ``today - 1`` — the bug that made the EOD label show yesterday's
# date on fresh days.
# ══════════════════════════════════════════════════════════════════════════════

class TestEndParamCoversToday:

    def test_end_is_today_plus_one(self, loader: PriceLoader) -> None:
        """end should be IST-today + 1 day so today's bar is
        included in yfinance's response."""
        from datetime import date, timedelta, timezone
        with patch(
            "nimbus_v3.data.price_loader.yf.download",
            return_value=_yf_frame(5),
        ) as mock_dl:
            loader.load("RELIANCE", force_refresh=True)

        assert mock_dl.called
        kwargs = mock_dl.call_args.kwargs
        end_str = kwargs["end"]
        end_date = date.fromisoformat(end_str)

        # End should be today or tomorrow (IST) — never yesterday.
        # We check against a [today_utc - 1, today_utc + 2] window to
        # tolerate both (a) UTC-vs-IST boundary at run time and
        # (b) yfinance's end-exclusivity buffer.
        from datetime import datetime
        today_ist = datetime.now(
            tz=timezone(timedelta(hours=5, minutes=30)),
        ).date()
        assert end_date >= today_ist, (
            f"end={end_date} must be >= today_ist={today_ist} "
            f"to include today's bar (yfinance end is exclusive)"
        )

    def test_end_uses_ist_not_utc(self, loader: PriceLoader) -> None:
        """At 23:00 UTC on day N, IST is already N+1 at 04:30.
        The loader's ``end`` must reflect IST-now so operators
        loading the app late-evening IST still get today's bar."""
        from datetime import datetime, timedelta, timezone

        # Simulate a moment where UTC and IST disagree on "today":
        # 2026-04-22 20:00 UTC == 2026-04-23 01:30 IST.
        class _FakeDT(datetime):
            @classmethod
            def now(cls, tz=None):
                fixed_utc = datetime(2026, 4, 22, 20, 0, tzinfo=timezone.utc)
                return fixed_utc.astimezone(tz) if tz else fixed_utc

        with patch("nimbus_v3.data.price_loader.datetime", _FakeDT):
            with patch(
                "nimbus_v3.data.price_loader.yf.download",
                return_value=_yf_frame(5),
            ) as mock_dl:
                loader.load("RELIANCE", force_refresh=True)

        kwargs = mock_dl.call_args.kwargs
        end_date = datetime.fromisoformat(kwargs["end"]).date()

        # IST-today at the fake moment is 2026-04-23. end = IST-today
        # + 1 day = 2026-04-24. A UTC-based implementation would
        # have computed 2026-04-23 (UTC-today + 1).
        assert end_date == datetime(2026, 4, 24).date(), (
            f"Expected end=2026-04-24 (IST-today+1), got {end_date}. "
            f"The loader is likely using UTC-now instead of IST-now."
        )
