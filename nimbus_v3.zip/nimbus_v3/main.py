"""NIMBUS · Emerald Slate · v3 Qt Desktop Dashboard (slim profile).

Entry point: logging → pyqtgraph config → splash → imports → MainWindow.

Pattern (preserved from oracle):
- Logging configured FIRST (before any other imports that might log)
- pyqtgraph global config set BEFORE any UI imports
- Splash visible BEFORE the heavy nimbus_v3.ui imports
- Bundled JetBrains Mono fonts loaded from assets/
- Splash visible for at least 2 seconds total

Slim profile (post-refactor)
────────────────────────────
- No strategies / scanner / conviction / macro / mode-toggle imports.
- Two tabs: Dashboard (sidebar-driven) + Market Pulse (independent).
- NSE client warm + Options / Sector / VIX / Filing providers are
  built lazily on first use rather than eagerly at startup.
- The panel load + enrich pass still happens behind the splash so
  Market Pulse opens with data on the first click.

Usage
─────
    python main.py
    python main.py --auto-refresh-interval 60   # 60s ticks during market hours
    python main.py --no-panel-prewarm           # skip the eager panel load
    python main.py --panel-refresh-hours 24     # bulk-refresh weekend panel every 24h
    python main.py --panel-refresh-hours 9999   # never bulk-refresh
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from datetime import timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path

# ── Logging (configured FIRST — before any other imports that log) ───────────
_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))    # so `from nimbus_v3...` works

from nimbus_v3.data.paths import data_root as _data_root

_log_dir = _data_root()
_log_dir.mkdir(parents=True, exist_ok=True)
_log_path = _log_dir / "nimbus.log"

_handler = RotatingFileHandler(
    str(_log_path),
    maxBytes=5 * 1024 * 1024,
    backupCount=3,
)
logging.basicConfig(
    handlers=[_handler, logging.StreamHandler(sys.stdout)],
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("nimbus")
logger.info("NIMBUS v3 starting — log path: %s", _log_path)

import os as _os

_env_data_dir = _os.environ.get("NIMBUS_DATA_DIR")
if _env_data_dir:
    logger.info(
        "data_root: %s (NIMBUS_DATA_DIR=%s)",
        _data_root().resolve(), _env_data_dir,
    )
else:
    logger.info(
        "data_root: %s (NIMBUS_DATA_DIR unset — using project-relative ./data)",
        _data_root().resolve(),
    )

# ── pyqtgraph global config (BEFORE any nimbus_v3.ui imports) ────────────────
try:
    import pyqtgraph as pg

    pg.setConfigOptions(
        background="#0D1117",    # SURFACE — matches Emerald Slate theme
        foreground="#64748B",    # MUTED
        antialias=True,
    )
    logger.info("pyqtgraph: global config set ✓")
except ImportError:
    logger.warning("pyqtgraph not available — chart widgets will fail to render")

# ── Qt imports (lightweight) ──────────────────────────────────────────────
from PyQt6.QtCore import QEventLoop, Qt, QTimer
from PyQt6.QtGui import QColor, QFont, QFontDatabase, QPainter, QPixmap
from PyQt6.QtWidgets import QApplication, QSplashScreen


# ══════════════════════════════════════════════════════════════════════════════
# Font + splash
# ══════════════════════════════════════════════════════════════════════════════


def _load_fonts() -> int:
    """Load bundled JetBrains Mono from assets/ via QFontDatabase.

    Returns the number of font files successfully loaded. The Emerald
    Slate theme requests "JetBrains Mono" by name; if loading fails,
    Qt falls back to the platform default monospace which is acceptable
    but visually inferior.
    """
    assets_dir = _PROJECT_ROOT / "assets"
    loaded = 0
    for fname in ("JetBrainsMono-Regular.ttf", "JetBrainsMono-Bold.ttf"):
        path = assets_dir / fname
        if not path.exists():
            logger.info("Font file not found (optional): %s", path)
            continue
        fid = QFontDatabase.addApplicationFont(str(path))
        if fid >= 0:
            families = QFontDatabase.applicationFontFamilies(fid)
            logger.info("Loaded font: %s → %s", fname, families)
            loaded += 1
        else:
            logger.warning("Failed to load font: %s", path)
    return loaded


def _show_splash(app: QApplication, font_name: str) -> QSplashScreen:
    """Create and show the startup splash."""
    pixmap = QPixmap(420, 140)
    pixmap.fill(QColor("#0D1117"))    # SURFACE
    painter = QPainter(pixmap)
    painter.setPen(QColor("#10B981"))    # EM
    painter.setFont(QFont(font_name, 18))
    painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "NIMBUS")
    painter.setPen(QColor("#64748B"))    # MUTED
    painter.setFont(QFont(font_name, 9))
    painter.drawText(
        pixmap.rect().adjusted(0, 50, 0, 0),
        Qt.AlignmentFlag.AlignCenter,
        "Loading...",
    )
    painter.end()

    splash = QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    splash.show()
    splash.raise_()
    splash.activateWindow()
    splash.repaint()
    app.processEvents()
    app.processEvents()    # double pump — macOS needs extra event processing
    return splash


def _splash_msg(splash: QSplashScreen, app: QApplication, msg: str) -> None:
    logger.info("splash: %s", msg)
    splash.showMessage(
        f"  {msg}",
        Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft,
        QColor("#64748B"),
    )
    splash.repaint()
    app.processEvents()


# ══════════════════════════════════════════════════════════════════════════════
# Argument parsing
# ══════════════════════════════════════════════════════════════════════════════


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="nimbus",
        description="NIMBUS v3 — Emerald Slate Qt Dashboard",
    )
    parser.add_argument(
        "--auto-refresh-interval",
        type=int,
        default=0,
        metavar="SECONDS",
        help=(
            "Auto-refresh interval in seconds for the currently-loaded "
            "symbol. 0 (default) disables — symbol data is only loaded "
            "when the operator clicks REFRESH or picks a new symbol. Any "
            "positive value starts a background QTimer that re-requests "
            "price + options every N seconds during NSE market hours."
        ),
    )
    parser.add_argument(
        "--no-panel-prewarm",
        action="store_true",
        help=(
            "Skip the eager panel load behind the splash. Market Pulse "
            "will then load on first tab open (cold start)."
        ),
    )
    parser.add_argument(
        "--panel-refresh-hours",
        type=float,
        default=12.0,
        metavar="HOURS",
        help=(
            "How old the panel-level marker can be before a bulk "
            "refresh fires when NSE is closed. Default 12 — covers "
            "weekend operators who want one consistent refresh per "
            "session. During trading hours the per-symbol 4h TTL "
            "handles freshness regardless of this flag. Pass a very "
            "large value (e.g. 9999) to effectively disable bulk "
            "refresh."
        ),
    )
    parser.add_argument(
        "--initial-symbol",
        type=str,
        default="RELIANCE",
        help=(
            "Symbol to auto-load after the window appears. Default "
            "RELIANCE — yfinance fetches it cleanly under .NS suffix; "
            "NSE indices (NIFTY/BANKNIFTY/etc) don't fetch and aren't "
            "in the tradeable universe."
        ),
    )
    return parser.parse_args()


# ══════════════════════════════════════════════════════════════════════════════
# Lazy builders — closures returned to MainWindow for first-use construction
# ══════════════════════════════════════════════════════════════════════════════


def _make_options_builder():
    """Return a zero-arg callable that builds an OptionsContextProvider.

    Defers all NSE/options imports until first invocation so the
    startup path doesn't pay for symbols that may never be looked at.
    """
    def _build():
        from nimbus_v3.context.options_context import OptionsContextProvider
        from nimbus_v3.data.cache import ParquetCache
        from nimbus_v3.data.nse_client import get_shared_client
        from nimbus_v3.data.options_loader import OptionsLoader
        from nimbus_v3.data.paths import cache_dir

        loader = OptionsLoader(
            get_shared_client(),
            ParquetCache(cache_dir("options")),
        )
        return OptionsContextProvider(loader)

    return _build


# ══════════════════════════════════════════════════════════════════════════════
# Panel loader — closure that yfinance-fetches + enriches the FNO universe
# ══════════════════════════════════════════════════════════════════════════════


def _make_panel_loader(
    compute_engine,
    *,
    panel_refresh_interval: timedelta | None = None,
):
    """Return a zero-arg callable that returns ``(panel, universe)``.

    On first call: walks the symbols listed in the industry DB
    (:func:`nimbus_v3.data.industry_db.load_industry_db`), fetches
    OHLCV via the price cache, enriches each frame, and builds a
    :class:`Universe` from the same DB. Idempotent — caches the
    result.

    Bulk-refresh policy
    ───────────────────
    Per-symbol freshness is decided by :class:`PriceLoader`'s
    market-aware TTL (4h during NSE hours, 7d when closed). That
    handles intraday refreshes well but doesn't address weekend
    panel-coherence: each symbol's parquet expires independently,
    so the panel ends up with bars from different fetch times.

    To produce a single coherent weekend snapshot, the loader
    additionally consults the panel-level marker
    (:mod:`nimbus_v3.data.panel_refresh`). When markets are closed
    AND the marker is older than ``panel_refresh_interval``, the
    loader fetches every symbol via ``force_refresh=True`` so the
    entire panel reflects the same yfinance snapshot. The marker
    is then touched so subsequent app launches within the window
    skip the bulk refresh.

    During trading hours the panel-level check is bypassed —
    per-symbol TTL is the right granularity intraday (you don't
    want to wait for 470 yfinance calls every time you re-open
    the app at 11:00 IST).

    NSE indices (NIFTY, BANKNIFTY, FINNIFTY, etc.) are deliberately
    NOT in the loader's iteration set: they don't fetch cleanly via
    yfinance under ``.NS`` and aren't in the ride-strategy scope.

    Failures degrade gracefully — symbols that don't fetch are
    omitted from the returned panel; the universe is built from
    whatever industry-DB metadata is available.

    Empty industry DB → empty panel + empty universe. The user's
    next move is to run ``scripts/build_industry_db.py``.

    Args:
        compute_engine: ``StrategyComputeEngine`` used to enrich
            raw OHLCV.
        panel_refresh_interval: How old the panel-level marker can
            be before a bulk refresh fires (only when markets are
            closed). ``None`` uses
            :data:`DEFAULT_PANEL_REFRESH_INTERVAL` (12h). Pass a
            very large timedelta to effectively disable bulk
            refresh.
    """
    if panel_refresh_interval is None:
        from nimbus_v3.data.panel_refresh import DEFAULT_PANEL_REFRESH_INTERVAL
        panel_refresh_interval = DEFAULT_PANEL_REFRESH_INTERVAL

    _cache: dict = {}

    def _load():
        if "panel" in _cache:
            return _cache["panel"], _cache["universe"]

        import time as _t

        from nimbus_v3.core.market_session import is_market_open
        from nimbus_v3.core.universe import SymbolMeta, Universe
        from nimbus_v3.data.cache import ParquetCache
        from nimbus_v3.data.enriched_cache import EnrichedPanelCache
        from nimbus_v3.data.industry_db import load_industry_db
        from nimbus_v3.data.panel_refresh import (
            mark_panel_refreshed, panel_age, panel_needs_refresh,
        )
        from nimbus_v3.data.paths import cache_dir
        from nimbus_v3.data.price_loader import PriceLoader
        import pandas as pd

        t0 = _t.perf_counter()

        ind_db = load_industry_db()
        symbol_list = sorted(ind_db.keys())
        if not symbol_list:
            logger.warning(
                "panel_loader: industry DB is empty — universe will be "
                "empty too. Run scripts/build_industry_db.py to populate."
            )

        # Two caches: raw price + per-schema enriched.
        raw_cache = ParquetCache(base_dir=cache_dir("equity_price"))
        enriched_cache = EnrichedPanelCache(
            raw_cache=raw_cache,
            schema_hash=compute_engine.enrichment_schema_hash(),
        )
        price_loader = PriceLoader(raw_cache, default_years=2)

        # Decide whether to do a bulk refresh. Only fires when the
        # market is closed AND the panel marker is stale — during
        # trading hours per-symbol TTL handles freshness.
        market_closed = not is_market_open()
        do_bulk_refresh = (
            market_closed
            and panel_needs_refresh(panel_refresh_interval)
        )
        if do_bulk_refresh:
            age = panel_age()
            age_label = (
                "never" if age is None
                else f"{age.total_seconds() / 3600:.1f}h ago"
            )
            logger.info(
                "panel: bulk refresh triggered (market closed, "
                "last refresh %s, threshold %s)",
                age_label, panel_refresh_interval,
            )

        panel: dict[str, pd.DataFrame] = {}
        n_hits = 0
        n_misses = 0
        n_failed = 0
        n_force_refreshed = 0

        for sym in symbol_list:
            if do_bulk_refresh:
                # Bypass both the enriched cache and the per-symbol
                # TTL. Force-fetch from yfinance so every symbol in
                # the panel reflects the same snapshot.
                try:
                    raw = price_loader.load(sym, force_refresh=True)
                    if raw.empty or len(raw) < compute_engine.MIN_BARS_REQUIRED:
                        n_failed += 1
                        continue
                    enriched = compute_engine.enrich(raw, sym)
                    enriched_cache.set(sym, enriched)
                    panel[sym] = enriched
                    n_force_refreshed += 1
                except Exception:    # noqa: BLE001
                    n_failed += 1
                    continue
                continue

            # Fast path: enriched cache hit with fresh raw underneath.
            hit = enriched_cache.get_if_fresh(sym)
            if hit is not None:
                panel[sym] = hit
                n_hits += 1
                continue
            try:
                raw = price_loader.load(sym)
                if raw.empty or len(raw) < compute_engine.MIN_BARS_REQUIRED:
                    n_failed += 1
                    continue
                enriched = compute_engine.enrich(raw, sym)
                enriched_cache.set(sym, enriched)
                panel[sym] = enriched
                n_misses += 1
            except Exception:    # noqa: BLE001
                n_failed += 1
                continue

        # Update the panel marker only when a bulk refresh actually
        # happened. If we used the per-symbol fast paths, the marker
        # stays at its prior value — that prevents the case where
        # opening the app twice in 12h would skip the bulk refresh
        # forever.
        if do_bulk_refresh:
            mark_panel_refreshed()

        # Universe — built from the industry DB. We don't hit live
        # NSE here. Synthetic ``built_at`` keeps Universe post_init
        # happy.
        symbols: dict[str, SymbolMeta] = {}
        for sym in symbol_list:
            ic = ind_db[sym]
            symbols[sym] = SymbolMeta(
                symbol=sym,
                macro_sector=ic.macro_sector or "Unknown",
                sector=ic.sector or "Unknown",
                industry=ic.industry or "Unknown",
                basic_industry=ic.basic_industry or "Unknown",
            )
        universe = Universe(
            symbols=symbols, built_at=pd.Timestamp.now("UTC"),
        )

        _cache["panel"] = panel
        _cache["universe"] = universe

        elapsed = _t.perf_counter() - t0
        if do_bulk_refresh:
            logger.info(
                "panel: %d enriched (%d force-refreshed, %d failed) "
                "from %d DB symbols in %.2fs [bulk refresh]",
                len(panel), n_force_refreshed, n_failed, len(symbol_list),
                elapsed,
            )
        else:
            logger.info(
                "panel: %d enriched (%d hits, %d misses, %d failed) "
                "from %d DB symbols in %.2fs",
                len(panel), n_hits, n_misses, n_failed, len(symbol_list),
                elapsed,
            )
        return panel, universe

    return _load


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════


def main() -> int:
    args = _parse_args()

    app = QApplication(sys.argv)
    app.setApplicationName("NIMBUS")
    app.setOrganizationName("NIMBUS")

    # ── Phase 0: Fonts ────────────────────────────────────────────────────
    _load_fonts()
    mono_available = "JetBrains Mono" in QFontDatabase.families()
    if mono_available:
        logger.info("JetBrains Mono: available ✓")
    else:
        logger.warning("JetBrains Mono: NOT available — using platform fallback")
    font_name = "JetBrains Mono" if mono_available else "Courier"

    # ── Phase 1: Splash ──────────────────────────────────────────────────
    splash = _show_splash(app, font_name)
    t0 = time.time()

    # ── Phase 2: Core compute engine ──────────────────────────────────────
    _splash_msg(splash, app, "Building compute engine...")
    from nimbus_v3.compute.engine import StrategyComputeEngine

    compute = StrategyComputeEngine()
    logger.info(
        "Compute engine ready (schema_hash=%s)",
        compute.enrichment_schema_hash(),
    )

    # Panel loader closure — heavy work runs on first call.
    panel_loader = _make_panel_loader(
        compute,
        panel_refresh_interval=timedelta(hours=args.panel_refresh_hours),
    )

    # ── Phase 3: Industry map (cheap — single JSON read) ─────────────────
    _splash_msg(splash, app, "Loading industry classifications...")
    from nimbus_v3.data.industry_db import load_industry_db

    industry_map = {
        sym: rec.industry for sym, rec in load_industry_db().items()
    }
    logger.info("industry_map: %d entries", len(industry_map))

    # ── Phase 4: DataManager (price + options workers) ────────────────────
    _splash_msg(splash, app, "Building data manager...")
    data_manager = None
    try:
        from nimbus_v3.data.cache import ParquetCache
        from nimbus_v3.data.data_manager import DataManager
        from nimbus_v3.data.nse_client import get_shared_client
        from nimbus_v3.data.options_loader import OptionsLoader
        from nimbus_v3.data.paths import cache_dir
        from nimbus_v3.data.price_loader import PriceLoader

        dm_price_loader = PriceLoader(
            ParquetCache(cache_dir("equity_price")),
            default_years=2,
            yfinance_suffix=".NS",
        )
        dm_options_loader = OptionsLoader(
            get_shared_client(),
            ParquetCache(cache_dir("options")),
        )
        data_manager = DataManager(
            price_loader=dm_price_loader,
            options_loader=dm_options_loader,
        )
        logger.info("DataManager: async loader ready")
    except Exception:    # noqa: BLE001
        logger.exception(
            "DataManager construction failed — MainWindow will fall back "
            "to synchronous panel-only render"
        )

    # Options provider builder — built on first need, not now.
    options_builder = _make_options_builder()

    # ── Phase 5: Pre-warm panel behind the splash (optional) ─────────────
    if not args.no_panel_prewarm:
        _splash_msg(splash, app, "Loading equity panel...")
        try:
            panel_loader()    # populates the closure cache
        except Exception:    # noqa: BLE001
            logger.exception("Pre-warm panel load failed — continuing")

    # ── Ensure splash visible for at least 2s total ───────────────────────
    elapsed = time.time() - t0
    remaining = max(0.0, 2.0 - elapsed)
    if remaining > 0:
        loop = QEventLoop()
        QTimer.singleShot(int(remaining * 1000), loop.quit)
        loop.exec()

    # ── Phase 6: Build window ────────────────────────────────────────────
    _splash_msg(splash, app, "Building interface...")
    from nimbus_v3.ui.main_window import MainWindow

    window = MainWindow(
        compute_engine=compute,
        panel_loader=panel_loader,
        data_manager=data_manager,
        options_builder=options_builder,
        industry_map=industry_map,
        auto_refresh_interval_sec=args.auto_refresh_interval,
    )

    splash.close()
    window.show()
    window.auto_load_initial(args.initial_symbol)
    logger.info("MainWindow shown — initial symbol: %s", args.initial_symbol)

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
