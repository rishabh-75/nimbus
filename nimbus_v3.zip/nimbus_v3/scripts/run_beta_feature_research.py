"""scripts/run_beta_feature_research.py — beta-vs-industry + alpha research.

Research harness for testing whether a stock's beta to its own
industry, combined with the industry's current phase, produces
forward-return edge.

The hypothesis (from turn 14 discussion):

  beta > 1.2 AND industry in MID/LATE → trend amplifier, positive edge
  beta < 0.8 AND industry in MID/LATE → sector laggard, negative edge
  beta > 1.2 AND industry = EUPHORIA  → reversal amplifier, negative edge
  beta < 0.8 AND industry = DECLINE   → defensive holder, positive edge

Plus alpha-based:
  alpha in top decile → systematic outperformer, positive persistence
  alpha in bottom decile → systematic laggard, negative persistence

Methodology notes
-----------------
1. Leave-one-out industry returns: for each stock and each bar, the
   industry return used is the mean of the OTHER members' returns.
   Avoids the trivial self-correlation on small industries.

2. Minimum 5 industry members. Below that, industry return is
   dominated by 1-2 stocks and beta is not meaningful.

3. 60-day rolling beta / alpha window. Standard choice — long enough
   for coefficient stability, short enough to reflect current regime.

4. Industry phase at each bar: the industry's equal-weight index is
   built as a time series (sum of member prices, normalised), then
   run through the same vectorised classifier used for stocks. The
   result is a per-bar phase label for each industry.

Run::

    python scripts/run_beta_feature_research.py

Writes:
  - data/beta_feature_research.csv
  - stdout report
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nimbus_v3.analysis.trend_phase import PhaseThresholds, TrendPhase   # noqa: E402
from nimbus_v3.data.industry_db import load_industry_db                  # noqa: E402
from nimbus_v3.research.equity_universe import load_equity_panel         # noqa: E402
from scripts.run_phase_calibration import (                              # noqa: E402
    compute_features, classify_rows,
)

logging.basicConfig(format="%(message)s", level=logging.INFO)
log = logging.getLogger("beta_research")


BETA_WINDOW = 60        # rolling window for beta/alpha estimation
MIN_INDUSTRY_SIZE = 5   # below this, beta-vs-industry is self-correlation


# ══════════════════════════════════════════════════════════════════════
# Industry return + phase computation
# ══════════════════════════════════════════════════════════════════════

def build_industry_returns_and_phase(
    panel: dict[str, pd.DataFrame],
    industry_map: dict[str, str],
) -> tuple[dict[str, pd.Series], dict[str, pd.Series], dict[str, list[str]]]:
    """For each industry, build (a) a per-bar total-return series used
    for leave-one-out stock betas, and (b) a per-bar phase label.

    Returns
    -------
    industry_rets : dict[industry, Series]
        Daily RETURN series (not price) for the industry's equal-weight
        index. Used as the "market return" when computing stock betas.
        We keep per-day returns (not just the total-price series)
        because that's what beta actually regresses against.
    industry_phases : dict[industry, Series]
        Per-bar phase label (string) for the industry's equal-weight
        price index. Used to condition the beta signals.
    industry_members : dict[industry, list[str]]
        Member symbols per industry — needed for leave-one-out.
    """
    # Group symbols by industry
    by_ind: dict[str, list[str]] = {}
    for sym, ind in industry_map.items():
        if sym in panel:
            by_ind.setdefault(ind, []).append(sym)

    industry_rets: dict[str, pd.Series] = {}
    industry_phases: dict[str, pd.Series] = {}
    industry_members: dict[str, list[str]] = {}

    for ind, members in by_ind.items():
        if len(members) < MIN_INDUSTRY_SIZE:
            continue
        # Stack member closes into a wide DataFrame aligned on date
        closes = pd.DataFrame({
            m: panel[m]["Close"] for m in members if "Close" in panel[m].columns
        })
        closes = closes.dropna(how="all")
        if len(closes) < 200:    # need enough history
            continue

        # Equal-weight price index: mean of members, forward-filling
        # missing bars at the member level so one missing stock doesn't
        # drop the index for that day. Short fill window — we only
        # forward-fill up to 5 bars to avoid masking real delisting.
        closes_ff = closes.ffill(limit=5)
        ew_index = closes_ff.mean(axis=1)

        # Industry return series: pct-change on the EW index
        industry_rets[ind] = ew_index.pct_change()

        # Volume series for the industry — sum of member volumes, same ffill
        vols = pd.DataFrame({
            m: panel[m]["Volume"] for m in members
            if "Volume" in panel[m].columns
        })
        vols = vols.ffill(limit=5)
        total_vol = vols.sum(axis=1) if len(vols.columns) else None

        # Build features on the EW index and run classify_rows
        synthetic_df = pd.DataFrame({
            "Close": ew_index,
            "Volume": total_vol if total_vol is not None else 0.0,
        }, index=ew_index.index)
        feats = compute_features(synthetic_df)
        if len(feats) < 100:
            continue
        phase = classify_rows(feats, PhaseThresholds())
        industry_phases[ind] = phase
        industry_members[ind] = members

    log.info("Industries with ≥%d members and sufficient history: %d",
             MIN_INDUSTRY_SIZE, len(industry_members))
    return industry_rets, industry_phases, industry_members


# ══════════════════════════════════════════════════════════════════════
# Per-stock beta, alpha, industry phase
# ══════════════════════════════════════════════════════════════════════

def compute_beta_features(
    panel: dict[str, pd.DataFrame],
    industry_map: dict[str, str],
    industry_rets: dict[str, pd.Series],
    industry_phases: dict[str, pd.Series],
    industry_members: dict[str, list[str]],
) -> pd.DataFrame:
    """For every (symbol, bar) in the panel, compute:
    - beta_vs_industry_60d
    - alpha_vs_industry_60d (mean residual over the same window)
    - industry_phase at that bar
    plus carry forward the classifier features and forward returns
    from compute_features so we can do the ablation in one table.
    """
    all_rows: list[pd.DataFrame] = []
    for sym, df in panel.items():
        ind = industry_map.get(sym)
        if ind is None or ind not in industry_members:
            continue
        if len(industry_members[ind]) < MIN_INDUSTRY_SIZE:
            continue

        # Standard features + forward returns
        feats = compute_features(df)
        if len(feats) < 100:
            continue

        # Stock's own daily returns
        stock_ret = df["Close"].pct_change()

        # Leave-one-out industry return: reconstruct as
        # (total_sum_of_returns - this_stock_return) / (n_members - 1).
        # We can't perfectly leave-one-out without access to raw member
        # returns here, so we approximate: assume the industry return
        # is computed from the full member set (including this stock)
        # and back out the LOO version.
        #
        # Let r_ind = mean(r_i for i in members), n = |members|.
        # LOO industry return for stock j:
        #   r_ind_loo_j = (n * r_ind - r_j) / (n - 1)
        # This is exact when ew_index is the simple mean of members'
        # prices (not returns) — close enough for our purposes given
        # the approximation error is O(1/n) and industries have n ≥ 5.
        n_members = len(industry_members[ind])
        ind_ret_full = industry_rets[ind]
        aligned_stock_ret, aligned_ind_ret = stock_ret.align(
            ind_ret_full, join="inner",
        )
        if len(aligned_stock_ret) < BETA_WINDOW + 10:
            continue
        ind_ret_loo = (
            n_members * aligned_ind_ret - aligned_stock_ret
        ) / (n_members - 1)

        # Rolling covariance and variance for beta
        cov = aligned_stock_ret.rolling(BETA_WINDOW).cov(ind_ret_loo)
        var = ind_ret_loo.rolling(BETA_WINDOW).var()
        beta = cov / var.replace(0, np.nan)

        # Alpha = mean(stock_ret - beta * ind_ret_loo) over the window.
        # Computed as the mean of the residual over the 60d window
        # using the *contemporaneous* beta (so it's self-consistent).
        residual = aligned_stock_ret - beta * ind_ret_loo
        alpha = residual.rolling(BETA_WINDOW).mean()

        # Industry phase aligned to feats index
        ind_phase = industry_phases[ind].reindex(feats.index, method="ffill")

        feats = feats.copy()
        feats["symbol"] = sym
        feats["industry"] = ind
        # Preserve bar_date as an explicit column — downstream scripts
        # (walk-forward validation, period-specific analysis) need to
        # filter by date, but the subsequent reset_index(drop=True)
        # would lose it. Done here rather than post-concat to avoid
        # alignment bugs on very long panels.
        feats["bar_date"] = feats.index
        # Align beta/alpha to feats index
        feats["beta_vs_industry"] = beta.reindex(feats.index)
        feats["alpha_vs_industry"] = alpha.reindex(feats.index)
        feats["industry_phase"] = ind_phase

        all_rows.append(feats)

    out = pd.concat(all_rows, ignore_index=False)
    out = out.reset_index(drop=True)
    log.info("Beta feature table: %d rows (%.0f%% with valid beta)",
             len(out), 100 * out["beta_vs_industry"].notna().mean())
    return out


# ══════════════════════════════════════════════════════════════════════
# Statistics
# ══════════════════════════════════════════════════════════════════════

def welch_t(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    va, vb = a.var(ddof=1), b.var(ddof=1)
    denom = np.sqrt(va / na + vb / nb)
    if denom == 0 or not np.isfinite(denom):
        return float("nan")
    return float((a.mean() - b.mean()) / denom)


def ablate(
    feats: pd.DataFrame, mask: np.ndarray, signature: str, fwd_col: str,
) -> dict:
    fwd = feats[fwd_col].to_numpy()
    valid = np.isfinite(fwd)
    fired = valid & mask
    unfired = valid & ~mask
    f, u = fwd[fired], fwd[unfired]
    return {
        "signature": signature,
        "horizon": fwd_col,
        "n_fired": int(fired.sum()),
        "n_unfired": int(unfired.sum()),
        "fired_pct": float(f.mean() * 100) if len(f) else float("nan"),
        "unfired_pct": float(u.mean() * 100) if len(u) else float("nan"),
        "delta_pp": (
            float((f.mean() - u.mean()) * 100)
            if len(f) and len(u) else float("nan")
        ),
        "t_stat": welch_t(f, u),
    }


def decile_report(feats: pd.DataFrame, feature: str, horizon: str) -> pd.DataFrame:
    valid = feats[np.isfinite(feats[feature]) & np.isfinite(feats[horizon])]
    if len(valid) < 1000:
        return pd.DataFrame()
    deciles = pd.qcut(valid[feature], 10, labels=False, duplicates="drop")
    grouped = (
        valid.assign(decile=deciles)
             .groupby("decile", observed=True)
             .agg(n=(horizon, "size"), mean_fwd=(horizon, "mean"),
                  feature_min=(feature, "min"),
                  feature_max=(feature, "max"))
    )
    grouped["mean_fwd_pct"] = grouped["mean_fwd"] * 100
    return grouped


# ══════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════

def verdict(row: dict, direction: str) -> str:
    """direction: 'positive' means we expect positive edge (accumulator),
    'negative' means we expect negative edge (distribution-style)."""
    if row["n_fired"] < 200:
        return "too few fires"
    d, t = row["delta_pp"], row["t_stat"]
    if np.isnan(d) or np.isnan(t):
        return "n/a"
    if direction == "positive":
        if d >= 0.5 and t >= 2:
            return "STRONG working"
        if d >= 0.2 and t >= 1.5:
            return "weak working"
        if d <= -0.5 and t <= -2:
            return "STRONG CONTRA (opposite direction works)"
        if d <= -0.2 and t <= -1.5:
            return "weak contra"
    else:
        if d <= -0.5 and t <= -2:
            return "STRONG working"
        if d <= -0.2 and t <= -1.5:
            return "weak working"
        if d >= 0.5 and t >= 2:
            return "STRONG CONTRA"
        if d >= 0.2 and t >= 1.5:
            return "weak contra"
    if abs(d) < 0.2 or abs(t) < 1:
        return "noise"
    return "inconclusive"


def print_sig_table(rows: list[dict]) -> None:
    hdr = (
        f"  {'signature':44s}  {'horizon':8s}  {'n_fire':>7s}  {'fired%':>8s}  "
        f"{'kept%':>8s}  {'Δ pp':>8s}  {'t':>7s}  verdict"
    )
    sep = "─" * len(hdr)
    print(sep)
    print(hdr)
    print(sep)
    for r in rows:
        v = r.get("_verdict", "?")
        print(
            f"  {r['signature']:44s}  {r['horizon']:8s}  "
            f"{r['n_fired']:>7,d}  "
            f"{r['fired_pct']:>+7.3f}  {r['unfired_pct']:>+7.3f}  "
            f"{r['delta_pp']:>+7.3f}  {r['t_stat']:>+6.2f}  {v}"
        )
    print(sep)


def print_decile_table(grouped: pd.DataFrame, feature: str, horizon: str) -> None:
    print(f"\nDecile: {feature} vs {horizon}")
    print("─" * 60)
    print(f"  {'dec':>3s}  {'n':>7s}  {'range':>22s}  {'fwd%':>8s}")
    for decile, row in grouped.iterrows():
        rng = f"{row['feature_min']:+7.3f} to {row['feature_max']:+7.3f}"
        print(
            f"  {decile:>3}  {int(row['n']):>7,d}  {rng:>22s}  "
            f"{row['mean_fwd_pct']:>+7.3f}"
        )
    spread = grouped.iloc[-1]["mean_fwd_pct"] - grouped.iloc[0]["mean_fwd_pct"]
    print(f"  Spread (top decile − bottom decile): {spread:+.3f}pp")
    print("─" * 60)


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    log.info("Loading equity panel …")
    panel = load_equity_panel(verbose=False)
    log.info("Panel: %d symbols", len(panel))

    log.info("Loading industry DB …")
    ind_db = load_industry_db()
    if not ind_db:
        log.error("Industry DB empty — run scripts/build_industry_db.py first")
        sys.exit(1)

    # Use the finer "industry" level (~40 groups) — sector is too coarse
    # (~20 groups) and basic_industry too fine (~120 groups, many tiny).
    industry_map = {sym: rec.industry for sym, rec in ind_db.items()}

    log.info("Building industry return + phase series …")
    industry_rets, industry_phases, industry_members = (
        build_industry_returns_and_phase(panel, industry_map)
    )

    log.info("Computing per-stock beta / alpha / industry-phase …")
    feats = compute_beta_features(
        panel, industry_map, industry_rets, industry_phases, industry_members,
    )

    # Drop rows with no beta (early history)
    feats = feats[feats["beta_vs_industry"].notna()].copy()
    log.info("Valid rows for ablation: %d", len(feats))

    # ── Decile reports: do the raw features separate fwd returns?
    print("\n" + "═" * 72)
    print("DECILE REPORTS — raw feature → forward return")
    print("═" * 72)
    for feature in ("beta_vs_industry", "alpha_vs_industry"):
        for horizon in ("fwd_10d", "fwd_20d"):
            grouped = decile_report(feats, feature, horizon)
            if len(grouped):
                print_decile_table(grouped, feature, horizon)

    # ── Conditional signatures: beta × industry phase
    print("\n" + "═" * 72)
    print("CONDITIONAL BETA × INDUSTRY PHASE")
    print("═" * 72)
    print("Direction: 'pos' = expect positive edge; 'neg' = expect negative edge.")

    beta = feats["beta_vs_industry"].to_numpy()
    ind_phase = feats["industry_phase"].to_numpy().astype(str)

    # Threshold candidates: beta high (>1.2), low (<0.8), very high (>1.5)
    rows: list[dict] = []
    signatures = [
        # (name, mask_fn, direction_hypothesis)
        ("beta>1.2 AND industry in (MID,LATE)",
         lambda: (beta > 1.2) & np.isin(ind_phase, ["MID", "LATE"]),
         "positive"),
        ("beta<0.8 AND industry in (MID,LATE)",
         lambda: (beta < 0.8) & np.isin(ind_phase, ["MID", "LATE"]),
         "negative"),
        ("beta>1.2 AND industry = EUPHORIA",
         lambda: (beta > 1.2) & (ind_phase == "EUPHORIA"),
         "negative"),
        ("beta<0.8 AND industry = DECLINE",
         lambda: (beta < 0.8) & (ind_phase == "DECLINE"),
         "positive"),
        ("beta>1.5 AND industry in (MID,LATE)",
         lambda: (beta > 1.5) & np.isin(ind_phase, ["MID", "LATE"]),
         "positive"),
        ("beta<0.5 AND industry = DECLINE",
         lambda: (beta < 0.5) & (ind_phase == "DECLINE"),
         "positive"),
    ]
    for name, mask_fn, direction in signatures:
        mask = mask_fn()
        for horizon in ("fwd_10d", "fwd_20d"):
            r = ablate(feats, mask, name, horizon)
            r["_verdict"] = verdict(r, direction)
            r["_direction"] = direction
            rows.append(r)
    print_sig_table(rows)

    # ── Alpha-based signatures
    print("\n" + "═" * 72)
    print("ALPHA (industry-adjusted residual return) DECILE-BASED SIGNATURES")
    print("═" * 72)

    alpha = feats["alpha_vs_industry"].to_numpy()
    # Top/bottom 20% and 10% of alpha
    alpha_valid = alpha[np.isfinite(alpha)]
    if len(alpha_valid) > 1000:
        a_p90 = np.quantile(alpha_valid, 0.90)
        a_p80 = np.quantile(alpha_valid, 0.80)
        a_p20 = np.quantile(alpha_valid, 0.20)
        a_p10 = np.quantile(alpha_valid, 0.10)
    else:
        a_p90 = a_p80 = a_p20 = a_p10 = 0.0

    alpha_sigs = [
        (f"alpha top 10% (>{a_p90*100:+.3f}%/day)",
         alpha > a_p90, "positive"),
        (f"alpha top 20% (>{a_p80*100:+.3f}%/day)",
         alpha > a_p80, "positive"),
        (f"alpha bottom 20% (<{a_p20*100:+.3f}%/day)",
         alpha < a_p20, "negative"),
        (f"alpha bottom 10% (<{a_p10*100:+.3f}%/day)",
         alpha < a_p10, "negative"),
    ]
    alpha_rows: list[dict] = []
    for name, mask, direction in alpha_sigs:
        for horizon in ("fwd_10d", "fwd_20d"):
            r = ablate(feats, mask, name, horizon)
            r["_verdict"] = verdict(r, direction)
            r["_direction"] = direction
            alpha_rows.append(r)
    print_sig_table(alpha_rows)

    # Persist
    all_rows = rows + alpha_rows
    out_df = pd.DataFrame(all_rows)
    out_path = Path("data/beta_feature_research.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    log.info("\nResults → %s", out_path)

    # Summary
    print("\n" + "═" * 72)
    print("SUMMARY")
    print("═" * 72)
    working = [r for r in all_rows if "working" in r.get("_verdict", "")]
    contra = [r for r in all_rows if "CONTRA" in r.get("_verdict", "")
              or "contra" in r.get("_verdict", "")]

    if working:
        print(f"✓ {len(working)} signature × horizon pair(s) earned expected edge:")
        for r in working:
            print(f"    {r['signature']} @ {r['horizon']}: "
                  f"Δ {r['delta_pp']:+.2f}pp, t={r['t_stat']:+.2f}  ({r['_verdict']})")
    if contra:
        print(f"\n⚠ {len(contra)} signature × horizon pair(s) went the OPPOSITE direction:")
        print("  (hypothesis wrong — but the contra direction itself is tradeable)")
        for r in contra:
            print(f"    {r['signature']} @ {r['horizon']}: "
                  f"Δ {r['delta_pp']:+.2f}pp, t={r['t_stat']:+.2f}  ({r['_verdict']})")
    if not working and not contra:
        print("No signatures earned edge in either direction. Beta-vs-industry")
        print("doesn't predict forward returns on Indian equities at 10-20d horizons.")


if __name__ == "__main__":
    main()
