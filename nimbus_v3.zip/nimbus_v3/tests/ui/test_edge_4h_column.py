"""Edge tab 4h body-above column: tri-state rendering and sorting."""
from __future__ import annotations

import dataclasses

import pytest
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication

from nimbus_v3.compute.equity_edge import (
    EdgeHorizonSet,
    EdgeResult,
    SymbolEdge,
)
from nimbus_v3.ui.widgets.edge_tab import EdgeTab

_FIELDS = [f.name for f in dataclasses.fields(SymbolEdge)]


@pytest.fixture(scope="module")
def qapp():
    yield QApplication.instance() or QApplication([])


def _row(sym, above_4h):
    return SymbolEdge(**{
        n: (sym if n == "symbol" else "Chem" if n == "industry"
            else above_4h if n == "above_4h" else 1.0)
        for n in _FIELDS})


def _tab(rows):
    w = EdgeTab()
    w.set_horizon_set(EdgeHorizonSet(
        results=(EdgeResult(rows=tuple(rows), horizon_days=10, kappa=0.5),),
        default_horizon=10))
    return w


def test_4h_column_exists(qapp):  # noqa: ARG001
    w = _tab([_row("A", True)])
    assert "4h" in w._COLS


def test_tri_state_glyphs(qapp):  # noqa: ARG001
    w = _tab([_row("YES", True), _row("NO", False), _row("UNK", None)])
    m = w._model
    c = w._COLS.index("4h")
    disp = {m.data(m.index(r, w._COLS.index("Symbol"))):
            m.data(m.index(r, c)) for r in range(m.rowCount())}
    assert disp["YES"] == "\u25b2"      # filled triangle
    assert disp["NO"] == "\u2014"       # em dash
    assert disp["UNK"] == "?"           # unknown, distinct from "not above"


def test_unknown_sorts_below_not_above(qapp):  # noqa: ARG001
    """Unknown must rank below a real 'not above', so a data gap never
    floats to the top as if it were a positive."""
    w = _tab([_row("UNK", None), _row("NO", False), _row("YES", True)])
    m = w._model
    c = w._COLS.index("4h")
    w._on_header_clicked(c)             # sort desc
    order = [m.data(m.index(r, w._COLS.index("Symbol")))
             for r in range(m.rowCount())]
    assert order == ["YES", "NO", "UNK"]


def test_defaults_to_unknown_when_field_absent(qapp):  # noqa: ARG001
    """A row built without above_4h (older callers) reads as unknown."""
    w = _tab([_row("A", None)])
    m = w._model
    c = w._COLS.index("4h")
    assert m.data(m.index(0, c)) == "?"


# ── RS-Rev column (display-only reversion candidacy) ────────────────────────
def test_rs_rev_column_tiers_and_sort(qapp):  # noqa: ARG001
    import dataclasses
    from PyQt6.QtCore import Qt
    fields = [f.name for f in dataclasses.fields(SymbolEdge)]

    def row(sym, z):
        return SymbolEdge(**{n: (sym if n == "symbol" else "Chem"
                                 if n == "industry" else z if n == "rs_rev_z"
                                 else 1.0) for n in fields})
    w = EdgeTab()
    w.set_horizon_set(EdgeHorizonSet(
        results=(EdgeResult(rows=(row("STRONG", -2.1), row("MILD", -0.9),
                                  row("NEUT", 0.2), row("NA", None)),
                            horizon_days=10, kappa=0.5),),
        default_horizon=10))
    m = w._model
    c = w._COLS.index("RS-Rev")
    disp = {m.data(m.index(r, w._COLS.index("Symbol"))): m.data(m.index(r, c))
            for r in range(m.rowCount())}
    assert disp["STRONG"].startswith("\u25c4\u25c4")   # strong tier
    assert disp["MILD"].startswith("\u25c4")           # mild tier
    assert disp["NEUT"] == "+0.2"                       # plain
    assert disp["NA"] == "\u2014"                       # unavailable
    # descending sort -> cheapest (most negative z) first, NA last
    w._on_header_clicked(c)
    order = [m.data(m.index(r, w._COLS.index("Symbol")))
             for r in range(m.rowCount())]
    assert order[0] == "STRONG"
    assert order[-1] == "NA"
