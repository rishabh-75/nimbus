"""
ui/scanner_tab.py — Scanner with RS/IVR columns, styled filter chips,
single-click populate, double-click navigate, stale banner.

Patch v5.3 (FIX-ETF):
- ETFs moved to dedicated ETF Momentum tab
- Scanner now equity-only: NIFTY 100, F&O Full, Watchlist
  (both already handled by existing display logic: None → "—")

Phase 1 (FilingsWorker):
- FilingsWorker imported and wired in _on_finished
- _on_filing_enriched patches rows in-place, re-sorts TRAP to top
- _on_filings_done hides progress label
"""

from __future__ import annotations

import logging
import time
from typing import Optional

import pandas as pd

from PyQt6.QtCore import (
    Qt,
    QAbstractTableModel,
    QModelIndex,
    QSortFilterProxyModel,
    pyqtSignal,
)
from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QProgressBar,
    QTableView,
    QHeaderView,
    QSpinBox,
    QSplitter,
    QFrame,
    QFileDialog,
    QAbstractItemView,
)
from PyQt6.QtGui import QFont, QColor, QBrush

from ui.theme import (
    BG, SURFACE, BORDER, EM, RED, GOLD, MUTED, WHITE, GREEN, BLUE,
    FONT_MONO, FONT_UI,
    grade_fg, grade_bg, sizing_fg, verdict_fg,
)
from ui.workers import FilingsWorker
from modules.data import NIFTY100_SYMBOLS, get_universe


logger = logging.getLogger(__name__)

_GRADE_ORD = {"S": 0, "A+": 1, "A": 2, "B+": 3, "B": 4, "C+": 5, "C": 6, "D": 7, "—": 8}

_COLUMNS = [
    ("Symbol", "symbol", 90),
    ("Price", "last_price", 75),
    ("Chg%", "day_chg", 50),
    ("Size", "dm_sizing", 50),
    ("WR", "dm_wr", 45),
    ("MFI", "dm_mfi", 45),
    ("vs SMA", "dm_pct_sma", 60),
    ("DD%", "dm_dd", 50),
    ("Red", "dm_streak", 35),
    ("Vol", "dm_vol_ratio", 45),
    ("ADTV", "adv_cr", 55),
    ("DTE", "dte", 40),
    ("#", "display_rank", 30),
    ("Grade", "dm_grade", 45),
    ("Verdict", "dm_verdict", 400),
]

# Must match SetupType.value strings exactly from setup_classifier.py
_SETUP_PRIORITY = {
    "TRAP": 0,
    "PREBREAKOUT": 1,
    "CONFIRMED": 2,
    "EVENTPLAY": 3,
    "REVERSALWATCH": 4,
    "OPTIONSONLY": 5,
    "CONFIRMEDBREAKDOWN": 6,
    "NEUTRAL": 7,
}

_SETUP_FG = {
    "CONFIRMED": "#10B981",
    "PREBREAKOUT": "#3B82F6",
    "EVENTPLAY": "#34D399",
    "TRAP": "#EF4444",
    "REVERSALWATCH": "#F59E0B",
    "CONFIRMEDBREAKDOWN": "#DC2626",
    "OPTIONSONLY": "#8B5CF6",
    "NEUTRAL": "#64748B",
}

_SETUP_BG = {
    "CONFIRMED": QColor(16, 185, 129, 45),
    "PREBREAKOUT": QColor(59, 130, 246, 45),
    "EVENTPLAY": QColor(52, 211, 153, 35),
    "TRAP": QColor(239, 68, 68, 60),
    "REVERSALWATCH": QColor(245, 158, 11, 40),
    "CONFIRMEDBREAKDOWN": QColor(220, 38, 38, 55),
    "OPTIONSONLY": QColor(139, 92, 246, 40),
}

# ── BB Ride columns (bottom table) ────────────────────────────────────────────
_RIDE_COLUMNS = [
    ("Symbol", "symbol", 90),
    ("Price", "last_price", 75),
    ("Chg%", "day_chg", 50),
    ("Size", "sizing", 50),
    ("%B", "bb_pct", 45),
    ("Vol", "vol_ratio", 45),
    ("vs SMA50", "pct_sma50", 65),
    ("BBW", "bbw", 45),
    ("BBW Δ", "bbw_slope", 50),
    ("ROC%", "roc_10", 50),
    ("ADX", "adx", 45),
    ("ADTV", "adtv", 55),
    ("#", "display_rank", 30),
    ("Grade", "grade", 45),
    ("Verdict", "verdict", 350),
]


def _assign_ranks(rows: list[dict]):
    """Assign display_rank 1,2,3... to entries after sort. Non-entries get 0."""
    rank = 1
    for r in rows:
        if r.get("dm_entry"):
            r["display_rank"] = rank
            rank += 1
        else:
            r["display_rank"] = 0


class TopNFilterProxy(QSortFilterProxyModel):
    """
    Proxy model that filters to show only the top N ranked entries.
    When top_n == 0, shows everything (no filter).
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._top_n = 0  # 0 = show all

    def set_top_n(self, n: int):
        self._top_n = n
        self.invalidateFilter()

    @property
    def top_n(self) -> int:
        return self._top_n

    def filterAcceptsRow(self, source_row, source_parent):
        if self._top_n <= 0:
            return True  # no filter
        model = self.sourceModel()
        if model is None:
            return True
        row_data = model.row_data(source_row) if hasattr(model, "row_data") else None
        if row_data is None:
            return True
        rank = row_data.get("display_rank", 0)
        # Show entries ranked 1..top_n, hide everything else
        return 0 < rank <= self._top_n


# ══════════════════════════════════════════════════════════════════════════════
# BB RIDE SCAN WORKER
# ══════════════════════════════════════════════════════════════════════════════

from PyQt6.QtCore import QThread


def _assign_ride_ranks(rows: list[dict]):
    """Assign display_rank: entries first, then near-UB candidates."""
    rank = 1
    # Pass 1: entries get top ranks
    for r in rows:
        if r.get("entry"):
            r["display_rank"] = rank
            rank += 1
        else:
            r["display_rank"] = 0
    # Pass 2: near-UB stocks (%B >= 0.75) fill remaining slots
    for r in rows:
        if not r.get("entry") and r.get("bb_pct", 0) >= 0.75:
            r["display_rank"] = rank
            rank += 1


class DualScanWorker(QThread):
    """
    Single worker that fetches price data ONCE per symbol,
    then runs both MR (analyze_symbol) and BB Ride (compute_ride).

    Emits to two separate tables via mr_row_ready / ride_row_ready.
    Halves the network calls vs two separate workers.
    """
    mr_row_ready = pyqtSignal(dict)
    ride_row_ready = pyqtSignal(dict)
    progress = pyqtSignal(int, int, str)
    mr_finished = pyqtSignal(list)
    ride_finished = pyqtSignal(list)

    def __init__(self, symbols, min_score=0, parent=None):
        super().__init__(parent)
        self.symbols = symbols
        self.min_score = min_score
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        from modules.data import get_price_daily, fetch_india_vix
        from modules.scanner import analyze_symbol
        from modules.bb_ride import compute_ride
        from modules.conviction import classify_vix_regime

        # Fetch VIX once for both strategies
        vix_val = None
        vix_regime = "UNKNOWN"
        try:
            vix_val = fetch_india_vix()
            vix_regime = classify_vix_regime(vix_val)
        except Exception:
            pass

        mr_results = []
        ride_results = []
        total = len(self.symbols)

        for i, sym in enumerate(self.symbols):
            if self._cancelled:
                break

            self.progress.emit(i + 1, total, sym)

            try:
                # ── FETCH ONCE ────────────────────────────────────
                df, msg = get_price_daily(sym, days=400)
                if df is None or df.empty or len(df) < 60:
                    continue

                # ── ADTV (shared) ─────────────────────────────────
                if "Volume" in df.columns and "Close" in df.columns:
                    traded_val = df["Close"].tail(20) * df["Volume"].tail(20)
                    adtv_cr = float(traded_val.mean()) / 1e7
                else:
                    adtv_cr = 0.0

                # ── Day change % (shared) ─────────────────────────
                day_chg = 0.0
                if len(df) >= 2:
                    c = df["Close"].iloc[-1]
                    p = df["Close"].iloc[-2]
                    if p > 0:
                        day_chg = round((c / p - 1) * 100, 2)

                # ── Sector context (shared) ───────────────────────
                sector_ctx = None
                try:
                    from modules.sector_rotation import get_sector_context
                    sector_ctx = get_sector_context(sym)
                except Exception:
                    pass

                # ══════════════════════════════════════════════════
                # MR: analyze_symbol with pre-fetched df
                # ══════════════════════════════════════════════════
                mr_row = None
                try:
                    row = analyze_symbol(sym, vix=vix_val, price_df=df)
                    if row is not None:
                        row["day_chg"] = day_chg
                        dm_sc = row.get("dm_score", row.get("viability_score", 0))
                        if dm_sc >= self.min_score:
                            mr_row = row
                except Exception as exc:
                    logger.debug("MR scan %s failed: %s", sym, exc)

                # ══════════════════════════════════════════════════
                # BB RIDE: compute_ride with same df
                # ══════════════════════════════════════════════════
                ride_result = None
                try:
                    if len(df) >= 80:
                        ride_result = compute_ride(df, symbol=sym,
                                              vix_regime=vix_regime,
                                              sector_ctx=sector_ctx)
                        if ride_result and ride_result.data_sufficient:
                            ride_row = {
                                "symbol": sym,
                                "last_price": ride_result.close,
                                "day_chg": day_chg,
                                "sizing": ride_result.sizing if adtv_cr >= 1.0 else "SKIP",
                                "bb_pct": round(ride_result.bb_pct, 2),
                                "vol_ratio": round(ride_result.vol_ratio, 1),
                                "pct_sma50": round(ride_result.pct_from_sma50, 1),
                                "bbw": round(ride_result.bbw, 1),
                                "bbw_slope": round(ride_result.bbw_slope, 2),
                                "roc_10": round(ride_result.roc_10, 1),
                                "adx": round(ride_result.adx, 0),
                                "adtv": round(adtv_cr, 1),
                                "grade": ride_result.grade,
                                "verdict": ride_result.verdict,
                                "entry": ride_result.entry_triggered and adtv_cr >= 1.0,
                                "quality_rank": ride_result.quality_rank,
                                "display_rank": 0,
                                "illiquid": adtv_cr < 1.0,
                                # Stashed for EOD logging — not displayed in UI.
                                # The "_ride_obj" key holds the original BBRideResult
                                # so _maybe_log_eod_snapshot can pass it directly to
                                # log_ride_signal() without reconstruction.
                                "_ride_obj": ride_result,
                            }
                            if adtv_cr < 1.0:
                                ride_row["verdict"] = f"⚠ ILLIQUID ({adtv_cr:.1f} Cr)"
                            ride_results.append(ride_row)
                            # Progressive emit removed: rows are now sent
                            # to the UI as one batch via ride_finished after
                            # the worker has sorted, ranked, and logged.
                except Exception as exc:
                    logger.debug("BB ride scan %s failed: %s", sym, exc)

                # ══════════════════════════════════════════════════
                # MERGE: ride context → MR row (same as dashboard)
                # ══════════════════════════════════════════════════
                if mr_row is not None:
                    mr_results.append(mr_row)
                    # Progressive emit removed: rows are now sent
                    # to the UI as one batch via mr_finished after
                    # the worker has sorted, ranked, and logged.

            except Exception as e:
                logger.debug("Dual scan %s failed: %s", sym, e)

        # ══════════════════════════════════════════════════════════════════
        # POST-COMPUTE: sort, rank, and log (gated on after-hours)
        # ══════════════════════════════════════════════════════════════════
        # Sort MR results by setup priority → grade → quality_rank
        mr_results.sort(
            key=lambda r: (
                _SETUP_PRIORITY.get(r.get("setup_type", "NEUTRAL"), 7),
                _GRADE_ORD.get(r.get("dm_grade", "—"), 7),
                -r.get("quality_rank", 0),
            )
        )
        _assign_ranks(mr_results)

        # Sort Ride results by grade → quality_rank
        ride_results.sort(
            key=lambda r: (
                _GRADE_ORD.get(r.get("grade", "—"), 7),
                -r.get("quality_rank", 0),
            )
        )
        _assign_ride_ranks(ride_results)

        # EOD logging: only fires if we're after market close and snapshot
        # hasn't run for today's trading day yet. The check is silent during
        # market hours — scanner remains a pure live tool intraday.
        try:
            self._maybe_log_eod_snapshot(mr_results, ride_results)
        except Exception as exc:
            logger.warning("EOD snapshot logging failed (non-fatal): %s", exc)

        self.mr_finished.emit(mr_results)
        self.ride_finished.emit(ride_results)

    def _maybe_log_eod_snapshot(self, mr_results: list[dict],
                                 ride_results: list[dict]):
        """
        If after-hours and snapshot not yet done for today's trading day,
        log all qualifying entries to the signal tracker.

        Qualifying = grade in {S, A+, A, B+} AND entry_triggered.
        Logs ALL qualifying entries (not just top N) so the regime detector
        gets maximum sample size.
        """
        from modules.signal_tracker import (
            should_run_snapshot_now, mark_snapshot_done,
            get_most_recent_nse_trading_day,
            log_signal, log_ride_signal,
        )

        should_run, reason = should_run_snapshot_now()
        if not should_run:
            logger.info("EOD snapshot skipped: %s", reason)
            return

        logger.info("EOD snapshot starting: %s", reason)
        qualifying_grades = {"S", "A+", "A", "B+"}

        # ── MR LOGGING ────────────────────────────────────────────────────
        # The scanner row dict comes from analyze_symbol() which doesn't
        # preserve the underlying DualModeSignal, so we reconstruct a minimal
        # SimpleNamespace with the fields log_signal() reads via attribute access.
        # Field names verified from modules/scanner.py analyze_symbol() output.
        from types import SimpleNamespace
        mr_logged = 0
        for row in mr_results:
            if not row.get("dm_entry"):
                continue
            grade = row.get("dm_grade", "—")
            if grade not in qualifying_grades:
                continue
            try:
                fake_sig = SimpleNamespace(
                    symbol=row.get("symbol", ""),
                    tier=row.get("dm_tier", "PRIMARY"),
                    close=float(row.get("last_price", 0)),
                    sma_20=0.0,                                 # not in row
                    pct_from_sma=float(row.get("dm_pct_sma", 0)),
                    wr_30=float(row.get("dm_wr", 0)),
                    adx_14=float(row.get("dm_adx", 0)),
                    base_score=int(row.get("dm_score", 0)),     # post-overlay
                    options_overlay=0,                          # not in row
                    filing_overlay=0,                           # not in row
                    is_trap=bool(row.get("setup_type") == "TRAP"),
                    dual_score=int(row.get("dm_score", 0)),
                    dual_label=grade,
                    dual_sizing=row.get("dm_sizing", "HALF"),
                    entry_triggered=True,
                    entry_reason=row.get("dm_entry_reason", ""),
                    input_interval="1D",
                    daily_bars_used=0,
                )
                if log_signal(fake_sig):
                    mr_logged += 1
            except Exception as exc:
                logger.debug("MR log failed for %s: %s", row.get("symbol"), exc)

        # ── RIDE LOGGING ──────────────────────────────────────────────────
        # The ride row dict has "_ride_obj" stashed which is the original
        # BBRideResult — we pass it directly to log_ride_signal() with no
        # reconstruction. Cleaner than the MR path.
        ride_logged = 0
        for row in ride_results:
            if not row.get("entry"):
                continue
            grade = row.get("grade", "—")
            if grade not in qualifying_grades:
                continue
            ride_obj = row.get("_ride_obj")
            if ride_obj is None:
                logger.debug("Ride row missing _ride_obj for %s", row.get("symbol"))
                continue
            try:
                if log_ride_signal(ride_obj):
                    ride_logged += 1
            except Exception as exc:
                logger.debug("Ride log failed for %s: %s", row.get("symbol"), exc)

        # Mark today's trading day as snapshotted
        last_trading_day = get_most_recent_nse_trading_day()
        if last_trading_day:
            mark_snapshot_done(last_trading_day)

        logger.info(
            "EOD snapshot complete: %d MR + %d Ride logged for %s",
            mr_logged, ride_logged, last_trading_day or "unknown",
        )


# ══════════════════════════════════════════════════════════════════════════════
# BB RIDE TABLE MODEL
# ══════════════════════════════════════════════════════════════════════════════


class BBRideModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: list[dict] = []

    def clear(self):
        self.beginResetModel(); self._data = []; self.endResetModel()

    def append_row(self, row):
        pos = len(self._data)
        self.beginInsertRows(QModelIndex(), pos, pos)
        self._data.append(row)
        self.endInsertRows()

    def row_data(self, row_idx):
        if 0 <= row_idx < len(self._data):
            return self._data[row_idx]
        return None

    def rowCount(self, parent=QModelIndex()): return len(self._data)
    def columnCount(self, parent=QModelIndex()): return len(_RIDE_COLUMNS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return _RIDE_COLUMNS[section][0]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid(): return None
        row = self._data[index.row()]
        _, col_key, _ = _RIDE_COLUMNS[index.column()]
        val = row.get(col_key)

        if role == Qt.ItemDataRole.DisplayRole:
            if val is None: return "—"
            if col_key == "last_price": return f"{val:,.2f}"
            if col_key == "day_chg" and isinstance(val, (int, float)): return f"{val:+.2f}%"
            if col_key == "bb_pct" and isinstance(val, (int, float)): return f"{val:.2f}"
            if col_key == "vol_ratio" and isinstance(val, (int, float)): return f"{val:.1f}x"
            if col_key == "pct_sma50" and isinstance(val, (int, float)): return f"{val:+.1f}%"
            if col_key == "bbw" and isinstance(val, (int, float)): return f"{val:.1f}"
            if col_key == "bbw_slope" and isinstance(val, (int, float)): return f"{val:+.1f}"
            if col_key == "roc_10" and isinstance(val, (int, float)): return f"{val:+.1f}%"
            if col_key == "adx" and isinstance(val, (int, float)): return f"{val:.0f}"
            if col_key == "adtv" and isinstance(val, (int, float)):
                return f"{val:.0f}" if val >= 10 else f"{val:.1f}"
            if col_key == "display_rank" and isinstance(val, (int, float)):
                return f"#{int(val)}" if val > 0 else "—"
            return str(val)

        if role == Qt.ItemDataRole.ForegroundRole:
            if col_key == "day_chg" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0 else (RED if val < 0 else MUTED)))
            if col_key == "grade":
                return QBrush(QColor(grade_fg(val)))
            if col_key == "verdict":
                return QBrush(QColor(verdict_fg(val)))
            if col_key == "sizing":
                return QBrush(QColor(sizing_fg(val)))
            if col_key == "vol_ratio" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 1.5 else (GREEN if val >= 1.0 else MUTED)))
            if col_key == "bb_pct" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val >= 1.0 else (GOLD if val >= 0.75 else MUTED)))
            if col_key == "pct_sma50" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0 else RED))
            if col_key == "roc_10" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0 else RED))
            if col_key == "display_rank" and isinstance(val, (int, float)):
                if val <= 0: return QBrush(QColor(MUTED))
                if val <= 3: return QBrush(QColor(GREEN))
                if val <= 10: return QBrush(QColor(EM))
                return QBrush(QColor(GOLD))

        if role == Qt.ItemDataRole.BackgroundRole:
            if col_key == "grade":
                bg = grade_bg(val)
                if bg: return QBrush(QColor(*bg))

        if role == Qt.ItemDataRole.FontRole:
            if col_key in ("sizing", "symbol", "grade"):
                f = QFont(FONT_MONO, 10); f.setBold(True); return f
            if col_key in ("last_price", "bb_pct", "vol_ratio", "pct_sma50",
                           "bbw", "adtv", "adx", "display_rank", "day_chg"):
                return QFont(FONT_MONO, 10)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if col_key in ("last_price", "bb_pct", "vol_ratio", "pct_sma50",
                           "bbw", "bbw_slope", "roc_10", "adx", "adtv",
                           "grade", "display_rank", "day_chg"):
                return Qt.AlignmentFlag.AlignCenter

        if role == Qt.ItemDataRole.UserRole:
            if val is None: return -9999
            if isinstance(val, (int, float)): return float(val)
            if isinstance(val, str):
                try: return float(val.replace("▶", "").replace("▷", "").strip())
                except ValueError: pass
            return str(val)

        return None


# ══════════════════════════════════════════════════════════════════════════════
# TABLE MODEL
# ══════════════════════════════════════════════════════════════════════════════


class ScanResultModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._data: list[dict] = []

    def set_data(self, rows):
        self.beginResetModel()
        self._data = rows
        self.endResetModel()

    def append_row(self, row):
        pos = len(self._data)
        self.beginInsertRows(QModelIndex(), pos, pos)
        self._data.append(row)
        self.endInsertRows()

    def clear(self):
        self.beginResetModel()
        self._data = []
        self.endResetModel()

    def row_data(self, row):
        return self._data[row] if 0 <= row < len(self._data) else None

    def rowCount(self, parent=QModelIndex()):
        return len(self._data)

    def columnCount(self, parent=QModelIndex()):
        return len(_COLUMNS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if (
            orientation == Qt.Orientation.Horizontal
            and role == Qt.ItemDataRole.DisplayRole
        ):
            return _COLUMNS[section][0]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row_dict = self._data[index.row()]
        _, col_key, _ = _COLUMNS[index.column()]
        val = row_dict.get(col_key)

        if role == Qt.ItemDataRole.DisplayRole:
            if val is None:
                return "—"
            if col_key == "last_price":
                return f"{val:,.2f}"
            if col_key == "day_chg" and isinstance(val, (int, float)):
                return f"{val:+.2f}%"
            if col_key == "dm_wr" and isinstance(val, (int, float)):
                return f"{val:.0f}"
            if col_key == "dm_mfi" and isinstance(val, (int, float)):
                return f"{val:.0f}"
            if col_key == "dm_pct_sma" and isinstance(val, (int, float)):
                return f"{val:+.1f}%"
            if col_key == "dm_dd" and isinstance(val, (int, float)):
                return f"{val:.1f}%"
            if col_key == "dm_streak" and isinstance(val, (int, float)):
                return f"{int(val)}d"
            if col_key == "dte" and isinstance(val, (int, float)):
                return f"{int(val)}d"
            if col_key == "adv_cr" and isinstance(val, (int, float)):
                return f"{val:.0f}" if val >= 1 else f"{val:.1f}"
            if col_key == "dm_vol_ratio" and isinstance(val, (int, float)):
                return f"{val:.1f}x"
            if col_key == "display_rank" and isinstance(val, (int, float)):
                return f"#{int(val)}" if val > 0 else "—"
            return str(val)

        if role == Qt.ItemDataRole.ForegroundRole:
            if col_key == "day_chg" and isinstance(val, (int, float)):
                return QBrush(QColor(GREEN if val > 0 else (RED if val < 0 else MUTED)))
            if col_key == "dm_grade":
                return QBrush(QColor(grade_fg(val)))
            if col_key == "dm_verdict":
                return QBrush(QColor(verdict_fg(val)))
            if col_key == "dm_sizing":
                return QBrush(QColor(sizing_fg(val)))
            if col_key == "dm_wr" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val < -50 else (GREEN if val < -30 else (GOLD if val < -20 else MUTED))))
            if col_key == "dm_mfi" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 50 else (GREEN if val >= 30 else RED)))
            if col_key == "adv_cr" and isinstance(val, (int, float)):
                return QBrush(QColor(MUTED if val < 50 else WHITE))
            if col_key == "dm_vol_ratio" and isinstance(val, (int, float)):
                return QBrush(QColor(EM if val >= 1.5 else (GREEN if val >= 1.0 else (GOLD if val >= 0.5 else RED))))
            if col_key == "dm_pct_sma" and isinstance(val, (int, float)):
                return QBrush(QColor(RED if val < -5 else (GOLD if val < -2 else (MUTED if val < 0 else EM))))
            if col_key == "dm_dd" and isinstance(val, (int, float)):
                return QBrush(QColor(RED if val < -10 else (GOLD if val < -5 else MUTED)))
            if col_key == "dm_streak" and isinstance(val, (int, float)):
                return QBrush(QColor(RED if val >= 4 else (GOLD if val >= 2 else MUTED)))
            if col_key == "gex_regime" and val == "ETF":
                return QBrush(QColor(BLUE))
            if col_key == "display_rank" and isinstance(val, (int, float)):
                if val <= 0: return QBrush(QColor(MUTED))
                if val <= 3: return QBrush(QColor(GREEN))
                if val <= 10: return QBrush(QColor(EM))
                if val <= 20: return QBrush(QColor(GOLD))
                return QBrush(QColor(MUTED))

        if role == Qt.ItemDataRole.BackgroundRole:
            if col_key == "dm_grade":
                bg = grade_bg(val)
                if bg: return QBrush(QColor(*bg))

        if role == Qt.ItemDataRole.FontRole:
            if col_key in ("dm_sizing", "symbol", "dm_grade"):
                f = QFont(FONT_MONO, 10); f.setBold(True); return f
            if col_key in ("last_price", "dm_wr", "dm_mfi", "dm_pct_sma", "dm_dd", "dte",
                           "display_rank", "dm_vol_ratio", "day_chg"):
                return QFont(FONT_MONO, 10)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if col_key in ("last_price", "dm_wr", "dm_mfi", "dm_pct_sma", "dm_dd",
                           "dm_streak", "dte", "dm_grade", "display_rank", "dm_vol_ratio",
                           "day_chg"):
                return Qt.AlignmentFlag.AlignCenter

        if role == Qt.ItemDataRole.UserRole:
            if val is None: return -9999
            if isinstance(val, (int, float)): return float(val)
            if isinstance(val, str):
                try: return float(val.replace("▶", "").replace("▷", "").strip())
                except ValueError: pass
            return str(val)

        return None


# ══════════════════════════════════════════════════════════════════════════════
# SCANNER TAB
# ══════════════════════════════════════════════════════════════════════════════


class ScannerTab(QWidget):
    row_clicked = pyqtSignal(str)  # double-click → open in dashboard
    symbol_selected = pyqtSignal(str)  # single-click  → populate sidebar

    def __init__(self, parent=None):
        super().__init__(parent)
        self._dual_worker: Optional[DualScanWorker] = None
        self._filings_worker: Optional[FilingsWorker] = None
        self._last_scan_ts: Optional[float] = None
        # MR model + proxy
        self._model = ScanResultModel()
        self._proxy = TopNFilterProxy()
        self._proxy.setSourceModel(self._model)
        self._proxy.setSortRole(Qt.ItemDataRole.UserRole)
        # BB Ride model + proxy
        self._ride_model = BBRideModel()
        self._ride_proxy = TopNFilterProxy()
        self._ride_proxy.setSourceModel(self._ride_model)
        self._ride_proxy.setSortRole(Qt.ItemDataRole.UserRole)
        # Throttled re-rank timer — fires every 500ms during scan
        self._rerank_timer = None
        self._rerank_dirty = False
        self._ride_rerank_dirty = False
        self._build_ui()
        # Apply default top_n filter (spinner defaults to 10)
        self._proxy.set_top_n(self._topn_spin.value())
        self._ride_proxy.set_top_n(self._topn_spin.value())

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Control bar ───────────────────────────────────────────
        ctrl_bar = QFrame()
        ctrl_bar.setFixedHeight(32)
        ctrl_bar.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-bottom: 1px solid {BORDER}; }}"
            f"QPushButton {{ background: {EM}; color: {BG}; font-weight: bold;"
            f"  border: none; border-radius: 2px; padding: 4px 12px;"
            f"  font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QPushButton:hover {{ background: #34D399; }}"
            f"QPushButton:pressed {{ background: #059669; }}"
            f"QPushButton#export {{ background: transparent; color: {MUTED};"
            f"  border: 1px solid {BORDER}; }}"
            f"QPushButton#export:hover {{ color: {WHITE}; border-color: {MUTED}; }}"
            f"QComboBox {{ background: {BG}; color: {WHITE}; border: 1px solid {BORDER};"
            f"  border-radius: 2px; padding: 2px 6px; font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QComboBox:hover {{ border-color: {MUTED}; }}"
            f"QComboBox::drop-down {{ border: none; width: 16px; }}"
            f"QSpinBox {{ background: {BG}; color: {WHITE}; border: 1px solid {BORDER};"
            f"  border-radius: 2px; padding: 2px 4px; font-family: '{FONT_MONO}'; font-size: 10px; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 9px;"
            f"  background: transparent; border: none; }}"
        )
        ctrl = QHBoxLayout(ctrl_bar)
        ctrl.setContentsMargins(8, 0, 8, 0)
        ctrl.setSpacing(8)

        self._run_btn = QPushButton("▶ SCAN")
        self._run_btn.setFixedHeight(22)
        self._run_btn.setFixedWidth(80)
        self._run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._run_btn.clicked.connect(self._on_run)
        ctrl.addWidget(self._run_btn)

        ctrl.addWidget(QLabel("UNIVERSE"))
        self._universe_combo = QComboBox()
        self._universe_combo.addItems([
            "NIFTY 50", "NIFTY 100", "NIFTY 200", "NIFTY 500",
            "NIFTY AUTO", "NIFTY BANK", "NIFTY CAPITAL MARKETS",
            "NIFTY COMMODITIES", "NIFTY CONSR DURBL", "NIFTY CONSUMPTION",
            "NIFTY CPSE", "NIFTY ENERGY", "NIFTY FIN SERVICE", "NIFTY FMCG",
            "NIFTY HEALTHCARE", "NIFTY IND DIGITAL", "NIFTY INDIA DEFENCE",
            "NIFTY INFRA", "NIFTY IT", "NIFTY MEDIA", "NIFTY METAL",
            "NIFTY MNC", "NIFTY MOBILITY", "NIFTY NON-CYCLICAL",
            "NIFTY OIL & GAS", "NIFTY PHARMA", "NIFTY PSU BANK",
            "NIFTY PVT BANK", "NIFTY REALTY", "NIFTY TOURISM",
            "NIFTY TRANSPORTATION & LOGISTICS",
            "F&O Full", "Watchlist",
        ])
        self._universe_combo.setCurrentText("NIFTY 200")
        self._universe_combo.setFixedWidth(190)
        self._universe_combo.setFixedHeight(22)
        ctrl.addWidget(self._universe_combo)

        ctrl.addStretch(1)

        ctrl.addWidget(QLabel("TOP"))
        self._topn_spin = QSpinBox()
        self._topn_spin.setRange(0, 100)
        self._topn_spin.setValue(10)
        self._topn_spin.setSpecialValueText("ALL")
        self._topn_spin.setFixedWidth(50)
        self._topn_spin.setFixedHeight(22)
        self._topn_spin.setToolTip("Show top N ranked entries (0 = all)")
        self._topn_spin.valueChanged.connect(self._on_topn_changed)
        ctrl.addWidget(self._topn_spin)

        self._export_btn = QPushButton("EXPORT")
        self._export_btn.setObjectName("export")
        self._export_btn.setFixedHeight(22)
        self._export_btn.setFixedWidth(70)
        self._export_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._export_btn.clicked.connect(self._on_export)
        ctrl.addWidget(self._export_btn)
        layout.addWidget(ctrl_bar)

        # ── Stale banner ──────────────────────────────────────────
        self._stale_banner = QFrame()
        self._stale_banner.setStyleSheet(
            f"QFrame {{ background: #12110A; border-bottom: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {GOLD}; font-family: '{FONT_MONO}'; font-size: 9px;"
            f"  background: transparent; border: none; }}"
            f"QPushButton {{ background: transparent; color: {GOLD};"
            f"  border: 1px solid {GOLD}; border-radius: 2px; padding: 2px 8px;"
            f"  font-family: '{FONT_MONO}'; font-size: 9px; }}"
        )
        self._stale_banner.setFixedHeight(24)
        bl = QHBoxLayout(self._stale_banner)
        bl.setContentsMargins(8, 0, 8, 0)
        self._stale_lbl = QLabel("")
        bl.addWidget(self._stale_lbl)
        rb = QPushButton("REFRESH")
        rb.setFixedHeight(18)
        rb.clicked.connect(self._on_run)
        bl.addWidget(rb)
        bl.addStretch()
        self._stale_banner.setVisible(False)
        layout.addWidget(self._stale_banner)

        # ── Progress ──────────────────────────────────────────────
        self._progress_frame = QFrame()
        self._progress_frame.setFixedHeight(18)
        self._progress_frame.setStyleSheet(
            f"QFrame {{ background: {BG}; border-bottom: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 8px;"
            f"  background: transparent; border: none; }}"
            f"QProgressBar {{ background: {BG}; border: none; border-radius: 2px;"
            f"  max-height: 4px; }}"
            f"QProgressBar::chunk {{ background: {EM}; border-radius: 2px; }}"
        )
        pr = QHBoxLayout(self._progress_frame)
        pr.setContentsMargins(8, 0, 8, 0)
        pr.setSpacing(8)
        self._progress = QProgressBar()
        self._progress.setFixedHeight(4)
        self._progress.setTextVisible(False)
        pr.addWidget(self._progress, stretch=1)
        self._progress_lbl = QLabel("")
        pr.addWidget(self._progress_lbl)
        self._progress_frame.setVisible(False)
        layout.addWidget(self._progress_frame)

        # ── Pro terminal table styling ────────────────────────────
        _TABLE_STYLE = (
            f"QTableView {{"
            f"  background: {BG}; alternate-background-color: #0A0E14;"
            f"  gridline-color: transparent; border: none;"
            f"  selection-background-color: rgba(16,185,129,0.08);"
            f"  selection-color: {WHITE};"
            f"  font-family: '{FONT_MONO}'; font-size: 10px;"
            f"}}"
            f"QTableView::item {{"
            f"  padding: 0px 5px;"
            f"  border-bottom: 1px solid #0C1018;"
            f"}}"
            f"QTableView::item:selected {{ background: rgba(16,185,129,0.08); }}"
            f"QHeaderView::section {{"
            f"  background: {SURFACE}; color: {MUTED};"
            f"  border: none; border-bottom: 1px solid {BORDER};"
            f"  border-right: 1px solid #0C1018;"
            f"  font-family: '{FONT_MONO}'; font-size: 9px;"
            f"  font-weight: 600; padding: 3px 5px;"
            f"  text-transform: uppercase; letter-spacing: 0.5px;"
            f"}}"
            f"QScrollBar:vertical {{"
            f"  background: transparent; width: 5px; margin: 0; border: none;"
            f"}}"
            f"QScrollBar::handle:vertical {{"
            f"  background: {BORDER}; border-radius: 2px; min-height: 20px;"
            f"}}"
            f"QScrollBar::handle:vertical:hover {{ background: {MUTED}; }}"
            f"QScrollBar:horizontal {{"
            f"  background: transparent; height: 5px; margin: 0; border: none;"
            f"}}"
            f"QScrollBar::handle:horizontal {{"
            f"  background: {BORDER}; border-radius: 2px; min-width: 20px;"
            f"}}"
            f"QScrollBar::handle:horizontal:hover {{ background: {MUTED}; }}"
            f"QScrollBar::add-line, QScrollBar::sub-line,"
            f"QScrollBar::add-page, QScrollBar::sub-page {{ background: none; border: none; height: 0; width: 0; }}"
        )

        _SPLITTER_STYLE = (
            f"QSplitter::handle {{ background: {SURFACE}; height: 1px; }}"
        )

        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(3)
        splitter.setStyleSheet(_SPLITTER_STYLE)

        # ── Top: MR table ─────────────────────────────────────────
        mr_container = QWidget()
        mr_container.setStyleSheet(f"background: {BG};")
        mr_lay = QVBoxLayout(mr_container)
        mr_lay.setContentsMargins(0, 0, 0, 0)
        mr_lay.setSpacing(0)

        mr_hdr = QFrame()
        mr_hdr.setFixedHeight(22)
        mr_hdr.setStyleSheet(
            f"background: {SURFACE}; border-left: 3px solid {GREEN};"
        )
        mr_hl = QHBoxLayout(mr_hdr)
        mr_hl.setContentsMargins(10, 0, 10, 0)
        mr_title = QLabel("MEAN REVERSION")
        mr_title.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        mr_title.setStyleSheet(f"color: {GREEN}; background: transparent; border: none;")
        mr_hl.addWidget(mr_title)
        mr_hl.addStretch(1)
        self._mr_count = QLabel("")
        self._mr_count.setFont(QFont(FONT_MONO, 7))
        self._mr_count.setStyleSheet(f"color: {MUTED}; background: transparent; border: none;")
        # Hover tooltip — explains that 0 entries is normal with the strict
        # filter from the 2026-04-08 robust sweep upgrade. Users seeing "MR: 0"
        # for the first time may think the system is broken, so spell it out.
        self._mr_count.setToolTip(
            "MR strict mode (DD≤-8%, Streak≥4, Vol≥1.5x).\n"
            "Expected ~110 entries/year across NIFTY 200 (~0.5/day).\n"
            "Zero entries on a given scan is normal — the strategy is\n"
            "waiting for genuine capitulation events. See dual_mode.py\n"
            "and signal_tracker.py for the parameter provenance."
        )
        mr_hl.addWidget(self._mr_count)
        mr_lay.addWidget(mr_hdr)

        self._table = QTableView()
        self._table.setModel(self._proxy)
        self._table.setSortingEnabled(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setAlternatingRowColors(True)
        self._table.verticalHeader().setVisible(False)
        self._table.verticalHeader().setDefaultSectionSize(24)
        self._table.setShowGrid(False)
        self._table.setMouseTracking(True)
        self._table.setStyleSheet(_TABLE_STYLE)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        hdr = self._table.horizontalHeader()
        hdr.setMouseTracking(True)
        hdr.setMinimumSectionSize(30)
        hdr.setStretchLastSection(False)
        hdr.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        hdr.setFixedHeight(26)
        for i, (_, _, w) in enumerate(_COLUMNS):
            hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            hdr.resizeSection(i, w)
        self._table.doubleClicked.connect(self._on_row_double_click)
        mr_lay.addWidget(self._table, stretch=1)
        splitter.addWidget(mr_container)

        # ── Bottom: BB Ride table ─────────────────────────────────
        ride_container = QWidget()
        ride_container.setStyleSheet(f"background: {BG};")
        ride_lay = QVBoxLayout(ride_container)
        ride_lay.setContentsMargins(0, 0, 0, 0)
        ride_lay.setSpacing(0)

        ride_hdr = QFrame()
        ride_hdr.setFixedHeight(22)
        ride_hdr.setStyleSheet(
            f"background: {SURFACE}; border-left: 3px solid {BLUE};"
        )
        ride_hl = QHBoxLayout(ride_hdr)
        ride_hl.setContentsMargins(10, 0, 10, 0)
        ride_title = QLabel("BB RIDE MOMENTUM")
        ride_title.setFont(QFont(FONT_MONO, 8, QFont.Weight.Bold))
        ride_title.setStyleSheet(f"color: {BLUE}; background: transparent; border: none;")
        ride_hl.addWidget(ride_title)
        ride_hl.addStretch(1)
        self._ride_count = QLabel("")
        self._ride_count.setFont(QFont(FONT_MONO, 7))
        self._ride_count.setStyleSheet(f"color: {MUTED}; background: transparent; border: none;")
        ride_hl.addWidget(self._ride_count)
        ride_lay.addWidget(ride_hdr)

        self._ride_table = QTableView()
        self._ride_table.setModel(self._ride_proxy)
        self._ride_table.setSortingEnabled(True)
        self._ride_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._ride_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._ride_table.setAlternatingRowColors(True)
        self._ride_table.verticalHeader().setVisible(False)
        self._ride_table.verticalHeader().setDefaultSectionSize(24)
        self._ride_table.setShowGrid(False)
        self._ride_table.setMouseTracking(True)
        self._ride_table.setStyleSheet(_TABLE_STYLE)
        self._ride_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._ride_table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        ride_h = self._ride_table.horizontalHeader()
        ride_h.setMouseTracking(True)
        ride_h.setMinimumSectionSize(30)
        ride_h.setStretchLastSection(False)
        ride_h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        ride_h.setFixedHeight(26)
        for i, (_, _, w) in enumerate(_RIDE_COLUMNS):
            ride_h.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            ride_h.resizeSection(i, w)
        self._ride_table.doubleClicked.connect(self._on_ride_row_double_click)
        ride_lay.addWidget(self._ride_table, stretch=1)
        splitter.addWidget(ride_container)

        splitter.setSizes([600, 400])
        layout.addWidget(splitter, stretch=1)

        # ── Terminal footer ───────────────────────────────────────
        footer = QFrame()
        footer.setFixedHeight(20)
        footer.setStyleSheet(
            f"QFrame {{ background: {SURFACE}; border-top: 1px solid {BORDER}; }}"
            f"QLabel {{ color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 8px;"
            f"  background: transparent; border: none; }}"
        )
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(10, 0, 10, 0)
        fl.addStretch(1)
        self._count_lbl = QLabel("")
        fl.addWidget(self._count_lbl)
        layout.addWidget(footer)

    def _lbl(self, text):
        l = QLabel(text)
        l.setFont(QFont(FONT_UI, 9))
        l.setStyleSheet(f"color: {MUTED};")
        return l

    def _on_topn_changed(self, value: int):
        """Filter both tables to show only top N ranked entries."""
        self._proxy.set_top_n(value)
        self._ride_proxy.set_top_n(value)

    # ── Scan flow ─────────────────────────────────────────────────────────────

    def _on_run(self):
        # Cancel worker if running
        if self._dual_worker and self._dual_worker.isRunning():
            if self._filings_worker and self._filings_worker.isRunning():
                self._filings_worker.cancel()
            self._dual_worker.cancel()
            if self._rerank_timer:
                self._rerank_timer.stop()
            self._rerank_dirty = True
            self._ride_rerank_dirty = True
            self._rerank_live()
            self._run_btn.setText("▶ SCAN")
            return

        universe = self._universe_combo.currentText()
        if universe == "F&O Full":
            symbols = get_universe()
        elif universe == "Watchlist":
            from ui.watchlist_db import load_watchlist
            symbols = [e["symbol"] for e in load_watchlist()]
        else:
            from modules.index_constituents import get_index_symbols
            symbols = get_index_symbols(universe)
            if not symbols:
                symbols = list(NIFTY100_SYMBOLS)

        if not symbols:
            self._count_lbl.setText("No symbols")
            return

        # Clear both models
        self._model.clear()
        self._ride_model.clear()
        self._stale_banner.setVisible(False)
        self._progress_frame.setVisible(True)
        self._progress.setMaximum(len(symbols))
        self._progress.setValue(0)
        self._run_btn.setText("■ STOP")

        # ── Single worker: fetch once, feed both engines ──────
        self._dual_worker = DualScanWorker(symbols=symbols, min_score=0)
        self._dual_worker.mr_row_ready.connect(self._on_row_ready)
        self._dual_worker.ride_row_ready.connect(self._on_ride_row_ready)
        self._dual_worker.progress.connect(self._on_progress)
        self._dual_worker.mr_finished.connect(self._on_mr_finished)
        self._dual_worker.ride_finished.connect(self._on_ride_finished)
        self._dual_worker.start()

        # Start live re-rank timer (every 500ms during scan)
        from PyQt6.QtCore import QTimer
        if self._rerank_timer is None:
            self._rerank_timer = QTimer(self)
            self._rerank_timer.timeout.connect(self._rerank_live)
        self._rerank_timer.start(500)
        self._rerank_dirty = False
        self._ride_rerank_dirty = False

    # ── Worker callbacks ──────────────────────────────────────────────────

    def _on_row_ready(self, row):
        self._model.append_row(row)
        self._rerank_dirty = True

    def _on_ride_row_ready(self, row):
        self._ride_model.append_row(row)
        self._ride_rerank_dirty = True

    def _on_progress(self, done, total, symbol):
        self._progress.setValue(done)
        self._progress_lbl.setText(f"{symbol} {done}/{total}")

    def _on_mr_finished(self, results):
        # Worker has sorted, ranked, and logged. Populate the model in one batch.
        self._model.beginResetModel()
        self._model._data = list(results)
        self._model.endResetModel()
        logger.info("MR scan complete: %d results", len(results))

        # Start filings enrichment
        if results:
            self._filings_worker = FilingsWorker(results)
            self._filings_worker.row_enriched.connect(self._on_filing_enriched)
            self._filings_worker.finished.connect(self._on_filings_done)
            self._filings_worker.start()

    def _on_ride_finished(self, results):
        # Worker has sorted and ranked. Populate the model in one batch.
        self._ride_model.beginResetModel()
        self._ride_model._data = list(results)
        self._ride_model.endResetModel()
        logger.info("BB Ride scan complete: %d results", len(results))

        # Both finished (single worker emits both)
        if self._rerank_timer:
            self._rerank_timer.stop()
        self._progress_frame.setVisible(False)
        self._run_btn.setText("▶ SCAN")
        self._last_scan_ts = time.time()

        mr_entries = sum(1 for r in self._model._data if r.get("dm_entry"))
        ride_entries = sum(1 for r in self._ride_model._data if r.get("entry"))
        near_ub = sum(1 for r in self._ride_model._data
                      if not r.get("entry") and r.get("bb_pct", 0) >= 0.75)
        ride_label = f"{ride_entries} entries"
        if near_ub:
            ride_label += f" + {near_ub} near UB"
        self._mr_count.setText(f"{mr_entries} entries / {len(self._model._data)}")
        self._ride_count.setText(f"{ride_label} / {len(self._ride_model._data)}")
        self._count_lbl.setText(
            f"MR: {mr_entries} · Ride: {ride_entries} · "
            f"Total: {len(self._model._data)} scanned"
        )

    # ── Live re-ranking ───────────────────────────────────────────────────

    def _rerank_live(self):
        """Re-sort and re-rank both tables every 500ms during scan."""
        if self._rerank_dirty:
            self._rerank_dirty = False
            self._model.layoutAboutToBeChanged.emit()
            self._model._data.sort(
                key=lambda r: (
                    _SETUP_PRIORITY.get(r.get("setup_type", "NEUTRAL"), 7),
                    _GRADE_ORD.get(r.get("dm_grade", "—"), 7),
                    -r.get("quality_rank", 0),
                )
            )
            _assign_ranks(self._model._data)
            self._model.layoutChanged.emit()

        if self._ride_rerank_dirty:
            self._ride_rerank_dirty = False
            self._ride_model.layoutAboutToBeChanged.emit()
            self._ride_model._data.sort(
                key=lambda r: (
                    _GRADE_ORD.get(r.get("grade", "—"), 7),
                    -r.get("quality_rank", 0),
                )
            )
            _assign_ride_ranks(self._ride_model._data)
            self._ride_model.layoutChanged.emit()

    # ── FilingsWorker callbacks ───────────────────────────────────────────

    def _on_filing_enriched(self, symbol: str, updated: dict):
        for row in self._model._data:
            if row.get("symbol") == symbol:
                row.update(updated)
                break

    def _on_filings_done(self):
        self._model.beginResetModel()
        self._model._data.sort(
            key=lambda r: (
                _SETUP_PRIORITY.get(r.get("setup_type", "NEUTRAL"), 7),
                _GRADE_ORD.get(r.get("dm_grade", "—"), 7),
                -r.get("quality_rank", 0),
            )
        )
        _assign_ranks(self._model._data)
        self._model.endResetModel()
        # progress_lbl in frame
        logger.info("FilingsWorker enrichment complete")

    # ── Table interaction ─────────────────────────────────────────────────────

    def _on_row_double_click(self, index):
        src = self._proxy.mapToSource(index)
        row = self._model.row_data(src.row())
        if row:
            self.symbol_selected.emit(row["symbol"])
            self.row_clicked.emit(row["symbol"])

    def _on_ride_row_double_click(self, index):
        src = self._ride_proxy.mapToSource(index)
        row = self._ride_model.row_data(src.row())
        if row:
            self.symbol_selected.emit(row["symbol"])
            self.row_clicked.emit(row["symbol"])

    def _on_export(self):
        if not self._model._data:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export", "nimbus_scan.csv", "CSV (*.csv)"
        )
        if path:
            pd.DataFrame(self._model._data).to_csv(path, index=False)
