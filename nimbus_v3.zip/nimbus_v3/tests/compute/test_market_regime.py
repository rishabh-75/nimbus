"""tests.compute.test_market_regime — broad-market regime detection."""
from __future__ import annotations

import pandas as pd
import pytest

from nimbus_v3.compute.market_regime import (
    BROAD_DECLINE_THRESHOLD, MarketRegime, evaluate_market_regime,
)
from nimbus_v3.core.industry_relative_state import IndustryRelativeState


def _state(
    symbol: str, industry: str, phase: str,
) -> IndustryRelativeState:
    """Build a minimal state with only the fields evaluate_market_regime
    reads — everything else is filler."""
    return IndustryRelativeState(
        symbol=symbol, bar_date=pd.Timestamp("2024-01-01"),
        industry=industry,
        beta_60d=1.0, alpha_60d=0.0, alpha_percentile=50.0,
        industry_phase=phase,
        industry_roc_20=0.0, industry_breadth_pct=0.5,
        peer_count_in_industry=5, peer_rank_in_industry=1,
        is_alpha_leader=False, is_high_beta_rider=False,
        is_low_beta_quality=False, is_industry_declining=False,
        is_accumulating=False,
        is_alpha_fading=False,
        data_sufficient=True,
    )


def _build_states(phase_by_industry: dict[str, str]) -> dict:
    """Build a states dict {symbol: state} where each industry has
    one representative symbol. Sufficient to test regime math."""
    out = {}
    for i, (industry, phase) in enumerate(phase_by_industry.items()):
        sym = f"SYM{i:03d}"
        out[sym] = _state(sym, industry, phase)
    return out


class TestNormalRegime:

    def test_healthy_market_not_broad_decline(self):
        """Mostly MID/LATE with a few DECLINE should not trigger."""
        states = _build_states({
            **{f"Ind{i}": "LATE" for i in range(15)},
            **{f"IndD{i}": "DECLINE" for i in range(3)},
        })
        regime = evaluate_market_regime(states)
        assert not regime.is_broad_decline
        # 3/18 = 0.167
        assert regime.pct_declining == pytest.approx(3 / 18)
        assert regime.n_industries == 18

    def test_mixed_regimes_no_flag(self):
        states = _build_states({
            "A": "EARLY", "B": "MID", "C": "LATE", "D": "EUPHORIA",
            "E": "NEUTRAL", "F": "DECLINE", "G": "LATE", "H": "MID",
            "I": "MID", "J": "LATE", "K": "DECLINE", "L": "LATE",
        })
        regime = evaluate_market_regime(states)
        assert not regime.is_broad_decline
        assert regime.pct_declining == pytest.approx(2 / 12)


class TestBroadDecline:

    def test_majority_decline_triggers(self):
        """70% in DECLINE with a large-enough sample should trigger."""
        states = _build_states({
            **{f"Ind{i}": "DECLINE" for i in range(14)},
            **{f"Hold{i}": "NEUTRAL" for i in range(6)},
        })
        regime = evaluate_market_regime(states)
        assert regime.is_broad_decline
        assert regime.pct_declining == pytest.approx(14 / 20)
        assert regime.n_industries == 20

    def test_exactly_at_threshold_triggers(self):
        """pct_declining == threshold should fire (>= semantics)."""
        # 12/20 = 0.60 exactly (the threshold)
        states = _build_states({
            **{f"Dec{i}": "DECLINE" for i in range(12)},
            **{f"Oth{i}": "LATE" for i in range(8)},
        })
        regime = evaluate_market_regime(states)
        assert regime.pct_declining == pytest.approx(BROAD_DECLINE_THRESHOLD)
        assert regime.is_broad_decline

    def test_just_below_threshold_no_flag(self):
        # 11/20 = 0.55, below 0.60 threshold
        states = _build_states({
            **{f"Dec{i}": "DECLINE" for i in range(11)},
            **{f"Oth{i}": "LATE" for i in range(9)},
        })
        regime = evaluate_market_regime(states)
        assert regime.pct_declining == pytest.approx(0.55)
        assert not regime.is_broad_decline


class TestSmallSampleSuppression:

    def test_all_decline_small_sample_suppressed(self):
        """5 industries all in DECLINE should NOT trigger — below
        minimum for meaningful broad-market inference."""
        states = _build_states({
            f"Ind{i}": "DECLINE" for i in range(5)
        })
        regime = evaluate_market_regime(states)
        assert not regime.is_broad_decline
        assert regime.pct_declining == pytest.approx(1.0)
        assert regime.n_industries == 5

    def test_at_minimum_sample_can_trigger(self):
        """Exactly 10 industries, all in DECLINE — at the lower
        bound for regime inference, should trigger."""
        states = _build_states({
            f"Ind{i}": "DECLINE" for i in range(10)
        })
        regime = evaluate_market_regime(states)
        assert regime.is_broad_decline

    def test_empty_input(self):
        regime = evaluate_market_regime({})
        assert not regime.is_broad_decline
        assert regime.pct_declining == 0.0
        assert regime.n_industries == 0


class TestIndustryDedupe:
    """Multiple symbols in the same industry shouldn't inflate the
    count — the regime measure is per-industry, not per-stock."""

    def test_many_symbols_single_industry_counts_once(self):
        """20 symbols in 2 industries → n_industries=2, not 20."""
        states = {}
        for i in range(10):
            states[f"A{i:02d}"] = _state(f"A{i:02d}", "IndA", "LATE")
        for i in range(10):
            states[f"B{i:02d}"] = _state(f"B{i:02d}", "IndB", "DECLINE")
        regime = evaluate_market_regime(states)
        assert regime.n_industries == 2
        assert regime.pct_declining == pytest.approx(0.5)


class TestMarketRegimeDataclass:

    def test_frozen(self):
        """MarketRegime is frozen — same pattern as IndustryState."""
        regime = evaluate_market_regime({})
        with pytest.raises(Exception):
            regime.is_broad_decline = True   # type: ignore[misc]

    def test_fields_populated(self):
        regime = evaluate_market_regime(_build_states({"A": "MID"}))
        assert isinstance(regime.is_broad_decline, bool)
        assert isinstance(regime.pct_declining, float)
        assert isinstance(regime.n_industries, int)
