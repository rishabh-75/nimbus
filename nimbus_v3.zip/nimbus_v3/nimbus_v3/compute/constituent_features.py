"""nimbus_v3.compute.constituent_features — per-symbol table features.

Stateless. Produces the full per-symbol feature set the Constituents
table displays (percent changes, %B, volume ratio, BBW, ADTV, body-above
flag, streak) in ONE place, so the widget renders rather than computes.

Before this module these were calculated inline in the table widget,
duplicating the return/ADTV/BBW reads that ``early_entry.extract_features``
also performs. Centralising them here makes the engine the single source
of per-symbol features; both the table and the Early-Entry scorer draw
from the same primitives (band_ride, indicators).
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from nimbus_v3.compute.band_ride import body_above_streak, last_body_above
from nimbus_v3.compute.indicators import adtv_latest

#: Minimum bars required before a symbol is analysable.
MIN_BARS: int = 20
#: Volume-ratio lookback (bars) for the Vol column.
_VOL_WINDOW: int = 20


@dataclass(frozen=True)
class ConstituentFeatures:
    """Per-symbol features for one Constituents-table row.

    All numeric fields are floats; missing/unavailable values are NaN so
    the renderer shows an em-dash. ``above`` is the body-above-band flag
    and ``streak`` its trailing run length.
    """

    symbol: str
    adtv: float
    chg_1d: float
    chg_5d: float
    chg_10d: float
    pct_b: float
    vol_ratio: float
    bbw: float
    above: bool
    streak: int


def _pct_change(close: pd.Series, latest: float, n: int) -> float:
    """Percent change of the latest close vs ``n`` bars back. NaN when
    the lookback exceeds available history or the base is non-positive."""
    if len(close) <= n:
        return float("nan")
    past = float(close.iloc[-n - 1])
    if past <= 0 or past != past:
        return float("nan")
    return 100.0 * (latest - past) / past


def extract_constituent_features(
    symbol: str,
    df: pd.DataFrame | None,
) -> ConstituentFeatures | None:
    """Extract a Constituents row's features from an enriched frame.

    Returns ``None`` when the frame is missing or has fewer than
    :data:`MIN_BARS` bars (the caller skips the row entirely).
    """
    if df is None or len(df) < MIN_BARS:
        return None

    adtv = adtv_latest(df)

    close = df["Close"]
    latest_close = float(close.iloc[-1])
    chg_1d = _pct_change(close, latest_close, 1)
    chg_5d = _pct_change(close, latest_close, 5)
    chg_10d = _pct_change(close, latest_close, 10)

    # %B — position of latest close within the 20-bar 1σ band, read
    # straight from the engine column (0 = lower band, 1 = upper).
    pct_b = float("nan")
    if "bb_20_1s_pct" in df.columns:
        v = df["bb_20_1s_pct"].iloc[-1]
        if v == v:
            pct_b = float(v)

    # Vol — latest Volume relative to the 20-bar mean.
    vol_ratio = float("nan")
    if "Volume" in df.columns and len(df) >= _VOL_WINDOW:
        mean_vol = float(df["Volume"].tail(_VOL_WINDOW).mean())
        latest_vol = float(df["Volume"].iloc[-1])
        if mean_vol > 0 and mean_vol == mean_vol:
            vol_ratio = latest_vol / mean_vol

    bbw = float("nan")
    if "bbw_20_1s" in df.columns:
        v = df["bbw_20_1s"].iloc[-1]
        if v == v:
            bbw = float(v)

    return ConstituentFeatures(
        symbol=symbol,
        adtv=adtv,
        chg_1d=chg_1d,
        chg_5d=chg_5d,
        chg_10d=chg_10d,
        pct_b=pct_b,
        vol_ratio=vol_ratio,
        bbw=bbw,
        above=last_body_above(df),
        streak=body_above_streak(df),
    )
