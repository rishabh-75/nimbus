#!/usr/bin/env python3
"""
tests/test_etf_phase_logic.py — Phase-aware verdict selection tests.

Tests _apply_phase_logic() which decides whether the primary Grade/Verdict
shows momentum (dip) or ride (upper band) based on the ETF's current state.

The key invariant: %B tells you what's happening NOW.
  %B >= 1.0 → riding upper band (present) → ride context dominates
  %B < 1.0 + mom entry → dip recovery (present) → momentum dominates
  Neither → neutral → momentum default
"""
import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _base_row(**overrides):
    """Create a base ETF row with sensible defaults."""
    row = {
        "symbol": "TESTBEES",
        "last_price": 100.0,
        "grade": "B",          # momentum grade
        "verdict": "▷ BUY HALF [B] — moderate dip",  # momentum verdict
        "sizing": "HALF",
        "entry": False,         # momentum entry
        "quality_rank": 50.0,
        # Ride fields
        "ride_pctb": 0.5,
        "ride_grade": "—",
        "ride_verdict": "▽ NEUTRAL — mid-band, %B=0.50",
        "ride_entry": False,
        "ride_vix_gated": False,
        "ride_status": "—",
    }
    row.update(overrides)
    return row


class TestPhaseLogic(unittest.TestCase):
    """Test _apply_phase_logic for all phase scenarios."""

    def setUp(self):
        from modules.etf_phase import apply_phase_logic
        self.apply = apply_phase_logic

    # ══════════════════════════════════════════════════════════════
    # RIDING PHASE: %B >= 1.0
    # ══════════════════════════════════════════════════════════════

    def test_riding_with_ride_grade_no_momentum(self):
        """Pure ride: %B=1.14, ride grade A, no momentum dip."""
        row = _base_row(
            ride_pctb=1.14, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A] — VIX elevated, cyclical",
            ride_entry=True, entry=False,
        )
        self.apply(row, "—", adtv_cr=50.0)
        self.assertEqual(row["phase"], "RIDE")
        self.assertEqual(row["grade"], "A")
        self.assertIn("RIDE FULL", row["verdict"])
        self.assertNotIn("dip", row["verdict"])
        self.assertEqual(row["sizing"], "FULL")

    def test_riding_with_ride_grade_plus_momentum(self):
        """Convergence: %B=1.14, ride A, momentum also triggered."""
        row = _base_row(
            ride_pctb=1.14, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A] — VIX elevated",
            ride_entry=True, entry=True,
            grade="B+", verdict="▷ BUY HALF [B+] — solid flow",
        )
        self.apply(row, "B+", adtv_cr=50.0)
        self.assertEqual(row["phase"], "BOTH")
        self.assertEqual(row["grade"], "A")  # ride grade wins (A > B+)
        self.assertIn("RIDE FULL", row["verdict"])
        self.assertIn("dip confirmed", row["verdict"])  # convergence note
        self.assertGreater(row["quality_rank"], 50.0)  # +10 boost

    def test_monq50_scenario(self):
        """MONQ50 bug: %B=1.83, ride grade "—" (already riding), momentum A+.
        Should show ride status, NOT 'deep dip'."""
        row = _base_row(
            symbol="MONQ50",
            ride_pctb=1.83, ride_grade="—",
            ride_verdict="△ RIDING — at upper band, %B=1.83",
            ride_entry=False, entry=True,
            grade="A+", verdict="▶ BUY FULL [A+] — deep dip, strong flow",
        )
        self.apply(row, "A+", adtv_cr=28.0)
        self.assertEqual(row["phase"], "BOTH")
        # PRIMARY VERDICT: should show RIDING, NOT deep dip
        self.assertIn("RIDING", row["verdict"])
        self.assertNotIn("deep dip", row["verdict"])
        # Momentum grade noted as context
        self.assertIn("momentum [A+]", row["verdict"])
        # Grade should still be A+ (momentum's, since ride is "—")
        self.assertEqual(row["grade"], "A+")

    def test_riding_no_ride_entry_no_momentum(self):
        """Riding upper band (%B=1.05) but no fresh entry, no momentum.
        Shows ride status in RIDE phase."""
        row = _base_row(
            ride_pctb=1.05, ride_grade="—",
            ride_verdict="△ RIDING — at upper band, %B=1.05",
            ride_entry=False, entry=False,
        )
        self.apply(row, "—", adtv_cr=10.0)
        self.assertEqual(row["phase"], "RIDE")
        self.assertIn("RIDING", row["verdict"])
        self.assertNotIn("momentum", row["verdict"])  # no momentum context

    def test_riding_vix_gated(self):
        """VIX NORMAL gated: ride grade D, %B=1.10, momentum active.
        Ride grade D → use ride status (not ride verdict)."""
        row = _base_row(
            ride_pctb=1.10, ride_grade="D",
            ride_verdict="⚠ VIX NORMAL — ETF ride unprofitable",
            ride_entry=False, ride_vix_gated=True,
            entry=True, grade="B",
            verdict="▷ BUY HALF [B] — moderate pullback",
        )
        self.apply(row, "B", adtv_cr=20.0)
        self.assertEqual(row["phase"], "BOTH")
        # D grade → treated like "—", show ride status not ride verdict entry
        self.assertIn("VIX NORMAL", row["verdict"])
        self.assertIn("momentum [B]", row["verdict"])

    def test_riding_high_pctb(self):
        """Extreme %B=2.5, no entries. Pure ride observation."""
        row = _base_row(
            ride_pctb=2.5, ride_grade="—",
            ride_verdict="△ RIDING — at upper band, %B=2.50",
            ride_entry=False, entry=False,
        )
        self.apply(row, "—", adtv_cr=5.0)
        self.assertEqual(row["phase"], "RIDE")
        self.assertIn("RIDING", row["verdict"])

    # ══════════════════════════════════════════════════════════════
    # DIP PHASE: mom_active=True, %B < 1.0
    # ══════════════════════════════════════════════════════════════

    def test_pure_dip(self):
        """Classic dip: momentum entry, %B=0.30, no ride."""
        row = _base_row(
            entry=True, grade="A",
            verdict="▶ BUY FULL [A] — deep dip, strong flow",
            ride_pctb=0.30, ride_grade="—",
            ride_verdict="▽ SKIP — below mid-band",
        )
        self.apply(row, "A", adtv_cr=100.0)
        self.assertEqual(row["phase"], "DIP")
        self.assertEqual(row["grade"], "A")
        self.assertIn("deep dip", row["verdict"])

    def test_dip_near_upper(self):
        """Dip recovery near upper band: %B=0.85, momentum entry."""
        row = _base_row(
            entry=True, grade="B+",
            verdict="▷ BUY HALF [B+] — recovering",
            ride_pctb=0.85, ride_grade="—",
            ride_verdict="▽ WATCH — near upper",
        )
        self.apply(row, "B+", adtv_cr=10.0)
        self.assertEqual(row["phase"], "DIP")
        self.assertEqual(row["grade"], "B+")
        self.assertIn("recovering", row["verdict"])

    def test_dip_with_ride_entry_edge(self):
        """Rare: momentum entry + ride entry at %B=0.98 (just under 1.0)."""
        row = _base_row(
            entry=True, grade="B",
            verdict="▷ BUY HALF [B] — moderate dip",
            ride_pctb=0.98, ride_grade="B+",
            ride_verdict="▶ ETF RIDE HALF [B+] — trending",
            ride_entry=True,
        )
        self.apply(row, "B", adtv_cr=20.0)
        self.assertEqual(row["phase"], "BOTH")
        self.assertIn("ride [B+]", row["verdict"])
        self.assertGreater(row["quality_rank"], 50.0)  # +10 boost

    # ══════════════════════════════════════════════════════════════
    # NEUTRAL PHASE: no active signal
    # ══════════════════════════════════════════════════════════════

    def test_neutral(self):
        """No momentum entry, no ride, mid-band."""
        row = _base_row(
            entry=False, grade="—",
            verdict="△ HOLD TREND — no dip yet",
            ride_pctb=0.55, ride_grade="—",
        )
        self.apply(row, "—", adtv_cr=50.0)
        self.assertEqual(row["phase"], "NEUTRAL")
        self.assertEqual(row["grade"], "—")
        self.assertIn("HOLD TREND", row["verdict"])

    def test_neutral_below_mid(self):
        """No signals, below mid-band."""
        row = _base_row(
            entry=False, grade="—",
            verdict="▽ WEAK — below SMA",
            ride_pctb=0.25, ride_grade="—",
        )
        self.apply(row, "—", adtv_cr=5.0)
        self.assertEqual(row["phase"], "NEUTRAL")

    # ══════════════════════════════════════════════════════════════
    # ILLIQUID OVERRIDE (always last)
    # ══════════════════════════════════════════════════════════════

    def test_illiquid_overrides_ride(self):
        """Illiquid ETF with ride entry — illiquid wins, ride_status reset."""
        row = _base_row(
            ride_pctb=1.20, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A]",
            ride_entry=True, entry=False,
            ride_status="ENTRY A",
        )
        self.apply(row, "—", adtv_cr=0.5)
        self.assertIn("ILLIQUID", row["verdict"])
        self.assertEqual(row["grade"], "—")
        self.assertEqual(row["sizing"], "SKIP")
        self.assertFalse(row["entry"])
        self.assertEqual(row["ride_status"], "—")

    def test_illiquid_overrides_momentum(self):
        """Illiquid ETF with momentum entry — illiquid wins."""
        row = _base_row(
            entry=True, grade="A+",
            verdict="▶ BUY FULL [A+] — deep dip",
            ride_pctb=0.30,
        )
        self.apply(row, "A+", adtv_cr=0.3)
        self.assertIn("ILLIQUID", row["verdict"])
        self.assertEqual(row["grade"], "—")

    def test_illiquid_overrides_convergence(self):
        """Illiquid with both signals — illiquid still wins."""
        row = _base_row(
            entry=True, grade="A+",
            verdict="▶ BUY FULL [A+]",
            ride_pctb=1.20, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A]",
            ride_entry=True,
        )
        self.apply(row, "A+", adtv_cr=0.8)
        self.assertIn("ILLIQUID", row["verdict"])
        self.assertEqual(row["grade"], "—")
        self.assertEqual(row["sizing"], "SKIP")

    # ══════════════════════════════════════════════════════════════
    # QUALITY RANK BOOST (convergence)
    # ══════════════════════════════════════════════════════════════

    def test_convergence_boost_riding(self):
        """Ride + momentum → +10 QR boost."""
        row = _base_row(
            entry=True, grade="B",
            ride_pctb=1.14, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A]",
            ride_entry=True, quality_rank=60.0,
        )
        self.apply(row, "B", adtv_cr=50.0)
        self.assertEqual(row["quality_rank"], 70.0)

    def test_no_boost_pure_ride(self):
        """Pure ride (no momentum) → no QR boost."""
        row = _base_row(
            entry=False, ride_pctb=1.14, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A]",
            ride_entry=True, quality_rank=60.0,
        )
        self.apply(row, "—", adtv_cr=50.0)
        self.assertEqual(row["quality_rank"], 60.0)  # unchanged

    def test_no_boost_pure_dip(self):
        """Pure dip (no ride) → no QR boost."""
        row = _base_row(
            entry=True, grade="A", quality_rank=60.0,
            ride_pctb=0.30, ride_grade="—",
        )
        self.apply(row, "A", adtv_cr=50.0)
        self.assertEqual(row["quality_rank"], 60.0)

    def test_convergence_boost_capped(self):
        """QR boost capped at 100."""
        row = _base_row(
            entry=True, grade="B",
            ride_pctb=1.14, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A]",
            ride_entry=True, quality_rank=95.0,
        )
        self.apply(row, "B", adtv_cr=50.0)
        self.assertEqual(row["quality_rank"], 100.0)

    # ══════════════════════════════════════════════════════════════
    # SIZING
    # ══════════════════════════════════════════════════════════════

    def test_ride_sizing_maps_correctly(self):
        """Ride grades map to correct sizing."""
        for grade, expected in [("A+", "FULL"), ("A", "FULL"), ("B+", "HALF"), ("B", "HALF"), ("C+", "SKIP")]:
            row = _base_row(
                ride_pctb=1.10, ride_grade=grade,
                ride_verdict=f"▶ ETF RIDE [{grade}]",
                ride_entry=True, entry=False,
            )
            self.apply(row, "—", adtv_cr=50.0)
            self.assertEqual(row["sizing"], expected, f"Grade {grade} should map to {expected}")

    def test_ride_sizing_skip_if_illiquid(self):
        """Even ride grade A+ → SKIP if illiquid."""
        row = _base_row(
            ride_pctb=1.10, ride_grade="A+",
            ride_verdict="▶ ETF RIDE FULL [A+]",
            ride_entry=True, entry=False,
        )
        self.apply(row, "—", adtv_cr=0.5)
        self.assertEqual(row["sizing"], "SKIP")

    # ══════════════════════════════════════════════════════════════
    # EDGE CASES
    # ══════════════════════════════════════════════════════════════

    def test_pctb_exactly_1(self):
        """%B exactly 1.0 → RIDE phase (boundary)."""
        row = _base_row(
            ride_pctb=1.0, ride_grade="—",
            ride_verdict="△ RIDING — at upper band",
            ride_entry=False, entry=False,
        )
        self.apply(row, "—", adtv_cr=10.0)
        self.assertEqual(row["phase"], "RIDE")

    def test_pctb_just_below_1(self):
        """%B=0.99 → NOT riding, check momentum."""
        row = _base_row(
            ride_pctb=0.99, ride_grade="—",
            entry=True, grade="B",
            verdict="▷ BUY HALF [B]",
        )
        self.apply(row, "B", adtv_cr=10.0)
        self.assertEqual(row["phase"], "DIP")

    def test_none_pctb(self):
        """ride_pctb=None (ride engine didn't compute) → NEUTRAL if no momentum."""
        row = _base_row(
            ride_pctb=None, ride_grade="—",
            entry=False, grade="—",
            verdict="△ HOLD TREND",
        )
        self.apply(row, "—", adtv_cr=10.0)
        self.assertEqual(row["phase"], "NEUTRAL")

    def test_none_pctb_with_momentum(self):
        """ride_pctb=None + momentum entry → DIP."""
        row = _base_row(
            ride_pctb=None, ride_grade="—",
            entry=True, grade="A",
            verdict="▶ BUY FULL [A]",
        )
        self.apply(row, "A", adtv_cr=10.0)
        self.assertEqual(row["phase"], "DIP")

    # ══════════════════════════════════════════════════════════════
    # NAV PREMIUM OVERRIDE
    # ══════════════════════════════════════════════════════════════

    def test_extreme_premium_forces_skip(self):
        """MONQ50 scenario: +18.55% premium → SKIP, snap-back warning, still ranked."""
        row = _base_row(
            ride_pctb=1.99, ride_grade="—",
            ride_verdict="△ RIDING — at upper band, %B=1.99",
            entry=True, grade="A+",
            verdict="▶ BUY FULL [A+] — deep dip",
            sizing="FULL", quality_rank=80.0,
        )
        self.apply(row, "A+", adtv_cr=50.0, nav_prem=18.55)
        self.assertEqual(row["sizing"], "SKIP")
        self.assertTrue(row["entry"])  # still ranked — signal is real
        self.assertIn("snap-back", row["verdict"])
        self.assertIn("18.6%", row["verdict"])
        self.assertLess(row["quality_rank"], 60)  # -30 penalty

    def test_high_premium_caps_to_half(self):
        """Premium 3% → cap sizing from FULL to HALF."""
        row = _base_row(
            ride_pctb=1.14, ride_grade="A",
            ride_verdict="▶ ETF RIDE FULL [A]",
            ride_entry=True, entry=False,
            sizing="FULL",
        )
        self.apply(row, "—", adtv_cr=50.0, nav_prem=3.0)
        self.assertEqual(row["sizing"], "HALF")
        self.assertIn("size capped", row["verdict"])

    def test_high_premium_keeps_half(self):
        """Premium 2.5% + already HALF → stays HALF (not double-downgraded)."""
        row = _base_row(
            ride_pctb=1.10, ride_grade="B+",
            ride_verdict="▷ ETF RIDE HALF [B+]",
            ride_entry=True, entry=False,
            sizing="HALF",
        )
        self.apply(row, "—", adtv_cr=50.0, nav_prem=2.5)
        self.assertEqual(row["sizing"], "HALF")  # stays HALF, not downgraded further

    def test_mild_premium_adds_note(self):
        """Premium 1.2% → note in verdict, no sizing change."""
        row = _base_row(
            entry=True, grade="A",
            verdict="▶ BUY FULL [A] — deep dip",
            sizing="FULL",
        )
        self.apply(row, "A", adtv_cr=50.0, nav_prem=1.2)
        self.assertEqual(row["sizing"], "FULL")  # no change
        self.assertIn("NAV premium", row["verdict"])

    def test_discount_no_penalty(self):
        """Discount -0.58% → no penalty, no note."""
        row = _base_row(
            entry=True, grade="B+",
            verdict="▷ BUY HALF [B+]",
            sizing="HALF",
        )
        original_verdict = row["verdict"]
        self.apply(row, "B+", adtv_cr=50.0, nav_prem=-0.58)
        self.assertEqual(row["sizing"], "HALF")  # unchanged
        self.assertNotIn("premium", row["verdict"])

    def test_nav_none_no_effect(self):
        """nav_prem=None → no override."""
        row = _base_row(
            entry=True, grade="A",
            verdict="▶ BUY FULL [A]",
            sizing="FULL",
        )
        self.apply(row, "A", adtv_cr=50.0, nav_prem=None)
        self.assertEqual(row["sizing"], "FULL")

    def test_premium_before_illiquid(self):
        """Illiquid still overrides premium warning."""
        row = _base_row(
            entry=True, grade="A+",
            verdict="▶ BUY FULL [A+]",
            sizing="FULL", ride_status="ENTRY A+",
        )
        self.apply(row, "A+", adtv_cr=0.5, nav_prem=10.0)
        self.assertIn("ILLIQUID", row["verdict"])
        self.assertEqual(row["sizing"], "SKIP")


if __name__ == "__main__":
    results = unittest.main(exit=False, verbosity=0)
    r = results.result
    passed = r.testsRun - len(r.failures) - len(r.errors)
    print(f"\n{'='*60}")
    print(f"RESULTS: {passed} passed, {len(r.failures) + len(r.errors)} failed")
    print(f"{'='*60}")
    if r.failures:
        for t, tb in r.failures:
            print(f"\nFAILED: {t}")
            print(tb)
    if r.errors:
        for t, tb in r.errors:
            print(f"\nERROR: {t}")
            print(tb)
