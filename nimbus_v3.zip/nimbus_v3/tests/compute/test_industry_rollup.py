"""Tests for nimbus_v3.compute.industry_rollup."""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.industry_rollup import aggregate_industry, IndustryRollup
from nimbus_v3.compute.ride_initiation import RideResult
from nimbus_v3.compute.ride_initiation.types import RidePhase


def _df(adtv: float, n: int = 30) -> pd.DataFrame:
    """A frame whose 20-bar mean Close×Volume equals ``adtv``."""
    idx = pd.bdate_range("2024-01-01", periods=n)
    return pd.DataFrame(
        {"Close": pd.Series(100.0, index=idx),
         "Volume": pd.Series(adtv / 100.0, index=idx)},
    )


def _res(phase: RidePhase, score: float, n: int = 30) -> RideResult:
    idx = pd.bdate_range("2024-01-01", periods=n)
    ph = pd.Series(RidePhase.NONE.value, index=idx, dtype=object)
    ph.iloc[-1] = phase.value
    sc = pd.Series(np.nan, index=idx)
    sc.iloc[-1] = score
    return RideResult(phase=ph, score=sc, fire=pd.Series(False, index=idx))


def test_returns_none_when_no_member_in_panel():
    assert aggregate_industry(["X", "Y"], {}, {}) is None


def test_counts_riders_irrespective_of_phase():
    panel = {"A": _df(100), "B": _df(100), "C": _df(100)}
    sr = {
        "A": _res(RidePhase.CONTINUATION, 50),
        "B": _res(RidePhase.RETEST, 40),
        "C": _res(RidePhase.NONE, float("nan")),
    }
    r = aggregate_industry(["A", "B", "C"], panel, sr)
    assert r.riding == 2          # CONT + RETEST both count
    assert r.members == 3


def test_score_is_breadth_scaled_adtv_weighted_mean():
    # Two riders: one liquid high-score, one illiquid lower-score.
    panel = {"A": _df(1000), "B": _df(100), "C": _df(50)}
    sr = {
        "A": _res(RidePhase.CONTINUATION, 80),
        "B": _res(RidePhase.NONE, float("nan")),
        "C": _res(RidePhase.RETEST, 40),
    }
    r = aggregate_industry(["A", "B", "C"], panel, sr)
    # weighted_mean = (80*1000 + 40*50) / (1050) = 78.095...
    # breadth = 2/3 ; score = 0.6667 * 78.095 = 52.06
    assert r.riding == 2
    assert abs(r.score - 52.06) < 0.5


def test_breadth_penalty_ranks_broad_industry_higher():
    # Same top rider (liquid, score 80) in both industries, but one has
    # more of its members riding → must score strictly higher.
    panel = {"A": _df(1000), "B": _df(100), "C": _df(50)}
    broad = aggregate_industry(
        ["A", "B", "C"], panel,
        {"A": _res(RidePhase.CONTINUATION, 80),
         "B": _res(RidePhase.CONTINUATION, 80),
         "C": _res(RidePhase.CONTINUATION, 80)},
    )
    narrow = aggregate_industry(
        ["A", "B", "C"], panel,
        {"A": _res(RidePhase.CONTINUATION, 80),
         "B": _res(RidePhase.NONE, float("nan")),
         "C": _res(RidePhase.NONE, float("nan"))},
    )
    assert broad.score > narrow.score


def test_no_riders_gives_nan_score():
    panel = {"A": _df(500)}
    r = aggregate_industry(["A"], panel, {"A": _res(RidePhase.NONE, float("nan"))})
    assert r.riding == 0
    assert r.score != r.score    # NaN


def test_adtv_total_sums_members():
    panel = {"A": _df(300), "B": _df(700)}
    r = aggregate_industry(["A", "B"], panel,
                           {"A": _res(RidePhase.NONE, float("nan")),
                            "B": _res(RidePhase.NONE, float("nan"))})
    assert abs(r.adtv_total - 1000.0) < 1.0
