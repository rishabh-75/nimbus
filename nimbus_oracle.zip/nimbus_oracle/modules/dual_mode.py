"""
modules/dual_mode.py — Unified mean-reversion scoring engine for NIMBUS.

WF-validated: 2271 OOS trades, Sharpe 1.20, Win 72.3%, PF 2.02 (68 NSE stocks, 5yr, 6 folds)

ENTRY (all on DAILY bars):
  Core:    WR(30) < -30 AND close < SMA(20) AND MFI(14) > 30
  Primary: + drawdown > 5% from 50d high AND ≥2 consecutive red days AND vol > 0.5x avg
  Secondary: core only (more signals, lower conviction)

EXIT:
  BBW contraction (BBW slope < 0 AND above SMA) OR +5% profit target
  Max hold: 30 days

Score = base(0-100) + options_overlay(±10) + filing_overlay(±10)
Deal levels are display-only (backtest r=0.03, not significant at any band).
"""
import logging
from dataclasses import dataclass
import numpy as np
import pandas as pd


logger = logging.getLogger(__name__)

# ── Entry filter parameters ───────────────────────────────────────────────────
#
# Updated 2026-04-08 from a robust walkforward sweep over 6yr NSE data
# (174 symbols, 5 OOS folds, 648 configurations). The previous values
# (DD<=-5, Streak>=2, Vol>=0.5) ranked #317/648 for robustness with only
# 2/5 positive OOS folds and three consecutive losing fold-windows in
# 2021-10 → 2023-04.
#
# The new values (DD<=-8, Streak>=4, Vol>=1.5) ranked #1/648 with 5/5
# positive folds, MinSh=+0.60, AggSh=+1.13, PF=1.84. The stricter filter
# turns the three losing folds into winners without sacrificing the good
# folds. Captures the same total alpha with ~95% fewer trades but ~3x
# better per-trade Sharpe.
#
# Critically, ENABLE_SECONDARY_TIER is now False — every config in the
# top 25 of the robust sweep used primary_only=True. The SECONDARY tier
# (core gate without DD/Streak/Vol confirmation) was producing low-quality
# signals that diluted the primary edge.
#
# See data/backtest_results/wf_robust_sweep.csv for the full ranking and
# scripts/run_walkforward.py --robust-sweep to reproduce.
WR_PERIOD = 30; WR_THRESH = -30
SMA_PERIOD = 20; MFI_PERIOD = 14; MFI_MIN = 30
DD_MODERATE = -8.0    # drawdown from 50d high (robust sweep #1: -8 sweet spot)
RED_STREAK_MIN = 4    # consecutive red days (robust sweep #1: deeper capitulation)
VOL_MIN_RATIO = 1.5   # volume vs 20d average (robust sweep #1: real selling required)
PROFIT_TARGET = 5.0   # exit at +5% then trail (robust sweep: PT=5 dominates 15/25)
MAX_HOLD = 30          # max hold days
MIN_DAILY_BARS = 35

# When False, compute_dual_mode emits ONLY PRIMARY signals — SECONDARY tier
# is computed but flagged as not_a_signal. The robust sweep showed every
# top-25 config dropped SECONDARY entirely; the loose tier was diluting
# overall edge by firing on shallow non-capitulation pullbacks.
# Set True for research / historical comparison; False for production.
ENABLE_SECONDARY_TIER = False

# ── Bollinger Band parameters ─────────────────────────────────────────────
# The system uses BB at TWO different std multipliers for two different
# purposes. Both share the same period (20). These are separate constants
# so consumers can pick which one they need.
#
#   BB_PERIOD       = 20    — shared period for both
#   BB_STD_BBW      = 2.0   — wider envelope for BBW squeeze detection (MR exits)
#   BB_STD_CHART    = 1.0   — narrower bands for chart visual display + Ride entry
#
# Why two values: the BBW *squeeze* metric works better at 2σ because it
# measures envelope contraction across a wider range, but the chart and the
# BB Ride entry use 1σ because it's a tighter signal for "price touching the
# upper band on a momentum push." See dual_mode.py:152-157 and bb_ride.py:103.
# This is intentional design, not drift.
BB_PERIOD = 20
BB_STD_BBW = 2.0     # used by dual_mode for BBW envelope
BB_STD_CHART = 1.0   # used by ui/data_manager and ui/workers for chart display

# ── Hybrid exit overlay (added April 2026 — fold 5 forensics drove this) ─────
# Principle: cut losers fast, let winners run.
#
# These three rules are added on top of the existing PT / BBW_CONTRACT / MAX_HOLD
# logic. They measure loss/gain from the trade's ENTRY price, NOT from the
# stock's 50-day high (that's `dd_from_high`, used at entry-time only).
#
#   1. HARD STOP — single-trade loss capped at -5% from entry.
#                  Non-negotiable. Fires on every bar regardless of state.
#   2. BAR RATCHET — at bar 8, exit if still underwater (close < entry).
#                    Cuts slow-bleed losers before they grow.
#   3. WINNER RUNNER — when price reaches +5% PT, instead of closing, switch
#                      to a trailing stop. Trail width = min(1.5*ATR, 4% of entry).
#                      Lets winners push past +5% in strong moves.
HARD_STOP_PCT = -5.0     # max acceptable loss per trade (from entry price)
BAR_RATCHET = 8          # cut if still underwater at this bar
TRAIL_ATR_MULT = 1.5     # winner-runner trail = 1.5x ATR from peak
MAX_TRAIL_PCT = 4.0      # cap trail width at 4% of entry (high-vol stocks)

# ── Signal dataclass ──────────────────────────────────────────────────────────
@dataclass
class DualModeSignal:
    """Unified mean-reversion signal. Named DualModeSignal for backward compat."""
    symbol: str = ""
    close: float = 0.0; sma_20: float = 0.0
    above_sma: bool = False; pct_from_sma: float = 0.0
    input_interval: str = ""; daily_bars_used: int = 0; data_sufficient: bool = False

    # Indicators
    wr_30: float = -100.0; mfi: float = 50.0; mfi_slope: float = 0.0
    adx_14: float = 0.0; rsi: float = 50.0
    bbw: float = 0.0; bbw_slope: float = 0.0; bbw_pctl: float = 50.0
    vol_ratio: float = 1.0
    atr: float = 0.0             # ATR(14) — for dynamic targets + stop sizing
    dd_from_high: float = 0.0   # % drawdown from 50d high (negative)
    red_streak: int = 0          # consecutive red candles
    bb_upper: float = 0.0; bb_lower: float = 0.0

    # Entry classification
    tier: str = "NONE"          # PRIMARY, SECONDARY, NONE
    entry_triggered: bool = False
    entry_reason: str = ""
    core_met: bool = False       # WR + SMA + MFI
    primary_met: bool = False    # core + DD + streak + vol
    secondary_met: bool = False  # core only

    # Scoring
    base_score: int = 0
    options_overlay: int = 0; options_detail: str = ""
    filing_overlay: int = 0; filing_detail: str = ""
    is_trap: bool = False  # filing TRAP only
    dual_score: int = 0; dual_label: str = "NEUTRAL"; dual_sizing: str = "SKIP"

    # Exit state
    exit_signal: str = ""
    bbw_contracting: bool = False; above_sma_exit: bool = False

    # Backward compat aliases
    segment: str = "UNIFIED"; mode: str = "MR"
    wr_20: float = -100.0; wr_20_cross_bars: int = 99; adx_trending: bool = False
    mode_a_entry: bool = False; mode_b_entry: bool = False


# ── Indicator computation ─────────────────────────────────────────────────────

def _compute_indicators(daily: pd.DataFrame) -> pd.DataFrame:
    """
    Add all indicators needed for scoring. Operates on daily bars.

    Uses canonical functions from indicators.py for WR, MFI, ADX.
    If indicators already exist in the DataFrame (e.g. from PriceWorker),
    they are NOT recomputed — single source of truth.

    BB uses 2σ for BBW squeeze detection (chart uses 1σ for visual bands —
    intentionally different, so BBW is always computed fresh here).
    """
    from modules.indicators import add_williams_r, add_mfi, add_adx

    d = daily.copy()
    c = d["Close"]; h = d["High"]; l = d["Low"]
    v = d["Volume"] if "Volume" in d.columns else pd.Series(0, index=d.index)

    # SMA (no canonical function — trivial)
    if "SMA" not in d.columns:
        d["SMA"] = c.rolling(SMA_PERIOD).mean()

    # WR — canonical function, period must match WR_PERIOD
    if "WR" not in d.columns:
        d = add_williams_r(d, period=WR_PERIOD)

    # ADX — canonical function (adds ADX_14, we alias to ADX)
    if "ADX" not in d.columns:
        d = add_adx(d, period=14)
        if "ADX_14" in d.columns:
            d["ADX"] = d["ADX_14"]
    # ATR (needed for targets, compute if missing)
    if "ATR" not in d.columns:
        tr = pd.concat([h-l, (h-c.shift(1)).abs(), (l-c.shift(1)).abs()], axis=1).max(axis=1)
        d["ATR"] = tr.rolling(14).mean()

    # MFI — canonical function (adds MFI_14, we alias to MFI)
    if "MFI" not in d.columns:
        d = add_mfi(d, period=MFI_PERIOD)
        if f"MFI_{MFI_PERIOD}" in d.columns:
            d["MFI"] = d[f"MFI_{MFI_PERIOD}"]
        else:
            d["MFI"] = np.nan
    if "MFI_slope" not in d.columns:
        d["MFI_slope"] = d["MFI"].diff(3)

    # RSI(14) — no canonical function, compute inline
    if "RSI" not in d.columns:
        delta = c.diff(); gain = delta.clip(lower=0); loss = -delta.clip(upper=0)
        ag = gain.rolling(14).mean(); al = loss.rolling(14).mean()
        d["RSI"] = 100 - (100 / (1 + ag / al.replace(0, np.nan)))

    # BB (2σ for BBW squeeze detection — intentionally different from chart's 1σ)
    # Always computed fresh because BBW/BBW_slope/BBW_pctl use 2σ envelope.
    # Constants live at the top of this file (BB_PERIOD, BB_STD_BBW) so any
    # consumer that wants the "BBW envelope" parameters can import them
    # directly. The chart uses BB_STD_CHART instead.
    bb_ma = c.rolling(BB_PERIOD).mean(); bb_sd = c.rolling(BB_PERIOD).std()
    d["BB_Upper_2s"] = bb_ma + BB_STD_BBW * bb_sd
    d["BB_Lower_2s"] = bb_ma - BB_STD_BBW * bb_sd
    d["BBW"] = ((d["BB_Upper_2s"] - d["BB_Lower_2s"]) / bb_ma.replace(0, np.nan) * 100)
    d["BBW_slope"] = d["BBW"].diff(5)
    d["BBW_pctl"] = d["BBW"].rolling(100, min_periods=20).apply(
        lambda x: pd.Series(x).rank(pct=True).iloc[-1] * 100, raw=False
    )

    # Volume ratio
    if "VOL_RATIO" not in d.columns:
        d["VOL_RATIO"] = v / v.rolling(20).mean().replace(0, np.nan)

    # Drawdown from 50d high (use min_periods for short histories)
    if "DD_FROM_HIGH" not in d.columns:
        d["HIGH_50"] = h.rolling(50, min_periods=20).max()
        d["DD_FROM_HIGH"] = ((c - d["HIGH_50"]) / d["HIGH_50"]) * 100

    # Consecutive red days
    if "RED_STREAK" not in d.columns:
        red = (c < c.shift(1)).astype(int)
        d["RED_STREAK"] = red.groupby((red != red.shift()).cumsum()).cumsum()

    return d


# ── Validate daily data ──────────────────────────────────────────────────────

def _validate_daily(df):
    """Validate that input is daily data. Returns (df, interval_label)."""
    if df is None or df.empty or len(df) < 10:
        return df, "UNKNOWN"
    return df, "1D"


# ── Main computation ──────────────────────────────────────────────────────────

def compute_dual_mode(price_df, symbol="", segment="", options_ctx=None,
                      filing_variance=None):
    """Compute unified mean-reversion signal from price data."""
    sig = DualModeSignal(symbol=symbol, segment="UNIFIED", mode="MR")

    if price_df is None or len(price_df) < 20:
        return sig

    daily, interval = _validate_daily(price_df)
    sig.input_interval = interval
    if daily is None or len(daily) < MIN_DAILY_BARS:
        return sig

    sig.daily_bars_used = len(daily)
    sig.data_sufficient = True

    # Compute all indicators
    df = _compute_indicators(daily)
    last = df.iloc[-1]

    # Extract values
    sig.close = float(last["Close"])
    sig.sma_20 = float(last["SMA"]) if not pd.isna(last["SMA"]) else 0.0
    if sig.sma_20 > 0:
        sig.above_sma = sig.close > sig.sma_20
        sig.pct_from_sma = (sig.close / sig.sma_20 - 1) * 100

    sig.wr_30 = float(last["WR"]) if not pd.isna(last["WR"]) else -100.0
    sig.mfi = float(last["MFI"]) if not pd.isna(last["MFI"]) else 50.0
    sig.mfi_slope = float(last["MFI_slope"]) if not pd.isna(last["MFI_slope"]) else 0.0
    sig.adx_14 = float(last["ADX"]) if not pd.isna(last["ADX"]) else 0.0
    sig.adx_trending = sig.adx_14 >= 20
    sig.rsi = float(last["RSI"]) if not pd.isna(last["RSI"]) else 50.0
    sig.bbw = float(last["BBW"]) if not pd.isna(last["BBW"]) else 0.0
    sig.bbw_slope = float(last["BBW_slope"]) if not pd.isna(last["BBW_slope"]) else 0.0
    sig.bbw_pctl = float(last["BBW_pctl"]) if not pd.isna(last.get("BBW_pctl", np.nan)) else 50.0
    sig.vol_ratio = float(last["VOL_RATIO"]) if not pd.isna(last["VOL_RATIO"]) else 1.0
    sig.atr = float(last["ATR"]) if not pd.isna(last["ATR"]) else 0.0
    sig.dd_from_high = float(last["DD_FROM_HIGH"]) if not pd.isna(last["DD_FROM_HIGH"]) else 0.0
    sig.red_streak = int(last["RED_STREAK"]) if not pd.isna(last["RED_STREAK"]) else 0
    sig.bb_upper = float(last["BB_Upper"]) if "BB_Upper" in last and not pd.isna(last["BB_Upper"]) else 0.0
    sig.bb_lower = float(last["BB_Lower"]) if "BB_Lower" in last and not pd.isna(last["BB_Lower"]) else 0.0

    # BBW exit state
    sig.bbw_contracting = sig.bbw_slope < 0
    sig.above_sma_exit = sig.above_sma

    # Backward compat
    sig.wr_20 = sig.wr_30; sig.wr_20_cross_bars = 99

    # ── Entry classification ──────────────────────────────────────────────
    # Core: WR(30) < -30, below SMA(20), MFI > 30
    sig.core_met = (
        sig.wr_30 < WR_THRESH
        and not sig.above_sma
        and sig.sma_20 > 0
        and sig.mfi >= MFI_MIN
    )

    # Primary: core + drawdown + red streak + volume
    sig.primary_met = (
        sig.core_met
        and sig.dd_from_high <= DD_MODERATE
        and sig.red_streak >= RED_STREAK_MIN
        and sig.vol_ratio >= VOL_MIN_RATIO
    )

    # Secondary: core only
    sig.secondary_met = sig.core_met and not sig.primary_met

    if sig.primary_met:
        sig.tier = "PRIMARY"
        sig.entry_triggered = True
        sig.entry_reason = (
            f"WR(30)={sig.wr_30:.0f} | {sig.pct_from_sma:+.1f}% vs SMA | "
            f"MFI={sig.mfi:.0f} | DD={sig.dd_from_high:.1f}% | "
            f"{sig.red_streak}d red | Vol={sig.vol_ratio:.1f}x"
        )
    elif sig.secondary_met and ENABLE_SECONDARY_TIER:
        sig.tier = "SECONDARY"
        sig.entry_triggered = True
        sig.entry_reason = (
            f"WR(30)={sig.wr_30:.0f} | {sig.pct_from_sma:+.1f}% vs SMA | "
            f"MFI={sig.mfi:.0f}"
        )
    else:
        sig.tier = "NONE"
        sig.entry_triggered = False

    # Backward compat
    sig.mode_b_entry = sig.entry_triggered
    sig.mode_a_entry = False

    # ── Base score ────────────────────────────────────────────────────────
    sig.base_score = _score(sig)

    # ── Overlays ──────────────────────────────────────────────────────────
    sig.options_overlay, sig.options_detail = _options_overlay(options_ctx, sig)
    sig.filing_overlay, sig.filing_detail, sig.is_trap = _filing_overlay(filing_variance, sig.base_score)

    # ── Final score ───────────────────────────────────────────────────────
    final = max(0, min(100, sig.base_score + sig.options_overlay + sig.filing_overlay))
    if sig.is_trap:
        final = min(final, 30)
    sig.dual_score = final
    sig.dual_label, sig.dual_sizing = _label_and_sizing(final, sig)

    return sig


# ── Scoring function ──────────────────────────────────────────────────────────

def _score(sig):
    """
    Score the mean-reversion setup (0-100).

    IMPORTANT: This score is an ENTRY GATE, not a conviction ranking.
    Walk-forward validated the ENTRY BOUNDARIES (WR<-30, SMA, MFI>=30)
    that produce Sharpe 1.20, 72% win. These work.

    KNOWN ISSUE (factor backtest 2026-03-29):
    Score has r=-0.032 with PnL (inverted). High scores DON'T predict
    better outcomes. Within accepted entries, moderate pullbacks with
    strong flow outperform deep capitulations.

    The GRADE system (_compute_grade in scanner.py) handles conviction
    ranking using data-validated factors: MFI, RSI, vol_ratio, VIX.
    Changing this score formula would require re-running walk-forward
    to validate new entry boundaries.
    """
    s = 30  # base

    # WR depth (deeper oversold = stronger bounce)
    if sig.wr_30 < -70:   s += 25
    elif sig.wr_30 < -50: s += 20
    elif sig.wr_30 < -30: s += 15
    elif sig.wr_30 < -20: s += 5

    # Distance below SMA (larger pullback = more room for reversion)
    if not sig.above_sma:
        if sig.pct_from_sma < -5.0:   s += 15
        elif sig.pct_from_sma < -3.0: s += 12
        elif sig.pct_from_sma < -1.5: s += 8
        elif sig.pct_from_sma < -0.5: s += 4
    else:
        s -= 10  # above SMA = not a pullback

    # MFI (money flow)
    if sig.mfi >= 50:     s += 8   # strong flow into dip
    elif sig.mfi >= 30:   s += 3   # acceptable
    else:                 s -= 5   # weak = no accumulation

    # MFI rising (smart money buying the dip)
    if sig.mfi_slope > 3: s += 4

    # Drawdown from high (deeper = more capitulation)
    if sig.dd_from_high <= -10:  s += 8
    elif sig.dd_from_high <= -5: s += 4

    # Red streak (selling exhaustion)
    if sig.red_streak >= 4:   s += 6
    elif sig.red_streak >= 2: s += 3

    # Volume (institutional presence during dip)
    if sig.vol_ratio >= 1.5: s += 4  # volume surge
    elif sig.vol_ratio < 0.5: s -= 3  # dry volume

    # BBW state (squeeze before entry = coiled spring)
    if sig.bbw_pctl < 30:   s += 3
    elif sig.bbw_pctl > 70:  s -= 2  # already expanded

    return max(0, min(100, s))


# ── Options overlay (mean-reversion mode only) ────────────────────────────────

def _options_overlay(ctx, sig):
    """
    Options context overlay.

    Only EXTREME PCR affects the score (validated threshold: >1.5 or <0.3).
    Moderate PCR (0.3-1.5) and GEX are context only — zero score impact.

    P(win) study: factors with Cohen's d < 0.2 don't predict individual
    trade outcomes. Options flow operates on intraday/weekly timescale
    while MR trades hold 5-21 days. Only extremes survive the timescale gap.

    Thresholds:
        PCR < 0.3  → extreme complacency, calls dominate, dip may not be done (-3)
        PCR > 1.5  → capitulation puts, heavy hedging = contrarian bullish (+3)
        0.3 - 1.5  → moderate range, no score impact (context only)
    """
    if ctx is None: return 0, "No options data"
    ov = 0; det = []
    try:
        pcr = getattr(getattr(ctx, "walls", None), "pcr_oi", None)
        gex = getattr(getattr(ctx, "gex", None), "regime", None)
        sp = getattr(getattr(ctx, "walls", None), "support_pct", None)

        if pcr is not None:
            if pcr < 0.3:
                ov -= 3
                det.append(f"PCR {pcr:.2f} extreme complacency — dip may deepen")
            elif pcr > 1.5:
                ov += 3
                det.append(f"PCR {pcr:.2f} capitulation puts — contrarian bullish")
            elif pcr <= 0.7:
                det.append(f"PCR {pcr:.2f} mildly bearish")
            elif pcr >= 1.3:
                det.append(f"PCR {pcr:.2f} elevated puts")
            else:
                det.append(f"PCR {pcr:.2f}")

        if gex is not None:
            if gex == "Negative":
                det.append("GEX negative (volatile, wider intraday swings)")
            elif gex == "Positive":
                det.append("GEX positive (dampened, pins toward strikes)")

        if sp is not None and abs(sp) < 2.0:
            ov += 2; det.append(f"Near OI support {sp:+.1f}%")
    except Exception: pass
    return max(-10, min(10, ov)), " | ".join(det) if det else "Neutral"


# ── Filing overlay ────────────────────────────────────────────────────────────

def _filing_overlay(fv, base_score):
    if fv is None: return 0, "No filing", False
    try:
        d = getattr(fv, "badge_color", "NONE")
        c = getattr(fv, "conviction", 0)
        if d == "BEARISH" and base_score >= 55:
            return -10, f"TRAP: bearish (conv {c}) vs high base", True
        if d == "BEARISH":
            return -5, f"Bearish filing (conv {c})", False
        if d == "BULLISH":
            ov = 7 if c >= 7 else (4 if c >= 5 else 2)
            return ov, f"Bullish filing (conv {c})", False
    except Exception: pass
    return 0, "Neutral", False


# ── Label and sizing ──────────────────────────────────────────────────────────

def _label_and_sizing(score, sig):
    if sig.is_trap: return "AVOID", "SKIP"
    if sig.tier == "PRIMARY":
        if score >= 75: return "STRONG", "FULL"
        if score >= 60: return "GOOD", "FULL"
        if score >= 45: return "WATCH", "HALF"
        return "AVOID", "SKIP"
    elif sig.tier == "SECONDARY":
        if score >= 75: return "STRONG", "HALF"
        if score >= 60: return "GOOD", "HALF"
        if score >= 45: return "WATCH", "SKIP"
        return "AVOID", "SKIP"
    else:
        if score >= 75: return "STRONG", "HALF"
        if score >= 60: return "GOOD", "SKIP"
        if score >= 45: return "WATCH", "SKIP"
        return "AVOID", "SKIP"


# ── Exit check ────────────────────────────────────────────────────────────────

def check_exit(sig, entry_price, bars_held, *,
               peak_price: float = 0.0,
               atr_at_entry: float = 0.0,
               in_trail_mode: bool = False):
    """
    Check exit conditions. Returns exit reason string or '' (empty = hold).

    Backward-compatible signature: legacy callers pass (sig, entry_price, bars_held)
    and get only the original PT/BBW/MAX_HOLD rules. The new hybrid rules
    activate when the caller supplies peak_price and atr_at_entry.

    Priority order (first match wins, applied on every bar):
      1. HARD_STOP    — loss from entry ≤ -5%, non-negotiable
      2. BAR_RATCHET  — at bar 8, still underwater, not yet in trail mode
      3. PROFIT_TARGET → switches to TRAIL mode if winner runner is enabled
      4. TRAIL_STOP   — only when in_trail_mode (peak_price has been seen)
      5. BBW_CONTRACT — original signal-driven exit
      6. MAX_HOLD     — final fallback

    Args:
        sig: DualModeSignal with current bar data (close, bbw_contracting, etc.)
        entry_price: price at which the trade was entered
        bars_held: number of bars since entry
        peak_price: highest close seen since entry (for trailing stop)
        atr_at_entry: ATR(14) at the entry bar (for trail width sizing)
        in_trail_mode: True if PT was already hit and we're trailing

    Returns:
        Exit reason string. New strings introduced:
          'HARD_STOP'    — -5% floor fired
          'BAR_RATCHET'  — bar-8 underwater check fired
          'TRAIL_STOP'   — winner-runner trailing stop fired
        Existing strings unchanged: PROFIT_TARGET, BBW_CONTRACT, MAX_HOLD, ''
    """
    c = sig.close
    if entry_price <= 0:
        return ""

    loss_pct = (c / entry_price - 1) * 100

    # Rule 1: HARD STOP — non-negotiable, checked first on every bar
    if loss_pct <= HARD_STOP_PCT:
        return "HARD_STOP"

    # Rule 2: BAR RATCHET — only at the checkpoint bar, only if not in trail
    if not in_trail_mode and bars_held == BAR_RATCHET and c < entry_price:
        return "BAR_RATCHET"

    # Rule 3: PROFIT TARGET — original logic, but caller decides whether to
    # switch to trail mode after this fires (it's a transition, not just an exit)
    if c >= entry_price * (1 + PROFIT_TARGET / 100):
        return "PROFIT_TARGET"

    # Rule 4: TRAIL STOP — only fires if we're already in trail mode
    if in_trail_mode and peak_price > 0 and atr_at_entry > 0:
        raw_trail = TRAIL_ATR_MULT * atr_at_entry
        max_trail = entry_price * MAX_TRAIL_PCT / 100
        trail_width = min(raw_trail, max_trail)
        trail_stop = peak_price - trail_width
        if c <= trail_stop:
            return "TRAIL_STOP"

    # Rule 5: BBW contraction — only after a couple of bars
    if bars_held >= 5 and sig.bbw_contracting and sig.above_sma:
        return "BBW_CONTRACT"

    # Rule 6: Max hold
    if bars_held >= MAX_HOLD:
        return "MAX_HOLD"

    return ""


# ── Summary (for logging/display) ────────────────────────────────────────────

def signal_summary(sig):
    return {
        "tier": sig.tier, "mode": "Mean Reversion",
        "entry_triggered": sig.entry_triggered, "entry_reason": sig.entry_reason,
        "base_score": sig.base_score,
        "wr_30": sig.wr_30, "mfi": sig.mfi, "adx_14": sig.adx_14,
        "rsi": sig.rsi, "dd_from_high": sig.dd_from_high,
        "red_streak": sig.red_streak, "vol_ratio": sig.vol_ratio,
        "bbw_slope": sig.bbw_slope, "bbw_pctl": sig.bbw_pctl,
        "pct_from_sma": sig.pct_from_sma, "above_sma": sig.above_sma,
        "options_overlay": sig.options_overlay, "filing_overlay": sig.filing_overlay,
        "is_trap": sig.is_trap, "final_score": sig.dual_score,
        "label": sig.dual_label, "sizing": sig.dual_sizing,
        "close": sig.close, "sma_20": sig.sma_20,
    }

# Backward compat: old names still importable
# Backward compat (kept for any external callers)
_score_mode_a = _score
_score_mode_b = _score
