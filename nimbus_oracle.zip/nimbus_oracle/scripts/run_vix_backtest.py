#!/usr/bin/env python3
"""
scripts/run_vix_backtest.py — Volatility regime analysis against OOS trades.

Tests whether volatility at entry predicts mean-reversion trade outcomes.
Three measures tested:
  1. India VIX at entry (market-level implied vol)
  2. Universe realized vol (avg 20d vol across all symbols)
  3. Per-stock realized vol at entry (stock's own 20d vol)

Usage:
    python3 scripts/run_vix_backtest.py
    python3 scripts/run_vix_backtest.py --trades data/backtest_results/wf_oos_trades.csv
"""
import argparse, datetime, logging, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.output import enable_export; enable_export()

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("vix_bt")

# ── VIX buckets ──────────────────────────────────────────────────────────────

VIX_BUCKETS = [
    ("Low (<13)", 0, 13),
    ("Normal (13-18)", 13, 18),
    ("Elevated (18-24)", 18, 24),
    ("Panic (>24)", 24, 999),
]

RVOL_BUCKETS = [
    ("Low (<15%)", 0, 15),
    ("Normal (15-25%)", 15, 25),
    ("High (25-40%)", 25, 40),
    ("Extreme (>40%)", 40, 999),
]


def calc_stats(pnls):
    if len(pnls) < 3:
        return {"n": len(pnls), "avg": 0, "win": 0, "sharpe": 0, "median": 0}
    arr = np.array(pnls)
    avg = float(np.mean(arr))
    std = float(np.std(arr))
    return {
        "n": len(arr),
        "avg": round(avg, 3),
        "win": round((arr > 0).mean() * 100, 1),
        "sharpe": round(avg / std * np.sqrt(252/10), 2) if std > 0 else 0,
        "median": round(float(np.median(arr)), 3),
        "worst": round(float(arr.min()), 2),
        "best": round(float(arr.max()), 2),
    }


# ── Data loading ─────────────────────────────────────────────────────────────

def load_trades(path):
    df = pd.read_csv(path)
    df["entry_date"] = pd.to_datetime(df["entry_date"])
    logger.info("Loaded %d trades from %s", len(df), path)
    logger.info("  Date range: %s → %s", df["entry_date"].min().date(), df["entry_date"].max().date())
    return df


def fetch_vix_history(start, end):
    """Fetch India VIX daily close from yfinance."""
    try:
        import yfinance as yf
        vix = yf.download("^INDIAVIX", start=start, end=end, progress=False)
        if vix is None or vix.empty:
            logger.warning("India VIX download returned empty")
            return None
        if isinstance(vix.columns, pd.MultiIndex):
            vix.columns = vix.columns.get_level_values(0)
        vix.index = pd.to_datetime(vix.index)
        if hasattr(vix.index, "tz") and vix.index.tz is not None:
            vix.index = vix.index.tz_localize(None)
        logger.info("India VIX: %d days, range %.1f – %.1f",
                    len(vix), vix["Close"].min(), vix["Close"].max())
        return vix["Close"]
    except Exception as exc:
        logger.warning("VIX fetch failed: %s", exc)
        return None


def compute_stock_rvol(trades_df, price_cache_path="data/backtest_cache"):
    """
    Compute 20-day annualized realized vol for each stock at entry date.
    Uses cached price data from walk-forward (parquet files in backtest_cache).
    Falls back to yfinance if cache missing.
    """
    rvols = []
    symbols = trades_df["symbol"].unique()

    # Load price data per symbol
    price_data = {}
    for sym in symbols:
        cache_file = os.path.join(price_cache_path, f"{sym}_1d.parquet")
        if os.path.exists(cache_file):
            try:
                df = pd.read_parquet(cache_file)
                df.index = pd.to_datetime(df.index)
                if hasattr(df.index, "tz") and df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                price_data[sym] = df
            except Exception:
                pass

    # Fetch missing symbols from yfinance
    missing = [s for s in symbols if s not in price_data]
    if missing:
        logger.info("Fetching price data for %d symbols without cache...", len(missing))
        try:
            import yfinance as yf
            for i, sym in enumerate(missing):
                try:
                    df = yf.download(f"{sym}.NS", period="5y", progress=False, timeout=10)
                    if df is not None and not df.empty:
                        if isinstance(df.columns, pd.MultiIndex):
                            df.columns = df.columns.get_level_values(0)
                        df.index = pd.to_datetime(df.index)
                        if hasattr(df.index, "tz") and df.index.tz is not None:
                            df.index = df.index.tz_localize(None)
                        price_data[sym] = df
                except Exception:
                    pass
                if (i+1) % 20 == 0:
                    logger.info("  %d/%d fetched", i+1, len(missing))
        except ImportError:
            logger.warning("yfinance not available for missing symbols")

    logger.info("Price data available for %d/%d symbols", len(price_data), len(symbols))

    # Compute per-trade realized vol
    for _, row in trades_df.iterrows():
        sym = row["symbol"]
        entry_dt = row["entry_date"]
        rvol = np.nan

        if sym in price_data:
            df = price_data[sym]
            # Get 20 trading days ending at or before entry
            mask = df.index <= entry_dt
            if mask.sum() >= 20:
                recent = df.loc[mask].tail(21)  # 21 prices → 20 returns
                if len(recent) >= 20:
                    returns = recent["Close"].pct_change().dropna()
                    if len(returns) >= 15:
                        rvol = float(returns.std() * np.sqrt(252) * 100)  # annualized %

        rvols.append(rvol)

    return np.array(rvols)


# ── Tests ────────────────────────────────────────────────────────────────────

def test_vix_buckets(trades_df, vix_series, report):
    """TEST 1: Win rate and returns by India VIX level at entry."""
    report.append("\n" + "="*70)
    report.append("TEST 1: INDIA VIX REGIME AT ENTRY")
    report.append("="*70)

    if vix_series is None:
        report.append("  India VIX data not available — skipping")
        return

    # Match VIX to trade entry dates
    vix_at_entry = []
    for _, row in trades_df.iterrows():
        dt = row["entry_date"]
        # Find closest VIX reading on or before entry
        mask = vix_series.index <= dt
        if mask.any():
            vix_at_entry.append(float(vix_series[mask].iloc[-1]))
        else:
            vix_at_entry.append(np.nan)

    trades_df = trades_df.copy()
    trades_df["vix"] = vix_at_entry
    valid = trades_df.dropna(subset=["vix"])
    report.append(f"\n  VIX matched: {len(valid)}/{len(trades_df)} trades")

    for label, lo, hi in VIX_BUCKETS:
        bucket = valid[(valid["vix"] >= lo) & (valid["vix"] < hi)]
        if len(bucket) < 10:
            report.append(f"  {label:20s}: N={len(bucket):4d}  (insufficient)")
            continue
        s = calc_stats(bucket["pnl_pct"].values)
        report.append(f"  {label:20s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}  "
                      f"worst={s['worst']:.1f}%  best={s['best']:.1f}%")

    # T-test: low VIX vs high VIX
    low = valid[valid["vix"] < 15]["pnl_pct"].values
    high = valid[valid["vix"] >= 20]["pnl_pct"].values
    if len(low) >= 20 and len(high) >= 20:
        try:
            from scipy import stats
            t, p = stats.ttest_ind(low, high, equal_var=False)
            sig = "✓ SIGNIFICANT" if p < 0.05 else "○ not significant"
            report.append(f"\n  Low VIX (<15) vs High VIX (≥20):")
            report.append(f"    t={t:.3f}  p={p:.4f}  {sig}")
            report.append(f"    Low:  avg={np.mean(low):+.3f}%  win={np.mean(low>0)*100:.1f}%")
            report.append(f"    High: avg={np.mean(high):+.3f}%  win={np.mean(high>0)*100:.1f}%")
        except ImportError:
            report.append("  (scipy not installed — skipping t-test)")


def test_stock_rvol(trades_df, rvols, report):
    """TEST 2: Win rate and returns by per-stock realized vol at entry."""
    report.append("\n" + "="*70)
    report.append("TEST 2: PER-STOCK REALIZED VOL (20D) AT ENTRY")
    report.append("="*70)

    trades_df = trades_df.copy()
    trades_df["rvol"] = rvols
    valid = trades_df.dropna(subset=["rvol"])
    report.append(f"\n  Realized vol computed: {len(valid)}/{len(trades_df)} trades")
    report.append(f"  Vol range: {np.nanmin(rvols):.1f}% – {np.nanmax(rvols):.1f}%  "
                  f"median={np.nanmedian(rvols):.1f}%")

    for label, lo, hi in RVOL_BUCKETS:
        bucket = valid[(valid["rvol"] >= lo) & (valid["rvol"] < hi)]
        if len(bucket) < 10:
            report.append(f"  {label:20s}: N={len(bucket):4d}  (insufficient)")
            continue
        s = calc_stats(bucket["pnl_pct"].values)
        report.append(f"  {label:20s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}  "
                      f"worst={s['worst']:.1f}%  best={s['best']:.1f}%")

    # Correlation
    mask = ~np.isnan(rvols)
    if mask.sum() >= 30:
        r = np.corrcoef(rvols[mask], trades_df["pnl_pct"].values[mask])[0, 1]
        report.append(f"\n  Pearson r (rvol vs return): {r:.4f}")
        if abs(r) > 0.15:
            report.append("  ✓ SIGNIFICANT — vol regime affects returns")
        elif abs(r) > 0.05:
            report.append("  ○ WEAK — consider as sizing gate, not score modifier")
        else:
            report.append("  ✗ NO correlation — vol regime doesn't predict returns")

    # T-test: low vol vs high vol
    low = valid[valid["rvol"] < 20]["pnl_pct"].values
    high = valid[valid["rvol"] >= 35]["pnl_pct"].values
    if len(low) >= 20 and len(high) >= 20:
        try:
            from scipy import stats
            t, p = stats.ttest_ind(low, high, equal_var=False)
            sig = "✓ SIGNIFICANT" if p < 0.05 else "○ not significant"
            report.append(f"\n  Low vol (<20%) vs High vol (≥35%):")
            report.append(f"    t={t:.3f}  p={p:.4f}  {sig}")
            report.append(f"    Low:  N={len(low)}  avg={np.mean(low):+.3f}%  win={np.mean(low>0)*100:.1f}%")
            report.append(f"    High: N={len(high)}  avg={np.mean(high):+.3f}%  win={np.mean(high>0)*100:.1f}%")
        except ImportError:
            report.append("  (scipy not installed — skipping t-test)")


def test_combined_regime(trades_df, vix_series, rvols, report):
    """TEST 3: Combined VIX + stock vol regime analysis."""
    report.append("\n" + "="*70)
    report.append("TEST 3: COMBINED REGIME (VIX × STOCK VOL)")
    report.append("="*70)

    if vix_series is None:
        report.append("  India VIX not available — skipping")
        return

    trades_df = trades_df.copy()
    trades_df["rvol"] = rvols

    vix_at_entry = []
    for _, row in trades_df.iterrows():
        dt = row["entry_date"]
        mask = vix_series.index <= dt
        if mask.any():
            vix_at_entry.append(float(vix_series[mask].iloc[-1]))
        else:
            vix_at_entry.append(np.nan)
    trades_df["vix"] = vix_at_entry

    valid = trades_df.dropna(subset=["vix", "rvol"])
    report.append(f"\n  Both VIX + rvol available: {len(valid)} trades")

    # 2x2 matrix: VIX low/high × stock vol low/high
    combos = [
        ("Calm market + Low vol stock", lambda r: r["vix"] < 16 and r["rvol"] < 25),
        ("Calm market + High vol stock", lambda r: r["vix"] < 16 and r["rvol"] >= 25),
        ("Stressed market + Low vol stock", lambda r: r["vix"] >= 16 and r["rvol"] < 25),
        ("Stressed market + High vol stock", lambda r: r["vix"] >= 16 and r["rvol"] >= 25),
    ]

    for label, cond in combos:
        bucket = valid[valid.apply(cond, axis=1)]
        if len(bucket) < 15:
            report.append(f"  {label:38s}: N={len(bucket):4d}  (insufficient)")
            continue
        s = calc_stats(bucket["pnl_pct"].values)
        report.append(f"  {label:38s}: N={s['n']:4d}  avg={s['avg']:+.3f}%  "
                      f"win={s['win']:.1f}%  Sh={s['sharpe']:.2f}")


def test_exit_reason_by_vol(trades_df, rvols, report):
    """TEST 4: Do high-vol entries hit MAX_HOLD more often (= fail to revert)?"""
    report.append("\n" + "="*70)
    report.append("TEST 4: EXIT REASON BY VOLATILITY REGIME")
    report.append("="*70)

    trades_df = trades_df.copy()
    trades_df["rvol"] = rvols
    valid = trades_df.dropna(subset=["rvol"])

    for label, lo, hi in RVOL_BUCKETS:
        bucket = valid[(valid["rvol"] >= lo) & (valid["rvol"] < hi)]
        if len(bucket) < 20:
            continue
        n = len(bucket)
        pt_pct = (bucket["exit_reason"] == "PT").mean() * 100
        bbw_pct = (bucket["exit_reason"] == "BBW").mean() * 100
        max_pct = (bucket["exit_reason"] == "MAX").mean() * 100
        report.append(f"  {label:20s}: N={n:4d}  PT={pt_pct:.0f}%  BBW={bbw_pct:.0f}%  MAX={max_pct:.0f}%")

    report.append("\n  If MAX% rises with vol → high vol = trades fail to revert in time")
    report.append("  If PT% falls with vol → high vol = less clean profit-target exits")


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="VIX/Volatility Regime Backtest")
    parser.add_argument("--trades", default="data/backtest_results/wf_oos_trades.csv")
    parser.add_argument("--output", default="vix_backtest_report.txt")
    args = parser.parse_args()

    trades_df = load_trades(args.trades)
    if "entry_price" not in trades_df.columns:
        logger.error("Missing entry_price column — run updated walk-forward first")
        sys.exit(1)

    # Fetch India VIX
    start = trades_df["entry_date"].min() - pd.Timedelta(days=30)
    end = trades_df["entry_date"].max() + pd.Timedelta(days=5)
    logger.info("Fetching India VIX history...")
    vix_series = fetch_vix_history(start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"))

    # Compute per-stock realized vol
    logger.info("Computing per-stock realized vol...")
    rvols = compute_stock_rvol(trades_df)
    valid_rvols = np.sum(~np.isnan(rvols))
    logger.info("Realized vol computed: %d/%d trades", valid_rvols, len(trades_df))

    # Run tests
    report = []
    report.append("=" * 70)
    report.append("VOLATILITY REGIME BACKTEST REPORT")
    report.append(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    report.append(f"Trades: {len(trades_df)} OOS from walk-forward")
    report.append(f"Symbols: {trades_df['symbol'].nunique()}")
    report.append(f"Trade dates: {trades_df['entry_date'].min().date()} → {trades_df['entry_date'].max().date()}")
    report.append("=" * 70)

    test_vix_buckets(trades_df, vix_series, report)
    test_stock_rvol(trades_df, rvols, report)
    test_combined_regime(trades_df, vix_series, rvols, report)
    test_exit_reason_by_vol(trades_df, rvols, report)

    # Decision framework
    report.append("\n" + "=" * 70)
    report.append("DECISION FRAMEWORK")
    report.append("=" * 70)
    report.append("""
  IF VIX buckets show monotonic decline in win%/avg from Low → Panic:
    → VIX is a valid regime filter
    → Consider: VIX > 22 → reduce sizing from FULL to HALF
    → Consider: VIX > 28 → no new entries (SKIP all)

  IF per-stock rvol shows r > 0.10 with returns:
    → Stock vol is predictive — add as score modifier
    → Low vol entries outperform → bonus points for calm stocks

  IF r ≈ 0 for both VIX and rvol:
    → Volatility regime doesn't affect mean reversion outcomes
    → Display as context only (like deal levels)

  IF MAX% rises sharply with vol:
    → High vol = trades fail to revert → use as entry gate
    → "Don't enter if stock 20d vol > X%"

  The key question: is it a SCORE MODIFIER (±points), 
  a SIZING GATE (FULL/HALF/SKIP), or just DISPLAY CONTEXT?
""")

    report_text = "\n".join(report)
    print(report_text)

    with open(args.output, "w") as f:
        f.write(report_text)
    logger.info("\nReport saved to %s", args.output)


if __name__ == "__main__":
    main()
