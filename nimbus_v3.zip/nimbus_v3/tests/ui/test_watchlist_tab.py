"""Tests for nimbus_v3.ui.widgets.watchlist_tab."""
from __future__ import annotations

import pandas as pd
import pytest
from PyQt6.QtCore import Qt

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import RideClassificationCache, RideEngine
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.ui.widgets.watchlist_tab import WatchlistTab

_UPLOADS = "/mnt/user-data/uploads"


@pytest.fixture
def _data():
    eng = StrategyComputeEngine()
    syms = {"CIPLA": "Pharma", "SUNPHARMA": "Pharma", "AWL": "FMCG"}
    panel, metas = {}, {}
    for s, ind in syms.items():
        panel[s] = eng.enrich(pd.read_parquet(f"{_UPLOADS}/{s}.parquet"), s)
        metas[s] = SymbolMeta(symbol=s, macro_sector="M", sector="S",
                              industry=ind, basic_industry=ind)
    uni = Universe(symbols=metas, built_at=pd.Timestamp.now("UTC"))
    cache = RideClassificationCache.build(
        panel, {"Pharma": ["CIPLA", "SUNPHARMA"], "FMCG": ["AWL"]},
        engine=RideEngine(),
    )
    return panel, uni, cache


def test_rows_have_checkboxes(qapp, _data):    # noqa: ARG001
    panel, uni, cache = _data
    wt = WatchlistTab()
    wt.set_data(["CIPLA", "AWL"], panel, uni, cache)
    inner = wt._table._table
    assert inner.rowCount() == 2
    for r in range(inner.rowCount()):
        flags = inner.item(r, 0).flags()
        assert flags & Qt.ItemFlag.ItemIsUserCheckable


def test_delete_selected_emits_checked(qapp, _data):    # noqa: ARG001
    panel, uni, cache = _data
    wt = WatchlistTab()
    got = []
    wt.remove_requested.connect(got.append)
    wt.set_data(["CIPLA", "AWL", "SUNPHARMA"], panel, uni, cache)
    inner = wt._table._table
    # check two of the three rows
    for r in range(inner.rowCount()):
        if inner.item(r, 0).text() in ("CIPLA", "SUNPHARMA"):
            inner.item(r, 0).setCheckState(Qt.CheckState.Checked)
    wt._on_delete_selected()
    assert got
    assert set(got[0]) == {"CIPLA", "SUNPHARMA"}


def test_delete_selected_noop_when_none_checked(qapp, _data):    # noqa: ARG001
    panel, uni, cache = _data
    wt = WatchlistTab()
    got = []
    wt.remove_requested.connect(got.append)
    wt.set_data(["CIPLA"], panel, uni, cache)
    wt._on_delete_selected()
    assert got == []


def test_double_click_activates_symbol(qapp, _data):    # noqa: ARG001
    panel, uni, cache = _data
    wt = WatchlistTab()
    got = []
    wt.symbol_activated.connect(got.append)
    wt.set_data(["CIPLA", "AWL"], panel, uni, cache)
    wt._on_double_click(0, 0)
    assert len(got) == 1
    assert got[0] in ("CIPLA", "AWL")


def test_columns_match_constituents(qapp, _data):    # noqa: ARG001
    from nimbus_v3.ui.widgets.industry_tables import CONSTITUENT_COLUMNS
    panel, uni, cache = _data
    wt = WatchlistTab()
    wt.set_data(["CIPLA"], panel, uni, cache)
    inner = wt._table._table
    cols = [inner.horizontalHeaderItem(i).text()
            for i in range(inner.columnCount())]
    assert cols == list(CONSTITUENT_COLUMNS)


def test_options_overlay_defaults_off(qapp):    # noqa: ARG001
    from nimbus_v3.ui.sidebar import Sidebar
    sb = Sidebar(default_symbols=["RELIANCE"])
    assert sb.options_overlay_enabled() is False
