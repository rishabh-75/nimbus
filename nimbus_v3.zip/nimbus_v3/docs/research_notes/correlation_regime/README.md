# Correlation Regime Research

Research thread: does **cross-industry correlation** act as a
market-state indicator, predicting forward returns differently in
HIGH-correlation vs LOW-correlation regimes?

## Status: SHIPPED with caveats — 2026-04-25

Walk-forward validation passed for HIGH and NORMAL regimes after
diagnostic follow-up clarified the headline numbers. Shipped as a
three-state badge in Market Pulse header alongside VIX. **Empirical
caveat (bull-market sample) is documented in tooltip.**

### Verdict files

- **`run_2026_04_25_walk_forward_verdict.txt`** — initial walk-
  forward run. Headline result: HIGH_CORR ships +3.46pp,
  NORMAL ships -1.20pp.
- **`run_2026_04_25_diagnostic_follow_up.txt`** — diagnostic
  follow-up after concerns about Fold 4 outlier and warmup-fold
  issues. Headline result: HIGH_CORR robust mean +1.61pp (Fold 4
  was carrying ~half the original lift), NORMAL is the cleanest
  signal at -1.12pp robust, LOW_CORR collapses to noise without
  Fold 3.

### What shipped

Header badge in Market Pulse showing one of:
- `CORR: HIGH` (green) — top quintile of trailing 252d correlation
- `CORR: NORMAL` (red) — middle quintiles
- `CORR: LOW` (muted gray) — bottom quintile
- `CORR: —` (muted) — warmup or insufficient data

Color mapping reflects empirically validated forward-return tilt,
not intuitive interpretation: NORMAL is RED because it had the
**worst** forward returns despite the name suggesting "neutral."

Tooltip carries the full empirical caveat: validated on 2022-2026
NSE bull-market sample; HIGH's positive tilt may not hold in
extended bear markets.

## Empirical findings (validated)

| Regime | Robust mean lift | Sign agreement | Calendar coherence |
|---|---|---|---|
| HIGH | +1.61pp | 100% (3 of 3 valid folds) | STRONG — clusters map to corrections + post-stress recoveries |
| NORMAL | -1.12pp | 100% (4 of 4 folds) | Residual; harder to inspect |
| LOW | +0.025pp | inconsistent | STRONG — clusters map to orderly bull rallies |

## Reinterpretation: post-hoc theory of why this works

The original "fear gauge" hypothesis predicted HIGH_CORR should
ship NEGATIVE (high correlation = panic = bad fwd returns). The
data showed the opposite. After looking at the calendar of
HIGH_CORR clusters (Oct-Dec 2023 correction, Mar-Jun 2024 election
crash, Aug 2024 yen carry, Feb-Jun 2025 Trump tariff correction),
the more honest interpretation is:

> **HIGH_CORR is a post-stress recovery regime in bull markets, not
> a fear gauge.**

In our validated 2022-2026 sample (a structural bull market),
every fear event resolved upward within the 10-day forward window.
HIGH_CORR fires *during* the stress, but the forward window is
positive because Indian equities V-shape recovered every time.

This interpretation is **regime-contingent**. In a sustained bear
market or 1990s-style sideways regime, HIGH_CORR may flip to
predicting negative returns. The badge tooltip carries this caveat.

## Methodology (as run)

1. For each industry, build EW return series (member-symbol mean).
2. At each bar, compute mean off-diagonal pairwise correlation of
   the last 60 trading days.
3. Classify each bar via percentile rank against trailing 252-day
   window: top 20% HIGH, bottom 20% LOW, middle NORMAL.
4. Pool member-symbol fwd_10d per regime, compare to baseline.
5. Walk-forward 4 expanding folds with 10-bar purge.

## Ship rule (locked in before the run)

A regime ships if both:
- Sign agreement ≥ 75% of folds (≥ 3 of 4)
- |Mean test-fold lift| ≥ 0.5pp absolute

After diagnostic follow-up we additionally required: robust mean
(excluding smallest-N fold) must stay above the 0.5pp threshold.

HIGH passed all bars (robust +1.61pp). NORMAL passed all bars
(robust -1.12pp). LOW passed the original ship rule but failed the
robust-mean check (collapsed to +0.025pp without smallest-N fold).
We ship LOW as a regime label without color implications because
the regime IS real (calendar coherence) even though the forward-
return prediction isn't.

## How to run / re-run

```bash
# Initial validation
python scripts/run_correlation_regime_validation.py
# Diagnostic follow-up
python scripts/run_correlation_regime_diagnostics.py
```

Outputs land at `scripts/output/`. Re-running with the same
parameters will produce the same verdicts.

## Future research

Two open threads:

1. **Extended-history validation.** If we can get NSE data going
   back to 2008 or 2010-2013 (sideways period), test whether
   HIGH_CORR remains positive or flips. Would either confirm the
   bull-market caveat is conservative or force a regime-conditioned
   interpretation.

2. **VIX × CORR joint regime research.** See
   `scripts/run_vix_corr_joint_regime_validation.py`. Tests whether
   joint cells like (VIX:RISING + CORR:HIGH) carry signal beyond
   either marginal alone. Stricter ship rule: joint cell must
   exceed larger marginal lift by ≥ 0.5pp. Awaiting run.
