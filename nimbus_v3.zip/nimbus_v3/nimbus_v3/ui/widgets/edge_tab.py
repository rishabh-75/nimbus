"""Edge sub-tab: per-symbol momentum-implied expected edge + reward-to-risk.

A ranked table over the :class:`~nimbus_v3.compute.equity_edge.EdgeResult`.
Pure display — all computation is in the stateless edge engine; this widget
only renders and sorts. Double-clicking a row emits ``symbol_activated`` so
the container can open the symbol on the Dashboard.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QHeaderView, QLabel, QLineEdit, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.equity_edge import EdgeResult
from nimbus_v3.ui.theme import (
    BLUE, BORDER, FONT_MONO, GOLD, GREEN, MUTED, RED, S2, WHITE,
)
from nimbus_v3.ui.widgets.formatters import format_adtv_cr


class _NumItem(QTableWidgetItem):
    """Sorts by a stored numeric value, not display text."""
    def __lt__(self, other: "QTableWidgetItem") -> bool:
        a = self.data(Qt.ItemDataRole.UserRole)
        b = other.data(Qt.ItemDataRole.UserRole)
        try:
            af, bf = float(a), float(b)
        except (TypeError, ValueError):
            return super().__lt__(other)
        if af != af:
            return True
        if bf != bf:
            return False
        return af < bf


def _signed_color(v: float) -> QColor:
    if v != v:
        return QColor(MUTED)
    return QColor(GREEN) if v >= 0 else QColor(RED)


def _chg_txt(v: float) -> str:
    return "\u2014" if v != v else f"{v:+.2f}"


def _trust_color(t: float) -> QColor:
    """Grey (low) → blue (high) — how much confluence backs the edge."""
    if t != t:
        return QColor(MUTED)
    t = max(0.0, min(1.0, t))
    base, tgt = QColor(MUTED), QColor(BLUE)
    return QColor(
        int(base.red() + (tgt.red() - base.red()) * t),
        int(base.green() + (tgt.green() - base.green()) * t),
        int(base.blue() + (tgt.blue() - base.blue()) * t))


_TABLE_QSS = f"""
QTableWidget {{
    background: transparent;
    border: none;
    gridline-color: {BORDER};
    color: {WHITE};
}}
QHeaderView::section {{
    background: {S2};
    color: {MUTED};
    border: none;
    border-bottom: 1px solid {BORDER};
    padding: 6px 5px;
    font-weight: bold;
}}
QTableWidget::item {{ padding: 5px 5px; }}
QTableWidget::item:selected {{ background: {BORDER}; color: {WHITE}; }}
"""


class EdgeTab(QWidget):
    """Ranked per-symbol edge table (expected edge % + reward-to-risk)."""

    #: Emitted with the symbol when a row is double-clicked, so the
    #: container can open it on the Dashboard.
    symbol_activated = pyqtSignal(str)

    _COLS = (
        "Symbol", "Industry",
        "Vol", "Chg", "Chg 5d%", "Chg 10d%",
        "Exp. Edge %", "Reward / Risk", "Above", "Streak",
        "ADTV \u20b9cr", "ATR %", "RS Excess %", "Member Shift %", "Trust",
    )

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 10)
        root.setSpacing(6)

        title = QLabel("EDGE · momentum-implied expected excess return")
        title.setFont(QFont(FONT_MONO, 11, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {WHITE}; letter-spacing: 1px;")
        root.addWidget(title)

        self._subtitle = QLabel("")
        self._subtitle.setFont(QFont(FONT_MONO, 8))
        self._subtitle.setStyleSheet(f"color: {MUTED};")
        self._subtitle.setWordWrap(True)
        root.addWidget(self._subtitle)

        # Filter box — matches symbol OR industry, case-insensitive.
        self._search = QLineEdit()
        self._search.setPlaceholderText("filter symbol or industry…")
        self._search.setClearButtonEnabled(True)
        self._search.setStyleSheet(
            f"QLineEdit {{ background: {S2}; color: {WHITE}; "
            f"border: 1px solid {BORDER}; border-radius: 4px; "
            f"padding: 5px 9px; font-family: '{FONT_MONO}'; }}"
            f"QLineEdit:focus {{ border-color: {BLUE}; }}")
        self._search.textChanged.connect(self._apply_filter)
        root.addWidget(self._search)

        self._empty = QLabel("No edge data — load a panel.")
        self._empty.setStyleSheet(f"color: {MUTED};")
        self._empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(self._empty)

        self._table = QTableWidget(0, len(self._COLS))
        self._table.setHorizontalHeaderLabels(self._COLS)
        # Centre the value-column headers to match the centred cells; keep
        # Symbol/Industry (0, 1) left-aligned.
        for c in range(2, len(self._COLS)):
            hi = self._table.horizontalHeaderItem(c)
            if hi is not None:
                hi.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self._table.setStyleSheet(_TABLE_QSS)
        self._table.setShowGrid(False)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.verticalHeader().setVisible(False)
        hh = self._table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        hh.setMinimumSectionSize(56)
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self._table.setColumnWidth(0, 130)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        self._table.setColumnWidth(1, 200)
        self._table.cellDoubleClicked.connect(self._on_activated)
        self._table.setVisible(False)
        root.addWidget(self._table, stretch=1)

        self._rows_cache: tuple = ()

    def set_result(self, result: EdgeResult | None) -> None:
        """Render an edge result. Pure display."""
        if result is None or not result.has_data:
            self._table.setVisible(False)
            self._empty.setVisible(True)
            self._subtitle.setText("")
            return
        self._table.setVisible(True)
        self._empty.setVisible(False)
        self._subtitle.setText(
            f"expected {result.horizon_days}d excess return, ranked by "
            f"reward-to-risk \u00b7 momentum estimate, not a valuation "
            f"premium \u00b7 double-click to open")

        self._rows_cache = result.rows
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(result.rows))
        for r, row in enumerate(result.rows):
            self._fill_row(r, row)
        self._table.setSortingEnabled(True)
        self._table.sortItems(
            self._COLS.index("Reward / Risk"), Qt.SortOrder.DescendingOrder)
        self._apply_filter(self._search.text())

    def _fill_row(self, r: int, row) -> None:
        def txt(s, color=WHITE):
            it = QTableWidgetItem(s)
            it.setForeground(QColor(color))
            it.setData(Qt.ItemDataRole.UserRole, s)
            return it

        def num(s, v, color=WHITE):
            it = _NumItem(s)
            it.setForeground(QColor(color))
            it.setData(Qt.ItemDataRole.UserRole,
                       v if v == v else float("-inf"))
            it.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            return it

        edge = row.expected_edge
        rr = row.reward_to_risk
        # ADTV in ₹ crore (bare number; header carries the unit); coloured
        # gold when the liquidity gate bit (thin name), muted when liquid.
        adtv = getattr(row, "adtv", float("nan"))
        liq = getattr(row, "liquidity_gate", 1.0)
        adtv_txt = format_adtv_cr(adtv)
        adtv_col = MUTED if liq >= 0.999 else GOLD
        vol = getattr(row, "vol_ratio", float("nan"))
        above = getattr(row, "above", False)
        streak = getattr(row, "streak", 0)
        cells = [
            txt(row.symbol, WHITE),
            txt(row.industry, MUTED),
            num(f"{vol:.2f}x" if vol == vol else "\u2014",
                vol if vol == vol else float("-inf"),
                GREEN if (vol == vol and vol >= 1.0) else MUTED),
            num(_chg_txt(row.chg_1d), row.chg_1d, _signed_color(row.chg_1d)),
            num(_chg_txt(row.chg_5d), row.chg_5d, _signed_color(row.chg_5d)),
            num(_chg_txt(row.chg_10d), row.chg_10d,
                _signed_color(row.chg_10d)),
            num(f"{edge:+.2f}", edge, _signed_color(edge)),
            num(f"{rr:+.3f}", rr, _signed_color(rr)),
            num("\u25b2" if above else "\u2014", 1.0 if above else 0.0,
                GREEN if above else MUTED),
            num(str(streak) if streak else "\u2014", float(streak),
                GREEN if streak > 0 else MUTED),
            num(adtv_txt, adtv if adtv == adtv else float("-inf"), adtv_col),
            num(f"{row.atr_pct:.2f}", row.atr_pct, MUTED),
            num(f"{row.industry_rs_excess:+.1f}", row.industry_rs_excess,
                _signed_color(row.industry_rs_excess)),
            num(f"{row.member_shift:+.2f}", row.member_shift,
                _signed_color(row.member_shift)),
            num(f"{row.trust*100:.0f}", row.trust, _trust_color(row.trust)),
        ]
        for c, it in enumerate(cells):
            self._table.setItem(r, c, it)

        tip = (
            f"{row.symbol} · {row.industry}\n"
            f"expected edge {edge:+.2f}% over horizon "
            f"(reward/risk {rr:+.3f})\n"
            f"industry RS excess {row.industry_rs_excess:+.1f}% "
            f"× trust {row.trust*100:.0f}% × \u03ba\n"
            f"member shift {row.member_shift:+.2f}% · ATR {row.atr_pct:.2f}%\n"
            f"ADTV {adtv_txt}\u20b9cr"
            f"{f' · liquidity gate ×{liq:.2f}' if liq < 0.999 else ' · liquid'}")
        for c in range(len(self._COLS)):
            self._table.item(r, c).setToolTip(tip)

    def _on_activated(self, r: int, _c: int) -> None:
        it = self._table.item(r, 0)
        if it is not None and it.text():
            self.symbol_activated.emit(it.text())

    def _apply_filter(self, text: str) -> None:
        """Show only rows whose symbol or industry contains ``text``
        (case-insensitive). Empty text shows all."""
        needle = text.strip().lower()
        for r in range(self._table.rowCount()):
            sym_it = self._table.item(r, 0)
            ind_it = self._table.item(r, 1)
            if sym_it is None:
                continue
            hay = (sym_it.text() + " "
                   + (ind_it.text() if ind_it else "")).lower()
            hidden = bool(needle) and needle not in hay
            self._table.setRowHidden(r, hidden)
