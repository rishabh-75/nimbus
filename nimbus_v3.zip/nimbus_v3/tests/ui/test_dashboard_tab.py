"""tests.ui.test_dashboard_tab — smoke tests for the slim DashboardTab.

Construction, set_symbol with various artefact combinations, the
Options Overlay panel rendering by formatting / colour, and clear().
The chart itself is a separate widget with its own contract — these
tests don't assert on chart internals beyond confirming set_data
doesn't raise.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import RideEngine, RidePhase, RideResult
from nimbus_v3.core.context import OptionsContext
from nimbus_v3.core.types import ExpiryRisk, GEXRegime
from nimbus_v3.ui.theme import GREEN, MUTED, RED
from nimbus_v3.ui.widgets.dashboard_tab import DashboardTab


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════


def _enriched_frame(n: int = 250) -> pd.DataFrame:
    """A 250-bar enriched OHLCV frame from synthetic prices."""
    rng = np.random.default_rng(42)
    close = 100 + np.cumsum(rng.normal(0.05, 1.0, n))
    df = pd.DataFrame(
        {
            "Open":   close * 0.998,
            "High":   close * 1.005,
            "Low":    close * 0.995,
            "Close":  close,
            "Volume": rng.integers(1_000_000, 5_000_000, n).astype(float),
        },
        index=pd.bdate_range("2024-01-01", periods=n),
    )
    return StrategyComputeEngine().enrich(df, "TEST")


def _ride_result(enriched: pd.DataFrame) -> RideResult:
    return RideEngine().classify(enriched)


def _options_context(
    *,
    expiry_risk: ExpiryRisk = ExpiryRisk.LOW,
    gex_regime: GEXRegime | None = GEXRegime.TREND_FRIENDLY,
    pcr_oi: float | None = 0.92,
    net_gex: float | None = 1_500_000.0,
) -> OptionsContext:
    return OptionsContext(
        asof_date=pd.Timestamp("2026-04-30"),
        symbol="RELIANCE",
        spot=2450.0,
        dte=5,
        max_pain=2400.0,
        support_wall=2380.0,
        resistance_wall=2500.0,
        pct_to_support=-2.86,
        pct_to_resistance=2.04,
        net_gex=net_gex,
        hvl=2470.0,
        gex_regime=gex_regime,
        pcr_oi=pcr_oi,
        iv_atm=18.5,
        ivr=42.0,
        expiry_risk=expiry_risk,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Construction + clear
# ══════════════════════════════════════════════════════════════════════════════


def test_dashboard_constructs_empty(qapp):    # noqa: ARG001
    d = DashboardTab()
    assert d.symbol == ""
    assert d._h_symbol_lbl.text() == "—"
    assert d._h_spot_lbl.text() == "—"


def test_dashboard_clear_resets(qapp):    # noqa: ARG001
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol(
        "TEST",
        enriched_df=enriched,
        ride_result=_ride_result(enriched),
        asof_label="close 30 Apr 2026",
    )
    assert d.symbol == "TEST"
    d.clear()
    assert d.symbol == ""
    assert d._h_symbol_lbl.text() == "—"
    assert d._h_asof_lbl.text() == ""


# ══════════════════════════════════════════════════════════════════════════════
# Header rendering via set_symbol
# ══════════════════════════════════════════════════════════════════════════════


def test_set_symbol_populates_header(qapp):    # noqa: ARG001
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol(
        "RELIANCE",
        enriched_df=enriched,
        asof_label="close 30 Apr 2026",
    )
    assert d._h_symbol_lbl.text() == "RELIANCE"
    assert "₹" in d._h_spot_lbl.text()
    assert d._h_asof_lbl.text() == "close 30 Apr 2026"
    # Change tint either GREEN or RED depending on the random walk.
    assert any(
        c in d._h_change_lbl.styleSheet()
        for c in (GREEN, RED, MUTED)
    )


def test_set_symbol_with_no_enriched_uses_empty_header(qapp):    # noqa: ARG001
    d = DashboardTab()
    d.set_symbol("RELIANCE", enriched_df=None)
    # Symbol still surfaces in the empty-header view, spot is em-dashed.
    assert d._h_symbol_lbl.text() == "RELIANCE"
    assert d._h_spot_lbl.text() == "—"


def test_header_stats_populate_from_enriched(qapp):    # noqa: ARG001
    """All four tiles must surface a value when enriched data is
    available. The exact numbers vary by random walk; we only check
    that nothing is the em-dash placeholder."""
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol("RELIANCE", enriched_df=enriched)

    for key in ("ADTV", "ATR%", "52w", "BBW pctl"):
        text = d._h_stats[key].text()
        assert text != "—", f"{key} expected to render a value, got em-dash"


def test_header_stats_clear_on_no_enriched(qapp):    # noqa: ARG001
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol("RELIANCE", enriched_df=enriched)
    # Now switch to a no-data symbol — every tile resets to em-dash.
    d.set_symbol("UNKNOWN", enriched_df=None)
    for key in ("ADTV", "ATR%", "52w", "BBW pctl"):
        assert d._h_stats[key].text() == "—"


def test_header_stats_clear_on_clear(qapp):    # noqa: ARG001
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol("RELIANCE", enriched_df=enriched)
    d.clear()
    for key in ("ADTV", "ATR%", "52w", "BBW pctl"):
        assert d._h_stats[key].text() == "—"


def test_header_stats_format_adtv_in_millions(qapp):    # noqa: ARG001
    """Sanity-check the ADTV format is the same comma-separated
    millions shape Market Pulse uses, not raw rupees."""
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol("RELIANCE", enriched_df=enriched)
    text = d._h_stats["ADTV"].text()
    assert text.endswith(" M"), f"ADTV format expected ' M' suffix, got {text!r}"


# ══════════════════════════════════════════════════════════════════════════════
# Embedded tables — Industries + Constituents wiring
# ══════════════════════════════════════════════════════════════════════════════


def _build_panel(symbols_per_industry: dict[str, list[str]]) -> tuple[dict, "Universe"]:
    from nimbus_v3.core.universe import SymbolMeta, Universe
    panel: dict[str, pd.DataFrame] = {}
    meta: dict[str, SymbolMeta] = {}
    seed = 0
    for industry, syms in symbols_per_industry.items():
        for sym in syms:
            panel[sym] = _enriched_frame()
            meta[sym] = SymbolMeta(
                symbol=sym, industry=industry,
                basic_industry=f"Sub-{industry}",
            )
            seed += 1
    return panel, Universe(symbols=meta, built_at=pd.Timestamp.now("UTC"))


def test_set_panel_populates_industries_table(qapp):    # noqa: ARG001
    """Pushing a panel + universe down to the Dashboard fills the
    Industries table immediately. Constituents auto-defaults to ALL
    when no chart symbol's industry is set, so the bottom strip is
    never empty when there's data on screen."""
    d = DashboardTab()
    panel, universe = _build_panel({
        "Petroleum": ["A", "B"],
        "Banks":     ["X", "Y", "Z"],
    })
    d.set_panel(panel, universe)
    # 2 industries + 1 ALL row.
    assert d._industries_table._table.rowCount() == 3
    # Constituents auto-populated from the ALL fallback (5 symbols
    # across both industries).
    assert d._constituents_table._table.rowCount() == 5
    assert d._industries_table.selected_industry() == "ALL"
    # The auto-select is programmatic — the operator hasn't pinned
    # an industry yet, so subsequent set_symbol calls can pivot the
    # tables.
    assert not d._industries_table.is_user_pinned()


def test_industry_click_populates_constituents(qapp):    # noqa: ARG001
    """Selecting an Industries row repopulates Constituents with
    that industry's members."""
    d = DashboardTab()
    panel, universe = _build_panel({
        "Petroleum": ["A", "B", "C"],
        "Banks":     ["X", "Y"],
    })
    d.set_panel(panel, universe)
    d._on_industry_selected("Petroleum")
    assert d._constituents_table._table.rowCount() == 3


def test_industry_click_with_empty_string_clears_constituents(qapp):    # noqa: ARG001
    """Defensive: empty industry name clears the constituents table."""
    d = DashboardTab()
    panel, universe = _build_panel({"Petroleum": ["A", "B"]})
    d.set_panel(panel, universe)
    d._on_industry_selected("Petroleum")
    assert d._constituents_table._table.rowCount() == 2
    d._on_industry_selected("")
    assert d._constituents_table._table.rowCount() == 0


def test_constituents_double_click_bubbles_via_symbol_activated(qapp):    # noqa: ARG001
    """Double-click on a Constituents row → DashboardTab emits its
    public ``symbol_activated`` signal carrying the symbol. This is
    the wire MainWindow uses to drive the chart load."""
    d = DashboardTab()
    panel, universe = _build_panel({"Petroleum": ["A", "B", "C"]})
    d.set_panel(panel, universe)
    d._on_industry_selected("Petroleum")

    captured: list[str] = []
    d.symbol_activated.connect(captured.append)

    # Drive the inner constituents-table activation slot directly
    # (we don't have a real Qt double-click event in the test).
    d._constituents_table._on_activated(0, 0)
    assert len(captured) == 1
    assert captured[0] in {"A", "B", "C"}


def test_clear_resets_both_tables(qapp):    # noqa: ARG001
    d = DashboardTab()
    panel, universe = _build_panel({"Petroleum": ["A", "B"]})
    d.set_panel(panel, universe)
    d._on_industry_selected("Petroleum")
    assert d._industries_table._table.rowCount() > 0
    assert d._constituents_table._table.rowCount() > 0
    d.clear()
    assert d._industries_table._table.rowCount() == 0
    assert d._constituents_table._table.rowCount() == 0


def test_set_panel_does_not_change_chart_symbol(qapp):    # noqa: ARG001
    """Pushing a fresh panel must not move the chart off the
    currently-loaded symbol — tables and chart are on independent
    selection rails per the design."""
    d = DashboardTab()
    enriched = _enriched_frame()
    d.set_symbol("RELIANCE", enriched_df=enriched)
    assert d.symbol == "RELIANCE"

    panel, universe = _build_panel({
        "Petroleum": ["A", "B"],
        "Banks":     ["X"],
    })
    d.set_panel(panel, universe)
    # Chart still on RELIANCE; tables now populated.
    assert d.symbol == "RELIANCE"
    assert d._industries_table._table.rowCount() > 0


# ══════════════════════════════════════════════════════════════════════════════
# Auto-selection behaviour for the embedded tables
# ══════════════════════════════════════════════════════════════════════════════


def test_set_panel_auto_selects_chart_symbol_industry(qapp):    # noqa: ARG001
    """Symbol set first, then panel pushed: tables default to the
    chart symbol's industry rather than ALL."""
    d = DashboardTab()
    panel, universe = _build_panel({
        "Petroleum": ["A", "B"],
        "Banks":     ["X", "Y"],
    })
    d.set_symbol("X", enriched_df=panel["X"], industry="Banks")
    d.set_panel(panel, universe)
    assert d._industries_table.selected_industry() == "Banks"
    assert d._constituents_table._table.rowCount() == 2


def test_set_symbol_pivots_tables_when_not_pinned(qapp):    # noqa: ARG001
    """Panel first, then symbol: the auto-default ALL gives way to
    the symbol's industry because the operator hasn't pinned a
    selection yet."""
    d = DashboardTab()
    panel, universe = _build_panel({
        "Petroleum": ["A", "B"],
        "Banks":     ["X", "Y"],
    })
    d.set_panel(panel, universe)
    assert d._industries_table.selected_industry() == "ALL"
    assert not d._industries_table.is_user_pinned()

    d.set_symbol("A", enriched_df=panel["A"], industry="Petroleum")
    assert d._industries_table.selected_industry() == "Petroleum"
    assert d._constituents_table._table.rowCount() == 2


def test_user_pinned_industry_survives_symbol_change(qapp):    # noqa: ARG001
    """Once the operator clicks a row, set_symbol must NOT pivot
    the tables — they explore industries independently of the chart."""
    d = DashboardTab()
    panel, universe = _build_panel({
        "Petroleum": ["A", "B"],
        "Banks":     ["X", "Y"],
    })
    d.set_panel(panel, universe)
    # Simulate a real user click via the public path.
    d._industries_table._on_selection_changed_was = None
    # Find the Banks row index and click-select it.
    for r in range(d._industries_table._table.rowCount()):
        if d._industries_table._table.item(r, 0).text() == "Banks":
            d._industries_table._table.selectRow(r)
            break
    assert d._industries_table.selected_industry() == "Banks"
    assert d._industries_table.is_user_pinned()

    # Switching the chart to a Petroleum symbol must NOT pivot the
    # tables off Banks — the user pinned Banks deliberately.
    d.set_symbol("A", enriched_df=panel["A"], industry="Petroleum")
    assert d._industries_table.selected_industry() == "Banks"
