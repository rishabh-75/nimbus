"""
modules/conviction.py — Single source of truth for trade conviction.

Every conviction output — grade, verdict, effective sizing, checklist,
risk notes — is computed HERE and only here. Scanner and dashboard
read from this. No recomputation anywhere.

Architecture:
    ConvictionEngine.compute(dm_sig, vix) → ConvictionResult
        ├── vix_regime, is_friday
        ├── effective_sizing, effective_label  (VIX + Friday gates applied)
        ├── grade (A+ to D, factor-backtest validated)
        ├── verdict (rich text with catalysts + risk warnings)
        ├── checklist (pre-trade items for dashboard)
        ├── catalysts, risks (separated lists)
        └── overlay_str (options + filing summary)

Input layers:
    1. DualModeSignal (from dual_mode.py)
       - base_score, options_overlay, filing_overlay → final score
       - tier (PRIMARY/SECONDARY/NONE), entry_triggered
       - WR, MFI, RSI, DD, streak, vol_ratio, bbw_pctl, pct_sma
    2. VIX (from data.py fetch_india_vix)
       - Drives regime classification and flat grade bonus

Grade factors (data-validated, factor backtest 2026-03-29):
    KEEP:  MFI (r=+0.039), RSI (r=+0.079), vol_ratio (r=+0.042), VIX flat (r=+0.096)
    DROP:  score band (r=-0.032), WR depth, DD+streak, BBW squeeze
"""
import datetime as _dt
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass
class ConvictionResult:
    """All conviction outputs in one place."""
    # VIX context
    vix_regime: str = "UNKNOWN"     # LOW, NORMAL, ELEVATED, PANIC
    vix_value: Optional[float] = None  # raw VIX value for display
    is_friday: bool = False

    # Effective sizing (after VIX + Friday gates)
    effective_sizing: str = "SKIP"  # FULL, HALF, SKIP
    effective_label: str = "NEUTRAL"  # STRONG, GOOD, WATCH, AVOID

    # Grade (A+ to D)
    grade: str = "—"

    # Verdict (rich text for scanner + dashboard)
    verdict: str = ""

    # Separated catalysts and risks for UI flexibility
    catalysts: List[str] = field(default_factory=list)  # positive signals
    risks: List[str] = field(default_factory=list)       # warnings

    # Overlay summary
    overlay_str: str = ""           # e.g. "(opt +6, fil -3)"
    options_impact: str = ""        # full options detail
    filing_impact: str = ""         # full filing detail

    # Checklist items: list of (status, label, value, detail)
    # status: "pass", "warn", "fail"
    checklist: List[Tuple[str, str, str, str]] = field(default_factory=list)

    # ML conviction (populated separately if model available)
    ml_pwin: Optional[float] = None
    ml_confidence: Optional[str] = None

    # Dynamic targets (ATR-scaled, grade-aware)
    target_pct: Optional[float] = None    # profit target as % from entry
    stop_pct: Optional[float] = None      # stop loss as % from entry (negative)
    target_atr_mult: Optional[float] = None  # target in ATR multiples
    stop_atr_mult: Optional[float] = None    # stop in ATR multiples
    atr_pct: Optional[float] = None       # ATR as % of price (for display)

    # Sector RS (from sector_rotation, H1 validated: p=0.0017, +11pp LEADING vs LAGGING)
    sector_name: str = ""                  # e.g. "Nifty Bank", "IT"
    sector_rotation: str = ""              # LEADING, INLINE, LAGGING, WEAKENING, IMPROVING
    sector_rs_impact: int = 0              # grade points applied (+1, 0, -1)

    # Rotation divergence (sector lagging behind correlated peers → catch-up)
    # Validated: lag_count≥1 → +15.7pp win rate, +1.25% avg fwd 21d
    div_lag_count: int = 0                 # how many correlated sectors this is lagging
    div_top_pair: str = ""                 # sector it's most diverged from
    div_top_spread: float = 0.0            # spread in pp vs top pair
    div_impact: int = 0                    # grade points applied (0 or +1)

    # Sector regime (H1 validated, 4511 OOS trades)
    sector_type: str = ""                  # CYCLICAL, DEFENSIVE, UNKNOWN
    sector_vol_z: float = 0.0             # sector vol z-score (>1.5 = EXTREME, >0.8 = HOT)
    sector_vol_impact: int = 0            # grade points from sector vol (+2/+1/0)
    cyclical_normal_penalty: int = 0      # -1 when CYCLICAL × NORMAL VIX

    # Quality rank — continuous score within grade for ordering (0-100)
    # Uses raw factor values instead of grade thresholds.
    # Two A+ stocks: ABB (MFI=72, DD=-9%) ranks above ASIANPAINT (MFI=45, DD=-23%)
    quality_rank: float = 0.0


class ConvictionEngine:
    """
    Stateless conviction calculator.

    Usage:
        engine = ConvictionEngine()
        result = engine.compute(dm_sig, vix=26.8)
        # result.grade, result.verdict, result.effective_sizing, etc.
    """

    # ── VIX regime boundaries ────────────────────────────────────────
    VIX_PANIC = 22
    VIX_ELEVATED = 18
    VIX_NORMAL = 13

    # ── Grade: flat VIX points (backtest winner, corr=0.034) ─────────
    _VIX_GRADE_PTS = {"PANIC": 4, "ELEVATED": 3, "LOW": 2, "NORMAL": 0, "UNKNOWN": 0}

    # ── Grade thresholds (0-9 range) ─────────────────────────────────
    _GRADE_MAP = [(8, "A+"), (6, "A"), (5, "B+"), (4, "B"), (3, "C+"), (2, "C")]

    # ── Grade-based sizing (replaces tier-based, tier p=0.74 not significant) ──
    _GRADE_SIZING = {
        "A+": "FULL",   # 97% win, Sh 11.76
        "A":  "FULL",   # 86% win, Sh 3.78
        "B+": "HALF",   # 83% win, Sh 3.07
        "B":  "HALF",   # 78% win, Sh 1.78
        "C+": "SKIP",   # 66% win, below threshold
        "C":  "SKIP",   # 64% win
        "D":  "SKIP",   # 64% win
        "—":  "SKIP",
    }

    # ── Minimum grade to take a trade (configurable) ─────────────────
    # Backtest optimal: A+ (Sh 11.76) but only 30 trades/yr
    # Practical sweet spot: B (Sh 1.78, 629 trades/yr)
    MIN_GRADE = "B"           # skip C+, C, D
    MIN_GRADE_NORMAL_VIX = "B+"  # Normal VIX is choppy (Sh 0.60), require higher conviction

    def compute(self, dm_sig, vix: float = None, sector_ctx: dict = None) -> ConvictionResult:
        """
        Compute all conviction outputs from DualModeSignal + VIX + sector RS.

        This is the ONLY place conviction is computed. Everything else reads.
        """
        r = ConvictionResult()
        r.is_friday = _dt.datetime.now().weekday() == 4

        # ── Handle missing/insufficient signal ───────────────────────
        if dm_sig is None:
            return r
        if not getattr(dm_sig, "data_sufficient", False):
            return r

        # ── VIX regime ───────────────────────────────────────────────
        r.vix_value = vix
        if vix is not None:
            if vix > self.VIX_PANIC:
                r.vix_regime = "PANIC"
            elif vix >= self.VIX_ELEVATED:
                r.vix_regime = "ELEVATED"
            elif vix >= self.VIX_NORMAL:
                r.vix_regime = "NORMAL"
            else:
                r.vix_regime = "LOW"

        # ── Sector RS context ────────────────────────────────────────
        # H1 validated: LEADING 77.1% vs LAGGING 66.0% (p=0.0017, chi2=12.7)
        if sector_ctx is not None:
            r.sector_name = sector_ctx.get("name", "")
            r.sector_rotation = sector_ctx.get("rotation", "")
            r.div_lag_count = sector_ctx.get("div_lag_count", 0)
            r.div_top_pair = sector_ctx.get("div_top_pair", "")
            r.div_top_spread = sector_ctx.get("div_top_spread", 0.0)
            r.sector_type = sector_ctx.get("sector_type", "")
            r.sector_vol_z = sector_ctx.get("vol_z", 0.0)

        # ── Overlays ─────────────────────────────────────────────────
        r.options_impact = getattr(dm_sig, "options_detail", "") or ""
        r.filing_impact = getattr(dm_sig, "filing_detail", "") or ""
        overlay_parts = []
        opt_ov = getattr(dm_sig, "options_overlay", 0)
        fil_ov = getattr(dm_sig, "filing_overlay", 0)
        if opt_ov != 0:
            overlay_parts.append(f"opt {opt_ov:+d}")
        if fil_ov != 0:
            overlay_parts.append(f"fil {fil_ov:+d}")
        r.overlay_str = f"({', '.join(overlay_parts)})" if overlay_parts else ""

        # ── Grade FIRST (drives sizing) ──────────────────────────────
        r.grade, r.sector_rs_impact, r.div_impact, r.sector_vol_impact, r.cyclical_normal_penalty = (
            self._compute_grade(
                dm_sig, r.vix_regime, r.is_friday,
                r.sector_rotation, r.div_lag_count,
                r.sector_type, r.sector_vol_z,
            )
        )

        # ── Sizing from GRADE ────────────────────────────────────────
        GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6, "—": 7}

        # Normal VIX uses tighter threshold (B+ instead of B)
        min_grade = self.MIN_GRADE_NORMAL_VIX if r.vix_regime == "NORMAL" else self.MIN_GRADE
        MIN_ORD = GRADE_ORD.get(min_grade, 3)

        if not dm_sig.entry_triggered:
            r.effective_sizing = "SKIP"
            r.effective_label = getattr(dm_sig, "dual_label", "NEUTRAL")
        elif getattr(dm_sig, "is_trap", False) or dm_sig.dual_score <= 30:
            r.effective_sizing = "SKIP"
            r.effective_label = "AVOID"
        elif GRADE_ORD.get(r.grade, 7) > MIN_ORD:
            r.effective_sizing = "SKIP"
            r.effective_label = "WATCH"
        else:
            r.effective_sizing = self._GRADE_SIZING.get(r.grade, "SKIP")
            r.effective_label = "STRONG" if r.grade in ("A+", "A") else "GOOD"

        # ── Friday + stressed VIX gate (Sh 6.40 → 0.48) ─────────────
        if r.is_friday and r.vix_regime in ("ELEVATED", "PANIC") and dm_sig.entry_triggered:
            if r.effective_sizing == "FULL":
                r.effective_sizing = "HALF"
            elif r.effective_sizing == "HALF":
                r.effective_sizing = "SKIP"
                r.effective_label = "WATCH"

        # ── Dynamic targets (ATR-scaled, grade-aware) ─────────────────
        self._compute_targets(dm_sig, r)

        # ── Quality rank (within-grade ordering) ──────────────────────
        self._compute_quality_rank(dm_sig, r)

        # ── Catalysts + risks ────────────────────────────────────────
        r.catalysts, r.risks = self._build_catalysts(dm_sig, r)

        # ── Verdict ──────────────────────────────────────────────────
        r.verdict = self._build_verdict(dm_sig, r)

        # ── Checklist ────────────────────────────────────────────────
        r.checklist = self._build_checklist(dm_sig, vix, r)

        return r

    # ── Grade computation ────────────────────────────────────────────

    # Sector RS grade points (H1 validated: chi2=12.7, p=0.0017)
    # LEADING 77.1% win vs LAGGING 66.0% — ~11pp gap → ±1 grade point
    # IMPROVING: 0 (not +1) — divergence detector handles catch-up thesis directly
    _SECTOR_RS_PTS = {
        "LEADING": 1, "IMPROVING": 0,
        "INLINE": 0, "WEAKENING": 0,
        "LAGGING": -1,
        "UNKNOWN": 0, "": 0,
    }

    def _compute_grade(self, sig, vix_regime, is_friday, sector_rotation="",
                       div_lag_count=0, sector_type="", sector_vol_z=0.0) -> tuple:
        """
        Grade A+ to D using ONLY data-validated factors.
        Returns (grade_str, sector_rs_impact, div_impact, sector_vol_impact, cyclical_normal_penalty).

        Factors (factor backtest 2026-03-29, 4,511 OOS trades):
            MFI level:  r=+0.039  (55+ = +2, 45+ = +1)
            Vol ratio:  r=+0.042  (1.5+ = +1, only LOO-validated quality factor)
            RSI:        r=+0.079  (50+ = +2, 40+ = +1, strongest quality predictor)
            VIX flat:   r=+0.096  (PANIC=+4, ELEV=+3, LOW=+2, NORMAL=+0)
            Sector RS:  p=0.0017  (LEADING=+1, LAGGING=-1, regime study H1)
            Rotation divergence: lag_count≥1 → +1 (catch-up, +15.7pp win rate vs 0)

        New factors (sector regime study 2026-04-02, 4,511 OOS + 41,626 signal snapshots):
            Sector vol z-score: EXTREME(z>1.5) × PANIC/ELEV → +2 (85.7% win, +3.16%)
                                HOT(z>0.8) × PANIC/ELEV → +1 (79.5% win, +2.14%)

        Removed after grade simulation (broke monotonicity: C+ 73.6% > B 69.5%):
            Cyclical × NORMAL penalty: was -1, removed — existing B+ gate handles NORMAL VIX

        Dropped (inverted per leave-one-out):
            Score band (+0.040 improvement when removed)
            WR depth (+0.027), DD+streak (+0.006), BBW squeeze (+0.008)
        """
        if not sig.entry_triggered:
            return "—", 0, 0, 0, 0

        pts = 0

        # MFI: strong flow = cleaner bounce
        if sig.mfi >= 55:
            pts += 2
        elif sig.mfi >= 45:
            pts += 1

        # Volume ratio: institutional participation
        if sig.vol_ratio >= 1.5:
            pts += 1

        # RSI: momentum not dead
        rsi = getattr(sig, "rsi", None)
        if rsi is not None:
            if rsi >= 50:
                pts += 2
            elif rsi >= 40:
                pts += 1

        # VIX flat addition
        pts += self._VIX_GRADE_PTS.get(vix_regime, 0)

        # Sector RS (H1 validated)
        rs_impact = self._SECTOR_RS_PTS.get(sector_rotation, 0)
        pts += rs_impact

        # Rotation divergence: sector lagging behind correlated peers → catch-up
        div_impact = 1 if div_lag_count >= 1 else 0
        pts += div_impact

        # ── NEW: Sector vol z-score (regime study H1 validated) ──────
        # EXTREME sector vol during market stress = highest-prob MR entries
        # 85.7% win, +3.16% avg (EXTREME), 79.5% win +2.14% (HOT)
        sv_impact = 0
        if vix_regime in ("PANIC", "ELEVATED"):
            if sector_vol_z >= 1.5:
                sv_impact = 2  # EXTREME vol + VIX stress
            elif sector_vol_z >= 0.8:
                sv_impact = 1  # HOT vol + VIX stress
        pts += sv_impact

        # ── NOTE: Cyclical × NORMAL VIX ─────────────────────────────
        # Sector regime study: CYCLICAL × NORMAL = 67.0% win, +0.61% avg
        # vs DEFENSIVE × NORMAL = 70.1%, +1.04%
        # However, applying a -1 pt penalty breaks grade monotonicity
        # (C+ at 73.6% beats B at 69.5% in simulation). The existing
        # MIN_GRADE_NORMAL_VIX gate (B+) already handles NORMAL VIX.
        # Sector type is surfaced as context in catalysts/risks, not as a grade factor.
        cn_penalty = 0

        # Friday penalty
        if is_friday and vix_regime in ("ELEVATED", "PANIC"):
            pts -= 2
        elif is_friday:
            pts -= 1

        # Map to letter
        for threshold, grade in self._GRADE_MAP:
            if pts >= threshold:
                return grade, rs_impact, div_impact, sv_impact, cn_penalty
        return "D", rs_impact, div_impact, sv_impact, cn_penalty

    # ── Targets ────────────────────────────────────────────────────────
    #
    # ATR TARGET BACKTEST (2026-03-29, 1,886 trades):
    #   Original walkforward (fixed +5% PT, BBW exit):  Sh=1.78, Win=77.8%
    #   Grade-scaled ATR targets:                       Sh=0.92, Win=67.8%
    #   Best fixed ATR (3.0× ATR):                     Sh=0.93, Win=65.6%
    #
    # CONCLUSION: BBW contraction is the primary exit (40-58% of trades).
    # PT is a ceiling, not the main exit. Fixed +5% PT validated.
    # ATR is useful for STOP LOSS sizing (risk management).
    #
    _TARGET_PCT = 5.0               # fixed PT ceiling (backtest validated)
    _STOP_ATR_MULT = 1.5            # ATR-based stop (risk management)
    _STOP_MAX_PCT = 4.0             # never risk more than 4%
    _STOP_MIN_PCT = 1.5             # minimum stop regardless of ATR

    def _compute_targets(self, sig, r: 'ConvictionResult'):
        """
        Compute profit target and ATR-based stop loss.

        PT: Fixed +5% ceiling (backtest validated — BBW exit does the heavy
            lifting, PT only fires 15% of the time as a bonus).
        SL: ATR-scaled (1.5× ATR, capped at 4%) — adapts to stock volatility.
        Primary exit: BBW contraction + SMA cross (not PT or SL).
        """
        if not sig.entry_triggered or r.grade == "—":
            return

        atr = getattr(sig, "atr", 0)
        close = getattr(sig, "close", 0)

        # Fixed PT
        r.target_pct = self._TARGET_PCT

        # ATR-based stop
        if atr > 0 and close > 0:
            atr_pct = atr / close * 100
            r.atr_pct = round(atr_pct, 2)
            raw_stop = atr_pct * self._STOP_ATR_MULT
            r.stop_pct = round(-max(self._STOP_MIN_PCT, min(raw_stop, self._STOP_MAX_PCT)), 1)
            r.stop_atr_mult = self._STOP_ATR_MULT
        else:
            r.stop_pct = -3.0  # default if ATR unavailable
            r.atr_pct = None

    # ── Quality rank (within-grade ordering) ─────────────────────────

    def _compute_quality_rank(self, sig, r: 'ConvictionResult'):
        """
        Continuous quality score (0-100) for ranking within the same grade.

        Normalized to ENTRY POPULATION ranges (not absolute 0-100):
          MFI 30-75 is the actual range for entries (30 = gate, 75 = exceptional)
          RSI 15-55 is the actual range
          Vol 0.5-2.5x, DD -5 to -30%, SMA -1 to -12%

        This gives 60+ point spread across typical entries instead of 20.

        Weights (same data-validated factors as grade):
          MFI:      30pts  (strongest quality predictor)
          RSI:      20pts
          Vol:      10pts
          DD sweet: 15pts  (moderate -5 to -10% > deep -20%+)
          SMA sweet:10pts  (moderate -2 to -5% > extended -10%+)
          Options:   5pts  (overlay proxy)
          Room:      5pts  (scanner-enriched)
          ADTV:      5pts  (scanner-enriched)

        Grade decides WHETHER to trade. Quality rank decides WHICH to pick first.
        """
        if not sig.entry_triggered or r.grade == "—":
            r.quality_rank = 0.0
            return

        q = 0.0

        # ── MFI (30pts) — entry range 30-75, linear ──────────────────
        # 30 = gate (just passed), 75 = exceptional flow
        mfi = max(30, min(75, sig.mfi))
        q += ((mfi - 30) / 45) * 30

        # ── RSI (20pts) — entry range 15-55 ──────────────────────────
        rsi = getattr(sig, "rsi", 35) or 35
        rsi = max(15, min(55, rsi))
        q += ((rsi - 15) / 40) * 20

        # ── Volume ratio (10pts) — 0.5-2.5x, log-scaled ─────────────
        import math
        vol = max(0.5, min(2.5, sig.vol_ratio))
        # 0.5→0, 1.0→4.6, 1.5→7.2, 2.0→8.9, 2.5→10
        q += (math.log(vol / 0.5) / math.log(5.0)) * 10

        # ── DD sweet spot (15pts) — peak at -7%, steep falloff ───────
        # -5 to -10% is the validated sweet spot (moderate pullback)
        # Below -15%: trend change risk (inverted r in backtest)
        dd = sig.dd_from_high  # negative number
        dd_dist = abs(dd - (-7.0))
        if dd < -15:
            # Extra penalty for deep capitulation
            dd_score = max(0, 8 - (abs(dd) - 15) * 0.8)
        elif dd > -3:
            # Too shallow — not a real pullback
            dd_score = max(0, 8 - (3 - abs(dd)) * 3)
        else:
            # Sweet zone: -3 to -15, peak at -7
            dd_score = max(0, 15 - dd_dist * 1.5)
        q += dd_score

        # ── SMA distance (10pts) — sweet spot at -3%, steep falloff ──
        sma = sig.pct_from_sma  # negative when below SMA
        sma_dist = abs(sma - (-3.0))
        if sma < -8:
            # Extended — slower reversion
            sma_score = max(0, 4 - (abs(sma) - 8) * 0.5)
        else:
            sma_score = max(0, 10 - sma_dist * 2.0)
        q += sma_score

        # ── Options overlay proxy (5pts) ─────────────────────────────
        # Only extreme PCR affects overlay (±3); moderate = 0
        opt_ov = getattr(sig, "options_overlay", 0)
        if opt_ov >= 3:    q += 5   # capitulation puts
        elif opt_ov >= 2:  q += 4   # near OI support
        elif opt_ov <= -3: q += 0   # extreme complacency
        else:              q += 2.5 # neutral / moderate

        # ── Room + ADTV (5+5pts) — neutral placeholders ─────────────
        # Scanner enriches these with actual PCR, room%, ADTV values
        q += 2.5  # room placeholder
        q += 2.5  # ADTV placeholder

        r.quality_rank = round(max(0, min(100, q)), 1)

    # ── Catalysts + risks ────────────────────────────────────────────

    def _build_catalysts(self, sig, r: ConvictionResult):
        """
        Build separated catalyst and risk lists.

        Catalysts = data-validated positive signals (flow, momentum, volume)
        Risks = depth/extension warnings (inverted in backtest)
        """
        catalysts = []
        risks = []

        if not sig.entry_triggered:
            return catalysts, risks

        # Conviction (positive predictors)
        if sig.mfi >= 60:
            catalysts.append("strong money flow")
        elif sig.mfi >= 50:
            catalysts.append("solid flow")
        elif sig.mfi < 35:
            risks.append(f"MFI {sig.mfi:.0f} weak")

        if sig.vol_ratio >= 1.5:
            catalysts.append("volume confirming")

        rsi = getattr(sig, "rsi", None)
        if rsi is not None:
            if rsi >= 50:
                catalysts.append("momentum recovering")
            elif rsi < 35:
                risks.append(f"RSI {rsi:.0f} — weak momentum")

        # Depth = risk context (inverted in backtest)
        if sig.dd_from_high < -15:
            risks.append(f"{sig.dd_from_high:.0f}% deep — trend change risk")
        elif sig.dd_from_high < -10:
            risks.append(f"{sig.dd_from_high:.0f}% extended")

        if sig.wr_30 < -80:
            risks.append("extreme oversold — may not bounce")

        if sig.pct_from_sma < -8:
            risks.append(f"{sig.pct_from_sma:.1f}% below SMA — extended")
        elif -3 < sig.pct_from_sma < 0:
            catalysts.append("shallow dip — clean reversion")

        # Sector RS + rotation divergence
        if r.div_lag_count >= 1:
            # Catch-up signal overrides negative RS label
            catalysts.append(f"{r.sector_name or 'sector'} rotation catch-up ({r.div_lag_count} peers ahead)")
        elif r.sector_rotation in ("LEADING",):
            catalysts.append(f"{r.sector_name or 'sector'} leading")
        elif r.sector_rotation == "LAGGING":
            risks.append(f"{r.sector_name or 'sector'} lagging")

        # Overlay risks
        if sig.options_overlay <= -3:
            risks.append("extreme options complacency — dip may deepen")
        if sig.is_trap:
            risks.append("⚠ filing TRAP — bearish filing")

        # Sector vol regime (H1: EXTREME = 85.7% win)
        if r.sector_vol_impact >= 2:
            catalysts.append(f"sector vol EXTREME (z={r.sector_vol_z:.1f}) — high-prob entry")
        elif r.sector_vol_impact >= 1:
            catalysts.append(f"sector vol HOT (z={r.sector_vol_z:.1f})")

        # Cyclical × NORMAL context (note, not a grade factor)
        if r.sector_type == "CYCLICAL" and r.vix_regime == "NORMAL":
            risks.append(f"{r.sector_name or 'cyclical'} in NORMAL VIX — historically choppy")

        # Friday
        if r.is_friday and r.vix_regime in ("ELEVATED", "PANIC"):
            risks.append("⚠ Friday — weekend gap risk")
        elif r.is_friday:
            risks.append("Friday entry")

        return catalysts, risks

    # ── Verdict ──────────────────────────────────────────────────────

    def _build_verdict(self, sig, r: ConvictionResult) -> str:
        """Build the full verdict string."""
        grade = r.grade
        sizing = r.effective_sizing
        score = sig.dual_score
        mfi = sig.mfi
        wr = sig.wr_30
        dd = sig.dd_from_high
        pct_sma = sig.pct_from_sma

        # ── Non-entry paths ──────────────────────────────────────────
        if not sig.entry_triggered:
            if sig.is_trap:
                return "⚠ TRAP — bearish filing vs pullback setup"
            if mfi < 30:
                if wr < -50 and dd < -10:
                    return f"⏳ CAPITULATION — deep dip, wait for MFI > 30 to confirm flow"
                elif wr < -30:
                    return f"⏳ OVERSOLD — WR={wr:.0f} MFI={mfi:.0f}, wait for accumulation"
            if score >= 60:
                return f"⏳ FORMING ({score}) — approaching entry zone"
            return f"— score {score}, below threshold"

        # ── Entry verdict ────────────────────────────────────────────
        # TRAP / weak score → AVOID regardless of entry
        if sig.is_trap:
            return f"⚠ AVOID — filing TRAP, bearish filing vs pullback"
        if score <= 30:
            return f"⚠ AVOID — score {score}, setup too weak"

        # Below minimum grade → SKIP
        GRADE_ORD = {"A+": 0, "A": 1, "B+": 2, "B": 3, "C+": 4, "C": 5, "D": 6}
        min_grade = self.MIN_GRADE_NORMAL_VIX if r.vix_regime == "NORMAL" else self.MIN_GRADE
        if sizing == "SKIP" and grade in GRADE_ORD and \
           GRADE_ORD[grade] > GRADE_ORD.get(min_grade, 3):
            if r.vix_regime == "NORMAL":
                return f"▽ SKIP [{grade}] — Normal VIX choppy, need grade ≥ {self.MIN_GRADE_NORMAL_VIX}"
            return f"▽ SKIP [{grade}] — below min grade ({self.MIN_GRADE}), conviction too low"

        # Assemble parts: catalysts first, then risks (max 3 total)
        parts = list(r.catalysts[:3])
        remaining = 3 - len(parts)
        if remaining > 0:
            parts.extend(r.risks[:remaining])
        if not parts:
            parts.append("entry conditions met")

        # VIX context is shown in the status bar regime indicator,
        # not repeated in every verdict string.

        # Only add VIX as catalyst if nothing else describes the setup
        if not r.catalysts and not r.risks:
            if r.vix_regime == "PANIC":
                parts = ["strong reversion tailwind"]
            elif r.vix_regime == "ELEVATED":
                parts = ["bounce zone"]

        part_str = ", ".join(parts)

        # Build action prefix
        if sizing == "SKIP" and r.vix_regime == "NORMAL":
            return f"▽ WATCH [{grade}] — {part_str} (Normal VIX: need ≥ {self.MIN_GRADE_NORMAL_VIX})"
        elif sizing == "SKIP" and r.is_friday and r.vix_regime in ("ELEVATED", "PANIC"):
            return f"▽ WATCH [{grade}] — {part_str} (Friday + VIX: weekend gap risk)"
        elif sizing == "HALF" and r.is_friday and r.vix_regime in ("ELEVATED", "PANIC"):
            return f"▷ BUY HALF [{grade}] — {part_str} (sized down: Friday gap risk)"
        elif sizing == "FULL":
            return f"▶ BUY FULL [{grade}] — {part_str}"
        elif sizing == "HALF":
            return f"▷ BUY HALF [{grade}] — {part_str}"
        else:
            return f"▽ WATCH [{grade}] — {part_str}"

    # ── Checklist ────────────────────────────────────────────────────

    def _build_checklist(self, sig, vix, r: ConvictionResult):
        """Build pre-trade checklist items."""
        checks = []

        # ── Entry conditions ─────────────────────────────────────────
        if sig.wr_30 < -70:
            checks.append(("warn", "WR(30) Extreme", f"WR={sig.wr_30:.0f}",
                           "Extended — watch for trend break"))
        elif sig.wr_30 < -50:
            checks.append(("pass", "WR(30) Oversold", f"WR={sig.wr_30:.0f}",
                           "Entry condition met"))
        elif sig.wr_30 < -30:
            checks.append(("pass", "WR(30) Zone", f"WR={sig.wr_30:.0f}",
                           "Moderate pullback — clean reversion (best win rate)"))
        else:
            checks.append(("fail", "WR(30) Wait", f"WR={sig.wr_30:.0f}",
                           "Not oversold"))

        if not sig.above_sma and sig.pct_from_sma < -8:
            checks.append(("warn", "Far Below SMA", f"{sig.pct_from_sma:+.1f}%",
                           "Extended — may not revert quickly"))
        elif not sig.above_sma:
            checks.append(("pass", "Below SMA", f"{sig.pct_from_sma:+.1f}%",
                           "Pullback active"))
        else:
            checks.append(("fail", "Above SMA", f"{sig.pct_from_sma:+.1f}%",
                           "Not a pullback"))

        # ── Conviction factors ───────────────────────────────────────
        if sig.mfi >= 55:
            checks.append(("pass", "MFI Strong", f"MFI={sig.mfi:.0f}",
                           "Strong flow — high conviction"))
        elif sig.mfi >= 45:
            checks.append(("pass", "MFI OK", f"MFI={sig.mfi:.0f}",
                           "Flow confirming"))
        elif sig.mfi >= 30:
            checks.append(("warn", "MFI Weak", f"MFI={sig.mfi:.0f}",
                           "Low flow — reduced conviction"))
        else:
            checks.append(("fail", "MFI Absent", f"MFI={sig.mfi:.0f}",
                           "No buying pressure"))

        rsi = getattr(sig, "rsi", None)
        if rsi is not None:
            if rsi >= 50:
                checks.append(("pass", "RSI Recovering", f"RSI={rsi:.0f}",
                               "Momentum returning"))
            elif rsi >= 40:
                checks.append(("pass", "RSI OK", f"RSI={rsi:.0f}",
                               "Not in freefall"))
            else:
                checks.append(("warn", "RSI Weak", f"RSI={rsi:.0f}",
                               "Momentum absent"))

        if sig.vol_ratio >= 1.5:
            checks.append(("pass", "Volume Surge", f"{sig.vol_ratio:.1f}x avg",
                           "Institutional activity"))
        elif sig.vol_ratio >= 0.8:
            checks.append(("warn", "Volume Normal", f"{sig.vol_ratio:.1f}x avg",
                           "No unusual activity"))
        else:
            checks.append(("warn", "Volume Dry", f"{sig.vol_ratio:.1f}x avg",
                           "Thin volume"))

        # ── Context ──────────────────────────────────────────────────
        if sig.dd_from_high <= -15:
            checks.append(("warn", "Deep DD", f"{sig.dd_from_high:.1f}%",
                           "Extended — trend change risk"))
        elif sig.dd_from_high <= -5:
            checks.append(("pass", "Moderate DD", f"{sig.dd_from_high:.1f}%",
                           "Orderly pullback"))
        else:
            checks.append(("pass", "Shallow DD", f"{sig.dd_from_high:.1f}%",
                           "Clean dip — quick reversion"))

        # VIX
        if vix is not None:
            _VIX = {
                "PANIC": ("pass", "VIX Panic", f"VIX={vix:.1f}", "97% win — strong tailwind"),
                "ELEVATED": ("pass", "VIX Elevated", f"VIX={vix:.1f}", "80% win zone"),
                "LOW": ("pass", "VIX Low", f"VIX={vix:.1f}", "Clean reversions"),
                "NORMAL": ("warn", "VIX Normal", f"VIX={vix:.1f}", "68% win — choppy zone"),
            }
            checks.append(_VIX.get(r.vix_regime, ("warn", "VIX", f"{vix:.1f}", "Unknown")))

        # Options (only extreme PCR affects score; moderate = context only)
        opt = sig.options_overlay
        if opt >= 3:
            checks.append(("pass", "Options ✓", sig.options_detail, "contrarian bullish"))
        elif opt <= -3:
            checks.append(("fail", "Options ✗", sig.options_detail, "extreme complacency"))
        elif opt != 0:
            checks.append(("warn", "Options", sig.options_detail, f"{opt:+d}"))
        else:
            checks.append(("warn", "Options", sig.options_detail or "No data", "context"))

        # Filing
        if sig.is_trap:
            checks.append(("fail", "⚠ TRAP", sig.filing_detail, "Bearish filing"))
        elif sig.filing_overlay > 3:
            checks.append(("pass", "Filing ✓", sig.filing_detail, f"+{sig.filing_overlay}"))
        elif sig.filing_overlay < -3:
            checks.append(("fail", "Filing ✗", sig.filing_detail, f"{sig.filing_overlay}"))
        elif sig.filing_overlay != 0:
            checks.append(("warn", "Filing ~", sig.filing_detail, f"{sig.filing_overlay:+d}"))
        else:
            checks.append(("warn", "Filing —", sig.filing_detail or "No filing", "0"))

        # Sector RS (H1: LEADING 77% vs LAGGING 66%, p=0.0017)
        if r.sector_rotation:
            _RS_STATUS = {
                "LEADING": "pass", "IMPROVING": "pass",
                "INLINE": "warn", "WEAKENING": "warn",
                "LAGGING": "fail",
            }
            rs_status = _RS_STATUS.get(r.sector_rotation, "warn")
            rs_val = f"{r.sector_rotation}"
            rs_impact_str = f"{r.sector_rs_impact:+d}" if r.sector_rs_impact != 0 else "0"
            rs_detail = f"{r.sector_name} — grade {rs_impact_str}" if r.sector_name else f"grade {rs_impact_str}"
            checks.append((rs_status, "Sector RS", rs_val, rs_detail))
        else:
            checks.append(("warn", "Sector RS", "—", "No sector data"))

        # Rotation divergence (lagging behind correlated sectors → catch-up)
        if r.div_lag_count >= 3:
            checks.append(("pass", "Rotation CU", f"lagging {r.div_lag_count} peers",
                           f"vs {r.div_top_pair} ({r.div_top_spread:.0f}pp) — catch-up +1"))
        elif r.div_lag_count >= 1:
            checks.append(("pass", "Rotation CU", f"lagging {r.div_lag_count} peer{'s' if r.div_lag_count > 1 else ''}",
                           f"vs {r.div_top_pair} ({r.div_top_spread:.0f}pp) — catch-up +1"))
        elif r.sector_name:
            # Sector data exists but no divergence — not lagging
            pass  # skip row entirely, don't clutter checklist

        # Entry — grade-based sizing
        if sig.entry_triggered:
            gate_note = ""
            min_grade = self.MIN_GRADE_NORMAL_VIX if r.vix_regime == "NORMAL" else self.MIN_GRADE
            if r.vix_regime == "NORMAL" and r.effective_sizing == "SKIP":
                gate_note = f" (Normal VIX: need ≥ {self.MIN_GRADE_NORMAL_VIX})"
            elif r.is_friday and r.vix_regime in ("ELEVATED", "PANIC"):
                gate_note = " (Friday gate)"

            sizing = r.effective_sizing
            grade = r.grade
            if sizing == "FULL":
                checks.append(("pass", f"▶ {grade} → FULL", sig.entry_reason,
                               f"High conviction{gate_note}"))
            elif sizing == "HALF":
                checks.append(("pass", f"▷ {grade} → HALF", sig.entry_reason,
                               f"Moderate conviction{gate_note}"))
            elif gate_note:
                checks.append(("warn", f"△ {grade} → SKIP", sig.entry_reason,
                               f"Gate active{gate_note}"))
            else:
                checks.append(("warn", f"△ {grade} → SKIP", sig.entry_reason,
                               f"Below min grade ({min_grade})"))

            # Target/stop from ATR
            if r.target_pct and r.stop_pct:
                if r.stop_atr_mult and r.atr_pct:
                    checks.append(("pass", "Target/Stop",
                                   f"PT +{r.target_pct}% · SL {r.stop_pct}% ({r.stop_atr_mult:.1f}× ATR) · BBW exit",
                                   f"ATR={r.atr_pct:.1f}%"))
                else:
                    checks.append(("pass", "Target/Stop",
                                   f"PT +{r.target_pct}% · SL {r.stop_pct}% · BBW exit",
                                   "ATR unavailable"))
        else:
            missing = []
            if sig.wr_30 >= -30: missing.append("WR oversold")
            if sig.above_sma: missing.append("below SMA")
            if sig.mfi < 30: missing.append("MFI > 30")
            checks.append(("fail", "NO ENTRY",
                           f"Missing: {', '.join(missing)}" if missing else "Not met", "Wait"))

        return checks


# Module-level singleton
_engine = ConvictionEngine()


def compute_conviction(dm_sig, vix=None, sector_ctx=None) -> ConvictionResult:
    """Convenience function — calls the singleton engine."""
    return _engine.compute(dm_sig, vix=vix, sector_ctx=sector_ctx)


def classify_vix_regime(vix: float | None) -> str:
    """
    Single source of truth for VIX regime classification.

    Thresholds validated on 4,511 OOS MR trades:
        PANIC    > 22   (Sh 6.40, 100% win)
        ELEVATED ≥ 18   (Sh 2.68, 83% win)
        NORMAL   ≥ 13   (Sh 0.60, 68% win)
        LOW      < 13   (Sh 1.42, 78% win)

    All code that needs a VIX regime for trade grading should call this.
    RegimeOrchestrator uses DIFFERENT thresholds for strategy allocation
    (PANIC=25, ELEVATED=20) — that's intentional, different purpose.
    """
    if vix is None:
        return "UNKNOWN"
    if vix > _engine.VIX_PANIC:
        return "PANIC"
    if vix >= _engine.VIX_ELEVATED:
        return "ELEVATED"
    if vix >= _engine.VIX_NORMAL:
        return "NORMAL"
    return "LOW"

