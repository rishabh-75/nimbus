"""Tests for nimbus_v3.compute.confluence."""
from __future__ import annotations

import math

from nimbus_v3.compute.confluence import (
    compute_confluence,
    _percentiles,
)
from nimbus_v3.compute.industry_rotation import (
    IndustryRotation,
    RotationResult,
)
from nimbus_v3.compute.industry_seasonality import (
    IndustrySeasonality,
    SeasonalityGrid,
)
from nimbus_v3.compute.rrg import (
    Maturity,
    Quadrant,
    RRGPoint,
    RRGResult,
)
from nimbus_v3.compute.seasonality import seasonal_reliability


def _seas_row(industry, month, avg, std, n_members=6, quality=None):
    a = [float("nan")] * 12
    s = [float("nan")] * 12
    q = [float("nan")] * 12
    a[month - 1] = avg
    s[month - 1] = std
    # By default the seasonal quality equals the composite reliability
    # (no member-level lumpiness modelled); a test can pass an explicit
    # `quality` to simulate a lumpy-heavy industry whose member-aware
    # quality diverges from its composite reliability.
    if avg == avg and std == std:
        q[month - 1] = (seasonal_reliability(avg, std) if quality is None
                        else quality)
    return IndustrySeasonality(
        industry=industry,
        avg_returns=tuple(a),
        hit_rates=(float("nan"),) * 12,
        std_returns=tuple(s),
        std_errs=(float("nan"),) * 12,
        cumulative_path=(0.0,) * 12,
        cell_n_members=(n_members,) * 12,
        seasonal_quality=tuple(q),
        n_years=5, n_members=n_members, has_data=True)


def _rot(*pairs):
    return RotationResult(
        industries=tuple(
            IndustryRotation(ind, (), (), roc, 6) for ind, roc in pairs),
        lookback=60)


def _rrg(*specs):
    pts = []
    for ind, rs, mom, quad, mat in specs:
        pts.append(RRGPoint(ind, rs, mom, 1.0, quad, 6, (), 0.2, mat))
    return RRGResult(points=tuple(pts), lookback=60)


# --------------------------------------------------------------------------
# Percentile helper
# --------------------------------------------------------------------------

def test_percentiles_basic():
    p = _percentiles({"a": 1.0, "b": 2.0, "c": 3.0})
    assert p["a"] == 0.0
    assert p["c"] == 100.0
    assert p["b"] == 50.0


def test_percentiles_nan_excluded():
    p = _percentiles({"a": 1.0, "b": float("nan"), "c": 3.0})
    assert math.isnan(p["b"])
    assert p["a"] == 0.0 and p["c"] == 100.0


def test_percentiles_single_value_is_median():
    p = _percentiles({"only": 5.0})
    assert p["only"] == 50.0


# --------------------------------------------------------------------------
# Engine
# --------------------------------------------------------------------------

def test_direction_is_absolute_not_relative():
    """Direction must use an ABSOLUTE desirability scale, not a percentile.
    Regression for the relative-ranking trap: a Weakening/Maturing leader
    in a field of even-worse Lagging industries must still score LOW on
    direction — it should not look strong merely because the rest are
    worse."""
    rot = _rot(("Fader", 10.0), ("Lag1", 1.0), ("Lag2", 0.5))
    rrg = _rrg(
        ("Fader", 106.0, 98.0, Quadrant.WEAKENING, Maturity.MATURING),
        ("Lag1", 95.0, 95.0, Quadrant.LAGGING, Maturity.MATURING),
        ("Lag2", 93.0, 94.0, Quadrant.LAGGING, Maturity.MATURING))
    seas = SeasonalityGrid(rows=(
        _seas_row("Fader", 6, 2.0, 3.0),
        _seas_row("Lag1", 6, 1.0, 3.0),
        _seas_row("Lag2", 6, 1.0, 3.0)))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # Weakening·Maturing absolute desirability = 0.35 * 0.45 = 0.1575 → ~16.
    # Even though it's the BEST direction in this field, it stays low.
    assert by["Fader"].direction.percentile < 25
    # Lagging ones are ~0.
    assert by["Lag1"].direction.percentile < 5


def test_empty_inputs_no_rows():
    res = compute_confluence(
        _rot(), _rrg(), SeasonalityGrid(rows=()), None, month=6)
    assert not res.has_data
    assert res.rows == ()


def test_strong_industry_ranks_top():
    """An industry leading on all three factors ranks above a laggard."""
    rot = _rot(("Strong", 12.0), ("Weak", -5.0))
    rrg = _rrg(
        ("Strong", 108.0, 104.0, Quadrant.LEADING, Maturity.FRESH),
        ("Weak", 92.0, 96.0, Quadrant.LAGGING, Maturity.MATURING))
    seas = SeasonalityGrid(rows=(
        _seas_row("Strong", 6, 7.0, 2.0),
        _seas_row("Weak", 6, -3.0, 5.0)))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    assert res.rows[0].industry == "Strong"
    assert res.rows[0].score > res.rows[1].score


def test_seasonal_reliability_discount():
    """Two industries identical on strength+direction; the one whose
    current-month seasonal cell is outlier-driven (low reliability) has
    its seasonal factor discounted to near-nothing, while a dependable
    cell gets full weight. The seasonal CONFIDENCE reflects this."""
    rot = _rot(("Depend", 5.0), ("Outlier", 5.0))
    rrg = _rrg(
        ("Depend", 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH),
        ("Outlier", 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH))
    seas = SeasonalityGrid(rows=(
        _seas_row("Depend", 6, 8.0, 2.0),     # high reliability
        _seas_row("Outlier", 6, 8.0, 40.0)))  # ~0 reliability
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # Same raw seasonal avg, very different confidence.
    assert by["Depend"].seasonal.value == by["Outlier"].seasonal.value
    assert by["Depend"].seasonal.confidence > 0.8
    assert by["Outlier"].seasonal.confidence < 0.2


def test_blank_seasonal_cell_does_not_sink_score():
    """An industry with no seasonal cell this month still ranks on the
    other two factors — seasonal contributes 0 weight, not a 0 score."""
    rot = _rot(("HasNoSeason", 10.0), ("Other", 1.0))
    rrg = _rrg(
        ("HasNoSeason", 107.0, 103.0, Quadrant.LEADING, Maturity.FRESH),
        ("Other", 99.0, 99.0, Quadrant.LAGGING, Maturity.STABLE))
    # HasNoSeason has a NaN current-month cell.
    seas = SeasonalityGrid(rows=(
        _seas_row("HasNoSeason", 6, float("nan"), float("nan")),
        _seas_row("Other", 6, 2.0, 3.0)))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # Strong on strength+direction → still ranks top despite no seasonal.
    assert res.rows[0].industry == "HasNoSeason"
    assert by["HasNoSeason"].seasonal.confidence == 0.0
    assert by["HasNoSeason"].score == by["HasNoSeason"].score  # not NaN


def test_direction_penalises_late_stage_leader():
    """A high-ROC industry whose momentum has rolled over (Weakening /
    Maturing) should score below a fresh improver of similar strength —
    direction is doing real work, not just echoing strength."""
    rot = _rot(("FadingLeader", 10.0), ("FreshMover", 9.0))
    rrg = _rrg(
        ("FadingLeader", 106.0, 98.0, Quadrant.WEAKENING, Maturity.MATURING),
        ("FreshMover", 104.0, 103.0, Quadrant.LEADING, Maturity.FRESH))
    seas = SeasonalityGrid(rows=(
        _seas_row("FadingLeader", 6, 3.0, 3.0),
        _seas_row("FreshMover", 6, 3.0, 3.0)))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    assert by["FreshMover"].direction.percentile > \
        by["FadingLeader"].direction.percentile


def test_regime_is_context_not_gate():
    """Regime label is carried for the banner but does NOT change scores:
    the same factors produce the same ranking regardless of regime."""
    rot = _rot(("A", 8.0), ("B", 2.0))
    rrg = _rrg(
        ("A", 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH),
        ("B", 98.0, 99.0, Quadrant.LAGGING, Maturity.STABLE))
    seas = SeasonalityGrid(rows=(
        _seas_row("A", 6, 4.0, 2.0), _seas_row("B", 6, 1.0, 2.0)))

    class _Regime:
        def __init__(self, label):
            self.label = label
            self.signals_on = 1
            self.n_signals = 4

    on = compute_confluence(rot, rrg, seas, _Regime("RISK_ON"), month=6)
    off = compute_confluence(rot, rrg, seas, _Regime("RISK_OFF"), month=6)
    assert on.regime_label == "RISK_ON"
    assert off.regime_label == "RISK_OFF"
    # Scores identical regardless of regime — it's context, not a gate.
    on_scores = {r.industry: round(r.score, 6) for r in on.rows}
    off_scores = {r.industry: round(r.score, 6) for r in off.rows}
    assert on_scores == off_scores


def test_score_is_gated_product_of_strength():
    """The score is strength_pct gated multiplicatively by direction and
    seasonality — never an additive blend. A name with elite strength but
    a weak/lumpy seasonal is heavily discounted BELOW its strength
    percentile (the multiplicative gate genuinely bites), and can be
    overtaken by a name with all three moderate-but-aligned."""
    core = [
        # Elite strength, elite direction, but WEAK+lumpy seasonal.
        ("EliteStrWeakSeas", 20.0, 112.0, 104.0, Quadrant.LEADING,
         Maturity.FRESH, 2.0, 0.15),
        # Moderate strength, good direction, STRONG clean seasonal.
        ("ModStrGoodSeas", 9.0, 104.0, 102.0, Quadrant.LEADING,
         Maturity.FRESH, 8.0, 0.90),
    ]
    filler = [
        (f"F{i}", -3.0 - i, 96.0 - i, 96.0, Quadrant.LAGGING,
         Maturity.MATURING, 0.0, 0.1) for i in range(6)
    ]
    allp = core + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat)
                 for i, _, rs, m, q, mat, _, _ in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, sa, 3.0, quality=sq)
        for i, *_, sa, sq in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # The elite-strength name is discounted well below its strength
    # percentile by the weak seasonal gate.
    assert by["EliteStrWeakSeas"].score < \
        by["EliteStrWeakSeas"].strength.percentile
    # And the all-three-aligned name overtakes it despite lower strength.
    assert by["ModStrGoodSeas"].score > by["EliteStrWeakSeas"].score


def test_good_seasonal_cannot_rescue_fading_name():
    """A strong, clean seasonal must NOT lift a Weakening/Lagging name:
    for non-favourable direction the seasonal gate is pinned at the floor,
    so seasonality can only fail to help, never compensate for bad
    direction."""
    core = [
        # Weakening name with an excellent seasonal.
        ("FadingGoodSeas", 12.0, 106.0, 97.0, Quadrant.WEAKENING,
         Maturity.MATURING, 8.0, 0.90),
        # Leading name with a mediocre seasonal, similar strength.
        ("LeadMehSeas", 12.0, 106.0, 103.0, Quadrant.LEADING,
         Maturity.FRESH, 3.0, 0.30),
    ]
    filler = [
        (f"F{i}", -3.0 - i, 96.0 - i, 96.0, Quadrant.LAGGING,
         Maturity.MATURING, 0.0, 0.1) for i in range(6)
    ]
    allp = core + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat)
                 for i, _, rs, m, q, mat, _, _ in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, sa, 3.0, quality=sq)
        for i, *_, sa, sq in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # The Leading name outranks the Weakening one even though the latter
    # has a far better seasonal — seasonality can't rescue fading direction.
    assert by["LeadMehSeas"].score > by["FadingGoodSeas"].score


def test_extended_direction_below_fresh():
    """An EXTENDED industry scores below an otherwise-identical FRESH one
    on direction — late-stage froth is penalised vs an early move, even
    though both are still rising."""
    rot = _rot(("Stretched", 8.0), ("Early", 8.0))
    rrg = _rrg(
        ("Stretched", 118.0, 103.0, Quadrant.LEADING, Maturity.EXTENDED),
        ("Early", 104.0, 102.0, Quadrant.LEADING, Maturity.FRESH))
    seas = SeasonalityGrid(rows=(
        _seas_row("Stretched", 6, 3.0, 3.0),
        _seas_row("Early", 6, 3.0, 3.0)))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    assert by["Early"].direction.percentile > \
        by["Stretched"].direction.percentile


def test_seasonal_only_industry_excluded():
    """An industry with a seasonal cell but NO strength/direction reading
    (e.g. a sub-floor override name absent from RRG/ROC) must not rank on
    seasonal alone — rotation needs a momentum read. It is excluded."""
    rot = _rot(("HasMomentum", 8.0))          # only one has ROC
    rrg = _rrg(
        ("HasMomentum", 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH))
    # SeasonalOnly has a (great) seasonal cell but no RRG/ROC entry.
    seas = SeasonalityGrid(rows=(
        _seas_row("HasMomentum", 6, 3.0, 3.0),
        _seas_row("SeasonalOnly", 6, 9.0, 1.0)))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    inds = {r.industry for r in res.rows}
    assert "SeasonalOnly" not in inds
    assert "HasMomentum" in inds


def test_direction_gate_caps_extended_and_weakening():
    """The direction soft-gate caps late/fading names: with comparable
    (adjacent) strength standing, a Leading·Fresh industry outranks an
    Extended or Weakening one. Uses a realistic universe so the top names
    have adjacent strength percentiles (in a tiny universe percentile
    spread is degenerate)."""
    top = [
        ("Extended", 12.0, 119.0, 104.0, Quadrant.LEADING,
         Maturity.EXTENDED),
        ("Fresh", 11.5, 116.0, 103.0, Quadrant.LEADING, Maturity.FRESH),
        ("Weak", 11.7, 117.0, 97.0, Quadrant.WEAKENING, Maturity.MATURING),
    ]
    filler = [
        (f"F{i}", 1.0 + i * 0.4, 101.0 + i, 100.0, Quadrant.LAGGING,
         Maturity.MATURING) for i in range(8)
    ]
    allp = top + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat) for i, _, rs, m, q, mat in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, 3.0, 3.0) for i, *_ in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # Fresh outranks both froth (Extended) and fading (Weak).
    assert by["Fresh"].score > by["Extended"].score
    assert by["Fresh"].score > by["Weak"].score
    assert by["Weak"].score < by["Extended"].score


def test_favourable_seasonal_boost_only_for_good_direction():
    """The favourable-direction seasonal boost is real and gated on good
    direction. LeadSeas has slightly LOWER raw strength than LeadNoSeas,
    so without the boost it would rank below — its strong, reliable
    seasonal lifts it above. A Weakening name with an equally strong
    seasonal gets NO boost and stays buried."""
    core = [
        # (name, roc, rs, mom, quad, mat, seas_avg, seas_std)
        ("LeadSeas", 5.0, 104.0, 102.0, Quadrant.LEADING, Maturity.FRESH,
         9.0, 1.5),                                   # weaker RS, great seas
        ("LeadNoSeas", 7.0, 106.0, 102.0, Quadrant.LEADING, Maturity.FRESH,
         0.1, 6.0),                                   # stronger RS, no seas
        ("WeakSeas", 7.0, 106.0, 97.0, Quadrant.WEAKENING, Maturity.MATURING,
         9.0, 1.5),                                   # strong seas, bad dir
    ]
    filler = [
        (f"F{i}", -3.0 - i, 96.0 - i, 96.0, Quadrant.LAGGING,
         Maturity.MATURING, 0.0, 3.0) for i in range(6)
    ]
    allp = core + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat)
                 for i, _, rs, m, q, mat, _, _ in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, sa, ss) for i, *_, sa, ss in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # Boost lifts the weaker-but-good-seasonal Leading name above the
    # stronger one that lacks a seasonal edge.
    assert by["LeadSeas"].score > by["LeadNoSeas"].score
    # The Weakening name is NOT rescued by its strong seasonal.
    assert by["WeakSeas"].score < by["LeadSeas"].score
    assert by["WeakSeas"].score < by["LeadNoSeas"].score


def test_seasonal_is_a_tilt_not_a_veto():
    """Seasonality is a TILT, not a near-veto (dampened regime, floor 0.55).

    Two effects, both required:

    1. In a CLOSE-strength call, a strong reliable seasonal still edges a
       name ahead of a comparably-strong one with a dead seasonal — the
       tilt is still live and can win a genuine tie-break.

    2. But the higher-strength / dead-seasonal name is NOT crushed the way
       the old hard gate (floor 0.20) crushed it: with strength as the
       primary factor, a top-strength name keeps the MAJORITY of its
       strength percentile even with no seasonal support (its seasonal gate
       is now ≥ the 0.55 floor, not ~0.20). This is the "bump strength,
       dampen seasonality" contract: seasonality corroborates, it no longer
       overrides.
    """
    core = [
        # Strong strength, but WEAK+unreliable seasonal.
        ("StrongNoSeas", 14.0, 108.0, 103.0, Quadrant.LEADING,
         Maturity.FRESH, 2.0, 12.0),
        # Slightly weaker strength, but STRONG+reliable seasonal.
        ("ModStrongSeas", 9.0, 104.0, 102.0, Quadrant.LEADING,
         Maturity.STABLE, 9.0, 2.0),
    ]
    filler = [
        (f"F{i}", -3.0 - i, 96.0 - i, 96.0, Quadrant.LAGGING,
         Maturity.MATURING, 0.0, 3.0) for i in range(6)
    ]
    allp = core + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat)
                 for i, _, rs, m, q, mat, _, _ in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, sa, ss) for i, *_, sa, ss in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    strong, seasonal = by["StrongNoSeas"], by["ModStrongSeas"]

    # (1) the live tilt: the elite-seasonal name still edges the close-strength
    # peer whose seasonal is dead.
    assert seasonal.score >= strong.score

    # (2) anti-veto: the top-strength name keeps the MAJORITY of its strength
    # percentile despite a dead seasonal — the seasonal gate floor (0.55) now
    # protects strength from being near-vetoed. Under the old hard gate it
    # retained ~a fifth; here it must retain over half.
    assert strong.score >= 0.50 * strong.strength.percentile


def test_seasonal_penalty_only_favourable_direction():
    """A Weakening name is NOT additionally penalised for a weak seasonal
    (it's already gated down hard); the penalty is a favourable-direction
    mechanism only, so it doesn't double-count."""
    from nimbus_v3.compute import confluence as C
    # Weakening name with a weak seasonal, plus filler for a real universe.
    core = [
        ("WeakDir", 8.0, 105.0, 97.0, Quadrant.WEAKENING, Maturity.MATURING,
         1.0, 12.0),
        ("GoodDir", 8.0, 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH,
         8.0, 2.0),
    ]
    filler = [
        (f"F{i}", -3.0 - i, 96.0 - i, 96.0, Quadrant.LAGGING,
         Maturity.MATURING, 0.0, 3.0) for i in range(6)
    ]
    allp = core + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat)
                 for i, _, rs, m, q, mat, _, _ in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, sa, ss) for i, *_, sa, ss in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # The favourable-direction name still clearly outranks the weakening
    # one — the point is simply that the penalty path didn't error or
    # double-penalise the weakening name.
    assert by["GoodDir"].score > by["WeakDir"].score


def test_lumpy_member_quality_demotes_seasonal_factor():
    """The confluence seasonal factor uses the member-aware seasonal
    QUALITY, not the raw composite reliability. Two Leading names with the
    SAME seasonal magnitude and SAME composite reliability, but one has a
    low member-quality (heavy lumpy members / dependable underweight) — it
    should rank below the one whose seasonal is member-clean."""
    # Both have avg +6, composite reliability ~ the same, but Lumpy's
    # quality is explicitly low (as _seasonal_quality_for_month would
    # produce for a lumpy-heavy industry).
    clean = _seas_row("Clean", 6, 6.0, 3.0, quality=0.75)
    lumpy = _seas_row("Lumpy", 6, 6.0, 3.0, quality=0.20)
    rot = _rot(("Clean", 8.0), ("Lumpy", 8.0))
    rrg = _rrg(
        ("Clean", 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH),
        ("Lumpy", 105.0, 102.0, Quadrant.LEADING, Maturity.FRESH))
    seas = SeasonalityGrid(rows=(clean, lumpy))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}
    # Same seasonal magnitude, but the lumpy industry's lower quality
    # lowers its seasonal confidence → it ranks below the clean one.
    assert by["Clean"].seasonal.confidence > by["Lumpy"].seasonal.confidence
    assert by["Clean"].score > by["Lumpy"].score


def test_breadth_gate_discounts_narrow_participation():
    """The market-relative breadth gate discounts a narrow move: two
    identical-strength Leading names diverge only in participation — the
    one whose member breadth is well below the market's is scored below
    the broadly-participating one, which (at/above market) is untouched."""
    rot = _rot(("Broad", 10.0), ("Narrow", 10.0))
    rrg = _rrg(
        ("Broad", 106.0, 103.0, Quadrant.LEADING, Maturity.FRESH),
        ("Narrow", 106.0, 103.0, Quadrant.LEADING, Maturity.FRESH))
    seas = SeasonalityGrid(rows=(
        _seas_row("Broad", 6, 4.0, 3.0, quality=0.3),
        _seas_row("Narrow", 6, 4.0, 3.0, quality=0.3)))
    # Market breadth 61%; Broad is above it, Narrow far below.
    breadth = {"Broad": 0.80, "Narrow": 0.35}
    res = compute_confluence(
        rot, rrg, seas, None, month=6,
        breadth_by_industry=breadth, market_breadth=0.61)
    by = {r.industry: r for r in res.rows}
    assert by["Narrow"].score < by["Broad"].score
    # Baseline without breadth: identical scores (gate is the only cause).
    base = compute_confluence(rot, rrg, seas, None, month=6)
    bb = {r.industry: r.score for r in base.rows}
    assert abs(bb["Broad"] - bb["Narrow"]) < 1e-9
    # Broad (at/above market) is not discounted vs its own baseline.
    assert abs(by["Broad"].score - bb["Broad"]) < 1e-9


def test_breadth_gate_inert_without_data():
    """With no breadth inputs the gate is inert — scores match the
    pre-breadth model exactly, so the feature is purely additive."""
    rot = _rot(("A", 10.0), ("B", 6.0))
    rrg = _rrg(
        ("A", 106.0, 103.0, Quadrant.LEADING, Maturity.FRESH),
        ("B", 103.0, 102.0, Quadrant.LEADING, Maturity.STABLE))
    seas = SeasonalityGrid(rows=(
        _seas_row("A", 6, 4.0, 3.0, quality=0.4),
        _seas_row("B", 6, 5.0, 3.0, quality=0.4)))
    with_none = compute_confluence(rot, rrg, seas, None, month=6)
    # market_breadth given but breadth_by_industry empty → still inert.
    with_mkt_only = compute_confluence(
        rot, rrg, seas, None, month=6, market_breadth=0.61)
    a = {r.industry: r.score for r in with_none.rows}
    b = {r.industry: r.score for r in with_mkt_only.rows}
    assert a == b


def test_row_carries_breadth_and_gate():
    """Each ConfluenceRow surfaces the raw breadth (fraction 0..1) and the
    breadth gate actually applied, so the Breadth column is auditable. A
    narrow industry shows a gate < 1.0; a broad one shows 1.0."""
    rot = _rot(("Broad", 10.0), ("Narrow", 10.0))
    rrg = _rrg(
        ("Broad", 106.0, 103.0, Quadrant.LEADING, Maturity.FRESH),
        ("Narrow", 106.0, 103.0, Quadrant.LEADING, Maturity.FRESH))
    seas = SeasonalityGrid(rows=(
        _seas_row("Broad", 6, 4.0, 3.0, quality=0.3),
        _seas_row("Narrow", 6, 4.0, 3.0, quality=0.3)))
    breadth = {"Broad": 0.80, "Narrow": 0.35}
    res = compute_confluence(
        rot, rrg, seas, None, month=6,
        breadth_by_industry=breadth, market_breadth=0.61)
    by = {r.industry: r for r in res.rows}
    # Raw breadth carried through.
    assert abs(by["Broad"].breadth - 0.80) < 1e-9
    assert abs(by["Narrow"].breadth - 0.35) < 1e-9
    # Broad (above market) → gate 1.0; Narrow (below) → gate < 1.0.
    assert by["Broad"].breadth_gate == 1.0
    assert by["Narrow"].breadth_gate < 1.0
    # Without breadth data the field is NaN and the gate defaults to 1.0.
    res2 = compute_confluence(rot, rrg, seas, None, month=6)
    r0 = res2.rows[0]
    assert r0.breadth != r0.breadth      # NaN
    assert r0.breadth_gate == 1.0


def test_leading_outranks_improving_at_equal_strength():
    """A confirmed leader beats a weak-but-turning name on equal strength.

    IMPROVING used to share LEADING's full 1.00 direction gate, so the two
    were interchangeable and the tie fell to whatever noise separated their
    strength. Measured forward returns (rrg_lookback_probe) put Leading
    consistently ahead, so IMPROVING is now discounted to 0.90.

    This is a TIE-BREAK, not a demotion: the gap must be small enough that
    a genuinely stronger Improving name can still win. Both halves are
    asserted, so pushing the gate too low would fail this test.
    """
    core = [
        ("LeadName", 8.0, 106.0, 103.0, Quadrant.LEADING,
         Maturity.FRESH, 5.0, 5.0),
        ("ImprovingName", 8.0, 96.0, 106.0, Quadrant.IMPROVING,
         Maturity.TURNING, 5.0, 5.0),
    ]
    filler = [
        (f"F{i}", -3.0 - i, 96.0 - i, 96.0, Quadrant.LAGGING,
         Maturity.MATURING, 0.0, 3.0) for i in range(6)
    ]
    allp = core + filler
    rot = _rot(*[(i, r) for i, r, *_ in allp])
    rrg = _rrg(*[(i, rs, m, q, mat) for i, _, rs, m, q, mat, _, _ in allp])
    seas = SeasonalityGrid(rows=tuple(
        _seas_row(i, 6, sa, ss) for i, *_, sa, ss in allp))
    res = compute_confluence(rot, rrg, seas, None, month=6)
    by = {r.industry: r for r in res.rows}

    # (1) equal strength -> the confirmed leader wins.
    assert by["LeadName"].score > by["ImprovingName"].score

    # (2) but only just: the discount is a tie-break, so an Improving name
    # keeps most of its strength rather than being demoted like Weakening.
    ratio = by["ImprovingName"].score / by["LeadName"].score
    assert ratio > 0.80, (
        f"Improving retained only {ratio:.0%} of Leading's score — the "
        f"direction gate has become a demotion, not a tie-break")
