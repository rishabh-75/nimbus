"""nimbus_v3.compute.industry_composite — shared composite-index builder.

A single, stateless construction of an ADTV-weighted industry composite
price index, used by every industry-level engine (rotation, RRG,
seasonality). Centralising it means the alignment + rebasing + weighting
logic — which is subtle (common-grid alignment to avoid the vertical
"cliff" artifact from members with differing history lengths) — lives in
exactly one place.

The composite is a 100-based index: every member is rebased to 1.0 at the
common anchor date, ADTV-weighted, and scaled ×100. Callers that want
percent-from-zero simply compute ``(index / 100 - 1) * 100``.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from nimbus_v3.compute.indicators import adtv_latest


def build_industry_composite(
    members: list[str],
    panel: dict[str, pd.DataFrame],
    *,
    min_members: int,
    min_bars: int,
    lookback: int | None = None,
) -> tuple[pd.Series | None, list[tuple[str, float]]]:
    """Build an ADTV-weighted composite price index for one industry.

    Aligns members on their union date grid, forward-fills within (to
    carry the last known price across non-trading gaps), trims the
    leading region where fewer than half the members have data (where
    rebasing would be unstable), rebases every member to a common anchor,
    and ADTV-weights them into a single 100-based index.

    Args:
        members: member symbols.
        panel: ``{symbol: enriched_df}``.
        min_members: minimum usable members required (else returns None).
        min_bars: minimum bars a member needs, and minimum length of the
            resulting common grid.
        lookback: if given, each member is truncated to its last
            ``lookback`` bars before alignment (rotation/RRG windows);
            None uses full history (seasonality).

    Returns:
        ``(composite_index, member_weights)`` where ``composite_index``
        is a 100-based ``pd.Series`` (None if too few members) and
        ``member_weights`` is the list of ``(symbol, normalised_weight)``
        actually used.
    """
    raw: list[tuple[str, pd.Series, float]] = []
    for sym in members:
        df = panel.get(sym)
        if df is None or df.empty or "Close" not in df.columns:
            continue
        s = df["Close"].dropna()
        if len(s) < min_bars:
            continue
        if lookback is not None:
            s = s.tail(lookback)
        adtv = adtv_latest(df)
        w = adtv if (adtv == adtv and adtv > 0) else 0.0
        raw.append((sym, s, w))

    if len(raw) < min_members:
        return None, []

    # Common date grid (union), ffill within, then drop the leading
    # region where < half the members are present.
    price = pd.concat(
        [s for _, s, _ in raw], axis=1,
        keys=range(len(raw)), sort=False,
    ).sort_index().ffill()
    present = price.notna().sum(axis=1)
    price = price.loc[present >= max(1, len(raw) // 2)]
    if len(price) < min_bars:
        return None, []

    weights = np.array([w for _, _, w in raw], dtype=float)
    if weights.sum() <= 0:
        weights = np.ones(len(raw))
    weights = weights / weights.sum()

    # Rebase each member to its first value on the common grid (members
    # missing at the anchor are back-filled to their first available
    # value, so they start at 1.0 too — no cliff), then ADTV-weight.
    anchor = price.bfill().iloc[0]
    idx = price.div(anchor)
    vals = idx.to_numpy(dtype=float)
    mask = ~np.isnan(vals)
    wsum = (mask * weights[None, :]).sum(axis=1)
    wsum[wsum == 0] = np.nan
    composite = np.nansum(np.where(mask, vals, 0.0) * weights[None, :],
                          axis=1) / wsum

    member_weights = [(sym, float(w)) for (sym, _, _), w in zip(raw, weights)]
    return pd.Series(composite * 100.0, index=price.index), member_weights
