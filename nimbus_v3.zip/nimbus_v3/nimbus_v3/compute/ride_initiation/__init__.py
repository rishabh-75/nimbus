"""nimbus_v3.compute.ride_initiation — BB ride classification engine.

3-phase ride classifier: INITIATION / RETEST / CONTINUATION / NONE.

Used as a SCREENER signal in Market Pulse — surfaces candidates for
manual chart review, not a validated forward-return signal.

IMPORTANT — empirical context:

Walk-forward validation on the full NIFTY 500 panel (2021-2026) at
fwd_5d / fwd_10d / fwd_20d horizons produced clean negative results
across all definitions and horizons (see
``docs/research_notes/bb_ride_initiation/``). This module exists
because the operator finds the pattern useful for **manual** chart
selection. UI rendering should be neutral (no green/red) and
tooltips honest ("not a validated forward-return signal").

CRITICAL DEFINITION OF "ABOVE BAND":

A bar is "body-above" if BOTH Open and Close exceed the upper BB.
Lower wick may pierce the band — that's normal "testing support
and holding" behaviour during a ride. NOT just `Close > upper`.

Public API:

  - :class:`RideEngine` — stateless classifier. Use this for new code.
  - :class:`RidePhase` — categorical phase labels.
  - :class:`RideResult` — per-bar classification + score bundle.
  - :func:`compute_ride_init_active` — legacy bool API. Returns True
    where any phase is active. Kept for backward compatibility.
  - :func:`compute_ride_init_active_industry` — legacy industry bool.
  - :func:`debug_fire_criteria` — per-criterion diagnostic.
  - :func:`schema_hash` — hash of all tunables for cache invalidation.
"""

from __future__ import annotations

import pandas as pd

# Public types and engine
from .types import RidePhase, RideResult
from .engine import RideEngine
from .cache import RideClassificationCache

# Public constants — anything a downstream caller (tests, UI) might need
from .constants import (  # noqa: F401
    ACTIVE_WINDOW,
    BBW_FLOOR_PERCENTILE,
    BBW_FLOOR_WINDOW,
    BBW_LOOKBACK,
    BODY_STRENGTH_MIN,
    CONT_ACTIVE_WINDOW,
    CONT_DETACHED_PCTB_MAX,
    CONT_RIDE_BARS_MIN,
    CONT_RIDE_LOOKBACK,
    CONT_TREND_BUFFER,
    CONT_VOL_DECAY_FLOOR,
    CROSS_LOOKBACK,
    DETACHED_PCTB_MAX,
    DETACHED_PCTB_MAX_COMPRESSED,
    HOLD_BARS,
    INDUSTRY_MIN_MEMBERS,
    OPEN_PCTB_MAX,
    OPEN_PCTB_MIN,
    REQUIRED_COLS,
    RETEST_ACTIVE_WINDOW,
    RETEST_PULLBACK_MAX_BARS,
    RETEST_PULLBACK_PCTB_MAX,
    RETEST_PULLBACK_PCTB_MIN,
    RETEST_RIDE_BARS_MIN,
    RETEST_RIDE_LOOKBACK,
    SCORE_WEIGHT_BBW,
    SCORE_WEIGHT_BODY,
    SCORE_WEIGHT_FRESHNESS,
    SCORE_WEIGHT_MOMENTUM,
    SCORE_WEIGHT_VOLUME,
    SMA_SLOPE_WINDOW,
    VOL_PERCENTILE_FLOOR,
    VOL_PERCENTILE_WINDOW,
    VOL_SURGE_RATIO,
    VOL_SURGE_WINDOW,
    schema_hash,
)
from .debug import debug_fire_criteria

# RIDE_MIN_BARS dropped from API — was only used by the legacy
# `recent_above_count >= RIDE_MIN_BARS` predicate. Kept here as a
# constant for any test that imports it.
RIDE_MIN_BARS = 1


# Module-level singleton engine — used by the legacy bool wrappers.
# Stateless, so a single instance is fine.
_engine = RideEngine()


# ══════════════════════════════════════════════════════════════════════
# Backward-compatible bool API
# ══════════════════════════════════════════════════════════════════════


def compute_ride_init_active(df: pd.DataFrame) -> pd.Series:
    """Legacy bool API — returns True at bars where any phase is active.

    Wraps :meth:`RideEngine.classify`'s ``fire`` field. Keeps existing
    callers (UI, scanner snapshot, tests) working unchanged.

    For new code, prefer :class:`RideEngine` directly so you can
    inspect the phase and score.
    """
    return _engine.classify(df).fire


def compute_ride_init_active_industry(
    members_panel: dict[str, pd.DataFrame],
) -> pd.Series:
    """Legacy industry bool API.

    Now backed by the synthetic-index classifier — returns the
    ``.fire`` boolean from the industry's :class:`RideResult`.
    Existing callers see the same bool semantics; new callers
    should use :meth:`RideEngine.classify_industry` directly to
    get Phase + Score too.
    """
    return _engine.classify_industry(members_panel).fire


__all__ = [
    "RideEngine",
    "RidePhase",
    "RideResult",
    "RideClassificationCache",
    "compute_ride_init_active",
    "compute_ride_init_active_industry",
    "debug_fire_criteria",
    "schema_hash",
    # Constants
    "ACTIVE_WINDOW",
    "BBW_FLOOR_PERCENTILE",
    "BBW_FLOOR_WINDOW",
    "BBW_LOOKBACK",
    "BODY_STRENGTH_MIN",
    "CONT_ACTIVE_WINDOW",
    "CONT_DETACHED_PCTB_MAX",
    "CONT_RIDE_BARS_MIN",
    "CONT_RIDE_LOOKBACK",
    "CONT_TREND_BUFFER",
    "CONT_VOL_DECAY_FLOOR",
    "CROSS_LOOKBACK",
    "DETACHED_PCTB_MAX",
    "DETACHED_PCTB_MAX_COMPRESSED",
    "HOLD_BARS",
    "INDUSTRY_MIN_MEMBERS",
    "OPEN_PCTB_MAX",
    "OPEN_PCTB_MIN",
    "REQUIRED_COLS",
    "RETEST_ACTIVE_WINDOW",
    "RETEST_PULLBACK_MAX_BARS",
    "RETEST_PULLBACK_PCTB_MAX",
    "RETEST_PULLBACK_PCTB_MIN",
    "RETEST_RIDE_BARS_MIN",
    "RETEST_RIDE_LOOKBACK",
    "RIDE_MIN_BARS",
    "SMA_SLOPE_WINDOW",
    "VOL_PERCENTILE_FLOOR",
    "VOL_PERCENTILE_WINDOW",
    "VOL_SURGE_RATIO",
    "VOL_SURGE_WINDOW",
]
