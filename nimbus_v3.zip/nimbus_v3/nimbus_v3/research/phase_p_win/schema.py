"""Frozen dataclasses describing the research artefacts produced by
the phase-p_win pipeline.

These are the **only** data shapes the rest of the package
exchanges. Keeping them in one module lets ``extract`` /
``aggregate`` / ``cont_model`` evolve independently as long as
the schemas match.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Final


# ══════════════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════════════

#: Bar columns required for fire-event extraction. Anything missing
#: here means ``extract`` can't process the symbol — graceful skip.
REQUIRED_ENRICHED_COLUMNS: Final[tuple[str, ...]] = (
    "Open", "High", "Low", "Close", "Volume",
    "sma_20",
    "bb_20_1s_upper", "bb_20_1s_lower", "bb_20_1s_mid",
    "bbw_20_1s", "bb_20_1s_pct",
)

#: Minimum bars of history a symbol must have before we'll try to
#: extract events. Anything shorter doesn't have enough history to
#: form a stable SMA20 / BB / Williams %R, and the event sample
#: would be too small for Beta smoothing anyway.
MIN_HISTORY_BARS: Final[int] = 200

#: The classifier phase strings we care about. NONE bars are
#: skipped by extraction.
ACTIVE_PHASES: Final[tuple[str, ...]] = ("INIT", "RETEST", "CONT")

#: Return threshold (percent) for "meaningful win" — a fire that
#: returned more than this is counted as a meaningful win in the
#: parallel ``p_win_meaningful`` metric. Chosen at 1% to filter
#: out the long tail of "barely positive" returns that pad
#: ``p_win_profit`` without being operationally interesting.
MEANINGFUL_RETURN_PCT: Final[float] = 1.0

#: Forward horizon (in bars) for the fixed-horizon CONT model.
#: A CONT bar is positive iff its ride continues for ≥ this many
#: more bars. Five bars (~1 trading week) is the operator's
#: typical conviction window — long enough to be operationally
#: meaningful, short enough that most rides have a chance of
#: clearing it.
FIXED_HORIZON_BARS: Final[int] = 5


# ══════════════════════════════════════════════════════════════════════════════
# Per-fire event record
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class FireEvent:
    """One row per (symbol, trigger_idx) where a phase fired.

    Attributes are split into three blocks:

    Identity:
        symbol, phase, trigger_idx (integer position in the
        symbol's enriched df), trigger_date.

    Outcome (computed look-back-safe — only uses bars after trigger):
        hold_bars: bars from trigger to first close-below-band
            exit. ``None`` for the most recent fire if no exit has
            happened yet (open ride).
        exit_idx: integer position of the exit bar, or None.
        return_pct: (close[exit] / close[trigger] − 1) × 100. None
            for open rides.
        is_resolved: True iff the ride exited within the available
            history (i.e. we have a complete forward outcome).

    Features at trigger (computed look-ahead-safe — only uses bars
    ≤ trigger):
        pct_b_at_trigger, sma20_slope_pct, sma50_slope_pct,
        bb_width_pctile (rolling-percentile of bbw_20_1s),
        vol_ratio_20 (today's vol / 20-bar mean), atr_14_pct,
        bars_since_sma20_above_sma50.

    The split matters for two reasons:
      1. ``aggregate`` only consumes ``Outcome`` fields to compute
         per-symbol historical p_win.
      2. ``cont_model`` only consumes ``Features`` fields to train
         a universe-wide predictor; mixing in outcome would leak
         label information into features.
    """

    # ── Identity ──────────────────────────────────────────────────────
    symbol:        str
    phase:         str    # one of ACTIVE_PHASES
    trigger_idx:   int
    trigger_date:  str    # ISO date string for portability across parquet engines

    # ── Outcome ────────────────────────────────────────────────────────
    hold_bars:     int | None
    exit_idx:      int | None
    return_pct:    float | None
    is_resolved:   bool

    # ── Features at trigger (lag-aware) ────────────────────────────────
    pct_b_at_trigger:           float
    sma20_slope_pct:            float
    sma50_slope_pct:            float
    bb_width_pctile:            float
    vol_ratio_20:               float
    atr_14_pct:                 float
    bars_since_sma20_above_sma50: int
    body_above_count_prior_5:   int    # 0..5 — how mature the ride is


# ══════════════════════════════════════════════════════════════════════════════
# Per-(symbol, phase) aggregated p_win stats
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class PhaseWinRateStats:
    """Per (symbol, phase) historical statistics with multiple
    win-rate definitions.

    Three "win" definitions are computed in parallel because
    each captures a different question the operator might ask:

      1. **Relative** (``p_win_relative_*``): fire's return >
         symbol's own historical mean for this phase. By
         construction this hovers near 0.50 (the mean splits
         the distribution); dispersion captures distributional
         skew. Useful for asking "is this fire above-typical
         for this symbol".
      2. **Profit** (``p_win_profit_*``): fire's return > 0.
         Absolute threshold — what fraction of historical
         fires actually made money. Most operationally
         meaningful single number.
      3. **Meaningful** (``p_win_meaningful_*``): fire's return
         > +1.0%. Filters out the tiny-positive returns that
         pad the profit fraction. Asks "what fraction of fires
         delivered a result worth taking".

    All three share the Beta-binomial smoothing pipeline with
    a universe-rate prior — the prior just shifts depending on
    which threshold is in play.

    The smoothed estimate is the posterior mean of
    Beta(α + wins, β + losses) where:
        α = prior_strength × universe_p_win
        β = prior_strength × (1 − universe_p_win)
    ``prior_strength=5`` keeps n≤5 symbols pulled toward the
    universe rate; n=20 is barely affected.
    """

    symbol:               str
    phase:                str
    n_resolved:           int      # complete fires (excluded open rides)
    n_open:               int      # un-resolved fires at end of history
    avg_return_pct:       float    # mean of return_pct across resolved fires
    median_hold_bars:     int      # used as N for the CONT model's positive label

    # ── "Relative" win: return > symbol's own historical mean ──────
    n_wins_relative:      int
    p_win_relative_raw:   float
    p_win_relative_smoothed: float

    # ── "Profit" win: return > 0 ────────────────────────────────────
    n_wins_profit:        int
    p_win_profit_raw:     float
    p_win_profit_smoothed: float

    # ── "Meaningful" win: return > +1% ──────────────────────────────
    n_wins_meaningful:    int
    p_win_meaningful_raw: float
    p_win_meaningful_smoothed: float

    # Diagnostic fields (same prior used for all three thresholds).
    prior_alpha_relative:    float
    prior_beta_relative:     float
    prior_alpha_profit:      float
    prior_beta_profit:       float
    prior_alpha_meaningful:  float
    prior_beta_meaningful:   float


# ══════════════════════════════════════════════════════════════════════════════
# Universe-wide CONT model
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class ContModelMetadata:
    """Coefficients + diagnostics for one trained CONT model.

    Two label flavours are supported (``label_kind``):

      - ``"median_hold"``: positive iff the ride continues for ≥
        the symbol's own historical median ride-hold bars.
        Per-symbol horizon, varies. Originally specified by the
        operator; tends to give a label whose meaning depends
        on each symbol's volatility profile.
      - ``"fixed_horizon"``: positive iff the ride continues for ≥
        a constant N bars (``horizon_value``). Uniform meaning
        across the universe; the operator can compare AUROC
        against the median version to see which label has more
        signal.

    The model is a logistic regression on a fixed feature set
    extracted at every CONT-bar firing. Trained universe-wide
    (single model, all symbols pooled) on a per-symbol
    walk-forward 70/30 split.

    Coefficients are documented for inspection / re-use. The
    saved JSON is self-contained — no pickle / sklearn
    dependency required to load and predict.
    """

    label_kind:      str            # "median_hold" or "fixed_horizon"
    horizon_value:   int            # for "fixed_horizon"; 0 for "median_hold"
    feature_names:   tuple[str, ...]
    coefficients:    tuple[float, ...]
    intercept:       float
    n_train:         int
    n_test:          int
    train_accuracy:  float
    test_accuracy:   float
    train_auroc:     float
    test_auroc:      float
    test_brier:      float    # calibration metric; lower is better
    train_pos_rate:  float    # fraction of train labels = 1
    test_pos_rate:   float    # fraction of test labels = 1
    feature_means:   tuple[float, ...]    # for standardisation at predict-time
    feature_stds:    tuple[float, ...]
    universe_p_win_init:    float
    universe_p_win_retest:  float
    universe_p_win_cont:    float


# ══════════════════════════════════════════════════════════════════════════════
# Per-symbol final score for the latest fire
# ══════════════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class LatestFireScore:
    """The headline output for one symbol — what the operator
    would consult before acting on a current fire.

    For INIT/RETEST: each ``p_win_*`` is the Beta-smoothed
    historical rate from :class:`PhaseWinRateStats` under the
    corresponding win definition.

    For CONT: ``p_win_cont_model_median`` and
    ``p_win_cont_model_fixed`` are the two CONT models' outputs
    applied to this bar's features. The historical relative /
    profit / meaningful rates are also surfaced for context —
    sometimes a symbol's own CONT history diverges from the
    universe model, which is itself information.

    Stack column ``conviction_score`` carries the live-app's
    composite score (post-extension/liquidity penalties) at the
    same bar, so the operator can sort the same table by either
    p_win or conviction or a combination.
    """

    symbol:              str
    latest_phase:        str | None    # None when no active fire
    latest_trigger_date: str | None
    n_historical:        int             # sample size used for raw p_win
    avg_historical_return_pct: float | None
    median_hold_bars:    int | None

    # ── INIT/RETEST: three Beta-smoothed historical rates ──────────
    p_win_relative:    float | None    # vs symbol's own mean
    p_win_profit:      float | None    # > 0
    p_win_meaningful:  float | None    # > +1%

    # ── CONT: two model outputs ────────────────────────────────────
    p_win_cont_model_median: float | None    # ≥ symbol's median hold
    p_win_cont_model_fixed:  float | None    # ≥ FIXED_HORIZON_BARS

    # ── Stack: live conviction score at the same bar ───────────────
    conviction_score:  float | None

    notes:               str = ""    # diagnostic text
