"""Research: does cross-industry correlation predict forward returns?

Hypothesis: when industries are highly correlated to each other
(top quintile of historical correlation), the market is in a risk-
off / contagion regime — everyone moves together. Forward returns
should be below baseline. When correlation is low (bottom quintile),
the cross-section is dispersing — a rotational environment, where
forward returns may be above baseline (or at least less directional).

Background: this is the academic correlation-as-fear-gauge thesis,
adapted to NSE industries. Different mechanism from rank rotation:
that asked "do climbing industries outperform?" (mostly subsumed
by composite). This asks "what regime is the cross-section in?"
— a macro-coherent signal closer in spirit to VIX than to ROC.

Methodology:
  1. For each industry, build EW return series.
  2. At each bar, compute mean off-diagonal pairwise correlation
     of the last 60 trading days of industry returns (one scalar
     per bar).
  3. Classify bar by percentile rank of correlation against
     trailing 252-day history:
       HIGH_CORR:  top 20% (≥80th pctile)
       LOW_CORR:   bottom 20% (≤20th pctile)
       NORMAL:     20-80th
  4. For each (regime, fold): pool member-symbol fwd_10d returns
     across symbols in that regime's bars; measure lift vs. all-
     bar baseline within the fold.
  5. Walk-forward, 4 folds, 10-bar purge.

Ship rule (decided BEFORE seeing results):
  Cell ships if sign agrees in ≥3/4 folds AND |mean test lift| ≥ 0.5pp.

Output: scripts/output/correlation_regime_validation.txt
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

# Make project root importable
_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import numpy as np
import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.data.cache import ParquetCache
from nimbus_v3.data.enriched_cache import EnrichedPanelCache
from nimbus_v3.data.industry_db import load_industry_db
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import add_forward_returns

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("correlation_regime")


_EQ_CACHE_DIR: Path = _ROOT / "data" / "cache" / "enriched"
_OUT_PATH: Path = _ROOT / "scripts" / "output" / "correlation_regime_validation.txt"


# ══════════════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════════════

#: Window for computing pairwise correlation. 60 days = ~3 months.
#: Long enough for stability; short enough to capture regime shifts.
_CORR_WINDOW: int = 60

#: Window for percentile-rank-based regime classification. 252 days
#: = ~1 year. Each bar's correlation is ranked against the prior
#: year's distribution so the threshold adapts to regime changes
#: rather than being fixed in absolute correlation units.
_PCTILE_WINDOW: int = 252

#: Top / bottom quintiles for regime classification.
_HIGH_PCTILE: float = 0.80
_LOW_PCTILE: float = 0.20

#: Three regimes we stratify forward returns by.
_REGIMES: tuple[str, ...] = ("HIGH_CORR", "NORMAL", "LOW_CORR")

#: Walk-forward folds + purge — same as rank rotation research.
_N_FOLDS: int = 4
_PURGE_BARS: int = 10

#: Cosmetic: divider widths.
_DIV_WIDE: str = "═" * 78
_DIV_THIN: str = "─" * 78

#: Ship criteria (locked in before running).
_SHIP_FOLD_AGREEMENT_THRESHOLD: float = 0.75    # ≥3/4 folds
_SHIP_MIN_LIFT_PP: float = 0.5

#: Minimum industries needed for a meaningful correlation matrix.
#: Below this we can't compute a robust mean pairwise correlation.
_MIN_INDUSTRIES: int = 10


# ══════════════════════════════════════════════════════════════════════
# Equity-only data prep — same pattern as rank rotation script
# ══════════════════════════════════════════════════════════════════════

def _prepare_equity_only() -> dict:
    """Equity-only data prep — skips VIX. Reuses the enriched cache."""
    log.info("Loading equity panel...")
    raw_panel = load_equity_panel(years=5, min_bars=250, verbose=False)
    log.info("Equity panel: %d symbols", len(raw_panel))
    if not raw_panel:
        raise RuntimeError("Equity panel empty — no cached data available")

    log.info("Enriching (cache-first)...")
    enrichment_cache = EnrichedPanelCache(
        raw_cache=ParquetCache(base_dir=_EQ_CACHE_DIR),
        schema_hash=StrategyComputeEngine.enrichment_schema_hash(),
    )
    compute = StrategyComputeEngine()
    enriched_panel: dict[str, pd.DataFrame] = {}
    hits = misses = 0
    for sym, df in raw_panel.items():
        hit = enrichment_cache.get_if_fresh(sym)
        if hit is not None:
            enriched_panel[sym] = hit
            hits += 1
        else:
            try:
                out = compute.enrich(df, sym)
                enriched_panel[sym] = out
                enrichment_cache.set(sym, out)
                misses += 1
            except Exception:    # noqa: BLE001
                pass
    log.info("Enriched panel: %d symbols (cache: %d hits, %d misses)",
             len(enriched_panel), hits, misses)

    log.info("Attaching forward returns...")
    panel_w_fwd: dict[str, pd.DataFrame] = {}
    for sym, df in enriched_panel.items():
        panel_w_fwd[sym] = add_forward_returns(df)

    log.info("Loading industry DB...")
    ind_db = load_industry_db()
    industry_map: dict[str, str] = {
        sym: rec.industry for sym, rec in ind_db.items()
    }
    log.info("Industry map: %d symbols across %d industries",
             len(industry_map), len(set(industry_map.values())))

    return {"panel_w_fwd": panel_w_fwd, "industry_map": industry_map}


# ══════════════════════════════════════════════════════════════════════
# Build industry return series
# ══════════════════════════════════════════════════════════════════════

def _build_industry_returns(
    panel_w_fwd: dict[str, pd.DataFrame],
    industry_map: dict[str, str],
) -> pd.DataFrame:
    """Equal-weighted daily return series per industry. Returns a
    wide DataFrame: index=dates, columns=industries.

    Industries with <3 members are dropped (too thin to form a
    meaningful EW return).
    """
    ind_to_syms: dict[str, list[str]] = {}
    for sym, ind in industry_map.items():
        if sym in panel_w_fwd:
            ind_to_syms.setdefault(ind, []).append(sym)

    series_dict: dict[str, pd.Series] = {}
    for ind, members in ind_to_syms.items():
        if len(members) < 3:
            continue
        close_df = pd.DataFrame({
            sym: panel_w_fwd[sym]["Close"]
            for sym in members
            if "Close" in panel_w_fwd[sym].columns
        })
        if close_df.empty:
            continue
        ew_ret = close_df.pct_change().mean(axis=1)
        series_dict[ind] = ew_ret

    out = pd.DataFrame(series_dict)
    log.info("Built return series for %d industries", out.shape[1])
    return out


# ══════════════════════════════════════════════════════════════════════
# Mean pairwise correlation over rolling windows
# ══════════════════════════════════════════════════════════════════════

def _mean_pairwise_correlation_series(
    industry_returns: pd.DataFrame,
    window: int = _CORR_WINDOW,
) -> pd.Series:
    """At each bar, compute the mean of the off-diagonal cells of
    the rolling-window correlation matrix across all industries.

    Returns: pd.Series indexed by date.

    Implementation: rolling correlation matrix at each bar would be
    O(N^2 * T * W) which is feasible for N=50, T=1500, W=60 (~225M
    ops). We compute it explicitly to avoid pandas API quirks
    around 3-D rolling.
    """
    industry_returns = industry_returns.dropna(how="all")
    n_industries = industry_returns.shape[1]
    if n_industries < _MIN_INDUSTRIES:
        raise RuntimeError(
            f"Only {n_industries} industries; need ≥{_MIN_INDUSTRIES}",
        )

    log.info("Computing mean pairwise correlation (window=%d)...", window)
    out = pd.Series(np.nan, index=industry_returns.index, dtype=float)

    # Convert to numpy for speed
    arr = industry_returns.values    # shape (T, N)
    T, N = arr.shape

    for t in range(window - 1, T):
        block = arr[t - window + 1:t + 1, :]    # shape (window, N)
        # Mask columns with too many NaN in this window
        valid_mask = ~np.isnan(block).any(axis=0)
        if valid_mask.sum() < _MIN_INDUSTRIES:
            continue
        valid_block = block[:, valid_mask]
        # Pearson correlation matrix
        corr_matrix = np.corrcoef(valid_block, rowvar=False)
        # Mean of off-diagonal (k=1 strict upper triangle = unique pairs)
        n_valid = valid_block.shape[1]
        iu = np.triu_indices(n_valid, k=1)
        if iu[0].size == 0:
            continue
        out.iloc[t] = float(np.nanmean(corr_matrix[iu]))

    log.info("Correlation series: %d non-null bars", out.notna().sum())
    return out


# ══════════════════════════════════════════════════════════════════════
# Regime classification: percentile-rank against trailing window
# ══════════════════════════════════════════════════════════════════════

def _classify_regimes(
    corr_series: pd.Series,
    pctile_window: int = _PCTILE_WINDOW,
    high_pctile: float = _HIGH_PCTILE,
    low_pctile: float = _LOW_PCTILE,
) -> pd.Series:
    """Classify each bar as HIGH_CORR / LOW_CORR / NORMAL based on
    where its correlation value falls in the trailing
    pctile_window distribution.

    Bars before pctile_window are NaN.
    """
    out = pd.Series("NORMAL", index=corr_series.index, dtype=object)
    rolling_pctile = corr_series.rolling(pctile_window, min_periods=pctile_window).rank(pct=True)
    out[rolling_pctile >= high_pctile] = "HIGH_CORR"
    out[rolling_pctile <= low_pctile] = "LOW_CORR"
    out[rolling_pctile.isna()] = pd.NA
    return out


# ══════════════════════════════════════════════════════════════════════
# Forward-return aggregation per (regime, fold)
# ══════════════════════════════════════════════════════════════════════

def _aggregate_regime_lift(
    panel_w_fwd: dict[str, pd.DataFrame],
    regime_series: pd.Series,
    date_start: pd.Timestamp,
    date_end: pd.Timestamp,
) -> tuple[dict[str, dict], float]:
    """For each regime, pool member-symbol fwd_10d returns across
    symbols on bars classified as that regime in [date_start, date_end].

    Returns:
      regime_stats: {regime: {n_obs, mean_pp, lift_pp}}
      universe_baseline_pp: mean fwd_10d across the entire pooled
        sample in this date range
    """
    # Date-bound regime series
    in_range = (regime_series.index >= date_start) & (regime_series.index <= date_end)
    regime_window = regime_series.loc[in_range]

    by_regime: dict[str, list[float]] = {r: [] for r in _REGIMES}
    all_returns: list[float] = []

    for sym, df in panel_w_fwd.items():
        if "fwd_ret_10d" not in df.columns:
            continue
        # Align symbol's fwd return series with the regime classification
        aligned = df["fwd_ret_10d"].reindex(regime_window.index)
        for date, fwd in aligned.items():
            if pd.isna(fwd):
                continue
            regime = regime_window.loc[date]
            if pd.isna(regime) or regime not in by_regime:
                continue
            fwd_pp = float(fwd) * 100
            by_regime[regime].append(fwd_pp)
            all_returns.append(fwd_pp)

    universe_baseline = (
        float(np.mean(all_returns)) if all_returns else 0.0
    )

    regime_stats: dict[str, dict] = {}
    for regime in _REGIMES:
        obs = by_regime[regime]
        if not obs:
            regime_stats[regime] = {
                "n_obs": 0, "mean_pp": 0.0, "lift_pp": 0.0,
            }
            continue
        mean_pp = float(np.mean(obs))
        regime_stats[regime] = {
            "n_obs":   len(obs),
            "mean_pp": mean_pp,
            "lift_pp": mean_pp - universe_baseline,
        }

    return regime_stats, universe_baseline


# ══════════════════════════════════════════════════════════════════════
# Walk-forward folds — match rank rotation style
# ══════════════════════════════════════════════════════════════════════

def _make_expanding_folds(
    dates: pd.DatetimeIndex, n_folds: int,
) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    """Same logic as rank rotation script. Total range split into
    (n+1) chunks; fold i trains on first (i+1), tests on chunk
    (i+2). Train_end → test_start gap is _PURGE_BARS days."""
    start = dates.min()
    end = dates.max()
    total = end - start
    chunk = total / (n_folds + 1)

    folds: list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]] = []
    for i in range(n_folds):
        train_end = start + chunk * (i + 1)
        test_start = train_end + pd.Timedelta(days=_PURGE_BARS)
        test_end = start + chunk * (i + 2)
        folds.append((train_end, test_start, test_end))
    return folds


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main() -> None:
    _OUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    log.info("Preparing data (equity-only)...")
    try:
        prepared = _prepare_equity_only()
    except RuntimeError as exc:
        log.error("%s", exc)
        return

    panel_w_fwd = prepared["panel_w_fwd"]
    industry_map = prepared["industry_map"]

    industry_returns = _build_industry_returns(panel_w_fwd, industry_map)
    corr_series = _mean_pairwise_correlation_series(industry_returns)
    regime_series = _classify_regimes(corr_series)

    valid_dates = regime_series.dropna().index
    folds = _make_expanding_folds(valid_dates, _N_FOLDS)

    with _OUT_PATH.open("w") as f:
        def emit(s: str = "") -> None:
            print(s, file=f)

        emit("CORRELATION REGIME — WALK-FORWARD VALIDATION")
        emit(_DIV_WIDE)
        emit("Hypothesis: cross-industry correlation acts as a")
        emit("market-state indicator. HIGH_CORR (top quintile)")
        emit("regimes signal contagion / risk-off; LOW_CORR (bottom")
        emit("quintile) regimes signal rotational environment.")
        emit("Forward returns should differ systematically.")
        emit("")
        emit(f"Validation: expanding-window walk-forward, {_N_FOLDS} folds, "
             f"purged ±{_PURGE_BARS} bars at boundary")
        emit(f"Ship rule: ≥{_SHIP_FOLD_AGREEMENT_THRESHOLD:.0%} fold sign-agreement "
             f"AND |mean test-fold lift| ≥ {_SHIP_MIN_LIFT_PP}pp")
        emit("")
        emit(f"Industry returns: {industry_returns.shape[1]} industries × "
             f"{industry_returns.shape[0]} bars")
        emit(f"Correlation window: {_CORR_WINDOW}d")
        emit(f"Percentile-rank window: {_PCTILE_WINDOW}d")
        emit(f"Regime thresholds: HIGH ≥ {_HIGH_PCTILE:.0%}, "
             f"LOW ≤ {_LOW_PCTILE:.0%}")
        emit("")
        emit(f"Bars classified: {len(valid_dates)} "
             f"({valid_dates.min().date()} → {valid_dates.max().date()})")
        emit("Regime distribution (full sample):")
        for regime in _REGIMES:
            n = (regime_series == regime).sum()
            pct = n / len(valid_dates) * 100 if len(valid_dates) else 0.0
            emit(f"  {regime:<10} {n:>5} bars ({pct:.1f}%)")
        emit("")

        # Diagnostic: percentile range of correlation values per regime
        for regime in _REGIMES:
            mask = (regime_series == regime)
            if not mask.any():
                continue
            corr_in_regime = corr_series[mask]
            emit(f"  {regime} correlation range: "
                 f"[{corr_in_regime.min():.3f}, {corr_in_regime.max():.3f}], "
                 f"median {corr_in_regime.median():.3f}")
        emit("")

        emit("Fold boundaries:")
        for i, (train_end, test_start, test_end) in enumerate(folds):
            emit(f"  Fold {i + 1}: train → {train_end.date()}, "
                 f"test {test_start.date()} → {test_end.date()}")
        emit("")

        # Run all folds
        fold_results: list[dict] = []
        for fi, (train_end, test_start, test_end) in enumerate(folds):
            train_start = regime_series.index.min()
            train_stats, train_baseline = _aggregate_regime_lift(
                panel_w_fwd, regime_series, train_start, train_end,
            )
            test_stats, test_baseline = _aggregate_regime_lift(
                panel_w_fwd, regime_series, test_start, test_end,
            )
            fold_results.append({
                "train_stats":    train_stats,
                "train_baseline": train_baseline,
                "test_stats":     test_stats,
                "test_baseline":  test_baseline,
            })

            emit(_DIV_WIDE)
            emit(f"FOLD {fi + 1}: train → {train_end.date()} | "
                 f"test {test_start.date()} → {test_end.date()}")
            emit(_DIV_WIDE)
            emit(f"  Train baseline: {train_baseline:+.2f}pp  |  "
                 f"Test baseline: {test_baseline:+.2f}pp")
            emit("")
            emit(f"  {'REGIME':<10} {'TRAIN_LIFT':>11} {'TRAIN_N':>9}  "
                 f"{'TEST_LIFT':>11} {'TEST_N':>9}  SIGN")
            for regime in _REGIMES:
                tr = train_stats[regime]
                te = test_stats[regime]
                sign = "—"
                if tr["n_obs"] and te["n_obs"]:
                    if (tr["lift_pp"] >= 0) == (te["lift_pp"] >= 0):
                        sign = "✓"
                    else:
                        sign = "✗"
                emit(f"  {regime:<10} "
                     f"{tr['lift_pp']:>+10.2f}pp {tr['n_obs']:>9d}  "
                     f"{te['lift_pp']:>+10.2f}pp {te['n_obs']:>9d}  {sign}")
            emit("")

        # Aggregate verdict per regime
        verdict: dict[str, dict] = {}
        for regime in _REGIMES:
            test_lifts = [
                f["test_stats"][regime]["lift_pp"] for f in fold_results
            ]
            test_n = [
                f["test_stats"][regime]["n_obs"] for f in fold_results
            ]
            valid = [(li, n) for li, n in zip(test_lifts, test_n) if n >= 50]
            if not valid:
                verdict[regime] = {
                    "agreement":         0.0,
                    "mean_test_lift_pp": 0.0,
                    "ship":              False,
                    "ship_reason":       "no folds with n ≥ 50",
                }
                continue
            lifts_only = [v[0] for v in valid]
            mean_lift = float(np.mean(lifts_only))
            same_sign = sum(
                1 for li in lifts_only
                if (li >= 0) == (mean_lift >= 0)
            )
            agreement = same_sign / len(lifts_only)
            sign_agree = agreement >= _SHIP_FOLD_AGREEMENT_THRESHOLD
            big_enough = abs(mean_lift) >= _SHIP_MIN_LIFT_PP
            ship = sign_agree and big_enough
            verdict[regime] = {
                "agreement":         agreement,
                "mean_test_lift_pp": mean_lift,
                "ship":              ship,
                "ship_reason": (
                    "" if ship else
                    f"agreement {agreement:.0%}, lift {mean_lift:+.2f}pp"
                ),
            }

        # Final summary
        emit(_DIV_WIDE)
        emit("FINAL SUMMARY — SHIP/NO-SHIP MATRIX")
        emit(_DIV_WIDE)
        emit(f"  {'REGIME':<10} | {'AGREE':>6} | {'LIFT':>8} | SHIP")
        emit(_DIV_THIN)
        any_ship = False
        for regime in _REGIMES:
            v = verdict[regime]
            ship_str = "YES" if v["ship"] else "—"
            if v["ship"]:
                any_ship = True
            agreement_pct = f"{v['agreement'] * 100:.0f}%"
            emit(f"  {regime:<10} | {agreement_pct:>6} | "
                 f"{v['mean_test_lift_pp']:>+7.2f}pp | {ship_str}")
        emit("")

        emit(_DIV_WIDE)
        if any_ship:
            emit("VERDICT: SHIP candidate cells exist")
            emit("Recommendation: surface as a CORR regime badge in")
            emit("Market Pulse header alongside VIX. Three states:")
            emit("CORR: HIGH / NORMAL / LOW. Validated cells inform")
            emit("the operator about cross-sectional dispersion.")
        else:
            emit("VERDICT: DO NOT SHIP")
            emit("No regime cleared the ship criteria")
            emit(f"  (≥{_SHIP_FOLD_AGREEMENT_THRESHOLD:.0%} sign agreement AND "
                 f"|lift| ≥ {_SHIP_MIN_LIFT_PP}pp).")
            emit("")
            emit("Cross-industry correlation may correlate with regime")
            emit("but the lift in forward returns is too small or")
            emit("unstable across time periods to ship.")
        emit(_DIV_WIDE)

    log.info("Wrote: %s", _OUT_PATH)


if __name__ == "__main__":
    main()
