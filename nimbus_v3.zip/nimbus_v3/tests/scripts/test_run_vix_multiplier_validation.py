"""Tests for scripts/run_vix_multiplier_validation.py primitives."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(_ROOT / "scripts"))

from run_vix_multiplier_validation import (                         # noqa: E402
    _MIN_CELL_N,
    _FLIP_NOISE_THRESHOLD_PP,
    _derive_multipliers,
    _find_sign_flips,
    _test_correlation,
)


# ══════════════════════════════════════════════════════════════════════
# _derive_multipliers
# ══════════════════════════════════════════════════════════════════════

class TestDeriveMultipliers:

    def _lift_frame(self, rows):
        return pd.DataFrame(rows, columns=["tag", "regime", "n_cell",
                                            "lift_pp", "t_lift"])

    def test_formula_with_k_half_clamp_wide(self):
        """m = 1 + 0.5 * lift_pp, clamp [0.5, 1.5]. A +0.6pp lift
        with sufficient n should produce m = 1.30."""
        lifts = self._lift_frame([
            {"tag": "FOO", "regime": "STABLE", "n_cell": 500,
             "lift_pp": 0.6, "t_lift": 5.0},
        ])
        out = _derive_multipliers(lifts, k=0.5, clamp_lo=0.5, clamp_hi=1.5)
        assert len(out) == 1
        assert out.iloc[0]["multiplier"] == pytest.approx(1.30)

    def test_clamp_applies_above_upper(self):
        """A +2.0pp lift at k=1.0 gives raw m=3.0 → clamped to 1.5."""
        lifts = self._lift_frame([
            {"tag": "FOO", "regime": "STABLE", "n_cell": 500,
             "lift_pp": 2.0, "t_lift": 5.0},
        ])
        out = _derive_multipliers(lifts, k=1.0, clamp_lo=0.5, clamp_hi=1.5)
        assert out.iloc[0]["multiplier"] == 1.5

    def test_clamp_applies_below_lower(self):
        """A -2.0pp lift at k=1.0 gives raw m=-1.0 → clamped to 0.5."""
        lifts = self._lift_frame([
            {"tag": "FOO", "regime": "STABLE", "n_cell": 500,
             "lift_pp": -2.0, "t_lift": -5.0},
        ])
        out = _derive_multipliers(lifts, k=1.0, clamp_lo=0.5, clamp_hi=1.5)
        assert out.iloc[0]["multiplier"] == 0.5

    def test_underpowered_cell_forces_m_equals_one(self):
        """n_cell < _MIN_CELL_N → multiplier = 1.0 regardless of lift."""
        lifts = self._lift_frame([
            {"tag": "FOO", "regime": "STABLE", "n_cell": _MIN_CELL_N - 1,
             "lift_pp": 0.8, "t_lift": 2.0},
        ])
        out = _derive_multipliers(lifts, k=0.5, clamp_lo=0.5, clamp_hi=1.5)
        assert out.iloc[0]["multiplier"] == 1.0

    def test_mix_of_powered_and_underpowered_rows(self):
        """Underpowered gets 1.0, powered gets the formula."""
        lifts = self._lift_frame([
            {"tag": "A", "regime": "STABLE", "n_cell": 500,
             "lift_pp": 0.6, "t_lift": 5.0},
            {"tag": "B", "regime": "STABLE", "n_cell": 50,
             "lift_pp": 0.6, "t_lift": 1.0},
        ])
        out = _derive_multipliers(lifts, k=0.5, clamp_lo=0.5, clamp_hi=1.5)
        mul_a = out[out["tag"] == "A"].iloc[0]["multiplier"]
        mul_b = out[out["tag"] == "B"].iloc[0]["multiplier"]
        assert mul_a == pytest.approx(1.30)
        assert mul_b == 1.0


# ══════════════════════════════════════════════════════════════════════
# _find_sign_flips
# ══════════════════════════════════════════════════════════════════════

class TestFindSignFlips:

    def _pair(self, train_lift, test_lift, tag="FOO", regime="STABLE",
              n_train=500, n_test=400):
        train = pd.DataFrame([{
            "tag": tag, "regime": regime, "n_cell": n_train,
            "lift_pp": train_lift, "t_lift": 3.0,
            "mean_pp": train_lift + 1.0, "baseline_pp": 1.0,
            "n_baseline": n_train * 2,
        }])
        test = pd.DataFrame([{
            "tag": tag, "regime": regime, "n_cell": n_test,
            "lift_pp": test_lift, "t_lift": 3.0,
            "mean_pp": test_lift + 1.0, "baseline_pp": 1.0,
            "n_baseline": n_test * 2,
        }])
        return train, test

    def test_clear_flip_above_threshold_detected(self):
        """train +0.5pp vs test -0.5pp: both above noise threshold,
        signs differ. Should be flagged."""
        train, test = self._pair(+0.5, -0.5)
        flips = _find_sign_flips(train, test)
        assert len(flips) == 1
        assert flips[0]["tag"] == "FOO"

    def test_same_sign_not_flagged(self):
        """train +0.5pp, test +0.3pp: same sign, no flip."""
        train, test = self._pair(+0.5, +0.3)
        flips = _find_sign_flips(train, test)
        assert len(flips) == 0

    def test_tiny_flip_below_noise_ignored(self):
        """train +0.05pp → test -0.05pp: signs differ but both under
        the 0.3pp noise threshold. Not a flip — just noise near zero."""
        train, test = self._pair(+0.05, -0.05)
        flips = _find_sign_flips(train, test)
        assert len(flips) == 0

    def test_asymmetric_flip_detected_when_one_side_large(self):
        """train +0.8pp → test -0.1pp: signs differ, one side well above
        noise floor. Should be flagged (one leg is a real finding)."""
        train, test = self._pair(+0.8, -0.1)
        flips = _find_sign_flips(train, test)
        assert len(flips) == 1

    def test_nan_rows_skipped(self):
        """If either side is NaN, skip (not a flip)."""
        train, test = self._pair(np.nan, -0.5)
        flips = _find_sign_flips(train, test)
        assert len(flips) == 0


# ══════════════════════════════════════════════════════════════════════
# _test_correlation
# ══════════════════════════════════════════════════════════════════════

class TestTestCorrelation:

    def _build_panel(
        self, n_bars: int, tag_fires_when_regime: str,
        positive_corr: bool,
    ) -> tuple[dict, pd.Series]:
        """Build a fake tagged panel + regime series where the tag's
        behavior is controllable for correlation testing."""
        rng = np.random.default_rng(42)
        idx = pd.bdate_range("2020-01-01", periods=n_bars)

        # Regime series: alternating blocks of STABLE / RISING / FALLING
        regime_seq = []
        for i in range(n_bars):
            if i % 30 < 10:
                regime_seq.append("RISING")
            elif i % 30 < 20:
                regime_seq.append("STABLE")
            else:
                regime_seq.append("FALLING")
        regime_series = pd.Series(regime_seq, index=idx)

        # Tagged panel: 10 symbols, alpha fires when regime matches
        panel = {}
        for sym_i in range(10):
            sym = f"SYM{sym_i}"
            is_alpha = (regime_series == tag_fires_when_regime).values
            # If positive_corr=True, fwd_ret is higher when alpha fires
            # If positive_corr=False, fwd_ret is unrelated
            if positive_corr:
                fwd = np.where(is_alpha,
                               rng.normal(0.02, 0.01, n_bars),
                               rng.normal(0.00, 0.01, n_bars))
            else:
                fwd = rng.normal(0.01, 0.01, n_bars)
            panel[sym] = pd.DataFrame({
                "fwd_ret_10d":          fwd,
                "is_alpha_leader":      is_alpha,
                "is_accumulating":      np.zeros(n_bars, dtype=bool),
                "is_alpha_fading":      np.zeros(n_bars, dtype=bool),
                "is_high_beta_rider":   np.zeros(n_bars, dtype=bool),
                "is_low_beta_quality":  np.zeros(n_bars, dtype=bool),
                "is_industry_declining":np.zeros(n_bars, dtype=bool),
            }, index=idx)
        return panel, regime_series

    def test_unit_multipliers_yield_zero_or_nan_correlation(self):
        """When all multipliers are 1.0, expected_lift is constant zero
        for every (sym, bar), so correlation is undefined / nan."""
        import warnings
        panel, regime = self._build_panel(
            400, tag_fires_when_regime="STABLE", positive_corr=True,
        )
        # Build multiplier table with m=1 everywhere
        rows = []
        for tag_display in ("ALPHA", "ACCUM", "FADE", "HIGHβ", "LOWβ", "IND↓"):
            for regime_val in ("RISING", "STABLE", "FALLING"):
                rows.append({
                    "tag": tag_display, "regime": regime_val,
                    "n_cell": 500, "lift_pp": 0.0,
                    "k": 0.5, "clamp_lo": 0.5, "clamp_hi": 1.5,
                    "multiplier": 1.0,
                })
        mults = pd.DataFrame(rows)
        # pandas.corr() on a zero-variance series triggers a numpy
        # divide-by-zero warning before returning NaN. That's exactly
        # the behavior we're verifying — suppress the warning so the
        # test passes on its assertion, not pytest's warning config.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            r, n = _test_correlation(
                panel, regime, mults,
                pd.Timestamp("2020-01-01"), pd.Timestamp("2025-01-01"),
            )
        # Constant-zero expected_lift → correlation undefined (NaN) or 0
        assert np.isnan(r) or r == 0.0

    def test_positive_multiplier_on_aligned_tag_produces_positive_corr(self):
        """When ALPHA fires in STABLE and we give ALPHA/STABLE a large
        multiplier (>1), and fwd returns are actually higher in those
        cells, correlation should come out positive."""
        panel, regime = self._build_panel(
            400, tag_fires_when_regime="STABLE", positive_corr=True,
        )
        rows = []
        for tag_display in ("ALPHA", "ACCUM", "FADE", "HIGHβ", "LOWβ", "IND↓"):
            for regime_val in ("RISING", "STABLE", "FALLING"):
                if tag_display == "ALPHA" and regime_val == "STABLE":
                    m = 1.5   # boost
                else:
                    m = 1.0
                rows.append({
                    "tag": tag_display, "regime": regime_val,
                    "n_cell": 500, "lift_pp": 0.0,
                    "k": 0.5, "clamp_lo": 0.5, "clamp_hi": 1.5,
                    "multiplier": m,
                })
        mults = pd.DataFrame(rows)
        r, n = _test_correlation(
            panel, regime, mults,
            pd.Timestamp("2020-01-01"), pd.Timestamp("2025-01-01"),
        )
        assert n > 100
        assert r > 0    # expected_lift rises exactly when fwd_ret rises

    def test_empty_panel_returns_nan(self):
        """Empty input must return nan, not raise."""
        r, n = _test_correlation(
            {}, pd.Series(dtype=str), pd.DataFrame(),
            pd.Timestamp("2020-01-01"), pd.Timestamp("2025-01-01"),
        )
        assert np.isnan(r)
        assert n == 0
