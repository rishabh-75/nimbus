"""nimbus_v3.compute.vix_regime_industry_directions — per-industry
regime directional config.

Static config module. Values are observationally-derived from the
walk-forward validation script
``scripts/run_vix_component_industry_validation.py`` run on NSE
history from 2021-04 through 2026-04, using the 20d VIX slope
window.

The research found 11 industries with stable sign agreement across
≥ 2 regimes and ≥ 3 of 4 walk-forward folds:

  - Aerospace & Defense, Auto Components, Chemicals &
    Petrochemicals, Electrical Equipment, Fertilizers &
    Agrochemicals, IT - Services, Leisure Services, Power, Realty,
    Telecom - Services, Transport Services

All 11 show the same directional pattern: **UP in VIX RISING regime,
DOWN in VIX STABLE regime.** None had sufficient FALLING-regime data
to stabilize (most FALLING cells appeared in only 2 folds, a
pre-condition not strong enough to pass the 75% threshold).

Interpretation — the economic story these numbers tell:
  - When VIX is inflecting UP (fear building off a low base), these
    industries catch a bid. Cyclicals (Auto, Cement, Power, Realty)
    benefit from fear-driven rotation out of growth/tech. Defensives
    (Telecom, Pharma) catch flight-to-safety inflows. Heavy
    industrials (Aerospace & Defense, Electrical Equipment) catch
    capex/geopolitical premium.
  - When VIX is quietly STABLE, those same industries underperform
    their own unconditional baseline. No rotation driver, no flight
    premium.

Magnitudes (median per-symbol lift within industry, walk-forward
averaged):
  - RISING lifts range from +0.97 to +5.50 pp (fwd_10d log return)
  - STABLE lifts range from -0.28 to -0.90 pp

Consumers should treat these as **directional** flags for UI
rendering, not as numerical multipliers for conviction math. The
prior iteration of this research (``run_vix_multiplier_validation.py``)
showed that tag × regime numerical multipliers do NOT replicate
out-of-sample. Directions do.

# ══════════════════════════════════════════════════════════════════════
# Re-validation cadence
# ══════════════════════════════════════════════════════════════════════

Re-run ``scripts/run_vix_component_industry_validation.py`` every
6 months or after any major market regime shift. If the stable-11
list changes by more than 2-3 industries, update this module and
log the change in V3_VS_ORACLE_GAP_ANALYSIS.md.
"""
from __future__ import annotations

from typing import Final

from nimbus_v3.compute.vix_pace import (
    REGIME_FALLING, REGIME_RISING, REGIME_STABLE,
)


#: Direction label — industry outperforms its own unconditional mean
#: in this regime. UI renders as a green ↑ arrow or equivalent.
DIRECTION_UP: Final[str] = "UP"

#: Direction label — industry underperforms its own unconditional
#: mean in this regime. UI renders as a red ↓ arrow.
DIRECTION_DOWN: Final[str] = "DOWN"

#: Default — no stable directional signal for this (industry, regime)
#: cell. UI renders as neutral styling, no arrow. Returned for
#: industries not in the stable-11 list OR for regime cells that
#: didn't pass the stability threshold.
DIRECTION_NEUTRAL: Final[str] = "NEUTRAL"


#: The core config. Hard-coded from the 20d walk-forward validation
#: output. Each entry is ``(industry, regime): direction``.
#:
#: Only cells that passed the ≥75% walk-forward stability threshold
#: are included. All other (industry, regime) lookups return
#: DIRECTION_NEUTRAL via the public ``direction_for()`` function.
_STABLE_DIRECTIONS: Final[dict[tuple[str, str], str]] = {
    # Aerospace & Defense — +2.95/+5.50pp RISING, -0.71/-0.84pp STABLE
    ("Aerospace & Defense",           REGIME_RISING): DIRECTION_UP,
    ("Aerospace & Defense",           REGIME_STABLE): DIRECTION_DOWN,

    # Auto Components — +1.51/+3.05pp RISING, -0.28/-0.58pp STABLE
    ("Auto Components",               REGIME_RISING): DIRECTION_UP,
    ("Auto Components",               REGIME_STABLE): DIRECTION_DOWN,

    # Chemicals & Petrochemicals — +1.06/+2.17pp RISING, -0.73/-0.50pp STABLE
    ("Chemicals & Petrochemicals",    REGIME_RISING): DIRECTION_UP,
    ("Chemicals & Petrochemicals",    REGIME_STABLE): DIRECTION_DOWN,

    # Electrical Equipment — +1.85/+5.16pp RISING, -0.33/-0.90pp STABLE
    ("Electrical Equipment",          REGIME_RISING): DIRECTION_UP,
    ("Electrical Equipment",          REGIME_STABLE): DIRECTION_DOWN,

    # Fertilizers & Agrochemicals — +1.18/+3.16pp RISING, -0.51/-0.61pp STABLE
    ("Fertilizers & Agrochemicals",   REGIME_RISING): DIRECTION_UP,
    ("Fertilizers & Agrochemicals",   REGIME_STABLE): DIRECTION_DOWN,

    # IT - Services — +2.40/+3.30pp RISING, -0.51/-0.71pp STABLE
    ("IT - Services",                 REGIME_RISING): DIRECTION_UP,
    ("IT - Services",                 REGIME_STABLE): DIRECTION_DOWN,

    # Leisure Services — +1.47/+1.88pp RISING, -0.78/-0.36pp STABLE
    ("Leisure Services",              REGIME_RISING): DIRECTION_UP,
    ("Leisure Services",              REGIME_STABLE): DIRECTION_DOWN,

    # Power — +0.97/+2.83pp RISING, -0.67/-0.59pp STABLE
    ("Power",                         REGIME_RISING): DIRECTION_UP,
    ("Power",                         REGIME_STABLE): DIRECTION_DOWN,

    # Realty — +3.08/+4.82pp RISING, -0.50/-0.77pp STABLE
    ("Realty",                        REGIME_RISING): DIRECTION_UP,
    ("Realty",                        REGIME_STABLE): DIRECTION_DOWN,

    # Telecom - Services — +3.55/+2.32pp RISING, -0.54/-0.50pp STABLE
    ("Telecom - Services",            REGIME_RISING): DIRECTION_UP,
    ("Telecom - Services",            REGIME_STABLE): DIRECTION_DOWN,

    # Transport Services — +1.74/+3.29pp RISING, -0.64/-0.63pp STABLE
    ("Transport Services",            REGIME_RISING): DIRECTION_UP,
    ("Transport Services",            REGIME_STABLE): DIRECTION_DOWN,
}


#: The canonical list of stable industries, in alphabetical order.
#: Exposed for diagnostics and for UI filter lists.
STABLE_INDUSTRIES: Final[tuple[str, ...]] = tuple(sorted({
    industry for (industry, _regime) in _STABLE_DIRECTIONS
}))


def direction_for(industry: str, regime: str) -> str:
    """Look up the directional signal for an (industry, regime) cell.

    Args:
        industry: Industry name. Must match the exact string used in
            ``nifty500_industry_db.json`` — e.g. "Auto Components",
            "Telecom - Services" (note the spaces around the dash).
        regime: Regime label from ``vix_pace``. One of REGIME_RISING,
            REGIME_STABLE, REGIME_FALLING.

    Returns:
        One of DIRECTION_UP / DIRECTION_DOWN / DIRECTION_NEUTRAL.
        NEUTRAL is the fallback for industries not in the stable-11
        list, for regime cells that didn't pass validation, and for
        unknown regime inputs (e.g. "UNKNOWN" during baseline
        warmup).
    """
    return _STABLE_DIRECTIONS.get((industry, regime), DIRECTION_NEUTRAL)


def is_stable_industry(industry: str) -> bool:
    """True if the industry has at least one stable regime direction.
    Useful for UI to decide whether to render the regime-direction
    badge at all for a given industry."""
    return industry in STABLE_INDUSTRIES
