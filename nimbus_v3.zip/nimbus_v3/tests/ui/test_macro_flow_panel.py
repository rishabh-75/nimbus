"""Tests for MacroFlowPanel widget — population, filtering, error handling."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.macro.universe import COMMODITY_UNIVERSE, CommodityCategory
from nimbus_v3.ui.widgets.macro_flow_panel import MacroFlowPanel


def _ohlcv(closes: np.ndarray, start="2023-01-01") -> pd.DataFrame:
    idx = pd.bdate_range(start, periods=len(closes))
    return pd.DataFrame({
        "Open": closes, "High": closes * 1.005, "Low": closes * 0.995,
        "Close": closes, "Volume": 1e6,
    }, index=idx)


def _calm_panel(tickers: list[str], n: int = 600) -> dict:
    rng = np.random.default_rng(0)
    return {
        t: _ohlcv(100.0 * np.exp(np.cumsum(rng.normal(0.0003, 0.012, n))))
        for t in tickers
    }


# ══════════════════════════════════════════════════════════════════════════════
# Construction
# ══════════════════════════════════════════════════════════════════════════════

def test_panel_constructs_disabled_without_loader(qapp) -> None:    # noqa: ARG001
    p = MacroFlowPanel(None)
    # The refresh button was removed in favor of auto-loading on show.
    # The loader-present/absent state is now communicated through the
    # status label text.
    assert "no data" in p._status_label.text().lower()


def test_panel_constructs_enabled_with_loader(qapp) -> None:    # noqa: ARG001
    loader = lambda: _calm_panel(["GC=F"])
    p = MacroFlowPanel(loader)
    assert "ready" in p._status_label.text().lower()


# ══════════════════════════════════════════════════════════════════════════════
# Refresh
# ══════════════════════════════════════════════════════════════════════════════

def test_refresh_populates_table(qapp) -> None:    # noqa: ARG001
    tickers = ["GC=F", "SI=F", "CL=F"]
    loader = lambda: _calm_panel(tickers)
    p = MacroFlowPanel(loader)
    p.refresh()
    assert p._table.rowCount() == 3


def test_refresh_with_full_universe(qapp) -> None:    # noqa: ARG001
    """When all 23 instruments load, the table shows 23 rows."""
    tickers = [i.ticker for i in COMMODITY_UNIVERSE]
    loader = lambda: _calm_panel(tickers)
    p = MacroFlowPanel(loader)
    p.refresh()
    assert p._table.rowCount() == 23


def test_refresh_handles_empty_panel_gracefully(qapp) -> None:    # noqa: ARG001
    p = MacroFlowPanel(lambda: {})
    p.refresh()
    assert p._table.rowCount() == 0
    # Asof remains the placeholder dash.
    assert p._asof_label.text() == "—"


def test_refresh_handles_loader_exception(qapp) -> None:    # noqa: ARG001
    """Loader raising must surface error in status, not crash."""
    def bad_loader():
        raise RuntimeError("network unreachable")

    p = MacroFlowPanel(bad_loader)
    import nimbus_v3.ui.widgets.macro_flow_panel as mod
    captured = []
    orig = mod.QMessageBox.critical
    mod.QMessageBox.critical = lambda *a, **kw: captured.append((a, kw))
    try:
        p.refresh()
    finally:
        mod.QMessageBox.critical = orig
    assert "network unreachable" in p._status_label.text()
    assert len(captured) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Category filter
# ══════════════════════════════════════════════════════════════════════════════

def test_category_filter_narrows_table(qapp) -> None:    # noqa: ARG001
    tickers = ["GC=F", "SI=F", "CL=F", "BZ=F", "ZC=F"]
    loader = lambda: _calm_panel(tickers)
    p = MacroFlowPanel(loader)
    p.refresh()
    # Switch filter to PRECIOUS (gold + silver).
    p._on_filter_clicked(CommodityCategory.PRECIOUS)
    assert p._table.rowCount() == 2
    visible = {p._table.item(i, 0).text() for i in range(p._table.rowCount())}
    assert visible == {"GC=F", "SI=F"}


def test_category_filter_all_restores(qapp) -> None:    # noqa: ARG001
    tickers = ["GC=F", "CL=F", "ZC=F"]
    loader = lambda: _calm_panel(tickers)
    p = MacroFlowPanel(loader)
    p.refresh()
    p._on_filter_clicked(CommodityCategory.ENERGY)
    assert p._table.rowCount() == 1
    p._on_filter_clicked(None)    # ALL
    assert p._table.rowCount() == 3


# ══════════════════════════════════════════════════════════════════════════════
# Selection
# ══════════════════════════════════════════════════════════════════════════════

def test_row_selection_emits_signal(qapp) -> None:    # noqa: ARG001
    tickers = ["GC=F", "SI=F"]
    loader = lambda: _calm_panel(tickers)
    p = MacroFlowPanel(loader)
    p.refresh()

    captured = []
    p.instrument_selected.connect(captured.append)
    p._table.selectRow(0)
    qapp.processEvents()
    assert len(captured) == 1
    assert captured[0] in {"GC=F", "SI=F"}


# ══════════════════════════════════════════════════════════════════════════════
# Runtime loader swap
# ══════════════════════════════════════════════════════════════════════════════

def test_set_panel_loader_enables_disables(qapp) -> None:    # noqa: ARG001
    """The panel swaps loaders at runtime; after a swap the new loader
    should be callable via refresh() and populate the table. After
    setting the loader to None the table clears on next refresh."""
    p = MacroFlowPanel(None)
    # No loader, no data — status reflects that.
    assert "no data" in p._status_label.text().lower()

    p.set_panel_loader(lambda: _calm_panel(["GC=F"]))
    p.refresh()
    assert p._table.rowCount() == 1

    p.set_panel_loader(None)
    assert p._table.rowCount() == 0


# ══════════════════════════════════════════════════════════════════════════════
# Status text
# ══════════════════════════════════════════════════════════════════════════════

def test_status_reports_strong_signal_count(qapp) -> None:    # noqa: ARG001
    """The '|z| ≥ 2' count in the status line must be accurate."""
    tickers = ["GC=F", "SI=F", "CL=F"]
    panel = _calm_panel(tickers)
    # Engineer GC=F to be strongly stretched.
    df = panel["GC=F"]
    closes = df["Close"].copy()
    last = float(closes.iloc[-6])
    closes.iloc[-5:] = last * np.array([1.05, 1.10, 1.16, 1.22, 1.28])
    df["Close"] = closes

    p = MacroFlowPanel(lambda: panel)
    p.refresh()
    assert "|z| ≥ 2" in p._status_label.text()
