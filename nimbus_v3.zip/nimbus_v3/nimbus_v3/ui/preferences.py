"""nimbus_v3.ui.preferences — user-preference persistence.

Thin wrapper over :class:`PyQt6.QtCore.QSettings` that centralizes:

- The key strings (no string literals duplicated across modules).
- The fallback logic for missing / corrupt persisted values.
- Error handling (write failures log but don't raise).

Lives in ``nimbus_v3.ui`` because QSettings is a Qt dependency; the
``core`` layer stays Qt-free. Every module that needs to read or
write a user preference must go through this module.

Current preferences:

- ``strategy_mode``  — ``StrategyMode`` enum, persists the sidebar's
  active CONSERVATIVE/AGGRESSIVE toggle.

Adding a new preference:

1. Add a ``_KEY_*`` constant below.
2. Add a typed load/save pair (``load_xxx()`` / ``save_xxx(value)``).
3. Call from UI sites.

Never hand-write a QSettings key elsewhere.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from PyQt6.QtCore import QSettings

if TYPE_CHECKING:
    from nimbus_v3.core.types import StrategyMode


logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# Key strings — ALL QSettings key writes/reads route through these
# ══════════════════════════════════════════════════════════════════════════════

_KEY_STRATEGY_MODE = "strategy_mode"


# ══════════════════════════════════════════════════════════════════════════════
# Strategy mode
# ══════════════════════════════════════════════════════════════════════════════

def load_strategy_mode(default: "StrategyMode | None" = None) -> "StrategyMode":
    """Load the persisted strategy mode, falling back gracefully.

    Priority:
        1. Valid persisted value → return as StrategyMode.
        2. Missing persisted value → return ``default`` if provided,
           else ``StrategyMode.CONSERVATIVE``.
        3. Corrupt persisted value → log warning, return same fallback
           as (2). Does not raise.

    The ``default`` parameter lets callers customise the fallback
    (e.g., a test harness may want a different baseline), but in
    production main.py uses None → CONSERVATIVE.
    """
    from nimbus_v3.core.types import StrategyMode
    fallback = default if default is not None else StrategyMode.CONSERVATIVE
    stored = QSettings().value(_KEY_STRATEGY_MODE, "", type=str)
    if not stored:
        return fallback
    try:
        return StrategyMode(stored)
    except ValueError:
        logger.warning(
            "preferences: ignoring unknown persisted strategy_mode %r — "
            "using fallback %s",
            stored, fallback.value,
        )
        return fallback


def save_strategy_mode(mode: "StrategyMode") -> bool:
    """Persist the strategy mode across sessions.

    Returns True on success, False on write failure (logged with
    exception detail but never raised). Callers should treat failure
    as non-fatal — the in-session mode still applies even if the
    write fails.
    """
    try:
        QSettings().setValue(_KEY_STRATEGY_MODE, mode.value)
        return True
    except Exception:    # noqa: BLE001
        logger.exception(
            "preferences: failed to persist strategy_mode %r — "
            "runtime toggle still applies", mode.value,
        )
        return False
