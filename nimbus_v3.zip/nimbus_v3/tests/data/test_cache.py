"""Tests for nimbus_v3.data.cache.ParquetCache."""
from __future__ import annotations

import time
from datetime import timedelta
from pathlib import Path

import pandas as pd
import pytest

from nimbus_v3.data.cache import ParquetCache


@pytest.fixture
def cache(tmp_path: Path) -> ParquetCache:
    return ParquetCache(base_dir=tmp_path / "cache_root")


@pytest.fixture
def sample_df() -> pd.DataFrame:
    return pd.DataFrame(
        {"a": [1.0, 2.0, 3.0], "b": ["x", "y", "z"]},
        index=pd.bdate_range("2024-01-01", periods=3, name="dt"),
    )


def test_get_missing_key_returns_none(cache: ParquetCache) -> None:
    assert cache.get("nope") is None


def test_set_then_get_roundtrips(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    cache.set("reliance/daily", sample_df)
    recovered = cache.get("reliance/daily")
    assert recovered is not None
    pd.testing.assert_frame_equal(recovered, sample_df, check_freq=False)


def test_exists(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    assert cache.exists("foo") is False
    cache.set("foo", sample_df)
    assert cache.exists("foo") is True


def test_age_increases(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    assert cache.age("foo") is None
    cache.set("foo", sample_df)
    age_1 = cache.age("foo")
    assert age_1 is not None and age_1 >= timedelta()
    time.sleep(0.05)
    age_2 = cache.age("foo")
    assert age_2 is not None and age_2 > age_1


def test_overwrite_replaces_value(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    cache.set("k", sample_df)
    other = sample_df.copy()
    other["a"] = other["a"] * 10
    cache.set("k", other)
    recovered = cache.get("k")
    assert recovered is not None
    pd.testing.assert_frame_equal(recovered, other, check_freq=False)


def test_clear_all(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    for k in ("a", "b", "nested/c"):
        cache.set(k, sample_df)
    assert cache.clear() == 3
    assert cache.get("a") is None
    assert cache.get("nested/c") is None


def test_clear_prefix(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    cache.set("price/RELIANCE", sample_df)
    cache.set("price/TCS", sample_df)
    cache.set("options/RELIANCE", sample_df)
    removed = cache.clear(prefix="price/")
    assert removed == 2
    assert cache.get("price/RELIANCE") is None
    assert cache.get("price/TCS") is None
    assert cache.get("options/RELIANCE") is not None


def test_empty_key_rejected(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    with pytest.raises(ValueError):
        cache.set("", sample_df)


def test_traversal_escape_rejected(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    with pytest.raises(ValueError, match="outside base_dir"):
        cache.set("../evil", sample_df)


def test_nested_keys_create_subdirs(cache: ParquetCache, sample_df: pd.DataFrame) -> None:
    cache.set("sector/NIFTY_BANK/daily", sample_df)
    recovered = cache.get("sector/NIFTY_BANK/daily")
    assert recovered is not None
    pd.testing.assert_frame_equal(recovered, sample_df, check_freq=False)


def test_atomic_write_no_partial_file(
    cache: ParquetCache, sample_df: pd.DataFrame, monkeypatch, tmp_path
) -> None:
    """If ``to_parquet`` raises mid-write, the destination key must not
    exist afterward (atomic guarantee)."""
    # Land one successful write first so we have a known-good baseline.
    cache.set("k", sample_df)
    good = cache.get("k")

    # Now force the next write to fail.
    original_to_parquet = pd.DataFrame.to_parquet

    def exploding_to_parquet(self, *args, **kwargs):  # noqa: ANN001
        raise RuntimeError("disk on fire")

    monkeypatch.setattr(pd.DataFrame, "to_parquet", exploding_to_parquet)
    with pytest.raises(RuntimeError):
        cache.set("k", sample_df)

    # Restore for cleanup.
    monkeypatch.setattr(pd.DataFrame, "to_parquet", original_to_parquet)

    # Original value still intact — the failed write did not corrupt it.
    pd.testing.assert_frame_equal(cache.get("k"), good, check_freq=False)
