"""nimbus_v3.data.intraday_loader — secondary 4-hour OHLCV cache.

Purpose
───────
The primary pipeline is daily. This module maintains a SEPARATE, secondary
4-hour cache used for exactly one thing today: a confirmation flag on the
Edge tab telling the operator whether a name's body is above its upper
Bollinger band on the 4h timeframe as well as the daily one.

Why a separate cache
────────────────────
The daily enriched cache is namespaced by the enrichment schema hash, and
its freshness is decided by raw-daily mtimes. 4h bars are a different
frequency with a different vendor request and a different staleness
profile, so they get their own directory (``cache/equity_price_4h``) and
never touch the daily cache's mtimes. Nothing here can invalidate or
collide with the daily pipeline.

yfinance quirks
───────────────
- yfinance has no native ``4h`` interval. We request ``60m`` and resample
  to 4h buckets. NSE's 09:15–15:30 session yields ~2 four-hour bars/day,
  which is all a 20-period Bollinger on 4h needs (~a fortnight of history).
- yfinance caps 60m history (~730 days); irrelevant here — we keep a short
  window, enough for BB(20) plus headroom.

Partial-bar discipline (mirrors the daily guard)
────────────────────────────────────────────────
The daily loader drops today's still-forming session bar so a half-formed
candle never reaches the cache or the indicators. The same hazard exists
per-bucket intraday: the 4h bucket currently in progress has a real open
but an as-of-now high/low/close. :meth:`_drop_forming_bar` removes any
trailing bar whose bucket end-time has not yet passed, so the flag is
always computed on COMPLETED 4h candles.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Final

import pandas as pd

from nimbus_v3.data.base import CacheStore, coerce_ohlcv_columns

logger = logging.getLogger(__name__)

_IST: Final = timezone(timedelta(hours=5, minutes=30))

#: Resample target. pandas offset alias; 4 hours.
_RESAMPLE_RULE: Final = "4h"

#: yfinance interval actually requested (no native 4h).
_SOURCE_INTERVAL: Final = "60m"

#: Bollinger period the 4h flag uses (must match band_ride.body_above_on_frame).
_BB_PERIOD: Final = 20

#: Completed 4h buckets NSE produces per trading day. The 09:15–15:30
#: session spans the [08:00,12:00) and [12:00,16:00) buckets → 2.
_BARS_PER_SESSION: Final = 2

#: Spare bars beyond the band period, to absorb holidays and half-days
#: without letting the rolling band go NaN (which would fail-soft the flag
#: to False — a false negative). 6 bars ≈ 3 trading days of cushion.
_BAR_MARGIN: Final = 6

#: Days of 60m history to request — DERIVED, not padded. We need
#: ``_BB_PERIOD + _BAR_MARGIN`` completed 4h bars; at ``_BARS_PER_SESSION``
#: per trading day that is a whole number of trading days, converted to
#: calendar days (×7/5 for weekends) plus a small holiday cushion. This is
#: a rolling RECENT window — never a full-history fetch — sized to exactly
#: what the calculation consumes.
def _history_days_for(period: int = _BB_PERIOD) -> int:
    import math
    bars_needed = period + _BAR_MARGIN
    trading_days = math.ceil(bars_needed / _BARS_PER_SESSION)
    calendar_days = math.ceil(trading_days * 7 / 5)
    return calendar_days + 3          # holiday cushion


_HISTORY_DAYS: Final = _history_days_for()  # 20d BB → ~22 calendar days

#: Cache freshness. Intraday the flag should track the latest completed 4h
#: bucket, so refetch every ~2h during the session; when closed, the last
#: fetch of the day stands.
_TTL_OPEN: Final = timedelta(hours=2)


class IntradayLoader:
    """Loads and caches 4-hour OHLCV for a single NSE symbol.

    Deliberately shaped like :class:`PriceLoader`: an injected
    :class:`CacheStore`, a fetcher, a market-aware TTL, and fail-soft
    behaviour (an empty frame on any vendor problem, never an exception
    for data-availability issues). The one addition over the daily loader
    is :meth:`_drop_forming_bar`, since 4h buckets close intraday.
    """

    def __init__(
        self,
        cache: CacheStore,
        *,
        yf_suffix: str = ".NS",
        history_days: int = _HISTORY_DAYS,
        ttl_open: timedelta = _TTL_OPEN,
    ) -> None:
        self._cache = cache
        self._yf_suffix = yf_suffix
        self._history_days = history_days
        self._ttl_open = ttl_open

    # ── public ──────────────────────────────────────────────────────────
    def load(self, symbol: str, *, force_refresh: bool = False,
             cache_only: bool = False) -> pd.DataFrame:
        """Return cached-or-fetched 4h OHLCV for ``symbol``.

        Freshness policy, matching the daily loader's spirit:
          * ``cache_only`` → NEVER fetch; return the cached frame or empty.
            This is the GUI-thread path: reading the parquet cache is fast
            and can't block, whereas a vendor fetch could hang the window.
          * ``force_refresh``  → always fetch.
          * market OPEN        → refetch when the cache is older than the
                                 2h TTL (a new 4h bucket may have closed).
          * market CLOSED      → serve cache regardless of age; the last
                                 intraday fetch already holds the final
                                 completed bucket. Only a cache MISS falls
                                 through to a fetch.
        Empty frame on any failure — the caller treats that as "unknown".
        """
        from nimbus_v3.core.market_session import is_market_open

        if not symbol:
            raise ValueError("symbol must be non-empty")

        if cache_only:
            cached = self._cache.get(symbol)
            return cached if cached is not None else pd.DataFrame()

        if not force_refresh:
            cached = self._cache.get(symbol)
            if cached is not None and not cached.empty:
                if not is_market_open():
                    return cached
                if self._cache_fresh(symbol, self._ttl_open):
                    return cached

        fetched = self._fetch(symbol)
        if fetched.empty:
            cached = self._cache.get(symbol)
            if cached is not None:
                return cached
            return fetched

        self._cache.set(symbol, fetched)
        return fetched

    # ── internals ───────────────────────────────────────────────────────
    def _cache_fresh(self, symbol: str, ttl: timedelta) -> bool:
        try:
            age = self._cache.age(symbol)
        except Exception:            # noqa: BLE001
            return False
        return age is not None and age < ttl

    def _fetch(self, symbol: str) -> pd.DataFrame:
        """Fetch 60m from yfinance, resample to 4h, drop the forming bar."""
        try:
            import yfinance as yf
        except Exception:            # noqa: BLE001
            logger.warning("intraday_loader: yfinance unavailable")
            return pd.DataFrame()

        yf_symbol = f"{symbol}{self._yf_suffix}"
        today_ist = datetime.now(tz=_IST).date()
        start = today_ist - timedelta(days=self._history_days)
        end = today_ist + timedelta(days=1)
        try:
            raw = yf.download(
                tickers=yf_symbol,
                start=start.isoformat(),
                end=end.isoformat(),
                interval=_SOURCE_INTERVAL,
                auto_adjust=True,
                progress=False,
                threads=False,
            )
        except Exception as exc:     # noqa: BLE001
            logger.warning("intraday_loader: yfinance raised for %s: %s",
                           yf_symbol, exc)
            return pd.DataFrame()

        return self._drop_forming_bar(
            self.resample_to_4h(self._normalize(raw)))

    @staticmethod
    def _normalize(raw: pd.DataFrame) -> pd.DataFrame:
        """OHLCV contract on a tz-naive, ascending, deduped index."""
        if raw is None or raw.empty:
            return pd.DataFrame()
        df = coerce_ohlcv_columns(raw.copy())
        if getattr(df.index, "tz", None) is not None:
            # Intraday timestamps arrive tz-aware (often UTC). Convert to
            # IST FIRST so the 4h buckets align to the NSE trading day,
            # then drop tz for a naive, storable index.
            df.index = df.index.tz_convert(_IST).tz_localize(None)
        df = df.sort_index()
        df = df[~df.index.duplicated(keep="last")]
        price_cols = [c for c in ("Open", "High", "Low", "Close")
                      if c in df.columns]
        if price_cols:
            df = df.dropna(subset=price_cols, how="all")
        return df

    @staticmethod
    def resample_to_4h(df: pd.DataFrame) -> pd.DataFrame:
        """Aggregate 60m bars into 4h OHLCV buckets.

        Standard OHLCV aggregation: first Open, max High, min Low, last
        Close, summed Volume. Empty buckets (overnight gaps) are dropped.
        Left-labelled so a bar's timestamp is its bucket START — the
        convention :meth:`_drop_forming_bar` relies on.
        """
        if df is None or df.empty:
            return pd.DataFrame()
        agg = {"Open": "first", "High": "max", "Low": "min",
               "Close": "last", "Volume": "sum"}
        cols = [c for c in agg if c in df.columns]
        out = df[cols].resample(
            _RESAMPLE_RULE, label="left", closed="left").agg(
            {c: agg[c] for c in cols})
        # Drop buckets with no trades (Close is NaN).
        if "Close" in out.columns:
            out = out.dropna(subset=["Close"])
        return out

    @staticmethod
    def _drop_forming_bar(df: pd.DataFrame,
                          now: datetime | None = None) -> pd.DataFrame:
        """Remove a trailing 4h bar whose bucket has not yet closed.

        Bars are left-labelled, so the bucket spanning ``[t, t+4h)`` is
        still forming while ``now < t + 4h``. Only the last bar can be in
        progress (index ascending), so at most one row is dropped. This is
        the intraday analogue of the daily incomplete-session guard: the
        flag is only ever computed on COMPLETED 4h candles.
        """
        if df is None or df.empty:
            return df
        if now is None:
            now = datetime.now(tz=_IST)
        now_naive = now.astimezone(_IST).replace(tzinfo=None)
        last_start = df.index[-1]
        bucket_end = last_start + pd.Timedelta(_RESAMPLE_RULE)
        if now_naive < bucket_end:
            return df.iloc[:-1]
        return df
