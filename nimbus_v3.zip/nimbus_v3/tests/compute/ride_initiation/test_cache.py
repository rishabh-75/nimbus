"""tests.compute.ride_initiation.test_cache — RideClassificationCache.

Covers ``build`` (per-symbol + per-industry + universe roll-up),
``update_symbol`` (incremental refresh after fresh data lands),
empty/edge cases, and exception isolation.

The classifier is the real engine — the cache exists to be a thin
indirection layer, so testing it against the real engine catches
any contract drift between the two.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.compute.ride_initiation import (
    RideClassificationCache, RideEngine, RideResult,
)


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════════════


def _enriched(seed: int, n: int = 250) -> pd.DataFrame:
    """A 250-bar enriched OHLCV frame from a seeded random walk —
    enough history to satisfy the classifier's warm-up windows
    (SMA20, BBW lookback, vol-percentile window, etc)."""
    rng = np.random.default_rng(seed)
    close = 100 + np.cumsum(rng.normal(0.05, 1.0, n))
    df = pd.DataFrame(
        {
            "Open":   close * 0.998,
            "High":   close * 1.005,
            "Low":    close * 0.995,
            "Close":  close,
            "Volume": rng.integers(1_000_000, 5_000_000, n).astype(float),
        },
        index=pd.bdate_range("2024-01-01", periods=n),
    )
    return StrategyComputeEngine().enrich(df, f"S{seed}")


@pytest.fixture(scope="module")
def panel() -> dict[str, pd.DataFrame]:
    """A 6-symbol panel grouped 3 + 3 across two industries."""
    return {f"S{i}": _enriched(i) for i in range(6)}


@pytest.fixture(scope="module")
def members_by_industry() -> dict[str, list[str]]:
    return {
        "Petroleum": ["S0", "S1", "S2"],
        "Banks":     ["S3", "S4", "S5"],
    }


# ══════════════════════════════════════════════════════════════════════════════
# build
# ══════════════════════════════════════════════════════════════════════════════


class TestBuild:
    def test_empty_panel_yields_empty_cache(self):
        cache = RideClassificationCache.build({}, {})
        assert cache.symbol_results == {}
        assert cache.industry_results == {}

    def test_populates_per_symbol(self, panel, members_by_industry):
        cache = RideClassificationCache.build(panel, members_by_industry)
        # Every symbol with full history should be classified.
        for sym in panel:
            assert sym in cache.symbol_results, (
                f"{sym} expected in cache.symbol_results"
            )
        # And every entry is a real RideResult.
        for sym, res in cache.symbol_results.items():
            assert isinstance(res, RideResult)
            assert not res.phase.empty

    def test_populates_per_industry_plus_all(self, panel, members_by_industry):
        cache = RideClassificationCache.build(panel, members_by_industry)
        # Both industries.
        assert "Petroleum" in cache.industry_results
        assert "Banks" in cache.industry_results
        # Plus the universe roll-up.
        assert "ALL" in cache.industry_results

    def test_industry_with_no_panel_members_is_skipped(self):
        """When members_by_industry lists symbols that aren't in the
        panel (universe wider than panel), the industry is skipped
        rather than producing an empty roll-up."""
        panel_partial = {"S0": _enriched(0)}
        members = {"Banks": ["S1", "S2"]}    # neither in panel
        cache = RideClassificationCache.build(panel_partial, members)
        assert "Banks" not in cache.industry_results
        # ALL row still computed from whatever's actually in the panel.
        assert "ALL" in cache.industry_results

    def test_skips_empty_dataframes(self):
        """Empty / None dataframes are silently skipped, not
        exception."""
        panel = {
            "S0": _enriched(0),
            "S1": pd.DataFrame(),      # empty
        }
        cache = RideClassificationCache.build(panel, {})
        assert "S0" in cache.symbol_results
        assert "S1" not in cache.symbol_results

    def test_classify_exception_is_isolated(self, monkeypatch):
        """If classify raises for one symbol, the rest still
        populate. The cache is best-effort, not all-or-nothing."""
        engine = RideEngine()
        original = engine.classify

        def raising_classify(df):
            if df["Close"].iloc[0] > 95 and df["Close"].iloc[0] < 105:
                # Trigger only on S0 (close starts ~100). Other
                # symbols' starting close is also near 100, but the
                # seeded random walk varies. We use a stable raise
                # condition independent of seed.
                raise RuntimeError("synthetic failure")
            return original(df)

        # Simpler: monkeypatch a lambda that raises only for S0.
        seen_calls = {"count": 0}

        def conditional_raise(df):
            seen_calls["count"] += 1
            if seen_calls["count"] == 1:
                raise RuntimeError("synthetic failure on first call")
            return original(df)

        engine.classify = conditional_raise    # type: ignore

        panel = {f"S{i}": _enriched(i) for i in range(3)}
        cache = RideClassificationCache.build(panel, {}, engine=engine)
        # 1 of 3 symbols failed; the other 2 are still cached.
        assert len(cache.symbol_results) == 2


# ══════════════════════════════════════════════════════════════════════════════
# Lookups
# ══════════════════════════════════════════════════════════════════════════════


class TestLookups:
    def test_for_symbol_returns_none_when_missing(self, panel, members_by_industry):
        cache = RideClassificationCache.build(panel, members_by_industry)
        assert cache.for_symbol("UNKNOWN") is None

    def test_for_symbol_returns_result(self, panel, members_by_industry):
        cache = RideClassificationCache.build(panel, members_by_industry)
        res = cache.for_symbol("S0")
        assert isinstance(res, RideResult)

    def test_for_industry_returns_none_when_missing(self, panel, members_by_industry):
        cache = RideClassificationCache.build(panel, members_by_industry)
        assert cache.for_industry("Pharma") is None

    def test_for_industry_supports_all_special_key(self, panel, members_by_industry):
        cache = RideClassificationCache.build(panel, members_by_industry)
        all_res = cache.for_industry("ALL")
        assert isinstance(all_res, RideResult)


# ══════════════════════════════════════════════════════════════════════════════
# update_symbol — the staleness fix
# ══════════════════════════════════════════════════════════════════════════════


class TestUpdateSymbol:
    def test_replaces_symbol_result_after_dataframe_changes(
        self, panel, members_by_industry,
    ):
        """When the panel's dataframe for a symbol is replaced,
        update_symbol re-classifies just that entry. The new result
        should differ from the old whenever the new dataframe
        produces a different last-bar phase."""
        cache = RideClassificationCache.build(panel, members_by_industry)
        original_res = cache.for_symbol("S0")
        assert original_res is not None
        original_last_phase = original_res.phase.iloc[-1]

        # Build a deliberately different dataframe — strong uptrend
        # near the end so the phase is more likely to flip.
        n = 250
        rng = np.random.default_rng(0)
        # 230 bars of mild noise then 20 bars of steady up
        prices_noise = 100 + np.cumsum(rng.normal(0, 0.5, 230))
        last_baseline = prices_noise[-1]
        prices_uptrend = last_baseline * np.cumprod(
            1 + np.full(20, 0.02),
        )
        prices = np.concatenate([prices_noise, prices_uptrend])
        new_df = pd.DataFrame(
            {
                "Open":   prices * 0.998,
                "High":   prices * 1.005,
                "Low":    prices * 0.995,
                "Close":  prices,
                "Volume": rng.integers(1_000_000, 5_000_000, n).astype(float),
            },
            index=pd.bdate_range("2024-01-01", periods=n),
        )
        enriched = StrategyComputeEngine().enrich(new_df, "S0")

        # Mutate the panel like MainWindow does after a fresh fetch.
        new_panel = {**panel, "S0": enriched}
        cache.update_symbol("S0", new_panel, members_by_industry)

        # Cache entry replaced.
        new_res = cache.for_symbol("S0")
        assert new_res is not None
        # The Series identity differs (engine produced a fresh one).
        assert new_res is not original_res

    def test_drops_symbol_when_dataframe_becomes_empty(
        self, panel, members_by_industry,
    ):
        """When update_symbol receives a panel where the symbol's
        dataframe is empty / removed, the cache entry is dropped."""
        cache = RideClassificationCache.build(panel, members_by_industry)
        assert cache.for_symbol("S0") is not None

        new_panel = {k: v for k, v in panel.items() if k != "S0"}
        cache.update_symbol("S0", new_panel, members_by_industry)
        assert cache.for_symbol("S0") is None

    def test_refreshes_affected_industry_only(
        self, panel, members_by_industry,
    ):
        """An update to an S0 (Petroleum member) refreshes
        Petroleum's roll-up + ALL. Banks roll-up untouched —
        Petroleum and Banks share no members."""
        cache = RideClassificationCache.build(panel, members_by_industry)
        banks_before = cache.for_industry("Banks")
        petroleum_before = cache.for_industry("Petroleum")
        assert banks_before is not None
        assert petroleum_before is not None

        new_panel = {**panel, "S0": _enriched(99)}    # different seed
        cache.update_symbol("S0", new_panel, members_by_industry)

        banks_after = cache.for_industry("Banks")
        petroleum_after = cache.for_industry("Petroleum")
        # Banks roll-up object unchanged — same identity.
        assert banks_after is banks_before
        # Petroleum roll-up replaced.
        assert petroleum_after is not petroleum_before

    def test_always_refreshes_all_universe_rollup(
        self, panel, members_by_industry,
    ):
        """Any symbol update touches the ALL row — universe roll-up
        is panel-wide."""
        cache = RideClassificationCache.build(panel, members_by_industry)
        all_before = cache.for_industry("ALL")
        assert all_before is not None

        new_panel = {**panel, "S0": _enriched(99)}
        cache.update_symbol("S0", new_panel, members_by_industry)
        all_after = cache.for_industry("ALL")
        assert all_after is not all_before

    def test_update_for_symbol_not_in_any_industry(self, panel):
        """A symbol that isn't a member of any tracked industry
        still gets its per-symbol entry refreshed; no industry
        roll-up changes."""
        members = {"Banks": ["S3", "S4", "S5"]}    # S0 not listed
        cache = RideClassificationCache.build(panel, members)
        new_panel = {**panel, "S0": _enriched(99)}
        # Should not raise.
        cache.update_symbol("S0", new_panel, members)
        # Cache reflects the update.
        assert cache.for_symbol("S0") is not None
