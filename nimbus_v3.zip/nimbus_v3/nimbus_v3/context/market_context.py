"""nimbus_v3.context.market_context — market-wide context provider.

Produces a ``MarketContext`` at any ``asof_date``:
    - VIX value and regime.
    - VIX HIGH-streak (consecutive days at HIGH regime up to and including ``asof_date``).
    - 20-day rolling z-score of VIX.
    - NIFTY 50 above/below 200-SMA and 20-day ROC, when NIFTY history is provided.

Regime thresholds
─────────────────
Placeholder thresholds appropriate for India VIX (single-digit VIX is
rare; most of the distribution lives between 11 and 25):

    VIX < 12      → LOW
    12 ≤ VIX < 16 → NORMAL
    16 ≤ VIX < 22 → ELEVATED
    22 ≤ VIX < 30 → HIGH
    VIX ≥ 30      → PANIC

These are refined in Phase 7 research on v3's universe. The provider
reads them from a constructor argument so tests and research can vary
them without monkey-patching.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import numpy as np
import pandas as pd

from nimbus_v3.core.context import MarketContext
from nimbus_v3.core.types import VIXRegime
from nimbus_v3.data.vix_loader import VIXLoader


# ══════════════════════════════════════════════════════════════════════════════
# Regime thresholds
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class VIXRegimeThresholds:
    """Ordered thresholds mapping a VIX value to a ``VIXRegime``.

    ``classify(value)`` returns the first regime whose upper bound is
    greater than ``value``. The final regime is unbounded.
    """
    low_max: float = 12.0
    normal_max: float = 16.0
    elevated_max: float = 22.0
    high_max: float = 30.0

    def classify(self, value: float) -> VIXRegime:
        if value < self.low_max:
            return VIXRegime.LOW
        if value < self.normal_max:
            return VIXRegime.NORMAL
        if value < self.elevated_max:
            return VIXRegime.ELEVATED
        if value < self.high_max:
            return VIXRegime.HIGH
        return VIXRegime.PANIC


_DEFAULT_THRESHOLDS: Final[VIXRegimeThresholds] = VIXRegimeThresholds()


# ══════════════════════════════════════════════════════════════════════════════
# Provider
# ══════════════════════════════════════════════════════════════════════════════

class MarketContextProvider:
    """``ContextProvider[MarketContext]`` backed by ``VIXLoader``.

    Construct with a ``VIXLoader`` for VIX values and optionally with a
    NIFTY 50 history DataFrame (loaded via ``PriceLoader`` using the
    index ticker) for the trend fields. When the NIFTY history is not
    provided, ``index_above_sma_200`` and ``index_roc_20d`` are ``None``
    — the grade formula treats these as missing.

    Stateless; thread-safe.
    """

    def __init__(
        self,
        vix_loader: VIXLoader,
        *,
        thresholds: VIXRegimeThresholds = _DEFAULT_THRESHOLDS,
        index_history: pd.DataFrame | None = None,
    ) -> None:
        self._vix = vix_loader
        self._thresholds = thresholds
        self._index_history = (
            index_history.copy() if index_history is not None else None
        )

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def build(
        self,
        *,
        symbol: str | None = None,      # noqa: ARG002 — market-wide, symbol unused
        asof_date: pd.Timestamp,
    ) -> MarketContext:
        asof = _normalise(asof_date)

        vix_value = self._vix.load_value_on(asof)
        regime = self._thresholds.classify(vix_value) if vix_value is not None else None
        history = self._vix.load_history()
        streak = _compute_high_streak(history, asof, self._thresholds)
        vix_z = _compute_vix_zscore(history, asof, window=20)

        idx_above_sma = None
        idx_roc = None
        if self._index_history is not None and not self._index_history.empty:
            idx_above_sma = _index_above_sma(self._index_history, asof, window=200)
            idx_roc = _index_roc(self._index_history, asof, window=20)

        return MarketContext(
            asof_date=asof,
            vix_value=vix_value,
            vix_regime=regime,
            vix_high_streak=streak,
            vix_z_20d=vix_z,
            index_above_sma_200=idx_above_sma,
            index_roc_20d=idx_roc,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Helpers — pure functions so they can be tested independently
# ══════════════════════════════════════════════════════════════════════════════

def _normalise(ts: pd.Timestamp) -> pd.Timestamp:
    t = pd.Timestamp(ts)
    if t.tz is not None:
        t = t.tz_localize(None)
    return t.normalize()


def _compute_high_streak(
    history: pd.DataFrame,
    asof: pd.Timestamp,
    thresholds: VIXRegimeThresholds,
) -> int:
    """Count consecutive HIGH-or-PANIC days ending at ``asof``.

    Walks backwards from ``asof`` while the classified regime remains at
    or above HIGH (i.e., VIX ≥ ``high_max`` from the prior bucket, so
    HIGH and PANIC both count). Returns 0 if the last bar is below HIGH
    or history is unavailable.
    """
    if history is None or history.empty:
        return 0
    eligible = history.loc[:asof]
    if eligible.empty:
        return 0
    # Iterate in reverse; stop at the first non-HIGH bar.
    streak = 0
    for _, close in reversed(list(eligible["Close"].items())):
        if pd.isna(close):
            break
        value = float(close)
        regime = thresholds.classify(value)
        if regime in (VIXRegime.HIGH, VIXRegime.PANIC):
            streak += 1
        else:
            break
    return streak


def _compute_vix_zscore(
    history: pd.DataFrame,
    asof: pd.Timestamp,
    *,
    window: int,
) -> float | None:
    """Rolling z-score of the VIX close at ``asof`` vs. the previous
    ``window`` trading days. Returns ``None`` when window coverage is
    insufficient."""
    if history is None or history.empty:
        return None
    eligible = history.loc[:asof]
    if len(eligible) < window + 1:
        return None
    window_slice = eligible["Close"].iloc[-(window + 1) :]
    current = float(window_slice.iloc[-1])
    baseline = window_slice.iloc[:-1]
    mu = float(baseline.mean())
    sigma = float(baseline.std(ddof=0))
    if sigma == 0 or np.isnan(sigma):
        return None
    return (current - mu) / sigma


def _index_above_sma(
    index_df: pd.DataFrame, asof: pd.Timestamp, *, window: int,
) -> bool | None:
    eligible = index_df.loc[:asof]
    if len(eligible) < window:
        return None
    window_slice = eligible["Close"].iloc[-window:]
    if window_slice.isna().any():
        return None
    sma = float(window_slice.mean())
    close = float(eligible["Close"].iloc[-1])
    return close > sma


def _index_roc(
    index_df: pd.DataFrame, asof: pd.Timestamp, *, window: int,
) -> float | None:
    eligible = index_df.loc[:asof]
    if len(eligible) < window + 1:
        return None
    close_now = float(eligible["Close"].iloc[-1])
    close_then = float(eligible["Close"].iloc[-(window + 1)])
    if close_then == 0 or np.isnan(close_then):
        return None
    return (close_now / close_then - 1.0) * 100.0
