"""Smoke test for run_composite_rank_rotation_validation.py.

Constructs a tiny synthetic panel + industry_map where:
  - Industry A: composite rises sharply over time (climbers)
  - Industry B: composite falls sharply over time (fallers)
  - Industry C: flat composite throughout

Then verifies that:
  - _build_industry_composites produces a series for each
  - _rank_per_bar gives 1 to the highest-composite industry per bar
  - _delta_ranks captures rank improvements over the window

This is a pipeline smoke test, NOT a validation of the
hypothesis. The point is just to confirm the script's mechanics
work on data we control before running it on real bars.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Make sure the script's helpers are importable
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from scripts.run_composite_rank_rotation_validation import (    # noqa: E402
    _band_for,
    _BANDS,
    _build_industry_composites,
    _compute_composite_series,
    _delta_ranks,
    _rank_per_bar,
)


def _synthetic_symbol(
    n_bars: int, drift: float, seed: int,
) -> pd.DataFrame:
    """Build a synthetic OHLCV frame. drift > 0 → uptrend, < 0 → down."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2024-01-01", periods=n_bars)
    log_returns = drift / 100 + rng.normal(0, 0.01, n_bars)
    close = pd.Series(100 * np.exp(np.cumsum(log_returns)), index=idx)
    volume = pd.Series(rng.integers(900_000, 1_100_000, n_bars), index=idx)
    return pd.DataFrame({"Close": close, "Volume": volume})


# ══════════════════════════════════════════════════════════════════════
# Composite series — sanity
# ══════════════════════════════════════════════════════════════════════

class TestCompositeSeries:

    def test_uptrending_symbol_has_positive_composite_at_end(self):
        df = _synthetic_symbol(n_bars=200, drift=0.15, seed=1)
        comp = _compute_composite_series(df["Close"], df["Volume"])
        # Last bar's composite should be clearly positive for an uptrend
        last = comp.iloc[-1]
        assert not pd.isna(last)
        assert last > 0.2, f"uptrend composite={last:.2f}, expected > 0.2"

    def test_downtrending_symbol_has_negative_composite_at_end(self):
        df = _synthetic_symbol(n_bars=200, drift=-0.15, seed=2)
        comp = _compute_composite_series(df["Close"], df["Volume"])
        last = comp.iloc[-1]
        assert not pd.isna(last)
        assert last < -0.2, f"downtrend composite={last:.2f}, expected < -0.2"

    def test_short_series_returns_nan(self):
        idx = pd.bdate_range("2024-01-01", periods=30)
        close = pd.Series(np.linspace(100, 105, 30), index=idx)
        vol = pd.Series(1_000_000, index=idx)
        comp = _compute_composite_series(close, vol)
        # All NaN — not enough bars
        assert comp.isna().all()


# ══════════════════════════════════════════════════════════════════════
# Industry composite + ranking
# ══════════════════════════════════════════════════════════════════════

class TestIndustryCompositesAndRanking:

    def _three_industry_panel(self):
        """Industry A: 3 strong-uptrend members
        Industry B: 3 strong-downtrend members
        Industry C: 3 flat members"""
        panel = {}
        industry_map = {}
        for i, (drift, ind) in enumerate(
            [(0.20, "A"), (0.20, "A"), (0.20, "A"),
             (-0.20, "B"), (-0.20, "B"), (-0.20, "B"),
             (0.0, "C"), (0.0, "C"), (0.0, "C")]
        ):
            sym = f"SYM{i}"
            panel[sym] = _synthetic_symbol(n_bars=200, drift=drift, seed=10 + i)
            industry_map[sym] = ind
        return panel, industry_map

    def test_three_industries_ranked_correctly_at_end(self):
        panel, industry_map = self._three_industry_panel()
        composites = _build_industry_composites(panel, industry_map)
        assert set(composites.keys()) == {"A", "B", "C"}

        rank_df = _rank_per_bar(composites)
        # With only 3 industries we don't have ≥ _MIN_INDUSTRIES_PER_BAR=20.
        # But the rank logic still computes; the script masks it later.
        # Test the underlying composite ordering instead:
        last_comps = {ind: composites[ind].iloc[-1] for ind in ["A", "B", "C"]}
        # A should have the highest composite, B the lowest
        assert last_comps["A"] > last_comps["C"] > last_comps["B"]


# ══════════════════════════════════════════════════════════════════════
# Δrank + banding
# ══════════════════════════════════════════════════════════════════════

class TestDeltaRankAndBanding:

    def test_delta_rank_positive_when_rank_improves(self):
        """If an industry was rank 20 last week and is rank 5 now,
        Δrank = 20 - 5 = +15 (climbed up)."""
        idx = pd.bdate_range("2024-01-01", periods=30)
        ranks = pd.DataFrame(
            {"X": [20] * 25 + [5] * 5},
            index=idx,
        )
        delta = _delta_ranks(ranks, window=5)
        # On the last bar, Δrank should be 20 - 5 = 15
        assert delta["X"].iloc[-1] == 15

    def test_band_for_assignment_correctness(self):
        # Band edges
        assert _band_for(15) == "BIG_CLIMB"        # ≥+10
        assert _band_for(10) == "BIG_CLIMB"        # boundary
        assert _band_for(5) == "MILD_CLIMB"        # +3..+9
        assert _band_for(0) == "FLAT"              # -2..+2
        assert _band_for(-5) == "MILD_FALL"        # -3..-9
        assert _band_for(-15) == "BIG_FALL"        # ≤-10

    def test_band_for_nan_returns_none(self):
        assert _band_for(float("nan")) is None
