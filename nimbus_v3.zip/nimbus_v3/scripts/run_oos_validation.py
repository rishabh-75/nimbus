"""scripts/run_oos_validation.py — out-of-sample strategy validation.

Two studies in one run:

A) **MR/BO confirmation** — apply the new (post-tuning) parameters on
   train (2020-03 → 2024-12) and test (2025-01 → 2026-04). If the lift
   over universe baseline shrinks materially on test, the parameters
   are overfit. If it holds, we have OOS-confirmed setups.

B) **Ride redesign exploration** — test eight candidate gate
   combinations on the train period using the three new candidate
   features (``green_streak``, ``adx_14``, ``mfi_slope_3``). Take any
   that produce baseline-beating lift to test for OOS confirmation.

Universe baseline is computed separately for train and test, so all
"lift" numbers are within-period and apples-to-apples.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.research.harness import (
    add_forward_returns,
    build_vix_proxy,
    compute_vix_streaks,
    evaluate_vector_predicate_panel,
    split_panel_by_date,
    split_streak_by_date,
    summarise,
)


OOS_CUTOFF = pd.Timestamp("2025-01-01")


# ══════════════════════════════════════════════════════════════════════════════
# Predicates
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class GateDef:
    name: str
    test: Callable[[pd.DataFrame, pd.Series], pd.Series]


def _all(gates: list[GateDef]) -> Callable[[pd.DataFrame, pd.Series], pd.Series]:
    def fn(df, st):
        result = None
        for g in gates:
            mask = g.test(df, st)
            result = mask if result is None else (result & mask)
        return result if result is not None else pd.Series(True, index=df.index)
    return fn


# ── Post-tuning MR ────────────────────────────────────────────────────────────
# Current production parameters.
NEW_MR = [
    GateDef("roc_5 < -3", lambda df, _: df["roc_5"] < -3.0),
    GateDef("bbw_pctl < 40", lambda df, _: df["bbw_20_2s_pctl"] < 40.0),
    GateDef("vix_streak >= 6", lambda _, st: st >= 6),
]

#: Loosened-MR variant. The full-period sensitivity sweep on fresh
#: yfinance data (April 2026) showed that ``(vix_streak >= 2,
#: bbw_pctl < 50)`` produces n≈2500 with mean_10d ≈ +1.64% / +1.82%
#: respectively — similar or better per-trade lift than the baseline
#: (6, 40) combination at roughly 3× the trade count. This variant
#: exists so the OOS validator can check whether the stronger sample
#: properties translate to OOS lift, or whether the strict original
#: combination protects against regime-specific failures that the
#: looser version doesn't catch.
LOOSER_MR = [
    GateDef("roc_5 < -3", lambda df, _: df["roc_5"] < -3.0),
    GateDef("bbw_pctl < 50", lambda df, _: df["bbw_20_2s_pctl"] < 50.0),
    GateDef("vix_streak >= 2", lambda _, st: st >= 2),
]


# ── Post-tuning Breakout ──────────────────────────────────────────────────────
NEW_BO = [
    GateDef("roc_20 > 7", lambda df, _: df["roc_20"] > 7.0),
]


# ── Original Ride (current production gates — for comparison only) ───────────
ORIGINAL_RIDE = [
    GateDef("Close in [bb_1s_upper, bb_2s_upper]",
              lambda df, _: (df["bb_20_1s_upper"] <= df["Close"])
                             & (df["Close"] <= df["bb_20_2s_upper"])),
    GateDef("wr_30 > -20", lambda df, _: df["wr_30"] > -20.0),
]


# ── Ride redesign candidates ──────────────────────────────────────────────────
def _bb_ride_gate() -> GateDef:
    return GateDef(
        "Close in [bb_1s_upper, bb_2s_upper]",
        lambda df, _: (df["bb_20_1s_upper"] <= df["Close"])
                       & (df["Close"] <= df["bb_20_2s_upper"]),
    )


RIDE_CANDIDATES: dict[str, list[GateDef]] = {
    "BB-only": [_bb_ride_gate()],
    "BB + green_streak>=3": [
        _bb_ride_gate(),
        GateDef("green_streak >= 3", lambda df, _: df["green_streak"] >= 3),
    ],
    "BB + adx_14>25": [
        _bb_ride_gate(),
        GateDef("adx_14 > 25", lambda df, _: df["adx_14"] > 25.0),
    ],
    "BB + mfi_slope_3>0": [
        _bb_ride_gate(),
        GateDef("mfi_slope_3 > 0", lambda df, _: df["mfi_slope_3"] > 0),
    ],
    "BB + green_streak>=3 + adx_14>25": [
        _bb_ride_gate(),
        GateDef("green_streak >= 3", lambda df, _: df["green_streak"] >= 3),
        GateDef("adx_14 > 25", lambda df, _: df["adx_14"] > 25.0),
    ],
    "BB + green_streak>=3 + mfi_slope>0": [
        _bb_ride_gate(),
        GateDef("green_streak >= 3", lambda df, _: df["green_streak"] >= 3),
        GateDef("mfi_slope_3 > 0", lambda df, _: df["mfi_slope_3"] > 0),
    ],
    "BB + adx_14>25 + mfi_slope>0": [
        _bb_ride_gate(),
        GateDef("adx_14 > 25", lambda df, _: df["adx_14"] > 25.0),
        GateDef("mfi_slope_3 > 0", lambda df, _: df["mfi_slope_3"] > 0),
    ],
    "BB + all three new gates": [
        _bb_ride_gate(),
        GateDef("green_streak >= 3", lambda df, _: df["green_streak"] >= 3),
        GateDef("adx_14 > 25", lambda df, _: df["adx_14"] > 25.0),
        GateDef("mfi_slope_3 > 0", lambda df, _: df["mfi_slope_3"] > 0),
    ],
    # Pure-trend candidates that drop the BB-ride condition entirely.
    "green_streak>=3 + adx_14>25 + mfi_slope>0 (no BB)": [
        GateDef("green_streak >= 3", lambda df, _: df["green_streak"] >= 3),
        GateDef("adx_14 > 25", lambda df, _: df["adx_14"] > 25.0),
        GateDef("mfi_slope_3 > 0", lambda df, _: df["mfi_slope_3"] > 0),
    ],
}


# ══════════════════════════════════════════════════════════════════════════════
# Reporting helpers
# ══════════════════════════════════════════════════════════════════════════════

def _print_header(text: str) -> None:
    print()
    print("═" * 84)
    print(f"  {text}")
    print("═" * 84)


def _row(label: str, stats, *, baseline_mean: float | None = None) -> str:
    if stats.n == 0:
        return f"  {label:54s}  n=     0   mean10d=  --     wr=  --     t=  --"
    line = (
        f"  {label:54s}  n={stats.n:6d}   "
        f"mean10d={stats.mean_10d * 100:+5.2f}%   "
        f"wr={stats.win_rate_10d * 100:5.1f}%   "
        f"t={stats.t_stat_10d:+5.2f}"
    )
    if baseline_mean is not None and not pd.isna(baseline_mean):
        lift_pp = (stats.mean_10d - baseline_mean) * 100
        line += f"   lift={lift_pp:+5.2f}pp"
    return line


def _eval(strategy_name, panel, streak, gates):
    return summarise(evaluate_vector_predicate_panel(
        strategy_name=strategy_name, enriched_panel=panel,
        vix_streak=streak, predicate=_all(gates),
    ))


def _universe_mean(panel, streak):
    return summarise(evaluate_vector_predicate_panel(
        strategy_name="universe", enriched_panel=panel,
        vix_streak=streak, predicate=lambda df, st: True,
    )).mean_10d


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    panel = load_equity_panel()
    if not panel:
        print("No equity panel loaded — yfinance unreachable? Stopping.")
        return

    print("Building VIX proxy and streak series …")
    vix_df = build_vix_proxy(panel, smoothing=5)
    high_threshold = float(vix_df["Close"].quantile(0.65))
    streak = compute_vix_streaks(vix_df, high_threshold=high_threshold)
    print(f"  HIGH threshold = {high_threshold:.2f}, max streak = {int(streak.max())}")

    print("Enriching every symbol with indicators + forward returns …")
    engine = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            e = engine.enrich(df, sym)
            e = add_forward_returns(e, horizons=(5, 10, 20))
            enriched[sym] = e
        except Exception:    # noqa: BLE001
            continue
    print(f"  enriched {len(enriched)}/{len(panel)} symbols")

    print(f"\nSplitting at OOS cutoff {OOS_CUTOFF.date()} …")
    train_panel, test_panel = split_panel_by_date(enriched, cutoff=OOS_CUTOFF)
    train_streak, test_streak = split_streak_by_date(streak, cutoff=OOS_CUTOFF)
    print(f"  train: {len(train_panel)} symbols, test: {len(test_panel)} symbols")

    train_uni_mean = _universe_mean(train_panel, train_streak)
    test_uni_mean = _universe_mean(test_panel, test_streak)
    print(f"  universe mean 10d — train: {train_uni_mean*100:+.2f}%   "
          f"test: {test_uni_mean*100:+.2f}%")

    # ── Study A: MR / BO OOS confirmation ────────────────────────────────────
    _print_header("A. Post-tuning Mean Reversion — OOS confirmation")
    mr_train = _eval("MR", train_panel, train_streak, NEW_MR)
    mr_test = _eval("MR", test_panel, test_streak, NEW_MR)
    print(_row("TRAIN (2020-03 → 2024-12)", mr_train, baseline_mean=train_uni_mean))
    print(_row("TEST  (2025-01 → 2026-04)", mr_test, baseline_mean=test_uni_mean))

    _print_header(
        "A'. Looser MR variant (bbw < 50, vix_streak ≥ 2) — OOS confirmation"
    )
    print("  Motivation: sensitivity sweep suggested similar per-trade lift at 3× trade count.")
    print("  Question: does the looser set preserve OOS lift, or was the strict set")
    print("            protecting against regime-specific failures we cannot see in-sample?")
    lmr_train = _eval("MR-loose", train_panel, train_streak, LOOSER_MR)
    lmr_test = _eval("MR-loose", test_panel, test_streak, LOOSER_MR)
    print(_row("TRAIN", lmr_train, baseline_mean=train_uni_mean))
    print(_row("TEST ", lmr_test, baseline_mean=test_uni_mean))

    _print_header("A. Post-tuning Breakout — OOS confirmation")
    bo_train = _eval("BO", train_panel, train_streak, NEW_BO)
    bo_test = _eval("BO", test_panel, test_streak, NEW_BO)
    print(_row("TRAIN (2020-03 → 2024-12)", bo_train, baseline_mean=train_uni_mean))
    print(_row("TEST  (2025-01 → 2026-04)", bo_test, baseline_mean=test_uni_mean))

    # ── Study B: Ride redesign on train, OOS-confirm winners ─────────────────
    _print_header("B. Ride redesign — TRAIN-period exploration")
    print(_row("UNIVERSE", summarise(evaluate_vector_predicate_panel(
        strategy_name="u", enriched_panel=train_panel,
        vix_streak=train_streak, predicate=lambda df, st: True,
    )), baseline_mean=train_uni_mean))
    orig_train = _eval("Ride[orig]", train_panel, train_streak, ORIGINAL_RIDE)
    print(_row("ORIGINAL Ride (BB + wr_30 > -20)", orig_train,
                 baseline_mean=train_uni_mean))

    candidate_results: list[tuple[str, object]] = []
    for label, gates in RIDE_CANDIDATES.items():
        s = _eval(f"Ride[{label}]", train_panel, train_streak, gates)
        candidate_results.append((label, s))
        print(_row(label, s, baseline_mean=train_uni_mean))

    # Pick the candidates with the largest train-period lift, n >= 100, t >= 2.
    ranked = sorted(
        candidate_results,
        key=lambda lr: (lr[1].mean_10d - train_uni_mean if lr[1].n >= 100 else -1),
        reverse=True,
    )
    top_two = [(label, s) for label, s in ranked
                  if s.n >= 100 and s.t_stat_10d >= 2.0][:2]

    _print_header("B. Ride redesign — TEST-period confirmation of top candidates")
    if not top_two:
        print("  No train-period candidate met the n≥100, t≥2 threshold.")
    for label, _ in top_two:
        gates = RIDE_CANDIDATES[label]
        train_stats = _eval("Ride", train_panel, train_streak, gates)
        test_stats = _eval("Ride", test_panel, test_streak, gates)
        train_lift = (train_stats.mean_10d - train_uni_mean) * 100
        test_lift = (test_stats.mean_10d - test_uni_mean) * 100 if test_stats.n > 0 else float("nan")
        print()
        print(f"  Candidate: {label}")
        print(_row("    TRAIN", train_stats, baseline_mean=train_uni_mean))
        print(_row("    TEST", test_stats, baseline_mean=test_uni_mean))
        decay = test_lift - train_lift
        print(f"    OOS lift decay: {decay:+.2f}pp  "
              f"(train lift {train_lift:+.2f}pp → test lift {test_lift:+.2f}pp)")

    print()
    print("═" * 84)
    print("  Done.")
    print("═" * 84)


if __name__ == "__main__":
    main()
