"""nimbus_v3.ui.widgets.macro_flow_panel — macro flow view.

Multi-window price z-score table over the commodity universe, topped
with a verdict bar that summarises the macro regime (RISK-ON / RISK-
OFF / INFLATIONARY / DEFLATIONARY / MIXED) with per-category stats
and top movers. Inherits Emerald Slate from MainWindow; only data-cell
colors are overridden inline via the theme's helper functions.

    Stage badges
    ────────────
    EARLY    — 10d hot, longer windows cool. Move just starting.
    MID      — 30d hot, others moderating. Mid-event.
    MATURE   — 60d hot, 10d cooled. Trend has been running.
    EXTENDED — all three windows hot. Persistent regime.

The panel re-fetches data on Refresh; no auto-polling. Category filter
buttons let the operator narrow the table view (the verdict bar
always summarises the full universe regardless of the filter).
"""
from __future__ import annotations

import logging
from typing import Callable

import pandas as pd
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont
from PyQt6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QFrame, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QMessageBox, QPushButton, QSizePolicy,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from nimbus_v3.compute.flow_analytics import (
    CategoryStats,
    FlowAnalyticsEngine,
    FlowAnalyticsResult,
    MacroVerdict,
)
from nimbus_v3.macro.flow_detector import MacroFlowResult, detect_flows
from nimbus_v3.macro.universe import (
    COMMODITY_UNIVERSE, CommodityCategory,
)
from nimbus_v3.ui.theme import (
    BLUE, BORDER, EM, FONT_MONO, GOLD, GREEN, MUTED, RED, SURFACE,
    STAGE_STYLES, WHITE, pct_change_fg, z_score_fg,
)


logger = logging.getLogger(__name__)


# Category label colours — match grade hue families.
CATEGORY_COLORS = {
    CommodityCategory.PRECIOUS:     GOLD,
    CommodityCategory.INDUSTRIAL:   BLUE,
    CommodityCategory.ENERGY:       "#FB923C",
    CommodityCategory.AGRICULTURAL: GREEN,
    CommodityCategory.LIVESTOCK:    "#C98062",
}

# ══════════════════════════════════════════════════════════════════════════════
# Engine-constant re-exports
# ══════════════════════════════════════════════════════════════════════════════
#
# The verdict computation used to live here, inline in the UI module.
# It's been extracted to ``nimbus_v3/compute/flow_analytics.py`` as
# ``FlowAnalyticsEngine``. Threshold constants are still aliased at
# module level for readability — ``_CAT_ORDER`` reads cleaner in the
# for-loops below than ``FlowAnalyticsEngine.CAT_ORDER`` repeated
# three times. The engine is the source of truth; these are one-time
# assignments at import.

_BULL_Z = FlowAnalyticsEngine.BULL_Z
_BEAR_Z = FlowAnalyticsEngine.BEAR_Z
_STRONG_Z = FlowAnalyticsEngine.STRONG_Z
_MODERATE_Z = FlowAnalyticsEngine.MODERATE_Z
_CAT_ORDER = FlowAnalyticsEngine.CAT_ORDER



# ══════════════════════════════════════════════════════════════════════════════
# Verdict bar widget — hero badge + category heatmap + movers
# ══════════════════════════════════════════════════════════════════════════════

class _VerdictBar(QWidget):
    """Summary card that renders a :class:`MacroVerdict`.

    Layout:

        ┌─────────────┐ ┌── 5 tiles: Cat · mean_z · bulls/bears ──┐
        │ RISK-OFF    │ │ PRECIOUS   +1.1z  ↑   4/4              │
        │ strong      │ │ INDUSTRIAL +0.1z  —   1/2              │
        │ precious    │ │ ENERGY     -2.1z ↓↓   0/5              │
        │ bid, energy │ │ AGRI       +0.2z  —   2/8              │
        │ dumping     │ │ LIVESTOCK  -0.1z  —   1/3              │
        └─────────────┘ └────────────────────────────────────────┘
        TOP UP:    SI +4.1z · PL +2.3z · GC +1.9z
        TOP DOWN:  CL -3.9z · HO -3.1z · BZ -2.5z
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMinimumHeight(140)

        # ── Hero card (left) ────────────────────────────────────────
        self._hero_card = QFrame()
        self._hero_card.setFixedWidth(220)
        self._hero_card.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; "
            f"border-radius: 6px;"
        )
        hero_lay = QVBoxLayout(self._hero_card)
        hero_lay.setContentsMargins(14, 10, 14, 10)
        hero_lay.setSpacing(4)

        caption = QLabel("MACRO REGIME")
        caption.setStyleSheet(
            f"color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 8px; "
            f"font-weight: 600; letter-spacing: 1.4px; border: none; "
            f"background: transparent;"
        )
        hero_lay.addWidget(caption)

        self._hero_label = QLabel("—")
        self._hero_label.setStyleSheet(
            f"color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 18px; "
            f"font-weight: 700; letter-spacing: 1px; border: none; "
            f"background: transparent;"
        )
        hero_lay.addWidget(self._hero_label)

        self._hero_strength = QLabel("awaiting data")
        self._hero_strength.setStyleSheet(
            f"color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 9px; "
            f"border: none; background: transparent;"
        )
        hero_lay.addWidget(self._hero_strength)

        self._hero_reasons = QLabel("")
        self._hero_reasons.setWordWrap(True)
        self._hero_reasons.setStyleSheet(
            f"color: {WHITE}; font-family: '{FONT_MONO}'; font-size: 10px; "
            f"border: none; background: transparent; padding-top: 4px;"
        )
        hero_lay.addWidget(self._hero_reasons)
        hero_lay.addStretch(1)

        # ── Category grid (right) ───────────────────────────────────
        self._cat_card = QFrame()
        self._cat_card.setStyleSheet(
            f"background: {SURFACE}; border: 1px solid {BORDER}; "
            f"border-radius: 6px;"
        )
        self._cat_grid = QGridLayout(self._cat_card)
        self._cat_grid.setContentsMargins(12, 8, 12, 8)
        self._cat_grid.setHorizontalSpacing(12)
        self._cat_grid.setVerticalSpacing(2)
        # Pre-create 5 rows of labels keyed by category so update is
        # cheap (no widget recreation).
        self._cat_rows: dict[CommodityCategory, tuple[QLabel, QLabel, QLabel]] = {}
        for row, cat in enumerate(_CAT_ORDER):
            name = QLabel(cat.value.upper())
            name.setStyleSheet(
                f"color: {CATEGORY_COLORS.get(cat, MUTED)}; "
                f"font-family: '{FONT_MONO}'; font-size: 9px; "
                f"font-weight: 600; letter-spacing: 1.2px; "
                f"border: none; background: transparent;"
            )
            mean_z = QLabel("—")
            mean_z.setStyleSheet(
                f"color: {MUTED}; font-family: '{FONT_MONO}'; "
                f"font-size: 10px; font-weight: 700; "
                f"border: none; background: transparent;"
            )
            mean_z.setMinimumWidth(70)
            detail = QLabel("—")
            detail.setStyleSheet(
                f"color: {MUTED}; font-family: '{FONT_MONO}'; "
                f"font-size: 9px; border: none; background: transparent;"
            )
            self._cat_grid.addWidget(name, row, 0)
            self._cat_grid.addWidget(mean_z, row, 1)
            self._cat_grid.addWidget(detail, row, 2)
            self._cat_rows[cat] = (name, mean_z, detail)
        self._cat_grid.setColumnStretch(2, 1)

        # ── Movers row (bottom) ─────────────────────────────────────
        movers_card = QFrame()
        movers_card.setStyleSheet("background: transparent; border: none;")
        mlay = QHBoxLayout(movers_card)
        mlay.setContentsMargins(4, 0, 4, 0)
        mlay.setSpacing(18)
        up_cap = QLabel("TOP UP")
        up_cap.setStyleSheet(
            f"color: {GREEN}; font-family: '{FONT_MONO}'; font-size: 8px; "
            f"font-weight: 700; letter-spacing: 1.2px; border: none;"
        )
        self._movers_up_lbl = QLabel("—")
        self._movers_up_lbl.setStyleSheet(
            f"color: {WHITE}; font-family: '{FONT_MONO}'; font-size: 10px; "
            f"border: none; background: transparent;"
        )
        down_cap = QLabel("TOP DOWN")
        down_cap.setStyleSheet(
            f"color: {RED}; font-family: '{FONT_MONO}'; font-size: 8px; "
            f"font-weight: 700; letter-spacing: 1.2px; border: none;"
        )
        self._movers_down_lbl = QLabel("—")
        self._movers_down_lbl.setStyleSheet(
            f"color: {WHITE}; font-family: '{FONT_MONO}'; font-size: 10px; "
            f"border: none; background: transparent;"
        )
        mlay.addWidget(up_cap)
        mlay.addWidget(self._movers_up_lbl)
        mlay.addSpacing(12)
        mlay.addWidget(down_cap)
        mlay.addWidget(self._movers_down_lbl)
        mlay.addStretch(1)
        self._movers_card = movers_card

        # ── Root layout ─────────────────────────────────────────────
        top_row = QHBoxLayout()
        top_row.setContentsMargins(0, 0, 0, 0)
        top_row.setSpacing(8)
        top_row.addWidget(self._hero_card)
        top_row.addWidget(self._cat_card, stretch=1)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)
        root.addLayout(top_row)
        root.addWidget(self._movers_card)

    # ────────────────────────────────────────────────────────────────
    # Public API
    # ────────────────────────────────────────────────────────────────

    def update(self, v: MacroVerdict | None) -> None:
        """Render a verdict (``None`` → empty-state)."""
        if v is None:
            self._render_empty()
            return
        # Hero card.
        self._hero_label.setText(v.label)
        self._hero_label.setStyleSheet(
            f"color: {v.color}; font-family: '{FONT_MONO}'; "
            f"font-size: 18px; font-weight: 700; letter-spacing: 1px; "
            f"border: none; background: transparent;"
        )
        self._hero_strength.setText(v.strength)
        self._hero_strength.setStyleSheet(
            f"color: {v.strength_color}; font-family: '{FONT_MONO}'; "
            f"font-size: 9px; border: none; background: transparent;"
        )
        self._hero_reasons.setText(" · ".join(v.reasons) if v.reasons else "")

        # Category grid.
        for cs in v.by_category:
            name_lbl, z_lbl, detail_lbl = self._cat_rows[cs.category]
            if cs.total == 0 or cs.mean_z != cs.mean_z:    # NaN
                z_lbl.setText("—")
                z_lbl.setStyleSheet(
                    f"color: {MUTED}; font-family: '{FONT_MONO}'; "
                    f"font-size: 10px; font-weight: 700; "
                    f"border: none; background: transparent;"
                )
                detail_lbl.setText("no data")
                detail_lbl.setStyleSheet(
                    f"color: {MUTED}; font-family: '{FONT_MONO}'; "
                    f"font-size: 9px; border: none; background: transparent;"
                )
                continue
            arrow = self._arrow_for(cs.mean_z)
            z_lbl.setText(f"{cs.mean_z:+.2f}z {arrow}")
            z_lbl.setStyleSheet(
                f"color: {z_score_fg(cs.mean_z)}; font-family: '{FONT_MONO}'; "
                f"font-size: 10px; font-weight: 700; "
                f"border: none; background: transparent;"
            )
            detail_lbl.setText(self._cat_detail(cs))
            detail_lbl.setStyleSheet(
                f"color: {MUTED}; font-family: '{FONT_MONO}'; "
                f"font-size: 9px; border: none; background: transparent;"
            )

        # Movers.
        self._movers_up_lbl.setText(self._fmt_movers(v.movers_up))
        self._movers_down_lbl.setText(self._fmt_movers(v.movers_down))

    # ────────────────────────────────────────────────────────────────
    # Internals
    # ────────────────────────────────────────────────────────────────

    def _render_empty(self) -> None:
        self._hero_label.setText("—")
        self._hero_label.setStyleSheet(
            f"color: {MUTED}; font-family: '{FONT_MONO}'; font-size: 18px; "
            f"font-weight: 700; letter-spacing: 1px; border: none;"
        )
        self._hero_strength.setText("awaiting data")
        self._hero_reasons.setText("")
        for cat in _CAT_ORDER:
            _, z_lbl, detail_lbl = self._cat_rows[cat]
            z_lbl.setText("—")
            z_lbl.setStyleSheet(
                f"color: {MUTED}; font-family: '{FONT_MONO}'; "
                f"font-size: 10px; font-weight: 700; border: none;"
            )
            detail_lbl.setText("—")
        self._movers_up_lbl.setText("—")
        self._movers_down_lbl.setText("—")

    @staticmethod
    def _arrow_for(z: float) -> str:
        if z >= 1.5:
            return "↑↑"
        if z >= 0.5:
            return "↑"
        if z <= -1.5:
            return "↓↓"
        if z <= -0.5:
            return "↓"
        return "—"

    @staticmethod
    def _cat_detail(cs: CategoryStats) -> str:
        """e.g. '4/5 bullish', '0/5 · 4 bearish', '1/3 mixed'."""
        if cs.bulls >= cs.total - cs.bears and cs.bulls >= cs.total - 1 and cs.bulls > 0:
            return f"{cs.bulls}/{cs.total} bullish"
        if cs.bears > cs.bulls and cs.bears >= cs.total - 1 and cs.bears > 0:
            return f"{cs.bears}/{cs.total} bearish"
        if cs.bulls > 0 and cs.bears > 0:
            return f"{cs.bulls}↑ · {cs.bears}↓ of {cs.total}"
        if cs.bulls > 0:
            return f"{cs.bulls}/{cs.total} bullish"
        if cs.bears > 0:
            return f"{cs.bears}/{cs.total} bearish"
        return f"{cs.total} flat"

    @staticmethod
    def _fmt_movers(movers: tuple[tuple[str, float], ...]) -> str:
        if not movers:
            return "—"
        return "  ·  ".join(f"{t}  {z:+.1f}z" for t, z in movers)


def _fmt_z(z: float) -> str:
    if z != z:
        return "—"
    return f"{z:+.2f}"


def _fmt_pct(p: float) -> str:
    if p != p:
        return "—"
    return f"{p:+.2f}%"


def _fmt_price(p: float) -> str:
    if p != p:
        return "—"
    if p >= 1000:
        return f"{p:,.2f}"
    return f"{p:.4f}" if p < 10 else f"{p:.2f}"


#: Ordering used when sorting by the Stage column. Later in the
#: tuple = "later in the move"; gives a natural early-to-late sort
#: ascending. "—" is treated as "before EARLY" since it means "no
#: pattern identified yet", which reads as earliest-possible.
_STAGE_SORT_ORDER: tuple[str, ...] = (
    "—", "EARLY", "MID", "MATURE", "EXTENDED",
)


class _NumericItem(QTableWidgetItem):
    """Table item whose display is a pre-formatted string but whose
    sort key is a numeric value stored in UserRole.

    Without this, Qt sorts by the string (e.g. ``"+10.0%"`` before
    ``"+2.0%"`` because ``"1" < "2"`` lexicographically). Setting
    ``DisplayRole`` to a float works for sort but breaks the
    formatted text — so we keep the string as the display and stash
    the float for ordering purposes.

    NaN is handled explicitly: NaN values sort *after* every finite
    value in both directions. The convention here is "missing data
    sinks to the bottom", which matches the detector's own
    ``results.sort`` behaviour.
    """

    def __init__(self, text: str, sort_value: float) -> None:
        super().__init__(text)
        self.setData(Qt.ItemDataRole.UserRole, float(sort_value))

    def __lt__(self, other: "QTableWidgetItem") -> bool:  # noqa: D401
        try:
            a = float(self.data(Qt.ItemDataRole.UserRole))
        except (TypeError, ValueError):
            return super().__lt__(other)
        try:
            b = float(other.data(Qt.ItemDataRole.UserRole))
        except (TypeError, ValueError):
            return super().__lt__(other)
        # NaN treated as "smaller than any finite value". Default
        # sort is Flow DESCENDING, so this puts NaN at the bottom by
        # default (where unscorable instruments belong). On a manual
        # ascending flip, NaN rises to the top — which matches the
        # "worst first" interpretation.
        if a != a and b != b:
            return False
        if a != a:
            return True     # NaN < any finite value
        if b != b:
            return False    # no finite value is < NaN
        return a < b


class _StageItem(QTableWidgetItem):
    """Stage cell with lifecycle-ordered sort.

    Sorting by raw text would put EARLY < EXTENDED < MATURE < MID
    alphabetically, which is meaningless. This item sorts by the
    stage's position in ``_STAGE_SORT_ORDER`` so ascending gives the
    natural early→late progression.
    """

    def __init__(self, stage: str) -> None:
        super().__init__(stage)
        try:
            idx = _STAGE_SORT_ORDER.index(stage)
        except ValueError:
            idx = -1
        self.setData(Qt.ItemDataRole.UserRole, int(idx))

    def __lt__(self, other: "QTableWidgetItem") -> bool:  # noqa: D401
        try:
            a = int(self.data(Qt.ItemDataRole.UserRole))
            b = int(other.data(Qt.ItemDataRole.UserRole))
        except (TypeError, ValueError):
            return super().__lt__(other)
        return a < b


# ══════════════════════════════════════════════════════════════════════════════
# Panel
# ══════════════════════════════════════════════════════════════════════════════

#: Callable returning the latest commodity OHLCV panel (dict ticker→df).
PanelLoader = Callable[[], dict[str, pd.DataFrame]]


class MacroFlowPanel(QWidget):
    """Macro flow panel — inherits Emerald Slate from MainWindow.

    Dense table with one row per commodity. Columns:
      Symbol | Name | Category | Last | %1d | %5d | 10d z | 30d z | 60d z | Stage
    """

    instrument_selected = pyqtSignal(str)

    _COLUMNS = (
        ("Symbol",   80),
        ("Name",    160),    # stretched — absorbs all slack
        ("Category", 100),
        ("Last",     90),
        ("%1d",      70),
        ("%5d",      70),
        ("10d z",    70),
        ("30d z",    70),
        ("60d z",    70),
        ("Flow",     75),    # composite — signed avg-z across the 3 windows
        ("Stage",    95),    # badge fits in ~80px, 15px breathing room
        ("Tag",      85),    # REBOUND badge — mean-reversion signal
    )

    def __init__(
        self,
        panel_loader: PanelLoader | None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._panel_loader = panel_loader
        self._results: list[MacroFlowResult] = []
        self._active_category: CommodityCategory | None = None
        #: Vol regime from the last engine.analyze() call. "unknown"
        #: until the first refresh populates it. Read by the header-
        #: strip vol-regime badge.
        self._vol_regime: str = "unknown"
        #: Stateless engine instance. Holding a single instance is
        #: safe — FlowAnalyticsEngine has no mutable state. Threshold
        #: overrides can be set via constructor kwargs if ever needed.
        self._engine = FlowAnalyticsEngine()
        #: Auto-load guard — set to True on first ``showEvent`` so we
        #: don't re-fire the loader every time the tab comes into view.
        #: Users can still force a reload by calling ``refresh()``
        #: directly from code (e.g. a future keyboard shortcut).
        self._loader_attempted: bool = False

        # ── Header strip ────────────────────────────────────────────────
        title = QLabel("COMMODITY")
        title.setObjectName("nimbus-logo")

        self._asof_label = QLabel("—")
        self._asof_label.setObjectName("muted")
        self._asof_label.setFont(self._mono_font(10))

        #: Vol regime badge. Renders "VOL: CALM/NORMAL/VOLATILE" in
        #: the header strip, color-coded. Informs the operator when
        #: REBOUND tags are active (only fire in calm/normal regimes;
        #: never in volatile). Starts as "—" and fills in on first
        #: refresh().
        self._vol_regime_label = QLabel("—")
        self._vol_regime_label.setObjectName("muted")
        self._vol_regime_label.setFont(self._mono_font(10))

        self._status_label = QLabel(
            "no data loaded — loader not wired"
            if panel_loader is None
            else "ready — data will load when tab is shown"
        )
        self._status_label.setObjectName("muted")
        self._status_label.setFont(self._mono_font(10))

        header_row = QHBoxLayout()
        header_row.addWidget(title)
        header_row.addStretch(1)
        header_row.addWidget(self._vol_regime_label)
        header_row.addSpacing(12)
        header_row.addWidget(self._asof_label)

        # ── Verdict bar ─────────────────────────────────────────────────
        # Summary card + category heatmap + movers. Always computed from
        # the unfiltered result set so switching the category filter
        # below doesn't change the macro readout.
        self._verdict_bar = _VerdictBar()

        # ── Filter bar ──────────────────────────────────────────────────
        self._filter_buttons: dict[CommodityCategory | None, QPushButton] = {}
        self._filter_group = QButtonGroup(self)
        self._filter_group.setExclusive(True)
        filter_row = QHBoxLayout()

        for label, cat in (
            ("ALL",        None),
            ("PRECIOUS",   CommodityCategory.PRECIOUS),
            ("INDUSTRIAL", CommodityCategory.INDUSTRIAL),
            ("ENERGY",     CommodityCategory.ENERGY),
            ("AGRI",       CommodityCategory.AGRICULTURAL),
            ("LIVESTOCK",  CommodityCategory.LIVESTOCK),
        ):
            btn = self._make_filter_button(label, cat)
            self._filter_buttons[cat] = btn
            self._filter_group.addButton(btn)
            filter_row.addWidget(btn)
        self._filter_buttons[None].setChecked(True)

        filter_row.addStretch(1)

        # Refresh button removed — the panel now auto-loads on first
        # show via ``showEvent`` (see below). Manual refresh wasn't
        # doing useful work since the loader is idempotent and
        # cache-backed; keeping a button made the tab feel like it
        # required an action before anything useful happened.

        # ── Table ───────────────────────────────────────────────────────
        self._table = self._build_table()

        # ── Legend ──────────────────────────────────────────────────────
        legend = self._build_legend()

        # ── Root layout ─────────────────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(8)
        root.addLayout(header_row)
        root.addWidget(self._status_label)
        root.addWidget(self._verdict_bar)
        root.addLayout(filter_row)
        root.addWidget(self._table, stretch=1)
        root.addWidget(legend)

    # ══════════════════════════════════════════════════════════════════════
    # Public API
    # ══════════════════════════════════════════════════════════════════════

    def refresh(self) -> None:
        """Re-fetch the panel and recompute flows via the engine.

        Uses ``FlowAnalyticsEngine.analyze()`` rather than calling
        ``detect_flows`` + ``_compute_verdict`` directly. The engine
        layer adds:
          - per-instrument ``is_rebound`` enrichment (mean-reversion
            tag gated on the panel's vol regime)
          - panel-wide ``vol_regime`` classification (calm/normal/
            volatile/unknown)

        Both are rendered by the UI; see the Tag column in the table
        and the vol-regime badge in the header strip.
        """
        if self._panel_loader is None:
            return
        self._status_label.setText("loading panel …")
        self._status_label.repaint()
        try:
            panel = self._panel_loader()
        except Exception as exc:    # noqa: BLE001
            logger.exception("MacroFlowPanel.refresh: loader raised")
            QMessageBox.critical(
                self, "Macro Panel Refresh Failed",
                f"Could not load commodity panel:\n\n{exc}",
            )
            self._status_label.setText(f"error: {exc}")
            return

        try:
            bundle = self._engine.analyze(panel)
        except Exception as exc:    # noqa: BLE001
            logger.exception("MacroFlowPanel.refresh: engine.analyze raised")
            QMessageBox.critical(
                self, "Macro Panel Engine Failed",
                f"Flow engine raised:\n\n{exc}",
            )
            self._status_label.setText(f"engine error: {exc}")
            return

        self._results = list(bundle.results)
        self._vol_regime = bundle.vol_regime
        self._populate_table(self._filter_results())
        self._verdict_bar.update(bundle.verdict)
        self._update_vol_regime_label()
        self._update_status_after_refresh(panel, self._results)

    def set_panel_loader(self, loader: PanelLoader | None) -> None:
        """Swap the loader at runtime.

        If the panel is currently visible when a loader is attached,
        trigger an immediate auto-load so the operator doesn't have
        to re-enter the tab. The ``_loader_attempted`` flag is reset
        so the new loader gets its chance to fire on the next show
        event in the case where the tab isn't currently visible.
        """
        self._panel_loader = loader
        if loader is None:
            self._status_label.setText("no data loaded — loader disconnected")
            self._table.setRowCount(0)
            self._verdict_bar.update(None)
            self._loader_attempted = False
        else:
            # Reset so the new loader gets auto-fired on next show.
            self._loader_attempted = False
            if self.isVisible():
                self._status_label.setText("loading panel …")
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(50, self._run_loader_safely)
            else:
                self._status_label.setText(
                    "ready — data will load when tab is shown",
                )

    def showEvent(self, event) -> None:    # noqa: N802
        """Auto-load on first show.

        Matches the Market Pulse pattern: the first time the tab
        comes into view, if a loader is wired and we haven't already
        attempted to load, kick the loader. Subsequent shows are no-
        ops so flipping between tabs doesn't refetch every time.
        """
        super().showEvent(event)
        if (
            self._panel_loader is not None
            and not self._loader_attempted
        ):
            self._loader_attempted = True
            self._status_label.setText("loading panel …")
            self._status_label.repaint()
            # Defer one event-loop tick so the 'loading' message
            # paints before yfinance fetches start — otherwise the
            # tab freezes with its previous content during the load.
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(50, self._run_loader_safely)

    def _run_loader_safely(self) -> None:
        """Invoke :meth:`refresh` with error containment.

        ``refresh`` already handles its own exception flow (shows a
        QMessageBox + status-label text). This wrapper exists purely
        as the single-shot target so ``showEvent`` can return cleanly
        before the heavy work runs.
        """
        try:
            self.refresh()
        except Exception:    # noqa: BLE001
            logger.exception("MacroFlowPanel: auto-load failed")
            # refresh() already surfaces errors to the status label;
            # this except block is defence-in-depth.

    # ══════════════════════════════════════════════════════════════════════
    # Filter
    # ══════════════════════════════════════════════════════════════════════

    def _on_filter_clicked(self, category: CommodityCategory | None) -> None:
        self._active_category = category
        self._populate_table(self._filter_results())

    def _filter_results(self) -> list[MacroFlowResult]:
        if self._active_category is None:
            return self._results
        return [r for r in self._results if r.category == self._active_category]

    # ══════════════════════════════════════════════════════════════════════
    # Construction helpers
    # ══════════════════════════════════════════════════════════════════════

    @staticmethod
    def _mono_font(size: int = 10) -> QFont:
        f = QFont(FONT_MONO)
        f.setStyleHint(QFont.StyleHint.TypeWriter)
        f.setPointSize(size)
        return f

    def _make_filter_button(
        self, label: str, category: CommodityCategory | None,
    ) -> QPushButton:
        btn = QPushButton(label)
        btn.setCheckable(True)
        btn.setSizePolicy(
            QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed,
        )
        btn.clicked.connect(lambda _checked, c=category: self._on_filter_clicked(c))
        return btn

    def _build_table(self) -> QTableWidget:
        table = QTableWidget(0, len(self._COLUMNS))
        table.setHorizontalHeaderLabels([h for h, _ in self._COLUMNS])
        for i, (_, w) in enumerate(self._COLUMNS):
            table.setColumnWidth(i, w)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setAlternatingRowColors(True)
        table.setShowGrid(False)
        table.setFont(self._mono_font(10))
        table.horizontalHeader().setStretchLastSection(False)
        # Default: every column is user-draggable (Interactive). Prior
        # ResizeToContents locked column widths to the widest cell
        # which felt rigid — users couldn't narrow the Category
        # column to make more room for Name, for example.
        table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Interactive,
        )
        # Name (idx 1) absorbs remaining slack — commodity names vary
        # in length ("Cotton" vs "RBOB Gasoline" vs "Soybean Oil"), so
        # giving them room to render on one line is worth the stretch.
        table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeMode.Stretch,
        )
        # Symbol (idx 0) fixed — always 4-char futures tickers, no
        # reason to let the operator waste UI real-estate on it.
        table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Fixed,
        )
        table.setColumnWidth(0, 70)
        # Sorting on. Default sort set after each _populate_table call
        # so the data-order signal ("biggest Flow first") is always
        # the initial view even when a fresh dataset arrives.
        table.setSortingEnabled(True)
        table.itemSelectionChanged.connect(self._on_row_selected)
        return table

    def _build_legend(self) -> QWidget:
        legend = QWidget()
        layout = QHBoxLayout(legend)
        layout.setContentsMargins(0, 0, 0, 0)

        items = [
            ("|z| ≥ 2", EM),
            ("|z| ≥ 1", GREEN),
            ("|z| < 1", MUTED),
            ("|z| ≥ 1 ↓", GOLD),
            ("|z| ≥ 2 ↓", RED),
        ]
        for label, color in items:
            swatch = QLabel("■")
            swatch.setStyleSheet(f"color: {color}; font-size: 14px;")
            text = QLabel(label)
            text.setObjectName("muted")
            text.setFont(self._mono_font(9))
            layout.addWidget(swatch)
            layout.addWidget(text)
            layout.addSpacing(8)
        layout.addStretch(1)
        return legend

    # ══════════════════════════════════════════════════════════════════════
    # Population
    # ══════════════════════════════════════════════════════════════════════

    def _populate_table(self, results: list[MacroFlowResult]) -> None:
        # Turn sorting off while inserting — otherwise each insert
        # triggers a re-sort and the (row, col) indices used in
        # _set_row become stale partway through population.
        self._table.setSortingEnabled(False)
        self._table.setRowCount(0)
        for i, r in enumerate(results):
            self._table.insertRow(i)
            self._set_row(i, r)
        self._table.setSortingEnabled(True)
        # Default sort: Flow descending — biggest bullish composite
        # floats to the top, biggest bearish to the bottom, NaN at
        # the very bottom regardless of direction.
        flow_col = self._column_index("Flow")
        self._table.sortByColumn(flow_col, Qt.SortOrder.DescendingOrder)

    def _column_index(self, header: str) -> int:
        """Locate a column by its header string. Returns -1 if absent.

        Helper so column-position code doesn't hard-code numeric
        indices that would silently drift if ``_COLUMNS`` is ever
        reordered.
        """
        for i, (h, _w) in enumerate(self._COLUMNS):
            if h == header:
                return i
        return -1

    def _set_row(self, row: int, r: MacroFlowResult) -> None:
        instr = r.instrument

        self._set_cell(row, 0, instr.ticker, color=WHITE, bold=True)
        self._set_cell(row, 1, instr.name, color=WHITE)
        self._set_cell(
            row, 2, instr.category.value,
            color=CATEGORY_COLORS.get(instr.category, MUTED),
        )

        # Last price — numeric sort on float value, text display with
        # instrument-appropriate precision.
        self._set_numeric_cell(
            row, 3, _fmt_price(r.close_price), r.close_price,
            color=WHITE, bold=False,
        )

        self._set_numeric_cell(
            row, 4, _fmt_pct(r.pct_change_1d), r.pct_change_1d,
            color=pct_change_fg(r.pct_change_1d),
        )
        self._set_numeric_cell(
            row, 5, _fmt_pct(r.pct_change_5d), r.pct_change_5d,
            color=pct_change_fg(r.pct_change_5d),
        )

        self._set_numeric_cell(
            row, 6, _fmt_z(r.price_z_10d), r.price_z_10d,
            color=z_score_fg(r.price_z_10d), bold=True,
        )
        self._set_numeric_cell(
            row, 7, _fmt_z(r.price_z_30d), r.price_z_30d,
            color=z_score_fg(r.price_z_30d), bold=True,
        )
        self._set_numeric_cell(
            row, 8, _fmt_z(r.price_z_60d), r.price_z_60d,
            color=z_score_fg(r.price_z_60d), bold=True,
        )

        # Flow = signed avg-z across the 3 windows. Computed via the
        # engine's _avg_z staticmethod — same value used internally
        # for regime classification, exposed here as a per-instrument
        # column. Positive = bullish conviction, negative = bearish,
        # magnitude = cross-window agreement.
        flow = FlowAnalyticsEngine._avg_z(r)
        flow_val = flow if flow is not None else float("nan")
        self._set_numeric_cell(
            row, 9, _fmt_z(flow_val), flow_val,
            color=z_score_fg(flow_val), bold=True,
        )

        # Stage cell rendered as an inline badge using the stage-style triple.
        stage_label = r.stage_label.upper() if r.stage_label != "—" else "—"
        self._set_stage_cell(row, 10, stage_label)

        # Tag cell — REBOUND badge when the mean-reversion signal is
        # firing, em-dash otherwise. Plain text (same rendering style
        # as the Stage cell — see _set_stage_cell docstring for why
        # pills don't render cleanly at this size).
        if r.is_rebound:
            self._set_cell(
                row, 11, "REBOUND",
                color=BLUE, bold=True,
            )
        else:
            self._set_cell(row, 11, "—", color=MUTED, bold=False)

    def _set_stage_cell(self, row: int, col: int, stage: str) -> None:
        """Stage cell — plain coloured text with lifecycle-ordered sort.

        Earlier versions used a filled pill widget via ``badge_qss``;
        at 10px with the Qt raster the pill edges produced a 'boxy
        EXTENDED / MATURE' look where borders caught aliasing and
        bled into adjacent text. Flat coloured text reads cleaner
        against the dark alternating row shading and still encodes
        the stage via ``STAGE_STYLES`` foreground colour.

        Uses ``_StageItem`` so sorting by the Stage column walks the
        lifecycle (— → EARLY → MID → MATURE → EXTENDED) rather than
        the alphabet.
        """
        if stage == "—":
            style = STAGE_STYLES["—"]
            fg = style.get("text", MUTED) if isinstance(style, dict) else MUTED
        else:
            style = STAGE_STYLES.get(stage, STAGE_STYLES["—"])
            fg = style.get("text", WHITE) if isinstance(style, dict) else WHITE

        item = _StageItem(stage)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        item.setForeground(QBrush(QColor(fg)))
        item.setTextAlignment(
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
        )
        f = self._mono_font(10)
        if stage != "—":
            f.setBold(True)
        item.setFont(f)
        self._table.setItem(row, col, item)

    def _set_cell(
        self,
        row: int, col: int, text: str,
        *, color: str = WHITE,
        align_right: bool = False, bold: bool = False,
    ) -> None:
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        item.setForeground(QBrush(QColor(color)))
        flags = Qt.AlignmentFlag.AlignVCenter
        flags |= (
            Qt.AlignmentFlag.AlignRight if align_right
            else Qt.AlignmentFlag.AlignLeft
        )
        item.setTextAlignment(flags)
        f = self._mono_font(10)
        if bold:
            f.setBold(True)
        item.setFont(f)
        self._table.setItem(row, col, item)

    def _set_numeric_cell(
        self,
        row: int, col: int, text: str, sort_value: float,
        *, color: str = WHITE, bold: bool = False,
    ) -> None:
        """Numeric cell: formatted string for display, float for sort.

        Always right-aligned so decimal points line up vertically —
        a monospace font alone isn't enough because negative signs
        and percent suffixes throw off column alignment without
        right-justification.
        """
        item = _NumericItem(text, sort_value)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        item.setForeground(QBrush(QColor(color)))
        item.setTextAlignment(
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight,
        )
        f = self._mono_font(10)
        if bold:
            f.setBold(True)
        item.setFont(f)
        self._table.setItem(row, col, item)

    def _update_vol_regime_label(self) -> None:
        """Refresh the vol-regime badge text + color from
        ``self._vol_regime``.

        Color mapping matches theme semantics:
          - calm     → EM   (green — mean-reversion trades are safe here)
          - normal   → WHITE (neutral)
          - volatile → RED  (REBOUND tag suppressed in this regime)
          - unknown  → MUTED (insufficient history)

        Rendered as ``VOL: {REGIME}`` so the operator can tell at a
        glance whether the REBOUND tag is active at all.
        """
        regime = self._vol_regime
        if regime == "calm":
            text, color = "VOL: CALM", EM
        elif regime == "normal":
            text, color = "VOL: NORMAL", WHITE
        elif regime == "volatile":
            text, color = "VOL: VOLATILE", RED
        else:
            text, color = "VOL: —", MUTED
        self._vol_regime_label.setText(text)
        self._vol_regime_label.setStyleSheet(
            f"color: {color}; background: transparent;"
        )

    def _update_status_after_refresh(
        self, panel: dict, results: list[MacroFlowResult],
    ) -> None:
        n_universe = len(COMMODITY_UNIVERSE)
        n_loaded = len(panel)
        n_results = len(results)

        if results:
            asof = max(r.asof_date for r in results)
            self._asof_label.setText(f"asof  {asof.date()}")
        else:
            self._asof_label.setText("—")

        if n_results == 0:
            msg = (
                f"loaded {n_loaded}/{n_universe} instruments — "
                f"detector produced 0 results"
            )
        else:
            n_strong = sum(1 for r in results if r.max_abs_z >= 2.0)
            msg = (
                f"loaded {n_loaded}/{n_universe} instruments — "
                f"{n_results} computed — {n_strong} at |z| ≥ 2"
            )
        self._status_label.setText(msg)

    def _on_row_selected(self) -> None:
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return
        row = rows[0].row()
        ticker_item = self._table.item(row, 0)
        if ticker_item is not None:
            self.instrument_selected.emit(ticker_item.text())
