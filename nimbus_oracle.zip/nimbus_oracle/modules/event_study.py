"""
modules/event_study.py — Forward-return event study engine.

Given a price series and event dates, measures what happened N days later.
Pure logic — no UI, no charting.

Usage:
    from modules.event_study import compute_forward_returns, detect_vix_spike

    events = detect_vix_spike(vix_df, threshold=25)
    table  = compute_forward_returns(nifty_df["Close"], events)
    # table is a DataFrame: rows = event dates, cols = horizons (1d, 2d, 1w, ...)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# RESULT
# ══════════════════════════════════════════════════════════════════════════════

# Default forward horizons (trading days)
DEFAULT_HORIZONS = {
    "1D": 1,
    "2D": 2,
    "3D": 3,
    "4D": 4,
    "1W": 5,
    "2W": 10,
    "3W": 15,
    "1M": 21,
    "2M": 42,
    "3M": 63,
}


@dataclass
class EventStudyResult:
    """Complete event study output."""
    title: str = ""
    subtitle: str = ""
    event_dates: list = field(default_factory=list)
    returns_df: Optional[pd.DataFrame] = None  # rows=dates, cols=horizons
    avg_returns: Optional[pd.Series] = None
    pct_positive: Optional[pd.Series] = None
    max_loss: Optional[pd.Series] = None
    price_series: Optional[pd.Series] = None   # for chart
    indicator_series: Optional[pd.Series] = None  # for chart (VIX, streak, etc.)
    indicator_label: str = ""
    threshold: Optional[float] = None
    n_events: int = 0


# ══════════════════════════════════════════════════════════════════════════════
# FORWARD RETURNS
# ══════════════════════════════════════════════════════════════════════════════

def compute_forward_returns(
    prices: pd.Series,
    event_dates: list,
    horizons: Optional[dict] = None,
) -> EventStudyResult:
    """
    Compute forward returns for each event date at each horizon.

    Args:
        prices: Daily close price series (DatetimeIndex)
        event_dates: List of dates/timestamps when the event fired
        horizons: Dict of {"label": trading_days} e.g. {"1W": 5, "1M": 21}

    Returns:
        EventStudyResult with returns_df, avg_returns, pct_positive
    """
    if horizons is None:
        horizons = DEFAULT_HORIZONS

    r = EventStudyResult()
    r.price_series = prices
    r.event_dates = sorted(event_dates)

    if not event_dates or prices.empty:
        return r

    # Normalize dates and ensure timezone-naive for matching
    prices = prices.copy()
    if hasattr(prices.index, 'tz') and prices.index.tz is not None:
        prices.index = prices.index.tz_localize(None)
    rows = []

    for evt_date in event_dates:
        evt_ts = pd.Timestamp(evt_date).normalize()
        if hasattr(evt_ts, 'tz') and evt_ts.tz is not None:
            evt_ts = evt_ts.tz_localize(None)
        # Find the closest trading day on or after event date
        valid = prices.index[prices.index >= evt_ts]
        if len(valid) == 0:
            continue
        match_date = valid[0]
        loc = prices.index.get_loc(match_date)
        if isinstance(loc, slice):
            loc = loc.start
        base_price = float(prices.iloc[loc])

        row = {"date": evt_ts}
        for label, days in horizons.items():
            fwd_loc = loc + days
            if fwd_loc < len(prices):
                fwd_price = float(prices.iloc[fwd_loc])
                row[label] = (fwd_price / base_price - 1) * 100
            else:
                row[label] = np.nan
        rows.append(row)

    if not rows:
        return r

    df = pd.DataFrame(rows).set_index("date")
    r.returns_df = df
    r.n_events = len(df)

    horizon_cols = [c for c in df.columns if c in horizons]
    r.avg_returns = df[horizon_cols].mean()
    r.pct_positive = (df[horizon_cols] > 0).mean() * 100
    r.max_loss = df[horizon_cols].min()

    return r


# ══════════════════════════════════════════════════════════════════════════════
# EVENT DETECTORS
# ══════════════════════════════════════════════════════════════════════════════

def _ensure_series(data, col="Close") -> pd.Series:
    """Ensure we have a Series, not a DataFrame."""
    if isinstance(data, pd.DataFrame):
        if isinstance(data.columns, pd.MultiIndex):
            data.columns = data.columns.get_level_values(0)
        if col in data.columns:
            s = data[col]
        else:
            s = data.iloc[:, 0]
        return s.dropna() if isinstance(s, pd.Series) else s.iloc[:, 0].dropna()
    return data.dropna()


def detect_vix_spike(
    vix_series: pd.Series,
    threshold: float = 25.0,
    cooldown_days: int = 20,
) -> list:
    """
    Find dates where VIX crosses ABOVE threshold (first cross only, not every day above).
    Cooldown prevents multiple signals from the same spike.
    """
    vix_series = _ensure_series(vix_series)
    above = vix_series > threshold
    # First day above after being below
    crosses = above & (~above.shift(1, fill_value=False))
    dates = vix_series.index[crosses].tolist()
    return _apply_cooldown(dates, cooldown_days)


def detect_consecutive_red_days(
    prices: pd.DataFrame,
    n_days: int = 5,
    cooldown_days: int = 10,
) -> list:
    """Find dates where price has been down N consecutive days."""
    c = _ensure_series(prices, "Close")
    red = (c < c.shift(1)).astype(int)
    streak = red.groupby((red != red.shift()).cumsum()).cumsum()
    dates = streak[streak >= n_days].index.tolist()
    # Take the first day the streak hits N (not every subsequent day)
    first_hits = []
    for d in dates:
        loc = streak.index.get_loc(d)
        if loc > 0 and int(streak.iloc[loc - 1]) < n_days:
            first_hits.append(d)
    return _apply_cooldown(first_hits, cooldown_days)


def detect_drawdown_breach(
    prices: pd.DataFrame,
    threshold_pct: float = -10.0,
    lookback: int = 50,
    cooldown_days: int = 30,
) -> list:
    """Find dates where drawdown from lookback high first breaches threshold."""
    c = _ensure_series(prices, "Close")
    h = _ensure_series(prices, "High").rolling(lookback, min_periods=20).max()
    dd = (c / h - 1) * 100
    below = dd < threshold_pct
    crosses = below & (~below.shift(1, fill_value=False))
    dates = dd.index[crosses].tolist()
    return _apply_cooldown(dates, cooldown_days)


def detect_pcr_spike(
    pcr_series: pd.Series,
    threshold: float = 1.1,
    cooldown_days: int = 10,
) -> list:
    """Find dates where put/call ratio crosses above threshold."""
    pcr_series = _ensure_series(pcr_series)
    above = pcr_series > threshold
    crosses = above & (~above.shift(1, fill_value=False))
    dates = pcr_series.index[crosses].tolist()
    return _apply_cooldown(dates, cooldown_days)


# ══════════════════════════════════════════════════════════════════════════════
# PRESETS
# ══════════════════════════════════════════════════════════════════════════════

PRESETS = {
    "vix_25": {
        "title": "NIFTY after India VIX crosses above 25",
        "subtitle": "First cross above 25 (20-day cooldown)",
        "indicator_label": "India VIX",
    },
    "vix_30": {
        "title": "NIFTY after India VIX crosses above 30",
        "subtitle": "First cross above 30 (20-day cooldown)",
        "indicator_label": "India VIX",
    },
    "red_5d": {
        "title": "NIFTY after 5 consecutive red days",
        "subtitle": "5+ consecutive daily declines",
        "indicator_label": "Consecutive red days",
    },
    "red_7d": {
        "title": "NIFTY after 7 consecutive red days",
        "subtitle": "7+ consecutive daily declines",
        "indicator_label": "Consecutive red days",
    },
    "dd_10": {
        "title": "NIFTY after 10% drawdown from 50-day high",
        "subtitle": "First breach of -10% from rolling 50d high",
        "indicator_label": "Drawdown from 50d high (%)",
    },
    "dd_15": {
        "title": "NIFTY after 15% drawdown from 50-day high",
        "subtitle": "First breach of -15% from rolling 50d high",
        "indicator_label": "Drawdown from 50d high (%)",
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _apply_cooldown(dates: list, cooldown_days: int) -> list:
    """Remove events that are within cooldown_days of the previous event."""
    if not dates:
        return dates
    filtered = [dates[0]]
    for d in dates[1:]:
        if (pd.Timestamp(d) - pd.Timestamp(filtered[-1])).days >= cooldown_days:
            filtered.append(d)
    return filtered
