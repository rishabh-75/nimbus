# RT-003 · Industry score recalibration (breadth-scaled, ADTV-weighted)

| Field        | Value                                                       |
|--------------|-------------------------------------------------------------|
| Date         | 2026-06-01                                                  |
| Status       | `validated`                                                 |
| Outcome      | Replaced the synthetic-index industry Score with a member-aggregate; added a Riding count column. |
| Baked into   | `compute/industry_rollup.py`, `ui/widgets/industry_tables.py` |
| Data window  | Live panel (per-symbol ride cache + 20-bar ADTV)            |

## Question

The Industries table's Score was the ride score of a *synthetic peer
index* (`classify_industry`). Operator wanted it to instead reflect how
much of the industry is actually riding, weighted by liquidity and
individual conviction — and to see the raw count of riding members.

## Methodology

Per industry, over members present in the panel:

- **Riding** = count of members whose latest ride phase != NONE
  (any phase — INIT/RETEST/CONT all count).
- **Score** (operator-chosen option 2 — breadth-scaled ADTV-weighted
  mean of riders' scores):

      riders         = members with latest phase != NONE
      weighted_mean  = Σ(score_i · adtv_i) / Σ(adtv_i)   over riders
      breadth        = riders / members_with_data
      industry_score = breadth · weighted_mean

The Phase column is unchanged (still the synthetic-index roll-up). All
arithmetic lives in a stateless `aggregate_industry()`; the table widget
only renders — preserving the single-source-of-truth rule.

## Key code

```python
# compute/industry_rollup.py (essence)
for sym in present:
    adtv = _member_adtv(panel[sym])
    res = symbol_results.get(sym)
    if res is None or res.latest_phase is RidePhase.NONE:
        continue
    riders += 1
    if res.latest_score == res.latest_score and adtv == adtv:
        weighted_score_sum += res.latest_score * adtv
        rider_adtv_sum += adtv
score = (riders / len(present)) * (weighted_score_sum / rider_adtv_sum)
```

## Results

Verified on the four reference symbols across synthetic industries:

| Industry  | Riding | Score | Note                                  |
|-----------|--------|-------|---------------------------------------|
| FMCG      | 1 / 1  | 41    | AWL RETEST 40.9, sole member          |
| Pharma    | 2 / 2  | 37    | CIPLA 36.3 + SUNPHARMA 36.7, ADTV-wtd |
| Chemicals | 1 / 1  | 27    | CLEAN 26.9                            |

Breadth penalty confirmed in unit tests: same liquid score-80 rider in
two industries → the one where more members ride scores strictly higher.

## Conclusion & decision

Adopted. The industry Score now answers "how much of this industry,
weighted by liquidity and conviction, is riding?" rather than "is the
synthetic index riding?". Riding count surfaced as its own column.
