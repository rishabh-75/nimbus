"""tests.ui.test_industry_tables — IndustriesTable + ConstituentsTable
unit tests.

Smoke-tests for the slim tables embedded in the unified Dashboard
bottom strip. Covers:
  - construction + clear
  - Industries refresh: ALL row pinned, member counts, ADTV sum
  - selection signal emission
  - Constituents set_industry rendering with the full column set
  - %B / Vol / ROC colour rules
  - double-click activation signal
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.ui.theme import EM, GOLD, GREEN, MUTED, RED, WHITE
from nimbus_v3.ui.widgets.formatters import format_adtv_m as _format_adtv_m
from nimbus_v3.ui.widgets.industry_tables import (
    CONSTITUENT_COLUMNS,
    INDUSTRY_COLUMNS,
    ConstituentsTable,
    IndustriesTable,
)


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════════════


def _enriched(seed: int, n: int = 250) -> pd.DataFrame:
    """Build a 250-bar enriched OHLCV frame from a seeded random walk."""
    rng = np.random.default_rng(seed)
    close = 100 + np.cumsum(rng.normal(0.05, 1.0, n))
    df = pd.DataFrame(
        {
            "Open":   close * 0.998,
            "High":   close * 1.005,
            "Low":    close * 0.995,
            "Close":  close,
            "Volume": rng.integers(1_000_000, 5_000_000, n).astype(float),
        },
        index=pd.bdate_range("2024-01-01", periods=n),
    )
    return StrategyComputeEngine().enrich(df, f"S{seed}")


def _make_panel(symbols_per_industry: dict[str, list[str]]) -> tuple[dict, Universe]:
    panel: dict[str, pd.DataFrame] = {}
    meta: dict[str, SymbolMeta] = {}
    seed = 0
    for industry, syms in symbols_per_industry.items():
        for sym in syms:
            panel[sym] = _enriched(seed)
            meta[sym] = SymbolMeta(
                symbol=sym,
                industry=industry,
                basic_industry=f"Sub-{industry}",
            )
            seed += 1
    universe = Universe(
        symbols=meta, built_at=pd.Timestamp.now("UTC"),
    )
    return panel, universe


# ══════════════════════════════════════════════════════════════════════════════
# Column definitions
# ══════════════════════════════════════════════════════════════════════════════


class TestColumns:
    def test_industry_columns_are_group_adtv_riding(self):
        assert INDUSTRY_COLUMNS == ("Group", "ADTV", "Riding")

    def test_constituent_columns_full_set(self):
        # Per the user spec — Industries gets the slim 4 columns;
        # Constituents keeps the full per-symbol context. Three
        # change columns: Chg (1-bar), Chg 5d%, Chg 10d%.
        assert "Symbol" in CONSTITUENT_COLUMNS
        assert "Industry" in CONSTITUENT_COLUMNS
        for c in ("Chg", "Chg 5d%", "Chg 10d%", "%B", "Vol", "BBW"):
            assert c in CONSTITUENT_COLUMNS, (
                f"{c!r} expected in constituent columns"
            )
        assert "Phase" in CONSTITUENT_COLUMNS
        assert "Score" in CONSTITUENT_COLUMNS

    def test_constituent_has_above_and_streak_columns(self):
        # Body-above-band flag + consecutive-bars streak, both
        # phase-independent.
        assert "Above" in CONSTITUENT_COLUMNS
        assert "Streak" in CONSTITUENT_COLUMNS

    def test_constituent_columns_chg_after_adtv(self):
        # 1-bar Chg sits immediately after ADTV — that's the
        # operator's first read after liquidity context: did this
        # symbol move today?
        cols = list(CONSTITUENT_COLUMNS)
        assert cols.index("Chg") == cols.index("ADTV") + 1


# ══════════════════════════════════════════════════════════════════════════════
# IndustriesTable
# ══════════════════════════════════════════════════════════════════════════════


class TestIndustriesTable:

    def test_constructs_empty(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        assert t._table.rowCount() == 0
        assert t._table.columnCount() == len(INDUSTRY_COLUMNS)

    def test_clear_resets(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B", "C"],
            "Banks":     ["X", "Y"],
        })
        t.refresh(panel, universe)
        assert t._table.rowCount() > 0
        t.clear()
        assert t._table.rowCount() == 0

    def test_refresh_with_no_panel(self, qapp):    # noqa: ARG002
        """Empty panel → empty table, no exceptions."""
        t = IndustriesTable()
        t.refresh({}, None)
        assert t._table.rowCount() == 0

    def test_refresh_groups_by_industry(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B", "C"],
            "Banks":     ["X", "Y"],
        })
        t.refresh(panel, universe)
        # 2 industries + 1 ALL row.
        assert t._table.rowCount() == 3

    def test_all_row_pinned_at_top(self, qapp):    # noqa: ARG002
        """The ALL row must always be the first row regardless of sort
        — it's an aggregate, not a peer to be ranked."""
        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B", "C"],
            "Banks":     ["X", "Y"],
        })
        t.refresh(panel, universe)
        first_row_text = t._table.item(0, 0).text()
        assert first_row_text == "ALL"

    def test_all_row_renders_with_emerald_text(self, qapp):    # noqa: ARG002
        """ALL row uses EM colour to set it apart from regular industries."""
        from PyQt6.QtGui import QColor

        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B", "C"],
            "Banks":     ["X", "Y"],
        })
        t.refresh(panel, universe)
        all_cell = t._table.item(0, 0)
        assert all_cell.text() == "ALL"
        assert all_cell.foreground().color() == QColor(EM)

    def test_adtv_format_uses_thousands_M(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        panel, universe = _make_panel({"Petroleum": ["A", "B", "C", "D"]})
        t.refresh(panel, universe)
        adtv_col = INDUSTRY_COLUMNS.index("ADTV")
        # Find the Petroleum row and verify its ADTV cell ends with " M".
        for r in range(t._table.rowCount()):
            if t._table.item(r, 0).text() == "Petroleum":
                text = t._table.item(r, adtv_col).text()
                assert text.endswith(" M") or text == "—", text
                break
        else:
            pytest.fail("Petroleum row not found")

    def test_members_for_returns_industry_members(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B", "C"],
            "Banks":     ["X", "Y"],
        })
        t.refresh(panel, universe)
        assert sorted(t.members_for("Petroleum")) == ["A", "B", "C"]
        assert sorted(t.members_for("Banks")) == ["X", "Y"]
        assert t.members_for("Unknown") == []

    def test_members_for_all_returns_full_panel(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B"],
            "Banks":     ["X"],
        })
        t.refresh(panel, universe)
        all_members = sorted(t.members_for("ALL"))
        assert all_members == ["A", "B", "X"]

    def test_industry_selected_signal_emits_on_row_click(self, qapp):    # noqa: ARG002
        t = IndustriesTable()
        panel, universe = _make_panel({
            "Petroleum": ["A", "B", "C"],
            "Banks":     ["X", "Y"],
        })
        t.refresh(panel, universe)

        captured: list[str] = []
        t.industry_selected.connect(captured.append)

        # Find the Banks row (skip ALL pinned at top), select it.
        target_row = None
        for r in range(t._table.rowCount()):
            if t._table.item(r, 0).text() == "Banks":
                target_row = r
                break
        assert target_row is not None
        t._table.selectRow(target_row)

        assert "Banks" in captured

    def test_refresh_with_unknown_industry_groups_under_unknown(self, qapp):    # noqa: ARG002
        """A symbol whose universe meta has empty industry should
        still appear in the panel under an 'Unknown' bucket."""
        meta = {
            "ORPHAN": SymbolMeta(symbol="ORPHAN", industry=""),
            "A":      SymbolMeta(symbol="A", industry="Banks"),
            "B":      SymbolMeta(symbol="B", industry="Banks"),
        }
        universe = Universe(symbols=meta, built_at=pd.Timestamp.now("UTC"))
        panel = {sym: _enriched(i) for i, sym in enumerate(meta)}

        t = IndustriesTable()
        t.refresh(panel, universe)
        groups = {
            t._table.item(r, 0).text() for r in range(t._table.rowCount())
        }
        assert "Unknown" in groups
        assert "Banks" in groups


# ══════════════════════════════════════════════════════════════════════════════
# ConstituentsTable
# ══════════════════════════════════════════════════════════════════════════════


class TestConstituentsTable:

    def test_constructs_empty(self, qapp):    # noqa: ARG002
        c = ConstituentsTable()
        assert c._table.rowCount() == 0
        assert c._table.columnCount() == len(CONSTITUENT_COLUMNS)

    def test_clear_resets(self, qapp):    # noqa: ARG002
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A", "B", "C"]})
        c.set_industry("Petroleum", ["A", "B", "C"], panel, universe)
        assert c._table.rowCount() > 0
        c.clear()
        assert c._table.rowCount() == 0

    def test_set_industry_renders_one_row_per_member(self, qapp):    # noqa: ARG002
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A", "B", "C", "D"]})
        c.set_industry("Petroleum", ["A", "B", "C", "D"], panel, universe)
        assert c._table.rowCount() == 4

    def test_set_industry_skips_missing_panel_members(self, qapp):    # noqa: ARG002
        """Members not in the panel are silently dropped — no
        placeholder row, no exception."""
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A", "B"]})
        c.set_industry("Petroleum", ["A", "B", "GHOST"], panel, universe)
        assert c._table.rowCount() == 2

    def test_industry_column_populated_from_universe(self, qapp):    # noqa: ARG002
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A", "B"]})
        c.set_industry("Petroleum", ["A", "B"], panel, universe)
        ind_col = CONSTITUENT_COLUMNS.index("Industry")
        for r in range(c._table.rowCount()):
            assert "Sub-Petroleum" in c._table.item(r, ind_col).text()

    def test_industry_column_em_dash_when_no_universe(self, qapp):    # noqa: ARG002
        """When universe is None, Industry renders as em-dash —
        graceful degradation, no exception."""
        c = ConstituentsTable()
        panel, _ = _make_panel({"Petroleum": ["A", "B"]})
        c.set_industry("Petroleum", ["A", "B"], panel, universe=None)
        ind_col = CONSTITUENT_COLUMNS.index("Industry")
        for r in range(c._table.rowCount()):
            assert c._table.item(r, ind_col).text() == "—"

    def test_metric_columns_populate(self, qapp):    # noqa: ARG002
        """All numeric columns surface a value (not em-dash) for a
        symbol with full enriched history."""
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A"]})
        c.set_industry("Petroleum", ["A"], panel, universe)

        for col_name in (
            "ADTV", "Chg", "Chg 5d%", "Chg 10d%", "%B", "Vol", "BBW",
        ):
            col_idx = CONSTITUENT_COLUMNS.index(col_name)
            text = c._table.item(0, col_idx).text()
            assert text != "—", (
                f"{col_name} expected a value, got em-dash"
            )

    def test_chg_format_carries_sign(self, qapp):    # noqa: ARG002
        """All three Chg columns format with a +/- prefix so direction
        is visible at a glance even with monospace fonts."""
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A"]})
        c.set_industry("Petroleum", ["A"], panel, universe)
        for col_name in ("Chg", "Chg 5d%", "Chg 10d%"):
            col_idx = CONSTITUENT_COLUMNS.index(col_name)
            text = c._table.item(0, col_idx).text()
            assert text.startswith("+") or text.startswith("-"), (
                f"{col_name}: expected +/- prefix, got {text!r}"
            )

    def test_vol_format_has_x_suffix(self, qapp):    # noqa: ARG002
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A"]})
        c.set_industry("Petroleum", ["A"], panel, universe)
        vol_col = CONSTITUENT_COLUMNS.index("Vol")
        text = c._table.item(0, vol_col).text()
        assert text.endswith("x") or text == "—", text

    def test_symbol_activated_signal_emits_on_double_click(self, qapp):    # noqa: ARG002
        """Double-click triggers the Constituents → Dashboard load
        pathway through ``symbol_activated``."""
        c = ConstituentsTable()
        panel, universe = _make_panel({"Petroleum": ["A", "B"]})
        c.set_industry("Petroleum", ["A", "B"], panel, universe)

        captured: list[str] = []
        c.symbol_activated.connect(captured.append)

        # Simulate the double-click path through the internal slot.
        c._on_activated(0, 0)
        assert len(captured) == 1
        assert captured[0] in {"A", "B"}

    def test_symbol_activated_ignores_negative_row(self, qapp):    # noqa: ARG002
        c = ConstituentsTable()
        captured: list[str] = []
        c.symbol_activated.connect(captured.append)
        c._on_activated(-1, 0)
        assert captured == []

    def test_score_descending_default_sort(self, qapp):    # noqa: ARG002
        """Rows must initially be ordered by Score descending so the
        most-conviction symbols appear at the top of the constituent
        list. NaN scores sink to the bottom."""
        c = ConstituentsTable()
        panel, universe = _make_panel({
            "Petroleum": [f"S{i}" for i in range(5)],
        })
        c.set_industry(
            "Petroleum", [f"S{i}" for i in range(5)], panel, universe,
        )
        score_col = CONSTITUENT_COLUMNS.index("Score")
        from PyQt6.QtCore import Qt

        seen_scores = []
        for r in range(c._table.rowCount()):
            v = c._table.item(r, score_col).data(Qt.ItemDataRole.UserRole)
            seen_scores.append(v)
        # Strip Nones / NaNs (which sink), check the rest are descending.
        non_null = [s for s in seen_scores if s is not None and s == s]
        assert non_null == sorted(non_null, reverse=True)


# ══════════════════════════════════════════════════════════════════════════════
# Format helpers
# ══════════════════════════════════════════════════════════════════════════════


class TestFormatHelpers:
    def test_format_adtv_m_basic(self):
        assert _format_adtv_m(946_000_000) == "946 M"
        assert _format_adtv_m(65_300_000_000) == "65,300 M"

    def test_format_adtv_m_handles_nan(self):
        assert _format_adtv_m(float("nan")) == "—"

    def test_format_adtv_m_handles_zero_or_negative(self):
        assert _format_adtv_m(0) == "—"
        assert _format_adtv_m(-1.0) == "—"
