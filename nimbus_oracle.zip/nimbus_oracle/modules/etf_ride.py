"""
modules/etf_ride.py — ETF BB Upper Band Ride Momentum Engine.

Single source of truth for ETF BB ride signals — same architecture
as BBRideEngine / ConvictionEngine / ETFMomentumEngine:
  - ETFRideEngine class: stateless, compute once, read everywhere
  - Module-level singleton + convenience function
  - No UI, no data fetching, no side effects

DIFFERENT from equity BBRideEngine in grade factors and VIX handling.
Reuses the same BB(1σ) signal extraction (identical indicators).

Usage:
    from modules.etf_ride import compute_etf_ride
    result = compute_etf_ride(price_df, symbol="BANKBEES",
                               vix_regime="ELEVATED", etf_type="CYCLICAL")

Backtest validation (660 trades, 20 ETFs, 5yr):
    Default BB(1σ) mid-break:  Sh 4.13, Win 42.7%, Avg +1.12%
    Best: trail 3×ATR MH=40:  Sh 4.82, Win 56.3%, Avg +1.95%
    ELEVATED+BROAD:            Sh 11.14, Win 64.3%, Avg +3.06%
    ELEVATED+CYCLICAL:         Sh 7.68, Win 56.2%, Avg +2.57%

CRITICAL: VIX NORMAL = LOSS MAKER on ETFs (7yr: Sh -0.31, N=336).
    NORMAL+DEFENSIVE:          Sh -0.46 — avoid
    NORMAL+CYCLICAL:           Sh -0.78 — avoid

Grade factors (ETF-specific, different from equities):
    KEEP (r > +0.03 in ETF backtest):
        ADX:  r=+0.118 (strongest — ETFs need trend confirmation)
        BBW:  r=+0.081 (wider bands = more room to run)
        RSI:  r=+0.080 (momentum confirmed)
    DROP (noise or inverted in ETF backtest):
        Volume: r=-0.021 (institutional flow, irrelevant)
        ROC:    r=-0.008 (noise)
        %B:     r=-0.006 (noise)
        MFI:    r=+0.058 (borderline, inconsistent across timeframes)
"""

from __future__ import annotations
import logging, math
import numpy as np, pandas as pd
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# RESULT DATACLASS (the public interface — all UI reads this)
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ETFRideResult:
    """Complete ETF BB ride output — signal + grade + verdict + targets.
    This is what UI components receive. Single source of truth."""
    # Signal data (copied from BBRideSignal)
    symbol: str = ""
    close: float = 0.0
    bb_upper: float = 0.0
    bb_mid: float = 0.0
    bb_pct: float = 0.5
    bbw: float = 0.0
    bbw_slope: float = 0.0
    vol_ratio: float = 0.0
    rsi: float = 50.0
    mfi: float = 50.0
    adx: float = 20.0
    atr: float = 0.0
    roc_10: float = 0.0
    pct_from_sma50: float = 0.0
    above_sma50: bool = False
    entry_triggered: bool = False
    entry_reason: str = ""
    data_sufficient: bool = False
    # Grade
    grade: str = "—"
    grade_pts: int = 0
    verdict: str = ""
    sizing: str = "SKIP"
    # Context
    vix_regime: str = "UNKNOWN"
    etf_type: str = "UNKNOWN"  # CYCLICAL/DEFENSIVE/BROAD/THEMATIC/COMMODITY
    quality_rank: float = 0.0
    # VIX gate
    vix_gated: bool = False    # True when NORMAL VIX suppresses entry
    # Targets (ETF-specific: MH=40 from sweep winner)
    trailing_atr_mult: float = 3.0
    profit_target: float = 10.0
    max_hold: int = 40         # ETFs ride longer than equities (30)
    trail_stop: float = 0.0
    trail_pct: float = 0.0
    pt_price: float = 0.0


# ══════════════════════════════════════════════════════════════════════════════
# ETF TYPE CLASSIFICATION
# ══════════════════════════════════════════════════════════════════════════════

_ETF_TYPE = {
    # Broad market
    "NIFTYBEES": "BROAD", "SETFNIF50": "BROAD", "JUNIORBEES": "BROAD",
    "NV20IETF": "BROAD", "N100": "BROAD",
    # Sectoral — Cyclical
    "BANKBEES": "CYCLICAL", "SETFNIFBK": "CYCLICAL", "PSUBNKBEES": "CYCLICAL",
    "FINIETF": "CYCLICAL", "AUTOIETF": "CYCLICAL", "INFRABEES": "CYCLICAL",
    "CPSEETF": "CYCLICAL", "METALIETF": "CYCLICAL", "OILIETF": "CYCLICAL",
    "COMMOIETF": "CYCLICAL",
    # Sectoral — Defensive
    "ITBEES": "DEFENSIVE", "PHARMABEES": "DEFENSIVE", "FMCGIETF": "DEFENSIVE",
    "HEALTHIETF": "DEFENSIVE",
    # Thematic
    "MOM100": "THEMATIC", "LOWVOLIETF": "THEMATIC", "MIDCAPIETF": "THEMATIC",
    "MAFANG": "THEMATIC",
    # Commodity
    "GOLDBEES": "COMMODITY", "GOLDCASE": "COMMODITY", "GOLDETF": "COMMODITY",
    "IVZINGOLD": "COMMODITY", "SILVERBEES": "COMMODITY", "SILVERIETF": "COMMODITY",
}


# ══════════════════════════════════════════════════════════════════════════════
# ENGINE
# ══════════════════════════════════════════════════════════════════════════════

class ETFRideEngine:
    """
    Stateless ETF BB ride calculator — single source of truth.

    Same architecture as BBRideEngine but with ETF-specific grading:
      - ADX, BBW, RSI as grade factors (not Volume)
      - VIX NORMAL gate (Sh -0.31 over 7yr = loss maker)
      - MH=40 (ETFs ride longer)
      - ETF type classification (CYCLICAL/BROAD/DEFENSIVE/COMMODITY)

    Reuses BBRideEngine._extract_signal() for indicator computation
    (identical BB(1σ) bands, ATR, RSI, etc.)
    """

    # ── VIX grade points (validated on ETFs: ELEVATED Sh 7.42, PANIC 6.82) ──
    _VIX_GRADE_PTS = {
        "PANIC": 3,      # Sh 7.89 (7yr)
        "ELEVATED": 3,   # Sh 6.24 (7yr)
        "LOW": 2,        # Sh 4.55 (7yr)
        "NORMAL": -1,    # Sh -0.31 (7yr) — LOSS MAKER, penalize
        "UNKNOWN": 0,
    }

    # ── Grade thresholds (max ~8 pts: VIX 3 + ADX 2 + BBW 2 + RSI 1) ──
    _GRADE_MAP = [
        (7, "A+"), (6, "A"), (5, "B+"), (4, "B"), (3, "C+"), (2, "C"),
    ]

    _GRADE_SIZING = {
        "A+": "FULL", "A": "FULL",
        "B+": "HALF", "B": "HALF",
        "C+": "SKIP", "C": "SKIP", "D": "SKIP", "—": "SKIP",
    }

    # ── ETF type grade bonus ──
    _ETF_TYPE_PTS = {
        "BROAD": 1,      # ELEVATED+BROAD = Sh 11.14
        "CYCLICAL": 1,   # ELEVATED+CYCLICAL = Sh 7.68
        "THEMATIC": 1,   # Sh 5.73
        "COMMODITY": 0,  # Mixed results
        "DEFENSIVE": 0,  # Sh 3.07
        "UNKNOWN": 0,
    }

    def compute(self, price_df: pd.DataFrame, symbol: str = "",
                vix_regime: str = "UNKNOWN", etf_type: str = None) -> ETFRideResult:
        """Compute everything: signal + grade + verdict + targets. THE single entry point."""
        # Auto-detect ETF type from symbol if not provided
        if etf_type is None:
            etf_type = _ETF_TYPE.get(symbol, "UNKNOWN")

        r = ETFRideResult(symbol=symbol, vix_regime=vix_regime, etf_type=etf_type)

        # Reuse equity engine's signal extraction (identical indicators)
        from modules.bb_ride import _engine as _equity_engine
        sig = _equity_engine._extract_signal(price_df, symbol)

        if not sig.data_sufficient:
            return r

        # Copy signal → result
        for f in ("close", "bb_upper", "bb_mid", "bb_pct", "bbw", "bbw_slope",
                  "vol_ratio", "rsi", "mfi", "adx", "atr", "roc_10",
                  "pct_from_sma50", "above_sma50", "entry_triggered", "entry_reason"):
            setattr(r, f, getattr(sig, f))
        r.data_sufficient = True

        # Targets (ETF params: trail 3×ATR, PT 10%, MH 40)
        r.trail_stop = sig.close - r.trailing_atr_mult * sig.atr if sig.atr > 0 else 0
        r.trail_pct = (sig.close - r.trail_stop) / sig.close * 100 if sig.close > 0 else 0
        r.pt_price = sig.close * (1 + r.profit_target / 100)

        # Non-entry: verdict only
        if not sig.entry_triggered:
            r.verdict = self._build_non_entry_verdict(sig)
            return r

        # ── VIX NORMAL gate ────────────────────────────────────
        # NORMAL VIX on ETFs: Sh -0.31 over 7yr (336 trades) = confirmed loss maker
        if vix_regime == "NORMAL":
            r.vix_gated = True
            r.grade = "D"
            r.sizing = "SKIP"
            r.verdict = f"⚠ VIX NORMAL — ETF ride unprofitable in this regime (%B={sig.bb_pct:.2f})"
            return r

        # ── Grade (ETF-specific factors) ───────────────────────
        r.grade_pts = self._compute_grade_pts(sig, r)
        r.grade = "D"
        for threshold, grade in self._GRADE_MAP:
            if r.grade_pts >= threshold:
                r.grade = grade
                break
        r.sizing = self._GRADE_SIZING.get(r.grade, "SKIP")
        r.quality_rank = self._compute_quality_rank(sig, r)
        r.verdict = self._build_entry_verdict(sig, r)

        return r

    def _compute_grade_pts(self, sig, r) -> int:
        """
        ETF-specific grade factors (validated on 660 trades, 20 ETFs, 5yr):

            VIX regime:  ELEVATED/PANIC +3, LOW +2, NORMAL -1
            ADX:         ≥25 +2, ≥15 +1  (r=+0.118, strongest ETF factor)
            BBW:         ≥5% +2, ≥3% +1  (r=+0.081, wider bands = room to run)
            RSI:         ≥60 +1           (r=+0.080, momentum confirmed)
            ETF type:    BROAD/CYCLICAL/THEMATIC +1

        Dropped (noise/inverted on ETFs):
            Volume (r=-0.021), ROC (r=-0.008), %B (r=-0.006)
        """
        pts = 0
        pts += self._VIX_GRADE_PTS.get(r.vix_regime, 0)

        # ADX — strongest ETF predictor
        if sig.adx >= 25:
            pts += 2
        elif sig.adx >= 15:
            pts += 1

        # BBW — wider bands = more room
        if sig.bbw >= 5:
            pts += 2
        elif sig.bbw >= 3:
            pts += 1

        # RSI — momentum confirmation
        if sig.rsi >= 60:
            pts += 1

        # ETF type bonus
        pts += self._ETF_TYPE_PTS.get(r.etf_type, 0)

        return pts

    def _compute_quality_rank(self, sig, r) -> float:
        """Continuous 0-100 for within-grade ordering. ETF-specific weights."""
        q = 0.0
        # ADX (30pts — strongest)
        adx_val = max(10, min(40, sig.adx))
        q += ((adx_val - 10) / 30) * 30
        # BBW (25pts)
        bbw_val = max(1, min(10, sig.bbw))
        q += ((bbw_val - 1) / 9) * 25
        # RSI (20pts)
        rsi_val = max(40, min(80, sig.rsi))
        q += ((rsi_val - 40) / 40) * 20
        # %B (10pts — slight preference for deeper penetration)
        pctb = max(1.0, min(1.5, sig.bb_pct))
        q += ((pctb - 1.0) / 0.5) * 10
        # Above SMA50 (15pts)
        if sig.above_sma50:
            q += 15
        return round(max(0, min(100, q)), 1)

    def _build_entry_verdict(self, sig, r) -> str:
        cats = []
        if r.vix_regime in ("ELEVATED", "PANIC"):
            cats.append(f"VIX {r.vix_regime.lower()}")
        if r.etf_type in ("CYCLICAL", "BROAD"):
            cats.append(r.etf_type.lower())
        if sig.adx >= 25:
            cats.append(f"ADX {sig.adx:.0f}")
        elif sig.adx >= 15:
            cats.append("trending")
        if sig.bbw >= 5:
            cats.append("wide bands")
        if sig.rsi >= 60:
            cats.append(f"RSI {sig.rsi:.0f}")
        cat_str = ", ".join(cats[:3]) if cats else "BB upper touch"

        if r.sizing == "FULL":
            return f"▶ ETF RIDE FULL [{r.grade}] — {cat_str}"
        elif r.sizing == "HALF":
            return f"▷ ETF RIDE HALF [{r.grade}] — {cat_str}"
        return f"▽ ETF WATCH [{r.grade}] — {cat_str}"

    def _build_non_entry_verdict(self, sig) -> str:
        if not sig.data_sufficient:
            return "— insufficient data"
        if sig.at_upper and not sig.was_below_upper:
            return f"△ RIDING — at upper band, %B={sig.bb_pct:.2f}"
        if sig.bb_pct >= 0.75:
            return f"▽ WATCH — near upper, %B={sig.bb_pct:.2f}"
        if sig.bb_pct >= 0.5:
            return f"▽ NEUTRAL — mid-band, %B={sig.bb_pct:.2f}"
        return f"▽ SKIP — below mid-band, %B={sig.bb_pct:.2f}"

    @staticmethod
    def get_etf_type(symbol: str) -> str:
        return _ETF_TYPE.get(symbol, "UNKNOWN")


# ══════════════════════════════════════════════════════════════════════════════
# MODULE-LEVEL SINGLETON + CONVENIENCE FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

_etf_ride_engine = ETFRideEngine()


def compute_etf_ride(price_df: pd.DataFrame, symbol: str = "",
                     vix_regime: str = "UNKNOWN",
                     etf_type: str = None) -> ETFRideResult:
    """Convenience function — calls the singleton engine.
    Single source of truth for ETF BB ride momentum."""
    return _etf_ride_engine.compute(price_df, symbol=symbol,
                                     vix_regime=vix_regime, etf_type=etf_type)
