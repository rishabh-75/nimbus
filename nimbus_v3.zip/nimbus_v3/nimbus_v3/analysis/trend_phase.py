"""nimbus_v3.analysis.trend_phase — trend maturity + snap-back risk.

Classifies a trending instrument into one of six phases and computes
a 0-10 snap-back risk score. Exists because pure ROC-based rankings
(like the Market Context composite) can't distinguish a fresh
breakout from a late-cycle parabolic blow-off — they look identical
on momentum alone, but the expected forward return is very
different. This module adds the *quality* dimension by factoring in:

- **Extension from SMA_50** — how stretched price is from its
  intermediate-term mean. 3-10% is healthy trend; >18% is euphoric.
- **ROC acceleration** (``roc_5 - roc_20``) — is short-term momentum
  accelerating relative to the longer window? Late-cycle moves
  typically accelerate just before reversing.
- **Bollinger %B** — where price sits relative to its 1σ bands.
  Values >1.0 mean price is outside the upper band (overextended);
  >1.1 is parabolic territory.

The six phases form a cycle: EARLY → MID → LATE → EUPHORIA →
DECLINE → NEUTRAL (choppy / return to mean) → EARLY again.

Default thresholds come from existing conventions in the codebase
(BB upper = mean + 1σ, ride-zone definition, SMA_50 mature-trend
gate). These are tunable via ``PhaseThresholds`` — see
``scripts/run_phase_calibration.py`` for an OOS-driven refinement
path using actual forward-return outcomes.

Empirical calibration (NIFTY 500, 2020-2026, 565k bars)
═══════════════════════════════════════════════════════

The default thresholds produce stable forward-return stratification
on Indian equities. Key findings at H = 10 trading days (the user's
max holding horizon):

                    n     fwd_10d     dd_10d    ret/|dd|
    EARLY       61,898     +1.18%     -3.38%     0.350
    MID         89,384     +1.59%     -3.58%     0.443  ← best risk-adj.
    LATE       157,217     +1.49%     -3.68%     0.404
    EUPHORIA    26,520     +2.13%     -5.13%     0.415  ← highest return
    NEUTRAL     45,055     +0.92%     -3.66%     0.252
    DECLINE    185,245     +0.98%     -3.73%     0.263

Three non-obvious results worth preserving:

1. **MID > EUPHORIA on risk-adjusted return at 10d.** EUPHORIA has
   higher absolute return but its drawdown grows faster. MID is the
   sweet spot for this holding horizon.
2. **EUPHORIA does not exhaust within 60 days.** Per-day return
   rate stays ~0.22%/day through H=60 — no momentum decay visible
   in the sample window. Indian momentum is structurally durable.
   The earlier hypothesis that "parabolic = imminent snap-back"
   was wrong for this market.
3. **Four candidate features failed the 80/20 screen.**
   vol_ratio_20, vol_trend, trend_age, and rs_vs_market were all
   tested via within-phase median splits and none produced ≥0.8%
   forward-return spread in ≥2 trending phases. The phase labels
   are already capturing the available signal.

The Market Context UI colour semantics (EARLY blue, MID green, LATE
emerald, EUPHORIA gold, DECLINE red) are derived directly from this
table, but chosen for visual distinctiveness so adjacent trending
phases read as different at a glance. See
``nimbus_v3/ui/widgets/market_context_tab.py::_phase_color``.

Quality gates (ablation-validated, Apr 2026)
════════════════════════════════════════════

An earlier iteration layered six "quality gates" onto MID and five
onto EARLY, each derived from chart-reading intuition: above_20,
ROC_5 floor, ROC_20 floor, ROC_5+ROC_10 deceleration, distribution
(weak price + volume collapse), V-recovery (ROC_10 >> ROC_20).

Ablation on 569k historical rows (463 symbols × 6 years, script at
``scripts/run_gate_ablation.py``) showed most of those gates were
either actively harmful or statistical noise:

    Gate                Phase     Δ fwd10     t-stat    Decision
    ──────────────────────────────────────────────────────────────
    roc_5_lt_m1         MID      +0.55pp     +10.33    DROPPED (harmful)
    deceleration        MID      +0.52pp      +8.72    DROPPED (harmful)
    above_20            MID      +0.27pp      +4.67    DROPPED (harmful)
    roc_5_lt_m05        EARLY    +0.26pp      +4.40    DROPPED (harmful)
    distribution        MID      +0.18pp      +1.78    DROPPED (noise)
    roc_20_lt_m2        MID      +0.03pp      +0.27    DROPPED (noise)
    distribution        LATE     +0.29pp      +1.31    DROPPED (noise, wrong dir)
    v_recovery          MID      -0.24pp      -0.55    DROPPED (noise, tiny n)
    v_recovery          EUPHORIA +0.14pp      +0.13    DROPPED (noise)

The four gates that SURVIVED ablation (i.e. the NEUTRAL-routed
cohort measurably underperformed the kept cohort):

    roc_20_lt_m2        LATE     -1.22pp      -5.84    KEPT (strongest gate)
    distribution        EUPHORIA -2.03pp      -2.14    KEPT (small-n but strong)
    roc_20_lt_m3        EUPHORIA -1.60pp      -1.68    KEPT (conservative)
    v_recovery          LATE     -0.38pp      -2.14    KEPT (weak but real)

Takeaway: **short-term weakness signals on MID-range Indian equities
mean-revert UPWARD on 10-day horizons**, contrary to chart intuition.
The TEJASNET rollover topology looks dangerous but its average
forward return over 10 days is indistinguishable from clean MID
stocks. Only stretched-LATE and parabolic-EUPHORIA tops produce
measurable forward underperformance, and only via specific gates.

MID and EARLY therefore operate on **pure extension assignment** —
no quality gates. This is the ablation-driven reality, not
chart-reader intuition.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class TrendPhase(str, Enum):
    """Position in the trend lifecycle.

    Ordered so the string comparison matches narrative progression:
    EARLY (fresh) → MID (mature) → LATE (stretched) → EUPHORIA
    (climactic / parabolic) → DECLINE (broken) → NEUTRAL (choppy).
    """
    EARLY    = "EARLY"       #: Fresh breakout; above SMA_20, near trend line
    MID      = "MID"         #: Healthy ride; above both SMAs, moderate extension
    LATE     = "LATE"        #: Stretched; tighten stops
    EUPHORIA = "EUPHORIA"    #: Parabolic; highest abs return + widest DD
    DECLINE  = "DECLINE"     #: Below SMA_50; downtrend
    NEUTRAL  = "NEUTRAL"     #: Choppy around SMAs


@dataclass(frozen=True)
class PhaseThresholds:
    """Tunable thresholds for phase classification.

    Defaults are first-principles values derived from the BB/SMA
    conventions already used in the codebase:

    - ``ext_healthy`` (3%) — minimum stretch above SMA_50 to be
      called "meaningfully trending" rather than "just crossed".
    - ``ext_mature`` (12%) — typical pain point where mean-reversion
      probability starts rising on Indian equities.
    - ``ext_euphoric`` (18%) — blow-off territory; very few moves
      sustain above this without a snap-back.
    - ``accel_strong`` (5%) — ROC_5 - ROC_20 gap that indicates
      clear acceleration (parabola signature).
    - ``bb_stretched`` (1.0) — price above the 1σ upper band.
    - ``bb_parabolic`` (1.1) — price meaningfully beyond the band
      (the "outside the ride zone" signal in BB parlance).

    Refine these values empirically via
    ``scripts/run_phase_calibration.py`` which buckets historical
    signals by feature value and reports forward-return + drawdown
    statistics per bucket. The bucket boundaries that maximize the
    forward-return spread across phases are the best thresholds.
    """
    ext_healthy:   float = 3.0
    ext_mature:    float = 12.0
    ext_euphoric:  float = 18.0
    accel_strong:  float = 5.0
    bb_stretched:  float = 1.0
    bb_parabolic:  float = 1.1


#: Module-level default — used when callers don't supply thresholds.
DEFAULT_THRESHOLDS: PhaseThresholds = PhaseThresholds()


@dataclass(frozen=True)
class PhaseResult:
    """Classification output with transparency on inputs used.

    The raw features are retained so UIs can show them as tooltips
    or secondary columns — operators asked why a row was tagged
    EUPHORIA shouldn't have to recompute.
    """
    phase: TrendPhase
    #: 0.0-10.0. Linear combination of extension (0-5), acceleration
    #: (0-3), and BB overshoot (0-2). Higher = more likely to snap
    #: back in the near term.
    snapback_risk: float
    #: Percent above/below SMA_50 (signed).
    ext_pct: float
    #: ROC_5 - ROC_20 (signed). Positive = accelerating.
    roc_accel: float
    #: Bollinger %B — 0.5 is at mid-band, 1.0 at upper band, >1.1
    #: is outside the band.
    bb_pct: float


def classify_phase(
    close: float,
    sma_20: float,
    sma_50: float,
    roc_5: float,
    roc_20: float,
    bb_pct: float,
    thresholds: PhaseThresholds = DEFAULT_THRESHOLDS,
    *,
    roc_10: float = 0.0,
    vol_chg_20: float = 0.0,
    vol_chg_60: float | None = None,
) -> PhaseResult:
    """Classify the trend phase and compute snap-back risk.

    Pure function — idempotent, no side-effects. Inputs are
    single-bar scalars so the function fits naturally into any
    per-row loop (dashboard one-shot, market-context bulk, research
    backtest).

    Keyword-only quality inputs preserve backward-compat:

    - ``roc_10``: 10-day rate-of-change (%). Used in the MID/EARLY
      deceleration check — when both ROC_5 and ROC_10 are negative
      the trend is turning down regardless of 20-day strength.
    - ``vol_chg_20``: 20-day volume change (% vs prior 20d). Legacy
      volume input; kept for callers that haven't been updated to
      supply ``vol_chg_60``.
    - ``vol_chg_60``: 60-day volume change (% vs prior 60d). The
      preferred window for the EUPHORIA distribution gate — volume
      research on 537k rows showed the 60d window has materially
      stronger edge at the 20d horizon (-0.57pp, t=-8.93) vs the
      20d window (-0.32pp, t=-5.60) for the same
      ``feature < -40 AND ROC_5 < 0`` signature. When ``vol_chg_60``
      is supplied, it's used in the distribution gate; when it's
      ``None`` (default for legacy callers), ``vol_chg_20`` is used
      as fallback.

    Callers that don't supply these default to values that never
    trigger the checks, so behaviour matches the original when only
    the six positional args are provided.

    Decision flow:

    1. **Structural gates** — where is price relative to the SMAs?

       - Below SMA_50: ``DECLINE`` (also below SMA_20) or ``NEUTRAL``
         (bear bounce — above SMA_20 despite below SMA_50).
       - Above SMA_50 but below SMA_20: ``NEUTRAL`` (rollover /
         distribution — the classic post-spike topology where the
         longer MA hasn't caught down yet but short-term support
         has already broken).

    2. **Extension + acceleration** — once structural gates pass,
       bucket by how stretched the move is:

       - ``ext ≥ euphoric`` AND (accelerating OR BB parabolic)
         → ``EUPHORIA``
       - ``ext ≥ mature`` OR ``BB ≥ stretched`` → ``LATE``
       - ``ext ≥ healthy`` → ``MID``
       - otherwise → ``EARLY``

    3. **ROC_20 quality override.** A critical safety net. A stock
       can satisfy every structural + extension gate yet still be
       in distribution rather than accumulation — if 20-day ROC is
       materially negative, the move is dying. Any phase that would
       otherwise fire gets downgraded to ``NEUTRAL``:

       - EARLY / MID / LATE: ``NEUTRAL`` if ``roc_20 < -2%``
       - EUPHORIA: ``NEUTRAL`` if ``roc_20 < -3%`` (looser because
         EUPHORIA is volatile by nature; small dips are part of the
         regime)

       Example: TEJASNET post-blow-off had ext=+3.5%, above SMA_50,
       but ROC_20 = -4.99% — without this gate it classified as
       MID ("Sweet spot"), which was misleading because the move
       had already died.

    Snap-back risk is a weighted sum capped at 10:
    extension contributes 0-5 pts (linear ramp to euphoric),
    acceleration contributes 0-3 pts, BB overshoot 0-2 pts.
    Note: snap-back risk is computed regardless of the quality
    gate outcome, so downstream consumers can still read "how
    stretched was this stock" even when phase landed at NEUTRAL.
    """
    # Trend state first — no point computing risk on downtrends.
    if sma_50 <= 0:
        # Degenerate data — can't compute ratios safely.
        return PhaseResult(
            phase=TrendPhase.NEUTRAL, snapback_risk=0.0,
            ext_pct=0.0, roc_accel=roc_5 - roc_20, bb_pct=bb_pct,
        )

    ext_pct = (close - sma_50) / sma_50 * 100.0
    roc_accel = roc_5 - roc_20
    above_20 = close > sma_20
    above_50 = close > sma_50

    if not above_50:
        return PhaseResult(
            phase=TrendPhase.DECLINE if not above_20 else TrendPhase.NEUTRAL,
            snapback_risk=0.0,
            ext_pct=round(ext_pct, 2),
            roc_accel=round(roc_accel, 2),
            bb_pct=round(bb_pct, 2),
        )

    # NOTE: The earlier version hoisted an ``if not above_20: NEUTRAL``
    # gate *here* — before the phase bucket. That was too aggressive:
    # a stock with ext_pct=15% (clearly LATE) briefly dipping below
    # SMA_20 during a pullback would incorrectly read NEUTRAL, losing
    # the "Ride with stops" signal. The fix is to scope the above_20
    # check down into MID / EARLY specifically (see bucket below),
    # because those labels imply "healthy ride" which *requires*
    # short-term support. LATE and EUPHORIA are extension-dominant
    # and survive SMA_20 wicks.

    # Snap-back risk components (each capped, then summed).
    risk_ext = min(
        5.0,
        max(0.0, ext_pct / thresholds.ext_euphoric * 5.0),
    )
    risk_accel = min(
        3.0,
        max(0.0, roc_accel / thresholds.accel_strong * 3.0),
    )
    # BB overshoot: maps [stretched..parabolic] → [0..2].
    band_range = max(
        0.001,
        thresholds.bb_parabolic - thresholds.bb_stretched,
    )
    risk_bb = min(
        2.0,
        max(0.0, (bb_pct - thresholds.bb_stretched) / band_range * 2.0),
    )
    snapback = round(risk_ext + risk_accel + risk_bb, 1)

    # Phase bucket. EUPHORIA and LATE keep empirically-validated
    # quality gates (see scripts/run_gate_ablation.py). MID and
    # EARLY are assigned purely by extension — no quality gates.
    #
    # History: an earlier version layered six gates onto MID
    # (above_20, ROC_20 floor, ROC_5 floor, decel, distribution,
    # V-recovery). Ablation on 569k rows across 463 symbols × 6
    # years showed two of them were actively harmful (ROC_5<-1%
    # flagged future winners at +0.55pp, t=+10.33; decel at
    # +0.52pp, t=+8.72) and the rest were noise. Net effect: MID's
    # forward-10d return degraded from +1.58% to +1.36% when the
    # gates were active. Stripped back to nothing — on 10-day
    # horizons on Indian equities, "MID stock showing short-term
    # weakness" mean-reverts higher, not lower. The TEJASNET-style
    # rollover topology *looks* dangerous but doesn't actually
    # underperform over 10 days on average. Chart intuition lost
    # to data; the label follows the data.
    if ext_pct >= thresholds.ext_euphoric and (
        roc_accel > 0 or bb_pct >= thresholds.bb_parabolic
    ):
        # EUPHORIA quality gates (ablation-validated):
        #
        #   (1) ROC_20 < -3% — grinding parabola → NEUTRAL.
        #       Ablation: -1.60pp delta, t=-1.68, n=184. Weak
        #       working on a small sample but directionally
        #       strong; kept conservatively.
        #
        #   (2) Distribution (ROC_5 < 0 AND vol_chg < -40%).
        #       Prefers vol_chg_60 when supplied — volume research
        #       (scripts/run_volume_feature_research.py on 537k
        #       rows) showed the 60d-vs-prior-60d window carries
        #       stronger forward-return edge at the 20d horizon
        #       (-0.57pp, t=-8.93) than vol_chg_20 (-0.32pp,
        #       t=-5.60). Falls back to vol_chg_20 for legacy
        #       callers that don't supply the 60d window.
        #
        # V-recovery dropped from EUPHORIA: ablation showed +0.14pp
        # (noise, t=+0.13, n=129). Parabolic stocks bouncing off
        # crashes don't meaningfully underperform.
        vol_chg_signal = (
            vol_chg_60 if vol_chg_60 is not None else vol_chg_20
        )
        if (roc_20 < -3.0
                or (roc_5 < 0 and vol_chg_signal < -40.0)):
            phase = TrendPhase.NEUTRAL
        else:
            phase = TrendPhase.EUPHORIA
    elif ext_pct >= thresholds.ext_mature or bb_pct >= thresholds.bb_stretched:
        # LATE quality gates (ablation-validated):
        #
        #   (1) ROC_20 < -2% — the strongest gate in the whole
        #       classifier. Ablation: -1.22pp delta, t=-5.84,
        #       n=1,949. LATE stocks with materially negative 20d
        #       ROC are grinding lower and should read NEUTRAL.
        #
        #   (2) V-recovery (ROC_10 > 10% AND ratio > 2.5×).
        #       Ablation: -0.38pp delta, t=-2.14, n=2,945. Weak
        #       but real — SHRIRAMFIN-type bounces genuinely
        #       underperform kept-LATE stocks.
        #
        # Distribution dropped from LATE: ablation showed +0.29pp
        # (inconclusive, t=+1.31, n=2,084) — the delta went the
        # wrong direction, so keeping it would actively hurt.
        if (roc_20 < -2.0
                or (roc_20 > 0 and roc_20 < 8.0
                    and roc_10 > 10.0
                    and roc_10 > 2.5 * roc_20)):
            phase = TrendPhase.NEUTRAL
        else:
            phase = TrendPhase.LATE
    elif ext_pct >= thresholds.ext_healthy:
        # MID: pure extension assignment. No quality gates —
        # every candidate was either noise or harmful in the
        # ablation. Forward-10d return for this bucket on the
        # full panel is +1.58% — the highest of any phase, and
        # that's the behaviour we want the label to reflect.
        phase = TrendPhase.MID
    else:
        # EARLY: same treatment as MID. Pure extension assignment.
        # All gate candidates (above_20, ROC_20<-1%, ROC_5<-0.5%,
        # decel, distribution) were noise or weakly harmful in
        # the ablation.
        phase = TrendPhase.EARLY

    return PhaseResult(
        phase=phase,
        snapback_risk=snapback,
        ext_pct=round(ext_pct, 2),
        roc_accel=round(roc_accel, 2),
        bb_pct=round(bb_pct, 2),
    )


def quality_adjusted_rank(composite: float, snapback_risk: float) -> float:
    """Penalise raw momentum by snap-back risk.

    Composite measures "how strong is the move"; snapback_risk
    measures "how likely is it to give those gains back". The rank
    is their difference — high composite with low risk wins,
    parabolic stocks get pushed down.

    The 1:1 weighting is deliberate: composite typically lives in
    ±3 to ±15 on Indian equities, snapback in 0-10, so they operate
    on roughly the same scale. If empirical calibration reveals the
    weighting should favour one over the other, add a scalar here.
    """
    return round(composite - snapback_risk, 2)
