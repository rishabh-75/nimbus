# RT-004 · Market-breadth regime — does a confirming tape predict ride sustain?

| Field        | Value                                                       |
|--------------|-------------------------------------------------------------|
| Date         | 2026-06-04                                                  |
| Status       | `validated`                                                 |
| Outcome      | Breadth regime discriminates ride sustain; added as a DISPLAY-ONLY state in the sidebar. Not (yet) a gate. |
| Baked into   | `compute/breadth_regime.py`, sidebar MARKET BREADTH panel   |
| Data window  | Full NSE-500 universe (477 symbols), 92,291 resolved events |

## Question

Do rides fired when the broad market is *confirming* (price up + breadth
expanding + A/D confirming + new-high/low positive) sustain better than
rides fired when it isn't? If so, the regime earns a place as context
(and possibly an entry gate).

## Methodology

- `compute_breadth(panel)` → daily breadth over the full universe.
- Daily regime from 4 signals (5 with optional index price-trend):
  level (%>SMA50 > 50), expand (%>SMA50 rising 10d), ad (A/D line rising
  10d), nhnl (new highs − new lows > 0).
- Two definitions tested: COUNT (signals_on ≥ n−1 → RISK_ON, ≤1 →
  RISK_OFF, else NEUTRAL) and STRICT (all signals on → RISK_ON).
- Ride events built inline from the SAME universe (so events and regime
  share one panel — avoids the universe-mismatch confound). Joined by
  trigger date. Outcome: win = held ≥ phase-median hold.
- Script: `scripts/research/run_breadth_regime_validation.py`.

## Results

Baseline win-rate (held ≥ phase-median): 0.546.

COUNT definition:

| regime   | n      | win_rate | mean_ret% |
|----------|--------|----------|-----------|
| RISK_ON  | 70,587 | 0.558    | +0.71     |
| NEUTRAL  | 13,878 | 0.518    | +0.45     |
| RISK_OFF | 7,826  | 0.493    | +0.09     |

RISK_ON − RISK_OFF: **+6.5pp win, +0.62pp mean return**. Clean monotonic
gradient (RISK_ON > NEUTRAL > RISK_OFF on every metric).

STRICT definition: RISK_ON 0.564 / +0.77 vs RISK_OFF 0.522 / +0.41
(+4.3pp win, +0.36pp return).

Contrast with RT (VIX regime, earlier, not logged): VIX regime did not
discriminate. Breadth — a direct participation measure — does. Direction
matches the thesis.

## Caveats (why display-only, not a gate)

- **In-sample, single 2-year window**; regime params (`SLOPE_LOOKBACK=10`,
  bucket thresholds) were sensible defaults, not cross-validated. Not yet
  checked for sub-period stability.
- **Base rates:** 76% of events already fire in RISK_ON; only 8.5% in
  RISK_OFF. Gating out RISK_OFF removes few entries for a modest lift.
- **Median return is negative in every bucket** (−0.93% even in RISK_ON):
  the edge lives in the right tail, not the typical ride.

## Conclusion & decision

Adopted as a **display-only** regime state in the sidebar MARKET BREADTH
panel (RISK-ON / NEUTRAL / RISK-OFF, coloured). The operator decides
whether to act on a weak tape; the ride scorer is unchanged
(schema_hash 3eb7942e holds). A hard or soft gate is deferred pending a
sub-period stability check.
