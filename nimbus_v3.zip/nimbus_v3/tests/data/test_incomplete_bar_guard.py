"""Regression tests: an in-progress session bar must never be persisted.

BACKGROUND
──────────
``end = today + 1`` is deliberate and correct after the close — it is what
makes today's EOD bar appear promptly, and ``test_end_is_today_plus_one``
pins that. The same request DURING the session returns a half-formed bar:
real Open, as-of-now High/Low/Close, ~a third of the day's volume.

Nothing downstream inspected the bar's date. It reached the raw cache,
whose mtime bump invalidated the enriched cache, which recomputed every
indicator including the partial bar. Worse for a cross-sectional tool:
only clicked symbols refetch intraday, so the panel became MIXED — some
names on today's half-bar, the rest on yesterday's close, ranked against
each other.

These tests pin the boundary guard. They deliberately assert BOTH
directions: dropping during the session, and KEEPING after the close.
A fix that drops too eagerly would break the post-close behaviour the
operator depends on.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pandas as pd
import pytest

from nimbus_v3.core.market_session import is_todays_bar_incomplete
from nimbus_v3.data.price_loader import PriceLoader

_IST = timezone(timedelta(hours=5, minutes=30))

# Wednesday 22 July 2026 / Saturday 25 July 2026.
_WED = (2026, 7, 22)
_SAT = (2026, 7, 25)


def _at(y, m, d, hh, mm=0):
    return datetime(y, m, d, hh, mm, tzinfo=_IST)


# ── session semantics ────────────────────────────────────────────────────
@pytest.mark.parametrize(("label", "now", "expected"), [
    ("pre-open 08:00",      _at(*_WED, 8), True),
    ("mid-session 11:00",   _at(*_WED, 11), True),
    ("one minute to close", _at(*_WED, 15, 29), True),
    ("just closed 15:31",   _at(*_WED, 15, 31), False),
    ("evening 19:00",       _at(*_WED, 19), False),
    ("weekend",             _at(*_SAT, 11), False),
])
def test_todays_bar_incompleteness(label, now, expected):
    """Pre-open counts as incomplete too — a bar dated today at 08:00 is
    not a session, so this is NOT the same predicate as is_market_open."""
    assert is_todays_bar_incomplete(now) is expected, label


def test_incompleteness_is_not_market_open():
    """These two predicates must not be conflated.

    At 08:00 the market is closed but today's bar is still not a real
    session; using ``is_market_open`` as the guard would let a pre-open
    stub through.
    """
    from nimbus_v3.core.market_session import is_market_open
    pre_open = _at(*_WED, 8)
    assert is_market_open(pre_open) is False
    assert is_todays_bar_incomplete(pre_open) is True


# ── the guard itself ─────────────────────────────────────────────────────
def _frame(last_day: str) -> pd.DataFrame:
    idx = pd.bdate_range("2026-07-01", last_day)
    return pd.DataFrame(
        {"Open": 1.0, "High": 1.0, "Low": 1.0, "Close": 1.0, "Volume": 1.0},
        index=idx)


def _run_guard(df, now, monkeypatch):
    """Invoke the guard with a frozen 'now'."""
    monkeypatch.setattr(
        "nimbus_v3.data.price_loader.is_todays_bar_incomplete",
        lambda _now=None: is_todays_bar_incomplete(now))

    class _FrozenDatetime(datetime):
        @classmethod
        def now(cls, tz=None):
            return now
    monkeypatch.setattr("nimbus_v3.data.price_loader.datetime",
                        _FrozenDatetime)
    return PriceLoader._drop_incomplete_session_bar(df)


def test_drops_todays_bar_during_session(monkeypatch):
    df = _frame("2026-07-22")
    out = _run_guard(df, _at(*_WED, 11), monkeypatch)
    assert len(out) == len(df) - 1
    assert out.index[-1].date() == datetime(2026, 7, 21).date()


def test_keeps_todays_bar_after_close(monkeypatch):
    """The post-close behaviour is the whole point of end=today+1."""
    df = _frame("2026-07-22")
    out = _run_guard(df, _at(*_WED, 19), monkeypatch)
    assert len(out) == len(df)
    assert out.index[-1].date() == datetime(2026, 7, 22).date()


def test_leaves_history_untouched_when_no_todays_bar(monkeypatch):
    """Mid-session with a frame that ends yesterday: nothing to drop."""
    df = _frame("2026-07-21")
    out = _run_guard(df, _at(*_WED, 11), monkeypatch)
    assert len(out) == len(df)


def test_empty_frame_survives(monkeypatch):
    out = _run_guard(pd.DataFrame(), _at(*_WED, 11), monkeypatch)
    assert out.empty


def test_only_the_last_bar_is_ever_dropped(monkeypatch):
    """The guard must not touch closed history — indicators are trailing,
    so rewriting a past bar would silently revise settled numbers."""
    df = _frame("2026-07-22")
    before = df.iloc[:-1].copy()
    out = _run_guard(df, _at(*_WED, 11), monkeypatch)
    pd.testing.assert_frame_equal(out, before)
