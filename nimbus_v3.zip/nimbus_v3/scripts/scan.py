"""scripts/scan.py — end-to-end scan against live data.

Composition root: wires every layer (price loader, compute engine,
context providers, strategies, conviction engine) into a single
``Scanner`` and runs it against the equity universe.

Usage
─────

    python scripts/scan.py                # scan today
    python scripts/scan.py --date 2025-01-15

On first run, fetches ~170 NIFTY 200 symbols from yfinance and caches
them under ``data/cache/equity_price/`` (~5-10 min). Subsequent runs
re-enrich from cache in 2-3 seconds, then run the scan.

Output
──────

Sorted scan results printed as a table — highest conviction score
first. Each row shows symbol, strategy, grade, verdict, sizing, score,
and a one-line reason synthesised from the top-3 contributions.

Research-tier signals (``production_weight=0``) appear in the list
with ``WATCH/SKIP`` verdict. Use ``--no-research`` to hide them.

This script is a v3.0 development deliverable: it demonstrates that
the full pipeline works end-to-end on real NSE data. In v3.1, the UI
wraps this same Scanner instance.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import pandas as pd

from nimbus_v3.compute.engine import StrategyComputeEngine
from nimbus_v3.conviction.grade_engine import ConvictionEngine
from nimbus_v3.core.types import VIXRegime
from nimbus_v3.core.universe import SymbolMeta, Universe
from nimbus_v3.research.equity_universe import load_equity_panel
from nimbus_v3.scanner.engine import ContextProviders, Scanner
from nimbus_v3.strategies.breakout import BreakoutStrategy
from nimbus_v3.strategies.drawdown_reversal import DrawdownReversalStrategy
from nimbus_v3.strategies.mean_reversion import MeanReversionStrategy
from nimbus_v3.strategies.pullback_uptrend import PullbackUptrendStrategy
from nimbus_v3.strategies.registry import StrategyRegistry
from nimbus_v3.strategies.ride import RideStrategy
from nimbus_v3.tracking.tracker import SignalTracker

from scripts._composition import (
    ChainedMarketProvider,
    ProxyMarketProvider,
    build_context_providers,
    build_universe_with_sectors,
    universe_from_panel,
)


# Backwards-compatibility aliases — some external callers (run_ui.py before
# refactor, tests) import these names from this module.
_ProxyMarketProvider = ProxyMarketProvider
_universe_from_panel = universe_from_panel


# ══════════════════════════════════════════════════════════════════════════════
# Reporting
# ══════════════════════════════════════════════════════════════════════════════

def _format_reason(conviction) -> str:
    """Synthesise a one-line reason from the top 3 contributions by abs(weighted)."""
    if conviction.override_reason:
        return conviction.override_reason
    contribs = sorted(
        conviction.contributions, key=lambda c: abs(c.weighted), reverse=True,
    )[:3]
    parts = [
        f"{c.name}={c.weighted:+.1f}" for c in contribs if abs(c.weighted) > 0.05
    ]
    return "; ".join(parts) if parts else "no dominant factor"


def _print_results(results: list, *, include_research: bool = True) -> None:
    rows = results
    if not include_research:
        rows = [r for r in rows if r.strategy.production_weight > 0.0]

    if not rows:
        print("\nNo signals in this scan.")
        return

    print()
    print("=" * 120)
    print(
        f"  {'SYMBOL':14s}  {'STRATEGY':18s}  {'GRADE':5s}  "
        f"{'VERDICT':8s}  {'SIZING':6s}  {'SCORE':>7s}   REASON"
    )
    print("=" * 120)
    for r in rows:
        c = r.conviction
        print(
            f"  {r.symbol:14s}  {r.strategy.name:18s}  "
            f"{c.grade.value:5s}  {c.verdict.value:8s}  "
            f"{c.sizing.value:6s}  {c.score:>+7.2f}   {_format_reason(c)}"
        )
    print("=" * 120)
    production = sum(
        1 for r in rows
        if r.strategy.production_weight > 0 and r.conviction.verdict.value == "TAKE"
    )
    research = sum(
        1 for r in rows if r.strategy.production_weight == 0.0
    )
    skipped = sum(
        1 for r in rows if r.conviction.verdict.value == "SKIP"
        and r.strategy.production_weight > 0
    )
    print(
        f"  {len(rows)} signal(s): {production} TAKE (production), "
        f"{research} WATCH (research), {skipped} SKIP (production)."
    )


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--date", type=str, default=None,
        help="Scan as-of date (YYYY-MM-DD). Defaults to today.",
    )
    parser.add_argument(
        "--no-research", action="store_true",
        help="Hide research-tier signals (production_weight=0).",
    )
    parser.add_argument(
        "--symbol", action="append", default=None,
        help="Restrict scan to specific symbols (repeat for multiple).",
    )
    parser.add_argument(
        "--track", type=str, default=None,
        help="Record scan results to the given SQLite database "
             "(default: data/tracking/signals.db if --track is passed without a path). "
             "Subsequent runs append; duplicates are skipped.",
    )
    parser.add_argument(
        "--backfill", action="store_true",
        help="After recording, attempt to backfill forward returns for any "
             "older unfilled rows using the enriched panel.",
    )
    parser.add_argument(
        "--no-live-vix", action="store_true",
        help="Skip the live VIXLoader and use only the synthetic VIX proxy "
             "derived from the equity panel. Useful for offline replays.",
    )
    parser.add_argument(
        "--no-live-sector", action="store_true",
        help="Skip the NSE universe fetch and SectorContextProvider. "
             "Sector contributions will be zero for every signal.",
    )
    parser.add_argument(
        "--no-live-filing", action="store_true",
        help="Skip the FilingContextProvider. Filing contributions will "
             "be zero and the TRAP-filing override path is disabled.",
    )
    args = parser.parse_args()

    asof = (
        pd.Timestamp(args.date) if args.date
        else pd.Timestamp.now().normalize()
    )

    panel = load_equity_panel()
    if not panel:
        print("No equity panel loaded — yfinance unreachable? Stopping.")
        sys.exit(1)

    print(f"Enriching {len(panel)} symbols …")
    compute = StrategyComputeEngine()
    enriched: dict[str, pd.DataFrame] = {}
    for sym, df in panel.items():
        try:
            enriched[sym] = compute.enrich(df, sym)
        except Exception as exc:     # noqa: BLE001
            print(f"  {sym}: enrich failed ({exc})")
            continue

    print("Building universe (sector-annotated) …")
    universe = build_universe_with_sectors(
        enriched, use_live_nse=not args.no_live_sector,
    )
    known_sectors = sum(
        1 for m in universe.symbols.values() if m.sector != "Unknown"
    )
    print(
        f"  {known_sectors}/{len(universe.symbols)} symbols have known sectors"
    )

    print("Building context providers …")
    providers = build_context_providers(
        enriched,
        universe=universe,
        use_live_vix=not args.no_live_vix,
        use_live_sector=not args.no_live_sector,
        use_live_filing=not args.no_live_filing,
    )
    if isinstance(providers.market, ChainedMarketProvider):
        print("  market: live VIXLoader with proxy fallback")
    else:
        print("  market: synthetic VIX proxy only")
    if providers.sector is not None:
        print("  sector: SectorContextProvider wired in")
    else:
        print("  sector: not wired (no known sectors or disabled)")
    if providers.filing is not None:
        print("  filing: FilingContextProvider wired in")
    else:
        print("  filing: not wired (disabled or NSE client failed)")

    registry = StrategyRegistry()
    for strat in (
        MeanReversionStrategy(),
        BreakoutStrategy(),
        RideStrategy(),
        PullbackUptrendStrategy(),
        DrawdownReversalStrategy(),
    ):
        registry.register(strat)

    scanner = Scanner(
        compute_engine=compute,
        registry=registry,
        providers=providers,
        conviction_engine=ConvictionEngine(),
        universe=universe,
    )

    print(f"Running scan for {asof.date()} …")
    results = scanner.scan(
        enriched_panel=enriched,
        asof_date=asof,
        symbols=args.symbol,
    )

    _print_results(results, include_research=not args.no_research)

    # ── Tracking ─────────────────────────────────────────────────────────
    if args.track is not None:
        track_path = Path(args.track) if args.track else Path("data/tracking/signals.db")
        print(f"\nRecording {len(results)} signal(s) to {track_path} …")
        with SignalTracker(track_path) as tracker:
            inserted = tracker.record_many(results)
            print(f"  {inserted} new rows inserted "
                  f"({len(results) - inserted} were duplicates).")
            if args.backfill:
                filled = tracker.backfill_returns(price_panel=panel)
                print(f"  {filled} older rows filled with forward returns "
                      f"({tracker.count_unfilled()} still unfilled).")
            print(f"  total rows in log: {tracker.count()}")


if __name__ == "__main__":
    main()
