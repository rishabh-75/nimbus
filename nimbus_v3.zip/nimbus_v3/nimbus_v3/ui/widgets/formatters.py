"""nimbus_v3.ui.widgets.formatters — shared presentation formatters.

Pure display helpers used by more than one widget. These belong in the
UI layer (they're about how a number reads on screen, not what it
means), but must be defined once so the Dashboard header, the
Constituents/Industries tables, and Market Pulse all speak the same
numeric language.
"""
from __future__ import annotations


def format_adtv_cr(value_inr: float) -> str:
    """Format Average Daily Traded Value (₹) in CRORE — the single
    denomination used app-wide (Dashboard tables + Edge tab) so figures
    read consistently. Bare number, no suffix (the column header carries
    the "₹cr" unit). ``—`` for NaN / non-positive.

    1 crore = ₹10,000,000. Shows one decimal below ₹1cr so thin names
    don't collapse to "0".
    """
    if value_inr != value_inr or value_inr <= 0:
        return "—"
    cr = value_inr / 1e7
    return f"{cr:,.0f}" if cr >= 1 else f"{cr:,.1f}"
