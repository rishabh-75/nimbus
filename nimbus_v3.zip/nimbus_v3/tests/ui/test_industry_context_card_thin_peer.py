"""tests.ui.test_industry_context_card_thin_peer — diagnostic rendering
when a symbol's industry has fewer than MIN_INDUSTRY_SIZE (=5) peers
in the loaded panel.

Replaces the generic "Industry context unavailable" placeholder with
a diagnostic showing the industry name + member count, so the
operator sees WHY peer analytics aren't available rather than
wondering if it's a bug.
"""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pandas as pd
import pytest
from PyQt6.QtWidgets import QApplication

from nimbus_v3.core.industry_relative_state import (
    IndustryRelativeState, ThinPeerContext,
)
from nimbus_v3.ui.widgets.industry_context_card import IndustryContextCard


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _real_state(*, symbol="HDFCBANK", industry="Banks",
                data_sufficient=True) -> IndustryRelativeState:
    """Build a valid IndustryRelativeState for card-rendering tests.
    Values are synthetic but type-correct for every field."""
    return IndustryRelativeState(
        symbol=symbol,
        bar_date=pd.Timestamp("2026-04-22"),
        industry=industry,
        beta_60d=1.05,
        alpha_60d=0.002,
        alpha_percentile=72.0,
        industry_phase="LATE",
        industry_roc_20=5.42,
        industry_breadth_pct=0.96,
        peer_count_in_industry=25,
        peer_rank_in_industry=8,
        is_alpha_leader=True,
        is_high_beta_rider=False,
        is_low_beta_quality=False,
        is_industry_declining=False,
        is_accumulating=False,
        is_alpha_fading=False,
        data_sufficient=data_sufficient,
    )


# ══════════════════════════════════════════════════════════════════════
# ThinPeerContext dataclass
# ══════════════════════════════════════════════════════════════════════

class TestThinPeerContext:

    def test_is_frozen(self):
        """Following the project convention — data carriers are
        frozen dataclasses."""
        ctx = ThinPeerContext(
            industry="Healthcare Equipment & Supplies",
            n_members=1,
            min_required=5,
        )
        with pytest.raises((AttributeError, Exception)):
            ctx.industry = "Banks"

    def test_holds_three_fields(self):
        ctx = ThinPeerContext(
            industry="Gas", n_members=3, min_required=5,
        )
        assert ctx.industry == "Gas"
        assert ctx.n_members == 3
        assert ctx.min_required == 5


# ══════════════════════════════════════════════════════════════════════
# Card rendering priority: real state > thin_peer > empty
# ══════════════════════════════════════════════════════════════════════

class TestCardRenderingPriority:

    def test_none_state_no_thin_peer_shows_generic_empty(self, qapp):
        """Backward-compatible default: no state, no thin_peer →
        generic placeholder."""
        card = IndustryContextCard()
        card.set_state(None)
        assert not card._empty_label.isHidden()
        assert card._empty_label.text() == "Industry context unavailable"

    def test_none_state_with_thin_peer_shows_diagnostic(self, qapp):
        """When state is None but thin_peer is supplied, render the
        thin-peer diagnostic instead of the generic placeholder."""
        card = IndustryContextCard()
        card.set_state(
            None,
            thin_peer=ThinPeerContext(
                industry="Healthcare Equipment & Supplies",
                n_members=1,
                min_required=5,
            ),
        )
        # Empty label is still visible (repurposed as sub-caption)
        # but now carries a different message
        assert not card._empty_label.isHidden()
        assert card._empty_label.text() != "Industry context unavailable"
        # The industry row is populated with the name + member count
        assert not card._row_industry.isHidden()

    def test_real_state_wins_over_thin_peer(self, qapp):
        """If a real IndustryRelativeState is supplied alongside a
        thin_peer context, the real state takes priority."""
        card = IndustryContextCard()
        card.set_state(
            _real_state(),
            thin_peer=ThinPeerContext(
                industry="X", n_members=1, min_required=5,
            ),
        )
        # Full population → empty label hidden
        assert card._empty_label.isHidden()
        # Rows populated (peer rank visible, etc.)
        assert not card._row_phase.isHidden()
        assert not card._row_beta.isHidden()

    def test_insufficient_state_with_thin_peer_falls_back_to_thin(self, qapp):
        """If state is populated but data_sufficient=False, the card
        still falls through to thin_peer if supplied (matches the
        spirit of 'peer analytics aren't reliable here, explain
        why')."""
        card = IndustryContextCard()
        card.set_state(
            _real_state(data_sufficient=False),
            thin_peer=ThinPeerContext(
                industry="Healthcare Equipment & Supplies",
                n_members=1, min_required=5,
            ),
        )
        # Thin-peer diagnostic fired, not generic empty
        assert card._empty_label.text() != "Industry context unavailable"
        assert not card._row_industry.isHidden()


# ══════════════════════════════════════════════════════════════════════
# Thin-peer content format
# ══════════════════════════════════════════════════════════════════════

class TestThinPeerContent:

    def test_industry_row_shows_name_and_count(self, qapp):
        """The INDUSTRY row's value contains both the industry name
        and the member count breakdown."""
        card = IndustryContextCard()
        card.set_state(
            None,
            thin_peer=ThinPeerContext(
                industry="Gas", n_members=3, min_required=5,
            ),
        )
        # Just assert the INDUSTRY row is visible — the exact text
        # format is an implementation detail of _render_thin_peer
        assert not card._row_industry.isHidden()

    def test_other_rows_hidden_in_thin_peer_state(self, qapp):
        """Peer-dependent rows stay hidden — we don't have β/α to
        populate them."""
        card = IndustryContextCard()
        card.set_state(
            None,
            thin_peer=ThinPeerContext(
                industry="Gas", n_members=2, min_required=5,
            ),
        )
        # Peer-relative rows should be hidden
        assert card._row_phase.isHidden()
        assert card._row_roc.isHidden()
        assert card._row_beta.isHidden()
        assert card._row_alpha.isHidden()
        assert card._row_breadth.isHidden()
        assert card._row_peer_rank.isHidden()
        assert card._row_tags.isHidden()

    def test_sub_caption_explains_why(self, qapp):
        """The repurposed empty_label carries a user-facing
        explanation of WHY peer analytics aren't available."""
        card = IndustryContextCard()
        card.set_state(
            None,
            thin_peer=ThinPeerContext(
                industry="Gas", n_members=1, min_required=5,
            ),
        )
        # Just check it says something different from the generic
        # placeholder — exact wording is implementation detail
        text = card._empty_label.text()
        assert text != "Industry context unavailable"
        assert len(text) > 0


# ══════════════════════════════════════════════════════════════════════
# Recovery — switching states cleanly
# ══════════════════════════════════════════════════════════════════════

class TestStateRecovery:

    def test_thin_peer_then_full_state(self, qapp):
        """Switching from thin-peer to a real populated state clears
        the repurposed empty_label text."""
        card = IndustryContextCard()
        # Start with thin-peer
        card.set_state(
            None,
            thin_peer=ThinPeerContext(
                industry="Gas", n_members=1, min_required=5,
            ),
        )
        assert not card._empty_label.isHidden()
        # Switch to real state
        card.set_state(_real_state())
        # Empty label hidden; peer rows visible
        assert card._empty_label.isHidden()
        assert not card._row_beta.isHidden()

    def test_full_state_then_none_shows_generic_empty(self, qapp):
        """Switching from real state to None (no thin_peer) shows
        the standard 'unavailable' placeholder, not the repurposed
        thin-peer message."""
        card = IndustryContextCard()
        card.set_state(_real_state())
        card.set_state(None)
        assert card._empty_label.text() == "Industry context unavailable"
